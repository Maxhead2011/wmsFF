"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientKizPolicyController = void 0;
const client_fulfillment_policy_1 = require("../../common/client-fulfillment-policy");
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const client_kiz_policy_service_1 = require("./client-kiz-policy.service");
let ClientKizPolicyController = class ClientKizPolicyController {
    policy;
    constructor(policy) {
        this.policy = policy;
    }
    fulfillment(id, user) {
        return this.policy.fulfillment(id, user);
    }
    saveFulfillment(id, rule, enabled, user) {
        (0, client_fulfillment_policy_1.requireSettingsEditor)(user.roleCodes);
        return this.policy.saveFulfillment(id, rule, enabled, user);
    }
    get(id, user) { return this.policy.get(id, user); }
    save(id, required, user) {
        (0, client_fulfillment_policy_1.requireSettingsEditor)(user.roleCodes);
        return this.policy.save(id, required, user);
    }
};
exports.ClientKizPolicyController = ClientKizPolicyController;
__decorate([
    (0, common_1.Get)('fulfillment'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientKizPolicyController.prototype, "fulfillment", null);
__decorate([
    (0, common_1.Put)('fulfillment'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)('rule')),
    __param(2, (0, common_1.Body)('enabled')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientKizPolicyController.prototype, "saveFulfillment", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientKizPolicyController.prototype, "get", null);
__decorate([
    (0, common_1.Put)(),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)('required')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientKizPolicyController.prototype, "save", null);
exports.ClientKizPolicyController = ClientKizPolicyController = __decorate([
    (0, common_1.Controller)('clients/:clientId/kiz-policy'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof client_kiz_policy_service_1.ClientKizPolicyService !== "undefined" && client_kiz_policy_service_1.ClientKizPolicyService) === "function" ? _a : Object])
], ClientKizPolicyController);
