"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientKizPolicyService = void 0;
const client_fulfillment_policy_1 = require("../../common/client-fulfillment-policy");
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_receipt_kiz_policy_1 = require("../../common/client-receipt-kiz-policy");
const client_scope_service_1 = require("../auth/client-scope.service");
let ClientKizPolicyService = class ClientKizPolicyService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    async check(clientId, user, mode) {
        if (process.env.WMS_KIZ_CLIENT_GUARD_ENABLED !== 'true')
            throw new common_1.NotFoundException('Настройка обязательных КИЗ не включена.');
        await this.checkClient(clientId, user, mode);
    }
    async checkClient(clientId, user, mode) {
        this.scopes.requireClientAccess(user, clientId, mode);
        if (!await this.prisma.client.findFirst({ where: { id: clientId, isDemo: Boolean(user.isDemo) }, select: { id: true } })) {
            throw new common_1.NotFoundException('Клиент не найден.');
        }
    }
    async fulfillment(id, user) {
        await this.checkClient(id, user, 'read');
        const [zones, pickKiz] = await Promise.all([(0, client_fulfillment_policy_1.activeRule)(this.prisma, id, 'zones'), (0, client_fulfillment_policy_1.activeRule)(this.prisma, id, 'pickKiz')]);
        return { zones, pickKiz, available: { zones: (0, client_fulfillment_policy_1.ruleAvailable)('zones'), pickKiz: (0, client_fulfillment_policy_1.ruleAvailable)('pickKiz') } };
    }
    async saveFulfillment(id, rule, enabled, user) {
        await this.checkClient(id, user, 'write');
        if ((rule !== 'zones' && rule !== 'pickKiz') || typeof enabled !== 'boolean' || !(0, client_fulfillment_policy_1.ruleAvailable)(rule))
            throw new common_1.BadRequestException('Настройка недоступна.');
        const key = (0, client_fulfillment_policy_1.ruleKey)(id, rule);
        await this.prisma.$transaction(async (tx) => {
            await tx.systemSetting.upsert({ where: { key }, create: { key, value: enabled, updatedByUserId: user.id }, update: { value: enabled, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, entity: 'Client', entityId: id, action: 'CLIENT_FULFILLMENT_RULE', payload: { rule, enabled } } });
        });
        return this.fulfillment(id, user);
    }
    async get(clientId, user) {
        await this.check(clientId, user, 'read');
        return { clientId, required: await (0, client_receipt_kiz_policy_1.clientRequiresReceiptKiz)(this.prisma, clientId) };
    }
    async save(clientId, required, user) {
        await this.check(clientId, user, 'write');
        if (typeof required !== 'boolean')
            throw new common_1.BadRequestException('Укажите, обязателен ли КИЗ для всех товаров.');
        const key = (0, client_receipt_kiz_policy_1.clientReceiptKizPolicyKey)(clientId);
        // FIX: setting, existing card flags and audit commit together; no stock mutation.
        return this.prisma.$transaction(async (tx) => {
            const before = await tx.systemSetting.findUnique({ where: { key } });
            await tx.systemSetting.upsert({ where: { key }, create: { key, value: { required }, updatedByUserId: user.id },
                update: { value: { required }, updatedByUserId: user.id } });
            const changed = required ? await tx.sku.updateMany({ where: { clientId, OR: [{ needsChestnyZnak: false }, { isUnmarked: true }] },
                data: { needsChestnyZnak: true, isUnmarked: false } }) : { count: 0 };
            await tx.auditLog.create({ data: { userId: user.id, entity: 'Client', entityId: clientId,
                    action: 'CLIENT_RECEIPT_KIZ_REQUIRED', payload: { before: before?.value ?? null, required, updatedCards: changed.count, stockChanged: false } } });
            return { clientId, required };
        });
    }
};
exports.ClientKizPolicyService = ClientKizPolicyService;
exports.ClientKizPolicyService = ClientKizPolicyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], ClientKizPolicyService);
