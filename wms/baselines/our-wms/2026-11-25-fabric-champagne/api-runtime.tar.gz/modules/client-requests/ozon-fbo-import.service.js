const deadlinePolicy=require("./ozon-supply-policy");
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonFboImportService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const fbo_unboxed_picking_1 = require("../tsd/fbo-unboxed-picking");
const node_crypto_1 = require("node:crypto");
const XLSX = require("xlsx");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const ozon_fbo_xlsx_parser_1 = require("./parsers/ozon-fbo-xlsx.parser");
let OzonFboImportService = class OzonFboImportService {
    db;
    scopes;
    constructor(db, scopes) {
        this.db = db;
        this.scopes = scopes;
    }
    // FIX: scope candidates to this client; never fall back across an internal user's branch.
    async warehouses(clientId, user, mode = 'write') {
        if (process.env.WMS_OZON_FBO_IMPORT_ENABLED !== 'true')
            throw new common_1.NotFoundException('Импорт ФБО Ozon выключен.');
        if (!clientId?.trim())
            throw new common_1.BadRequestException('Выберите клиента.');
        this.scopes.requireClientAccess(user, clientId, mode);
        const scoped = (0, client_request_warehouse_scope_1.effectiveWarehouseId)(user, mode);
        const fixed = scoped ?? (!(user.roleCodes ?? []).includes('CLIENT') ? user.activeWarehouseId : null);
        const rows = await this.db.warehouseClient.findMany({ where: {
                clientId, status: 'ACTIVE', warehouse: { isActive: true }, ...(fixed ? { warehouseId: fixed } : {}),
            }, select: { warehouseId: true, warehouse: { select: { name: true } } }, orderBy: { warehouseId: 'asc' } });
        return rows.map(row => ({ id: row.warehouseId, name: row.warehouse.name }));
    }
    async resolveWarehouse(clientId, user, mode, selected) {
        const choices = await this.warehouses(clientId, user, mode);
        const scoped = (0, client_request_warehouse_scope_1.effectiveWarehouseId)(user, mode);
        const cabinet = (user.roleCodes ?? []).includes('CLIENT');
        const requested = selected?.trim() || scoped || (!cabinet ? user.activeWarehouseId : null);
        if (requested) {
            if (!choices.some(row => row.id === requested))
                throw new common_1.BadRequestException('Выбранный филиал недоступен для этого клиента.');
            return requested;
        }
        if (cabinet && choices.length === 1)
            return choices[0].id;
        throw new common_1.BadRequestException(choices.length ? 'Выберите филиал.' : 'У клиента нет активного филиала.');
    }
    // FIX: the Ozon screen lists the same assemblies it creates, within client and branch scope.
    async list(clientId, user, selectedWarehouseId, view = 'active', allClients, beforeNumber) {
        if (process.env.WMS_OZON_FBO_IMPORT_ENABLED !== 'true')
            throw new common_1.NotFoundException('Импорт ФБО Ozon выключен.');
        if (allClients !== undefined && allClients !== 'true' && allClients !== 'false')
            throw new common_1.BadRequestException('Неизвестный режим списка сборок.');
        // FIX: opt-in affects reads only; imports keep their explicit client/branch requirements.
        const all = allClients === 'true' && process.env.WMS_MARKETPLACE_WORKSPACES_ENABLED === 'true';
        if (!all && !clientId?.trim())
            throw new common_1.BadRequestException('Выберите клиента.');
        if (beforeNumber !== undefined && (!all || typeof beforeNumber !== 'string' || !/^[1-9]\d*$/.test(beforeNumber) || !Number.isSafeInteger(Number(beforeNumber))))
            throw new common_1.BadRequestException('Некорректный номер страницы сборок.');
        let clientFilter = clientId;
        let warehouseId;
        if (all) {
            clientFilter = this.scopes.resolveClientFilter(user, clientId?.trim() || undefined);
            const fixed = (0, client_request_warehouse_scope_1.effectiveWarehouseId)(user, 'read') ?? (!(user.roleCodes ?? []).includes('CLIENT') ? user.activeWarehouseId : null);
            const selected = selectedWarehouseId?.trim();
            if (fixed && selected && fixed !== selected)
                throw new common_1.BadRequestException('Выбранный филиал недоступен в текущем контуре.');
            warehouseId = fixed || selected || undefined;
        }
        else {
            this.scopes.requireClientAccess(user, clientId, 'read');
            warehouseId = await this.resolveWarehouse(clientId, user, 'read', selectedWarehouseId);
        }
        // FIX: filter before take; completed packing alone does not mean handover.
        if (view !== 'active' && view !== 'completed')
            throw new common_1.BadRequestException('Неизвестный список сборок.');
        const closed = [client_1.ClientRequestStatus.DONE, client_1.ClientRequestStatus.CANCELLED, client_1.ClientRequestStatus.REJECTED];
        const rows = await this.db.clientRequest.findMany({ where: { clientId: clientFilter, warehouseId, ozonShipment: { isNot: null },
                ...(beforeNumber !== undefined ? { number: { lt: Number(beforeNumber) } } : {}),
                status: view === 'completed' ? { in: closed } : { notIn: closed } },
            orderBy: all ? { number: 'desc' } : { createdAt: 'desc' }, take: 100, select: { id: true, clientId: true, number: true, title: true, status: true, desiredDate: true, destinationCity: true,
                ...(all ? { clientId: true, createdAt: true, client: { select: { name: true, code: true } }, warehouse: { select: { name: true } } } : {}),
                items: { select: { quantity: true, ...(all ? { name: true, barcode: true } : {}) } }, ozonShipment: { select: { directions: true, integration: true } }, fboAssembly: { select: { phase: true } } } });
        const progressLabels = await require('../tsd/fbo-progress-status').fboProgressLabels(this.db, rows.map(r => r.id));
        const stores = await require("../clients/request-store-context").requestStoreContexts(this.db,rows);
        return rows.map(r => ({ ...stores.get(r.id), id: r.id, number: r.number, title: r.title, status: r.status, fboProgressLabel: progressLabels[r.id], desiredDate: r.desiredDate, destinationCity: r.destinationCity,
            ...(all ? { clientId: r.clientId, clientName: r.client?.name ?? null, clientCode: r.client?.code ?? null, warehouseName: r.warehouse?.name ?? null, createdAt: r.createdAt,
                itemCount: r.items.length, itemsPreview: r.items.slice(0, 3).map(i => ({ name: i.name ?? null, barcode: i.barcode ?? null, quantity: i.quantity })) } : {}),
            editDeadlines: r.ozonShipment?.integration ? (0, deadlinePolicy.supplyOrders)(r.ozonShipment.integration).map(o => ({ orderId: o.orderId, orderNumber: o.orderNumber, editDeadlineAt: o.editDeadlineAt ?? null, checkedAt: o.checkedAt })) : [],
            quantity: r.items.reduce((s, i) => s + i.quantity, 0), directions: r.ozonShipment.directions.length, phase: r.fboAssembly?.phase ?? 'NOT_STARTED' }));
    }
    async preview(file, dto, user) {
        if (process.env.WMS_OZON_FBO_IMPORT_ENABLED !== 'true')
            throw new common_1.NotFoundException('Импорт ФБО Ozon выключен.');
        this.scopes.requireClientAccess(user, dto.clientId, 'write');
        const warehouseId = await this.resolveWarehouse(dto.clientId, user, 'write', dto.warehouseId);
        const client = await this.db.client.findUniqueOrThrow({ where: { id: dto.clientId } });
        if (client.storesWithoutBoxes && !(0, fbo_unboxed_picking_1.unboxedFboEnabled)())
            throw new common_1.BadRequestException('Для этой сборки нужен учёт клиента по коробам.');
        if (!dto.destinationCity?.trim())
            throw new common_1.BadRequestException('Укажите место общей отгрузки.');
        if (!file?.buffer?.length || file.buffer.length > 10 * 1024 * 1024)
            throw new common_1.BadRequestException('Нужен Excel-файл до 10 МБ.');
        let parsed;
        try {
            const wb = XLSX.read(file.buffer, { type: 'buffer' });
            parsed = (0, ozon_fbo_xlsx_parser_1.parseOzonFboRows)(XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: true }));
        }
        catch (e) {
            throw new common_1.BadRequestException(e instanceof Error ? e.message : 'Не удалось прочитать Excel.');
        }
        const alternateBarcode = (value) => /^0[0-9]{13}$/.test(value) ? value.slice(1)
            : /^[0-9]{13}$/.test(value) ? `0${value}` : value;
        const values = [...new Set(parsed.flatMap(({ barcode }) => [barcode, alternateBarcode(barcode)]))];
        const matches = await this.db.barcode.findMany({ where: { value: { in: values }, sku: { clientId: dto.clientId } }, include: { sku: true } });
        const directions = [];
        for (const line of parsed) {
            const alternate = alternateBarcode(line.barcode);
            const found = matches.filter(m => m.value === line.barcode || m.value === alternate);
            if (new Set(found.map(m => m.skuId)).size !== 1)
                throw new common_1.BadRequestException(`Строка ${line.row}: ШК ${line.barcode} не найден однозначно у выбранного клиента.`);
            let d = directions.find(d => d.name === line.direction);
            if (!d) {
                d = { name: line.direction, items: [] };
                directions.push(d);
            }
            const item = d.items.find(i => i.skuId === found[0].skuId);
            if (item)
                item.quantity += line.quantity;
            else
                d.items.push({ skuId: found[0].skuId, barcode: line.barcode, quantity: line.quantity });
        }
        const items = [];
        for (const d of directions)
            for (const line of d.items) {
                const item = items.find(i => i.skuId === line.skuId);
                if (item)
                    item.quantity += line.quantity;
                else
                    items.push({ ...line, name: matches.find(m => m.skuId === line.skuId).sku.name });
            }
        if (items.length > 1000)
            throw new common_1.BadRequestException('Не больше 1000 товаров в одной сборке.');
        // FIX: retrying the same customer allocation does not create a second reservation.
        const importKey = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([dto.clientId, warehouseId, dto.desiredDate ?? null, dto.destinationCity.trim(),
            directions.map(d => [d.name, d.items.map(i => [i.skuId, i.quantity]).sort()]).sort()])).digest('hex');
        return { warehouseId, importKey, directions, items, totalQuantity: items.reduce((s, i) => s + i.quantity, 0) };
    }
    async commit(file, dto, user) {
        const p = await this.preview(file, dto, user);
        return this.db.$transaction(tx => this.createPrepared(tx, p, file, dto, user));
    }
    // FIX: link import creates demand and external ownership in the same transaction.
    async createPrepared(tx, p, file, dto, user, connectionId) {
        await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${p.importKey}))`;
        const prior = await tx.ozonFboShipment.findUnique({ where: { importKey: p.importKey }, include: { request: true } });
        if (prior)
            return { request: prior.request, directions: p.directions, existing: true };
        const decision = process.env.WMS_OZON_STOCK_DECISION_AUDIT_ENABLED === "true" ? require("./ozon-stock-decision").readOzonStockDecision(dto.stockDecision,p.items) : null;
        const request = await tx.clientRequest.create({ data: {
                clientId: dto.clientId, warehouseId: p.warehouseId, type: 'OUTBOUND', status: 'SUBMITTED', priority: dto.priority ?? 'NORMAL',
                title: dto.title?.trim() || `ФБО Ozon · ${p.directions.length} направлений`,
                comment: `Создано из Excel: ${file.originalname}. ФБО Ozon, ${p.totalQuantity} шт.`,
                destinationCity: dto.destinationCity.trim(), deliveryAddress: dto.deliveryAddress,
                desiredDate: dto.desiredDate ? new Date(dto.desiredDate) : undefined, createdByUserId: user.id,
                items: { create: p.items },
                ozonShipment: { create: { importKey: p.importKey, directions: p.directions } },
                files: { create: { clientId: dto.clientId, fileName: file.originalname, mimeType: file.mimetype, sizeBytes: file.buffer.length, content: Uint8Array.from(file.buffer), uploadedByUserId: user.id } },
                events: { create: { clientId: dto.clientId, eventType: 'CREATED', title: 'Единая сборка ФБО Ozon из файла клиента', statusTo: 'SUBMITTED', createdByUserId: user.id } },
            } });
                if (decision) {
            const action = decision.mode === 'AS_IS' ? 'Сформировать как есть' : 'Скорректировать по фактическим остаткам';
            const cards = decision.shortages.length
                ? await tx.sku.findMany({ where: { clientId: dto.clientId, id: { in: decision.shortages.map(i => i.skuId) } }, select: { id: true, article: true, internalSku: true, size: true } }) : [];
            const byId = new Map(cards.map(card => [card.id, card]));
            const shortages = decision.shortages.map(row => ({ ...row, article: byId.get(row.skuId)?.article ?? byId.get(row.skuId)?.internalSku ?? null, size: byId.get(row.skuId)?.size ?? null }));
            const context = { clientId: dto.clientId, warehouseId: p.warehouseId, connectionId: connectionId ?? null, source: connectionId ? 'LINK' : 'FILE' };
            await tx.auditLog.create({ data: { entity: 'ClientRequest', entityId: request.id, userId: user.id,
                    action: 'OZON_IMPORT_STOCK_DECISION', payload: { ...context, ...decision, shortages } } });
            await tx.clientRequestEvent.create({ data: { requestId: request.id, clientId: dto.clientId,
                    eventType: 'COMMENT', createdByUserId: user.id, title: 'Выбор при создании ФБО Ozon: ' + action,
                    body: ['Создана заявка на ' + decision.requested + ' шт. По сверке доступно для заявки ' + decision.availableForPlan + ' шт.',
                        ...shortages.map(i => [i.name, i.article, i.size, i.barcode].filter(Boolean).join(' · ') + ' · нужно ' + i.quantity + ', доступно ' + i.available + ', не хватает ' + i.shortage)].join('\n') } });
        }
return { request, directions: p.directions, existing: false };
    }
};
exports.OzonFboImportService = OzonFboImportService;
exports.OzonFboImportService = OzonFboImportService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], OzonFboImportService);
