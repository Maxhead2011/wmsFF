"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonUnitExemplarPayload = ozonUnitExemplarPayload;
exports.ozonUnitExemplarsPassed = ozonUnitExemplarsPassed;
const common_1 = require("@nestjs/common");
const kiz_client_registry_1 = require("../../common/kiz-client-registry");
const ozon_fbs_pick_lines_1 = require("./ozon-fbs-pick-lines");
// FIX: bind every scanned unit to its own exemplar, preserving already assigned marks.
function ozonUnitExemplarPayload(state, posting, response, postingNumber) {
    (0, ozon_fbs_pick_lines_1.requireOzonLineComposition)(state, posting);
    const usedIds = new Set();
    const products = state.lines.filter(line => line.requiresKiz).map(line => {
        const matches = (response.products ?? []).filter((p) => Number(p.product_id) === line.productId);
        if (matches.length !== 1 || matches[0].exemplars?.length !== line.quantity)
            throw new common_1.ConflictException('Количество экземпляров Ozon отличается от собранного состава.');
        const remaining = new Map(line.picks.map(p => [(0, kiz_client_registry_1.clientKizIdentity)(p.kiz), p.kiz]));
        const exemplars = matches[0].exemplars.map((e) => {
            const id = Number(e.exemplar_id);
            if (!Number.isSafeInteger(id) || id <= 0 || usedIds.has(id))
                throw new common_1.ConflictException('Некорректный экземпляр Ozon.');
            usedIds.add(id);
            const marks = (e.marks ?? []).filter((m) => m.mark);
            if (marks.length > 1)
                throw new common_1.ConflictException('У экземпляра Ozon неоднозначная маркировка.');
            const identity = marks.length ? (0, kiz_client_registry_1.clientKizIdentity)(marks[0].mark) : '';
            if (identity && !remaining.has(identity))
                throw new common_1.ConflictException('В Ozon записан другой КИЗ. Нужна сверка.');
            if (marks.length && !identity)
                throw new common_1.ConflictException('Ozon вернул неполный КИЗ.');
            const mark = identity ? remaining.get(identity) : null;
            if (identity)
                remaining.delete(identity);
            return { id, mark };
        });
        return { product_id: line.productId, exemplars: exemplars.map((e) => {
                let mark = e.mark;
                if (!mark) {
                    const next = remaining.entries().next().value;
                    mark = next[1];
                    remaining.delete(next[0]);
                }
                return { exemplar_id: e.id, gtd: '', is_gtd_absent: true, rnpt: '', is_rnpt_absent: true,
                    marks: [{ mark, mark_type: 'mandatory_mark' }] };
            }) };
    });
    return { multi_box_qty: 1, posting_number: postingNumber, products };
}
// FIX: a generic passed status cannot stand in for confirmation of the exact sent exemplars.
function ozonUnitExemplarsPassed(payload, response) {
    if (response.status === 'failed')
        throw new common_1.ConflictException('Ozon отклонил маркировку заказа.');
    return payload.products.every(product => {
        const matches = (response.products ?? []).filter((p) => Number(p.product_id) === product.product_id);
        if (matches.length !== 1)
            return false;
        return product.exemplars.every((expected) => {
            const exemplars = (matches[0].exemplars ?? []).filter((e) => Number(e.exemplar_id) === expected.exemplar_id);
            if (exemplars.length !== 1)
                return false;
            const marks = exemplars[0].marks ?? [];
            if (marks.some((m) => m.error_codes?.length || m.check_status === 'failed'))
                throw new common_1.ConflictException('Ozon отклонил КИЗ.');
            return marks.length === 1 && marks[0].check_status === 'passed' &&
                (!marks[0].mark || (0, kiz_client_registry_1.clientKizIdentity)(marks[0].mark) === (0, kiz_client_registry_1.clientKizIdentity)(expected.marks[0].mark));
        });
    });
}
