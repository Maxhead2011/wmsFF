"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonActiveLine = exports.ozonPickTotal = exports.ozonPickCount = exports.ozonPickLinesEnabled = void 0;
exports.ozonPostingProducts = ozonPostingProducts;
exports.requireOzonLineComposition = requireOzonLineComposition;
exports.recordOzonLineScan = recordOzonLineScan;
exports.recordOzonUnitKiz = recordOzonUnitKiz;
exports.readOzonPickState = readOzonPickState;
exports.writeOzonPickState = writeOzonPickState;
exports.resolveOzonLineSku = resolveOzonLineSku;
const common_1 = require("@nestjs/common");
const kiz_client_registry_1 = require("../../common/kiz-client-registry");
const ozonPickLinesEnabled = () => process.env.WMS_OZON_MULTILINE_PICKING === 'true';
exports.ozonPickLinesEnabled = ozonPickLinesEnabled;
const ozonPickCount = (state) => state.lines.reduce((n, line) => n + line.picks.length, 0);
exports.ozonPickCount = ozonPickCount;
const ozonPickTotal = (state) => state.lines.reduce((n, line) => n + line.quantity, 0);
exports.ozonPickTotal = ozonPickTotal;
const ozonActiveLine = (state) => state.lines.find(line => line.picks.length < line.quantity);
exports.ozonActiveLine = ozonActiveLine;
// FIX: quantities and identities must be exact; an equal grand total is not proof of composition.
function ozonPostingProducts(posting) {
    if (!Array.isArray(posting?.products) || !posting.products.length)
        throw new common_1.BadRequestException('Ozon не вернул состав заказа.');
    const products = posting.products.map((product) => {
        const productId = Number(product.sku), quantity = Number(product.quantity);
        if (!Number.isSafeInteger(productId) || productId <= 0 || !Number.isSafeInteger(quantity) || quantity <= 0 || !product.offer_id) {
            throw new common_1.BadRequestException('Некорректная товарная строка Ozon. Обновите заказ.');
        }
        return { productId, quantity, offerId: String(product.offer_id), barcodes: Array.isArray(product.barcodes) ? product.barcodes.map(String) : [] };
    });
    if (new Set(products.map(p => p.productId)).size !== products.length)
        throw new common_1.BadRequestException('Ozon вернул повторяющиеся строки товара. Нужна проверка состава.');
    return products;
}
function requireOzonLineComposition(state, posting) {
    const actual = ozonPostingProducts(posting);
    if (actual.length !== state.lines.length || state.lines.some(line => {
        const remote = actual.find(p => p.productId === line.productId && p.offerId === line.offerId);
        return !remote || remote.quantity !== line.quantity || line.picks.length !== line.quantity;
    }))
        throw new common_1.ConflictException('Состав Ozon изменился или не все товары отсканированы. Отправка остановлена; обновите заказ.');
    const marks = posting.requirements?.products_requiring_mandatory_mark;
    if (Array.isArray(marks) && marks.length && (state.unitMarksVersion !== 1 || marks.some(id => {
        const line = state.lines.find(l => String(l.productId) === String(id));
        return !line || line.picks.some(p => !(0, kiz_client_registry_1.clientKizIdentity)(p.kiz ?? ''));
    })))
        throw new common_1.BadRequestException('Ozon требует маркировку: не все экземпляры подтверждены КИЗ.');
    // FIX: WMS marking requirements remain mandatory even if Ozon omits them.
    const identities = state.lines.flatMap(l => l.picks.filter(p => l.requiresKiz || p.kiz).map(p => (0, kiz_client_registry_1.clientKizIdentity)(p.kiz ?? '')));
    if (state.pendingBarcode || identities.some(k => !k) || new Set(identities).size !== identities.length)
        throw new common_1.ConflictException('Не все КИЗ подтверждены или КИЗ повторяется.');
}
function recordOzonLineScan(state, barcode, expectedCount, actorId, now = new Date()) {
    const count = (0, exports.ozonPickCount)(state);
    if (!Number.isSafeInteger(expectedCount) || Number(expectedCount) < 0 || Number(expectedCount) > count) {
        throw new common_1.ConflictException('Обновите задание: отсутствует актуальный счётчик сканирования.');
    }
    // FIX: replay of the previous request cannot consume a unit from the next product line.
    if (Number(expectedCount) < count) {
        const accepted = state.lines.flatMap(line => line.picks)[Number(expectedCount)];
        if (accepted?.barcode !== barcode)
            throw new common_1.ConflictException('Этот номер сканирования уже занят другим товаром. Обновите задание.');
        return state;
    }
    if (state.submission !== 'PICKING')
        throw new common_1.ConflictException('Заказ уже передаётся в Ozon. Новые сканы не принимаются.');
    const index = state.lines.findIndex(line => line.picks.length < line.quantity);
    if (index < 0)
        throw new common_1.BadRequestException('Все товары уже отсканированы. Подтвердите отбор.');
    const line = state.lines[index];
    if (!line.barcodes.includes(barcode))
        throw new common_1.BadRequestException(`Неверный товар. Нужен артикул ${line.article}, ШК ${line.barcodes.join(', ')}.`);
    if (!state.source)
        throw new common_1.BadRequestException('Сначала отсканируйте короб или выберите «Без короба».');
    const result = structuredClone(state);
    // FIX: the barcode selects a unit; only its KIZ completes a marked pick.
    if (line.requiresKiz) {
        if (state.unitMarksVersion !== 1)
            throw new common_1.ConflictException('Поштучный учёт КИЗ не включён.');
        result.pendingBarcode = barcode;
        return result;
    }
    result.lines[index].picks.push({ barcode, ...state.source, actorId, at: now.toISOString() });
    if (result.lines[index].picks.length === line.quantity)
        result.source = null;
    return result;
}
// FIX: durable counter + physical KIZ identity make a lost-response retry idempotent.
function recordOzonUnitKiz(state, kiz, expectedCount, actorId, now = new Date()) {
    const identity = (0, kiz_client_registry_1.clientKizIdentity)(kiz), count = (0, exports.ozonPickCount)(state);
    if (!identity)
        throw new common_1.BadRequestException('Отсканируйте полный КИЗ товара.');
    if (!Number.isSafeInteger(expectedCount) || Number(expectedCount) < 0 || Number(expectedCount) > count)
        throw new common_1.ConflictException('Обновите задание: отсутствует актуальный счётчик сканирования.');
    if (Number(expectedCount) < count) {
        if ((0, kiz_client_registry_1.clientKizIdentity)(state.lines.flatMap(l => l.picks)[Number(expectedCount)]?.kiz ?? '') !== identity)
            throw new common_1.ConflictException('Этот номер сканирования уже занят другим КИЗ.');
        return state;
    }
    const line = (0, exports.ozonActiveLine)(state);
    if (state.unitMarksVersion !== 1 || state.submission !== 'PICKING' || !line?.requiresKiz || !state.pendingBarcode || !state.source)
        throw new common_1.ConflictException('Сначала подтвердите источник и ШК товара.');
    if (state.lines.some(l => l.picks.some(p => (0, kiz_client_registry_1.clientKizIdentity)(p.kiz ?? '') === identity)))
        throw new common_1.ConflictException('Этот КИЗ уже отобран в заказе.');
    const result = structuredClone(state), target = result.lines[state.lines.indexOf(line)];
    target.picks.push({ barcode: state.pendingBarcode, ...state.source, kiz, actorId, at: now.toISOString() });
    delete result.pendingBarcode;
    if (target.picks.length === target.quantity)
        result.source = null;
    return result;
}
async function readOzonPickState(db, assemblyId) {
    const rows = await db.$queryRaw `SELECT "data" FROM "OzonFbsPickState" WHERE "assemblyId"=${assemblyId}`;
    return rows[0]?.data ?? null;
}
async function writeOzonPickState(db, assemblyId, state) {
    const data = JSON.stringify(state);
    await db.$executeRaw `INSERT INTO "OzonFbsPickState" ("assemblyId", "data") VALUES (${assemblyId}, ${data}::jsonb)
    ON CONFLICT ("assemblyId") DO UPDATE SET "data"=EXCLUDED."data", "updatedAt"=CURRENT_TIMESTAMP`;
}
// Existing imported SKUs may use a compound marketplaceProductId. Match exact tokens, never substrings.
function resolveOzonLineSku(product, skus, allowMarked = false) {
    const candidates = skus.filter(sku => {
        const ids = String(sku.marketplaceProductId ?? '').split(':');
        return ids.includes(product.offerId) || ids.includes(String(product.productId)) ||
            sku.marketplaceOfferId === product.offerId ||
            (sku.barcodes ?? []).some((b) => product.barcodes.includes(b.value));
    });
    if (candidates.length !== 1)
        throw new common_1.BadRequestException(`Не найдено однозначное соответствие артикула Ozon ${product.offerId}. Проверьте карточку в WMS.`);
    const sku = candidates[0];
    if ((!allowMarked && sku.needsChestnyZnak && !sku.isUnmarked) || sku.needsRelabel)
        throw new common_1.BadRequestException('Многотоварный заказ с КИЗ или переклейкой требует отдельной проверки.');
    if (!sku.barcodes?.length)
        throw new common_1.BadRequestException(`У артикула ${product.offerId} не задан ШК товара.`);
    return sku;
}
