"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FulfillmentAnalyticsController = exports.FulfillmentQueryDto = void 0;
const common_1 = require("@nestjs/common");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const fulfillment_service_1 = require("./fulfillment.service");
class FulfillmentQueryDto {
    clientId;
    warehouseId;
    dateFrom;
    dateTo;
    channel;
    leadDays;
    reviewDays;
    safetyDays;
}
exports.FulfillmentQueryDto = FulfillmentQueryDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], FulfillmentQueryDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], FulfillmentQueryDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(10),
    __metadata("design:type", String)
], FulfillmentQueryDto.prototype, "dateFrom", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(10),
    __metadata("design:type", String)
], FulfillmentQueryDto.prototype, "dateTo", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['FBS', 'FBO']),
    __metadata("design:type", String)
], FulfillmentQueryDto.prototype, "channel", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Number)
], FulfillmentQueryDto.prototype, "leadDays", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Number)
], FulfillmentQueryDto.prototype, "reviewDays", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Number)
], FulfillmentQueryDto.prototype, "safetyDays", void 0);
// FIX: authenticated client/warehouse scopes are enforced in the service for every query.
let FulfillmentAnalyticsController = class FulfillmentAnalyticsController {
    service;
    constructor(service) {
        this.service = service;
    }
    clients(user) { return this.service.clients(user); }
    dashboard(q, user) { return this.service.dashboard(q, user); }
};
exports.FulfillmentAnalyticsController = FulfillmentAnalyticsController;
__decorate([
    (0, common_1.Get)('clients'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FulfillmentAnalyticsController.prototype, "clients", null);
__decorate([
    (0, common_1.Get)('dashboard'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [FulfillmentQueryDto, Object]),
    __metadata("design:returntype", void 0)
], FulfillmentAnalyticsController.prototype, "dashboard", null);
exports.FulfillmentAnalyticsController = FulfillmentAnalyticsController = __decorate([
    (0, common_1.Controller)('analytics/fulfillment'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __metadata("design:paramtypes", [typeof (_a = typeof fulfillment_service_1.FulfillmentAnalyticsService !== "undefined" && fulfillment_service_1.FulfillmentAnalyticsService) === "function" ? _a : Object])
], FulfillmentAnalyticsController);
