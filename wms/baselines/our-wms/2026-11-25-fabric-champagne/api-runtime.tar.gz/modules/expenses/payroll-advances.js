"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.payrollPaymentHash = exports.payrollAdvancesEnabled = void 0;
exports.requirePayrollAdvances = requirePayrollAdvances;
exports.planPayrollAdvances = planPayrollAdvances;
exports.payrollAdvanceRows = payrollAdvanceRows;
exports.createPayrollAdvance = createPayrollAdvance;
exports.applyPayrollAdvances = applyPayrollAdvances;
exports.reversePayrollAdvances = reversePayrollAdvances;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
const payrollAdvancesEnabled = () => process.env.WMS_PAYROLL_ADVANCES_ENABLED === 'true';
exports.payrollAdvancesEnabled = payrollAdvancesEnabled;
function requirePayrollAdvances() { if (!(0, exports.payrollAdvancesEnabled)())
    throw new common_1.NotFoundException('Авансы ФОТ не включены.'); }
const payrollPaymentHash = (value) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(value)).digest('hex');
exports.payrollPaymentHash = payrollPaymentHash;
// FIX: allocate a shared employee balance once across explicit selected earning rows.
function planPayrollAdvances(rows, advances) {
    const allocations = [];
    const balances = new Map(advances.map(a => [a.id, a.remainingKopecks]));
    if (new Set(rows.map(r => r.key)).size !== rows.length || new Set(advances.map(a => a.id)).size !== advances.length)
        throw new common_1.BadRequestException('Повторные строки выплаты.');
    let grossKopecks = 0, deductedKopecks = 0;
    for (const r of rows) {
        if (!Number.isSafeInteger(r.amountKopecks) || r.amountKopecks < 0)
            throw new common_1.BadRequestException('Некорректная сумма начисления.');
        grossKopecks += r.amountKopecks;
        let available = r.amountKopecks;
        for (const a of advances.filter(a => a.rootId === r.rootId)) {
            const balance = balances.get(a.id);
            if (!Number.isSafeInteger(balance) || balance < 0)
                throw new common_1.BadRequestException('Некорректный остаток аванса.');
            const amount = Math.min(available, balance);
            if (!amount)
                continue;
            allocations.push({ advanceId: a.id, settlementKey: r.key, amountKopecks: amount });
            available -= amount;
            balances.set(a.id, balance - amount);
            deductedKopecks += amount;
        }
    }
    if (!Number.isSafeInteger(grossKopecks) || !Number.isSafeInteger(deductedKopecks))
        throw new common_1.BadRequestException('Слишком большая сумма.');
    return { grossKopecks, deductedKopecks, netKopecks: grossKopecks - deductedKopecks, allocations };
}
async function payrollAdvanceRows(tx, employeeIds) {
    if (!employeeIds.length)
        return [];
    return tx.$queryRaw `SELECT a.*, (a."amountKopecks"-COALESCE((SELECT SUM(u."amountKopecks") FROM "PayrollAdvanceUse" u WHERE u."advanceId"=a.id AND u."reversedAt" IS NULL),0))::int AS "remainingKopecks" FROM "PayrollAdvance" a WHERE a."employeeId" IN (${client_1.Prisma.join(employeeIds)}) ORDER BY a."issuedDate",a."createdAt",a.id`;
}
async function createPayrollAdvance(tx, data) {
    if (!/^[0-9a-f-]{36}$/i.test(data.id) || !/^\d{4}-\d{2}-\d{2}$/.test(data.issuedDate) || !Number.isSafeInteger(data.amountKopecks) || data.amountKopecks <= 0 || data.amountKopecks > 2147483647 || !data.reason.trim() || data.reason.length > 1000)
        throw new common_1.BadRequestException('Проверьте дату, сумму и основание аванса.');
    const old = await tx.$queryRaw `SELECT * FROM "PayrollAdvance" WHERE id=${data.id}`;
    if (old.length) {
        const o = old[0];
        if (o.employeeId !== data.employeeId || o.warehouseId !== data.warehouseId || o.amountKopecks !== data.amountKopecks || o.issuedDate !== data.issuedDate || o.kind !== data.kind || o.reason !== data.reason || o.cancelledAt)
            throw new common_1.BadRequestException('Идентификатор уже использован для другого аванса.');
        return o;
    }
    await tx.$executeRaw `INSERT INTO "PayrollAdvance" (id,"employeeId","warehouseId","issuedDate","amountKopecks",kind,reason,"createdById") VALUES (${data.id},${data.employeeId},${data.warehouseId},${data.issuedDate},${data.amountKopecks},${data.kind},${data.reason},${data.actorId})`;
    await tx.payrollAudit.create({ data: { warehouseId: data.warehouseId, actorId: data.actorId, entityId: data.employeeId, action: 'ADVANCE_CREATED', details: data } });
    return data;
}
async function applyPayrollAdvances(tx, allocations, runId) {
    for (const a of allocations)
        await tx.$executeRaw `INSERT INTO "PayrollAdvanceUse" (id,"advanceId","settlementKey","amountKopecks","runId") VALUES (${(0, node_crypto_1.randomUUID)()},${a.advanceId},${a.settlementKey},${a.amountKopecks},${runId})`;
}
async function reversePayrollAdvances(tx, keys) {
    if (keys.length)
        await tx.$executeRaw `UPDATE "PayrollAdvanceUse" SET "reversedAt"=now() WHERE "settlementKey" IN (${client_1.Prisma.join(keys)}) AND "reversedAt" IS NULL`;
}
