"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ruleKey = exports.palitraClientId = void 0;
exports.ruleAvailable = ruleAvailable;
exports.configuredRule = configuredRule;
exports.activeRule = activeRule;
exports.requireSettingsEditor = requireSettingsEditor;
const common_1 = require("@nestjs/common");
exports.palitraClientId = 'e8597352-0b93-442c-9582-c694620a9695';
const ruleKey = (id, rule) => `client.fulfillment.${id}.${rule}`;
exports.ruleKey = ruleKey;
function ruleAvailable(rule) {
    return (rule === 'zones' ? process.env.WMS_OZON_BOX_ZONES_ENABLED : process.env.WMS_PALITRA_PICK_KIZ) === 'true';
}
// FIX: missing settings inherit the original per-installation client policy.
async function configuredRule(db, id, rule) {
    const saved = await db.systemSetting.findUnique({ where: { key: (0, exports.ruleKey)(id, rule) }, select: { value: true } });
    return typeof saved?.value === 'boolean' ? saved.value : id === exports.palitraClientId;
}
async function activeRule(db, id, rule) {
    return ruleAvailable(rule) && await configuredRule(db, id, rule);
}
function requireSettingsEditor(roles) {
    if (!roles.some(role => role === 'ADMIN' || role === 'OWNER'))
        throw new common_1.ForbiddenException('Настройки меняет администратор или собственник.');
}
