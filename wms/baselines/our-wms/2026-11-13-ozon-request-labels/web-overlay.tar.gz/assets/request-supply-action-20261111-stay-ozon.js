export function requestSupplyOrders(target, orders) {
 const {request,action}=target;
 const linked=orders.filter(order=>order.request?.id===request.id);
 const expected=request.fbsCompletion?.totalOrders;
 if(!linked.length||(expected&&linked.length!==expected))throw Error('Не удалось загрузить полный состав заявки FBS.');
 if(linked.some(order=>!['WILDBERRIES','OZON'].includes(order.marketplace)))throw Error('Печать стикеров доступна для заявок WB и Ozon.');
 if(action!=='deliver')return linked;
 if(linked.some(order=>order.marketplace!=='WILDBERRIES'))throw Error('Эта передача доступна только для WB.');
 if(!request.fbsCompletion?.completed||linked.some(order=>!order.supplyId||order.supplierStatus!=='confirm'))throw Error('Для передачи все заказы заявки должны быть собраны и готовы к отправке в WB.');
 const key=order=>JSON.stringify([order.connectionId,order.supplyId]);
 const supplies=new Set(linked.map(key));
 if(orders.some(order=>order.marketplace==='WILDBERRIES'&&supplies.has(key(order))&&order.request?.id!==request.id))throw Error('В поставку WB входят заказы из другой заявки. Проверьте состав поставки.');
 return linked;
}
let pending=null;
export function getTarget(){return pending;}
export function setTarget(target){pending=target;}
