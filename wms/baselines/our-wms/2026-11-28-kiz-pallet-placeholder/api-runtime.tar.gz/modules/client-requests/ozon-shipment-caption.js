"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonShipmentCaptions = ozonShipmentCaptions;
const ozon_supply_policy_1 = require("./ozon-supply-policy");
// FIX: readiness is per Ozon order, and requires confirmed cargoes for every supply.
function ozonShipmentCaptions(link) {
    return (0, ozon_supply_policy_1.supplyOrders)(link).map(o => ({ orderId: o.orderId, orderNumber: o.orderNumber, editDeadlineAt: o.editDeadlineAt ?? null, checkedAt: o.checkedAt,
        handoverAt: o.date || null,
        readyToShip: !!link.frozenHash && o.supplies.length > 0 && o.supplies.every(s => {
            const op = link.operations?.[s.id];
            return op?.state === 'SUCCESS' && !op.error && !!op.cargoes?.length && op.cargoes.every(c => !!c.cargoId);
        }) }));
}
