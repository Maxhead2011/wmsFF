"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaClient = exports.lamodaResources = exports.LamodaApiError = void 0;
exports.sealSecret = sealSecret;
exports.openSecret = openSecret;
exports.record = record;
const node_crypto_1 = require("node:crypto");
const lamoda_commands_1 = require("./lamoda-commands");
class LamodaApiError extends Error {
    code;
    status;
    outcome;
    constructor(code, status, outcome) {
        // FIX: never propagate remote bodies (which can contain credentials/customer data).
        super(`Lamoda: ${code}${status ? ` (${status})` : ''}`);
        this.code = code;
        this.status = status;
        this.outcome = outcome;
    }
}
exports.LamodaApiError = LamodaApiError;
function encryptionKey() {
    const value = process.env.WMS_LAMODA_SECRET_KEY ?? '';
    if (!/^[A-Za-z0-9+/]{43}=$/.test(value))
        throw new LamodaApiError('SECRET_KEY_NOT_CONFIGURED');
    const key = Buffer.from(value, 'base64');
    if (key.length !== 32)
        throw new LamodaApiError('SECRET_KEY_NOT_CONFIGURED');
    return key;
}
function sealSecret(secret, identity) {
    const iv = (0, node_crypto_1.randomBytes)(12);
    const cipher = (0, node_crypto_1.createCipheriv)('aes-256-gcm', encryptionKey(), iv);
    cipher.setAAD(Buffer.from(identity));
    const body = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()]);
    return ['v1', iv.toString('base64'), cipher.getAuthTag().toString('base64'), body.toString('base64')].join('.');
}
function openSecret(encrypted, identity) {
    const key = encryptionKey();
    try {
        const [version, iv, tag, body, extra] = encrypted.split('.');
        if (version !== 'v1' || extra || !iv || !tag || !body)
            throw new Error();
        const decipher = (0, node_crypto_1.createDecipheriv)('aes-256-gcm', key, Buffer.from(iv, 'base64'));
        decipher.setAAD(Buffer.from(identity));
        decipher.setAuthTag(Buffer.from(tag, 'base64'));
        return Buffer.concat([decipher.update(Buffer.from(body, 'base64')), decipher.final()]).toString('utf8');
    }
    catch {
        throw new LamodaApiError('SECRET_DECRYPTION_FAILED');
    }
}
const resources = {
    CATALOG: { path: '/nomenclatures', key: 'nomenclatures' },
    ORDERS: { path: '/orders', key: 'orders' },
    FBO_SHIPMENTS: { path: '/fbo/shipments', key: 'shipments' },
    FBS_SHIPMENTS: { path: '/fbs/shipments', key: 'items' },
    RETURNS: { path: '/fbs/return-items', key: 'data' },
};
exports.lamodaResources = Object.keys(resources);
const base = 'https://public-api-seller.lamoda.ru/api/v2';
// FIX: operational writes are allow-listed, gated and never automatically retried.
class LamodaClient {
    http;
    now;
    tokens = new Map();
    pending = new Map();
    constructor(http = fetch, now = Date.now) {
        this.http = http;
        this.now = now;
    }
    key(c) {
        return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([c.oauthClientId, c.secret, c.sellerId])).digest('hex');
    }
    async json(url, init) {
        let response;
        try {
            response = await this.http(url, { ...init, redirect: 'error', signal: AbortSignal.timeout(20_000) });
        }
        catch {
            throw new LamodaApiError('TRANSPORT_ERROR');
        }
        if (!response.ok)
            throw new LamodaApiError('HTTP_ERROR', response.status);
        const raw = await response.text().catch(() => { throw new LamodaApiError('TRANSPORT_ERROR'); });
        if (raw.length > 10_000_000)
            throw new LamodaApiError('RESPONSE_TOO_LARGE');
        try {
            return JSON.parse(raw);
        }
        catch {
            throw new LamodaApiError('INVALID_JSON');
        }
    }
    async token(c) {
        const key = this.key(c), cached = this.tokens.get(key);
        if (cached && cached.until > this.now())
            return cached;
        const pending = this.pending.get(key);
        if (pending)
            return pending;
        const task = (async () => {
            const raw = record(await this.json(`${base}/auth-token`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ grant_type: 'client_credentials', client_id: c.oauthClientId, client_secret: c.secret }),
            }));
            if (typeof raw.access_token !== 'string' || !raw.access_token || raw.token_type?.toString().toLowerCase() !== 'bearer' ||
                !Number.isSafeInteger(raw.expires_in) || Number(raw.expires_in) <= 0)
                throw new LamodaApiError('INVALID_TOKEN_RESPONSE');
            const lifetime = Number(raw.expires_in) * 1000;
            const token = { value: raw.access_token, until: this.now() + lifetime - Math.min(30_000, lifetime / 10) };
            // Bound process-local memory. Tokens are never stored in DB/logs or returned to the UI.
            if (this.tokens.size >= 100)
                this.tokens.delete(this.tokens.keys().next().value);
            this.tokens.set(key, token);
            return token;
        })();
        this.pending.set(key, task);
        try {
            return await task;
        }
        finally {
            this.pending.delete(key);
        }
    }
    async get(c, path, params) {
        const url = new URL(`${base}${path}`);
        Object.entries({ ...params, sellerId: c.sellerId }).forEach(([key, value]) => url.searchParams.set(key, value));
        for (let attempt = 0;; attempt++) {
            const token = await this.token(c);
            try {
                return record(await this.json(url.toString(), { headers: { Authorization: `Bearer ${token.value}` } }));
            }
            catch (error) {
                if (attempt === 0 && error instanceof LamodaApiError && error.status === 401) {
                    if (this.tokens.get(this.key(c)) === token)
                        this.tokens.delete(this.key(c));
                    continue;
                }
                throw error;
            }
        }
    }
    async execute(c, command) {
        if (process.env.WMS_LAMODA_EXTERNAL_WRITES_ENABLED !== 'true')
            throw new LamodaApiError('WRITES_DISABLED', undefined, 'REJECTED');
        let request;
        try {
            request = (0, lamoda_commands_1.prepareLamodaCommand)(command, c.sellerId);
        }
        catch {
            throw new LamodaApiError('INVALID_COMMAND', undefined, 'REJECTED');
        }
        // Authentication happens before the business request: failure cannot have changed a shipment.
        let token;
        try {
            token = await this.token(c);
        }
        catch {
            throw new LamodaApiError('AUTH_FAILED', undefined, 'REJECTED');
        }
        let response;
        try {
            response = await this.http(`${base}${request.path}`, {
                method: 'POST', headers: { Authorization: `Bearer ${token.value}`, 'Content-Type': 'application/json' },
                body: request.body, redirect: 'error', signal: AbortSignal.timeout(20_000),
            });
        }
        catch {
            throw new LamodaApiError('TRANSPORT_ERROR', undefined, 'UNKNOWN');
        }
        if (!response.ok) {
            const rejected = [400, 401, 403, 404, 405, 422, 429].includes(response.status);
            throw new LamodaApiError('HTTP_ERROR', response.status, rejected ? 'REJECTED' : 'UNKNOWN');
        }
        // A malformed success response must not be treated as permission to repeat a write.
        if (response.status === 204)
            return null;
        try {
            const bytes = await this.boundedBody(response);
            return JSON.parse(bytes.toString('utf8'));
        }
        catch {
            throw new LamodaApiError('INVALID_WRITE_RESPONSE', response.status, 'UNKNOWN');
        }
    }
    async boundedBody(response) {
        const reader = response.body?.getReader();
        if (!reader)
            throw new LamodaApiError('EMPTY_RESPONSE');
        const chunks = [];
        let size = 0;
        try {
            for (;;) {
                const { value, done } = await reader.read();
                if (done)
                    break;
                size += value.byteLength;
                if (size > 10_000_000) {
                    await reader.cancel();
                    throw new LamodaApiError('RESPONSE_TOO_LARGE');
                }
                chunks.push(value);
            }
            return Buffer.concat(chunks);
        }
        finally {
            reader.releaseLock();
        }
    }
    async packLabel(c, orderId, packNumber, labelFormat = 'M') {
        if (!['S', 'M', 'L'].includes(labelFormat))
            throw new LamodaApiError('INVALID_LABEL_FORMAT');
        const url = new URL(`${base}/orders/${(0, lamoda_commands_1.lamodaPathId)(orderId)}/packs/${(0, lamoda_commands_1.lamodaPathId)(packNumber)}/label`);
        url.searchParams.set('sellerId', c.sellerId);
        url.searchParams.set('labelFormat', labelFormat);
        const token = await this.token(c);
        let response;
        try {
            response = await this.http(url.toString(), { headers: { Authorization: `Bearer ${token.value}` }, redirect: 'error', signal: AbortSignal.timeout(20_000) });
        }
        catch {
            throw new LamodaApiError('TRANSPORT_ERROR');
        }
        if (!response.ok)
            throw new LamodaApiError('HTTP_ERROR', response.status);
        const bytes = await this.boundedBody(response);
        if (response.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/pdf' || bytes.subarray(0, 5).toString('ascii') !== '%PDF-')
            throw new LamodaApiError('INVALID_PDF');
        return bytes;
    }
    async check(c) {
        // Verify seller access too, rather than treating OAuth success as a working connection.
        // FIX: v2 catalog requires country even for a one-row connection check.
        const data = await this.get(c, '/nomenclatures', { country: 'RU', page: '1', limit: '1' });
        if (!Array.isArray(data.nomenclatures) || record(data.meta).page !== 1)
            throw new LamodaApiError('INVALID_PAGE');
        return data;
    }
    // FIX: fetch every planned line through the fixed API host and verify seller ownership.
    async fboShipment(c, id) {
        const path = `/fbo/shipments/${(0, lamoda_commands_1.lamodaPathId)(id)}`;
        const shipment = await this.get(c, path, {});
        if (shipment.id !== id || String(shipment.sellerId) !== c.sellerId)
            throw new LamodaApiError('SHIPMENT_SCOPE_MISMATCH');
        const items = [];
        for (let page = 1; page <= 40; page++) {
            const response = await this.get(c, `${path}/items`, { page: String(page), limit: '25' }), meta = record(response.meta);
            if (!Array.isArray(response.items) || meta.page !== page || !Number.isSafeInteger(meta.totalPages) || Number(meta.totalPages) < 1 || response.items.length > 25)
                throw new LamodaApiError('INVALID_PAGE');
            items.push(...response.items.map(record));
            if (page === meta.totalPages)
                return { shipment, items };
        }
        throw new LamodaApiError('SYNC_PAGE_LIMIT');
    }
    async collection(c, kind, params = {}) {
        const resource = resources[kind];
        if (!resource)
            throw new LamodaApiError('UNKNOWN_RESOURCE');
        const result = [], started = this.now();
        // FIX: catalog has a 25-row maximum; keep the previous 10,000-row safety cap.
        const limit = kind === 'CATALOG' ? 25 : 100;
        for (let page = 1; page <= 10_000 / limit; page++) {
            if (this.now() - started > 120_000)
                throw new LamodaApiError('SYNC_TIME_LIMIT');
            const data = await this.get(c, resource.path, { ...params, ...(kind === 'CATALOG' ? { country: 'RU' } : {}), page: String(page), limit: String(limit) });
            const items = data[resource.key], meta = record(data.meta);
            if (!Array.isArray(items) || items.length > limit || meta.page !== page || !Number.isSafeInteger(meta.totalPages) ||
                Number(meta.totalPages) < 0 || (Number(meta.totalPages) === 0 && items.length !== 0) ||
                (Number(meta.totalPages) > page && !items.length))
                throw new LamodaApiError('INVALID_PAGE');
            result.push(...items.map(record));
            if (page >= Number(meta.totalPages))
                return result;
        }
        throw new LamodaApiError('SYNC_PAGE_LIMIT');
    }
}
exports.LamodaClient = LamodaClient;
function record(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new LamodaApiError('INVALID_OBJECT');
    return value;
}
