"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lamodaLabelDrafts = lamodaLabelDrafts;
exports.freezeLamodaBatchLabels = freezeLamodaBatchLabels;
const common_1 = require("@nestjs/common");
const lamoda_label_service_1 = require("./lamoda-label.service");
const lamoda_label_1 = require("./lamoda-label");
// FIX: defaults are suggestions only; batch-specific values are stored with the assembly.
async function lamodaLabelDrafts(db, clientId, skus, cards) {
    if (process.env.WMS_LAMODA_ENABLED !== 'true')
        return;
    const profile = (await db.systemSetting.findUnique({ where: { key: (0, lamoda_label_service_1.lamodaLabelKey)(clientId) } }))?.value;
    if (!profile?.enabled)
        return;
    if (profile.clientId !== clientId)
        throw new common_1.BadRequestException('Профиль Lamoda принадлежит другому клиенту.');
    return skus.map(s => {
        const matches = cards.filter(c => c.skuId === s.id && c.isPresent && c.linkState === 'CONFIRMED');
        if (matches.length !== 1)
            throw new common_1.BadRequestException('Уточните соответствие Lamoda для ' + s.name);
        const card = matches[0], r = profile.records?.[card.barcode];
        if (r && (r.article !== card.remoteSku || r.barcode !== card.barcode))
            throw new common_1.BadRequestException('Обновите данные карточки Lamoda для ' + s.name);
        const draft = { ...profile.defaults, ...r, barcode: card.barcode, article: card.remoteSku,
            brand: r?.brand || s.brand || '', name: r?.name || s.name || card.name, color: r?.color || s.color || '', size: r?.size || s.size || card.size || '',
            composition: r?.composition || '', manufacturer: r?.manufacturer || '', origin: r?.origin || '', manufacturedAt: r?.manufacturedAt || '' };
        return { ...draft, skuId: s.id, model: draft.name.replace(/[_\s]+(?:\d{2,3}|[2-5]?XL|XS|S|M|L)$/i, '').replace(/_/g, ' ') };
    });
}
function freezeLamodaBatchLabels(drafts, inputs, confirmed) {
    if (!drafts)
        return undefined;
    if (!confirmed || !inputs || inputs.length !== drafts.length || new Set(inputs.map(x => x.skuId)).size !== inputs.length)
        throw new common_1.BadRequestException('Заполните и подтвердите данные этикеток для каждого вида костюма.');
    return drafts.map(d => {
        const input = inputs.find(i => i.skuId === d.skuId);
        if (!input)
            throw new common_1.BadRequestException('Нет данных партии для ' + d.name);
        const fullLabel = (0, lamoda_label_1.validateLamodaLabel)({ ...d, composition: input.composition, manufacturer: input.manufacturer, origin: input.origin, manufacturedAt: input.manufacturedAt });
        return { skuId: d.skuId, barcode: d.barcode, article: d.article, name: d.name, size: d.size, fullLabel };
    });
}
