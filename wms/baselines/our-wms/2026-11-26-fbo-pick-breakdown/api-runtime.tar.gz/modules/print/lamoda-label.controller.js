"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaLabelController = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const lamoda_label_service_1 = require("./lamoda-label.service");
const lamoda_label_1 = require("./lamoda-label");
let LamodaLabelController = class LamodaLabelController {
    db;
    scopes;
    constructor(db, scopes) {
        this.db = db;
        this.scopes = scopes;
    }
    // FIX: preview is read-only; printing stays in the existing explicit agent/browser workflow.
    async preview(skuId, barcode, user) {
        if (!skuId)
            throw new common_1.BadRequestException('Выберите товар.');
        const sku = await this.db.sku.findFirst({ where: { id: skuId, clientId: this.scopes.resolveClientFilter(user) }, select: { id: true, clientId: true } });
        if (!sku)
            throw new common_1.BadRequestException('Товар недоступен.');
        this.scopes.requireClientAccess(user, sku.clientId, 'read');
        const label = await (0, lamoda_label_service_1.readLamodaLabel)(this.db, sku.clientId, sku.id, barcode);
        if (!label)
            throw new common_1.BadRequestException('Для клиента не настроен шаблон Lamoda с полными данными.');
        const pdf = await (0, lamoda_label_1.buildLamodaLabelPdf)(label);
        return { clientId: sku.clientId, skuId: sku.id, barcode: label.barcode, article: label.article, widthMm: 58, heightMm: 40, imageBase64: await (0, lamoda_label_1.lamodaLabelImage)(pdf), pdfBase64: pdf.toString('base64') };
    }
};
exports.LamodaLabelController = LamodaLabelController;
__decorate([
    (0, common_1.Get)('label'),
    __param(0, (0, common_1.Query)('skuId')),
    __param(1, (0, common_1.Query)('barcode')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], LamodaLabelController.prototype, "preview", null);
exports.LamodaLabelController = LamodaLabelController = __decorate([
    (0, common_1.Controller)('print/lamoda'),
    (0, require_permissions_decorator_1.RequirePermissions)('print:write'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], LamodaLabelController);
