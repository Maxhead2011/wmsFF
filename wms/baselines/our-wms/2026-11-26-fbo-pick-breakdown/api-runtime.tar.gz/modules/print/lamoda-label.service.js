"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lamodaLabelKey = void 0;
exports.readLamodaLabel = readLamodaLabel;
const common_1 = require("@nestjs/common");
const lamoda_label_1 = require("./lamoda-label");
const lamodaLabelKey = (clientId) => `lamoda.label-profile.v1:${clientId}`;
exports.lamodaLabelKey = lamodaLabelKey;
// FIX: use only a current confirmed mapping in the same client, never names or sizes as a join.
async function readLamodaLabel(db, clientId, skuId, barcode, article, snapshot, requireSnapshot = false) {
    if (process.env.WMS_LAMODA_ENABLED !== 'true')
        return null;
    if (snapshot) {
        const saved = (0, lamoda_label_1.validateLamodaLabel)(snapshot);
        if (saved.barcode !== barcode || saved.article !== article)
            throw new common_1.BadRequestException('Сохранённая этикетка не соответствует товару заявки.');
        return saved;
    }
    const profile = (await db.systemSetting.findUnique({ where: { key: (0, exports.lamodaLabelKey)(clientId) } }))?.value;
    if (!profile?.enabled)
        return null;
    if (requireSnapshot)
        throw new common_1.BadRequestException('Заполните и сохраните данные в форме переклейки Lamoda перед печатью.');
    if (profile.clientId !== clientId)
        throw new common_1.BadRequestException('Профиль этикеток Lamoda принадлежит другому клиенту.');
    const cards = await db.lamodaProduct.findMany({ where: { skuId, isPresent: true, linkState: 'CONFIRMED', ...(barcode ? { barcode } : {}), account: { clientId, isActive: true } }, select: { barcode: true, remoteSku: true } });
    if (cards.length !== 1 || !cards[0].barcode)
        throw new common_1.BadRequestException('Подтвердите однозначную привязку товара к ШК Lamoda.');
    const card = cards[0], raw = profile.records?.[card.barcode];
    if (!raw)
        throw new common_1.BadRequestException(`Для ШК Lamoda ${card.barcode} нет полных данных этикетки. Добавьте состав, производителя, адреса, дату изготовления и знаки ухода из образца.`);
    const value = (0, lamoda_label_1.validateLamodaLabel)(raw);
    if (value.barcode !== card.barcode || value.article !== card.remoteSku || (article && value.article !== article))
        throw new common_1.BadRequestException('Данные этикетки расходятся с артикулом или ШК подтверждённой карточки Lamoda.');
    return value;
}
