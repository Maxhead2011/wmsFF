"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaRelabelDataController = exports.LamodaRelabelDataDto = void 0;
const common_1 = require("@nestjs/common");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const fbo_two_stage_service_1 = require("./fbo-two-stage.service");
class LamodaRelabelItemDto {
    skuId;
    composition;
    manufacturer;
    origin;
    manufacturedAt;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaRelabelItemDto.prototype, "skuId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(600),
    __metadata("design:type", String)
], LamodaRelabelItemDto.prototype, "composition", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(600),
    __metadata("design:type", String)
], LamodaRelabelItemDto.prototype, "manufacturer", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(600),
    __metadata("design:type", String)
], LamodaRelabelItemDto.prototype, "origin", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(10),
    __metadata("design:type", String)
], LamodaRelabelItemDto.prototype, "manufacturedAt", void 0);
class LamodaRelabelDataDto {
    confirmed;
    labelData;
}
exports.LamodaRelabelDataDto = LamodaRelabelDataDto;
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], LamodaRelabelDataDto.prototype, "confirmed", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(1000),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => LamodaRelabelItemDto),
    __metadata("design:type", Array)
], LamodaRelabelDataDto.prototype, "labelData", void 0);
let LamodaRelabelDataController = class LamodaRelabelDataController {
    fbo;
    constructor(fbo) {
        this.fbo = fbo;
    }
    view(id, user) { return this.fbo.lamodaLabelData(id, user); }
    save(id, body, user) { return this.fbo.lamodaLabelData(id, user, body); }
};
exports.LamodaRelabelDataController = LamodaRelabelDataController;
__decorate([
    (0, common_1.Get)('data'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], LamodaRelabelDataController.prototype, "view", null);
__decorate([
    (0, common_1.Post)('data'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, LamodaRelabelDataDto, Object]),
    __metadata("design:returntype", void 0)
], LamodaRelabelDataController.prototype, "save", null);
exports.LamodaRelabelDataController = LamodaRelabelDataController = __decorate([
    (0, common_1.Controller)('tsd/requests/:id/fbo/lamoda-relabel'),
    __metadata("design:paramtypes", [typeof (_a = typeof fbo_two_stage_service_1.FboTwoStageService !== "undefined" && fbo_two_stage_service_1.FboTwoStageService) === "function" ? _a : Object])
], LamodaRelabelDataController);
