"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isFabricMaterial = exports.colorNameKey = exports.BASE_FABRIC_COLORS = exports.BASE_FABRIC_MATERIALS = void 0;
exports.addFabricMaterial = addFabricMaterial;
exports.preserveFabricBinding = preserveFabricBinding;
exports.addFabricColor = addFabricColor;
exports.readFabricBinding = readFabricBinding;
exports.createFabricBinding = createFabricBinding;
const crypto_1 = require("crypto");
exports.BASE_FABRIC_MATERIALS = { SATIN: 'Атлас / сатин', GABARDINE: 'Габардин' };
exports.BASE_FABRIC_COLORS = { black: 'Чёрный', white: 'Белый', green: 'Зелёный', red: 'Красный', ivory: 'Айвори / шампань', blue: 'Синий' };
const colorNameKey = (name) => name.normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('ru-RU').replace(/ё/g, 'е');
exports.colorNameKey = colorNameKey;
const customMaterialId = (id) => typeof id === 'string' && /^material-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id);
const validName = (name) => typeof name === 'string' && !!name.trim() && name.length <= 80 && !/[\x00-\x1f\x7f]/.test(name);
const isFabricMaterial = (id, materials = []) => Object.prototype.hasOwnProperty.call(exports.BASE_FABRIC_MATERIALS, id) || materials.some(m => customMaterialId(m.id) && m.id === id && validName(m.name));
exports.isFabricMaterial = isFabricMaterial;
// FIX: material IDs are client-scoped catalog identities; names never substitute for stock identity.
function addFabricMaterial(materials, name) {
    if (!validName(name))
        throw new Error('Название ткани: от 1 до 80 символов.');
    name = name.normalize('NFKC').trim().replace(/\s+/g, ' ');
    const normalized = (0, exports.colorNameKey)(name), alias = normalized.replace(/[\s/\\]+/g, '');
    const base = ['атлас', 'сатин', 'атлассатин', 'сатинатлас'].includes(alias) ? 'SATIN' : normalized === 'габардин' ? 'GABARDINE' : null;
    const existing = materials.find(m => (0, exports.colorNameKey)(m.name) === normalized);
    const material = base ? { id: base, name: exports.BASE_FABRIC_MATERIALS[base] } : existing ?? { id: 'material-' + (0, crypto_1.randomUUID)(), name };
    return { material, materials: base || existing ? [...materials] : [...materials, material], reused: !!(base || existing) };
}
// FIX: preserve warehouse-owned metadata during marketplace synchronization.
function preserveFabricBinding(incoming, previous) {
    const payload = incoming && typeof incoming === 'object' && !Array.isArray(incoming) ? { ...incoming } : {};
    delete payload.fabricRollBinding;
    const binding = readFabricBinding(previous);
    return binding ? { ...payload, fabricRollBinding: binding } : payload;
}
// FIX: colors belong to one client registry and one material; duplicate names reuse the existing color.
function addFabricColor(colors, material, name, materials = []) {
    if (!(0, exports.isFabricMaterial)(material, materials) || typeof name !== 'string')
        throw new Error('Укажите ткань и название цвета.');
    name = name.normalize('NFKC').trim().replace(/\s+/g, ' ');
    if (!name || name.length > 80 || /[\x00-\x1f\x7f]/.test(name))
        throw new Error('Название цвета: от 1 до 80 символов.');
    const base = Object.entries(exports.BASE_FABRIC_COLORS).find(([, label]) => (0, exports.colorNameKey)(label) === (0, exports.colorNameKey)(name));
    const existing = colors.find(c => c.material === material && (0, exports.colorNameKey)(c.name) === (0, exports.colorNameKey)(name));
    const color = base ? { id: base[0], material, name: base[1] } : existing ?? { id: 'custom-' + (0, crypto_1.randomUUID)(), material, name };
    return { color, colors: base || existing ? [...colors] : [...colors, color], reused: Boolean(base || existing) };
}
// FIX: the SKU remains the marketplace identity; its explicit binding supplies exact material consumption.
function readFabricBinding(payload) {
    const b = payload?.fabricRollBinding;
    return b?.version === 1 && (['SATIN', 'GABARDINE'].includes(b.material) || (customMaterialId(b.material) && validName(b.materialName))) && typeof b.color === 'string' &&
        typeof b.colorName === 'string' && Number.isSafeInteger(b.lengthMm) && b.lengthMm > 0 && b.lengthMm <= 100000 ? b : null;
}
function createFabricBinding(colors, material, colorId, lengthMm, materials = []) {
    const colorName = exports.BASE_FABRIC_COLORS[colorId] ?? colors.find(c => c.id === colorId && c.material === material)?.name;
    if (!(0, exports.isFabricMaterial)(material, materials) || !colorName || !Number.isSafeInteger(lengthMm) || lengthMm < 1 || lengthMm > 100000) {
        throw new Error('Выберите цвет этой ткани и длину отреза от 0,001 до 100 м.');
    }
    return { version: 1, material, ...(customMaterialId(material) ? { materialName: materials.find(m => m.id === material).name } : {}), color: colorId, colorName, lengthMm };
}
