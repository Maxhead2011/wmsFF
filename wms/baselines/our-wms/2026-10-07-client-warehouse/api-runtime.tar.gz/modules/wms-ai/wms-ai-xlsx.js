"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.WMS_AI_XLSX_MIME = void 0;
exports.buildWmsAiWorkbook = buildWmsAiWorkbook;
const XLSX = __importStar(require("xlsx"));
exports.WMS_AI_XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
function buildWmsAiWorkbook(input) {
    const resultRows = [
        input.columns.map((column) => column.label),
        ...input.rows.map((row) => input.columns.map((column) => row[column.key] ?? '')),
    ];
    const resultSheet = XLSX.utils.aoa_to_sheet(resultRows);
    resultSheet['!cols'] = input.columns.map((column) => ({
        wch: Math.min(48, Math.max(column.label.length + 2, ...input.rows.slice(0, 500).map((row) => String(row[column.key] ?? '').length + 2))),
    }));
    resultSheet['!autofilter'] = { ref: resultSheet['!ref'] || 'A1:A1' };
    const paramsSheet = XLSX.utils.aoa_to_sheet([
        ['Отчёт', input.title],
        ['Склад', input.warehouse.name],
        ['Город', input.warehouse.city],
        ['Код склада', input.warehouse.code],
        ['Сформирован', input.generatedAt],
        ['Строк', input.rows.length],
    ]);
    paramsSheet['!cols'] = [{ wch: 20 }, { wch: 54 }];
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, resultSheet, 'Результат');
    XLSX.utils.book_append_sheet(workbook, paramsSheet, 'Параметры');
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
