"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsAiController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const wms_ai_chat_dto_1 = require("./dto/wms-ai-chat.dto");
const wms_ai_service_1 = require("./wms-ai.service");
const wms_ai_xlsx_1 = require("./wms-ai-xlsx");
const wms_openclaw_service_1 = require("./wms-openclaw.service");
const wms_openclaw_job_dto_1 = require("./dto/wms-openclaw-job.dto");
let WmsAiController = class WmsAiController {
    service;
    openClaw;
    constructor(service, openClaw) {
        this.service = service;
        this.openClaw = openClaw;
    }
    // FIX: durable jobs keep browser retries from replaying server changes.
    openClawStatus(user) { return this.openClaw.status(user); }
    openClawSubmit(dto, user) { return this.openClaw.submit(dto, user); }
    openClawJobs(user, cursor) { return this.openClaw.listJobs(user, cursor); }
    openClawJob(requestId, user) { return this.openClaw.get(requestId, user); }
    chat(dto, user) {
        if ((0, wms_openclaw_service_1.openClawEnabled)())
            throw new common_1.ConflictException('ИИ заменён на OpenClaw. Обновите страницу и используйте новый чат.');
        return this.service.chat(dto.message, user);
    }
    learn(dto, user) {
        if ((0, wms_openclaw_service_1.openClawEnabled)())
            throw new common_1.ConflictException('База знаний теперь ведётся в OpenClaw.');
        return this.service.learn(dto, user);
    }
    async export(tool, query, user, response) {
        const file = await this.service.export(tool, {
            search: query.search,
            boxCode: query.boxCode,
            palletCode: query.palletCode,
            maxTotal: query.maxTotal ? Number(query.maxTotal) : undefined,
            minTotal: query.minTotal ? Number(query.minTotal) : undefined,
            clientSearch: query.clientSearch,
            requestNumber: query.requestNumber ? Number(query.requestNumber) : undefined,
            days: query.days ? Number(query.days) : undefined,
            status: query.status,
        }, user);
        response.setHeader('Content-Type', wms_ai_xlsx_1.WMS_AI_XLSX_MIME);
        response.setHeader('Content-Disposition', `attachment; filename="wms-ai.xlsx"; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.buffer);
    }
};
exports.WmsAiController = WmsAiController;
__decorate([
    (0, common_1.Get)('openclaw/status'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], WmsAiController.prototype, "openClawStatus", null);
__decorate([
    (0, common_1.Post)('openclaw/jobs'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wms_openclaw_job_dto_1.WmsOpenClawJobDto, Object]),
    __metadata("design:returntype", void 0)
], WmsAiController.prototype, "openClawSubmit", null);
__decorate([
    (0, common_1.Get)('openclaw/jobs/:requestId'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WmsAiController.prototype, "openClawJob", null);
__decorate([
    (0, common_1.Post)('chat'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wms_ai_chat_dto_1.WmsAiChatDto, Object]),
    __metadata("design:returntype", void 0)
], WmsAiController.prototype, "chat", null);
__decorate([
    (0, common_1.Post)('knowledge'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('warehouse:write', 'stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wms_ai_chat_dto_1.WmsAiLearnDto, Object]),
    __metadata("design:returntype", void 0)
], WmsAiController.prototype, "learn", null);
__decorate([
    (0, common_1.Get)('export.xlsx'),
    __param(0, (0, common_1.Query)('tool')),
    __param(1, (0, common_1.Query)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", Promise)
], WmsAiController.prototype, "export", null);
__decorate([
    (0, common_1.Get)('openclaw/jobs'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('cursor')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WmsAiController.prototype, "openClawJobs", null);
exports.WmsAiController = WmsAiController = __decorate([
    (0, common_1.Controller)('wms-ai'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:read', 'stock:read'),
    __metadata("design:paramtypes", [wms_ai_service_1.WmsAiService, wms_openclaw_service_1.WmsOpenClawService])
], WmsAiController);
