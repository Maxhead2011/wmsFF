"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const access_model_service_1 = require("../auth/access-model.service");
const password_service_1 = require("../auth/password.service");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const printer_scope_service_1 = require("../auth/printer-scope.service");
const user_deletion_policy_1 = require("./user-deletion-policy");
let UsersService = class UsersService {
    prisma;
    accessModel;
    passwords;
    constructor(prisma, accessModel, passwords) {
        this.prisma = prisma;
        this.accessModel = accessModel;
        this.passwords = passwords;
    }
    async list(currentUser) {
        const users = await this.prisma.user.findMany({
            where: {
                isDemo: Boolean(currentUser.isDemo),
                status: { not: client_1.UserStatus.ARCHIVED },
                ...(currentUser.permissionCodes.includes('system:admin') || !(currentUser.warehouseIds?.length)
                    ? {}
                    : {
                        OR: [
                            { id: currentUser.id },
                            {
                                warehouseScopes: {
                                    some: { warehouseId: { in: currentUser.warehouseIds } },
                                },
                            },
                        ],
                    }),
            },
            orderBy: { createdAt: 'desc' },
            select: this.userSummarySelect(),
        });
        const actor = users.find(user => user.id === currentUser.id);
        return users.map((user) => ({ ...this.toUserSummary(user), canDelete: (0, user_deletion_policy_1.canDeleteUser)(actor, user) }));
    }
    // FIX: archive atomically with access revocation and audit; never delete historical user relations.
    async deleteUser(userId, currentUser) {
        try {
            return await this.prisma.$transaction(async (tx) => {
                const [actor, target] = await Promise.all([currentUser.id, userId].map(id => tx.user.findFirst({
                    where: { id, isDemo: Boolean(currentUser.isDemo) }, select: this.userSummarySelect(),
                })));
                if (!target)
                    throw new common_1.NotFoundException('Пользователь не найден.');
                if (!(0, user_deletion_policy_1.canDeleteUser)(actor, target))
                    throw new common_1.ForbiddenException('Удалять пользователей может owner или администратор закреплённого филиала. Администратор не может удалить администратора или owner.');
                if (target.status === client_1.UserStatus.ARCHIVED)
                    return { id: userId, status: 'ARCHIVED' };
                const now = new Date();
                await tx.user.update({ where: { id: userId }, data: { status: client_1.UserStatus.ARCHIVED, tsdActivationCodeHash: null } });
                await tx.userSession.updateMany({ where: { userId }, data: { expiresAt: now } });
                await tx.mobileSession.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: now } });
                // FIX: revoke the employee's access without blocking a shared physical TSD.
                // Auth gates reject ARCHIVED users; keep the sold installation's behavior unless opted in.
                if (process.env.WMS_USER_DELETION_PRESERVE_TSD_DEVICES !== 'true') {
                    await tx.tsdDevice.updateMany({ where: { userId }, data: { status: 'BLOCKED' } });
                }
                await tx.auditLog.create({ data: { userId: currentUser.id, action: 'USER_ARCHIVED', entity: 'User', entityId: userId,
                        payload: { name: target.name, previousStatus: target.status, roles: target.roles.map(row => row.role.code),
                            warehouseIds: target.warehouseScopes.map(row => row.warehouse.id) } } });
                return { id: userId, status: 'ARCHIVED' };
            }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError && error.code === 'P2034') {
                throw new common_1.ConflictException('Права или данные пользователя изменились. Обновите список и повторите удаление.');
            }
            throw error;
        }
    }
    async create(dto, currentUser) {
        const roles = await this.accessModel.resolveRoles(dto.roleCodes?.length ? dto.roleCodes : ['OPERATOR']);
        this.assertCompatibleRoleCodes(roles.map((role) => role.code));
        await this.ensureDemoSafeRoles(roles.map((role) => role.id), currentUser);
        const clientScopes = this.buildCreateClientScopes(dto.clientIds, dto.writableClientIds);
        await this.ensureClientsExist(clientScopes.map((scope) => scope.clientId), currentUser);
        const warehouseId = await this.resolveCreationWarehouse(dto.warehouseId, roles.map((role) => role.code), currentUser);
        // Русский комментарий: API никогда не возвращает passwordHash; пароль сохраняется только как scrypt hash.
        const user = await this.prisma.user.create({
            data: {
                email: dto.email.trim().toLowerCase(),
                name: dto.name.trim(),
                passwordHash: await this.passwords.hash(dto.password),
                isDemo: Boolean(currentUser.isDemo),
                activeWarehouseId: warehouseId,
                roles: {
                    create: roles.map((role) => ({ roleId: role.id })),
                },
                warehouseScopes: warehouseId
                    ? {
                        create: {
                            warehouseId,
                            canRead: true,
                            canWrite: true,
                        },
                    }
                    : undefined,
                clientScopes: clientScopes.length
                    ? {
                        create: clientScopes,
                    }
                    : undefined,
            },
            select: this.userSummarySelect(),
        });
        return this.toUserSummary(user);
    }
    async resolveCreationWarehouse(requestedWarehouseId, roleCodes, currentUser) {
        if (roleCodes.some((code) => ['ADMIN', 'OWNER', 'CLIENT'].includes(code))) {
            return null;
        }
        const warehouseId = requestedWarehouseId?.trim() || currentUser.activeWarehouseId || '';
        if (!warehouseId) {
            throw new common_1.BadRequestException('Для сотрудника укажите филиал.');
        }
        const isNetworkAdmin = currentUser.permissionCodes.includes('system:admin');
        if (!isNetworkAdmin &&
            (currentUser.activeWarehouseId !== warehouseId ||
                !(currentUser.writableWarehouseIds ?? []).includes(warehouseId))) {
            throw new common_1.BadRequestException('Сотрудника можно создать только в своём филиале.');
        }
        const warehouse = await this.prisma.warehouse.findFirst({
            where: { id: warehouseId, isActive: true },
            select: { id: true },
        });
        if (!warehouse) {
            throw new common_1.BadRequestException('Выбранный филиал не найден или отключён.');
        }
        return warehouse.id;
    }
    async updateClientScopes(userId, dto, currentUser) {
        await this.ensureUserInSameMode(userId, currentUser);
        const scopes = [...new Map(dto.scopes.map((scope) => [scope.clientId, scope])).values()].map((scope) => ({
            clientId: scope.clientId,
            canWrite: scope.canWrite ?? false,
            canRead: (scope.canRead ?? true) || (scope.canWrite ?? false),
        }));
        await this.ensureClientsExist(scopes.map((scope) => scope.clientId), currentUser);
        await this.prisma.$transaction(async (tx) => {
            await tx.userClient.deleteMany({ where: { userId } });
            if (scopes.length > 0) {
                await tx.userClient.createMany({
                    data: scopes.map((scope) => ({
                        userId,
                        ...scope,
                    })),
                    skipDuplicates: true,
                });
            }
        });
        return this.findUserSummary(userId);
    }
    async updatePrinterScopes(userId, dto, currentUser) {
        await this.ensureUserInSameMode(userId, currentUser);
        const scopes = [...new Map(dto.scopes.map((scope) => [(0, printer_scope_service_1.normalizePrinterGroupCode)(scope.groupCode), scope])).values()].map((scope) => ({
            groupCode: (0, printer_scope_service_1.normalizePrinterGroupCode)(scope.groupCode),
            canManage: scope.canManage ?? false,
            canPrint: (scope.canPrint ?? true) || (scope.canManage ?? false),
        }));
        await this.prisma.$transaction(async (tx) => {
            await tx.user.findUniqueOrThrow({
                where: { id: userId },
                select: { id: true },
            });
            await tx.userPrinterGroup.deleteMany({ where: { userId } });
            if (scopes.length > 0) {
                await tx.userPrinterGroup.createMany({
                    data: scopes.map((scope) => ({
                        userId,
                        ...scope,
                    })),
                    skipDuplicates: true,
                });
            }
        });
        return this.findUserSummary(userId);
    }
    async updateProfile(userId, dto, currentUser) {
        await this.ensureUserInSameMode(userId, currentUser);
        if (dto.status && dto.status !== client_1.UserStatus.ACTIVE) {
            await this.ensureSystemAdminStatusSurvives(userId);
        }
        const warehouseId = dto.warehouseId === undefined
            ? undefined
            : await this.resolveUpdatedWarehouse(userId, dto.warehouseId, currentUser);
        const passwordHash = dto.password === undefined
            ? undefined
            : await this.passwords.hash(dto.password);
        try {
            const user = await this.prisma.$transaction(async (tx) => {
                await tx.user.update({
                    where: { id: userId },
                    data: {
                        ...(dto.email === undefined ? {} : { email: dto.email.trim().toLowerCase() }),
                        ...(dto.name === undefined ? {} : { name: dto.name.trim() }),
                        ...(passwordHash === undefined ? {} : { passwordHash }),
                        ...(dto.status === undefined ? {} : { status: dto.status }),
                        ...(dto.analyticsEnabled === undefined ? {} : { analyticsEnabled: dto.analyticsEnabled }),
                        ...(warehouseId === undefined ? {} : { activeWarehouseId: warehouseId }),
                    },
                });
                if (warehouseId !== undefined) {
                    await tx.userWarehouse.deleteMany({ where: { userId } });
                    if (warehouseId) {
                        await tx.userWarehouse.create({
                            data: {
                                userId,
                                warehouseId,
                                canRead: true,
                                canWrite: true,
                            },
                        });
                    }
                }
                return tx.user.findUniqueOrThrow({
                    where: { id: userId },
                    select: this.userSummarySelect(),
                });
            });
            return this.toUserSummary(user);
        }
        catch (caught) {
            if (isRecordNotFoundError(caught)) {
                throw new common_1.NotFoundException('Пользователь не найден.');
            }
            if (isUniqueUserEmailError(caught)) {
                throw new common_1.BadRequestException('Пользователь с таким логином или email уже существует.');
            }
            throw caught;
        }
    }
    async resolveUpdatedWarehouse(userId, requestedWarehouseId, currentUser) {
        const target = await this.prisma.user.findUnique({
            where: { id: userId },
            select: {
                roles: { select: { role: { select: { code: true } } } },
            },
        });
        if (!target)
            throw new common_1.NotFoundException('Пользователь не найден.');
        const warehouseId = requestedWarehouseId?.trim() || '';
        const roleCodes = target.roles.map((item) => item.role.code);
        const mayWorkAcrossBranches = roleCodes.some((code) => ['ADMIN', 'OWNER', 'CLIENT'].includes(code));
        if (!warehouseId) {
            if (!mayWorkAcrossBranches) {
                throw new common_1.BadRequestException('Для сотрудника нужно выбрать филиал.');
            }
            return null;
        }
        const isNetworkAdmin = currentUser.permissionCodes.includes('system:admin');
        if (!isNetworkAdmin &&
            (currentUser.activeWarehouseId !== warehouseId ||
                !(currentUser.writableWarehouseIds ?? []).includes(warehouseId))) {
            throw new common_1.BadRequestException('Сотрудника можно закрепить только за своим филиалом.');
        }
        const warehouse = await this.prisma.warehouse.findFirst({
            where: { id: warehouseId, isActive: true },
            select: { id: true },
        });
        if (!warehouse) {
            throw new common_1.BadRequestException('Выбранный филиал не найден или отключён.');
        }
        return warehouse.id;
    }
    async updateRoles(userId, dto, currentUser) {
        if (currentUser) {
            await this.ensureUserInSameMode(userId, currentUser);
        }
        const roleCodes = this.normalizeRoleCodes(dto.roleCodes);
        if (roleCodes.length === 0) {
            throw new common_1.BadRequestException('Нужно выбрать хотя бы одну роль пользователя.');
        }
        const roles = await this.accessModel.resolveRoles(roleCodes);
        this.assertCompatibleRoleCodes(roles.map((role) => role.code));
        if (currentUser) {
            await this.ensureDemoSafeRoles(roles.map((role) => role.id), currentUser);
        }
        await this.ensureSystemAdminSurvives(userId, roles.map((role) => role.id));
        await this.prisma.$transaction(async (tx) => {
            await tx.user.findUniqueOrThrow({
                where: { id: userId },
                select: { id: true },
            });
            await tx.userRole.deleteMany({ where: { userId } });
            await tx.userRole.createMany({
                data: roles.map((role) => ({
                    userId,
                    roleId: role.id,
                })),
                skipDuplicates: true,
            });
        });
        return this.findUserSummary(userId);
    }
    async setTsdActivationCode(userId, dto) {
        if (!/^\d{4}$/.test(dto.code)) {
            throw new common_1.BadRequestException('Код подтверждения должен состоять ровно из 4 цифр.');
        }
        try {
            const user = await this.prisma.user.update({
                where: { id: userId },
                data: {
                    tsdActivationCodeHash: await this.passwords.hash(dto.code),
                },
                select: this.userSummarySelect(),
            });
            return this.toUserSummary(user);
        }
        catch (caught) {
            if (isRecordNotFoundError(caught)) {
                throw new common_1.NotFoundException('Пользователь не найден.');
            }
            throw caught;
        }
    }
    async clearTsdActivationCode(userId) {
        try {
            const user = await this.prisma.user.update({
                where: { id: userId },
                data: {
                    tsdActivationCodeHash: null,
                },
                select: this.userSummarySelect(),
            });
            return this.toUserSummary(user);
        }
        catch (caught) {
            if (isRecordNotFoundError(caught)) {
                throw new common_1.NotFoundException('Пользователь не найден.');
            }
            throw caught;
        }
    }
    async listRoles(currentUser) {
        const roles = await this.accessModel.listRoles();
        return roles
            .filter((role) => !currentUser.isDemo ||
            !role.permissions.some((item) => item.permission.code === 'system:admin'))
            .map((role) => ({
            id: role.id,
            code: role.code,
            name: role.name,
            permissions: role.permissions.map((item) => ({
                code: item.permission.code,
                name: item.permission.name,
            })),
        }));
    }
    buildCreateClientScopes(clientIds, writableClientIds) {
        const readSet = new Set(clientIds ?? []);
        const writeSet = new Set(writableClientIds ?? []);
        writeSet.forEach((clientId) => readSet.add(clientId));
        return [...readSet].map((clientId) => ({
            clientId,
            canRead: true,
            canWrite: writeSet.has(clientId),
        }));
    }
    async ensureClientsExist(clientIds, currentUser) {
        const uniqueClientIds = [...new Set(clientIds)];
        if (uniqueClientIds.length === 0) {
            return;
        }
        const foundClients = await this.prisma.client.findMany({
            where: {
                id: { in: uniqueClientIds },
                ...(currentUser ? { isDemo: Boolean(currentUser.isDemo) } : {}),
            },
            select: { id: true },
        });
        if (foundClients.length !== uniqueClientIds.length) {
            throw new common_1.BadRequestException('Один или несколько клиентов для scope не найдены.');
        }
    }
    normalizeRoleCodes(roleCodes) {
        return [...new Set(roleCodes.map((code) => code.trim().toUpperCase()).filter(Boolean))];
    }
    assertCompatibleRoleCodes(roleCodes) {
        if (roleCodes.includes('CLIENT') && roleCodes.some((code) => code !== 'CLIENT')) {
            throw new common_1.BadRequestException('Роль клиента нельзя совмещать с внутренними ролями сотрудников.');
        }
    }
    async ensureSystemAdminSurvives(userId, nextRoleIds) {
        const currentHasSystemAdmin = await this.prisma.userRole.count({
            where: {
                userId,
                role: {
                    permissions: {
                        some: {
                            permission: { code: 'system:admin' },
                        },
                    },
                },
            },
        });
        if (currentHasSystemAdmin === 0) {
            return;
        }
        const nextHasSystemAdmin = await this.prisma.role.count({
            where: {
                id: { in: nextRoleIds },
                permissions: {
                    some: {
                        permission: { code: 'system:admin' },
                    },
                },
            },
        });
        if (nextHasSystemAdmin > 0) {
            return;
        }
        const otherSystemAdmins = await this.prisma.user.count({
            where: {
                id: { not: userId },
                status: client_1.UserStatus.ACTIVE,
                roles: {
                    some: {
                        role: {
                            permissions: {
                                some: {
                                    permission: { code: 'system:admin' },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (otherSystemAdmins === 0) {
            throw new common_1.BadRequestException('Нельзя снять последнюю роль с полным административным доступом.');
        }
    }
    async findUserSummary(userId) {
        const user = await this.prisma.user.findUniqueOrThrow({
            where: { id: userId },
            select: this.userSummarySelect(),
        });
        return this.toUserSummary(user);
    }
    async ensureUserInSameMode(userId, currentUser) {
        const target = await this.prisma.user.findFirst({
            where: { id: userId, isDemo: Boolean(currentUser.isDemo), status: { not: client_1.UserStatus.ARCHIVED } },
            select: { id: true },
        });
        if (!target) {
            throw new common_1.NotFoundException('Пользователь не найден.');
        }
    }
    async ensureDemoSafeRoles(roleIds, currentUser) {
        if (!currentUser.isDemo) {
            return;
        }
        const unsafeRoles = await this.prisma.role.count({
            where: {
                id: { in: roleIds },
                permissions: {
                    some: {
                        permission: { code: 'system:admin' },
                    },
                },
            },
        });
        if (unsafeRoles > 0) {
            throw new common_1.BadRequestException('В демонстрационном режиме нельзя назначать production-роли владельца и администратора.');
        }
    }
    userSummarySelect() {
        return {
            id: true,
            email: true,
            name: true,
            status: true,
            analyticsEnabled: true,
            activeWarehouseId: true,
            tsdActivationCodeHash: true,
            createdAt: true,
            roles: {
                select: {
                    role: {
                        select: {
                            code: true,
                            name: true,
                        },
                    },
                },
            },
            clientScopes: {
                select: {
                    canRead: true,
                    canWrite: true,
                    client: {
                        select: {
                            id: true,
                            code: true,
                            name: true,
                        },
                    },
                },
            },
            printerScopes: {
                select: {
                    groupCode: true,
                    canPrint: true,
                    canManage: true,
                },
            },
            warehouseScopes: {
                select: {
                    canRead: true,
                    canWrite: true,
                    warehouse: {
                        select: {
                            id: true,
                            code: true,
                            name: true,
                            city: true,
                        },
                    },
                },
            },
        };
    }
    toUserSummary(user) {
        const { tsdActivationCodeHash: _tsdActivationCodeHash, ...summary } = user;
        return {
            ...summary,
            hasTsdActivationCode: Boolean(_tsdActivationCodeHash),
        };
    }
    async ensureSystemAdminStatusSurvives(userId) {
        const currentHasSystemAdmin = await this.prisma.userRole.count({
            where: {
                userId,
                role: {
                    permissions: {
                        some: {
                            permission: { code: 'system:admin' },
                        },
                    },
                },
            },
        });
        if (currentHasSystemAdmin === 0) {
            return;
        }
        const otherSystemAdmins = await this.prisma.user.count({
            where: {
                id: { not: userId },
                status: client_1.UserStatus.ACTIVE,
                roles: {
                    some: {
                        role: {
                            permissions: {
                                some: {
                                    permission: { code: 'system:admin' },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (otherSystemAdmins === 0) {
            throw new common_1.BadRequestException('Нельзя заблокировать последнего пользователя с полным административным доступом.');
        }
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        access_model_service_1.AccessModelService,
        password_service_1.PasswordService])
], UsersService);
function isRecordNotFoundError(caught) {
    return caught instanceof client_1.Prisma.PrismaClientKnownRequestError && caught.code === 'P2025';
}
function isUniqueUserEmailError(caught) {
    return caught instanceof client_1.Prisma.PrismaClientKnownRequestError && caught.code === 'P2002';
}
