"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const create_user_dto_1 = require("./dto/create-user.dto");
const set_tsd_activation_code_dto_1 = require("./dto/set-tsd-activation-code.dto");
const update_user_client_scopes_dto_1 = require("./dto/update-user-client-scopes.dto");
const update_user_printer_scopes_dto_1 = require("./dto/update-user-printer-scopes.dto");
const update_user_profile_dto_1 = require("./dto/update-user-profile.dto");
const update_user_roles_dto_1 = require("./dto/update-user-roles.dto");
const users_service_1 = require("./users.service");
let UsersController = class UsersController {
    users;
    constructor(users) {
        this.users = users;
    }
    list(user) {
        return this.users.list(user);
    }
    create(dto, user) {
        return this.users.create(dto, user);
    }
    // FIX: role/branch authorization is rechecked from the DB inside the transaction.
    deleteUser(id, user) {
        return this.users.deleteUser(id, user);
    }
    updateClientScopes(id, dto, user) {
        return this.users.updateClientScopes(id, dto, user);
    }
    updatePrinterScopes(id, dto, user) {
        return this.users.updatePrinterScopes(id, dto, user);
    }
    updateProfile(id, dto, user) {
        return this.users.updateProfile(id, dto, user);
    }
    updateRoles(id, dto, user) {
        return this.users.updateRoles(id, dto, user);
    }
    setTsdActivationCode(id, dto) {
        return this.users.setTsdActivationCode(id, dto);
    }
    clearTsdActivationCode(id) {
        return this.users.clearTsdActivationCode(id);
    }
    listRoles(user) {
        return this.users.listRoles(user);
    }
};
exports.UsersController = UsersController;
__decorate([
    (0, common_1.Get)(),
    (0, require_permissions_decorator_1.RequirePermissions)('users:read'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "list", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('users:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_user_dto_1.CreateUserDto, Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "create", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('users:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "deleteUser", null);
__decorate([
    (0, common_1.Patch)(':id/client-scopes'),
    (0, require_permissions_decorator_1.RequirePermissions)('users:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_user_client_scopes_dto_1.UpdateUserClientScopesDto, Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "updateClientScopes", null);
__decorate([
    (0, common_1.Patch)(':id/printer-scopes'),
    (0, require_permissions_decorator_1.RequirePermissions)('users:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_user_printer_scopes_dto_1.UpdateUserPrinterScopesDto, Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "updatePrinterScopes", null);
__decorate([
    (0, common_1.Patch)(':id/profile'),
    (0, require_permissions_decorator_1.RequirePermissions)('users:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_user_profile_dto_1.UpdateUserProfileDto, Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "updateProfile", null);
__decorate([
    (0, common_1.Patch)(':id/roles'),
    (0, require_permissions_decorator_1.RequirePermissions)('users:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_user_roles_dto_1.UpdateUserRolesDto, Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "updateRoles", null);
__decorate([
    (0, common_1.Patch)(':id/tsd-activation-code'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, set_tsd_activation_code_dto_1.SetTsdActivationCodeDto]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "setTsdActivationCode", null);
__decorate([
    (0, common_1.Delete)(':id/tsd-activation-code'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "clearTsdActivationCode", null);
__decorate([
    (0, common_1.Get)('roles'),
    (0, require_permissions_decorator_1.RequirePermissions)('users:read'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "listRoles", null);
exports.UsersController = UsersController = __decorate([
    (0, swagger_1.ApiTags)('users'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.Controller)('users'),
    __metadata("design:paramtypes", [users_service_1.UsersService])
], UsersController);
