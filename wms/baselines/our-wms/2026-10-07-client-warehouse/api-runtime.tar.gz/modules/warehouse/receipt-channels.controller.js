"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var ReceiptChannelsController_1;
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceiptChannelsController = void 0;
const core_1 = require("@nestjs/core");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const common_1 = require("@nestjs/common");
const exceljs_1 = __importDefault(require("exceljs"));
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_2 = require("../auth/decorators/require-permissions.decorator");
const client_scope_service_1 = require("../auth/client-scope.service");
const receipt_channel_policy_1 = require("./receipt-channel-policy");
let ReceiptChannelsController = ReceiptChannelsController_1 = class ReceiptChannelsController {
    prisma;
    scopes;
    modules;
    logger = new common_1.Logger(ReceiptChannelsController_1.name);
    constructor(prisma, scopes, modules) {
        this.prisma = prisma;
        this.scopes = scopes;
        this.modules = modules;
    }
    async list(user, clientId, from, to) {
        if (typeof clientId !== 'string' || !clientId.trim())
            throw new common_1.BadRequestException('Выберите клиента.');
        this.scopes.requireClientAccess(user, clientId, 'read');
        const warehouseIds = await this.readWarehouses(user, clientId);
        if (!(0, receipt_channel_policy_1.receiptChannelsEnabled)())
            return { enabled: false, rows: [] };
        const since = from && /^\d{4}-\d{2}-\d{2}$/.test(from) ? new Date(from + 'T00:00:00+03:00') : new Date(Date.now() - 30 * 86400000);
        const until = to && /^\d{4}-\d{2}-\d{2}$/.test(to) ? new Date(to + 'T23:59:59+03:00') : new Date();
        if (!Number.isFinite(since.getTime()) || !Number.isFinite(until.getTime()) || since > until)
            throw new common_1.BadRequestException('Проверьте период приёмок.');
        const [groups, saved] = await Promise.all([Promise.all(warehouseIds.map(w => (0, receipt_channel_policy_1.receiptDocuments)(this.prisma, clientId, w, since))), this.prisma.systemSetting.findMany({ where: { key: { startsWith: `receipt.channels.v1:${clientId}:` } }, select: { value: true } })]);
        const docs = groups.flat(), approvals = (await Promise.all(warehouseIds.map(w => (0, receipt_channel_policy_1.receiptApprovalEntries)(this.prisma, clientId, w, docs)))).flat();
        const approvalById = new Map(approvals.map(a => [a.doc.id, a.approval]));
        const rules = new Map(saved.map(s => { const r = s.value; return [r.id, r]; }));
        return { enabled: true, canManageDirections: user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)), rows: docs.filter(d => d.current || new Date(d.date) <= until).map(d => ({ ...d, approvalEnabled: approvalById.has(d.id), approval: approvalById.get(d.id) ?? { available: true, revision: 0 }, fbs: rules.get(d.id)?.fbs ?? true, fbo: rules.get(d.id)?.fbo ?? true, revision: rules.get(d.id)?.revision ?? 0 })) };
    }
    // FIX: the client can confirm only its own receipt; disabling remains an administrator action.
    async approval(user, body) {
        if (!body || typeof body.clientId !== 'string' || typeof body.warehouseId !== 'string' || typeof body.id !== 'string' || !/^[a-f0-9]{32}$/.test(body.id) || typeof body.save !== 'boolean')
            throw new common_1.BadRequestException('Укажите клиента, филиал и приёмку.');
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        if (!(await this.readWarehouses(user, body.clientId)).includes(body.warehouseId))
            throw new common_1.ForbiddenException('Нет доступа к приёмке этого филиала.');
        if (user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)))
            (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        const result = await this.prisma.$transaction(tx => (0, receipt_channel_policy_1.changeReceiptApproval)(tx, body, user, body.save), { isolationLevel: body.save ? 'ReadCommitted' : 'RepeatableRead', timeout: 60000 });
        if (body.save)
            this.refresh(body.clientId);
        return result;
    }
    async history(user, clientId, warehouseId, id) {
        await this.readReceipt(user, clientId, warehouseId, id);
        return this.prisma.auditLog.findMany({ where: { entity: 'Receipt', entityId: id, action: 'RECEIPT_STOCK_ACCESS_CHANGED', AND: [{ payload: { path: ['clientId'], equals: clientId } }, { payload: { path: ['warehouseId'], equals: warehouseId } }] }, select: { createdAt: true, payload: true }, orderBy: { createdAt: 'desc' }, take: 100 });
    }
    async file(user, clientId, warehouseId, id, response) {
        const doc = await this.readReceipt(user, clientId, warehouseId, id);
        const boxes = new Map(doc.boxes.map(b => [b.id, b.code]));
        const rows = await this.prisma.stockMovement.findMany({ where: { clientId, warehouseId, type: 'RECEIPT', quantity: { gt: 0 }, OR: doc.boxes.map(b => ({ boxId: b.id, sourceDocument: b.receiptDocument?.startsWith('BOX:') ? null : b.receiptDocument })), createdAt: { gte: new Date(doc.date.slice(0, 4) + '-01-01T00:00:00Z'), lt: new Date((Number(doc.date.slice(0, 4)) + 1) + '-01-01T00:00:00Z') } }, include: { sku: { include: { barcodes: true } } }, orderBy: { createdAt: 'asc' } });
        const workbook = new exceljs_1.default.Workbook(), sheet = workbook.addWorksheet('Приёмка');
        sheet.columns = [{ header: 'Дата приёмки (МСК)', key: 'date', width: 23 }, { header: 'Короб', key: 'box', width: 24 }, { header: 'Товар', key: 'name', width: 45 }, { header: 'Артикул', key: 'article', width: 28 }, { header: 'Размер', key: 'size', width: 16 }, { header: 'Штрихкод', key: 'barcode', width: 20 }, { header: 'Принято, шт.', key: 'quantity', width: 16 }];
        for (const r of rows)
            sheet.addRow({ date: r.createdAt.toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' }), box: boxes.get(r.boxId), name: r.sku.name, article: r.sku.article, size: r.sku.size, barcode: r.sku.barcodes[0]?.value ?? '', quantity: r.quantity });
        sheet.getRow(1).font = { bold: true };
        sheet.views = [{ state: 'frozen', ySplit: 1 }];
        response.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        response.setHeader('Content-Disposition', `attachment; filename="receipt-${id}.xlsx"`);
        response.send(Buffer.from(await workbook.xlsx.writeBuffer()));
    }
    async readWarehouses(user, clientId) {
        if (user.activeWarehouseId)
            return [user.activeWarehouseId];
        if (user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)))
            throw new common_1.BadRequestException('Выберите филиал.');
        if (!(0, receipt_channel_policy_1.receiptApprovalEnabled)())
            return [];
        const scopes = await this.prisma.systemSetting.findMany({ where: { key: { startsWith: `receipt.approval.scope.v1:${clientId}:` } }, select: { value: true } });
        return scopes.map(s => String(s.value.warehouseId));
    }
    async readReceipt(user, clientId, warehouseId, id) {
        if (!clientId || !warehouseId || !id)
            throw new common_1.BadRequestException('Укажите приёмку.');
        this.scopes.requireClientAccess(user, clientId, 'read');
        if (!(await this.readWarehouses(user, clientId)).includes(warehouseId))
            throw new common_1.ForbiddenException('Нет доступа к филиалу.');
        const doc = (await (0, receipt_channel_policy_1.receiptDocuments)(this.prisma, clientId, warehouseId)).find(d => d.id === id);
        if (!doc)
            throw new common_1.NotFoundException('Приёмка не найдена.');
        return doc;
    }
    async assign(user, body) {
        if (!body || typeof body.clientId !== 'string' || typeof body.id !== 'string' || typeof body.boxCode !== 'string' || !body.boxCode.trim() || typeof body.save !== 'boolean')
            throw new common_1.BadRequestException('Укажите приёмку и короб.');
        const warehouseId = (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        const result = await this.prisma.$transaction(tx => (0, receipt_channel_policy_1.assignReceiptBox)(tx, body.clientId, warehouseId, body.id, body.boxCode, user.id, body.save), { isolationLevel: 'Serializable', timeout: 30000 });
        if (body.save)
            this.refresh(body.clientId);
        return result;
    }
    preview(user, body) { return this.change(user, body, false); }
    save(user, body) { return this.change(user, body, true); }
    async change(user, body, save) {
        if (!body || typeof body.clientId !== 'string' || !body.clientId.trim() || typeof body.id !== 'string' || !/^[a-f0-9]{32}$/.test(body.id))
            throw new common_1.BadRequestException('Укажите клиента и приёмку.');
        const warehouseId = (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        const result = await this.prisma.$transaction(async (tx) => {
            // FIX: serialize policy changes with each other; serializable scans retry stale reads.
            if (save)
                await tx.$executeRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))', `receipt-channels:${body.clientId}:${warehouseId}`);
            return (0, receipt_channel_policy_1.receiptChannelChange)(tx, body.clientId, warehouseId, body.id, body.fbs, body.fbo, body.revision, save, user.id);
        }, { isolationLevel: save ? 'Serializable' : 'RepeatableRead', timeout: 30000 });
        if (save)
            this.refresh(body.clientId);
        return result;
    }
    refresh(clientId) {
        // FIX: schedule recalculation immediately; the existing periodic stock sync retries failures.
        // FIX: a failed background sync must not misreport a committed save as failed.
        void Promise.resolve().then(() => this.modules.get(marketplace_connections_service_1.MarketplaceConnectionsService, { strict: false }).refreshReceiptChannelStocks(clientId))
            .catch(() => this.logger.warn(`Receipt directions saved for ${clientId}; periodic WB stock synchronization will retry.`));
    }
};
exports.ReceiptChannelsController = ReceiptChannelsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('from')),
    __param(3, (0, common_1.Query)('to')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('approval'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "approval", null);
__decorate([
    (0, common_1.Get)('history'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('warehouseId')),
    __param(3, (0, common_1.Query)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "history", null);
__decorate([
    (0, common_1.Get)('file.xlsx'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('warehouseId')),
    __param(3, (0, common_1.Query)('id')),
    __param(4, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "file", null);
__decorate([
    (0, common_1.Post)('assign-box'),
    (0, require_permissions_decorator_2.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "assign", null);
__decorate([
    (0, common_1.Post)('preview'),
    (0, require_permissions_decorator_2.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ReceiptChannelsController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_2.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ReceiptChannelsController.prototype, "save", null);
exports.ReceiptChannelsController = ReceiptChannelsController = ReceiptChannelsController_1 = __decorate([
    (0, common_1.Controller)('warehouse/receipt-channels'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('warehouse:read', 'stock:read', 'client-requests:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof core_1.ModuleRef !== "undefined" && core_1.ModuleRef) === "function" ? _c : Object])
], ReceiptChannelsController);
