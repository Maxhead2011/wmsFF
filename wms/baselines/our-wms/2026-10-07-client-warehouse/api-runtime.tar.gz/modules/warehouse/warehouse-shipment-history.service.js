"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WarehouseShipmentHistoryService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const shipped_kiz_history_1 = require("../../common/shipment-history/shipped-kiz-history");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
let WarehouseShipmentHistoryService = class WarehouseShipmentHistoryService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    async list(filter, user) {
        const clientId = filter.clientId?.trim();
        const search = filter.search?.trim();
        const periodFrom = optionalDate(filter.periodFrom, false);
        const periodTo = optionalDate(filter.periodTo, true);
        const warehouseId = resolveScopedWarehouseId(user, 'read');
        return this.prisma.shippedKizHistory.findMany({
            where: {
                clientId: this.clientScopes.resolveClientFilter(user, clientId || undefined),
                ...(warehouseId ? { warehouseId } : {}),
                shippedAt: periodFrom || periodTo
                    ? {
                        gte: periodFrom,
                        lte: periodTo,
                    }
                    : undefined,
                ...(search
                    ? {
                        OR: [
                            { kiz: { contains: search, mode: 'insensitive' } },
                            { orderId: { contains: search, mode: 'insensitive' } },
                            { internalSku: { contains: search, mode: 'insensitive' } },
                            { barcode: { contains: search, mode: 'insensitive' } },
                            { productName: { contains: search, mode: 'insensitive' } },
                            { sourceBoxCode: { contains: search, mode: 'insensitive' } },
                        ],
                    }
                    : {}),
            },
            orderBy: { shippedAt: 'desc' },
            take: 1000,
        });
    }
    async sync(user, clientIdValue) {
        const clientId = clientIdValue?.trim();
        const clientFilter = this.clientScopes.resolveClientFilter(user, clientId || undefined);
        const warehouseId = resolveScopedWarehouseId(user, 'write');
        const requests = await this.prisma.clientRequest.findMany({
            where: {
                clientId: clientFilter,
                status: client_1.ClientRequestStatus.DONE,
                ...(warehouseId ? { warehouseId } : {}),
            },
            select: { id: true, updatedAt: true },
            orderBy: { updatedAt: 'desc' },
            take: 5000,
        });
        let added = 0;
        for (const request of requests) {
            added += await this.prisma.$transaction((tx) => (0, shipped_kiz_history_1.captureShippedKizHistory)(tx, request.id, request.updatedAt));
        }
        return { checkedRequests: requests.length, added };
    }
};
exports.WarehouseShipmentHistoryService = WarehouseShipmentHistoryService;
exports.WarehouseShipmentHistoryService = WarehouseShipmentHistoryService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], WarehouseShipmentHistoryService);
function resolveScopedWarehouseId(user, access) {
    if (user.permissionCodes.includes('system:admin') ||
        user.roleCodes.includes('CLIENT') ||
        (!user.roleCodes.includes('BRANCH_MANAGER') && (user.warehouseIds?.length ?? 0) === 0)) {
        return null;
    }
    const warehouseId = user.activeWarehouseId?.trim() || null;
    const allowedWarehouseIds = access === 'write' ? user.writableWarehouseIds : user.warehouseIds;
    if (!warehouseId || !(allowedWarehouseIds ?? []).includes(warehouseId)) {
        throw new common_1.ForbiddenException(access === 'write'
            ? 'Выберите доступный для изменения активный филиал.'
            : 'Выберите доступный активный филиал.');
    }
    return warehouseId;
}
function optionalDate(value, endOfDay) {
    if (!value?.trim())
        return undefined;
    const parsed = new Date(`${value.trim()}T${endOfDay ? '23:59:59.999' : '00:00:00.000'}Z`);
    if (Number.isNaN(parsed.getTime()))
        throw new common_1.BadRequestException('Некорректный период истории.');
    return parsed;
}
