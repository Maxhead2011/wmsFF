"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorageLocationsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const storage_locations_service_1 = require("./storage-locations.service");
let StorageLocationsController = class StorageLocationsController {
    storage;
    constructor(storage) {
        this.storage = storage;
    }
    list(user, warehouseId, query, sync) {
        return this.storage.listLayout(warehouseId, query, sync !== 'false', user);
    }
    syncGoogle(body, user) {
        return this.storage.syncGoogleSheet(typeof body.warehouseId === 'string' ? body.warehouseId : user.activeWarehouseId || undefined, true, typeof body.clientId === 'string' ? body.clientId : undefined, user);
    }
    createZone(body, user) {
        return this.storage.createZone(body, user);
    }
    deleteZone(id, user) {
        return this.storage.deleteZone(id, user);
    }
    createPallet(body, user) {
        return this.storage.createPallet(body, user);
    }
    updatePallet(id, body, user) {
        return this.storage.updatePallet(id, body, user);
    }
    deletePallet(id, user) {
        return this.storage.deletePallet(id, user);
    }
    deletePallets(body, user) {
        return this.storage.deletePallets(body, user);
    }
    clearPallet(id, user) {
        return this.storage.clearPallet(id, user);
    }
    addBox(id, body, user) {
        return this.storage.addBox(id, body, user);
    }
    relocateBox(body, user) {
        return this.storage.relocateBox(body, user);
    }
    removeBox(id, boxCode, user) {
        return this.storage.removeBox(id, boxCode, user);
    }
};
exports.StorageLocationsController = StorageLocationsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('warehouseId')),
    __param(2, (0, common_1.Query)('query')),
    __param(3, (0, common_1.Query)('sync')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('sync-google'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "syncGoogle", null);
__decorate([
    (0, common_1.Post)('zones'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "createZone", null);
__decorate([
    (0, common_1.Delete)('zones/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "deleteZone", null);
__decorate([
    (0, common_1.Post)('pallets'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "createPallet", null);
__decorate([
    (0, common_1.Patch)('pallets/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "updatePallet", null);
__decorate([
    (0, common_1.Delete)('pallets/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "deletePallet", null);
__decorate([
    (0, common_1.Post)('pallets/bulk-delete'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "deletePallets", null);
__decorate([
    (0, common_1.Post)('pallets/:id/clear'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "clearPallet", null);
__decorate([
    (0, common_1.Post)('pallets/:id/boxes'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "addBox", null);
__decorate([
    (0, common_1.Post)('pallets/boxes/relocate'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "relocateBox", null);
__decorate([
    (0, common_1.Delete)('pallets/:id/boxes/:boxCode'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('boxCode')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], StorageLocationsController.prototype, "removeBox", null);
exports.StorageLocationsController = StorageLocationsController = __decorate([
    (0, swagger_1.ApiTags)('storage-locations'),
    (0, common_1.Controller)('warehouse/storage-locations'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:read'),
    __metadata("design:paramtypes", [storage_locations_service_1.StorageLocationsService])
], StorageLocationsController);
