"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadFboRoutePreference = loadFboRoutePreference;
exports.orderFboRequestBoxes = orderFboRequestBoxes;
// FIX: opt-in per request; a stale preference cannot follow a changed composition or warehouse.
async function loadFboRoutePreference(db, request, compositionHash) {
    const setting = await db.systemSetting.findUnique({ where: { key: `fbo.route.${request.id}` } });
    const value = setting?.value;
    if (!value || value.version !== 1 || value.id !== request.id || value.clientId !== request.clientId
        || value.warehouseId !== request.warehouseId || value.compositionHash !== compositionHash
        || !Array.isArray(value.preferredBoxIds) || !value.preferredBoxIds.every(id => typeof id === 'string'))
        return null;
    return new Set(value.preferredBoxIds);
}
// FIX: order only authorized, non-busy candidates against current unpicked demand.
// The caller retains physical mark checks, local pallet context and all stock mutations.
function orderFboRequestBoxes(boxes, demand, decide, preferred) {
    const remaining = { ...demand }, pending = [...boxes], result = [];
    const useful = (box) => {
        const available = {};
        for (const b of box.balances)
            if (b.status === 'AVAILABLE' && b.quantity > 0)
                available[b.skuId] = (available[b.skuId] ?? 0) + b.quantity;
        return Object.entries(available).reduce((sum, [sku, qty]) => sum + Math.min(qty, remaining[sku] ?? 0), 0);
    };
    const recent = (a, b) => Number(preferred.has(b.id)) - Number(preferred.has(a.id));
    const consume = (box) => {
        result.push(box);
        pending.splice(pending.indexOf(box), 1);
        for (const b of box.balances)
            if (b.status === 'AVAILABLE' && b.quantity > 0)
                remaining[b.skuId] = Math.max(0, (remaining[b.skuId] ?? 0) - b.quantity);
    };
    for (;;) {
        const whole = pending.filter(box => useful(box) > 0 && decide(box, remaining).allowed);
        if (!whole.length)
            break;
        whole.sort((a, b) => recent(a, b) || useful(b) - useful(a) || a.code.localeCompare(b.code));
        consume(whole[0]);
    }
    while (pending.length) {
        pending.sort((a, b) => useful(b) - useful(a) || recent(a, b) || a.code.localeCompare(b.code));
        if (useful(pending[0]) === 0)
            break;
        consume(pending[0]);
    }
    return [...result, ...pending];
}

// FIX: lifetime is one snapshot; stock and KIZ inputs cannot change inside this pure route loop.
exports.cacheFboBoxDecision = cacheFboBoxDecision;
function cacheFboBoxDecision(decide) {
 if (process.env.WMS_FBO_PLAN_COALESCE_ENABLED !== 'true') return decide;
 const cache = new WeakMap();
 return (box, remaining) => {
  const previous = cache.get(box);
  const keys = previous?.keys ?? [...new Set(box.balances.map(b => b.skuId))];
  if (previous && keys.every((key, i) => Object.is(remaining[key], previous.values[i]))) return previous.result;
  const result = decide(box, remaining);
  cache.set(box, { keys, values: keys.map(key => remaining[key]), result });
  return result;
 };
}
