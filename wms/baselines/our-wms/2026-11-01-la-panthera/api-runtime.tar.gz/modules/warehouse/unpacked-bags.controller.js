const {storageChargeBlocks}=require('./storage-charge-period');
'use strict';
const C=require('@nestjs/common'),{randomUUID,createHash}=require('crypto');
const {PrismaService}=require('../../common/prisma/prisma.service');
const {ClientScopeService}=require('../auth/client-scope.service');
const {WarehouseService}=require('./warehouse.service');
const {CurrentUser}=require('../auth/decorators/current-user.decorator');
const {RequirePermissions}=require('../auth/decorators/require-permissions.decorator');
const {runBillingMutation}=require('../billing/billing-mutation');
const S=require('./unpacked-bag-storage');
const bad=m=>{throw new C.BadRequestException(m);};
function integer(n,max){if(!Number.isSafeInteger(n)||n<1||n>max)bad('Укажите целое количество мешков в пределах остатка.');return n;}
function date(d){if(typeof d!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d)||!Number.isFinite(Date.parse(d))||new Date(d).toISOString().slice(0,10)!==d||d>new Date().toISOString().slice(0,10))bad('Нужна корректная дата, не позже сегодняшней.');return d;}
class UnpackedBagsController{
 constructor(db,scopes,warehouse){this.db=db;this.scopes=scopes;this.warehouse=warehouse;}
 check(id,user,write=false){
  if(user.isDemo)throw new C.NotFoundException();
  this.scopes.requireClientAccess(user,id,write?'write':'read');
  if(write&&(user.roleCodes.includes('CLIENT')||!user.permissionCodes.some(p=>['warehouse:write','system:admin'].includes(p))))throw new C.ForbiddenException();
  const branch=write?this.warehouse.resolveWriteWarehouseId(user):this.warehouse.resolveReadWarehouseId(user);
  if(!branch&&!user.roleCodes.includes('CLIENT'))bad('Выберите филиал.');return branch;
 }
 async get(id,user){
  const branch=this.check(id,user),records=await S.states(this.db,id);
  const arrivals=await this.db.auditLog.findMany({where:{entity:'goods-arrival',entityId:id,action:'warehouse.goods-arrival'},select:{id:true,payload:true},orderBy:{createdAt:'desc'},take:5000});
  return {litersPerBag:480,rows:arrivals.filter(a=>a.payload?.status!=='CANCELLED'&&a.payload?.bagCount>0&&(!branch||a.payload.warehouseId===branch)).map(a=>({id:a.id,arrivalDate:a.payload.arrivalDate,bagCount:a.payload.bagCount,comment:a.payload.comment||'',state:records.find(s=>s.arrivalId===a.id)||null}))};
 }
 async save(id,dto,user){
  const warehouseId=this.check(id,user,true);
  if(!dto||typeof dto.operationKey!=='string'||!/^[a-zA-Z0-9:-]{8,100}$/.test(dto.operationKey))bad('Обновите форму и повторите действие.');
  const hash=createHash('sha256').update(JSON.stringify([id,warehouseId,dto])).digest('hex');
  await runBillingMutation(this.db,async db=>{
   const prior=await db.auditLog.findUnique({where:{id:dto.operationKey}});
   if(prior){if(prior.entity!=='UnpackedBags'||prior.entityId!==id||prior.payload?.hash!==hash)bad('Ключ операции уже использован.');return;}
   const arrival=await db.auditLog.findUnique({where:{id:dto.arrivalId}}),p=arrival?.payload;
   if(arrival?.entity!=='goods-arrival'||arrival.entityId!==id||p?.clientId!==id||p.status==='CANCELLED'||p.warehouseId!==warehouseId)bad('Приход не найден в выбранном клиенте и филиале.');
   const setting=await db.systemSetting.findUnique({where:{key:S.key(arrival.id)}});
   let state=setting?.value?structuredClone(setting.value):null;
   if((state?.revision||0)!==dto.revision)bad('Учёт уже изменился. Обновите данные.');
   let affectedFrom=dto.action==='COMPLETE'?new Date(S.end(date(dto.completedDate)).getTime()+1).toISOString().slice(0,10):p.arrivalDate;
   const charges=await db.billingCharge.findMany({where:{clientId:id,source:'STORAGE',status:{not:'CANCELLED'}},select:{metadata:true,sourceKey:true}});
   if(dto.action==='ENABLE'){
    if(state)bad('Учёт уже включён.');
    state={version:1,revision:0,arrivalId:arrival.id,clientId:id,warehouseId,arrivalDate:date(p.arrivalDate),initialBagCount:integer(dto.bagCount,p.bagCount),litersPerBag:480,batches:[]};
   }else{
    if(!state)bad('Сначала укажите фактическое число неразобранных мешков.');S.assertState(state);
    if(dto.action==='START'){
     const remaining=state.initialBagCount-state.batches.reduce((n,b)=>n+b.bagCount,0),count=integer(dto.bagCount,remaining);
     const boxCodes=typeof dto.boxCodes==='string'?[...new Set(dto.boxCodes.split(/[\s,;]+/).filter(Boolean))]:[];
     if(!boxCodes.length||boxCodes.length>200||boxCodes.some(c=>c.length>150))bad('Укажите от 1 до 200 кодов коробов для этой партии.');
     const all=await db.systemSetting.findMany({where:{key:{startsWith:S.PREFIX}},select:{value:true}});
     if(all.some(s=>s.value?.batches?.some(b=>b.boxCodes.some(c=>boxCodes.includes(c)))))bad('Один из коробов уже связан с разбором мешков.');
     const boxes=await db.box.findMany({where:{code:{in:boxCodes}},select:{clientId:true,warehouseId:true,status:true}});
     if(boxes.some(b=>b.clientId!==id||b.warehouseId!==warehouseId||['deleted','archived'].includes(b.status)))bad('Короб принадлежит другому клиенту, филиалу или удалён.');
     const existingLedger=await db.stockMovement.findMany({where:{box:{code:{in:boxCodes}}},select:{createdAt:true}});
     affectedFrom=existingLedger.length?new Date(Math.min(...existingLedger.map(m=>m.createdAt.getTime()))+86400000).toISOString().slice(0,10):'9999-12-31';
     state.batches.push({id:randomUUID(),bagCount:count,boxCodes,startedAt:new Date().toISOString(),completedDate:null});
    }else if(dto.action==='COMPLETE'){
     const batch=state.batches.find(b=>b.id===dto.batchId);if(!batch||batch.completedDate)bad('Партия уже разобрана или не найдена.');
     const completedDate=date(dto.completedDate);if(completedDate<state.arrivalDate)bad('Разбор не может быть раньше прихода.');
     const boxes=await db.box.findMany({where:{code:{in:batch.boxCodes}},select:{code:true,clientId:true,warehouseId:true,status:true}});
     if(boxes.length!==batch.boxCodes.length||boxes.some(b=>b.clientId!==id||b.warehouseId!==warehouseId||b.status!=='active'))bad('Сначала примите и закройте все связанные короба.');
     const ledger=await db.stockMovement.findMany({where:{box:{code:{in:batch.boxCodes}}},include:{box:{select:{code:true}},sku:true}});
     if(batch.boxCodes.some(code=>!ledger.some(m=>m.box.code===code&&S.relevant(m)&&m.quantity>0)))bad('В каждом коробе должен быть принятый товар.');
     if(ledger.some(m=>S.relevant(m)&&m.createdAt>S.end(completedDate)))bad('Дата завершения раньше приёмки товара в связанных коробах.');
     if(ledger.some(m=>S.relevant(m)&&!(Number(m.sku.volumeLiters)>0||Number(m.sku.lengthCm)*Number(m.sku.widthCm)*Number(m.sku.heightCm)>0)))bad('Заполните объём или габариты фактического товара.');
     batch.completedDate=completedDate;batch.completedAt=completedDate===new Date().toISOString().slice(0,10)?new Date().toISOString():S.end(completedDate).toISOString();
    }else bad('Неизвестное действие.');
   }
   if(charges.some(c=>storageChargeBlocks(c,id,affectedFrom)))bad('За этот период уже есть начисление хранения. Сначала отмените или пересчитайте его в биллинге, чтобы сохранить согласованность истории.');
   // Validate history before persisting: moved/foreign stock cannot be silently suppressed.
   const codes=state.batches.flatMap(b=>b.boxCodes),ledger=codes.length?await db.stockMovement.findMany({where:{box:{code:{in:codes}}},include:{box:{select:{code:true}},sku:true}}):[];
   S.sourceRows(state,ledger,new Date('9999-12-31'));
   state.revision++;state.updatedAt=new Date().toISOString();
   await db.systemSetting.upsert({where:{key:S.key(arrival.id)},create:{key:S.key(arrival.id),value:state,updatedByUserId:user.id},update:{value:state,updatedByUserId:user.id}});
   await db.auditLog.create({data:{id:dto.operationKey,userId:user.id,entity:'UnpackedBags',entityId:id,action:'UNPACKED_BAGS_'+dto.action,payload:{hash,arrivalId:arrival.id,warehouseId,revision:state.revision,bagCount:state.initialBagCount,batchId:dto.batchId||null}}});
  });
  return this.get(id,user);
 }
}
Reflect.defineMetadata('design:paramtypes',[PrismaService,ClientScopeService,WarehouseService],UnpackedBagsController);
C.Controller('warehouse/unpacked-bags/:clientId')(UnpackedBagsController);RequirePermissions('warehouse:read')(UnpackedBagsController);
for(const [name,method] of [['get',C.Get],['save',C.Post]]){const d=Object.getOwnPropertyDescriptor(UnpackedBagsController.prototype,name);method()(UnpackedBagsController.prototype,name,d);C.Param('clientId')(UnpackedBagsController.prototype,name,0);if(name==='save'){C.Body()(UnpackedBagsController.prototype,name,1);CurrentUser()(UnpackedBagsController.prototype,name,2);RequirePermissions('warehouse:write')(UnpackedBagsController.prototype,name,d);}else CurrentUser()(UnpackedBagsController.prototype,name,1);}
module.exports={UnpackedBagsController};
