"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cargoPickupEnabled = void 0;
exports.cargoPickupInput = cargoPickupInput;
const common_1 = require("@nestjs/common");
const cargoPickupEnabled = () => process.env.WMS_CARGO_PICKUP_ENABLED === 'true';
exports.cargoPickupEnabled = cargoPickupEnabled;
// FIX: legacy arrivals never acquire an implicit delivery charge.
function cargoPickupInput(dto) {
    if (!(0, exports.cargoPickupEnabled)()) {
        if (dto.ourDelivery !== undefined || dto.deliveryCostRub !== undefined) {
            throw new common_1.BadRequestException('Учёт забора с карго не включён.');
        }
        return {};
    }
    if (dto.ourDelivery !== undefined && typeof dto.ourDelivery !== 'boolean') {
        throw new common_1.BadRequestException('Выберите вид доставки.');
    }
    if (dto.ourDelivery !== true)
        return { ourDelivery: false, deliveryCostRub: null };
    const cost = dto.deliveryCostRub;
    if (typeof cost !== 'number' || !Number.isFinite(cost) || cost <= 0 || cost > 10000000 || Math.abs(cost * 100 - Math.round(cost * 100)) > 0.000001) {
        throw new common_1.BadRequestException('Укажите стоимость доставки в рублях, не более двух знаков после запятой.');
    }
    return { ourDelivery: true, deliveryCostRub: cost };
}
