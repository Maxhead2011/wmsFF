'use strict';
const {BadRequestException}=require('@nestjs/common');
const PREFIX='storage.unpacked-bags.v1:';
const DAY=86400000;
const key=id=>PREFIX+id;
const relevant=m=>!['PICK','PACK','MOVE'].includes(m.type)&&(m.type!=='SHIP'||m.quantity<0)&&m.quantity!==0;
const end=date=>new Date(date+'T23:59:59.999Z');
function skuFor(s){return {id:'unpacked-bags:'+s.arrivalId,internalSku:'BAGS-'+s.arrivalDate,name:'Неразобранные мешки · '+s.arrivalDate,volumeLiters:480,lengthCm:null,widthCm:null,heightCm:null,size:'мешок 480 л',barcodes:[],article:null,clientSku:null,marketplaceOfferId:null,marketplaceProductId:null};}
function assertState(s){if(s?.version!==1||!s.clientId||!s.warehouseId||!s.arrivalId||!/^\d{4}-\d{2}-\d{2}$/.test(s.arrivalDate)||!Number.isSafeInteger(s.initialBagCount)||s.initialBagCount<1||!Array.isArray(s.batches)||s.batches.some(b=>!b.id||!Number.isSafeInteger(b.bagCount)||b.bagCount<1||!Array.isArray(b.boxCodes)||!b.boxCodes.length||b.boxCodes.some(c=>typeof c!=='string'||!c)||b.completedDate&&(!/^\d{4}-\d{2}-\d{2}$/.test(b.completedDate)||b.completedDate<s.arrivalDate))||s.batches.reduce((n,b)=>n+b.bagCount,0)>s.initialBagCount)throw new BadRequestException('Повреждена история неразобранных мешков. Нужна проверка.');}
async function states(db,clientId){const rows=await db.systemSetting.findMany({where:{key:{startsWith:PREFIX}},select:{value:true}});return rows.map(r=>r.value).filter(s=>s?.clientId===clientId).map(s=>(assertState(s),s));}
function sourceRows(s,ledger,to,now=new Date()){
 assertState(s);const sku=skuFor(s),movements=[],suppressedBoxCodes=new Set();
 const emit=(quantity,createdAt,extra={})=>{if(createdAt<=to)movements.push({skuId:sku.id,warehouseId:s.warehouseId,type:'INVENTORY_ADJUSTMENT',status:'AVAILABLE',quantity,createdAt,sku,...extra});};
 // Native storage bills opening stock. Put the arrival before that day's opening.
 emit(s.initialBagCount,new Date(new Date(s.arrivalDate+'T00:00:00Z').getTime()-1));
 for(const b of s.batches){
  const cutoff=b.completedDate?end(b.completedDate):null;
  if(!cutoff||cutoff>=new Date(now.toISOString().slice(0,10)+'T00:00:00Z'))for(const code of b.boxCodes)suppressedBoxCodes.add(code);
  if(cutoff)emit(-b.bagCount,cutoff);
  const rows=ledger.filter(m=>b.boxCodes.includes(m.box?.code)&&(!cutoff||m.createdAt<=cutoff));
  if(rows.some(m=>m.clientId!==s.clientId||m.warehouseId!==s.warehouseId||m.createdAt<new Date(s.arrivalDate+'T00:00:00Z')))throw new BadRequestException('Короба разбора содержат постороннюю историю. Нужна проверка связи с приходом.');
  if(rows.some(m=>['PICK','PACK','MOVE','SHIP'].includes(m.type)&&(!b.completedAt||m.createdAt<new Date(b.completedAt))))throw new BadRequestException('Товар перемещали или отгружали до завершения разбора мешков. Проверьте дату завершения и короба.');
  const released=new Map();
  for(const m of rows.filter(relevant)){
   emit(-m.quantity,m.createdAt,{skuId:m.skuId,status:m.status,sku:m.sku});
   const k=m.skuId+':'+m.status,old=released.get(k);released.set(k,{...m,quantity:(old?.quantity||0)+m.quantity});
  }
  if(cutoff)for(const m of released.values())emit(m.quantity,cutoff,{skuId:m.skuId,status:m.status,sku:m.sku});
 }
 const today=now.toISOString().slice(0,10),quantity=s.arrivalDate>today?0:s.initialBagCount-s.batches.filter(b=>b.completedDate&&b.completedDate<today).reduce((n,b)=>n+b.bagCount,0);
 return {movements,sku,balance:{skuId:sku.id,quantity,box:null,pallet:null},suppressedBoxCodes};
}
async function unpackedBagStorageSources(db,clientId,to){
 const records=await states(db,clientId),codes=[...new Set(records.flatMap(s=>s.batches.flatMap(b=>b.boxCodes)))];
 const ledger=codes.length?await db.stockMovement.findMany({where:{box:{code:{in:codes}},createdAt:{lte:to}},include:{box:{select:{code:true}},sku:true},orderBy:[{createdAt:'asc'},{id:'asc'}]}):[];
 const result={movements:[],skus:[],balances:[],suppressedBoxCodes:new Set()};
 for(const s of records){const r=sourceRows(s,ledger,to);result.movements.push(...r.movements);result.skus.push(r.sku);result.balances.push(r.balance);for(const c of r.suppressedBoxCodes)result.suppressedBoxCodes.add(c);}
 return result;
}
module.exports={PREFIX,key,states,sourceRows,unpackedBagStorageSources,relevant,end,assertState};
