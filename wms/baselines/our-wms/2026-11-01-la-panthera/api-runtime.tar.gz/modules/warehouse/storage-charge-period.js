'use strict';
// Legacy storage charges have canonical source keys even when tax-only metadata
// predates period fields. Unknown or conflicting provenance must still block edits.
function validDate(s){return typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(Date.parse(s))&&new Date(s).toISOString().slice(0,10)===s;}
function storageChargePeriodTo(charge,clientId){
 const m=charge.metadata||{},prefix='storage:'+clientId+':',key=charge.sourceKey;
 let period=null;
 if(typeof key==='string'&&key.startsWith(prefix)){
  const parts=key.slice(prefix.length).split(':');
  if(parts.length===2&&parts.every(validDate)&&parts[0]<=parts[1])period={from:parts[0],to:parts[1]};
  else return null;
 }else if(key)return null;
 if(m.periodFrom!==undefined&&!validDate(m.periodFrom)||m.periodTo!==undefined&&!validDate(m.periodTo))return null;
 if(period){if(m.periodFrom&&m.periodFrom!==period.from||m.periodTo&&m.periodTo!==period.to)return null;return period.to;}
 if(validDate(m.periodTo)&&(!m.periodFrom||m.periodFrom<=m.periodTo))return m.periodTo;
 return null;
}
function storageChargeBlocks(charge,clientId,affectedFrom){const to=storageChargePeriodTo(charge,clientId);return !to||to>=affectedFrom;}
module.exports={storageChargePeriodTo,storageChargeBlocks};
