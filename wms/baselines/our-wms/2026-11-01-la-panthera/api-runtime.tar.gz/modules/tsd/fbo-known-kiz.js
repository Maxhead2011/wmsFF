"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireKnownFboKiz = requireKnownFboKiz;
const common_1 = require("@nestjs/common");
// FIX: source and runtime call this before any recovery, binding or quantity change.
function requireKnownFboKiz(mark) {
    if (process.env.WMS_INVENTORY_FOUND_UNIT_ENABLED === 'true' && !mark)
        throw new common_1.ConflictException('КИЗ не зарегистрирован в WMS. Отбор остановлен. Передайте товар администратору для проверки приёмки и исходного короба.');
}
