"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonLabelControlEnabled = void 0;
exports.ozonLabelReceipt = ozonLabelReceipt;
exports.ozonBoxLabelConfirmed = ozonBoxLabelConfirmed;
exports.confirmOzonBoxLabel = confirmOzonBoxLabel;
const common_1 = require("@nestjs/common");
// FIX: opt-in control applies only to an actual Ozon assembly, not Lamoda/WB.
const ozonLabelControlEnabled = () => process.env.WMS_OZON_LABEL_CONTROL_ENABLED === 'true';
exports.ozonLabelControlEnabled = ozonLabelControlEnabled;
function ozonLabelReceipt(link, box) {
    const supplyId = box.direction && link?.mapping?.[box.direction], op = supplyId && link?.operations?.[supplyId];
    const entries = Object.entries(link?.operations ?? {}).flatMap(([s, v]) => (v.cargoes ?? []).map((c) => ({ ...c, supplyId: s })));
    const matches = entries.filter((c) => c.key === box.id), receipt = matches[0];
    if (!link?.frozenHash || !op || op.state !== 'SUCCESS' || !op.labelUrl || matches.length !== 1 || receipt.supplyId !== supplyId || !/^\d+$/.test(receipt.cargoId) || entries.filter((c) => c.cargoId === receipt.cargoId).length !== 1)
        throw new common_1.ConflictException('Сначала передайте грузоместа и получите стикеры Ozon. Соответствие короба должно быть однозначным.');
    return { supplyId: supplyId, cargoId: receipt.cargoId };
}
function ozonBoxLabelConfirmed(link, box) {
    try {
        const r = ozonLabelReceipt(link, box), check = link.boxLabelChecks?.[box.id];
        return !!box.confirmedAt && !!check?.at && !!check?.userId && check.cargoId === r.cargoId && check.supplyId === r.supplyId && check.frozenHash === link.frozenHash;
    }
    catch {
        return false;
    }
}
async function confirmOzonBoxLabel(tx, shipment, box, barcode, userId) {
    const link = shipment.integration, receipt = ozonLabelReceipt(link, box);
    if (barcode?.trim() !== receipt.cargoId)
        throw new common_1.ConflictException('Стикер Ozon не соответствует этому коробу. Проверьте наклейку и сканируйте правильную пару.');
    const check = { ...receipt, frozenHash: link.frozenHash, at: new Date().toISOString(), userId };
    await tx.ozonFboShipment.update({ where: { requestId: shipment.requestId }, data: { integration: { ...link, boxLabelChecks: { ...link.boxLabelChecks, [box.id]: check } } } });
    await tx.clientRequestEvent.create({ data: { requestId: shipment.requestId, clientId: shipment.clientId ?? shipment.request?.clientId, eventType: 'COMMENT', title: 'Проверена наклейка Ozon на коробе', body: `Короб ${box.boxCode} · стикер ${receipt.cargoId} · поставка ${receipt.supplyId}`, createdByUserId: userId } });
}
