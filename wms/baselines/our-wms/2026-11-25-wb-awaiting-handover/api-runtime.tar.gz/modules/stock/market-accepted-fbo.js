"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.marketFboCompletionEnabled = void 0;
exports.completeMarketAcceptedFbo = completeMarketAcceptedFbo;
const ozon_fbo_directions_1 = require("../tsd/ozon-fbo-directions");
const common_1 = require("@nestjs/common");
const kiz_client_review_1 = require("../../common/kiz-client-review");
const fbo_completion_batch_1 = require("../tsd/fbo-completion-batch");
const marketFboCompletionEnabled = () => process.env.WMS_FBO_MARKET_COMPLETION_ENABLED === 'true';
exports.marketFboCompletionEnabled = marketFboCompletionEnabled;
// FIX: called only after exact marketplace acceptance, under the shipment transaction lock.
async function completeMarketAcceptedFbo(tx, request, user, packageRequest) {
    const assembly = await tx.fboAssembly.findUnique({ where: { requestId: request.id } });
    if (!assembly || assembly.phase === 'COMPLETED')
        return;
    const boxes = await tx.fboAssemblyBox.findMany({ where: { requestId: request.id } });
    const units = await tx.fboAssemblyUnit.findMany({ where: { requestId: request.id, state: { not: 'RETURNED' } } });
    const counts = new Map();
    for (const unit of units) {
        if (unit.state !== 'PACKED')
            throw new common_1.ConflictException('Сдача подтверждена, но есть неупакованные единицы. Требуется сверка состава.');
        counts.set(unit.requestItemId, (counts.get(unit.requestItemId) ?? 0) + 1);
    }
    if (!boxes.length || request.items.some((item) => counts.get(item.id) !== item.quantity) ||
        [...counts.keys()].some(id => !request.items.some((item) => item.id === id))) {
        throw new common_1.ConflictException('Сдача подтверждена, но состав упаковки не совпадает с заявкой.');
    }
    const shipment = await tx.ozonFboShipment.findUnique({ where: { requestId: request.id } });
    if (shipment && (0, ozon_fbo_directions_1.directionProgress)(shipment.directions, boxes, units).some(direction => direction.items.some(item => item.packed !== item.quantity))) {
        throw new common_1.ConflictException('Состав коробов не совпадает с направлениями поставки Ozon.');
    }
    await (0, fbo_completion_batch_1.validateFboPackedBoxes)(tx, request, boxes, units);
    await (0, kiz_client_review_1.assertClientRequestKizShipment)(tx, request, user);
    const packages = (0, fbo_completion_batch_1.fboCompletionPackages)(request, boxes, units);
    await (0, fbo_completion_batch_1.saveFboCompletionSelections)(tx, request, boxes, packages);
    // The persisted packed status can precede actual PACK movements, as in request 3211.
    await tx.clientRequest.update({ where: { id: request.id }, data: { status: 'IN_WORK' } });
    await packageRequest({ requestId: request.id, idempotencyKey: 'fbo-pack:' + request.id,
        boxes: boxes.length, packedUnits: units.length, packages });
    await tx.productMark.updateMany({ where: { id: { in: units.filter((unit) => unit.markId).map((unit) => unit.markId) }, status: 'PACKING' }, data: { status: 'SHIPPING' } });
    await tx.fboAssemblyUnit.updateMany({ where: { requestId: request.id }, data: { activeMarkId: null } });
    await tx.fboAssemblyBox.updateMany({ where: { requestId: request.id }, data: { activeBoxId: null } });
    await tx.fboAssembly.update({ where: { requestId: request.id }, data: { phase: 'COMPLETED' } });
    await tx.auditLog.create({ data: { entity: 'ClientRequest', entityId: request.id,
            action: 'FBO_MARKET_STAGES_COMPLETED',
            payload: { previousPhase: assembly.phase, previousStatus: request.status, packedUnits: units.length, boxes: boxes.length, confirmationSource: 'MARKETPLACE' } } });
}
