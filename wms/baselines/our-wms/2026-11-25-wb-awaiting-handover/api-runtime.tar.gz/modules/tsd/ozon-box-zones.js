"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertOzonBoxZones = assertOzonBoxZones;
const common_1 = require("@nestjs/common");
const client_fulfillment_policy_1 = require("../../common/client-fulfillment-policy");
function assertOzonBoxZones(raw, name, directions, packed, added, clientId = '', enabled = clientId === client_fulfillment_policy_1.palitraClientId) {
    if (!enabled)
        return;
    const skus = new Set([...packed, added]);
    if (skus.size < 2)
        return;
    const link = raw;
    const supply = name && link?.supplies?.find(s => s.id === link.mapping?.[name]);
    const direction = directions.find(d => d.name === name);
    const zones = new Set();
    for (const sku of skus) {
        const barcode = direction?.items.find(i => i.skuId === sku)?.barcode;
        const items = supply ? supply.items.filter(i => i.barcode === barcode) : [];
        const zone = items.length === 1 && items[0].placementZone?.trim();
        if (!zone || /UNKNOWN|UNSPECIFIED|^NONE$/i.test(zone)) {
            throw new common_1.ConflictException('Зона размещения Ozon неизвестна. Обновите состав поставки или выберите короб с одним SKU.');
        }
        zones.add(zone);
    }
    if (zones.size > 1)
        throw new common_1.ConflictException('У товаров разные зоны размещения Ozon. Выберите другой короб.');
}
