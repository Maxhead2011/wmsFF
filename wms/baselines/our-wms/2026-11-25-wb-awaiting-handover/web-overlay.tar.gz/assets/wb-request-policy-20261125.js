// wms/apps/web/src/components/fbs/requestSupplyAction.ts
function requestSupplyOrders(target, orders) {
  const { request, action } = target;
  const linked = orders.filter((order) => order.request?.id === request.id);
  const expected = request.fbsCompletion?.totalOrders;
  if (!linked.length || expected && linked.length !== expected) {
    throw new Error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043F\u043E\u043B\u043D\u044B\u0439 \u0441\u043E\u0441\u0442\u0430\u0432 \u0437\u0430\u044F\u0432\u043A\u0438 FBS.");
  }
  if (linked.some((order) => !["WILDBERRIES", "OZON"].includes(order.marketplace))) {
    throw new Error("\u041F\u0435\u0447\u0430\u0442\u044C \u0441\u0442\u0438\u043A\u0435\u0440\u043E\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0434\u043B\u044F \u0437\u0430\u044F\u0432\u043E\u043A WB \u0438 Ozon.");
  }
  if (action !== "deliver") return linked;
  if (linked.some((order) => order.marketplace !== "WILDBERRIES")) {
    throw new Error("\u042D\u0442\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0430 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u043B\u044F WB.");
  }
  if (!request.fbsCompletion?.completed || linked.some((order) => !order.supplyId || order.supplierStatus !== "confirm")) {
    throw new Error("\u0414\u043B\u044F \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0438 \u0432\u0441\u0435 \u0437\u0430\u043A\u0430\u0437\u044B \u0437\u0430\u044F\u0432\u043A\u0438 \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0441\u043E\u0431\u0440\u0430\u043D\u044B \u0438 \u0433\u043E\u0442\u043E\u0432\u044B \u043A \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0432 WB.");
  }
  const supplyKey = (order) => JSON.stringify([order.connectionId, order.supplyId]);
  const supplies = new Set(linked.map(supplyKey));
  if (orders.some((order) => order.marketplace === "WILDBERRIES" && supplies.has(supplyKey(order)) && order.request?.id !== request.id)) {
    throw new Error("\u0412 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0443 WB \u0432\u0445\u043E\u0434\u044F\u0442 \u0437\u0430\u043A\u0430\u0437\u044B \u0438\u0437 \u0434\u0440\u0443\u0433\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0438. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u043E\u0441\u0442\u0430\u0432 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0438.");
  }
  return linked;
}
function retainFbsClient(current, active, explicit = "") {
  return explicit || current || active[0]?.client.id || "";
}
function requestSupplyNeedsArchive(target) {
  return target.action !== "deliver" || target.request.status === "DONE";
}
function rememberFbsRequestClient(userId, clientId) {
  if (!clientId?.trim()) return;
  const storageKey = `logoff-wms:last-client:${userId}`;
  window.localStorage.setItem(storageKey, clientId);
  window.dispatchEvent(new CustomEvent("logoff-wms:last-client-change", { detail: { storageKey, clientId } }));
}
function fbsDisplayCategory(order) {
  if (order.marketplace === "WILDBERRIES" && order.category === "shipped" && order.supplierStatus === "complete" && order.wbStatus === "waiting" && order.request?.status !== "DONE") return "active";
  return order.category;
}
export {
  fbsDisplayCategory,
  rememberFbsRequestClient,
  requestSupplyNeedsArchive,
  requestSupplyOrders,
  retainFbsClient
};
