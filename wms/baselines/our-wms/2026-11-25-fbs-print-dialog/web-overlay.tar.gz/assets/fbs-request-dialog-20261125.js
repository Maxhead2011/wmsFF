// live-react:react
import { r as R } from "/assets/storage-volume-root-20261109.js";
var react_default = R;
var useState = (...a) => R.useState(...a);
var useEffect = (...a) => R.useEffect(...a);
var useRef = (...a) => R.useRef(...a);

// ../fulfillment-analytics/wms/apps/web/src/components/fbs/FbsRequestActionDialog.tsx
function requestActionExplanation(error) {
  if (error.includes("EXEMPLAR_INFO_NOT_FILLED_COMPLETELY")) return {
    title: "Ozon \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E\u0431 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0430\u0445 \u0442\u043E\u0432\u0430\u0440\u0430",
    detail: error.startsWith("\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 ") ? error.replace(/ Код: EXEMPLAR_INFO_NOT_FILLED_COMPLETELY\.?$/, "") : "Ozon \u043D\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u043B \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0438\u043A\u0435\u0440\u044B: \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043E\u0431 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0430\u0445 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u044B \u043D\u0435 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F \u043A \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C\u0443 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044E.",
    next: "\u0415\u0441\u043B\u0438 \u0413\u0422\u0414 \u0435\u0441\u0442\u044C \u2014 \u0443\u043A\u0430\u0436\u0438\u0442\u0435 \u043D\u043E\u043C\u0435\u0440. \u0415\u0441\u043B\u0438 \u0413\u0422\u0414 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u2014 \u0432 Ozon \u043D\u0443\u0436\u043D\u043E \u044F\u0432\u043D\u043E \u043E\u0442\u043C\u0435\u0442\u0438\u0442\u044C \u0435\u0451 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435. \u041F\u0443\u0441\u0442\u043E\u0435 \u043F\u043E\u043B\u0435 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442 \u044D\u0442\u043E\u0442 \u043F\u0440\u0438\u0437\u043D\u0430\u043A. \u041F\u043E\u0441\u043B\u0435 \u0438\u0441\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043F\u0435\u0447\u0430\u0442\u044C."
  };
  return { title: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435", detail: error, next: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u0440\u0438\u0447\u0438\u043D\u0443 \u0432\u044B\u0448\u0435. \u041F\u043E\u0432\u0442\u043E\u0440\u044F\u0439\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u0435\u0451 \u0443\u0441\u0442\u0440\u0430\u043D\u0435\u043D\u0438\u044F; \u043F\u0440\u0438 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u043C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u0441\u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u043F\u0435\u0447\u0430\u0442\u0438." };
}
function FbsRequestActionDialog({ requestNumber, error, message, onClose }) {
  const ref = useRef(null), [elapsed, setElapsed] = useState(0), explanation = error ? requestActionExplanation(error) : null;
  useEffect(() => {
    const dialog = ref.current;
    dialog.showModal();
    return () => {
      if (dialog.open) dialog.close();
    };
  }, []);
  useEffect(() => {
    if (error) return;
    const timer = window.setInterval(() => setElapsed((s) => s + 1), 1e3);
    return () => window.clearInterval(timer);
  }, [error]);
  return /* @__PURE__ */ react_default.createElement("dialog", { ref, "aria-labelledby": "fbs-request-action-title", onCancel: (event) => {
    event.preventDefault();
    onClose();
  }, style: { border: "1px solid #d6e2e7", borderRadius: 20, padding: 24, width: "min(620px, calc(100vw - 32px))", maxHeight: "85vh", overflow: "auto", color: "#263b49", background: "#fff", boxShadow: "0 18px 65px #0004" } }, /* @__PURE__ */ react_default.createElement("h2", { id: "fbs-request-action-title" }, "\u0421\u0442\u0438\u043A\u0435\u0440\u044B \u0437\u0430\u044F\u0432\u043A\u0438 \u2116", String(requestNumber).padStart(6, "0")), explanation ? /* @__PURE__ */ react_default.createElement("div", { role: "alert" }, /* @__PURE__ */ react_default.createElement("h3", null, explanation.title), /* @__PURE__ */ react_default.createElement("p", { style: { whiteSpace: "pre-wrap" } }, explanation.detail), /* @__PURE__ */ react_default.createElement("p", null, explanation.next), /* @__PURE__ */ react_default.createElement("details", null, /* @__PURE__ */ react_default.createElement("summary", null, "\u0422\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F"), /* @__PURE__ */ react_default.createElement("p", { style: { overflowWrap: "anywhere" } }, error))) : /* @__PURE__ */ react_default.createElement("div", { role: "status", "aria-live": "polite" }, /* @__PURE__ */ react_default.createElement("p", null, message || "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u044E \u0441\u043E\u0441\u0442\u0430\u0432 \u0437\u0430\u044F\u0432\u043A\u0438 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u044E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u0441\u0442\u044C \u0441\u0442\u0438\u043A\u0435\u0440\u043E\u0432\u2026"), /* @__PURE__ */ react_default.createElement("p", null, "\u041F\u0440\u043E\u0448\u043B\u043E ", elapsed, " \u0441\u0435\u043A."), elapsed >= 30 && /* @__PURE__ */ react_default.createElement("p", null, "\u041E\u0442\u0432\u0435\u0442 \u0437\u0430\u043D\u0438\u043C\u0430\u0435\u0442 \u0434\u043E\u043B\u044C\u0448\u0435 \u043E\u0431\u044B\u0447\u043D\u043E\u0433\u043E. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043D\u0430\u0436\u0438\u043C\u0430\u0442\u044C \u043F\u0435\u0447\u0430\u0442\u044C \u043F\u043E\u043A\u0430 \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.")), !error && /* @__PURE__ */ react_default.createElement("p", null, "\u0415\u0441\u043B\u0438 \u0437\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u043A\u043D\u043E, \u0443\u0436\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0442\u044C\u0441\u044F."), /* @__PURE__ */ react_default.createElement("button", { type: "button", className: "icon-text-button", onClick: onClose }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044C"));
}
export {
  FbsRequestActionDialog,
  requestActionExplanation
};
