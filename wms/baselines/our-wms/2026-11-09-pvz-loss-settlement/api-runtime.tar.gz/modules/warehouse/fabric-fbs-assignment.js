"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assignFabricOrder = assignFabricOrder;
const common_1 = require("@nestjs/common");
const fabric_fbs_order_1 = require("./fabric-fbs-order");
const fabric_fbs_store_1 = require("./fabric-fbs-store");
const fabric_fbs_availability_1 = require("./fabric-fbs-availability");
// FIX: reserve every fabric line and claim the task inside one transaction.
// The caller resolves the complete marketplace composition before opening it;
// claim must only write DB state, never call the marketplace or printer.
async function assignFabricOrder(tx, command, claim, enabled = process.env.WMS_FBS_FABRIC_CUT_ENABLED === 'true') {
    if (!enabled || command.capability !== true)
        throw new common_1.ConflictException('Нарезка ФБС не включена для этого ТСД.');
    await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${command.owner.requestId} FOR UPDATE`;
    const request = await tx.clientRequest.findUnique({ where: { id: command.owner.requestId } });
    if (!request || request.clientId !== command.clientId || !request.warehouseId ||
        ['DONE', 'CANCELLED', 'REJECTED'].includes(request.status))
        throw new common_1.ConflictException('Заявка закрыта или изменена.');
    return (0, fabric_fbs_store_1.withLockedFabricLedger)(tx, command.clientId, async (raw) => {
        for (const prefix of ['fabric.rolls.enabled.v1:', 'fabric.fbs.enabled.v1:']) {
            const setting = await tx.systemSetting.findUnique({ where: { key: prefix + command.clientId } });
            if (setting?.value?.enabled !== true) {
                throw new common_1.ConflictException('Нарезка ФБС не включена у клиента.');
            }
        }
        const items = await tx.clientRequestItem.findMany({ where: { requestId: request.id }, include: { sku: true } });
        const pending = raw.shipmentPending ?? [];
        const receivedAfter = new Map();
        const currentKey = (0, fabric_fbs_order_1.fabricOrderKey)(command.owner);
        const orders = raw.fbsOrders ?? {};
        for (const line of command.lines) {
            const item = items.find(i => i.id === line.lineId);
            if (!item || item.skuId !== line.skuId || item.sku?.clientId !== command.clientId ||
                line.warehouseId !== request.warehouseId || item.quantity < line.units) {
                throw new common_1.ConflictException('Состав нарезки не соответствует заявке.');
            }
            const identity = (0, fabric_fbs_availability_1.identifyFabricSku)(item.sku);
            if (!identity || identity.material !== line.material || identity.color !== line.color || identity.lengthMm !== line.lengthMm) {
                throw new common_1.ConflictException('Длина или материал не соответствует артикулу.');
            }
            // FIX: several orders may share one request item. Its total is a ceiling,
            // not permission to manufacture that total separately for every order.
            let committed = 0;
            for (const [key, order] of Object.entries(orders)) {
                if (key === currentKey || order.identity.requestId !== request.id)
                    continue;
                for (const other of order.lines.filter(l => l.lineId === line.lineId)) {
                    const reservation = raw.fbsReservations?.find(r => r.key === JSON.stringify([key, other.lineId]));
                    if (!reservation)
                        throw new common_1.ConflictException('История резерва ткани требует сверки.');
                    committed += reservation.released ? reservation.confirmedUnits : reservation.units;
                }
            }
            if (committed + line.units > item.quantity)
                throw new common_1.ConflictException('Количество позиции уже зарезервировано для других заказов.');
            const disputed = pending.filter(p => p.warehouseId === line.warehouseId && p.material === line.material && p.color === line.color && p.meters > 0);
            if (disputed.length) {
                // FIX: resolve immutable shipment dates under the same client ledger lock.
                // Unknown/FBO evidence fails closed; never spend new receipts to erase old debt.
                if (disputed.some(p => !p.key?.startsWith('wb:') || p.key.length <= 3)) {
                    throw new common_1.ConflictException('По этому материалу требуется сверка предыдущего расхода.');
                }
                const ids = [...new Set(disputed.map(p => p.key.slice(3)))];
                const shipments = await tx.wbOrderShipment.findMany({
                    where: { clientId: command.clientId, warehouseId: line.warehouseId, id: { in: ids } },
                    select: { id: true, shippedAt: true },
                });
                const dates = ids.map(id => shipments.find(s => s.id === id)?.shippedAt?.getTime());
                if (dates.some(date => date === undefined || !Number.isFinite(date))) {
                    throw new common_1.ConflictException('По этому материалу требуется сверка предыдущего расхода.');
                }
                receivedAfter.set(line.lineId, Math.max(...dates));
            }
        }
        let ledger;
        try {
            ledger = (0, fabric_fbs_order_1.reserveFabricOrder)(raw, command.owner, command.lines, receivedAfter);
        }
        catch (error) {
            if (receivedAfter.size && error instanceof Error && ['Insufficient continuous fabric', 'Fabric reservation requires reconciliation'].includes(error.message)) {
                throw new common_1.ConflictException('Недостаточно свободной ткани из приходов после спорных отгрузок. Старый расход остаётся на сверке.');
            }
            throw error;
        }
        const result = await claim(tx, ledger);
        return { ledger, result };
    });
}
