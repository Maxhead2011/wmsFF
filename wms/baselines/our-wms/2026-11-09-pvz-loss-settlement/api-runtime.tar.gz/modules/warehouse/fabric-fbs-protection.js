"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.freeFabricMm = freeFabricMm;
exports.assertFabricMutationPreservesReservations = assertFabricMutationPreservesReservations;
exports.fabricCreditMatches = fabricCreditMatches;
const fabric_fbs_ledger_1 = require("./fabric-fbs-ledger");
// FIX: persisted commitments remain protected even when new assignment is disabled.
function freeFabricMm(state, rollId) {
    (0, fabric_fbs_ledger_1.validateFabricLedger)(state);
    const roll = state.rolls.find(r => r.id === rollId);
    if (!roll || roll.writtenOffAt)
        return 0;
    return Math.max(0, roll.remainingMm - (0, fabric_fbs_ledger_1.reservedFabricMm)(state, rollId));
}
function assertFabricMutationPreservesReservations(before, after) {
    (0, fabric_fbs_ledger_1.validateFabricLedger)(before);
    (0, fabric_fbs_ledger_1.validateFabricLedger)(after);
    if (JSON.stringify(before.fbsReservations ?? []) !== JSON.stringify(after.fbsReservations ?? [])) {
        throw new Error('Резервы ткани изменились вне операции ФБС.');
    }
    for (const roll of before.rolls) {
        const reserved = (0, fabric_fbs_ledger_1.reservedFabricMm)(before, roll.id);
        if (!reserved)
            continue;
        const updated = after.rolls.find(r => r.id === roll.id);
        if (!updated || updated.writtenOffAt || updated.warehouseId !== roll.warehouseId ||
            updated.material !== roll.material || updated.color !== roll.color || updated.remainingMm < reserved) {
            throw new Error('Метры зарезервированы под заказы ФБС. Сначала разберите резерв.');
        }
    }
}
// FIX: an old shipment of the same SKU cannot consume a new order's cut proof.
function fabricCreditMatches(credit, shipment) {
    return ['skuId', 'warehouseId', 'marketplace', 'connectionId', 'orderId', 'taskId', 'requestId'].every(key => {
        const field = key;
        return typeof shipment[field] === 'string' && !!shipment[field].trim() && credit[field] === shipment[field];
    }) && Number.isSafeInteger(credit.mm) && credit.mm > 0;
}
