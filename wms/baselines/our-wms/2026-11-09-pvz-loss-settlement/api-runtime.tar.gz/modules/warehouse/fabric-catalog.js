"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.colorNameKey = exports.BASE_FABRIC_COLORS = void 0;
exports.preserveFabricBinding = preserveFabricBinding;
exports.addFabricColor = addFabricColor;
exports.readFabricBinding = readFabricBinding;
exports.createFabricBinding = createFabricBinding;
const crypto_1 = require("crypto");
exports.BASE_FABRIC_COLORS = { black: 'Чёрный', white: 'Белый', green: 'Зелёный', red: 'Красный', ivory: 'Айвори / шампань', blue: 'Синий' };
const colorNameKey = (name) => name.normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('ru-RU').replace(/ё/g, 'е');
exports.colorNameKey = colorNameKey;
// FIX: preserve warehouse-owned metadata during marketplace synchronization.
function preserveFabricBinding(incoming, previous) {
    const payload = incoming && typeof incoming === 'object' && !Array.isArray(incoming) ? { ...incoming } : {};
    delete payload.fabricRollBinding;
    const binding = readFabricBinding(previous);
    return binding ? { ...payload, fabricRollBinding: binding } : payload;
}
// FIX: colors belong to one client registry and one material; duplicate names reuse the existing color.
function addFabricColor(colors, material, name) {
    if (!['SATIN', 'GABARDINE'].includes(material) || typeof name !== 'string')
        throw new Error('Укажите ткань и название цвета.');
    name = name.normalize('NFKC').trim().replace(/\s+/g, ' ');
    if (!name || name.length > 80 || /[\x00-\x1f\x7f]/.test(name))
        throw new Error('Название цвета: от 1 до 80 символов.');
    const base = Object.entries(exports.BASE_FABRIC_COLORS).find(([, label]) => (0, exports.colorNameKey)(label) === (0, exports.colorNameKey)(name));
    const existing = colors.find(c => c.material === material && (0, exports.colorNameKey)(c.name) === (0, exports.colorNameKey)(name));
    const color = base ? { id: base[0], material, name: base[1] } : existing ?? { id: 'custom-' + (0, crypto_1.randomUUID)(), material, name };
    return { color, colors: base || existing ? [...colors] : [...colors, color], reused: Boolean(base || existing) };
}
// FIX: the SKU remains the marketplace identity; its explicit binding supplies exact material consumption.
function readFabricBinding(payload) {
    const b = payload?.fabricRollBinding;
    return b?.version === 1 && ['SATIN', 'GABARDINE'].includes(b.material) && typeof b.color === 'string' &&
        typeof b.colorName === 'string' && Number.isSafeInteger(b.lengthMm) && b.lengthMm > 0 && b.lengthMm <= 100000 ? b : null;
}
function createFabricBinding(colors, material, colorId, lengthMm) {
    const colorName = exports.BASE_FABRIC_COLORS[colorId] ?? colors.find(c => c.id === colorId && c.material === material)?.name;
    if (!['SATIN', 'GABARDINE'].includes(material) || !colorName || !Number.isSafeInteger(lengthMm) || lengthMm < 1 || lengthMm > 100000) {
        throw new Error('Выберите цвет этой ткани и длину отреза от 0,001 до 100 м.');
    }
    return { version: 1, material, color: colorId, colorName, lengthMm };
}
