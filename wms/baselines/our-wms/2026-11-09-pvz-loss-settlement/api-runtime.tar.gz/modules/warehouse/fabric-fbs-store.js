"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withLockedFabricLedger = withLockedFabricLedger;
const common_1 = require("@nestjs/common");
// FIX: caller owns the surrounding request-first transaction. All colours and
// branches share this existing lock because the entire client ledger is one JSON.
// Never perform an external marketplace request from the callback.
async function withLockedFabricLedger(tx, clientId, operation) {
    if (!clientId.trim())
        throw new common_1.ConflictException('Не указан клиент учёта ткани.');
    const key = `fabric.rolls.v1:${clientId}`;
    const locks = await tx.$queryRaw `
    SELECT pg_try_advisory_xact_lock(hashtext(${key})) AS locked
  `;
    if (locks[0]?.locked !== true) {
        throw new common_1.ConflictException('Ткань сейчас обрабатывается другим сотрудником. Повторите операцию.');
    }
    const record = await tx.systemSetting.findUnique({ where: { key } });
    if (!record || !record.value || typeof record.value !== 'object' ||
        Array.isArray(record.value) || !Array.isArray(record.value.rolls)) {
        throw new common_1.ConflictException('Учёт рулонов не заполнен или требует проверки.');
    }
    // Preserve every unrelated field, including historical shipment credits.
    const ledger = JSON.parse(JSON.stringify(record.value));
    const outcome = await operation(ledger);
    await tx.systemSetting.update({
        where: { key }, data: { value: outcome.ledger },
    });
    return outcome.result;
}
