"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fabricOrderKey = fabricOrderKey;
exports.reserveFabricOrder = reserveFabricOrder;
exports.confirmFabricOrderCut = confirmFabricOrderCut;
exports.releaseFabricOrder = releaseFabricOrder;
const fabric_fbs_ledger_1 = require("./fabric-fbs-ledger");
// FIX: structured keys cannot collide when marketplace identifiers contain punctuation.
function fabricOrderKey(identity) {
    const values = [identity.marketplace, identity.connectionId, identity.orderId, identity.requestId];
    if (values.some(v => typeof v !== 'string' || !v.trim()))
        throw new Error('Incomplete fabric order identity');
    return JSON.stringify(values);
}
function lineKey(owner, lineId) { return JSON.stringify([fabricOrderKey(owner), lineId]); }
function composition(lines) {
    return JSON.stringify([...lines].sort((a, b) => a.lineId.localeCompare(b.lineId)).map(l => [l.lineId, l.skuId, l.warehouseId, l.material, l.color, l.lengthMm, l.units]));
}
// FIX: all lines reserve atomically in memory; the caller persists once under the client lock.
function reserveFabricOrder(input, owner, lines, receivedAfter = new Map()) {
    const key = fabricOrderKey(owner);
    if (!lines.length || lines.some(l => typeof l.lineId !== 'string' || !l.lineId.trim()))
        throw new Error('Missing fabric order lines');
    if (new Set(lines.map(l => l.lineId)).size !== lines.length)
        throw new Error('Duplicate fabric order line');
    const saved = input.fbsOrders?.[key];
    if (saved && composition(saved.lines) !== composition(lines))
        throw new Error('Fabric order composition changed');
    let next = structuredClone(input);
    for (const line of lines)
        next = (0, fabric_fbs_ledger_1.reserveFabric)(next, { ...line, key: lineKey(owner, line.lineId) }, receivedAfter.get(line.lineId));
    (next.fbsOrders ??= {})[key] = { identity: structuredClone(owner), lines: structuredClone(lines) };
    return next;
}
function confirmFabricOrderCut(input, owner, lineId, units, operationId) {
    const saved = input.fbsOrders?.[fabricOrderKey(owner)];
    if (!saved?.lines.some(l => l.lineId === lineId))
        throw new Error('Fabric order line missing');
    // FIX: replay may not redirect the same operation to another product line.
    const other = saved.lines.filter(l => l.lineId !== lineId).map(l => lineKey(owner, l.lineId));
    if (input.fbsReservations?.some(r => other.includes(r.key) && r.operations.some(op => op.id === operationId))) {
        throw new Error('Operation payload conflict');
    }
    return (0, fabric_fbs_ledger_1.confirmFabricCut)(input, lineKey(owner, lineId), units, operationId);
}
function releaseFabricOrder(input, owner) {
    const saved = input.fbsOrders?.[fabricOrderKey(owner)];
    if (!saved)
        throw new Error('Fabric order missing');
    let next = structuredClone(input);
    for (const line of saved.lines)
        next = (0, fabric_fbs_ledger_1.releaseUncutFabric)(next, lineKey(owner, line.lineId));
    return next;
}
