"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.receiptFinalQuantities = receiptFinalQuantities;
const common_1 = require("@nestjs/common");
// FIX: final box/SKU composition instead of separate correction movements; no stock writes.
function receiptFinalQuantities(rows) {
    const groups = new Map();
    for (const row of rows) {
        if (!row.boxId || !row.skuId || !Number.isSafeInteger(row.quantity))
            throw new common_1.ConflictException('Не удалось проверить состав приёмки.');
        const key = JSON.stringify([row.boxId, row.skuId]), existing = groups.get(key);
        if (existing)
            existing.quantity += row.quantity;
        else
            groups.set(key, { ...row });
    }
    const result = [...groups.values()];
    if (result.some(row => !Number.isSafeInteger(row.quantity) || row.quantity < 0))
        throw new common_1.ConflictException('Итоговое количество товара в коробе отрицательное. Требуется сверка.');
    return result.filter(row => row.quantity > 0);
}
