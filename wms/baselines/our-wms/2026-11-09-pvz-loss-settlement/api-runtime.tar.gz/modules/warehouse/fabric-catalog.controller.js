"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FabricCatalogController = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const client_scope_service_1 = require("../auth/client-scope.service");
const fabric_catalog_1 = require("./fabric-catalog");
const fabric_fbs_availability_1 = require("./fabric-fbs-availability");
let FabricCatalogController = class FabricCatalogController {
    db;
    scopes;
    constructor(db, scopes) {
        this.db = db;
        this.scopes = scopes;
    }
    key(id) { return 'fabric.catalog.v1:' + id; }
    async check(id, user, write = false) {
        if (process.env.WMS_FBS_FABRIC_CUT_ENABLED !== 'true' || user.isDemo)
            throw new common_1.NotFoundException();
        this.scopes.requireClientAccess(user, id, write ? 'write' : 'read');
        if (write && (user.roleCodes.includes('CLIENT') || !user.permissionCodes.some(p => ['stock:write', 'system:admin'].includes(p))))
            throw new common_1.ForbiddenException();
        if (!user.activeWarehouseId)
            throw new common_1.BadRequestException('Выберите филиал.');
        const member = await this.db.warehouseClient.findFirst({ where: { clientId: id, warehouseId: user.activeWarehouseId } });
        if (!member)
            throw new common_1.ForbiddenException('Клиент не подключён к выбранному филиалу.');
    }
    async get(id, user) {
        await this.check(id, user);
        const saved = await this.db.systemSetting.findUnique({ where: { key: this.key(id) } });
        const colors = (saved?.value?.colors ?? []);
        const skus = await this.db.sku.findMany({ where: { clientId: id, isDraft: false }, select: { id: true, name: true, internalSku: true, marketplace: true, marketplaceProductId: true, marketplaceOfferId: true, marketplacePayload: true, barcodes: { select: { value: true } } } });
        return { colors, baseColors: fabric_catalog_1.BASE_FABRIC_COLORS, version: saved?.updatedAt.toISOString() ?? null, skus: skus.map(s => ({ id: s.id, name: s.name, internalSku: s.internalSku, marketplace: s.marketplace, productId: s.marketplaceProductId, offerId: s.marketplaceOfferId, barcodes: s.barcodes.map(b => b.value), binding: (0, fabric_catalog_1.readFabricBinding)(s.marketplacePayload) })) };
    }
    async save(id, body, user) {
        await this.check(id, user, true);
        if (!body || typeof body !== 'object' || !['CREATE_COLOR', 'BIND_SKU'].includes(body.action) || !Object.prototype.hasOwnProperty.call(body, 'version'))
            throw new common_1.BadRequestException('Укажите действие и текущую версию каталога.');
        const result = await this.db.$transaction(async (tx) => {
            // FIX: serialize color creation and SKU binding with receipt and FBS metre accounting.
            await tx.$executeRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))', 'fabric.rolls.v1:' + id);
            const saved = await tx.systemSetting.findUnique({ where: { key: this.key(id) } });
            if ((saved?.updatedAt.toISOString() ?? null) !== body.version)
                throw new common_1.ConflictException('Каталог изменился. Обновите данные.');
            let colors = (saved?.value?.colors ?? []);
            let outcome;
            try {
                if (body.action === 'CREATE_COLOR') {
                    const added = (0, fabric_catalog_1.addFabricColor)(colors, body.material, body.name);
                    colors = added.colors;
                    outcome = added;
                }
                else if (body.action === 'BIND_SKU') {
                    const binding = (0, fabric_catalog_1.createFabricBinding)(colors, body.material, body.colorId, body.lengthMm);
                    const sku = await tx.sku.findFirst({ where: { id: body.skuId, clientId: id, isDraft: false } });
                    if (!body.skuId || !sku)
                        throw new Error('Товар выбранного клиента не найден.');
                    if (!sku.marketplaceProductId && !sku.marketplaceOfferId && !(await tx.marketplaceProductLink.findFirst({ where: { clientId: id, skuId: sku.id } })))
                        throw new Error('Сначала свяжите карточку товара WMS с маркетплейсом.');
                    const old = (0, fabric_fbs_availability_1.identifyFabricSku)(sku);
                    if (old && (old.material !== binding.material || old.color !== binding.color || old.lengthMm !== binding.lengthMm))
                        throw new Error('Существующую привязку ткани менять нельзя: она используется в истории и резервах.');
                    if (!old && await tx.stockBalance.findFirst({ where: { clientId: id, skuId: sku.id, quantity: { gt: 0 } } }))
                        throw new Error('У товара уже есть складской остаток. Требуется проверка перед привязкой к рулонам.');
                    const payload = sku.marketplacePayload && typeof sku.marketplacePayload === 'object' && !Array.isArray(sku.marketplacePayload) ? sku.marketplacePayload : {};
                    await tx.sku.update({ where: { id: sku.id }, data: { marketplacePayload: { ...payload, fabricRollBinding: binding } } });
                    outcome = { skuId: sku.id, binding };
                }
                else
                    throw new Error('Неизвестное действие.');
            }
            catch (error) {
                throw new common_1.BadRequestException(error instanceof Error ? error.message : 'Не удалось сохранить.');
            }
            await tx.systemSetting.upsert({ where: { key: this.key(id) }, create: { key: this.key(id), value: { colors }, updatedByUserId: user.id }, update: { value: { colors }, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'FABRIC_CATALOG_' + body.action, entity: 'FabricRolls', entityId: id, payload: { warehouseId: user.activeWarehouseId, result: outcome } } });
            return outcome;
        });
        return { result, catalog: await this.get(id, user) };
    }
};
exports.FabricCatalogController = FabricCatalogController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], FabricCatalogController.prototype, "get", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], FabricCatalogController.prototype, "save", null);
exports.FabricCatalogController = FabricCatalogController = __decorate([
    (0, common_1.Controller)('warehouse/fabric-catalog/:clientId'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], FabricCatalogController);
