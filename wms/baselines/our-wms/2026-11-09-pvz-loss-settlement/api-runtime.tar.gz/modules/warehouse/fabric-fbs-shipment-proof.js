"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readFabricShipmentProof = readFabricShipmentProof;
const common_1 = require("@nestjs/common");
const fabric_fbs_task_state_1 = require("./fabric-fbs-task-state");
const fabric_fbs_protection_1 = require("./fabric-fbs-protection");
// FIX: a task status is not production evidence. Match audit, movement and exact
// request item; never grant another order credit for the same SKU's raw debit.
async function readFabricShipmentProof(db, request, warehouseId, eligibleTaskIds) {
    // FIX: the caller has already excluded print-confirmed WB shipments.
    if (!eligibleTaskIds.size)
        return [];
    const tasks = await db.fbsTsdAssembly.findMany({ where: { requestId: request.id, clientId: request.clientId, status: 'COMPLETED', sourceArticle: fabric_fbs_task_state_1.FABRIC_TASK_MARKER } });
    if (!tasks.length)
        return [];
    if (!warehouseId)
        throw new common_1.ConflictException('Не определён склад нарезанных отрезов.');
    const audits = await db.auditLog.findMany({ where: { entity: 'FabricRolls', entityId: request.clientId, action: 'FABRIC_FBS_CUT' }, select: { payload: true } });
    const result = [];
    const used = new Map();
    for (const task of tasks) {
        if (!eligibleTaskIds.has(task.id) || task.sourceArticle !== fabric_fbs_task_state_1.FABRIC_TASK_MARKER || task.status !== 'COMPLETED')
            continue;
        const records = audits.map((a) => a.payload).filter((p) => p?.taskId === task.id);
        const lines = await (0, fabric_fbs_task_state_1.readFabricTaskLines)(db, task);
        if (!lines?.length || lines.some(l => l.remainingUnits !== 0 || records.filter((p) => p.lineId === l.lineId && p.skuId === l.skuId).reduce((n, p) => n + p.units, 0) !== l.quantity))
            throw new common_1.ConflictException('Нет полного подтверждения производства отрезов.');
        for (const proof of records) {
            const item = request.items.find((i) => i.id === proof.lineId && i.skuId === proof.skuId);
            if (!item)
                continue; // WB already-shipped items are removed from the remaining request.
            if (!(0, fabric_fbs_protection_1.fabricCreditMatches)(proof, { ...task, taskId: task.id, skuId: proof.skuId, warehouseId }) ||
                !Number.isSafeInteger(proof.units) || proof.units <= 0 || proof.clientId !== request.clientId)
                throw new common_1.ConflictException('История производства не соответствует отгрузке.');
            const movement = await db.stockMovement.findUnique({ where: { idempotencyKey: proof.movementKey } });
            if (!movement || movement.clientId !== request.clientId || movement.sourceDocument !== request.id ||
                movement.skuId !== item.skuId || movement.warehouseId !== warehouseId || movement.status !== 'PACKING' ||
                movement.quantity !== proof.units || movement.boxId || movement.palletId ||
                proof.movementKey !== `fbs-sticker-pick:${task.id}:fabric:${proof.key}`)
                throw new common_1.ConflictException('Не подтверждён приход отрезов под заказ.');
            const total = (used.get(item.id) ?? 0) + proof.units;
            if (total > item.quantity)
                throw new common_1.ConflictException('Производство превышает количество к отгрузке. Нужна сверка.');
            used.set(item.id, total);
            result.push({ itemId: item.id, skuId: item.skuId, warehouseId, boxId: null, palletId: null, quantity: proof.units, movementIds: [movement.id], strictPacking: true });
        }
    }
    return result;
}
