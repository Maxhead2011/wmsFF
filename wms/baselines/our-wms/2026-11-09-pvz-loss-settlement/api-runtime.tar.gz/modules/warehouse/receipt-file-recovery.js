'use strict';
const {createHash}=require('node:crypto');
const {ConflictException}=require('@nestjs/common');
const {clientKizIdentity}=require('../../common/kiz-client-registry');
const prefix=(client,warehouse)=>`receipt.file-recovery.v1:${client}:${warehouse}:`;
function digest(rows){return createHash('sha256').update(JSON.stringify(rows.map(r=>[r.rowNumber,r.boxId,r.skuId,r.barcode,r.kiz,r.quantity,r.receiptMovementId,r.recordedAt,r.legacyMarkId]))).digest('hex');}
function matches(binding,client,warehouse,doc){
 if(!binding||binding.clientId!==client||binding.warehouseId!==warehouse||binding.receiptId!==doc.id)return false;
 const expected=binding.boxGenerations;
 return Array.isArray(expected)&&expected.length===doc.boxes.length&&expected.every(e=>doc.boxes.some(b=>b.id===e.id&&b.receiptDocument===e.receiptDocument));
}
function validate(binding){
 const rows=binding.rows;
 if(binding.version!==1||!/^[a-f0-9]{64}$/.test(binding.sourceFileSha256)||!Array.isArray(rows)||rows.length!==binding.rowCount||digest(rows)!==binding.rowsSha256)throw new ConflictException('Проверенный состав файла приёмки повреждён. Требуется сверка.');
 const keys=new Set(),numbers=new Set(),boxes=new Set(binding.boxGenerations.map(b=>b.id));
 for(const r of rows){const identity=clientKizIdentity(r.kiz);if(!identity||keys.has(identity)||numbers.has(r.rowNumber)||!Number.isSafeInteger(r.rowNumber)||!boxes.has(r.boxId)||!r.skuId||!r.barcode||r.quantity!==1||(!r.receiptMovementId&&!r.legacyMarkId)||(r.recordedAt!==null&&!Number.isFinite(Date.parse(r.recordedAt))))throw new ConflictException('Не удалось проверить строки восстановленной приёмки.');keys.add(identity);numbers.add(r.rowNumber);}
 return rows;
}
async function bindingFor(db,client,warehouse,doc){const saved=await db.systemSetting.findUnique({where:{key:prefix(client,warehouse)+doc.id}});if(!matches(saved?.value,client,warehouse,doc))return null;validate(saved.value);return saved.value;}
async function attachCounts(db,client,warehouse,docs){
 const saved=await db.systemSetting.findMany({where:{key:{startsWith:warehouse?prefix(client,warehouse):`receipt.file-recovery.v1:${client}:`}},select:{value:true}});
 return docs.map(doc=>{const binding=saved.map(s=>s.value).find(b=>matches(b,client,doc.warehouseId,doc));if(!binding)return doc;const rows=validate(binding);return {...doc,received:rows.length,recoveryFileVerified:true};});
}
async function fileRows(db,client,warehouse,doc){
 const binding=await bindingFor(db,client,warehouse,doc);if(!binding)return null;
 const skus=await db.sku.findMany({where:{clientId:client,id:{in:[...new Set(binding.rows.map(r=>r.skuId))]}},select:{id:true,name:true,article:true,size:true}});const byId=new Map(skus.map(s=>[s.id,s]));
 if(binding.rows.some(r=>!byId.has(r.skuId)))throw new ConflictException('Товар восстановленной приёмки не найден у клиента.');
 return binding.rows.map(r=>({id:'recovery-file:'+r.rowNumber,boxId:r.boxId,sku:byId.get(r.skuId),quantity:1,createdAt:r.recordedAt===null?null:new Date(r.recordedAt),barcode:r.barcode,kiz:r.kiz.replace(/\u001d/g,'<GS>'),sourceRow:r.rowNumber,evidence:r.receiptMovementId?'Запись прихода WMS':'Существующий КИЗ; дата исходного прихода не сохранена'}));
}
module.exports={digest,matches,validate,attachCounts,fileRows};
