"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateFabricLedger = validateFabricLedger;
exports.reservedFabricMm = reservedFabricMm;
exports.reserveFabric = reserveFabric;
exports.confirmFabricCut = confirmFabricCut;
exports.releaseUncutFabric = releaseUncutFabric;
function integer(n, min, max) {
    if (!Number.isSafeInteger(n) || n < min || n > max)
        throw new Error('Invalid fabric quantity');
}
function copy(value) { return JSON.parse(JSON.stringify(value)); }
// FIX: refuse corrupt persisted allocations rather than confirming phantom cuts.
function validateFabricLedger(state) {
    const validInt = (n, min = 0) => Number.isSafeInteger(n) && n >= min;
    const text = (s) => typeof s === 'string' && !!s.trim();
    const fail = () => { throw new Error('Invalid fabric ledger'); };
    if (!state || !Array.isArray(state.rolls))
        fail();
    const rolls = new Map();
    for (const r of state.rolls) {
        if (!r || ![r.id, r.warehouseId, r.material, r.color].every(text) || rolls.has(r.id) ||
            !validInt(r.remainingMm) || !validInt(r.cutMm) || !Number.isFinite(Date.parse(r.createdAt)))
            fail();
        rolls.set(r.id, r);
    }
    if (state.fbsReservations !== undefined && !Array.isArray(state.fbsReservations))
        fail();
    const keys = new Set();
    for (const r of state.fbsReservations ?? []) {
        if (!r || ![r.key, r.skuId, r.warehouseId, r.material, r.color].every(text) || keys.has(r.key) ||
            !validInt(r.units, 1) || r.units > 500 || !validInt(r.lengthMm, 1) || r.lengthMm > 100000 ||
            !validInt(r.confirmedUnits) || r.confirmedUnits > r.units || typeof r.released !== 'boolean' ||
            !Array.isArray(r.rollIds) || r.rollIds.length !== r.units || !Array.isArray(r.operations))
            fail();
        keys.add(r.key);
        for (const id of r.rollIds) {
            const roll = rolls.get(id);
            if (!roll || roll.warehouseId !== r.warehouseId || roll.material !== r.material || roll.color !== r.color)
                fail();
        }
        const ops = new Set();
        for (const op of r.operations) {
            if (!op || !text(op.id) || ops.has(op.id) || !validInt(op.units, 1) || op.units > r.confirmedUnits)
                fail();
            ops.add(op.id);
        }
    }
}
function same(a, b) {
    return a.key === b.key && a.warehouseId === b.warehouseId && a.material === b.material &&
        a.color === b.color && a.skuId === b.skuId && a.lengthMm === b.lengthMm && a.units === b.units;
}
function reservedFabricMm(state, rollId) {
    return (state.fbsReservations ?? []).reduce((sum, r) => sum + (r.released ? 0 :
        r.rollIds.slice(r.confirmedUnits).filter(id => id === rollId).length * r.lengthMm), 0);
}
function reserveFabric(state, demand, receivedAfter) {
    validateFabricLedger(state);
    // FIX: only independently received rolls may cover new orders after disputed shipments.
    if (receivedAfter !== undefined && !Number.isFinite(receivedAfter))
        throw new Error('Invalid receipt cutoff');
    integer(demand.lengthMm, 1, 100000);
    integer(demand.units, 1, 500);
    if (![demand.key, demand.warehouseId, demand.material, demand.color, demand.skuId].every(v => typeof v === 'string' && v.trim())) {
        throw new Error('Incomplete fabric identity');
    }
    const existing = state.fbsReservations?.find(r => r.key === demand.key);
    if (existing) {
        if (!same(existing, demand) || existing.released)
            throw new Error('Fabric reservation conflict');
        if (receivedAfter !== undefined && existing.rollIds.slice(existing.confirmedUnits).some(id => Date.parse(state.rolls.find(r => r.id === id).createdAt) <= receivedAfter))
            throw new Error('Fabric reservation requires reconciliation');
        return copy(state);
    }
    const next = copy(state);
    const rolls = next.rolls.filter(r => !r.writtenOffAt && r.warehouseId === demand.warehouseId &&
        r.material === demand.material && r.color === demand.color &&
        (receivedAfter === undefined || Date.parse(r.createdAt) > receivedAfter))
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
    const rollIds = [];
    for (const roll of rolls) {
        integer(roll.remainingMm, 0, Number.MAX_SAFE_INTEGER);
        const free = roll.remainingMm - reservedFabricMm(next, roll.id);
        const count = Math.min(demand.units - rollIds.length, Math.max(0, Math.floor(free / demand.lengthMm)));
        for (let i = 0; i < count; i++)
            rollIds.push(roll.id);
        if (rollIds.length === demand.units)
            break;
    }
    if (rollIds.length !== demand.units)
        throw new Error('Insufficient continuous fabric');
    (next.fbsReservations ??= []).push({ ...demand, rollIds, confirmedUnits: 0, released: false, operations: [] });
    return next;
}
// FIX: absolute confirmed count plus durable operation ID prevents retry debits.
// Caller must atomically persist returned ledger with the delta's PACKING proof and audit.
function confirmFabricCut(state, key, units, operationId) {
    validateFabricLedger(state);
    if (!operationId.trim())
        throw new Error('Missing operation ID');
    const next = copy(state);
    const r = next.fbsReservations?.find(item => item.key === key);
    if (!r)
        throw new Error('Fabric reservation missing');
    integer(units, 1, r.units);
    const previous = r.operations.find(op => op.id === operationId);
    if (previous) {
        if (previous.units !== units)
            throw new Error('Operation payload conflict');
        return { state: next, cutUnits: 0, cutMm: 0, replay: true };
    }
    if (r.released || units < r.confirmedUnits)
        throw new Error('Fabric reservation changed');
    const delta = units - r.confirmedUnits;
    // FIX: validate total outstanding commitments once before any debit. An
    // external adjustment must not make this order spend another order's fabric.
    for (const id of new Set(r.rollIds.slice(r.confirmedUnits, units))) {
        const roll = next.rolls.find(item => item.id === id);
        if (!roll || !Number.isSafeInteger(roll.remainingMm) ||
            roll.remainingMm < reservedFabricMm(next, id))
            throw new Error('Reserved fabric unavailable');
    }
    for (const id of r.rollIds.slice(r.confirmedUnits, units)) {
        const roll = next.rolls.find(item => item.id === id);
        if (!roll || roll.writtenOffAt || roll.warehouseId !== r.warehouseId || roll.material !== r.material ||
            roll.color !== r.color || roll.remainingMm < r.lengthMm)
            throw new Error('Reserved fabric unavailable');
        roll.remainingMm -= r.lengthMm;
        roll.cutMm += r.lengthMm;
    }
    r.confirmedUnits = units;
    r.operations.push({ id: operationId, units });
    return { state: next, cutUnits: delta, cutMm: delta * r.lengthMm, replay: false };
}
// FIX: use only for real cancellation; worker postponement must retain the reservation.
function releaseUncutFabric(state, key) {
    validateFabricLedger(state);
    const next = copy(state);
    const r = next.fbsReservations?.find(item => item.key === key);
    if (!r)
        throw new Error('Fabric reservation missing');
    r.released = true;
    return next;
}
