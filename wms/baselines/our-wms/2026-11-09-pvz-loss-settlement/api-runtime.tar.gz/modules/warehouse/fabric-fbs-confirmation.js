"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmFabricProduction = confirmFabricProduction;
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const fabric_fbs_store_1 = require("./fabric-fbs-store");
const fabric_fbs_order_1 = require("./fabric-fbs-order");
// FIX: caller supplies its database transaction and writes PACKING + audit in that
// same transaction. No marketplace request or fictitious scanner event is emitted.
async function confirmFabricProduction(tx, command, actor, writeProof, now = new Date()) {
    if (!actor.userId?.trim() || !actor.deviceCode?.trim() || !command.operationId?.trim() ||
        command.operationId.length > 128 || !command.clientId?.trim() || !command.taskId?.trim()) {
        throw new common_1.ConflictException('Не указан сотрудник, устройство или идентификатор операции нарезки.');
    }
    await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${command.owner.requestId} FOR UPDATE`;
    const request = await tx.clientRequest.findUnique({ where: { id: command.owner.requestId } });
    if (!request || request.clientId !== command.clientId || ['DONE', 'CANCELLED', 'REJECTED'].includes(request.status)) {
        throw new common_1.ConflictException('Заявка закрыта или принадлежит другому клиенту.');
    }
    return (0, fabric_fbs_store_1.withLockedFabricLedger)(tx, command.clientId, async (raw) => {
        const ledger = raw;
        await tx.$queryRaw `SELECT id FROM "FbsTsdAssembly" WHERE id=${command.taskId} FOR UPDATE`;
        const task = await tx.fbsTsdAssembly.findUnique({ where: { id: command.taskId } });
        if (!task || task.status !== 'IN_PROGRESS' || task.workerUserId !== actor.userId || task.deviceCode !== actor.deviceCode ||
            task.clientId !== command.clientId || task.requestId !== command.owner.requestId ||
            task.marketplace !== command.owner.marketplace || task.connectionId !== command.owner.connectionId || task.orderId !== command.owner.orderId) {
            throw new common_1.ConflictException('Задание нарезки изменилось или назначено другому сотруднику.');
        }
        const saved = ledger.fbsOrders?.[(0, fabric_fbs_order_1.fabricOrderKey)(command.owner)];
        const line = saved?.lines.find(l => l.lineId === command.lineId);
        if (!line || line.warehouseId !== request.warehouseId)
            throw new common_1.ConflictException('Изменился склад или состав нарезки.');
        const item = await tx.clientRequestItem.findUnique({ where: { id: line.lineId } });
        if (!item || item.requestId !== request.id || item.skuId !== line.skuId || item.quantity < line.units) {
            throw new common_1.ConflictException('Позиция нарезки больше не соответствует заявке.');
        }
        const result = (0, fabric_fbs_order_1.confirmFabricOrderCut)(ledger, command.owner, command.lineId, command.confirmedUnits, command.operationId);
        if (result.cutUnits) {
            const key = 'fabric-fbs-cut:' + (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([
                command.clientId, (0, fabric_fbs_order_1.fabricOrderKey)(command.owner), command.lineId, command.operationId,
            ])).digest('hex');
            await writeProof(tx, {
                key, taskId: task.id, clientId: command.clientId, ...command.owner,
                lineId: line.lineId, skuId: line.skuId, warehouseId: line.warehouseId,
                material: line.material, color: line.color,
                units: result.cutUnits, mm: result.cutMm, userId: actor.userId, deviceCode: actor.deviceCode, at: now.toISOString(),
            });
        }
        return { ledger: result.state, result: { cutUnits: result.cutUnits, cutMm: result.cutMm, replay: result.replay } };
    });
}
