"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordFabricScan = recordFabricScan;
exports.scanWbFabric = scanWbFabric;
const common_1 = require("@nestjs/common");
const fabric_fbs_confirmation_1 = require("./fabric-fbs-confirmation");
const fabric_fbs_production_1 = require("./fabric-fbs-production");
const fabric_fbs_task_state_1 = require("./fabric-fbs-task-state");
// FIX: called only after validating the product scan, within the scan transaction.
async function recordFabricScan(tx, task, lineId, count, user, deviceCode) {
    await (0, fabric_fbs_task_state_1.readFabricTaskLines)(tx, task); // fail closed if the mode/reservation disappeared
    return (0, fabric_fbs_confirmation_1.confirmFabricProduction)(tx, {
        clientId: task.clientId, taskId: task.id,
        owner: { marketplace: task.marketplace, connectionId: task.connectionId, orderId: task.orderId, requestId: task.requestId }, lineId, confirmedUnits: count,
        operationId: `scan:${lineId}:${count}`,
    }, { userId: user.id, deviceCode }, (_, proof) => (0, fabric_fbs_production_1.writeFabricProduction)(tx, proof));
}
// FIX: WB uses the same durable absolute counter as Ozon: one accepted scan, one piece.
async function scanWbFabric(service, task, barcode, expected, user) {
    if (task.sourceArticle !== fabric_fbs_task_state_1.FABRIC_TASK_MARKER || task.marketplace !== 'WILDBERRIES')
        return null;
    await service.inventoryLock?.assertStockMovementsAllowed();
    return service.prisma.$transaction(async (tx) => {
        await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${task.requestId} FOR UPDATE`;
        const key = `fabric.rolls.v1:${task.clientId}`;
        const locks = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${key})) AS locked`;
        if (locks[0]?.locked !== true)
            throw new common_1.ConflictException('Ткань обрабатывается другим сотрудником. Повторите скан.');
        await tx.$queryRaw `SELECT id FROM "FbsTsdAssembly" WHERE id=${task.id} FOR UPDATE`;
        const fresh = await tx.fbsTsdAssembly.findUnique({ where: { id: task.id } });
        service.requireCurrentFbsTsdLease(fresh, user);
        const lines = await (0, fabric_fbs_task_state_1.readFabricTaskLines)(tx, fresh);
        const line = lines?.find(l => l.lineId === fresh.requestItemId && l.skuId === fresh.skuId);
        if (lines?.length !== 1 || !line || line.quantity !== fresh.itemCount)
            throw new common_1.ConflictException('Состав нарезки изменился.');
        if (!Array.isArray(fresh.barcodes) || !fresh.barcodes.some((v) => v.toLowerCase() === barcode.toLowerCase()))
            throw new common_1.ConflictException('Неверный ШК товара. Метры не списаны.');
        if (!Number.isSafeInteger(expected) || Number(expected) < 0 || Number(expected) > line.confirmedUnits)
            throw new common_1.ConflictException('Обновите счётчик сканирования.');
        // FIX: a validated rescan restores lost barcode proof without another production debit.
        if (line.remainingUnits === 0) {
            if (fresh.barcode === barcode)
                return fresh;
            return tx.fbsTsdAssembly.update({ where: { id: fresh.id }, data: { barcode, errorMessage: null } });
        }
        if (Number(expected) < line.confirmedUnits)
            return fresh;
        await recordFabricScan(tx, fresh, line.lineId, line.confirmedUnits + 1, user, service.fbsTsdDeviceCode(undefined, user));
        return tx.fbsTsdAssembly.update({ where: { id: fresh.id }, data: {
                barcode: line.remainingUnits === 1 ? barcode : null, errorMessage: null,
            } });
    });
}
