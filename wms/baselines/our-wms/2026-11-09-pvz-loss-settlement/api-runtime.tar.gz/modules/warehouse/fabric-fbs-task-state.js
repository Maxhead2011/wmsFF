"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FABRIC_TASK_MARKER = void 0;
exports.fabricTaskLines = fabricTaskLines;
exports.readFabricTaskLines = readFabricTaskLines;
exports.requireFabricCutComplete = requireFabricCutComplete;
const common_1 = require("@nestjs/common");
const fabric_fbs_order_1 = require("./fabric-fbs-order");
exports.FABRIC_TASK_MARKER = '__FABRIC_FBS__';
// FIX: manufacture progress is separate from barcode/KIZ scan evidence.
function fabricTaskLines(ledger, owner) {
    const key = (0, fabric_fbs_order_1.fabricOrderKey)(owner), order = ledger.fbsOrders?.[key];
    if (!order)
        return null;
    if ((0, fabric_fbs_order_1.fabricOrderKey)(order.identity) !== key)
        throw new common_1.ConflictException('Владелец резерва ткани изменился.');
    return order.lines.map(line => {
        const reservation = ledger.fbsReservations?.find(r => r.key === JSON.stringify([key, line.lineId]));
        if (!reservation || reservation.skuId !== line.skuId || reservation.units !== line.units ||
            reservation.lengthMm !== line.lengthMm || reservation.warehouseId !== line.warehouseId ||
            reservation.material !== line.material || reservation.color !== line.color ||
            !Number.isSafeInteger(reservation.confirmedUnits) || reservation.confirmedUnits < 0 || reservation.confirmedUnits > line.units) {
            throw new common_1.ConflictException('Резерв нарезки требует сверки.');
        }
        if (reservation.released && reservation.confirmedUnits < line.units) {
            throw new common_1.ConflictException('Резерв нарезки освобождён. Обновите задание.');
        }
        return { lineId: line.lineId, skuId: line.skuId, material: line.material, color: line.color,
            lengthMm: line.lengthMm, quantity: line.units, confirmedUnits: reservation.confirmedUnits,
            remainingUnits: line.units - reservation.confirmedUnits };
    });
}
async function readFabricTaskLines(db, task, enabled = process.env.WMS_FBS_FABRIC_CUT_ENABLED === 'true') {
    if (!enabled) {
        if (task.sourceArticle === exports.FABRIC_TASK_MARKER)
            throw new common_1.ConflictException('Нарезка временно отключена. Резерв и нарезанные отрезы сохранены; обратитесь к администратору.');
        return null;
    }
    const record = await db.systemSetting.findUnique({ where: { key: `fabric.rolls.v1:${task.clientId}` } });
    const lines = record?.value ? fabricTaskLines(record.value, task) : null;
    if (!lines && task.sourceArticle === exports.FABRIC_TASK_MARKER)
        throw new common_1.ConflictException('Не найден резерв задания нарезки. Требуется сверка.');
    return lines;
}
async function requireFabricCutComplete(db, task) {
    const lines = await readFabricTaskLines(db, task);
    if (lines?.some(line => line.remainingUnits > 0)) {
        throw new common_1.ConflictException('Сначала отсканируйте все отрезы заказа. Метры учитываются при сканировании товара.');
    }
}
