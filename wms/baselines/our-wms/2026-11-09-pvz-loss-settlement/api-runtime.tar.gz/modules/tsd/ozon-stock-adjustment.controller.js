"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonStockAdjustmentController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const ozon_stock_adjustment_service_1 = require("./ozon-stock-adjustment.service");
// FIX: customers adjust their own requests; the service retains staff stock-write requirements.
let OzonStockAdjustmentController = class OzonStockAdjustmentController {
    service;
    constructor(service) {
        this.service = service;
    }
    syncPreview(id, user) { return this.service.syncPreview(id, user); }
    syncApply(id, body, user) { return this.service.syncApply(id, body, user); }
    view(id, user) { return this.service.view(id, user); }
    preview(id, user, body) { return this.service.preview(id, user, body); }
    start(id, body, user) { return this.service.start(id, body, user); }
    resume(id, user) { return this.service.resume(id, user); }
    cancel(id, user) { return this.service.cancel(id, user); }
};
exports.OzonStockAdjustmentController = OzonStockAdjustmentController;
__decorate([
    (0, common_1.Post)('sync-preview'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonStockAdjustmentController.prototype, "syncPreview", null);
__decorate([
    (0, common_1.Post)('sync-apply'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonStockAdjustmentController.prototype, "syncApply", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonStockAdjustmentController.prototype, "view", null);
__decorate([
    (0, common_1.Post)('preview'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonStockAdjustmentController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)('start'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonStockAdjustmentController.prototype, "start", null);
__decorate([
    (0, common_1.Post)('resume'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonStockAdjustmentController.prototype, "resume", null);
__decorate([
    (0, common_1.Post)('cancel'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonStockAdjustmentController.prototype, "cancel", null);
exports.OzonStockAdjustmentController = OzonStockAdjustmentController = __decorate([
    (0, common_1.Controller)('tsd/requests/:id/fbo/ozon-adjustment'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __metadata("design:paramtypes", [typeof (_a = typeof ozon_stock_adjustment_service_1.OzonStockAdjustmentService !== "undefined" && ozon_stock_adjustment_service_1.OzonStockAdjustmentService) === "function" ? _a : Object])
], OzonStockAdjustmentController);
