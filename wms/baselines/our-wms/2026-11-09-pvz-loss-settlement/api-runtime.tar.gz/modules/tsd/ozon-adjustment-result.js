"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adjustmentResultState = adjustmentResultState;
exports.adjustmentError = adjustmentError;
// FIX: ERROR is Ozon's terminal asynchronous failure, not a pending response.
function adjustmentResultState(status) {
    return status === 'SUCCESS' ? 'SUCCESS' : ['ERROR', 'FAILED'].includes(String(status)) ? 'FAILED' : 'ACCEPTED';
}
function adjustmentError(error) {
    if (!error)
        return undefined;
    const text = typeof error === 'string' ? error : JSON.stringify(error);
    if (text.includes('INBOUND_NO_CAPACITY'))
        return 'Ozon отклонил изменение: недостаточно места для приёмки на выбранном направлении (INBOUND_NO_CAPACITY). Уточните доступность поставки в кабинете Ozon. Короба в ВМС сохранены.';
    return text;
}
