"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reconciliationMode = reconciliationMode;
exports.physicalAdjustmentPlan = physicalAdjustmentPlan;
exports.reconciliationDirections = reconciliationDirections;
exports.remoteComposition = remoteComposition;
exports.reconciliationOperations = reconciliationOperations;
const common_1 = require("@nestjs/common");
const ozon_fbo_directions_1 = require("./ozon-fbo-directions");
const ozon_adjustment_policy_1 = require("./ozon-adjustment-policy");
const ozon_supply_policy_1 = require("../client-requests/ozon-supply-policy");
function reconciliationMode(value) {
    if (value !== 'AVAILABLE' && value !== 'PICKED')
        throw new common_1.BadRequestException('Выберите наличие или фактический отбор.');
    return value;
}
// FIX: derive physical quantities from persisted units, never from a route or stock balance.
function physicalAdjustmentPlan(s) {
    const r = s.request, a = r.fboAssembly;
    const units = (a?.units ?? []).filter((u) => u.state !== 'RETURNED');
    if (!units.length)
        throw new common_1.ConflictException('Нет отобранного товара. Используйте расчёт по наличию.');
    const late = ['CONTROL', 'COMPLETED'].includes(a?.phase);
    if (late && (units.some((u) => u.state !== 'PACKED') || !a.boxes.length || a.boxes.some((b) => !b.closedAt)))
        throw new common_1.ConflictException('На контроле требуется весь упакованный товар и закрытые короба.');
    if (units.some((u) => !['PICKED', 'PACKED'].includes(u.state) || !r.items.some((i) => i.skuId === u.skuId)))
        throw new common_1.ConflictException('Отобранные единицы требуют сверки.');
    for (const u of units.filter((u) => u.state === 'PACKED')) {
        const box = a.boxes.find((b) => b.boxId === u.targetBoxId);
        if (!box || !s.directions.some((d) => d.name === box.direction && d.items.some((i) => i.skuId === u.skuId)))
            throw new common_1.ConflictException('Не определено направление упакованной единицы.');
    }
    const directions = (0, ozon_fbo_directions_1.directionProgress)(s.directions, a.boxes, units);
    const lines = r.items.map((i) => ({ ...i, needed: i.quantity, picked: units.filter((u) => u.skuId === i.skuId).length }));
    if (lines.some((l) => l.picked > l.needed))
        throw new common_1.ConflictException('Отобрано больше плана. Требуется сверка.');
    return { needed: r.items.reduce((n, i) => n + i.quantity, 0), lines, directions, route: [], pendingLocations: [], physicalBasis: late ? 'PACKED' : 'PICKED' };
}
function reconciliationDirections(s, rows) {
    return s.directions.map((d) => ({ ...d, items: d.items.map((i) => ({ ...i, quantity: rows.find(r => r.direction === d.name && r.skuId === i.skuId).after })).filter((i) => i.quantity > 0) }));
}
// FIX: pin both remote contents and identifiers; read timestamps do not invalidate a preview.
function remoteComposition(link) {
    return { connectionId: link.connectionId, mapping: link.mapping, orders: (0, ozon_supply_policy_1.supplyOrders)(link).map(o => ({ orderId: o.orderId, state: o.state, supplies: o.supplies })) };
}
async function reconciliationOperations(s, fresh, directions, resolve) {
    const operations = [], comparison = [], used = new Set();
    for (const d of directions) {
        const supply = fresh.supplies.find(v => v.id === fresh.mapping[d.name]);
        const order = (0, ozon_supply_policy_1.supplyOrders)(fresh).find(o => o.supplies.some(v => v.id === supply?.id));
        if (!supply || !order || used.has(supply.id))
            throw new common_1.ConflictException('Нет однозначного соответствия направления Ozon.');
        used.add(supply.id);
        if (!d.items.length)
            throw new common_1.ConflictException('Направление стало пустым. Его отмена в Ozon требует отдельного решения.');
        const items = [];
        for (const i of d.items) {
            const matches = supply.items.filter(v => v.barcode === i.barcode);
            if (matches.length > 1)
                throw new common_1.ConflictException('Неоднозначный товар в Ozon.');
            const m = matches[0] ?? await resolve(i);
            if (!m?.offerId || !Number.isSafeInteger(Number(m.sku)) || Number(m.sku) <= 0)
                throw new common_1.ConflictException(`Не найден SKU Ozon для ШК ${i.barcode}.`);
            items.push({ sku: Number(m.sku), quantity: i.quantity, quant: m.quant || 1 });
        }
        if (new Set(items.map(i => i.sku)).size !== items.length)
            throw new common_1.ConflictException('Один SKU Ozon сопоставлен нескольким товарам.');
        let changed = false;
        for (const barcode of new Set([...supply.items.map(i => i.barcode), ...d.items.map((i) => i.barcode)])) {
            const before = s.directions.find((v) => v.name === d.name)?.items.filter((i) => i.barcode === barcode).reduce((n, i) => n + i.quantity, 0) ?? 0;
            const remote = supply.items.filter(i => i.barcode === barcode).reduce((n, i) => n + i.quantity, 0);
            const after = d.items.filter((i) => i.barcode === barcode).reduce((n, i) => n + i.quantity, 0);
            comparison.push({ direction: d.name, barcode, before, remote, after });
            if (remote !== after)
                changed = true;
        }
        if (changed)
            operations.push({ supplyId: supply.id, orderId: order.orderId, state: 'PENDING', items });
    }
    if (used.size !== fresh.supplies.length)
        throw new common_1.ConflictException('Есть поставка Ozon без направления ВМС.');
    return { operations, comparison, fingerprint: (0, ozon_adjustment_policy_1.adjustmentHash)(itemsIdentity(operations)) };
}
const itemsIdentity = (operations) => operations.map(o => [o.supplyId, o.orderId, o.items]);
