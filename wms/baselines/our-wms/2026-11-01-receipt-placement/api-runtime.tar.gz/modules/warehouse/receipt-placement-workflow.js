"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.placementReceipts = placementReceipts;
exports.lockPlacementReceipt = lockPlacementReceipt;
exports.recordPlacementAction = recordPlacementAction;
exports.assertPlacementReceipt = assertPlacementReceipt;
exports.receiptForPlacementBox = receiptForPlacementBox;
exports.placementTransaction = placementTransaction;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
const receipt_placement_report_1 = require("./receipt-placement-report");
const key = (warehouse, r) => "receipt.placement.v1:" +
    (0, node_crypto_1.createHash)("sha256")
        .update(JSON.stringify([warehouse, r.clientId, r.document]))
        .digest("hex");
async function placementReceipts(tx, warehouseId, clientIds, selected, includeRequests = false) {
    const rows = await tx.$queryRaw(client_1.Prisma.sql `${(0, receipt_placement_report_1.placementStockSql)(warehouseId, clientIds)}
 SELECT b.*,i."receiptAt",
 ${includeRequests
        ? client_1.Prisma.sql `ARRAY(SELECT DISTINCT r.number FROM "ClientRequestBoxSelection" bs
   JOIN "ClientRequestItem" ri ON ri.id=bs."requestItemId" JOIN "ClientRequest" r ON r.id=ri."requestId"
   WHERE bs."boxId"=b.id AND r."clientId"=b."clientId" AND r."warehouseId"=${warehouseId}
     AND r.status NOT IN ('DONE','CANCELLED') AND NOT b.placed)`
        : client_1.Prisma.sql `ARRAY[]::int[]`} AS requests,
 CASE WHEN m.value->>'clientId'=b."clientId" AND m.value->>'warehouseId'=${warehouseId} THEN m.value->>'series'
   WHEN i."receiptAt" IS NOT NULL THEN 'SERIES:'||extract(year from i."receiptAt")::int||':'||regexp_replace(b.code,'_[0-9]+$','') ELSE NULL END AS document
 FROM stocked b LEFT JOIN "ReceiptStockIdentity" i ON i."boxId"=b.id
 LEFT JOIN "SystemSetting" m ON m.key='receipt.membership.v1:'||b."clientId"||':'||b.id
 WHERE b."needsPlacement"`);
    const groups = new Map();
    for (const row of rows) {
        if (!row.document ||
            (selected &&
                (row.clientId !== selected.clientId ||
                    row.document !== selected.document)))
            continue;
        const id = key(warehouseId, {
            clientId: row.clientId,
            document: row.document,
        });
        const group = groups.get(id) ?? {
            id,
            clientId: row.clientId,
            client: row.client,
            document: row.document,
            date: row.receiptAt,
            receiving: false,
            total: 0,
            placed: 0,
            remaining: [],
            boxes: [],
            requests: [],
        };
        group.receiving = group.receiving || row.status === "receiving";
        group.total++;
        if (row.placed)
            group.placed++;
        else
            group.remaining.push(row.code);
        group.boxes.push(row.code);
        group.requests = Array.from(new Set([...group.requests, ...row.requests]));
        groups.set(id, group);
    }
    const result = Array.from(groups.values());
    const saved = await tx.systemSetting.findMany({
        where: {
            key: { startsWith: "receipt.placement.v1:" },
            AND: [
                { value: { path: ["warehouseId"], equals: warehouseId } },
                ...(clientIds
                    ? [
                        {
                            OR: clientIds.map((clientId) => ({
                                value: { path: ["clientId"], equals: clientId },
                            })),
                        },
                    ]
                    : []),
                ...(selected
                    ? [
                        { value: { path: ["clientId"], equals: selected.clientId } },
                        { value: { path: ["document"], equals: selected.document } },
                    ]
                    : []),
            ],
        },
    });
    const relevant = saved.filter((s) => s.value?.warehouseId === warehouseId &&
        (!clientIds || clientIds.includes(s.value.clientId)) &&
        (!selected ||
            (s.value.clientId === selected.clientId &&
                s.value.document === selected.document)));
    for (const s of relevant)
        if (!result.some((r) => r.id === s.key)) {
            result.push({
                id: s.key,
                clientId: s.value.clientId,
                client: s.value.client,
                document: s.value.document,
                date: s.value.date,
                total: 0,
                placed: 0,
                remaining: [],
                boxes: [],
                requests: [],
            });
        }
    for (const row of result) {
        const state = relevant.find((s) => s.key === row.id)?.value;
        row.status =
            row.remaining.length || row.receiving
                ? state?.status === "DEFERRED"
                    ? "DEFERRED"
                    : "OPEN"
                : "COMPLETED";
        row.history = state?.history ?? [];
        row.previouslyPlaced = row.remaining.filter((code) => row.history.some((h) => h.boxCode === code && ["PLACED", "COMPLETED"].includes(h.action)));
        row.excluded = (state?.initialBoxes ?? []).filter((b) => !row.boxes.includes(b));
    }
    for (const row of result) {
        row.exclusions = [];
        if (!row.excluded.length)
            continue;
        const boxes = await tx.box.findMany({
            where: { clientId: row.clientId, code: { in: row.excluded } },
            select: {
                code: true,
                status: true,
                warehouseId: true,
                client: {
                    select: { storesWithoutBoxes: true, stockBalanceMode: true },
                },
                balances: {
                    where: { warehouseId, quantity: { gt: 0 } },
                    select: { status: true, quantity: true },
                },
            },
        });
        row.exclusions = row.excluded.map((code) => {
            const box = boxes.find((b) => b.code === code);
            const reason = !box
                ? "Короб удалён"
                : box.warehouseId !== warehouseId
                    ? "Перемещён в другой филиал"
                    : ["archived", "deleted"].includes(box.status)
                        ? "Короб архивирован или удалён"
                        : box.client.storesWithoutBoxes
                            ? "Хранение без коробов"
                            : box.client.stockBalanceMode !== "PALLET_SORT"
                                ? "Изменён способ хранения"
                                : !box.balances.length
                                    ? "В коробе больше нет остатка"
                                    : box.balances.every((b) => ["PACKING", "SHIPPING", "IN_TRANSIT"].includes(b.status))
                                        ? "Передан в упаковку, отгрузку или транзит"
                                        : "Изменилось состояние хранения";
            return { boxCode: code, reason };
        });
    }
    return result
        .filter((r) => !r.receiving || relevant.some((s) => s.key === r.id))
        .sort((a, b) => (b.requests?.length ?? 0) - (a.requests?.length ?? 0) ||
        b.remaining.length - a.remaining.length);
}
// FIX: one advisory lock serializes changes for the same receipt across both managers.
async function lockPlacementReceipt(tx, warehouseId, r) {
    await tx.$executeRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(${key(warehouseId, r)},0))`);
}
async function recordPlacementAction(tx, warehouseId, r, action, user, boxCode) {
    const [current] = await placementReceipts(tx, warehouseId, [r.clientId], r);
    if (!current)
        throw new common_1.BadRequestException("Приёмка не найдена среди коробов с остатком.");
    const id = key(warehouseId, r), old = await tx.systemSetting.findUnique({ where: { key: id } });
    const state = old?.value ?? {};
    const completed = current.remaining.length === 0 && !current.receiving;
    const status = completed
        ? "COMPLETED"
        : action === "DEFER"
            ? "DEFERRED"
            : "OPEN";
    // TEST: a repeated completion does not add another closing event.
    if (!(completed && state.status === "COMPLETED")) {
        const event = {
            action: completed ? "COMPLETED" : action,
            at: new Date().toISOString(),
            worker: user.name,
            userId: user.id,
            boxCode: boxCode ?? null,
            remaining: current.remaining.length,
        };
        const value = {
            ...state,
            warehouseId,
            clientId: r.clientId,
            document: r.document,
            client: current.client,
            date: current.date,
            status,
            initialBoxes: Array.from(new Set([...(state.initialBoxes ?? []), ...current.boxes])),
            history: [...(state.history ?? []).slice(-199), event],
        };
        await tx.systemSetting.upsert({
            where: { key: id },
            create: { key: id, value },
            update: { value },
        });
        await tx.auditLog.create({
            data: {
                entity: "ReceiptPlacement",
                entityId: id,
                action: "RECEIPT_PLACEMENT_" + event.action,
                userId: user.id,
                payload: { ...event, warehouseId, ...r },
            },
        });
    }
    return { ...current, status, canFinish: completed };
}
async function assertPlacementReceipt(tx, warehouseId, r, boxCode) {
    const [current] = await placementReceipts(tx, warehouseId, [r.clientId], r);
    if (!current?.boxes.includes(boxCode))
        throw new common_1.ConflictException("Этот короб не относится к выбранной приёмке или уже выбыл из хранения.");
}
async function receiptForPlacementBox(tx, warehouseId, clientId, boxCode) {
    const rows = await tx.$queryRaw(client_1.Prisma.sql `SELECT
   CASE WHEN m.value->>'clientId'=b."clientId" AND m.value->>'warehouseId'=${warehouseId} THEN m.value->>'series'
     WHEN i."receiptAt" IS NOT NULL THEN 'SERIES:'||extract(year from i."receiptAt")::int||':'||regexp_replace(b.code,'_[0-9]+$','') ELSE NULL END AS document
   FROM "Box" b JOIN "Client" c ON c.id=b."clientId" LEFT JOIN "ReceiptStockIdentity" i ON i."boxId"=b.id
   LEFT JOIN "SystemSetting" m ON m.key='receipt.membership.v1:'||b."clientId"||':'||b.id
   WHERE b."warehouseId"=${warehouseId} AND b."clientId"=${clientId} AND b.code=${boxCode} AND b.status NOT IN ('archived','deleted')
     AND c."stockBalanceMode"='PALLET_SORT' AND NOT c."storesWithoutBoxes"
     AND EXISTS(SELECT 1 FROM "StockBalance" q WHERE q."boxId"=b.id AND q."warehouseId"=${warehouseId} AND q."clientId"=${clientId}
       AND q.quantity>0 AND q.status NOT IN ('PACKING','SHIPPING','IN_TRANSIT'))`);
    return rows[0]?.document ? { clientId, document: rows[0].document } : null;
}
// FIX: concurrent managers can retry a serialization rollback with the same box and receipt.
async function placementTransaction(db, operation, options) {
    const attempts = process.env.WMS_RECEIPT_PLACEMENT_ENABLED === "true" ? 4 : 1;
    for (let attempt = 0; attempt < attempts; attempt++) {
        try {
            return await db.$transaction(operation, options);
        }
        catch (error) {
            if (error?.code !== "P2034" || attempt === attempts - 1)
                throw error;
            await new Promise((resolve) => setTimeout(resolve, 20 * (attempt + 1)));
        }
    }
    throw new Error("Не удалось сохранить размещение.");
}
