"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.busyBoxes = busyBoxes;
exports.fboPickingCapacity = fboPickingCapacity;
const fbo_fbs_reservations_1 = require("./fbo-fbs-reservations");
const fbo_unplaced_picking_1 = require("./fbo-unplaced-picking");
const fbo_unboxed_picking_1 = require("./fbo-unboxed-picking");
const untouchedFbsRoute = (task) => !task.sourceBarcode && !task.barcode && !task.kiz && !task.relabelConfirmedAt &&
    ((task.status === 'RESERVED' && task.deviceCode === 'AUTO:FBS:PALLET_SORT' && !task.boxId) || task.status === 'IN_PROGRESS');
async function busyBoxes(tx, ids, requestId, allowUntouchedRoutes = false) {
    if (!ids.length)
        return new Set();
    const boxId = { in: ids };
    const [counts, tasks, selections, parcels] = await Promise.all([
        tx.inventoryAuditBox.findMany({ where: { boxId, status: { in: ['COUNTING', 'MISMATCH'] }, session: { status: { in: ['ACTIVE', 'REVIEW'] } } }, select: { boxId: true } }),
        tx.fbsTsdAssembly.findMany({ where: { OR: [{ boxId }, { reservedBoxId: boxId }], status: { in: ['RESERVED', 'IN_PROGRESS'] } } }),
        tx.clientRequestBoxSelection.findMany({ where: { boxId, requestItem: { request: { id: { not: requestId }, status: { in: ['APPROVED', 'IN_WORK'] } } } }, select: { boxId: true } }),
        tx.fboAssemblyBox.findMany({ where: { activeBoxId: boxId, requestId: { not: requestId } }, select: { activeBoxId: true } }),
    ]);
    return new Set([...counts.map(b => b.boxId), ...selections.map(b => b.boxId), ...parcels.map(b => b.activeBoxId),
        ...tasks.filter(t => !allowUntouchedRoutes || !untouchedFbsRoute(t)).flatMap(t => [t.boxId, t.reservedBoxId])].filter((id) => !!id));
}
// FIX: count eligible stock without exposing warehouse locations to the client.
async function fboPickingCapacity(tx, clientId, warehouseId, skuIds) {
    const client = await tx.client.findUniqueOrThrow({ where: { id: clientId }, select: { storesWithoutBoxes: true, stockBalanceMode: true } });
    const scope = { id: 'preview', clientId, warehouseId };
    if (client.storesWithoutBoxes)
        return (0, fbo_unboxed_picking_1.unboxedFboEnabled)() ? (0, fbo_unboxed_picking_1.unboxedFree)(tx, scope, skuIds) : new Map();
    const boxes = await tx.box.findMany({ where: { clientId, warehouseId, status: 'active', balances: { some: { skuId: { in: skuIds }, status: 'AVAILABLE', quantity: { gt: 0 } } } },
        select: { id: true, storagePlacement: { select: { id: true } }, balances: { where: { skuId: { in: skuIds }, status: 'AVAILABLE', quantity: { gt: 0 } }, select: { skuId: true, quantity: true, sku: { select: { needsChestnyZnak: true, isUnmarked: true } } } }, productMarks: { where: { skuId: { in: skuIds }, status: 'AVAILABLE' }, select: { skuId: true } } } });
    const blocked = await busyBoxes(tx, boxes.map(b => b.id), scope.id, true);
    const accepted = await (0, fbo_unplaced_picking_1.confirmedUnplacedFboBoxes)(tx, scope, boxes.filter(b => !b.storagePlacement).map(b => b.id));
    const availability = await (0, fbo_fbs_reservations_1.loadFboFbsAvailability)(tx, scope, skuIds);
    const totals = new Map();
    for (const box of boxes) {
        if (blocked.has(box.id) || (client.stockBalanceMode === 'PALLET_SORT' && !box.storagePlacement && !accepted.has(box.id)))
            continue;
        const marks = new Map();
        for (const m of box.productMarks)
            marks.set(m.skuId, (marks.get(m.skuId) ?? 0) + 1);
        for (const row of box.balances) {
            const marked = row.sku.needsChestnyZnak && !row.sku.isUnmarked;
            const count = Math.min(row.quantity, availability.free(box.id, row.skuId), marked ? (marks.get(row.skuId) ?? 0) : Infinity);
            if (count <= 0)
                continue;
            if (marked)
                marks.set(row.skuId, (marks.get(row.skuId) ?? 0) - count);
            availability.take(box.id, row.skuId, count);
            totals.set(row.skuId, (totals.get(row.skuId) ?? 0) + count);
        }
    }
    return totals;
}
