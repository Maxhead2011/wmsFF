"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routeBoxSelect = void 0;
exports.preparePickingBoxes = preparePickingBoxes;
// FIX: routing needs mark identities and stock states, not full receipt records.
exports.routeBoxSelect = {
    id: true, code: true,
    balances: { select: { skuId: true, quantity: true, status: true } },
    productMarks: { where: { status: { not: 'SHIPPING' } }, select: { value: true, skuId: true, status: true } },
    storagePlacement: { select: { pallet: { select: { code: true, zone: { select: { name: true } } } } } },
    pallet: { select: { code: true } }, zone: { select: { name: true } },
};
const naturalOrder = new Intl.Collator('ru', { numeric: true });
function preparePickingBoxes(boxes, lines) {
    const marked = new Set();
    for (const box of boxes) {
        for (const mark of box.productMarks)
            if (mark.status === 'AVAILABLE')
                marked.add(mark.skuId);
    }
    for (const line of lines)
        if (marked.has(line.skuId))
            line.requiresKiz = true;
    const palletCode = (box) => box.storagePlacement?.pallet.code ?? box.pallet?.code ?? '';
    boxes.sort((a, b) => naturalOrder.compare(palletCode(a), palletCode(b)) || naturalOrder.compare(a.code, b.code));
}
