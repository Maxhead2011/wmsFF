'use strict';
const C=require('@nestjs/common'),{randomUUID,createHash}=require('crypto');
const {PrismaService}=require('../../common/prisma/prisma.service');
const {ClientScopeService}=require('../auth/client-scope.service');
const {StockOperationsService}=require('../stock/stock-operations.service');
const {CurrentUser}=require('../auth/decorators/current-user.decorator');
const {RequirePermissions}=require('../auth/decorators/require-permissions.decorator');
const CLIENTS=new Set(['1757a389-c0d4-49b5-9347-2bde0c549260','76a39f04-d03c-4da0-9512-89ad796e9e32']);
const COLORS={black:'Чёрный',white:'Белый',green:'Зелёный',red:'Красный',ivory:'Айвори / шампань'};
const LENGTHS=new Set([1,3,5,10,20,30,50]);
const ROLL_LITERS=24.740; // pi * (15/2)^2 * 140 / 1000, rounded to native 0.001 L precision.
function fabricSku(sku){
 if(!/ткань/i.test(sku.name))return null;
 const m=/^(gab_)?(black|white|green|red|ivory)_(1|3|5|10|20|30|50)(?:-0)?$/.exec(sku.internalSku||'');
 if(!m)return null;
 const material=m[1]?'GABARDINE':'SATIN',color=m[2],meters=Number(m[3]);
 return {skuId:sku.id,name:sku.name,material,color,colorName:COLORS[color],meters,key:material+':'+color,requiresKiz:sku.needsChestnyZnak&&!sku.isUnmarked,barcodes:(sku.barcodes||[]).map(b=>b.value)};
}
function integer(v,min,max,label){if(!Number.isSafeInteger(v)||v<min||v>max)throw new C.BadRequestException(label);return v;}
function applyRollAction(state,dto,sku,warehouseId){
 state=structuredClone(state);state.rolls??=[];
 if(dto.action==='RECEIVE'){
  if(!['SATIN','GABARDINE'].includes(dto.material)||!COLORS[dto.color])throw new C.BadRequestException('Укажите тип ткани и цвет.');
  const count=integer(dto.count,1,500,'Количество рулонов: от 1 до 500.');
  if(state.rolls.length+count>10000)throw new C.BadRequestException('Лимит реестра рулонов.');
  for(let i=0;i<count;i++)state.rolls.push({id:randomUUID(),code:'R-'+randomUUID().slice(0,8).toUpperCase(),warehouseId,material:dto.material,color:dto.color,initialMm:100000,remainingMm:100000,cutMm:0,adjustmentMm:0,volumeLiters:ROLL_LITERS,lengthCm:140,diameterCm:15,createdAt:new Date().toISOString()});
 }else{
  const roll=state.rolls.find(r=>r.id===dto.rollId&&r.warehouseId===warehouseId);
  if(!roll)throw new C.BadRequestException('Рулон не найден в выбранном филиале.');
  if(dto.action==='CUT'){
   if(!sku||sku.material!==roll.material||sku.color!==roll.color)throw new C.BadRequestException('Баркод относится к другой ткани или цвету.');
   const count=integer(dto.count,1,500,'Количество отрезов: от 1 до 500.'),mm=sku.meters*1000*count;
   if(mm>roll.remainingMm)throw new C.BadRequestException('В выбранном рулоне недостаточно метров. Выберите другой рулон или подтвердите фактическую корректировку.');
   roll.remainingMm-=mm;roll.cutMm+=mm;
  }else if(dto.action==='WRITE_OFF'){
   if(roll.writtenOffAt||roll.remainingMm<=0)throw new C.BadRequestException('Рулон уже списан или израсходован.');
   if(typeof dto.reason!=='string'||dto.reason.trim().length<5||dto.reason.trim().length>1000)throw new C.BadRequestException('Укажите причину списания: от 5 до 1000 символов.');
   roll.writtenOffMm=roll.remainingMm;roll.remainingMm=0;roll.writtenOffAt=new Date().toISOString();roll.writeOffReason=dto.reason.trim();
  }else if(dto.action==='ADJUST'){
   if(roll.writtenOffAt)throw new C.BadRequestException('Списанный рулон нельзя корректировать.');
   const mm=integer(dto.deltaMm,-2000,2000,'Корректировка рулона: не более ±2 м.');
   if(mm===0||Math.abs(roll.adjustmentMm+mm)>2000||roll.remainingMm+mm<0)throw new C.BadRequestException('Недопустимая корректировка; суммарный допуск ±2 м.');
   if(typeof dto.reason!=='string'||dto.reason.trim().length<5)throw new C.BadRequestException('Укажите причину корректировки.');
   roll.remainingMm+=mm;roll.adjustmentMm+=mm;
  }else throw new C.BadRequestException('Неизвестное действие.');
 }
 return state;
}
class FabricRollsController{
 constructor(db,scopes,operations){this.db=db;this.scopes=scopes;this.operations=operations;}
 key(id){return 'fabric.rolls.v1:'+id;}
 async check(id,user,write=false){
  if(user.isDemo)throw new C.NotFoundException('Рулонный учёт недоступен в демо-режиме.');
  this.scopes.requireClientAccess(user,id,write?'write':'read');
  if(write){
   if(!user.permissionCodes.some(p=>['stock:write','system:admin'].includes(p)))throw new C.ForbiddenException('Нет прав на изменение остатков.');
   if(user.roleCodes?.includes('CLIENT'))throw new C.ForbiddenException('Клиенту доступен только просмотр.');
  }
 }
 async get(id,user){
  await this.check(id,user);
  const enabled=await this.db.systemSetting.findUnique({where:{key:'fabric.rolls.enabled.v1:'+id}});
  if(enabled?.value?.enabled!==true)return {clientId:id,enabled:false};
  const setting=await this.db.systemSetting.findUnique({where:{key:this.key(id)}}),state=setting?.value||{rolls:[]};
  const skus=(await this.db.sku.findMany({where:{clientId:id},include:{barcodes:true}})).map(fabricSku).filter(Boolean);
  const balances=await this.db.stockBalance.findMany({where:{clientId:id,skuId:{in:skus.map(s=>s.skuId)},quantity:{gt:0}},select:{skuId:true,quantity:true,status:true,warehouseId:true}});
  const byId=new Map(skus.map(s=>[s.skuId,s]));
  const groups=new Map();
  for(const sku of skus)if(!groups.has(sku.key))groups.set(sku.key,{key:sku.key,material:sku.material,color:sku.color,colorName:sku.colorName,whole:0,open:0,rawMeters:0,rolls:[],ready:[],fbs:{pieces:0,meters:0},fbo:{pieces:0,meters:0}});
  for(const r of state.rolls){const key=r.material+':'+r.color;if(!groups.has(key))groups.set(key,{key,material:r.material,color:r.color,colorName:COLORS[r.color],whole:0,open:0,rawMeters:0,rolls:[],ready:[],fbs:{pieces:0,meters:0},fbo:{pieces:0,meters:0}});const g=groups.get(key);if(r.remainingMm>0){r.cutMm===0&&!(r.shippedMm>0)?g.whole++:g.open++;g.rawMeters+=r.remainingMm/1000;}g.rolls.push(r);}
  for(const b of balances){const s=byId.get(b.skuId),g=groups.get(s.key);let row=g.ready.find(r=>r.skuId===s.skuId);if(!row){row={skuId:s.skuId,meters:s.meters,pieces:0,reserved:0};g.ready.push(row);}row.pieces+=b.quantity;if(['PACKING','SHIPPING'].includes(b.status))row.reserved+=b.quantity;}
  // Confirmed shipment facts, not corrective SHIP ledger rows: no double counting repairs.
  const facts=await this.db.wbOrderShipment.findMany({where:{clientId:id,skuId:{in:skus.map(s=>s.skuId)}},select:{id:true,skuId:true,quantity:true}});
  for(const f of facts){const s=byId.get(f.skuId),g=groups.get(s.key);g.fbs.pieces+=f.quantity;g.fbs.meters+=f.quantity*s.meters;}
  const requests=await this.db.clientRequest.findMany({where:{clientId:id,status:'DONE',fboAssembly:{isNot:null}},select:{items:{select:{skuId:true,quantity:true}}}});
  for(const r of requests)for(const i of r.items){const s=byId.get(i.skuId);if(s){const g=groups.get(s.key);g.fbo.pieces+=i.quantity;g.fbo.meters+=i.quantity*s.meters;}}
  for(const g of groups.values())g.rawLiters=Math.round(g.rolls.reduce((s,r)=>s+r.remainingMm/100000*(r.volumeLiters||ROLL_LITERS),0)*1000)/1000;
  return {clientId:id,enabled:true,version:setting?.updatedAt?.toISOString()||null,nominalMeters:100,toleranceMeters:2,rollVolumeLiters:ROLL_LITERS,lengthCm:140,diameterCm:15,groups:[...groups.values()],skus,shipmentPending:state.shipmentPending||[],history:await this.db.auditLog.findMany({where:{entity:'FabricRolls',entityId:id},orderBy:{createdAt:'desc'},take:30,select:{action:true,createdAt:true,payload:true}})};
 }
 async enable(id,dto,user){
  await this.check(id,user);
  this.scopes.requireClientAccess(user,id,'write');
  if(!user.permissionCodes.some(p=>['clients:write','system:admin'].includes(p))||user.roleCodes?.includes('CLIENT'))throw new C.ForbiddenException('Нет прав на настройки клиента.');
  if(typeof dto?.enabled!=='boolean')throw new C.BadRequestException('Укажите enabled.');
  await this.db.$transaction(async tx=>{await tx.$executeRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))',this.key(id));
   const client=await tx.client.findUnique({where:{id},select:{isDemo:true}});if(!client||client.isDemo)throw new C.NotFoundException('Клиент не найден.');
   await tx.systemSetting.upsert({where:{key:'fabric.rolls.enabled.v1:'+id},create:{key:'fabric.rolls.enabled.v1:'+id,value:{enabled:dto.enabled},updatedByUserId:user.id},update:{value:{enabled:dto.enabled},updatedByUserId:user.id}});
   await tx.auditLog.create({data:{userId:user.id,action:'FABRIC_ROLLS_ENABLED_CHANGED',entity:'FabricRolls',entityId:id,payload:{enabled:dto.enabled}}});
  });return this.get(id,user);
 }
 async save(id,dto,user){
  await this.check(id,user,true);
  const enabled=await this.db.systemSetting.findUnique({where:{key:'fabric.rolls.enabled.v1:'+id}});if(enabled?.value?.enabled!==true)throw new C.BadRequestException('Включите рулонный учёт в настройке клиента.');
  if(!dto||typeof dto.operationKey!=='string'||!/^[a-zA-Z0-9-]{16,100}$/.test(dto.operationKey))throw new C.BadRequestException('Нужен ключ операции.');
  const warehouseId=user.activeWarehouseId;
  if(!warehouseId)throw new C.BadRequestException('Выберите рабочий филиал.');
  const membership=await this.db.warehouseClient.findFirst({where:{clientId:id,warehouseId}});
  if(!membership)throw new C.ForbiddenException('Клиент не подключён к филиалу.');
  await this.operations.inventoryLock?.assertStockMovementsAllowed();
  const hash=createHash('sha256').update(JSON.stringify(dto)).digest('hex'),auditId='fabric-'+dto.operationKey;
  await this.db.$transaction(async tx=>{
   await tx.$executeRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))',this.key(id));
   const active=await tx.systemSetting.findUnique({where:{key:'fabric.rolls.enabled.v1:'+id}});if(active?.value?.enabled!==true)throw new C.ConflictException('Рулонный учёт выключен.');
   const existing=await tx.auditLog.findUnique({where:{id:auditId}});
   if(existing){if(existing.entityId!==id||existing.payload?.hash!==hash)throw new C.ConflictException('Ключ уже использован для другой операции.');return;}
   const previous=await tx.systemSetting.findUnique({where:{key:this.key(id)}}),before=previous?.value||{rolls:[]};
   if((previous?.updatedAt?.toISOString()||null)!==(dto.version??null))throw new C.ConflictException('Данные изменились. Обновите экран.');
   let sku=null,rawSku=null;
   if(dto.action==='CUT'){
    if(typeof dto.barcode!=='string'||!dto.barcode.trim())throw new C.BadRequestException('Отсканируйте баркод отреза.');
    const matches=await tx.sku.findMany({where:{clientId:id,barcodes:{some:{value:dto.barcode.trim()}}},include:{barcodes:true}});
    if(matches.length!==1||!(sku=fabricSku(matches[0])))throw new C.BadRequestException('Баркод не привязан однозначно к отрезу 1/3/5/10/20/30/50 м.');
    rawSku=matches[0];
   }
   const after=applyRollAction(before,dto,sku,warehouseId);
   if(dto.action==='CUT'){
    if(typeof dto.boxCode!=='string'||!dto.boxCode.trim())throw new C.BadRequestException('Укажите короб готовых отрезов.');
    const box=await tx.box.findFirst({where:{code:dto.boxCode.trim(),clientId:id,warehouseId,status:{notIn:['deleted','archived']}},include:{storagePlacement:true}});
    if(!box)throw new C.BadRequestException('Сначала создайте и разместите короб этого клиента в выбранном филиале.');
    if(!box.storagePlacement)throw new C.BadRequestException('Разместите короб на паллет-сорте, чтобы отрезы были доступны для сборки.');
    const marks=typeof dto.kiz==='string'?dto.kiz.split(/\r?\n/).map(x=>x.trim()).filter(Boolean):[];
    if(sku.requiresKiz&&(marks.length!==dto.count||new Set(marks).size!==marks.length))throw new C.BadRequestException('Для каждого отреза нужен отдельный КИЗ.');
    if(marks.length&&marks.length!==dto.count)throw new C.BadRequestException('Количество КИЗ не совпадает с количеством отрезов.');
    if(marks.length){for(let i=0;i<marks.length;i++)await this.operations.receiveIntoBox({clientId:id,warehouseId,skuId:rawSku.id,barcode:dto.barcode.trim(),boxCode:box.code,quantity:1,status:'AVAILABLE',kiz:marks[i],sourceDocument:auditId,idempotencyKey:auditId+':'+i,comment:'Нарезка из рулона '+dto.rollId},user,tx,'INVENTORY_ADJUSTMENT');}
    else await this.operations.receiveIntoBox({clientId:id,warehouseId,skuId:rawSku.id,barcode:dto.barcode.trim(),boxCode:box.code,quantity:dto.count,status:'AVAILABLE',sourceDocument:auditId,idempotencyKey:auditId,comment:'Нарезка из рулона '+dto.rollId},user,tx,'INVENTORY_ADJUSTMENT');
   }
   await tx.systemSetting.upsert({where:{key:this.key(id)},create:{key:this.key(id),value:after,updatedByUserId:user.id},update:{value:after,updatedByUserId:user.id}});
   const affected=after.rolls.find(r=>r.id===dto.rollId);
   const material=dto.material||sku?.material||affected?.material,color=dto.color||sku?.color||affected?.color;
   const beforeMm=before.rolls.filter(r=>r.warehouseId===warehouseId&&r.material===material&&r.color===color).reduce((s,r)=>s+r.remainingMm,0),afterMm=after.rolls.filter(r=>r.warehouseId===warehouseId&&r.material===material&&r.color===color).reduce((s,r)=>s+r.remainingMm,0);
   await tx.auditLog.create({data:{id:auditId,userId:user.id,action:'FABRIC_ROLL_'+dto.action,entity:'FabricRolls',entityId:id,payload:{hash,warehouseId,action:dto.action,rollId:dto.rollId||null,material,color,count:dto.count||null,cutMeters:sku?sku.meters*dto.count:0,deltaMm:dto.deltaMm||0,storageRollEquivalentDelta:(afterMm-beforeMm)/100000,volumeLiters:ROLL_LITERS,lengthCm:140,diameterCm:15,reason:dto.reason?.trim()||null,writtenOffMeters:dto.action==='WRITE_OFF'?(affected?.writtenOffMm||0)/1000:0,skuId:rawSku?.id||null,addedRollIds:after.rolls.filter(r=>!before.rolls.some(b=>b.id===r.id)).map(r=>r.id)}}});
   await require('./fabric-shipment-accounting').syncFabricShipments(tx,id,user.id);
  },{timeout:60000});
  return this.get(id,user);
 }
}
Reflect.defineMetadata('design:paramtypes',[PrismaService,ClientScopeService,StockOperationsService],FabricRollsController);
C.Controller('warehouse/fabric-rolls/:clientId')(FabricRollsController);RequirePermissions('clients:read')(FabricRollsController);
for(const [name,method] of [['get',C.Get],['save',C.Post],['enable',C.Put]]){
 const desc=Object.getOwnPropertyDescriptor(FabricRollsController.prototype,name);method()(FabricRollsController.prototype,name,desc);
 C.Param('clientId')(FabricRollsController.prototype,name,0);
 if(name!=='get'){C.Body()(FabricRollsController.prototype,name,1);CurrentUser()(FabricRollsController.prototype,name,2);RequirePermissions(name==='save'?'stock:write':'clients:write')(FabricRollsController.prototype,name,desc);}
 else CurrentUser()(FabricRollsController.prototype,name,1);
}
module.exports={FabricRollsController,fabricSku,applyRollAction,CLIENTS};
