"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.canManageReceiptDirections = canManageReceiptDirections;
// FIX: client managers use their existing writable client scope, without personal grants.
async function canManageReceiptDirections(_db, user, clientId) {
    if (process.env.WMS_RECEIPT_CHANNELS_ENABLED !== 'true' || user.isDemo)
        return false;
    if (user.roleCodes.some(role => role === 'ADMIN' || role === 'OWNER')) {
        return user.permissionCodes.some(permission => permission === 'warehouse:write' || permission === 'system:admin');
    }
    return user.roleCodes.includes('CLIENT') && Boolean(user.writableClientIds?.includes(clientId));
}
