"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rememberPackedUnit = rememberPackedUnit;
exports.packedUnitForUndo = packedUnitForUndo;
const common_1 = require("@nestjs/common");
// FIX: keep an immutable receipt for the exact packed unit, not a barcode-based guess.
async function rememberPackedUnit(tx, unit, actorId, key) {
    if (process.env.WMS_FBO_PACK_UNDO_ENABLED !== 'true')
        return;
    await tx.auditLog.create({ data: { id: `fbo-pack:${key}`, userId: actorId, action: 'FBO_PACK_UNDO_RECEIPT', entity: 'FboAssemblyUnit', entityId: key,
            payload: { unitId: unit.id, requestId: unit.requestId, boxId: unit.targetBoxId, packedAt: unit.packedAt.toISOString() } } });
}
// FIX: run inside the request's existing Serializable transaction and lock.
async function packedUnitForUndo(tx, requestId, operationId, actorId) {
    if (process.env.WMS_FBO_PACK_UNDO_ENABLED !== 'true')
        throw new common_1.ConflictException('Отмена упаковки выключена.');
    if (!operationId)
        throw new common_1.ConflictException('Нет последней единицы для отмены.');
    const receipt = await tx.auditLog.findUnique({ where: { id: `fbo-pack:${requestId}:${operationId}` } });
    const p = receipt?.payload;
    if (!p?.unitId || p.requestId !== requestId || receipt?.userId !== actorId)
        throw new common_1.ConflictException('Подтверждение этой упаковки не найдено.');
    const unit = await tx.fboAssemblyUnit.findUnique({ where: { id: p.unitId } });
    if (!unit || unit.requestId !== requestId || unit.state !== 'PACKED' || unit.wholeBox || unit.targetBoxId !== p.boxId ||
        unit.packedByUserId !== actorId || unit.packedAt?.toISOString() !== p.packedAt)
        throw new common_1.ConflictException('Единица уже отменена или её упаковка изменилась.');
    const box = await tx.fboAssemblyBox.findUnique({ where: { activeBoxId: unit.targetBoxId } });
    if (!box || box.requestId !== requestId || box.closedAt || box.confirmedAt || box.wholeBox)
        throw new common_1.ConflictException('Отмена доступна только в открытом коробе.');
    // Indexed request/createdAt lookup; never scan the complete audit history.
    const later = await tx.fboAssemblyAction.findFirst({ where: { requestId, actorId, id: { not: `${requestId}:${operationId}` }, createdAt: { gte: receipt.createdAt } } });
    if (later)
        throw new common_1.ConflictException('После упаковки выполнена другая операция. Можно отменить только последнюю единицу.');
    return unit;
}
