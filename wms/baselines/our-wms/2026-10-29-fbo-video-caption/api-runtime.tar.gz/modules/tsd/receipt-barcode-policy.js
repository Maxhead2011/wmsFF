"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.receiptBarcodeReviewEnabled = void 0;
exports.receiptBarcodeRisk = receiptBarcodeRisk;
exports.requireReceiptReviewer = requireReceiptReviewer;
exports.isBarcodeReview = isBarcodeReview;
const common_1 = require("@nestjs/common");
const receiptBarcodeReviewEnabled = () => process.env.WMS_RECEIPT_BARCODE_REVIEW_ENABLED === 'true';
exports.receiptBarcodeReviewEnabled = receiptBarcodeReviewEnabled;
// FIX: an existing approved card may intentionally use an internal barcode.
function receiptBarcodeRisk(code, known) {
    if (known)
        return null;
    if (!/^\d{12,14}$/.test(code))
        return 'Необычная длина или формат неизвестного ШК';
    let total = 0;
    for (let i = code.length - 2, weight = 3; i >= 0; i--, weight = weight === 3 ? 1 : 3)
        total += Number(code[i]) * weight;
    return (10 - total % 10) % 10 === Number(code.at(-1)) ? null : 'Контрольная цифра неизвестного ШК не совпадает';
}
function requireReceiptReviewer(user) {
    if (user.isDemo || !user.roleCodes.some(r => r === 'ADMIN' || r === 'OWNER'))
        throw new common_1.ForbiddenException('Разбор доступен администратору и собственнику.');
}
function isBarcodeReview(payload) {
    return !!payload && typeof payload === 'object' && payload.barcodeReview === 'PENDING';
}
