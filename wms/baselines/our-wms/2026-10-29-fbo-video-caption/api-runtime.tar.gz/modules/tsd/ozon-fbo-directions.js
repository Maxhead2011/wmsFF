"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.directionProgress = directionProgress;
exports.assertDirectionCapacity = assertDirectionCapacity;
const common_1 = require("@nestjs/common");
// FIX: one shared pick pool; only physical target boxes assign units to destinations.
function directionProgress(directions, boxes, units) {
    return directions.map(d => {
        const ids = new Set(boxes.filter(b => b.direction === d.name).map(b => b.boxId));
        const items = d.items.map(i => ({ ...i, packed: units.filter(u => u.state === 'PACKED' && u.skuId === i.skuId && !!u.targetBoxId && ids.has(u.targetBoxId)).length }));
        return { name: d.name, needed: items.reduce((s, i) => s + i.quantity, 0), packed: items.reduce((s, i) => s + i.packed, 0), items };
    });
}
function assertDirectionCapacity(directions, boxes, units, name, added) {
    const d = directionProgress(directions, boxes, units).find(d => d.name === name);
    if (!d)
        throw new common_1.ConflictException('Выберите направление поставки для короба.');
    const counts = new Map();
    for (const u of added)
        counts.set(u.skuId, (counts.get(u.skuId) ?? 0) + 1);
    for (const [sku, n] of counts) {
        const item = d.items.find(i => i.skuId === sku);
        if (!item || item.packed + n > item.quantity)
            throw new common_1.ConflictException(`Товар не требуется или превышено количество для направления «${name}».`);
    }
}
