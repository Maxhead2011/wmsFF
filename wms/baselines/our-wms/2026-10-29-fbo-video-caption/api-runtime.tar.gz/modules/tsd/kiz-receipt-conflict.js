"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.receiptConflictDetails = receiptConflictDetails;
exports.receiptConflictFromError = receiptConflictFromError;
function receiptConflictDetails(value) {
    if (process.env.WMS_KIZ_CLIENT_GUARD_ENABLED !== 'true' || !value || typeof value !== 'object')
        return;
    const row = value;
    if (row.code !== 'KIZ_DUPLICATE' || row.duplicate !== true || !row.duplicateInfo ||
        typeof row.duplicateInfo !== 'object' || Array.isArray(row.duplicateInfo))
        return;
    return { code: 'KIZ_DUPLICATE', duplicate: true, duplicateInfo: row.duplicateInfo };
}
function receiptConflictFromError(error) {
    const e = error;
    return typeof e?.getResponse === 'function' ? receiptConflictDetails(e.getResponse()) : undefined;
}
