"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lamodaRelabelLabels = lamodaRelabelLabels;
exports.assertLamodaRelabelScan = assertLamodaRelabelScan;
exports.assertLamodaRelabelPacked = assertLamodaRelabelPacked;
exports.readLamodaRelabelLabels = readLamodaRelabelLabels;
exports.assertLamodaRelabelRecovery = assertLamodaRelabelRecovery;
exports.resolveLamodaRelabelUnit = resolveLamodaRelabelUnit;
const kiz_physical_identity_1 = require("../../common/kiz-physical-identity");
const common_1 = require("@nestjs/common");
// FIX: freeze the marketplace identity; never print a warehouse alias or guess a size.
function lamodaRelabelLabels(lines, cards) {
    const labels = new Map();
    for (const line of lines) {
        const matches = cards.filter(p => p.isPresent && p.linkState === 'CONFIRMED' && p.skuId && p.barcode === line.barcode &&
            (!line.remoteSku || p.remoteSku === line.remoteSku) && (!line.article || [p.externalSku, p.remoteSku].includes(line.article)));
        if (matches.length !== 1)
            throw new common_1.ConflictException('Переклейка Lamoda: подтвердите однозначное соответствие каждой строки.');
        const p = matches[0];
        if (!/^\d{8,14}$/.test(p.barcode ?? ''))
            throw new common_1.ConflictException('В карточке Lamoda нет корректного товарного ШК.');
        const label = { skuId: p.skuId, barcode: p.barcode, article: p.remoteSku, name: p.name, size: p.size };
        const old = labels.get(label.skuId);
        if (old && JSON.stringify(old) !== JSON.stringify(label))
            throw new common_1.ConflictException('Один складской товар связан с разными этикетками Lamoda. Уточните соответствия.');
        labels.set(label.skuId, label);
    }
    return [...labels.values()];
}
function assertLamodaRelabelScan(expected, scanned, printStatus) {
    if (printStatus !== 'PRINTED')
        throw new common_1.ConflictException('Дождитесь подтверждения печати этикетки Lamoda.');
    if (scanned?.trim() !== expected)
        throw new common_1.ConflictException('Отсканирован не тот ШК Lamoda. Проверьте товар и размер.');
}
function assertLamodaRelabelPacked(required, confirmedAt) {
    if (required && !confirmedAt)
        throw new common_1.ConflictException('Сначала напечатайте этикетку Lamoda и подтвердите переклейку сканированием нового ШК.');
}
async function readLamodaRelabelLabels(tx, assembly) {
    if (Array.isArray(assembly.relabelLabels))
        return assembly.relabelLabels;
    const plan = await tx.lamodaPlan.findUniqueOrThrow({ where: { id: assembly.planId } });
    const cards = await tx.lamodaProduct.findMany({ where: { accountId: plan.accountId, isPresent: true, linkState: 'CONFIRMED' } });
    return lamodaRelabelLabels(plan.items, cards);
}
// FIX: administrative bulk recovery has no physical label scan; use normal unit packing.
async function assertLamodaRelabelRecovery(tx, request) {
    if (process.env.WMS_LAMODA_ENABLED !== 'true')
        return;
    const binding = await tx.lamodaFboAssembly.findUnique({ where: { requestId: request.id } });
    if (binding && (binding.relabelLabels || request.client.relabelingEnabled && process.env.WMS_LAMODA_FBO_RELABEL_ENABLED === 'true'))
        throw new common_1.ConflictException('Товар Lamoda с переклейкой упаковывается только через поштучное сканирование.');
}
// FIX: choose by warehouse identity, never by a manually selected marketplace row.
function resolveLamodaRelabelUnit(units, lines, scan, kiz) {
    const barcode = typeof scan === 'string' ? scan.trim() : '';
    if (!barcode)
        throw new common_1.ConflictException('Сканируйте складской ШК товара.');
    const found = units.filter(u => u.sourceBarcode === barcode || lines.some(l => l.skuId === u.skuId && (l.barcode === barcode || l.barcodes?.includes(barcode))));
    if (!found.length)
        throw new common_1.ConflictException('Этот товар не отобран или уже прошёл переклейку.');
    if (new Set(found.map(u => u.skuId)).size !== 1)
        throw new common_1.ConflictException('ШК связан с разными товарами. Уточните соответствия.');
    if (found.some(u => !u.label) || new Set(found.map(u => JSON.stringify(u.label))).size !== 1)
        throw new common_1.ConflictException('Нет однозначного соответствия Lamoda.');
    const identity = (s) => (0, kiz_physical_identity_1.physicalKizIdentity)(s) || s.trim();
    if (found.some(u => u.kiz)) {
        if (!kiz)
            throw new common_1.ConflictException('Сканируйте КИЗ этой единицы.');
        const exact = found.filter(u => u.kiz && identity(u.kiz) === identity(kiz));
        if (exact.length !== 1)
            throw new common_1.ConflictException('КИЗ не соответствует отобранному товару.');
        return exact[0];
    }
    if (kiz)
        throw new common_1.ConflictException('Для этого товара КИЗ не ожидается.');
    return [...found].sort((a, b) => Number(!!b.printId) - Number(!!a.printId) || a.id.localeCompare(b.id))[0];
}
