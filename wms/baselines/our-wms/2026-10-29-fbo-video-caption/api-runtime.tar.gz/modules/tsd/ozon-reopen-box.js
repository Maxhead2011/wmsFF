"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonReopenSupported = ozonReopenSupported;
exports.reopenOzonBox = reopenOzonBox;
const common_1 = require("@nestjs/common");
const ozon_supply_policy_1 = require("../client-requests/ozon-supply-policy");
// FIX: reopening is navigation within the existing destination, never manual stock insertion.
function ozonReopenSupported(shipment) {
    if (!shipment || process.env.WMS_OZON_REOPEN_BOX_ENABLED !== 'true')
        return false;
    try {
        (0, ozon_supply_policy_1.assertSupplyMutable)(shipment.integration, 'REOPEN_BOX');
        return true;
    }
    catch {
        return false;
    }
}
async function reopenOzonBox(tx, shipment, requestId, box, direction) {
    if (!shipment || process.env.WMS_OZON_REOPEN_BOX_ENABLED !== 'true')
        throw new common_1.ConflictException('Догруз закрытого короба Ozon недоступен.');
    (0, ozon_supply_policy_1.assertSupplyMutable)(shipment.integration, 'REOPEN_BOX');
    if (!box || box.requestId !== requestId || !box.closedAt || box.wholeBox || !direction || box.direction !== direction)
        throw new common_1.ConflictException('Выберите закрытый короб этой заявки и его направление.');
    await tx.fboAssemblyBox.update({ where: { id: box.id }, data: { closedAt: null, confirmedAt: null, confirmedByUserId: null } });
}
