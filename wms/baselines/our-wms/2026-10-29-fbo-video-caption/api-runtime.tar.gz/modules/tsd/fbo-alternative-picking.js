"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.alternativeFboPickingEnabled = void 0;
exports.prioritizeAlternativeFboBox = prioritizeAlternativeFboBox;
const alternativeFboPickingEnabled = () => process.env.WMS_FBO_ALTERNATIVE_PICK_ENABLED === 'true';
exports.alternativeFboPickingEnabled = alternativeFboPickingEnabled;
// FIX: prefer the physically scanned source among scoped candidates; all stock guards still run afterwards.
function prioritizeAlternativeFboBox(boxes, context) {
    if (!(0, exports.alternativeFboPickingEnabled)() || typeof context.sourceBoxCode !== 'string')
        return boxes;
    const code = context.sourceBoxCode.trim().toUpperCase();
    if (!/^FFL[\w-]{1,96}$/.test(code))
        return boxes;
    const selected = boxes.find(box => box.code.toUpperCase() === code);
    return selected ? [selected, ...boxes.filter(box => box !== selected)] : boxes;
}
