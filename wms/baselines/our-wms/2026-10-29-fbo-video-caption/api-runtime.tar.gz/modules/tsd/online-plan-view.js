"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.onlinePlanView = onlinePlanView;
// FIX: opt-in browser projection; legacy terminals and write responses stay complete.
function onlinePlanView(plan, view, offset) {
    if (process.env.WMS_MENU_READS_ENABLED !== 'true' || !['summary', 'history'].includes(view ?? ''))
        return plan;
    const value = plan;
    if (value.fbo)
        return { ...plan, fbo: onlinePlanView(value.fbo, view, offset) };
    if (!Array.isArray(value.pickedUnits))
        return plan;
    const units = value.pickedUnits;
    if (view === 'summary')
        return { ...plan, pickedUnits: [], pickedUnitsCount: units.length };
    const parsed = Number(offset ?? 0), start = Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : 0;
    return { pickedUnits: units.slice(start, start + 100), total: units.length, offset: start };
}
