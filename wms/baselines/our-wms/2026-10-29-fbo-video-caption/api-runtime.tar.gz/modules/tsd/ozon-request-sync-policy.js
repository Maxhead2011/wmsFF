"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncComposition = syncComposition;
const common_1 = require("@nestjs/common");
// FIX: Ozon is the demand source; exact client-scoped barcode ownership defines identity.
function syncComposition(s, link, catalog) {
    const directions = [], totals = new Map(), rows = [];
    const names = s.directions.map(d => d.name), mapped = names.map(n => link.mapping[n]);
    if (new Set(names).size !== names.length || mapped.some(v => !v) || new Set(mapped).size !== mapped.length || mapped.length !== link.supplies.length || link.supplies.some((v) => !mapped.includes(v.id)))
        throw new common_1.ConflictException('Изменился набор направлений. Сначала нужна сверка привязки поставок.');
    const units = (s.request.fboAssembly?.units ?? []).filter((u) => u.state !== 'RETURNED');
    if (units.some((u) => u.state === 'PACKED' && !(s.request.fboAssembly?.boxes ?? []).some((b) => b.boxId === u.targetBoxId && names.includes(b.direction))))
        throw new common_1.ConflictException('Упакованный товар без подтверждённого направления требует сверки.');
    for (const name of names) {
        const supply = link.supplies.find((v) => v.id === link.mapping[name]), items = [];
        for (const row of supply.items) {
            if (!Number.isSafeInteger(row.quantity) || row.quantity <= 0)
                throw new common_1.ConflictException('Ozon вернул некорректное количество.');
            const owners = catalog.filter(c => c.barcodes.some((b) => b.value === row.barcode));
            if (owners.length !== 1)
                throw new common_1.ConflictException(`ШК ${row.barcode}: товар не найден однозначно в карточках клиента.`);
            const sku = owners[0];
            if (items.some(i => i.skuId === sku.id))
                throw new common_1.ConflictException('Несколько строк Ozon соответствуют одному товару направления.');
            const item = { skuId: sku.id, barcode: row.barcode, name: sku.name, quantity: row.quantity };
            items.push(item);
            const previous = totals.get(sku.id);
            if (previous && previous.barcode !== row.barcode)
                throw new common_1.ConflictException('Разные ШК одного товара по направлениям требуют сверки.');
            totals.set(sku.id, { ...item, quantity: (previous?.quantity ?? 0) + row.quantity });
        }
        if (!items.length)
            throw new common_1.ConflictException('Пустая поставка Ozon требует отдельной отмены.');
        const old = s.directions.find((d) => d.name === name).items;
        const boxIds = new Set((s.request.fboAssembly?.boxes ?? []).filter((b) => b.direction === name).map((b) => b.boxId));
        for (const skuId of new Set([...old.map((i) => i.skuId), ...items.map(i => i.skuId), ...units.filter((u) => boxIds.has(u.targetBoxId)).map((u) => u.skuId)])) {
            const after = items.find(i => i.skuId === skuId), before = old.filter((i) => i.skuId === skuId).reduce((n, i) => n + i.quantity, 0), packed = units.filter((u) => u.skuId === skuId && boxIds.has(u.targetBoxId)).length;
            if ((after?.quantity ?? 0) < packed)
                throw new common_1.ConflictException(`В направлении ${name} уже упаковано больше, чем указано в Ozon.`);
            rows.push({ direction: name, skuId, barcode: after?.barcode ?? old.find((i) => i.skuId === skuId)?.barcode, name: after?.name, before, after: after?.quantity ?? 0, packed });
        }
        directions.push({ name, items });
    }
    for (const skuId of new Set(units.map((u) => u.skuId)))
        if ((totals.get(skuId)?.quantity ?? 0) < units.filter((u) => u.skuId === skuId).length)
            throw new common_1.ConflictException('Уже отобрано больше товара, чем осталось в Ozon. Сначала оформите возврат из сборки.');
    return { directions, items: [...totals.values()], rows, needed: s.request.items.reduce((n, i) => n + i.quantity, 0), after: [...totals.values()].reduce((n, i) => n + i.quantity, 0) };
}
