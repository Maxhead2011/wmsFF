"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fboBarcodeMatches = fboBarcodeMatches;
exports.fboBarcodeAliases = fboBarcodeAliases;
// FIX: resolve only registered identities, never article/name or an ambiguous request barcode.
function fboBarcodeMatches(skuId, barcode, lines) {
    if (!barcode)
        return false;
    const owners = new Set(lines.filter(l => l.barcode === barcode || l.sku?.barcodes?.some(b => b.value === barcode)).map(l => l.skuId));
    return owners.size === 1 && owners.has(skuId);
}
function fboBarcodeAliases(line, lines) {
    return [...new Set([line.barcode, ...(line.sku?.barcodes?.map(b => b.value) ?? [])])]
        .filter((b) => !!b && !!line.skuId && fboBarcodeMatches(line.skuId, b, lines));
}
