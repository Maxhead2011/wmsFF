"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adjustmentHash = adjustmentHash;
exports.adjustmentRows = adjustmentRows;
exports.validateAdjustment = validateAdjustment;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
function adjustmentHash(value) { const stable = (x) => Array.isArray(x) ? x.map(stable) : x && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map(k => [k, stable(x[k])])) : x; return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(stable(value))).digest('hex'); }
// FIX: distribute only the unfilled quota; never reduce already packed or picked goods.
function adjustmentRows(plan, limits) {
    const rows = plan.directions.flatMap((d) => d.items.map((i) => ({ direction: d.name, skuId: i.skuId, barcode: i.barcode, before: i.quantity, packed: i.packed, after: i.packed })));
    for (const line of plan.lines) {
        const group = rows.filter(r => r.skuId === line.skuId), before = group.reduce((s, r) => s + r.before, 0), floor = group.reduce((s, r) => s + r.packed, 0), target = Math.min(before, Math.max(line.picked, limits[line.skuId] ?? before));
        if (before !== line.needed || floor > target)
            throw new common_1.ConflictException('Состав направлений не совпадает с заявкой.');
        let rest = target - floor;
        const capacity = before - floor;
        const ranked = group.map((r, index) => { const exact = capacity ? rest * (r.before - r.packed) / capacity : 0; const n = Math.floor(exact); r.after += n; return { r, index, remainder: exact - n }; });
        rest = target - group.reduce((s, r) => s + r.after, 0);
        for (const { r } of ranked.sort((a, b) => b.remainder - a.remainder || a.index - b.index)) {
            if (rest > 0 && r.after < r.before) {
                r.after++;
                rest--;
            }
        }
    }
    return rows;
}
function validateAdjustment(rows, quantities) {
    if (!Array.isArray(quantities) || quantities.length !== rows.length)
        throw new common_1.ConflictException('Повторите предпросмотр корректировки.');
    const out = rows.map((r, i) => { const after = quantities[i]; if (!Number.isSafeInteger(after) || after < r.packed || after > r.before)
        throw new common_1.ConflictException('Количество должно быть целым, не ниже упакованного и не выше плана.'); return { ...r, after }; });
    for (const sku of new Set(rows.map(r => r.skuId)))
        if (rows.filter(r => r.skuId === sku).reduce((s, r) => s + r.after, 0) !== out.filter(r => r.skuId === sku).reduce((s, r) => s + r.after, 0))
            throw new common_1.ConflictException('Сумма по направлениям должна совпадать с доступным количеством.');
    for (const direction of new Set(out.map(r => r.direction)))
        if (!out.some(r => r.direction === direction && r.after > 0))
            throw new common_1.ConflictException('Направление стало пустым. Его отмена в Ozon требует отдельного решения.');
    return out;
}
