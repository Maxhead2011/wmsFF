const kiz_receipt_conflict_1 = require("./kiz-receipt-conflict");
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdOperationLogService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
let TsdOperationLogService = class TsdOperationLogService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    async findExisting(operationKey) {
        // FIX: replay uses the durable receipt, not screenshot/payload history.
        if (process.env.WMS_COMPACT_OPERATION_RECEIPTS_ENABLED === 'true') {
            const row = await this.prisma.tsdOperation.findUnique({ where: { operationKey },
                select: { status: true, serverMessage: true, reviewReason: true, resolutionMessage: true } });
            // FIX: ordinary successful replays stay compact; only a receipt rejection needs its diagnostic.
            if (process.env.WMS_KIZ_CLIENT_GUARD_ENABLED === 'true' && row?.status === 'NEEDS_REVIEW' && row.reviewReason === 'RECEIPT_FAILED') {
                const detail = await this.prisma.tsdOperation.findUnique({ where: { operationKey }, select: { payload: true, deviceId: true, operationType: true } });
                return { ...row, ...detail };
            }
            return row;
        }
        return this.prisma.tsdOperation.findUnique({ where: { operationKey } });
    }
    listReviewQueue(user) {
        this.clientScopes.requireGlobalClientAccess(user);
        return this.prisma.tsdOperation.findMany({
            where: { status: client_1.TsdOperationStatus.NEEDS_REVIEW },
            orderBy: { createdAt: 'desc' },
            take: 200,
        });
    }
    async recordResult(operation, status, message, reviewReason, resolutionMessage, conflict, receiptScope) {
        const persistedStatus = this.toPersistedStatus(status);
        const details = status === 'NEEDS_REVIEW' ? (0, kiz_receipt_conflict_1.receiptConflictDetails)(conflict) : undefined;
        const payload = { ...operation.payload };
        if (process.env.WMS_KIZ_CLIENT_GUARD_ENABLED === 'true') {
            delete payload._kizDuplicate;
            delete payload._kizDuplicateScope;
            if (details) {
                payload._kizDuplicate = details;
                if (receiptScope)
                    payload._kizDuplicateScope = { clientId: receiptScope.clientId, warehouseId: receiptScope.warehouseId ?? null };
            }
        }
        await this.prisma.tsdOperation.upsert({
            where: { operationKey: operation.operationKey },
            update: {
                status: persistedStatus,
                serverMessage: message,
                reviewReason,
                resolutionMessage,
                ...(details ? { payload: payload } : {}),
            },
            create: {
                deviceId: operation.deviceId,
                operationKey: operation.operationKey,
                operationType: operation.operationType,
                payload: payload,
                status: persistedStatus,
                serverMessage: message,
                reviewReason,
                resolutionMessage,
            },
        });
        return this.result(operation, status, message, reviewReason, resolutionMessage, details);
    }
    existingResult(operation, existing, user) {
        const message = existing.resolutionMessage ?? existing.serverMessage ?? undefined;
        const reviewReason = existing.reviewReason ?? undefined;
        const resolutionMessage = existing.resolutionMessage ?? undefined;
        if (existing.status === client_1.TsdOperationStatus.ACCEPTED) {
            return this.result(operation, 'ALREADY_APPLIED', message, reviewReason, resolutionMessage);
        }
        const payload = existing.payload && typeof existing.payload === 'object'
            ? existing.payload : {};
        const details = (0, kiz_receipt_conflict_1.receiptConflictDetails)(payload._kizDuplicate);
        if (details) {
            // FIX: replay must neither disclose another receipt nor overwrite/re-execute its operation key.
            const scope = payload._kizDuplicateScope;
            let allowed = !!user && existing.operationType === 'receipt_scan' && operation.operationType === 'receipt_scan'
                && existing.deviceId === operation.deviceId && typeof payload.clientId === 'string'
                && payload.clientId === operation.payload.clientId && scope?.clientId === payload.clientId
                && (!scope.warehouseId || scope.warehouseId === user.activeWarehouseId);
            if (allowed) {
                try {
                    this.clientScopes.requireClientAccess(user, payload.clientId, 'write');
                }
                catch {
                    allowed = false;
                }
            }
            if (!allowed)
                return this.result(operation, 'REJECTED', 'Эта операция недоступна в текущем контексте приёмки. Обратитесь к администратору.');
        }
        return this.result(operation, existing.status, message, reviewReason, resolutionMessage, details);
    }
    result(operation, status, message, reviewReason, resolutionMessage, conflict) {
        return {
            operationKey: operation.operationKey,
            operationType: operation.operationType,
            status,
            message,
            reviewReason,
            resolutionMessage,
            ...(status === 'NEEDS_REVIEW' ? (0, kiz_receipt_conflict_1.receiptConflictDetails)(conflict) : undefined),
            serverTime: new Date().toISOString(),
        };
    }
    toPersistedStatus(status) {
        if (status === 'NEEDS_REVIEW') {
            return client_1.TsdOperationStatus.NEEDS_REVIEW;
        }
        if (status === 'REJECTED') {
            return client_1.TsdOperationStatus.REJECTED;
        }
        // Русский комментарий: APPLIED/ACCEPTED/ALREADY_APPLIED в TSD log считаются закрытой операцией.
        return client_1.TsdOperationStatus.ACCEPTED;
    }
};
exports.TsdOperationLogService = TsdOperationLogService;
exports.TsdOperationLogService = TsdOperationLogService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], TsdOperationLogService);
