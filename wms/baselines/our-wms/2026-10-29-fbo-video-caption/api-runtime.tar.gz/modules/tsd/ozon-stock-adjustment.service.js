"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonStockAdjustmentService = void 0;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const ozon_request_sync_policy_1 = require("./ozon-request-sync-policy");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("../client-requests/client-request-warehouse-scope");
const ozon_assembly_supply_service_1 = require("../client-requests/ozon-assembly-supply.service");
const ozon_supply_policy_1 = require("../client-requests/ozon-supply-policy");
const fbo_two_stage_service_1 = require("./fbo-two-stage.service");
const wb_order_stock_lifecycle_1 = require("../../common/stock/wb-order-stock-lifecycle");
const ozon_adjustment_policy_1 = require("./ozon-adjustment-policy");
const active = (op) => op && !['APPLIED', 'CANCELLED'].includes(op.state);
const composition = (items) => (0, ozon_adjustment_policy_1.adjustmentHash)(items.map(i => [i.id, i.skuId, i.barcode, i.quantity]).sort((a, b) => String(a[0]).localeCompare(String(b[0]))));
let OzonStockAdjustmentService = class OzonStockAdjustmentService {
    db;
    scopes;
    fbo;
    ozon;
    constructor(db, scopes, fbo, ozon) {
        this.db = db;
        this.scopes = scopes;
        this.fbo = fbo;
        this.ozon = ozon;
    }
    async load(tx, id, user) {
        if (process.env.WMS_OZON_FBO_IMPORT_ENABLED !== 'true')
            throw new common_1.NotFoundException('ФБО Ozon выключено.');
        const s = await tx.ozonFboShipment.findUnique({ where: { requestId: id }, include: { request: { include: { items: true, fboAssembly: { include: { units: true, boxes: true } } } } } });
        if (!s)
            throw new common_1.NotFoundException('Сборка Ozon не найдена.');
        this.scopes.requireClientAccess(user, s.request.clientId, 'write');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, s.request, 'write');
        if (!user.activeWarehouseId || user.activeWarehouseId !== s.request.warehouseId)
            throw new common_1.ConflictException('Выберите филиал заявки.');
        return s;
    }
    async connection(s) { const c = await this.db.clientMarketplaceConnection.findFirst({ where: { id: s.integration?.connectionId, clientId: s.request.clientId, marketplace: 'OZON', isActive: true } }); if (!s.integration?.connectionId || !c?.apiKey)
        throw new common_1.ConflictException('Сначала привяжите кабинет и поставку Ozon.'); return c; }
    async fresh(s, c) { const old = s.integration, orders = []; for (const o of (0, ozon_supply_policy_1.supplyOrders)(old))
        orders.push(...(0, ozon_supply_policy_1.supplyOrders)(await this.ozon.snapshot(c, o.orderId))); return (0, ozon_supply_policy_1.mergeSupplyOrders)(old, orders); }
    // FIX: never invalidate existing Ozon labels or unidentified cargoes.
    async assertEmptyCargoes(c, link) {
        for (const supply of link.supplies) {
            const data = await this.ozon.call(c, '/v1/cargoes/supplies/get', { supply_ids: [Number(supply.id)] });
            const remote = data.supplies_cargoes?.find((v) => String(v.supply_id) === supply.id);
            if (!remote || remote.transport_cargoes?.length || remote.cargoes_without_transport_cargoes?.length)
                throw new common_1.ConflictException('В Ozon уже есть грузоместа или их состав не подтверждён. Сначала нужна сверка грузомест.');
        }
    }
    async locked(id, user, fn) { return this.db.$transaction(async (tx) => { await tx.$queryRaw `SELECT "id" FROM "ClientRequest" WHERE "id"=${id} FOR UPDATE`; return fn(await this.load(tx, id, user), tx); }, { timeout: 30000, isolationLevel: 'Serializable' }); }
    async assess(tx, id, user) {
        const s = await this.load(tx, id, user);
        (0, ozon_supply_policy_1.assertNoOzonAdjustment)(s.integration);
        if (!['SUBMITTED', 'APPROVED', 'IN_WORK'].includes(s.request.status) || s.integration?.frozenHash || Object.keys(s.integration?.operations ?? {}).length || ['CONTROL', 'COMPLETED'].includes(s.request.fboAssembly?.phase))
            throw new common_1.ConflictException('Корректировка доступна до передачи грузомест и завершения проверки.');
        if (new Set(s.request.items.map((i) => i.skuId)).size !== s.request.items.length)
            throw new common_1.ConflictException('Повторяющиеся строки товара требуют сверки.');
        const { plan } = await this.fbo.adjustmentContext(tx, id, user), skuIds = plan.lines.map(l => l.skuId), limits = {};
        const reserved = await (0, wb_order_stock_lifecycle_1.wbReservationQuantities)(tx, s.request.clientId, skuIds, s.request.warehouseId, id);
        const balances = await tx.stockBalance.findMany({ where: { clientId: s.request.clientId, warehouseId: s.request.warehouseId, skuId: { in: skuIds }, status: 'AVAILABLE', OR: [{ boxId: null }, { box: { status: 'active', clientId: s.request.clientId, warehouseId: s.request.warehouseId } }] }, select: { skuId: true, quantity: true } });
        for (const l of plan.lines) {
            const routed = plan.route.flatMap(r => r.tasks).filter(i => i.skuId === l.skuId).reduce((n, i) => n + i.quantity, 0), candidate = plan.unboxedPickingSupported ? l.remaining : routed + (l.pendingPlacementQuantity ?? 0), stock = balances.filter((b) => b.skuId === l.skuId).reduce((n, b) => n + b.quantity, 0);
            limits[l.skuId] = l.picked + Math.max(0, Math.min(candidate, stock - (reserved.get(l.skuId) ?? 0)));
        }
        if (plan.compositionChanged)
            throw new common_1.ConflictException('Состав сборки требует сверки.');
        const rows = (0, ozon_adjustment_policy_1.adjustmentRows)(plan, limits), basis = { status: s.request.status, phase: s.request.fboAssembly?.phase ?? null, items: s.request.items.map((i) => ({ id: i.id, skuId: i.skuId, barcode: i.barcode, quantity: i.quantity })).sort((a, b) => a.id.localeCompare(b.id)), units: (s.request.fboAssembly?.units ?? []).filter((u) => u.state !== 'RETURNED').map((u) => ({ id: u.id, state: u.state, targetBoxId: u.targetBoxId })).sort((a, b) => a.id.localeCompare(b.id)), directions: s.directions, connectionId: s.integration?.connectionId, orderIds: s.integration ? (0, ozon_supply_policy_1.supplyOrders)(s.integration).map(o => o.orderId) : [] };
        return { s, plan, rows, basis, token: (0, ozon_adjustment_policy_1.adjustmentHash)([user.id, id, basis, rows]) };
    }
    async preview(id, user) { const x = await this.db.$transaction(tx => this.assess(tx, id, user), { isolationLevel: 'RepeatableRead', timeout: 30000 }); const c = await this.connection(x.s), link = await this.fresh(x.s, c); await this.assertEmptyCargoes(c, link); if ((0, ozon_supply_policy_1.supplyDifferences)(x.s.directions, link).length)
        throw new common_1.ConflictException('Состав WMS уже расходится с Ozon. Сначала выполните сверку поставок.'); return { token: x.token, rows: x.rows, lines: x.plan.lines, pendingLocations: x.plan.pendingLocations, route: x.plan.route, needed: x.plan.needed, after: x.rows.reduce((n, r) => n + r.after, 0) }; }
    // FIX: inbound synchronization reads Ozon only; a fresh preview guards every local write.
    async syncAssessment(tx, s, link, user) {
        (0, ozon_supply_policy_1.assertNoOzonAdjustment)(s.integration);
        const r = s.request, a = r.fboAssembly;
        if (!['SUBMITTED', 'APPROVED', 'IN_WORK'].includes(r.status) || s.integration?.frozenHash || Object.keys(s.integration?.operations ?? {}).length || a && (!['PICKING', 'PACKING'].includes(a.phase) || a.pickClosure))
            throw new common_1.ConflictException('Синхронизация доступна до контроля и передачи грузомест.');
        if (new Set(r.items.map((i) => i.skuId)).size !== r.items.length || r.items.some((i) => !i.skuId))
            throw new common_1.ConflictException('Строки заявки требуют сверки.');
        if (a?.compositionHash && a.compositionHash !== composition(r.items))
            throw new common_1.ConflictException('Состав сборки требует сверки.');
        if ((0, ozon_supply_policy_1.supplyOrders)(link).some(o => !['DATA_FILLING', 'READY_TO_SUPPLY'].includes(o.state)))
            throw new common_1.ConflictException('Поставка Ozon больше не находится в подготовке.');
        const barcodes = link.supplies.flatMap(v => v.items.map(i => i.barcode));
        const catalog = await tx.sku.findMany({ where: { clientId: r.clientId, barcodes: { some: { value: { in: barcodes } } } }, include: { barcodes: true } });
        const result = (0, ozon_request_sync_policy_1.syncComposition)(s, link, catalog);
        const basis = { status: r.status, items: r.items, directions: s.directions, assembly: a, integration: s.integration };
        // Ignore remote read timestamps, but bind the token to all local progress and remote demand.
        const remote = (0, ozon_supply_policy_1.supplyOrders)(link).map(o => ({ orderId: o.orderId, state: o.state, supplies: o.supplies }));
        return { ...result, token: (0, ozon_adjustment_policy_1.adjustmentHash)([user.id, r.id, basis, remote, result]) };
    }
    async syncPreview(id, user) {
        const initial = await this.load(this.db, id, user), c = await this.connection(initial), link = await this.fresh(initial, c);
        await this.assertEmptyCargoes(c, link);
        return this.locked(id, user, async (s, tx) => { if ((0, ozon_adjustment_policy_1.adjustmentHash)(s.integration) !== (0, ozon_adjustment_policy_1.adjustmentHash)(initial.integration))
            throw new common_1.ConflictException('Привязка изменилась. Повторите сверку.'); return this.syncAssessment(tx, s, link, user); });
    }
    async syncApply(id, body, user) {
        if (body?.confirm !== true || !body.token)
            throw new common_1.BadRequestException('Подтвердите синхронизацию заявки с Ozon.');
        const initial = await this.load(this.db, id, user), c = await this.connection(initial), link = await this.fresh(initial, c);
        await this.assertEmptyCargoes(c, link);
        return this.locked(id, user, async (s, tx) => {
            if ((0, ozon_adjustment_policy_1.adjustmentHash)(s.integration) !== (0, ozon_adjustment_policy_1.adjustmentHash)(initial.integration))
                throw new common_1.ConflictException('Привязка изменилась. Повторите сверку.');
            const p = await this.syncAssessment(tx, s, link, user);
            if (p.token !== body.token)
                throw new common_1.ConflictException('Состав Ozon или сборка изменились. Повторите предпросмотр.');
            const items = [];
            for (const item of p.items) {
                const old = s.request.items.find((i) => i.skuId === item.skuId);
                items.push(old ? await tx.clientRequestItem.update({ where: { id: old.id }, data: { quantity: item.quantity, barcode: item.barcode } }) : await tx.clientRequestItem.create({ data: { requestId: id, ...item } }));
            }
            for (const old of s.request.items)
                if (!p.items.some(i => i.skuId === old.skuId))
                    await tx.clientRequestItem.delete({ where: { id: old.id } });
            await tx.ozonFboShipment.update({ where: { requestId: id }, data: { directions: p.directions, integration: link } });
            const a = s.request.fboAssembly;
            if (a) {
                const picked = a.units.filter((u) => u.state !== 'RETURNED').length;
                await tx.fboAssembly.update({ where: { requestId: id }, data: { compositionHash: composition(items), ...(p.after > picked ? { phase: 'PICKING' } : {}) } });
            }
            await tx.auditLog.create({ data: { userId: user.id, action: 'OZON_REMOTE_COMPOSITION_SYNC', entity: 'ClientRequest', entityId: id, payload: { oldItems: s.request.items, oldDirections: s.directions, rows: p.rows, needed: p.needed, after: p.after, checkedAt: link.checkedAt } } });
            return { applied: true, needed: p.needed, after: p.after };
        });
    }
    // FIX: persist intent before external writes; unknown outcomes are never blindly retried.
    async start(id, body, user) {
        if (body?.confirm !== true)
            throw new common_1.BadRequestException('Подтвердите изменение количества в WMS и Ozon.');
        const initial = await this.load(this.db, id, user);
        if (active(initial.integration?.adjustment))
            return this.view(id, user);
        const c = await this.connection(initial), fresh = await this.fresh(initial, c);
        if ((0, ozon_supply_policy_1.supplyDifferences)(initial.directions, fresh).length)
            throw new common_1.ConflictException('Состав Ozon изменился. Повторите сверку.');
        if ((0, ozon_supply_policy_1.supplyOrders)(fresh).some(o => !['DATA_FILLING', 'READY_TO_SUPPLY'].includes(o.state)))
            throw new common_1.ConflictException('Ozon больше не разрешает подготовку этой поставки.');
        await this.assertEmptyCargoes(c, fresh);
        await this.locked(id, user, async (s, tx) => {
            const x = await this.assess(tx, id, user);
            if (x.token !== body.token)
                throw new common_1.ConflictException('Остатки или сборка изменились. Повторите предпросмотр.');
            if ((0, ozon_adjustment_policy_1.adjustmentHash)(s.directions) !== (0, ozon_adjustment_policy_1.adjustmentHash)(initial.directions) || s.integration.connectionId !== fresh.connectionId || (0, ozon_adjustment_policy_1.adjustmentHash)((0, ozon_supply_policy_1.supplyOrders)(s.integration).map((o) => o.orderId)) !== (0, ozon_adjustment_policy_1.adjustmentHash)((0, ozon_supply_policy_1.supplyOrders)(fresh).map(o => o.orderId)))
                throw new common_1.ConflictException('Привязка изменилась.');
            const rows = (0, ozon_adjustment_policy_1.validateAdjustment)(x.rows, body.quantities);
            if (rows.every(r => r.after === r.before))
                throw new common_1.ConflictException('Корректировка не требуется.');
            const directions = s.directions.map(d => ({ ...d, items: d.items.map((i) => ({ ...i, quantity: rows.find(r => r.direction === d.name && r.skuId === i.skuId).after })).filter((i) => i.quantity > 0) }));
            const operations = [];
            for (const d of directions) {
                if (!rows.some(r => r.direction === d.name && r.after !== r.before))
                    continue;
                const supply = fresh.supplies.find(v => v.id === fresh.mapping[d.name]), order = (0, ozon_supply_policy_1.supplyOrders)(fresh).find(o => o.supplies.some(v => v.id === supply?.id));
                if (!supply || !order)
                    throw new common_1.ConflictException('Нет соответствия направления Ozon.');
                const items = d.items.map((i) => { const m = supply.items.filter(v => v.barcode === i.barcode); if (m.length !== 1 || !m[0].sku || !Number.isSafeInteger(Number(m[0].sku)))
                    throw new common_1.ConflictException('Ozon не вернул однозначный SKU товара.'); return { sku: Number(m[0].sku), quantity: i.quantity, quant: m[0].quant || 1 }; });
                operations.push({ supplyId: supply.id, orderId: order.orderId, state: 'PENDING', items });
            }
            fresh.adjustment = { id: (0, node_crypto_1.randomUUID)(), state: 'RUNNING', actorId: user.id, createdAt: new Date().toISOString(), basis: x.basis, rows, directions, operations };
            await tx.ozonFboShipment.update({ where: { requestId: id }, data: { integration: fresh } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'OZON_STOCK_ADJUSTMENT_STARTED', entity: 'ClientRequest', entityId: id, payload: fresh.adjustment } });
        });
        return this.resume(id, user);
    }
    async view(id, user) { const s = await this.load(this.db, id, user), op = s.integration?.adjustment; return { operation: op ? { id: op.id, state: op.state, rows: op.rows, operations: op.operations.map((o) => ({ supplyId: o.supplyId, state: o.state, error: o.error })) } : null }; }
    async resume(id, user) {
        let s = await this.load(this.db, id, user);
        if (!active(s.integration?.adjustment))
            return this.view(id, user);
        const c = await this.connection(s), opId = s.integration.adjustment.id;
        for (const original of s.integration.adjustment.operations) {
            const claim = await this.locked(id, user, async (cur, tx) => { const a = cur.integration.adjustment; if (a?.id !== opId || !active(a))
                return null; const op = a.operations.find((o) => o.supplyId === original.supplyId); if (op.state !== 'PENDING')
                return null; op.state = 'SENDING'; await tx.ozonFboShipment.update({ where: { requestId: id }, data: { integration: cur.integration } }); return op; });
            if (!claim)
                continue;
            let result;
            try {
                result = await this.ozon.call(c, '/v1/supply-order/content/update', { order_id: Number(claim.orderId), supply_id: Number(claim.supplyId), items: claim.items }, false);
            }
            catch (e) {
                const error = e instanceof Error ? e.message : String(e);
                result = { uncertain: true, error, ...(/Ozon: HTTP (400|401|403|404|422)\./.test(error) ? { errors: [error] } : {}) };
            }
            await this.locked(id, user, async (cur, tx) => { const a = cur.integration.adjustment; if (a?.id !== opId)
                throw new common_1.ConflictException('Операция изменилась.'); const op = a.operations.find((o) => o.supplyId === claim.supplyId); op.state = result.operation_id ? 'ACCEPTED' : result.errors?.length ? 'FAILED' : 'UNKNOWN'; op.operationId = result.operation_id ? String(result.operation_id) : undefined; op.error = result.error ?? (result.errors?.length ? JSON.stringify(result.errors) : undefined); await tx.ozonFboShipment.update({ where: { requestId: id }, data: { integration: cur.integration } }); });
            if (!result.operation_id)
                break;
        }
        s = await this.load(this.db, id, user);
        for (const op of s.integration.adjustment.operations) {
            if (!op.operationId || ['SUCCESS', 'FAILED'].includes(op.state))
                continue;
            const status = await this.ozon.call(c, '/v1/supply-order/content/update/status', { operation_id: op.operationId });
            await this.locked(id, user, async (cur, tx) => { const a = cur.integration.adjustment; if (a?.id !== opId)
                throw new common_1.ConflictException('Операция изменилась.'); const current = a.operations.find((v) => v.supplyId === op.supplyId); current.state = status.status === 'SUCCESS' ? 'SUCCESS' : status.status === 'FAILED' ? 'FAILED' : 'ACCEPTED'; current.error = status.errors?.length ? JSON.stringify(status.errors) : undefined; await tx.ozonFboShipment.update({ where: { requestId: id }, data: { integration: cur.integration } }); });
        }
        s = await this.load(this.db, id, user);
        const fresh = await this.fresh(s, c), a = s.integration.adjustment;
        if (a.operations.every((o) => o.state === 'SUCCESS') && !(0, ozon_supply_policy_1.supplyDifferences)(a.directions, fresh).length) {
            await this.locked(id, user, async (cur, tx) => {
                const op = cur.integration.adjustment;
                if (op?.id !== opId || !active(op))
                    return;
                if (cur.request.status !== op.basis.status || (cur.request.fboAssembly?.phase ?? null) !== op.basis.phase)
                    throw new common_1.ConflictException('Статус сборки изменился во время корректировки. Требуется сверка.');
                const currentItems = cur.request.items.map((i) => ({ id: i.id, skuId: i.skuId, barcode: i.barcode, quantity: i.quantity })), currentUnits = (cur.request.fboAssembly?.units ?? []).filter((u) => u.state !== 'RETURNED').map((u) => ({ id: u.id, state: u.state, targetBoxId: u.targetBoxId }));
                const ordered = (x) => [...x].sort((a, b) => a.id.localeCompare(b.id));
                if ((0, ozon_adjustment_policy_1.adjustmentHash)(ordered(currentItems)) !== (0, ozon_adjustment_policy_1.adjustmentHash)(ordered(op.basis.items)) || (0, ozon_adjustment_policy_1.adjustmentHash)(ordered(currentUnits)) !== (0, ozon_adjustment_policy_1.adjustmentHash)(ordered(op.basis.units)))
                    throw new common_1.ConflictException('Локальная сборка изменилась во время корректировки. Требуется сверка.');
                const items = [];
                for (const i of cur.request.items) {
                    const quantity = op.rows.filter((r) => r.skuId === i.skuId).reduce((n, r) => n + r.after, 0);
                    if (quantity) {
                        await tx.clientRequestItem.update({ where: { id: i.id }, data: { quantity } });
                        items.push({ ...i, quantity });
                    }
                    else
                        await tx.clientRequestItem.delete({ where: { id: i.id } });
                }
                op.state = 'APPLIED';
                op.appliedAt = new Date().toISOString();
                fresh.adjustment = op;
                await tx.ozonFboShipment.update({ where: { requestId: id }, data: { directions: op.directions, integration: fresh } });
                if (cur.request.fboAssembly)
                    await tx.fboAssembly.update({ where: { requestId: id }, data: { compositionHash: composition(items) } });
                await tx.auditLog.create({ data: { userId: user.id, action: 'OZON_STOCK_ADJUSTMENT_APPLIED', entity: 'ClientRequest', entityId: id, payload: { operationId: opId, rows: op.rows } } });
            });
        }
        return this.view(id, user);
    }
    // FIX: cancel only a conclusively rejected, unchanged external operation; never unlock an uncertain write.
    async cancel(id, user) {
        const s = await this.load(this.db, id, user), a = s.integration?.adjustment;
        if (!active(a))
            return this.view(id, user);
        if (a.operations.some((o) => !['PENDING', 'FAILED'].includes(o.state)))
            throw new common_1.ConflictException('Есть неподтверждённая или успешная операция Ozon. Сначала завершите сверку.');
        const fresh = await this.fresh(s, await this.connection(s));
        if ((0, ozon_supply_policy_1.supplyDifferences)(a.basis.directions, fresh).length)
            throw new common_1.ConflictException('Ozon уже изменён: отменять локальную корректировку нельзя.');
        await this.locked(id, user, async (cur, tx) => { const op = cur.integration.adjustment; if (op?.id !== a.id || !active(op) || op.operations.some((o) => !['PENDING', 'FAILED'].includes(o.state)))
            throw new common_1.ConflictException('Состояние операции изменилось.'); op.state = 'CANCELLED'; await tx.ozonFboShipment.update({ where: { requestId: id }, data: { integration: cur.integration } }); await tx.auditLog.create({ data: { userId: user.id, action: 'OZON_STOCK_ADJUSTMENT_CANCELLED', entity: 'ClientRequest', entityId: id, payload: { operationId: a.id } } }); });
        return this.view(id, user);
    }
};
exports.OzonStockAdjustmentService = OzonStockAdjustmentService;
exports.OzonStockAdjustmentService = OzonStockAdjustmentService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof fbo_two_stage_service_1.FboTwoStageService !== "undefined" && fbo_two_stage_service_1.FboTwoStageService) === "function" ? _c : Object, typeof (_d = typeof ozon_assembly_supply_service_1.OzonAssemblySupplyService !== "undefined" && ozon_assembly_supply_service_1.OzonAssemblySupplyService) === "function" ? _d : Object])
], OzonStockAdjustmentService);
