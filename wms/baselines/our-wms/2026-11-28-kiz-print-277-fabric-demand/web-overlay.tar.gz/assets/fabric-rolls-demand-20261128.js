export function FabricRollsPanel({React:R,jsx:E,request,accessToken,clientId,canConfigure,canManage,onStockChanged}){
 const [data,setData]=R.useState(null),[error,setError]=R.useState(''),[busy,setBusy]=R.useState(false),[open,setOpen]=R.useState(false);
 const [material,setMaterial]=R.useState('SATIN'),[color,setColor]=R.useState('black'),[count,setCount]=R.useState('1');
 const [rollId,setRollId]=R.useState(''),[barcode,setBarcode]=R.useState(''),[cuts,setCuts]=R.useState('1'),[box,setBox]=R.useState(''),[kiz,setKiz]=R.useState('');
 const [delta,setDelta]=R.useState('0'),[reason,setReason]=R.useState('');
 const pending=R.useRef(null),generation=R.useRef(0);
 const api='/warehouse/fabric-rolls/'+encodeURIComponent(clientId);
 const h=(type,props,...children)=>R.createElement(type,props,...children);
 async function load(){const g=++generation.current;setError('');try{const d=await request(api,{accessToken});if(g===generation.current)setData(d);}catch(e){if(g===generation.current)setError(e.message||'Не удалось загрузить рулоны.');}}
 R.useEffect(()=>{setData(null);setRollId('');setOpen(false);pending.current=null;load();return()=>{generation.current++};},[clientId,accessToken]);
 async function changeEnabled(enabled){setBusy(true);setError('');try{setData(await request(api,{method:'PUT',accessToken,body:{enabled}}));}catch(e){setError(e.message);}finally{setBusy(false);}}
 async function action(body){if(busy)return;setBusy(true);setError('');const fingerprint=JSON.stringify(body);if(pending.current?.fingerprint!==fingerprint)pending.current={fingerprint,key:crypto.randomUUID()};
  try{const result=await request(api,{method:'POST',accessToken,body:{...body,version:data.version,operationKey:pending.current.key}});setData(result);pending.current=null;if(body.action==='CUT'){setBarcode('');setKiz('');onStockChanged?.();}}
  catch(e){setError(e.message||'Не удалось сохранить.');}finally{setBusy(false);}}
 const materials={SATIN:'Атлас / сатин',GABARDINE:'Габардин',...(data?.materials||{})},colors={black:'Чёрный',white:'Белый',green:'Зелёный',red:'Красный',ivory:'Айвори / шампань',...Object.fromEntries((data?.catalogColors||[]).filter(c=>c.material===material).map(c=>[c.id,c.name]))};
 const num=n=>Number(n||0).toLocaleString('ru-RU',{maximumFractionDigits:3});
 const select=(label,value,set,options)=>h('label',null,h('span',null,label),h('select',{value,onChange:e=>set(e.target.value),disabled:busy},...options.map(([v,n])=>h('option',{key:v,value:v},n))));
 const input=(label,value,set,type='text')=>h('label',null,h('span',null,label),h('input',{type,value,onChange:e=>set(e.target.value),disabled:busy,...(type==='number'?{min:1,max:500,step:1}:{})}));
 const rolls=data?.groups?.flatMap(g=>g.rolls)||[],current=rolls.find(r=>r.id===rollId),matched=data?.skus?.find(s=>s.barcodes.includes(barcode.trim()));
 if(!data&&!error)return canConfigure?h('p',{className:'muted'},'Загружаю настройку рулонного учёта…'):null;
 if(!data?.enabled&&!canConfigure)return null;
 return h('section',{className:'fabric-rolls', 'aria-label':'Рулоны и отрезы'},
  h('header',{className:'fabric-rolls__header'},h('div',null,h('p',{className:'eyebrow'},'ТКАНЬ · ХРАНЕНИЕ И УЧЁТ'),h('h3',null,'Рулоны и готовые отрезы')),
   canConfigure?h('label',{className:'fabric-rolls__toggle'},h('input',{type:'checkbox',checked:!!data?.enabled,disabled:busy,onChange:e=>changeEnabled(e.target.checked)}),'Товар в рулонах'):null,
   data?.enabled?h('button',{type:'button',className:'secondary-button',disabled:busy,onClick:load},'Обновить'):null),
  error?h('p',{className:'form-error',role:'alert'},error):null,
  data?.enabled?h(R.Fragment,null,
   h('p',{className:'muted'},'Рулон — 100 м, длина 140 см, диаметр 15 см: 24,74 л. Объём открытого рулона рассчитывается пропорционально метражу. Фактическая корректировка до ±2 м. При подтверждённой отгрузке метры списываются автоматически; уже списанные при нарезке метры повторно не списываются. Рулоны включены в хранение по литро-дням; готовые отрезы учитываются отдельно.'),
   data.shipmentPending?.length?h('p',{className:'form-error',role:'alert'},'Не хватает зарегистрированных метров для части отгрузок: '+num(data.shipmentPending.reduce((s,r)=>s+r.meters,0))+' м. Проверьте фактический остаток рулонов и даты поступления.'):null,
   h('div',{className:'fabric-rolls__grid'},...data.groups.map(g=>h('article',{key:g.key,className:'fabric-rolls__card'},
    h('header',null,h('i',{style:{background:({black:'#252b30',white:'#f7f6ef',red:'#b84848',green:'#37785a',ivory:'#ece2c6'})[g.color]}}),h('div',null,h('strong',null,materials[g.material]),h('span',null,g.colorName))),
    h('div',{className:'fabric-rolls__numbers'},h('div',null,h('b',null,num(g.whole)),h('small',null,'целых рулонов')),h('div',null,h('b',null,num(g.open)),h('small',null,'открытых рулонов')),h('div',null,h('b',null,num(g.rawMeters)+' м'),h('small',null,'в рулонах'))),
    h('p',null,'Объём рулонов для хранения: '+num(g.rawLiters)+' л'),h('p',null,'Готовые отрезы: '+num(g.ready.reduce((s,r)=>s+r.pieces,0))+' шт. · '+num(g.ready.reduce((s,r)=>s+r.pieces*r.meters,0))+' м'),
    h('div',{className:'fabric-rolls__chips'},...g.ready.sort((a,b)=>a.meters-b.meters).map(r=>h('span',{key:r.skuId},r.meters+' м × '+num(r.pieces)+(r.reserved?' · резерв '+num(r.reserved):'')))),
    h('p',{className:'muted'},'Необходимо · FBS: '+num(g.required.fbs.pieces)+' отрезов / '+num(g.required.fbs.meters)+' м · FBO: '+num(g.required.fbo.pieces)+' отрезов / '+num(g.required.fbo.meters)+' м'),h('p',{className:'muted'},'Отгружено · FBS: '+num(g.fbs.pieces)+' отрезов / '+num(g.fbs.meters)+' м · FBO: '+num(g.fbo.pieces)+' отрезов / '+num(g.fbo.meters)+' м'),
    h('details',null,h('summary',null,'Остаток каждого рулона'),...g.rolls.filter(r=>r.remainingMm>0).map(r=>h('div',{key:r.id,className:'fabric-rolls__roll'},h('span',null,r.code),h('progress',{value:r.remainingMm,max:r.initialMm+r.adjustmentMm}),h('b',null,num(r.remainingMm/1000)+' м'))))))),
   !data.groups.length?h('p',null,'Рулонов пока 0. После пересчёта добавьте тип ткани и цвет.'):null,
   canManage?h('details',{open,onToggle:e=>setOpen(e.currentTarget.open)},h('summary',null,'Учёт склада: добавить / нарезать / списать рулоны'),
    h('form',{className:'fabric-rolls__form',onSubmit:e=>{e.preventDefault();action({action:'RECEIVE',material,color,count:Number(count)});}},h('h4',null,'Добавить фактически имеющиеся или поступившие рулоны'),
     select('Тип ткани',material,setMaterial,Object.entries(materials)),select('Цвет',color,setColor,Object.entries(colors)),input('Количество рулонов',count,setCount,'number'),h('button',{type:'submit',disabled:busy},'Добавить рулоны')),
    h('form',{className:'fabric-rolls__form',onSubmit:e=>{e.preventDefault();action({action:'CUT',rollId,barcode,count:Number(cuts),boxCode:box,kiz});}},h('h4',null,'Нарезать и оприходовать новые отрезы'),
     select('Рулон',rollId,setRollId,[['','Выберите рулон'],...rolls.filter(r=>r.remainingMm>0).map(r=>[r.id,materials[r.material]+' · '+colors[r.color]+' · '+r.code+' · '+num(r.remainingMm/1000)+' м'])]),
     input('Баркод готового отреза',barcode,setBarcode),input('Количество отрезов',cuts,setCuts,'number'),input('Короб на паллет-сорте',box,setBox),
     matched?h('p',null,'По баркоду: '+matched.meters+' м × '+num(cuts)+' = '+num(matched.meters*Number(cuts))+' м'):null,
     h('label',null,h('span',null,'КИЗ каждого отреза — по одному на строку, если товар маркируемый'),h('textarea',{value:kiz,onChange:e=>setKiz(e.target.value),disabled:busy})),
     h('p',{className:'muted'},'Только для новых отрезов. Уже имеющиеся остатки повторно не вносить. После нарезки отрезы доступны в обычной сборке FBS/FBO.'),h('button',{type:'submit',disabled:busy||!rollId||!barcode.trim()},'Списать метры и добавить отрезы')),
    h('form',{className:'fabric-rolls__form',onSubmit:e=>{e.preventDefault();action({action:'WRITE_OFF',rollId,reason});}},h('h4',null,'Списать рулон вручную'),
     select('Рулон для списания',rollId,setRollId,[['','Выберите рулон'],...rolls.filter(r=>r.remainingMm>0&&!r.writtenOffAt).map(r=>[r.id,materials[r.material]+' · '+colors[r.color]+' · '+r.code+' · '+num(r.remainingMm/1000)+' м'])]),
     input('Причина списания (обязательно)',reason,setReason),
     current?h('p',null,'Будет списан весь остаток рулона: '+num(current.remainingMm/1000)+' м. Запись и причина сохранятся в истории.'):null,
     h('button',{type:'submit',disabled:busy||!current||current.remainingMm<=0||reason.trim().length<5},'Списать остаток рулона')),
    h('form',{className:'fabric-rolls__form',onSubmit:e=>{e.preventDefault();action({action:'ADJUST',rollId,deltaMm:Math.round(Number(delta)*1000),reason});}},h('h4',null,'Фактическая погрешность рулона'),
     select('Рулон',rollId,setRollId,[['','Выберите рулон'],...rolls.map(r=>[r.id,r.code+' · '+num(r.remainingMm/1000)+' м'])]),h('label',null,'Изменение, м (от −2 до +2)',h('input',{type:'number',min:-2,max:2,step:0.001,value:delta,onChange:e=>setDelta(e.target.value)})),input('Причина / результат замера',reason,setReason),h('button',{type:'submit',disabled:busy||!rollId},'Записать корректировку'))):null,
   h('details',null,h('summary',null,'История рулонного учёта'),...data.history.map((r,i)=>h('p',{key:i},new Date(r.createdAt).toLocaleString('ru-RU')+' · '+({FABRIC_ROLL_RECEIVE:'Приход рулонов',FABRIC_ROLL_CUT:'Нарезка',FABRIC_ROLL_SHIP:'Списание по отгрузке',FABRIC_ROLL_WRITE_OFF:'Ручное списание',FABRIC_ROLL_ADJUST:'Корректировка',FABRIC_ROLLS_ENABLED_CHANGED:'Настройка клиента'})[r.action]+(r.payload?.cutMeters?' · '+num(r.payload.cutMeters)+' м':'')+(r.payload?.coveredMeters?' · уже списано при нарезке: '+num(r.payload.coveredMeters)+' м':'')+(r.payload?.writtenOffMeters?' · '+num(r.payload.writtenOffMeters)+' м':'')+(r.payload?.reason?' · '+r.payload.reason:''))))) : h('p',{className:'muted'},'Включите для клиента, у которого ткань хранится в рулонах. Обычные штучные товары не меняются.'));
}
