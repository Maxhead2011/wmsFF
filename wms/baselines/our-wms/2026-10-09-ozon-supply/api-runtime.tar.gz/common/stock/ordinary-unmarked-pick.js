"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ordinaryUnmarkedPickEnabled = void 0;
exports.isOrdinaryUnmarkedPick = isOrdinaryUnmarkedPick;
exports.ordinaryPickStatusLabel = ordinaryPickStatusLabel;
// FIX: opt-in ordinary WB picking; marked and SOS workflows remain unchanged.
const ordinaryUnmarkedPickEnabled = () => process.env.WMS_FBS_UNMARKED_PICK_CLOSE_ENABLED === 'true';
exports.ordinaryUnmarkedPickEnabled = ordinaryUnmarkedPickEnabled;
function isOrdinaryUnmarkedPick(task) {
    return (0, exports.ordinaryUnmarkedPickEnabled)() && task.marketplace === 'WILDBERRIES' && task.requiresKiz === false &&
        !task.kiz && !task.sourceBoxPending && !!task.barcode && !!task.deviceCode &&
        !task.deviceCode.startsWith('SOS-WB:') && !task.deviceCode.startsWith('AUTO:');
}
function ordinaryPickStatusLabel(task, fallback) {
    if (!isOrdinaryUnmarkedPick(task))
        return fallback;
    return task.status === 'COMPLETED' ? 'Упаковано' : task.status === 'IN_PROGRESS' ? 'Найдено' : fallback;
}
