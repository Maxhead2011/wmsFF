"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelledWithoutSale = exports.cancelledKizReviewEnabled = void 0;
exports.releaseCancelledBindings = releaseCancelledBindings;
const common_1 = require("@nestjs/common");
const kiz_sorting_return_proof_1 = require("./kiz-sorting-return-proof");
const kiz_sorting_return_proof_2 = require("./kiz-sorting-return-proof");
// FIX: opt-in for our WMS. Unknown circulation permits human review, never automatic reuse.
const cancelledKizReviewEnabled = () => process.env.WMS_KIZ_CANCELLED_ADMIN_REUSE_ENABLED === 'true';
exports.cancelledKizReviewEnabled = cancelledKizReviewEnabled;
const cancelledWithoutSale = (status) => ['canceled', 'canceled_by_client', 'declined_by_client'].includes(status ?? '');
exports.cancelledWithoutSale = cancelledWithoutSale;
// FIX: preserve shipment records and the complete historical task before releasing its unique live slot.
// The caller must first check admin rights, current unit/box/balance and confirmation of physical presence.
async function releaseCancelledBindings(tx, clientId, kiz, evidence, userId, reviewId, excludedTaskId = '', physicalConfirmation = false) {
    const conflict = () => new common_1.ConflictException('КИЗ занят другой сборкой или отмена прежнего заказа не подтверждена. Обновите проверку.');
    // FIX: only the authenticated, confirmed manager action may review unknown WB history.
    const physicalReview = physicalConfirmation && process.env.WMS_KIZ_PHYSICAL_REVIEW_ENABLED === 'true';
    const age = Date.now() - Date.parse(evidence.checkedAt);
    if (!(0, exports.cancelledKizReviewEnabled)() || evidence.decision !== 'REVIEW' ||
        ['RETIRED', 'WRITTEN_OFF'].includes(evidence.circulation ?? '') || !Number.isFinite(age) || age < 0 || age > 60000 ||
        !evidence.orders.length || (!physicalReview && !evidence.orders.every(o => o.verified)))
        throw conflict();
    const identity = (0, kiz_sorting_return_proof_2.manualKizIdentity)(kiz);
    if (!identity)
        throw conflict();
    await tx.$queryRaw `SELECT 1 FROM pg_advisory_xact_lock(hashtextextended(${identity},0))`;
    const links = (await tx.fbsTsdAssembly.findMany({ where: { clientId, id: { not: excludedTaskId },
            OR: (0, kiz_sorting_return_proof_2.manualKizPrefixes)(identity).map(p => ({ kiz: { startsWith: p } })) } })).filter(t => (0, kiz_sorting_return_proof_2.manualKizIdentity)(t.kiz ?? '') === identity);
    const requests = await tx.clientRequest.findMany({ where: { clientId, id: { in: links.map(t => t.requestId) }, status: { in: ['DONE', 'CANCELLED', 'REJECTED'] } } });
    // FIX: a confirmed physical recount can release a historical WB_ACCOUNTED slot,
    // but only through the existing administrator confirmation, never on a scan.
    const inventoryProof = physicalReview && process.env.WMS_KIZ_INVENTORY_ADMIN_REUSE_ENABLED === 'true'
        ? await inventoryReturnProof(tx, clientId, identity, links, requests, evidence) : null;
    if (inventoryProof) {
        for (const old of links) {
            await tx.auditLog.create({ data: { userId, action: 'KIZ_INVENTORY_BINDING_ARCHIVED', entity: 'FbsTsdAssembly', entityId: old.id,
                payload: JSON.parse(JSON.stringify({ reviewId, kizIdentity: identity, evidence, physicalConfirmation: true, inventoryProof, before: old })) } });
            const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: old.id, clientId, status: old.status,
                kiz: old.kiz, updatedAt: old.updatedAt }, data: { kiz: null } });
            if (changed.count !== 1) throw conflict();
        }
        return;
    }
    // FIX: preserve full audit before clearing only a never-shipped cancelled binding.
    const unfinishedProof = physicalReview ? await unfinishedCancelledProof(tx, clientId, identity, links, requests, evidence) : null;
    if (unfinishedProof) {
        for (const old of links) {
            await tx.auditLog.create({data:{userId,action:'KIZ_UNFINISHED_CANCELLED_BINDING_ARCHIVED',entity:'FbsTsdAssembly',entityId:old.id,payload:JSON.parse(JSON.stringify({reviewId,kizIdentity:identity,evidence,physicalConfirmation:true,sortingProof:unfinishedProof,before:old}))}});
            const changed=await tx.fbsTsdAssembly.updateMany({where:{id:old.id,clientId,status:'RELEASED',completedAt:null,kiz:old.kiz,updatedAt:old.updatedAt},data:{kiz:null}});
            if(changed.count!==1)throw conflict();
        }
        return;
    }
    if (links.some(t => (t.status !== 'COMPLETED' && !(physicalReview && t.status === 'RELEASED')) || !t.completedAt || !requests.some(r => r.id === t.requestId) ||
        !evidence.orders.some(o => o.orderId === t.orderId)))
        throw conflict();
    const cancelled = evidence.orders.every(o => o.verified && o.supplierStatus === 'cancel' && (0, exports.cancelledWithoutSale)(o.wbStatus));
    const eligibleSortingStatus = evidence.orders.every(o => (o.verified && o.supplierStatus === 'cancel' && (0, exports.cancelledWithoutSale)(o.wbStatus)) ||
        (o.verified && o.supplierStatus === 'complete' && o.wbStatus === 'sorted'));
    const uncertainHistory = physicalReview && evidence.orders.every(o => !o.verified ||
        (o.supplierStatus === 'cancel' && (0, exports.cancelledWithoutSale)(o.wbStatus)) ||
        (o.supplierStatus === 'complete' && o.wbStatus === 'sorted'));
    // FIX: require physical return evidence for released historical bindings.
    const released = links.some(t => t.status === 'RELEASED');
    const proof = (!cancelled || released) && ((eligibleSortingStatus && process.env.WMS_KIZ_SORTING_ADMIN_REUSE_ENABLED === 'true') || uncertainHistory)
        ? await (0, kiz_sorting_return_proof_1.findSortingReturnProof)(tx, clientId, identity, links) : null;
    if ((!cancelled || released) && !proof)
        throw conflict();
    for (const old of links) {
        const history = await tx.shippedKizHistory.findMany({ where: { clientId, orderId: old.orderId, requestId: old.requestId,
                OR: (0, kiz_sorting_return_proof_2.manualKizPrefixes)(identity).map(p => ({ kiz: { startsWith: p } })) } });
        if (!history.some(h => (0, kiz_sorting_return_proof_2.manualKizIdentity)(h.kiz) === identity))
            throw conflict();
        await tx.auditLog.create({ data: { userId, action: proof && physicalReview ? 'KIZ_PHYSICAL_BINDING_ARCHIVED' : proof ? 'KIZ_SORTING_BINDING_ARCHIVED' : 'KIZ_CANCELLED_BINDING_ARCHIVED', entity: 'FbsTsdAssembly', entityId: old.id,
                payload: JSON.parse(JSON.stringify({ reviewId, kizIdentity: identity, evidence, physicalConfirmation: physicalReview, sortingProof: proof, before: old })) } });
        const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: old.id, clientId, status: old.status, kiz: old.kiz, updatedAt: old.updatedAt }, data: { kiz: null } });
        if (changed.count !== 1)
            throw conflict();
    }
}

// FIX: immutable, per-serial recount evidence is required; an AVAILABLE flag alone is insufficient.
async function inventoryReturnProof(tx, clientId, identity, links, requests, evidence) {
    if (!links.length || links.some(t => !['COMPLETED', 'WB_ACCOUNTED', 'RELEASED'].includes(t.status) ||
        !requests.some(r => r.id === t.requestId) || !evidence.orders.some(o => o.orderId === t.orderId))) return null;
    // Fail closed on unknown/contradictory WB replies and any evidence of transmission.
    if (!evidence.orders.every(o => o.verified && ['cancel', 'complete'].includes(o.supplierStatus) &&
        cancelledWithoutSale(o.wbStatus) && o.containsKiz === false && o.supplyAccepted === false)) return null;
    const prefixes = kiz_sorting_return_proof_2.manualKizPrefixes(identity);
    const exact = value => kiz_sorting_return_proof_2.manualKizIdentity(value || '') === identity;
    const marks = (await tx.productMark.findMany({ where: { OR: prefixes.map(p => ({ value: { startsWith: p } })) } }))
        .filter(m => exact(m.value));
    if (marks.length !== 1 || marks[0].clientId !== clientId || marks[0].status !== 'AVAILABLE' || !marks[0].boxId) return null;
    const mark = marks[0];
    await tx.$queryRaw`SELECT id FROM "ProductMark" WHERE id = ${mark.id} FOR UPDATE`;
    const current = await tx.productMark.findUnique({ where: { id: mark.id } });
    if (!current || current.updatedAt.getTime() !== mark.updatedAt.getTime() || current.status !== 'AVAILABLE' ||
        current.clientId !== clientId || current.boxId !== mark.boxId || current.skuId !== mark.skuId || !exact(current.value)) return null;
    const box = await tx.box.findUnique({ where: { id: mark.boxId } });
    if (!box || box.clientId !== clientId || !box.warehouseId || ['archived', 'deleted'].includes(box.status) ||
        requests.some(r => r.warehouseId !== box.warehouseId)) return null;
    const allBindings = (await tx.fbsTsdAssembly.findMany({ where: { OR: prefixes.map(p => ({ kiz: { startsWith: p } })) } }))
        .filter(t => exact(t.kiz));
    if (allBindings.some(t => !links.some(old => old.id === t.id))) return null;
    const fbo = await tx.fboAssemblyUnit.findMany({ where: { OR: [{ activeMarkId: mark.id },
        { OR: prefixes.map(p => ({ kiz: { startsWith: p } })), state: { in: ['PICKED', 'PACKED'] },
          assembly: { phase: { not: 'COMPLETED' }, request: { status: { notIn: ['DONE', 'CANCELLED'] } } } }] } });
    if (fbo.some(u => u.activeMarkId === mark.id || exact(u.kiz))) return null;
    const history = (await tx.shippedKizHistory.findMany({ where: { OR: prefixes.map(p => ({ kiz: { startsWith: p } })) } }))
        .filter(h => exact(h.kiz));
    if (history.some(h => h.clientId !== clientId || h.warehouseId !== box.warehouseId ||
        !evidence.orders.some(o => o.orderId === h.orderId)) ||
        links.some(t => !history.some(h => h.assemblyId === t.id && h.orderId === t.orderId && h.requestId === t.requestId))) return null;
    const after = new Date(Math.max(...links.map(t => new Date(t.updatedAt).getTime()),
        ...history.map(h => new Date(h.shippedAt).getTime())));
    if (!Number.isFinite(after.getTime())) return null;
    const audit = await tx.auditLog.findFirst({ where: { action: 'INVENTORY_KIZ_COMPOSITION_CONFIRMED', entity: 'InventoryAuditBox',
        createdAt: { gt: after }, AND: [{ payload: { path: ['boxId'], equals: mark.boxId } },
        { payload: { path: ['clientId'], equals: clientId } }] }, orderBy: { createdAt: 'desc' } });
    const p = audit?.payload;
    if (!audit?.userId || !p || p.clientId !== clientId || p.warehouseId !== box.warehouseId || p.boxId !== mark.boxId ||
        !(new Date(p.roundStartedAt).getTime() > after.getTime()) ||
        !Array.isArray(p.scans) || p.scans.filter(s => s.identity === identity && s.skuId === mark.skuId && exact(s.value)).length !== 1 ||
        !Array.isArray(p.previousScannedMarks) || !p.previousScannedMarks.some(m => m.id === mark.id && m.clientId === clientId && exact(m.value))) return null;
    const balance = await tx.stockBalance.aggregate({ where: { clientId, warehouseId: box.warehouseId, skuId: mark.skuId,
        boxId: mark.boxId, status: 'AVAILABLE' }, _sum: { quantity: true } });
    if ((balance._sum.quantity ?? 0) < 1) return null;
    return { auditId: audit.id, auditBoxId: audit.entityId, confirmedBy: audit.userId, confirmedAt: audit.createdAt,
        markId: mark.id, boxId: mark.boxId, previousShipmentAt: after, shipmentIds: history.map(h => h.id) };
}

// FIX: a cancelled pick that never shipped has no shipment timestamp to return after.
async function unfinishedCancelledProof(tx, clientId, identity, links, requests, evidence) {
 if (!links.length || links.some(t => t.status !== 'RELEASED' || t.completedAt || !requests.some(r => r.id === t.requestId))) return null;
 if (evidence.orders.some(o => !links.some(t => t.orderId === o.orderId) || (o.verified && !(o.supplierStatus === 'cancel' && cancelledWithoutSale(o.wbStatus))))) return null;
 const prefixes = kiz_sorting_return_proof_2.manualKizPrefixes(identity);
 const history = await tx.shippedKizHistory.findMany({where:{clientId,OR:prefixes.map(p=>({kiz:{startsWith:p}}))}});
 if (history.some(h=>kiz_sorting_return_proof_2.manualKizIdentity(h.kiz)===identity)) return null;
 for (const t of links) {
  const cancellation=await tx.fbsOrderRequestLink.findFirst({where:{clientId,connectionId:t.connectionId,orderId:t.orderId,requestId:t.requestId,syncStatus:'REMOVED',lastSupplierStatus:'cancel',lastWbStatus:{in:['canceled','canceled_by_client','declined_by_client']},handedOverAt:null}});
  if (!cancellation) return null;
 }
 const marks=(await tx.productMark.findMany({where:{clientId,OR:prefixes.map(p=>({value:{startsWith:p}}))}})).filter(m=>kiz_sorting_return_proof_2.manualKizIdentity(m.value)===identity);
 if(marks.length!==1||marks[0].status!=='AVAILABLE'||!marks[0].boxId)return null;
 const mark=marks[0],after=new Date(Math.max(...links.map(t=>new Date(t.updatedAt).getTime())));
 if(!Number.isFinite(after.getTime()))return null;
 const audit=await tx.auditLog.findFirst({where:{action:{in:['PALLET_SORTING_UNIT_MOVED','PALLET_SORTING_UNIT_RECOVERED']},entity:'PalletSortingSession',createdAt:{gt:after},AND:[{payload:{path:['identity'],equals:identity}},{payload:{path:['markId'],equals:mark.id}},{payload:{path:['targetBoxId'],equals:mark.boxId}}]},orderBy:{createdAt:'desc'}});
 const proof=audit?.payload;
 if(!audit?.userId||!proof||proof.physicalTruth!==true||proof.quantity!==1||proof.targetClientId!==clientId||proof.skuId!==mark.skuId||typeof proof.movementId!=='string')return null;
 const movement=await tx.stockMovement.findFirst({where:{id:proof.movementId,clientId,skuId:mark.skuId,boxId:mark.boxId,warehouseId:String(proof.targetWarehouseId),status:'AVAILABLE',quantity:{gt:0},createdAt:{gt:after}}});
 return movement?{auditId:audit.id,movementId:movement.id,markId:mark.id,boxId:mark.boxId,sortedAt:audit.createdAt,releasedBefore:after}:null;
}
