"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recoveryWarehouse = recoveryWarehouse;
const common_1 = require("@nestjs/common");
// FIX: the actor and grants come from the database, never from an action payload.
function recoveryWarehouse(actor) {
    if (!actor || actor.status !== 'ACTIVE' || actor.isDemo)
        throw new common_1.ForbiddenException('Только администратор и собственник.');
    if (actor.roles.some(r => r.role.code === 'OWNER'))
        return null;
    if (!actor.roles.some(r => r.role.code === 'ADMIN'))
        throw new common_1.ForbiddenException('Только администратор и собственник.');
    if (process.env.WMS_RECEIPT_BARCODE_REVIEW_ENABLED === 'true') {
        const scope = actor.warehouseScopes.find(s => s.warehouseId === actor.activeWarehouseId && s.canRead && s.canWrite);
        if (scope)
            return scope.warehouseId;
        throw new common_1.ForbiddenException('Выберите закреплённый филиал с правом чтения и изменения.');
    }
    if (actor.warehouseScopes.length !== 1 || !actor.warehouseScopes[0].canRead || !actor.warehouseScopes[0].canWrite) {
        throw new common_1.ForbiddenException('Нужен один закреплённый филиал администратора.');
    }
    return actor.warehouseScopes[0].warehouseId;
}
