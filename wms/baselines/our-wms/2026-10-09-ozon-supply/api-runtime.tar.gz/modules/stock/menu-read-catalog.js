"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.instructionPayloadKeys = exports.menuReadsEnabled = void 0;
exports.leanInstructionCatalog = leanInstructionCatalog;
const client_1 = require("@prisma/client");
const menuReadsEnabled = () => process.env.WMS_MENU_READS_ENABLED === 'true';
exports.menuReadsEnabled = menuReadsEnabled;
// FIX: only keys consumed by buildShkCatalogFromSkus cross the DB boundary.
exports.instructionPayloadKeys = ['barcode', 'barCode', 'sku', 'offerBarcode', 'nmID', 'nmId', 'imtID', 'imtId', 'vendorCode', 'offerId',
    'brand', 'brandName', 'ip', 'seller', 'sellerName', 'supplierName', 'color', 'colour', 'colorName', 'size', 'techSize', 'russianSize'];
async function leanInstructionCatalog(db, clientId) {
    const rowsRead = db.sku.findMany({ where: { clientId }, omit: { marketplacePayload: true }, include: { barcodes: { select: { value: true, isPrimary: true } } } });
    // FIX: independent projections overlap; no completed stock response is cached.
    const payloadRead = db.$queryRaw(client_1.Prisma.sql `
    SELECT id, COALESCE((SELECT jsonb_object_agg(key,value)
      FROM jsonb_each(CASE WHEN jsonb_typeof("marketplacePayload")='object' THEN "marketplacePayload" ELSE '{}'::jsonb END)
      WHERE key IN (${client_1.Prisma.join(exports.instructionPayloadKeys)})), '{}'::jsonb) AS payload
    FROM "Sku" WHERE "clientId"=${clientId}`);
    const [rows, payloads] = await Promise.all([rowsRead, payloadRead]);
    const byId = new Map(payloads.map(r => [r.id, r.payload]));
    return rows.map(r => ({ ...r, marketplacePayload: byId.get(r.id) ?? null }));
}
