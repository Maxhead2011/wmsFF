"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttendanceDeviceController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const public_decorator_1 = require("../auth/decorators/public.decorator");
const attendance_device_service_1 = require("./attendance-device.service");
// FIX: Public bypasses WMS user JWT only; every device operation checks its own scoped token.
let AttendanceDeviceController = class AttendanceDeviceController {
    service;
    constructor(service) {
        this.service = service;
    }
    register(body, ip) { return this.service.register(body, ip); }
    state(token) { return this.service.state(token); }
    event(token, key, body) { return this.service.event(token, key, body); }
    receipts(token, body) { return this.service.acknowledge(token, body); }
    photo(token, key, id, body, file) { return this.service.uploadPhoto(token, id, key, body, file); }
};
exports.AttendanceDeviceController = AttendanceDeviceController;
__decorate([
    (0, common_1.Post)('register'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Ip)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof Record !== "undefined" && Record) === "function" ? _b : Object, String]),
    __metadata("design:returntype", void 0)
], AttendanceDeviceController.prototype, "register", null);
__decorate([
    (0, common_1.Get)('state'),
    __param(0, (0, common_1.Headers)('authorization')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AttendanceDeviceController.prototype, "state", null);
__decorate([
    (0, common_1.Post)('events'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Headers)('idempotency-key')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, typeof (_c = typeof Record !== "undefined" && Record) === "function" ? _c : Object]),
    __metadata("design:returntype", void 0)
], AttendanceDeviceController.prototype, "event", null);
__decorate([
    (0, common_1.Post)('receipts'),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof Record !== "undefined" && Record) === "function" ? _d : Object]),
    __metadata("design:returntype", void 0)
], AttendanceDeviceController.prototype, "receipts", null);
__decorate([
    (0, common_1.Post)('photo-requests/:id'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('photo', { limits: { fileSize: 4 * 1024 * 1024, files: 1, fields: 3, fieldSize: 200 } })),
    __param(0, (0, common_1.Headers)('authorization')),
    __param(1, (0, common_1.Headers)('idempotency-key')),
    __param(2, (0, common_1.Param)('id')),
    __param(3, (0, common_1.Body)()),
    __param(4, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, typeof (_e = typeof Record !== "undefined" && Record) === "function" ? _e : Object, typeof (_g = typeof Express !== "undefined" && (_f = Express.Multer) !== void 0 && _f.File) === "function" ? _g : Object]),
    __metadata("design:returntype", void 0)
], AttendanceDeviceController.prototype, "photo", null);
exports.AttendanceDeviceController = AttendanceDeviceController = __decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Controller)('attendance-device'),
    __metadata("design:paramtypes", [typeof (_a = typeof attendance_device_service_1.AttendanceDeviceService !== "undefined" && attendance_device_service_1.AttendanceDeviceService) === "function" ? _a : Object])
], AttendanceDeviceController);
