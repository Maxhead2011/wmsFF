"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonAssemblySupplyService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const ozon_supply_policy_1 = require("./ozon-supply-policy");
let OzonAssemblySupplyService = class OzonAssemblySupplyService {
    db;
    scopes;
    constructor(db, scopes) {
        this.db = db;
        this.scopes = scopes;
    }
    async load(id, user, mode = 'read', db = this.db) {
        if (process.env.WMS_OZON_FBO_IMPORT_ENABLED !== 'true')
            throw new common_1.NotFoundException('Связь Ozon выключена.');
        const s = await db.ozonFboShipment.findUnique({ where: { requestId: id }, include: { request: { include: { fboAssembly: { include: { boxes: true, units: true } } } } } });
        if (!s)
            throw new common_1.NotFoundException('Сборка Ozon не найдена.');
        this.scopes.requireClientAccess(user, s.request.clientId, mode);
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, s.request, mode);
        if (!user.activeWarehouseId || s.request.warehouseId !== user.activeWarehouseId)
            throw new common_1.NotFoundException('Выберите филиал сборки.');
        return s;
    }
    async connection(id, clientId) {
        const c = await this.db.clientMarketplaceConnection.findFirst({ where: { id, clientId, marketplace: 'OZON', isActive: true } });
        if (!c?.sellerId || !c.apiKey)
            throw new common_1.BadRequestException('Кабинет Ozon не настроен для этого клиента.');
        return c;
    }
    // FIX: only read operations retry throttling; a write with an unknown result is never repeated.
    async call(c, path, body, read = true) {
        for (let attempt = 0; attempt < 3; attempt++) {
            let r;
            try {
                r = await fetch('https://api-seller.ozon.ru' + path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Client-Id': c.sellerId, 'Api-Key': c.apiKey }, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
            }
            catch {
                throw new common_1.BadGatewayException('Нет подтверждённого ответа Ozon. Проверьте статус; не отправляйте повторно.');
            }
            if (read && r.status === 429 && attempt < 2) {
                await new Promise(r => setTimeout(r, 1500 * (attempt + 1)));
                continue;
            }
            const p = await r.json().catch(() => ({}));
            if (!r.ok)
                throw new common_1.BadGatewayException(`Ozon: HTTP ${r.status}. ${String(p.message ?? 'Ошибка запроса').slice(0, 300)}`);
            return p;
        }
    }
    async snapshot(c, orderId) {
        if (!/^\d+$/.test(orderId) || !Number.isSafeInteger(Number(orderId)))
            throw new common_1.BadRequestException('Укажите числовой ID заявки Ozon из адреса кабинета.');
        const data = await this.call(c, '/v3/supply-order/get', { order_ids: [Number(orderId)] });
        const o = data.orders?.find((o) => String(o.order_id) === orderId);
        if (!o?.supplies?.length)
            throw new common_1.NotFoundException('Поставка не найдена в выбранном кабинете Ozon.');
        const clusters = await this.call(c, '/v1/cluster/list', { cluster_type: 'CLUSTER_TYPE_OZON', cluster_ids: [] });
        const supplies = [];
        for (const s of o.supplies) {
            const items = [];
            let last = '';
            const seen = new Set();
            for (let page = 0;; page++) {
                if (page >= 100)
                    throw new common_1.BadGatewayException('Состав Ozon превышает лимит страниц.');
                await new Promise(r => setTimeout(r, 400));
                const b = await this.call(c, '/v1/supply-order/bundle', { bundle_ids: [s.bundle_id], limit: 100, last_id: last });
                if (!Array.isArray(b.items))
                    throw new common_1.BadGatewayException('Ozon не вернул состав поставки.');
                items.push(...b.items);
                if (!b.has_next)
                    break;
                if (!b.last_id || seen.has(b.last_id))
                    throw new common_1.BadGatewayException('Ошибка пагинации состава Ozon.');
                last = b.last_id;
                seen.add(last);
            }
            const cluster = clusters.clusters?.find((v) => String(v.macrolocal_cluster_id ?? v.id) === String(s.macrolocal_cluster_id));
            supplies.push({ id: String(s.supply_id), name: cluster?.name ?? s.storage_warehouse?.name ?? String(s.macrolocal_cluster_id), items: items.map(i => ({ barcode: String(i.barcode ?? ''), offerId: String(i.offer_id ?? ''), quantity: Number(i.quantity), quant: Number(i.quant) || 1 })) });
        }
        return { connectionId: c.id, orderId, orderNumber: String(o.order_number ?? orderId), place: o.drop_off_warehouse?.name ?? '', date: o.timeslot?.timeslot?.from ?? '', state: o.state, supplies, mapping: {}, operations: {}, checkedAt: new Date().toISOString() };
    }
    async locked(id, user, fn) {
        return this.db.$transaction(async (tx) => { await tx.$queryRaw `SELECT "id" FROM "ClientRequest" WHERE "id"=${id} FOR UPDATE`; const s = await this.load(id, user, 'write', tx); return fn(s, tx); });
    }
    async save(tx, id, link, user, action) {
        await tx.ozonFboShipment.update({ where: { requestId: id }, data: { integration: link } });
        await tx.auditLog.create({ data: { userId: user.id, action, entity: 'ClientRequest', entityId: id, payload: { orderId: link.orderId, operations: link.operations } } });
    }
    async view(id, user) {
        const s = await this.load(id, user), link = s.integration;
        const connections = await this.db.clientMarketplaceConnection.findMany({ where: { clientId: s.request.clientId, marketplace: 'OZON', isActive: true }, select: { id: true, accountName: true, sellerId: true } });
        let packingError = '';
        if (link)
            try {
                (0, ozon_supply_policy_1.packedCargoes)(s.directions, link, s.request.fboAssembly);
            }
            catch (e) {
                packingError = e instanceof Error ? e.message : String(e);
            }
        return { requestId: id, directions: s.directions, connections, link, differences: link ? (0, ozon_supply_policy_1.supplyDifferences)(s.directions, link) : [], packingError };
    }
    async bind(id, body, user) {
        const s = await this.load(id, user, 'write');
        if (s.integration?.frozenHash)
            throw new common_1.ConflictException('Состав уже отправляется. Привязка заблокирована.');
        const c = await this.connection(body.connectionId, s.request.clientId), link = await this.snapshot(c, String(body.orderId).trim());
        if (await this.db.ozonFboPlan.findFirst({ where: { connectionId: c.id, ozonOrderId: link.orderId } }))
            throw new common_1.ConflictException('Эта поставка уже используется в прежнем плане Ozon. Нужен перенос плана, а не вторая сборка.');
        // Exact names may be suggested; the user sees and explicitly saves all mappings.
        for (const d of s.directions) {
            const matches = link.supplies.filter(v => v.name.trim().toLocaleLowerCase() === d.name.trim().toLocaleLowerCase());
            if (matches.length === 1)
                link.mapping[d.name] = matches[0].id;
        }
        await this.locked(id, user, async (current, tx) => {
            if (current.integration?.frozenHash)
                throw new common_1.ConflictException('Отправка уже началась.');
            const key = `${c.sellerId}:${link.orderId}`;
            const other = await tx.ozonFboShipment.findUnique({ where: { externalOrderKey: key } });
            if (other && other.requestId !== id)
                throw new common_1.ConflictException('Поставка Ozon уже привязана к другой сборке.');
            await tx.ozonFboShipment.update({ where: { requestId: id }, data: { externalOrderKey: key } });
            await this.save(tx, id, link, user, 'OZON_SUPPLY_BOUND');
        });
        return this.view(id, user);
    }
    async map(id, mapping, user) {
        await this.locked(id, user, async (s, tx) => {
            const l = s.integration;
            if (!l)
                throw new common_1.ConflictException('Сначала привяжите поставку.');
            if (l.frozenHash)
                throw new common_1.ConflictException('Отправка уже началась.');
            if (!mapping || typeof mapping !== 'object' || Array.isArray(mapping))
                throw new common_1.BadRequestException('Неверное сопоставление.');
            const clean = {};
            for (const d of s.directions) {
                const v = mapping[d.name];
                if (v) {
                    if (!l.supplies.some(s => s.id === v))
                        throw new common_1.BadRequestException('Неизвестное направление Ozon.');
                    clean[d.name] = v;
                }
            }
            l.mapping = clean;
            await this.save(tx, id, l, user, 'OZON_SUPPLY_MAPPING');
        });
        return this.view(id, user);
    }
    async refresh(id, user) {
        const s = await this.load(id, user, 'write'), old = s.integration;
        if (!old)
            throw new common_1.ConflictException('Сначала привяжите поставку.');
        const c = await this.connection(old.connectionId, s.request.clientId), fresh = await this.snapshot(c, old.orderId);
        await this.locked(id, user, async (cur, tx) => { const l = cur.integration; if (l?.orderId !== old.orderId || l.connectionId !== old.connectionId)
            throw new common_1.ConflictException('Привязка изменилась. Обновите экран.'); await this.save(tx, id, { ...fresh, mapping: l.mapping, operations: l.operations, frozenHash: l.frozenHash }, user, 'OZON_SUPPLY_REFRESH'); });
        return this.view(id, user);
    }
    async upload(id, confirm, user) {
        if (confirm !== true)
            throw new common_1.BadRequestException('Подтвердите передачу проверенных коробов.');
        await this.refresh(id, user);
        const s = await this.load(id, user, 'write'), l = s.integration, c = await this.connection(l.connectionId, s.request.clientId);
        if (l.state !== 'DATA_FILLING')
            throw new common_1.ConflictException('Поставка Ozon не в статусе заполнения данных.');
        const cargoes = (0, ozon_supply_policy_1.packedCargoes)(s.directions, l, s.request.fboAssembly);
        for (const supplyId of Object.keys(cargoes)) {
            if (l.operations[supplyId])
                continue;
            const existing = await this.call(c, '/v1/cargoes/supplies/get', { supply_ids: [Number(supplyId)] });
            const remote = existing.supplies_cargoes?.find((v) => String(v.supply_id) === supplyId);
            if (!remote || remote.transport_cargoes?.length || remote.cargoes_without_transport_cargoes?.length)
                throw new common_1.ConflictException('В Ozon уже есть грузоместа или их состав не подтверждён. Автоматическая замена запрещена.');
            const claimed = await this.locked(id, user, async (cur, tx) => {
                const link = cur.integration;
                if (link.operations[supplyId])
                    return false;
                if (link.orderId !== l.orderId || link.connectionId !== l.connectionId)
                    throw new common_1.ConflictException('Привязка изменилась.');
                const now = (0, ozon_supply_policy_1.packedCargoes)(cur.directions, link, cur.request.fboAssembly), hash = (0, ozon_supply_policy_1.cargoHash)(now);
                if (hash !== (0, ozon_supply_policy_1.cargoHash)(cargoes) || (link.frozenHash && link.frozenHash !== hash))
                    throw new common_1.ConflictException('Состав изменился. Повторите сверку.');
                link.frozenHash = hash;
                link.operations[supplyId] = { state: 'SENDING' };
                await this.save(tx, id, link, user, 'OZON_CARGO_SENDING');
                return true;
            });
            if (!claimed)
                continue;
            try {
                const result = await this.call(c, '/v1/cargoes/create', { supply_id: Number(supplyId), delete_current_version: false, cargoes: cargoes[supplyId] }, false);
                if (!result.operation_id)
                    throw new Error('Ozon не вернул номер операции.');
                await this.locked(id, user, async (cur, tx) => { const link = cur.integration; link.operations[supplyId] = { state: 'ACCEPTED', operationId: String(result.operation_id) }; await this.save(tx, id, link, user, 'OZON_CARGO_ACCEPTED'); });
            }
            catch (e) {
                await this.locked(id, user, async (cur, tx) => { const link = cur.integration; if (!link.operations[supplyId]?.operationId) {
                    link.operations[supplyId] = { state: 'UNKNOWN', error: e instanceof Error ? e.message : String(e) };
                    await this.save(tx, id, link, user, 'OZON_CARGO_UNKNOWN');
                } });
                throw new common_1.ConflictException('Ответ Ozon не подтверждён. Повторная отправка заблокирована; нужна сверка грузомест.');
            }
        }
        return this.status(id, user);
    }
    async status(id, user) {
        const s = await this.load(id, user, 'write'), l = s.integration;
        if (!l)
            throw new common_1.ConflictException('Нет привязки.');
        const c = await this.connection(l.connectionId, s.request.clientId);
        for (const [supplyId, op] of Object.entries(l.operations)) {
            if (!op.operationId)
                continue;
            const r = await this.call(c, '/v2/cargoes/create/info', { operation_id: op.operationId });
            const state = r.status === 'SUCCESS' ? 'SUCCESS' : r.status === 'FAILED' ? 'FAILED' : 'ACCEPTED';
            await this.locked(id, user, async (cur, tx) => {
                const link = cur.integration;
                const current = link.operations[supplyId];
                if (current.operationId !== op.operationId)
                    return;
                current.state = state;
                current.error = r.errors?.length ? JSON.stringify(r.errors) : undefined;
                if (state === 'SUCCESS')
                    current.cargoes = (r.result?.cargoes ?? []).map((v) => ({ key: String(v.key), cargoId: String(v.value?.cargo_id ?? '') }));
                await this.save(tx, id, link, user, 'OZON_CARGO_STATUS');
            });
        }
        return this.view(id, user);
    }
    async labels(id, supplyId, user) {
        const s = await this.load(id, user, 'write'), l = s.integration, op = l?.operations[supplyId];
        if (!op || op.state !== 'SUCCESS' || !op.cargoes?.length || op.cargoes.some(v => !/^\d+$/.test(v.cargoId)))
            throw new common_1.ConflictException('Сначала дождитесь подтверждения грузомест Ozon.');
        const c = await this.connection(l.connectionId, s.request.clientId);
        let operationId = op.labelOperationId;
        if (!operationId) {
            const created = await this.call(c, '/v1/cargoes-label/create', { supply_id: Number(supplyId), cargoes: op.cargoes.map(v => ({ cargo_id: Number(v.cargoId) })) }, false);
            operationId = String(created.operation_id ?? '');
            if (!operationId)
                throw new common_1.BadGatewayException('Ozon не вернул операцию подготовки этикеток.');
            await this.locked(id, user, async (cur, tx) => { const link = cur.integration; link.operations[supplyId].labelOperationId = operationId; await this.save(tx, id, link, user, 'OZON_LABEL_REQUEST'); });
        }
        const result = await this.call(c, '/v1/cargoes-label/get', { operation_id: operationId });
        const url = result.result?.file_url ?? result.file_url;
        if (url) {
            if (typeof url !== 'string' || !url.startsWith('https://'))
                throw new common_1.BadGatewayException('Ozon вернул некорректную ссылку этикеток.');
            await this.locked(id, user, async (cur, tx) => { const link = cur.integration; link.operations[supplyId].labelUrl = url; await this.save(tx, id, link, user, 'OZON_LABEL_READY'); });
        }
        return this.view(id, user);
    }
};
exports.OzonAssemblySupplyService = OzonAssemblySupplyService;
exports.OzonAssemblySupplyService = OzonAssemblySupplyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], OzonAssemblySupplyService);
