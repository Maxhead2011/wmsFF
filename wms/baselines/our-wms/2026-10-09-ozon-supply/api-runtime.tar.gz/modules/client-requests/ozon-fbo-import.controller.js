"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonFboImportController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const import_outbound_request_xlsx_dto_1 = require("./dto/import-outbound-request-xlsx.dto");
const ozon_fbo_import_service_1 = require("./ozon-fbo-import.service");
let OzonFboImportController = class OzonFboImportController {
    service;
    constructor(service) {
        this.service = service;
    }
    capability() { return { enabled: process.env.WMS_OZON_FBO_IMPORT_ENABLED === 'true' }; }
    list(clientId, user) { return this.service.list(clientId, user); }
    preview(file, dto, user) { return this.service.preview(file, dto, user); }
    commit(file, dto, user) { return this.service.commit(file, dto, user); }
};
exports.OzonFboImportController = OzonFboImportController;
__decorate([
    (0, common_1.Get)('capability'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "capability", null);
__decorate([
    (0, common_1.Get)('requests'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('preview'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_c = typeof Express !== "undefined" && (_b = Express.Multer) !== void 0 && _b.File) === "function" ? _c : Object, typeof (_d = typeof import_outbound_request_xlsx_dto_1.ImportOutboundRequestXlsxDto !== "undefined" && import_outbound_request_xlsx_dto_1.ImportOutboundRequestXlsxDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)('commit'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_f = typeof Express !== "undefined" && (_e = Express.Multer) !== void 0 && _e.File) === "function" ? _f : Object, typeof (_g = typeof import_outbound_request_xlsx_dto_1.ImportOutboundRequestXlsxDto !== "undefined" && import_outbound_request_xlsx_dto_1.ImportOutboundRequestXlsxDto) === "function" ? _g : Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "commit", null);
exports.OzonFboImportController = OzonFboImportController = __decorate([
    (0, common_1.Controller)('ozon-fbo-import'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __metadata("design:paramtypes", [typeof (_a = typeof ozon_fbo_import_service_1.OzonFboImportService !== "undefined" && ozon_fbo_import_service_1.OzonFboImportService) === "function" ? _a : Object])
], OzonFboImportController);
