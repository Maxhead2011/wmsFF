"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonAssemblySupplyController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const ozon_assembly_supply_service_1 = require("./ozon-assembly-supply.service");
// FIX: all external writes are explicit actions on one scoped customer assembly.
let OzonAssemblySupplyController = class OzonAssemblySupplyController {
    service;
    constructor(service) {
        this.service = service;
    }
    view(id, user) { return this.service.view(id, user); }
    bind(id, body, user) { return this.service.bind(id, body, user); }
    map(id, body, user) { return this.service.map(id, body.mapping, user); }
    refresh(id, user) { return this.service.refresh(id, user); }
    upload(id, body, user) { return this.service.upload(id, body.confirm, user); }
    status(id, user) { return this.service.status(id, user); }
    labels(id, body, user) { return this.service.labels(id, body.supplyId, user); }
};
exports.OzonAssemblySupplyController = OzonAssemblySupplyController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonAssemblySupplyController.prototype, "view", null);
__decorate([
    (0, common_1.Post)('bind'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonAssemblySupplyController.prototype, "bind", null);
__decorate([
    (0, common_1.Post)('mapping'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonAssemblySupplyController.prototype, "map", null);
__decorate([
    (0, common_1.Post)('refresh'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonAssemblySupplyController.prototype, "refresh", null);
__decorate([
    (0, common_1.Post)('upload'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonAssemblySupplyController.prototype, "upload", null);
__decorate([
    (0, common_1.Post)('status'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonAssemblySupplyController.prototype, "status", null);
__decorate([
    (0, common_1.Post)('labels'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonAssemblySupplyController.prototype, "labels", null);
exports.OzonAssemblySupplyController = OzonAssemblySupplyController = __decorate([
    (0, common_1.Controller)('ozon-fbo-import/requests/:id/supply'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __metadata("design:paramtypes", [typeof (_a = typeof ozon_assembly_supply_service_1.OzonAssemblySupplyService !== "undefined" && ozon_assembly_supply_service_1.OzonAssemblySupplyService) === "function" ? _a : Object])
], OzonAssemblySupplyController);
