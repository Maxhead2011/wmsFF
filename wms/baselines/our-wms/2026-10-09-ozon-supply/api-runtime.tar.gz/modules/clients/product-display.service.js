"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductDisplayService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const product_display_policy_1 = require("./product-display.policy");
let ProductDisplayService = class ProductDisplayService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    async check(clientId, user, mode) {
        if (process.env.WMS_CLIENT_PRODUCT_DISPLAY_ENABLED !== 'true') {
            throw new common_1.NotFoundException('Настройка отображения товаров не включена.');
        }
        this.scopes.requireClientAccess(user, clientId, mode);
        const client = await this.prisma.client.findFirst({
            where: { id: clientId, isDemo: Boolean(user.isDemo) }, select: { id: true },
        });
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
    }
    async get(clientId, user) {
        await this.check(clientId, user, 'read');
        const setting = await this.prisma.systemSetting.findUnique({ where: { key: this.key(clientId) } });
        // FIX: null keeps the existing screen defaults; no mass rewrite of client preferences.
        return { clientId, fields: (0, product_display_policy_1.validProductDisplayFields)(setting?.value) ? setting.value : null };
    }
    async save(clientId, fields, user) {
        await this.check(clientId, user, 'write');
        if (fields !== null && !(0, product_display_policy_1.validProductDisplayFields)(fields)) {
            throw new common_1.BadRequestException('Выберите от одного до пяти разных полей товара.');
        }
        const key = this.key(clientId);
        // FIX: keep the author/time when restoring defaults as well as saving a custom selection.
        await this.prisma.systemSetting.upsert({
            where: { key },
            create: { key, value: fields ?? { defaults: true }, updatedByUserId: user.id },
            update: { value: fields ?? { defaults: true }, updatedByUserId: user.id },
        });
        return { clientId, fields };
    }
    key(clientId) { return `client.product-display.v1:${clientId}`; }
};
exports.ProductDisplayService = ProductDisplayService;
exports.ProductDisplayService = ProductDisplayService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService])
], ProductDisplayService);
