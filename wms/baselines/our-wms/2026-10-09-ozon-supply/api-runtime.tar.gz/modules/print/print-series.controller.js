"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintSeriesController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const print_series_service_1 = require("./print-series.service");
// FIX: isolated opt-in queue; old agents cannot claim a multi-page job.
let PrintSeriesController = class PrintSeriesController {
    service;
    constructor(service) {
        this.service = service;
    }
    stations(u) { return this.service.stations(u); }
    create(b, u) { return this.service.create(b ?? {}, u); }
    heartbeat(id, u) { return this.service.heartbeat(id, u); }
    claim(id, u) { return this.service.claim(id, u); }
    finish(station, id, b, u) { return this.service.finish(station, id, b?.success, b?.error, u); }
};
exports.PrintSeriesController = PrintSeriesController;
__decorate([
    (0, common_1.Get)('stations'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PrintSeriesController.prototype, "stations", null);
__decorate([
    (0, common_1.Post)('jobs'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], PrintSeriesController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('stations/:id/heartbeat'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PrintSeriesController.prototype, "heartbeat", null);
__decorate([
    (0, common_1.Post)('stations/:id/claim'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PrintSeriesController.prototype, "claim", null);
__decorate([
    (0, common_1.Post)('stations/:station/jobs/:id/result'),
    __param(0, (0, common_1.Param)('station')),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", void 0)
], PrintSeriesController.prototype, "finish", null);
exports.PrintSeriesController = PrintSeriesController = __decorate([
    (0, common_1.Controller)('print/series'),
    (0, require_permissions_decorator_1.RequirePermissions)('print:write'),
    __metadata("design:paramtypes", [typeof (_a = typeof print_series_service_1.PrintSeriesService !== "undefined" && print_series_service_1.PrintSeriesService) === "function" ? _a : Object])
], PrintSeriesController);
