"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintSeriesService = void 0;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const key = (id) => `print.series.agent.v1:${id}`;
function text(v) {
    if (typeof v !== 'string' || !v.trim() || v.length > 150)
        throw new common_1.BadRequestException('Неверный идентификатор.');
    return v.trim();
}
let PrintSeriesService = class PrintSeriesService {
    prisma;
    clients;
    constructor(prisma, clients) {
        this.prisma = prisma;
        this.clients = clients;
    }
    scope(user) {
        if (process.env.WMS_PRINT_SERIES_ENABLED !== 'true')
            throw new common_1.NotFoundException('Серийная печать не включена.');
        if (user.isDemo || !user.permissionCodes.some(p => ['system:admin', 'print:write'].includes(p)))
            throw new common_1.ForbiddenException();
        if (!user.activeWarehouseId)
            throw new common_1.BadRequestException('Выберите филиал.');
        return user.activeWarehouseId;
    }
    async binding(stationId, user, agent = false, fresh = false) {
        const warehouseId = this.scope(user);
        const [station, setting] = await Promise.all([
            this.prisma.fbsPrintStation.findFirst({ where: { id: stationId, enabled: true } }),
            this.prisma.systemSetting.findUnique({ where: { key: key(stationId) } }),
        ]);
        const b = setting?.value;
        if (!station || !b || b.warehouseId !== warehouseId || agent && b.userId !== user.id)
            throw new common_1.ForbiddenException('Обновлённый агент этого филиала недоступен.');
        if (fresh && (!Number.isFinite(b.seenAt) || Date.now() - b.seenAt > 120_000))
            throw new common_1.ConflictException('Запустите обновлённый агент печати.');
        return b;
    }
    async heartbeat(stationId, user) {
        const warehouseId = this.scope(user);
        stationId = text(stationId);
        if (!await this.prisma.fbsPrintStation.findFirst({ where: { id: stationId, enabled: true } }))
            throw new common_1.NotFoundException('Станция не найдена.');
        const prior = await this.prisma.systemSetting.findUnique({ where: { key: key(stationId) } });
        const b = prior?.value;
        if (b && (b.userId !== user.id || b.warehouseId !== warehouseId))
            throw new common_1.ForbiddenException('Станция закреплена за другим агентом.');
        if (prior)
            await this.prisma.systemSetting.update({ where: { key: key(stationId) }, data: { value: { ...b, seenAt: Date.now() } } });
        else
            await this.prisma.systemSetting.create({ data: { key: key(stationId), value: { userId: user.id, warehouseId, seenAt: Date.now() } } });
        return { ready: true, version: 1 };
    }
    async stations(user) {
        const warehouseId = this.scope(user);
        const settings = await this.prisma.systemSetting.findMany({ where: { key: { startsWith: 'print.series.agent.v1:' } } });
        const ids = settings.filter(s => { const b = s.value; return b.warehouseId === warehouseId && Date.now() - b.seenAt < 120_000; }).map(s => s.key.slice('print.series.agent.v1:'.length));
        return this.prisma.fbsPrintStation.findMany({ where: { id: { in: ids }, enabled: true }, select: { id: true, name: true, printerName: true } });
    }
    async create(body, user) {
        const warehouseId = this.scope(user), clientId = text(body.clientId), stationId = text(body.stationId), requestId = text(body.requestId);
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(requestId))
            throw new common_1.BadRequestException('Неверный номер операции.');
        this.clients.requireClientAccess(user, clientId, 'read');
        if (!await this.prisma.warehouseClient.findFirst({ where: { clientId, warehouseId } }))
            throw new common_1.ForbiddenException('Клиент недоступен в филиале.');
        const w = body.widthMm, h = body.heightMm;
        if (typeof w !== 'number' || typeof h !== 'number' || !Number.isInteger(w) || !Number.isInteger(h) || w < 20 || w > 150 || h < 20 || h > 150)
            throw new common_1.BadRequestException('Размер этикетки — от 20 до 150 мм.');
        if (!Array.isArray(body.pages) || body.pages.length < 1 || body.pages.length > 500)
            throw new common_1.BadRequestException('Серия — от 1 до 500 этикеток.');
        let total = 0, pixels = 0;
        const pages = body.pages.map(p => {
            const value = text(p?.value), imageBase64 = p?.imageBase64;
            if (typeof imageBase64 !== 'string' || imageBase64.length > 1_500_000 || !/^[A-Za-z0-9+/]+={0,2}$/.test(imageBase64))
                throw new common_1.BadRequestException('Неверное изображение этикетки.');
            total += imageBase64.length;
            if (total > 8_000_000)
                throw new common_1.BadRequestException('Серия слишком велика: уменьшите количество этикеток.');
            const b = Buffer.from(imageBase64, 'base64');
            if (b.length < 24 || b.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a')
                throw new common_1.BadRequestException('Ожидается PNG.');
            const pw = b.readUInt32BE(16), ph = b.readUInt32BE(20);
            if (pw < 100 || pw > 2000 || ph < 100 || ph > 3000 || Math.abs(pw / ph - w / h) > 0.08)
                throw new common_1.BadRequestException('Неверный размер PNG.');
            pixels += pw * ph;
            if (pixels > 60_000_000)
                throw new common_1.BadRequestException("Серия слишком велика: уменьшите количество этикеток.");
            return { value, imageBase64 };
        });
        // FIX: the UUID binds the entire series, including order, to one durable job.
        const payload = { source: 'SERIES_V1', warehouseId, clientId, requestedById: user.id, widthMm: w, heightMm: h, pages };
        const digest = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify({ stationId, ...payload })).digest('hex');
        const id = `series:${requestId}`;
        const match = (job) => { if (job.payload?.digest !== digest)
            throw new common_1.ConflictException('Номер операции уже использован для другой серии.'); return { id: job.id, status: job.status, pages: pages.length }; };
        const existing = await this.prisma.printJob.findUnique({ where: { id } });
        if (existing)
            return match(existing);
        await this.binding(stationId, user, false, true);
        try {
            const job = await this.prisma.printJob.create({ data: { id, printerCode: `SERIES:${stationId}`, labelType: 'CUSTOM', status: 'queued', tspl: 'IMAGE/PNG-SERIES', payload: { ...payload, digest } } });
            return match(job);
        }
        catch (e) {
            if (e.code !== 'P2002')
                throw e;
            const job = await this.prisma.printJob.findUnique({ where: { id } });
            if (!job)
                throw e;
            return match(job);
        }
    }
    async claim(stationId, user) {
        await this.binding(stationId, user, true);
        // FIX: never reclaim sent/uncertain jobs; a lost ACK must not duplicate a whole series.
        return this.prisma.$transaction(async (tx) => {
            const job = await tx.printJob.findFirst({ where: { printerCode: `SERIES:${stationId}`, status: 'queued' }, orderBy: [{ createdAt: 'asc' }, { id: 'asc' }] });
            if (!job)
                return null;
            const claimed = await tx.printJob.updateMany({ where: { id: job.id, status: 'queued' }, data: { status: 'sent', attempts: { increment: 1 }, processedAt: new Date() } });
            if (!claimed.count)
                return null;
            return { id: job.id, ...job.payload };
        });
    }
    async finish(stationId, id, success, error, user) {
        await this.binding(stationId, user, true);
        if (typeof success !== 'boolean')
            throw new common_1.BadRequestException('Неверный результат.');
        const job = await this.prisma.printJob.findFirst({ where: { id, printerCode: `SERIES:${stationId}` } });
        if (!job)
            throw new common_1.NotFoundException();
        const status = success ? 'printed' : 'failed';
        if (job.status === status)
            return { id, status };
        if (job.status !== 'sent')
            throw new common_1.ConflictException('Задание уже завершено.');
        const changed = await this.prisma.printJob.updateMany({ where: { id, status: 'sent' }, data: { status, processedAt: new Date(), payload: { ...job.payload, error: success ? null : String(error ?? 'Ошибка печати').slice(0, 500) } } });
        if (!changed.count)
            throw new common_1.ConflictException('Результат изменился.');
        return { id, status };
    }
};
exports.PrintSeriesService = PrintSeriesService;
exports.PrintSeriesService = PrintSeriesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], PrintSeriesService);
