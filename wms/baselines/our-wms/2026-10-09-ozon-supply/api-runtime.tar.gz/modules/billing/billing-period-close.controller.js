"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingPeriodCloseController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const billing_period_close_service_1 = require("./billing-period-close.service");
const billing_period_close_dto_1 = require("./dto/billing-period-close.dto");
let BillingPeriodCloseController = class BillingPeriodCloseController {
    periods;
    constructor(periods) {
        this.periods = periods;
    }
    capabilities() { return this.periods.capabilities(); }
    list(dto, user) { return this.periods.list(dto, user); }
    history(dto, user) { return this.periods.correctionHistory(dto, user); }
    preview(dto, user) { return this.periods.preview(dto, user); }
    close(dto, user) { return this.periods.close(dto, user); }
    previewCorrection(dto, user) { return this.periods.previewCorrection(dto, user); }
    correction(dto, user) { return this.periods.createCorrection(dto, user); }
};
exports.BillingPeriodCloseController = BillingPeriodCloseController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], BillingPeriodCloseController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [billing_period_close_dto_1.BillingCloseQuery, Object]),
    __metadata("design:returntype", void 0)
], BillingPeriodCloseController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('corrections'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [billing_period_close_dto_1.BillingCloseQuery, Object]),
    __metadata("design:returntype", void 0)
], BillingPeriodCloseController.prototype, "history", null);
__decorate([
    (0, common_1.Post)('preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [billing_period_close_dto_1.BillingCloseQuery, Object]),
    __metadata("design:returntype", void 0)
], BillingPeriodCloseController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [billing_period_close_dto_1.CloseBillingPeriodDto, Object]),
    __metadata("design:returntype", void 0)
], BillingPeriodCloseController.prototype, "close", null);
__decorate([
    (0, common_1.Post)('corrections/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [billing_period_close_dto_1.PreviewInvoiceCorrectionDto, Object]),
    __metadata("design:returntype", void 0)
], BillingPeriodCloseController.prototype, "previewCorrection", null);
__decorate([
    (0, common_1.Post)('corrections'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [billing_period_close_dto_1.CreateInvoiceCorrectionDto, Object]),
    __metadata("design:returntype", void 0)
], BillingPeriodCloseController.prototype, "correction", null);
exports.BillingPeriodCloseController = BillingPeriodCloseController = __decorate([
    (0, common_1.Controller)('billing/period-close'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:read'),
    __metadata("design:paramtypes", [billing_period_close_service_1.BillingPeriodCloseService])
], BillingPeriodCloseController);
