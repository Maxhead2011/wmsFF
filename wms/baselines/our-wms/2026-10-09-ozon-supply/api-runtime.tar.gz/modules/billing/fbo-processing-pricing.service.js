"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FboProcessingPricingService = void 0;
exports.legacyFboConditions = legacyFboConditions;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const billing_mutation_1 = require("./billing-mutation");
const fbo_processing_pricing_policy_1 = require("./fbo-processing-pricing.policy");
const clientInclude = { billingServicePrices: { include: { service: true } }, fbsBillingSettings: { include: { additionalServices: { include: { service: true } } } } };
// FIX: inspect existing conditions without running the legacy GET that creates defaults.
function legacyFboConditions(client) {
    const prices = client.billingServicePrices ?? [];
    const selected = client.fbsBillingSettings?.additionalServices ?? [];
    const ids = new Set(selected.map((part) => part.serviceId));
    const existing = prices.filter((part) => ids.has(part.serviceId) || (part.isActive && Number(part.priceRub) > 0 && (['ITEM_PROCESSING', 'NOM_ОБРАБОТКА_ОДЕЖДЫ'].includes(part.service.code) || part.service.code.startsWith('NOM_ОТРЕЗ_'))));
    return {
        protected: selected.length > 0 || existing.length > 0 || Boolean(client.fbsBillingSettings?.primaryProcessingEnabled && ['primaryWhiteUnitPriceRub', 'primaryGrayUnitPriceRub', 'primaryReturnUnitPriceRub'].some(key => Number(client.fbsBillingSettings[key]) > 0)),
        services: [...new Set([...existing.map((p) => p.serviceId), ...ids])].map(id => {
            const price = prices.find((p) => p.serviceId === id), selection = selected.find((p) => p.serviceId === id), service = price?.service ?? selection?.service;
            return { serviceId: id, name: service.name, priceRub: price?.priceRub.toString() ?? null, taxMode: price?.taxMode ?? null, isActive: price?.isActive ?? false, multiplier: selection?.quantityMultiplier.toString() ?? '1', matchKeywords: selection?.matchKeywords ?? null };
        }),
        primaryFbs: client.fbsBillingSettings?.primaryProcessingEnabled ? { white: client.fbsBillingSettings.primaryWhiteUnitPriceRub.toString(), gray: client.fbsBillingSettings.primaryGrayUnitPriceRub.toString(), returned: client.fbsBillingSettings.primaryReturnUnitPriceRub.toString() } : null,
    };
}
let FboProcessingPricingService = class FboProcessingPricingService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    requireEnabled() {
        if (!(0, fbo_processing_pricing_policy_1.fboProcessingPricingEnabled)())
            throw new common_1.NotFoundException('Настройка первоначальной обработки не включена.');
    }
    requirePermission(user, permission) {
        if (!user.permissionCodes.includes(permission) && !user.permissionCodes.includes('system:admin'))
            throw new common_1.ForbiddenException('Нет доступа к первоначальной обработке.');
    }
    async list(user) {
        this.requirePermission(user, 'billing:read');
        if (!(0, fbo_processing_pricing_policy_1.fboProcessingPricingEnabled)())
            return { enabled: false };
        const filter = this.scopes.resolveClientFilter(user);
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SET TRANSACTION READ ONLY`;
            const clients = await tx.client.findMany({ where: { id: filter, isDemo: Boolean(user.isDemo) }, include: clientInclude, orderBy: { name: 'asc' } });
            const ids = clients.map(client => client.id);
            const tariffs = ids.length ? await tx.$queryRaw `SELECT * FROM "ClientFboProcessingTariff" WHERE "clientId" IN (${client_1.Prisma.join(ids)})` : [];
            const services = (await tx.billingService.findMany({ where: { isActive: true, unit: 'PIECE' }, orderBy: { name: 'asc' } })).filter(fbo_processing_pricing_policy_1.selectableFboService).map(service => ({ id: service.id, code: service.code, name: service.name, defaultPriceRub: service.defaultPriceRub?.toString() ?? null }));
            return { enabled: true, services, clients: clients.map(client => ({ id: client.id, code: client.code, name: client.name, status: client.status, legacy: legacyFboConditions(client), tariff: tariffs.find(t => t.clientId === client.id) ?? null })) };
        });
    }
    async products(clientId, search, user) {
        this.requireEnabled();
        this.requirePermission(user, 'billing:read');
        this.scopes.requireClientAccess(user, clientId, 'read');
        if (search.length > 120)
            throw new common_1.BadRequestException('Слишком длинный поисковый запрос.');
        const client = await this.prisma.client.findFirst({ where: { id: clientId, isDemo: Boolean(user.isDemo) }, select: { id: true } });
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
        const query = search.trim();
        return this.prisma.sku.findMany({ where: { clientId, ...(query ? { OR: [{ name: { contains: query, mode: 'insensitive' } }, { article: { contains: query, mode: 'insensitive' } }, { barcodes: { some: { value: { contains: query } } } }] } : {}) }, select: { id: true, name: true, article: true, size: true, barcodes: { select: { value: true } } }, orderBy: { name: 'asc' }, take: 30 });
    }
    async create(clientId, dto, user) {
        this.requireEnabled();
        this.requirePermission(user, 'billing:write');
        this.scopes.requireClientAccess(user, clientId, 'write');
        return (0, billing_mutation_1.runBillingMutation)(this.prisma, async (tx) => {
            const client = await tx.client.findFirst({ where: { id: clientId, isDemo: Boolean(user.isDemo) }, include: clientInclude });
            if (!client)
                throw new common_1.NotFoundException('Клиент не найден.');
            const catalog = await tx.billingService.findMany({ where: { isActive: true, unit: 'PIECE' } });
            const definition = (0, fbo_processing_pricing_policy_1.normalizeFboTariff)(dto.definition, catalog);
            const hash = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(definition)).digest('hex');
            const saved = await tx.$queryRaw `SELECT * FROM "ClientFboProcessingTariff" WHERE "clientId"=${clientId} OR "operationKey"=${dto.operationKey}`;
            if (saved.length) {
                if (saved.length === 1 && saved[0].clientId === clientId && saved[0].operationKey === dto.operationKey && saved[0].definitionHash === hash)
                    return saved[0];
                throw new common_1.ConflictException('Условия уже сохранены. Повторное сохранение не изменит действующие цены.');
            }
            if (legacyFboConditions(client).protected)
                throw new common_1.ConflictException('У клиента уже есть индивидуальные условия. Они доступны только для просмотра.');
            const skuIds = definition.variants.flatMap(variant => variant.skuIds);
            if (skuIds.length && await tx.sku.count({ where: { clientId, id: { in: skuIds } } }) !== skuIds.length)
                throw new common_1.BadRequestException('Варианты должны содержать только товары выбранного клиента.');
            const id = (0, node_crypto_1.randomUUID)();
            const rows = await tx.$queryRaw `INSERT INTO "ClientFboProcessingTariff" ("id","clientId","operationKey","definition","definitionHash","createdByUserId") VALUES (${id},${clientId},${dto.operationKey},${JSON.stringify(definition)}::jsonb,${hash},${user.id}) RETURNING *`;
            await tx.auditLog.create({ data: { userId: user.id, action: 'FBO_PROCESSING_TARIFF_CREATED', entity: 'ClientFboProcessingTariff', entityId: id, payload: { clientId, definition, definitionHash: hash } } });
            return rows[0];
        });
    }
};
exports.FboProcessingPricingService = FboProcessingPricingService;
exports.FboProcessingPricingService = FboProcessingPricingService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService])
], FboProcessingPricingService);
