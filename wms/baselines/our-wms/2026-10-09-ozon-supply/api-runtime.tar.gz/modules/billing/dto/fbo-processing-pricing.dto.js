"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateFboProcessingTariffDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class FboProcessingComponentDto {
    serviceId;
    priceRub;
    multiplier;
    taxMode;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], FboProcessingComponentDto.prototype, "serviceId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(32),
    __metadata("design:type", String)
], FboProcessingComponentDto.prototype, "priceRub", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(16),
    __metadata("design:type", String)
], FboProcessingComponentDto.prototype, "multiplier", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['INCLUDED', 'ADD_6_PERCENT']),
    __metadata("design:type", String)
], FboProcessingComponentDto.prototype, "taxMode", void 0);
class FboProcessingVariantDto {
    name;
    skuIds;
    services;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], FboProcessingVariantDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(1000),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    (0, class_validator_1.MaxLength)(100, { each: true }),
    __metadata("design:type", Array)
], FboProcessingVariantDto.prototype, "skuIds", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(50),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FboProcessingComponentDto),
    __metadata("design:type", Array)
], FboProcessingVariantDto.prototype, "services", void 0);
class FboProcessingDefinitionDto {
    common;
    variants;
}
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(50),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FboProcessingComponentDto),
    __metadata("design:type", Array)
], FboProcessingDefinitionDto.prototype, "common", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(50),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FboProcessingVariantDto),
    __metadata("design:type", Array)
], FboProcessingDefinitionDto.prototype, "variants", void 0);
class CreateFboProcessingTariffDto {
    operationKey;
    definition;
}
exports.CreateFboProcessingTariffDto = CreateFboProcessingTariffDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateFboProcessingTariffDto.prototype, "operationKey", void 0);
__decorate([
    (0, class_validator_1.IsDefined)(),
    (0, class_validator_1.ValidateNested)(),
    (0, class_transformer_1.Type)(() => FboProcessingDefinitionDto),
    __metadata("design:type", FboProcessingDefinitionDto)
], CreateFboProcessingTariffDto.prototype, "definition", void 0);
