"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateInvoiceCorrectionDto = exports.PreviewInvoiceCorrectionDto = exports.CloseBillingPeriodDto = exports.BillingCloseQuery = void 0;
const class_validator_1 = require("class-validator");
class BillingCloseQuery {
    clientId;
    periodFrom;
    periodTo;
}
exports.BillingCloseQuery = BillingCloseQuery;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], BillingCloseQuery.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], BillingCloseQuery.prototype, "periodFrom", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], BillingCloseQuery.prototype, "periodTo", void 0);
class CloseBillingPeriodDto extends BillingCloseQuery {
    reason;
    previewHash;
}
exports.CloseBillingPeriodDto = CloseBillingPeriodDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], CloseBillingPeriodDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^[a-f0-9]{64}$/),
    __metadata("design:type", String)
], CloseBillingPeriodDto.prototype, "previewHash", void 0);
class PreviewInvoiceCorrectionDto {
    invoiceId;
    amountRub;
    reason;
    kind;
}
exports.PreviewInvoiceCorrectionDto = PreviewInvoiceCorrectionDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], PreviewInvoiceCorrectionDto.prototype, "invoiceId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^-?\d+(?:\.\d{1,2})?$/),
    __metadata("design:type", String)
], PreviewInvoiceCorrectionDto.prototype, "amountRub", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PreviewInvoiceCorrectionDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(['ADJUSTMENT', 'LATE_WORK']),
    __metadata("design:type", String)
], PreviewInvoiceCorrectionDto.prototype, "kind", void 0);
class CreateInvoiceCorrectionDto extends PreviewInvoiceCorrectionDto {
    operationKey;
    previewHash;
}
exports.CreateInvoiceCorrectionDto = CreateInvoiceCorrectionDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateInvoiceCorrectionDto.prototype, "operationKey", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^[a-f0-9]{64}$/),
    __metadata("design:type", String)
], CreateInvoiceCorrectionDto.prototype, "previewHash", void 0);
