"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fboProcessingPricingEnabled = fboProcessingPricingEnabled;
exports.selectableFboService = selectableFboService;
exports.normalizeFboTariff = normalizeFboTariff;
exports.priceFboUnits = priceFboUnits;
exports.fboUnitAmount = fboUnitAmount;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const separatelyBilled = new Set(['FBS_PROCESSING', 'RELABELING', 'BOX_60_40_40', 'BOX_ASSEMBLY', 'PALLET', 'PALLET_ASSEMBLY']);
function fboProcessingPricingEnabled() { return process.env.WMS_FBO_PROCESSING_PRICING_ENABLED === 'true'; }
function selectableFboService(service) { return service.isActive && service.unit === 'PIECE' && !separatelyBilled.has(service.code); }
function decimal(value, precision, maximum, label) {
    const text = typeof value === 'string' ? value.trim().replace(',', '.') : '';
    if (!new RegExp(`^\\d+(?:\\.\\d{1,${precision}})?$`).test(text))
        throw new common_1.BadRequestException(`Проверьте ${label}.`);
    const parsed = new client_1.Prisma.Decimal(text);
    if (parsed.gt(maximum))
        throw new common_1.BadRequestException(`Слишком большое значение: ${label}.`);
    return parsed;
}
function components(value, services) {
    if (!Array.isArray(value) || value.length > 50)
        throw new common_1.BadRequestException('Выберите не более 50 услуг для одного состава.');
    const used = new Set();
    return value.map(part => {
        const service = services.find(s => s.id === part?.serviceId);
        if (!service || !service.isActive || service.unit !== 'PIECE')
            throw new common_1.BadRequestException('Выберите действующую услугу с ценой за штуку.');
        if (separatelyBilled.has(service.code))
            throw new common_1.BadRequestException('Короба, паллеты, перемаркировка и обработка FBS начисляются отдельно.');
        if (used.has(service.id))
            throw new common_1.BadRequestException('Услуга повторяется в одном составе.');
        used.add(service.id);
        const price = decimal(part.priceRub, 2, '9999999999.99', 'стоимость услуги');
        const multiplier = decimal(part.multiplier, 3, '1000', 'количество услуги на единицу');
        if (multiplier.lt('0.001'))
            throw new common_1.BadRequestException('Количество услуги должно быть не меньше 0,001.');
        if (!['INCLUDED', 'ADD_6_PERCENT'].includes(part.taxMode))
            throw new common_1.BadRequestException('Выберите порядок учёта налога.');
        return { serviceId: service.id, priceRub: price.toFixed(2), multiplier: multiplier.toFixed(3), taxMode: part.taxMode };
    });
}
function positive(parts) { return parts.some(part => new client_1.Prisma.Decimal(part.priceRub).gt(0)); }
// FIX: retain separate alternatives instead of summing all cut tariffs into one universal price.
function normalizeFboTariff(value, services) {
    const raw = value;
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.variants) || raw.variants.length > 50)
        throw new common_1.BadRequestException('Проверьте варианты первоначальной обработки.');
    const common = components(raw.common, services), commonIds = new Set(common.map(part => part.serviceId));
    const usedSkus = new Set(), names = new Set();
    const variants = raw.variants.map(variant => {
        const name = typeof variant?.name === 'string' ? variant.name.trim() : '';
        if (!name || name.length > 120 || names.has(name.toLocaleLowerCase('ru-RU')))
            throw new common_1.BadRequestException('Укажите разные названия вариантов, например «Отрез 3 м».');
        names.add(name.toLocaleLowerCase('ru-RU'));
        if (!Array.isArray(variant.skuIds) || !variant.skuIds.length || variant.skuIds.length > 1000)
            throw new common_1.BadRequestException('Выберите товары для каждого варианта.');
        const skuIds = variant.skuIds.map(id => {
            if (typeof id !== 'string' || !id || id.length > 100)
                throw new common_1.BadRequestException('Проверьте выбранные товары.');
            if (usedSkus.has(id))
                throw new common_1.BadRequestException('Один товар выбран для нескольких вариантов.');
            usedSkus.add(id);
            return id;
        });
        const parts = components(variant.services, services);
        if (!parts.length || parts.some(part => commonIds.has(part.serviceId)))
            throw new common_1.BadRequestException('Выберите услуги варианта без повторения общих услуг.');
        if (!positive([...common, ...parts]))
            throw new common_1.BadRequestException('Стоимость варианта должна быть больше нуля.');
        return { name, skuIds, services: parts };
    });
    if (!positive(common) && !variants.length)
        throw new common_1.BadRequestException('Стоимость обработки должна быть больше нуля.');
    return { common, variants };
}
function taxed(value, mode) { return mode === 'ADD_6_PERCENT' ? value.mul(100).div(94) : value; }
// FIX: aggregate actual unit quantities first, then round each line using the existing tax convention.
function priceFboUnits(definition, units) {
    const groups = new Map();
    for (const unit of units) {
        if (!Number.isSafeInteger(unit.quantity) || unit.quantity <= 0)
            throw new common_1.BadRequestException('Проверьте фактическое количество обработанных товаров.');
        const matching = definition.variants.map((v, index) => ({ v, index })).filter(({ v }) => v.skuIds.includes(unit.skuId));
        if (matching.length > 1)
            throw new common_1.BadRequestException('Для товара задано несколько вариантов обработки.');
        const variant = matching[0];
        if (!variant && !positive(definition.common))
            throw new common_1.BadRequestException('Для обработанного товара не задан тариф. Уточните состав услуг.');
        for (const [parts, variantKey, variantName] of [[definition.common, 'common', null], ...(variant ? [[variant.v.services, 'variant-' + variant.index, variant.v.name]] : [])]) {
            for (const part of parts) {
                const key = variantKey + ':' + part.serviceId, previous = groups.get(key), quantity = new client_1.Prisma.Decimal(unit.quantity).mul(part.multiplier);
                groups.set(key, { part, variantKey, variantName, quantity: (previous?.quantity ?? new client_1.Prisma.Decimal(0)).plus(quantity) });
            }
        }
    }
    return [...groups.values()].map(({ part, variantName, variantKey, quantity }) => ({ serviceId: part.serviceId, variantName, variantKey, quantity: quantity.toFixed(3), priceBeforeTaxRub: part.priceRub, taxMode: part.taxMode, multiplier: part.multiplier, unitPriceRub: taxed(new client_1.Prisma.Decimal(part.priceRub), part.taxMode).toDecimalPlaces(2, client_1.Prisma.Decimal.ROUND_HALF_UP).toFixed(2), totalRub: taxed(new client_1.Prisma.Decimal(part.priceRub).mul(quantity), part.taxMode).toDecimalPlaces(2, client_1.Prisma.Decimal.ROUND_HALF_UP).toFixed(2) }));
}
function fboUnitAmount(definition, variantIndex) {
    const index = variantIndex === undefined ? undefined : definition.variants[variantIndex];
    const skuId = index?.skuIds[0] ?? '__default__';
    return priceFboUnits(definition, [{ skuId, quantity: 1 }]).reduce((sum, line) => sum.plus(line.totalRub), new client_1.Prisma.Decimal(0)).toFixed(2);
}
