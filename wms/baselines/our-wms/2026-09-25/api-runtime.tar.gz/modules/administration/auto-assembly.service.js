"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AutoAssemblyService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoAssemblyService = void 0;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const auto_assembly_eligibility_1 = require("../marketplace-connections/auto-assembly-eligibility");
const auto_assembly_recovery_1 = require("../marketplace-connections/auto-assembly-recovery");
const auto_assembly_policy_1 = require("./auto-assembly-policy");
const PREFIX = 'fbs.autoAssembly.config.';
const RUN = 'fbs.autoAssembly.run.';
let AutoAssemblyService = AutoAssemblyService_1 = class AutoAssemblyService {
    prisma;
    scopes;
    marketplace;
    timer;
    stopped = false;
    logger = new common_1.Logger(AutoAssemblyService_1.name);
    constructor(prisma, scopes, marketplace) {
        this.prisma = prisma;
        this.scopes = scopes;
        this.marketplace = marketplace;
    }
    onModuleInit() { if (process.env.WMS_AUTO_ASSEMBLY_ENABLED === 'true')
        this.schedule(); }
    onModuleDestroy() { this.stopped = true; clearTimeout(this.timer); }
    schedule() { if (!this.stopped)
        this.timer = setTimeout(() => { void this.tick().catch(e => this.logger.error(e.message)).finally(() => this.schedule()); }, 30000); }
    admin(user) {
        if (user.isDemo || user.roleCodes.includes('CLIENT') || !user.permissionCodes.includes('system:admin'))
            throw new common_1.ForbiddenException('Автосборка доступна администратору.');
    }
    async connection(id, user) {
        this.admin(user);
        const c = await this.prisma.clientMarketplaceConnection.findUnique({ where: { id }, include: { client: { select: { isDemo: true } } } });
        if (!c || c.client.isDemo || !c.isActive || !['WILDBERRIES', 'OZON'].includes(c.marketplace))
            throw new common_1.BadRequestException('Кабинет недоступен.');
        this.scopes.requireClientAccess(user, c.clientId, 'write');
        return c;
    }
    async list(clientId, user) {
        this.admin(user);
        this.scopes.requireClientAccess(user, clientId, 'read');
        const connections = await this.prisma.clientMarketplaceConnection.findMany({ where: { clientId, isActive: true, marketplace: { in: ['WILDBERRIES', 'OZON'] } }, select: { id: true, marketplace: true, accountName: true, fbsExecutionWarehouseId: true } });
        const items = await Promise.all(connections.map(async (c) => {
            const saved = await this.prisma.systemSetting.findUnique({ where: { key: PREFIX + c.id } });
            const config = saved?.value;
            const routes = c.marketplace === 'WILDBERRIES' ? (await this.marketplace.listFbsWarehouseRoutes(c.id, user)).warehouses.filter(r => r.effectiveExecutionWarehouseId).map(r => ({ id: r.marketplaceWarehouseId, name: r.marketplaceWarehouseName })) : await this.marketplace.listAutoAssemblyOzonRoutes(c.id, user);
            const history = await this.prisma.systemSetting.findMany({ where: { key: { startsWith: RUN + c.id + '.' } }, orderBy: { createdAt: 'desc' }, take: 20 });
            return { ...c, config: config ?? auto_assembly_policy_1.emptyAutoAssembly, nextAt: config?.enabled ? config.nextAt : null, version: saved?.updatedAt.toISOString() ?? null, routes, history: history.map(row => row.value) };
        }));
        return { available: process.env.WMS_AUTO_ASSEMBLY_ENABLED === 'true', items };
    }
    async save(id, body, user) {
        const connection = await this.connection(id, user);
        if (process.env.WMS_AUTO_ASSEMBLY_ENABLED !== 'true')
            throw new common_1.BadRequestException('Автосборка отключена на сервере.');
        const config = (0, auto_assembly_policy_1.parseAutoAssembly)(body.config);
        const configurationError = config.enabled && (0, auto_assembly_eligibility_1.autoAssemblyOzonError)(connection);
        if (configurationError)
            throw new common_1.BadRequestException(configurationError);
        const value = { ...config, ownerId: user.id, nextAt: (0, auto_assembly_policy_1.nextAutoAssembly)(config.times, new Date()).toISOString() };
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${PREFIX + id}))`;
            const old = await tx.systemSetting.findUnique({ where: { key: PREFIX + id } });
            if ((old?.updatedAt.toISOString() ?? null) !== (body.version ?? null))
                throw new common_1.BadRequestException('Настройки изменились. Обновите страницу.');
            const saved = await tx.systemSetting.upsert({ where: { key: PREFIX + id }, create: { key: PREFIX + id, value, updatedByUserId: user.id }, update: { value, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'AUTO_ASSEMBLY_SETTINGS', entity: 'ClientMarketplaceConnection', entityId: id, payload: value } });
            return { saved: true, version: saved.updatedAt.toISOString(), nextAt: value.nextAt };
        });
    }
    async preview(id, config, user) { await this.connection(id, user); return this.marketplace.runAutoAssembly(id, (0, auto_assembly_policy_1.parseAutoAssembly)(config), user, true); }
    async run(id, user, slot = 'manual') {
        await this.connection(id, user);
        if (process.env.WMS_AUTO_ASSEMBLY_ENABLED !== 'true')
            throw new common_1.BadRequestException('Автосборка отключена.');
        const saved = await this.prisma.systemSetting.findUnique({ where: { key: PREFIX + id } });
        if (!saved)
            throw new common_1.BadRequestException('Сначала сохраните настройки.');
        const config = (0, auto_assembly_policy_1.parseAutoAssembly)(saved.value);
        if (slot !== 'manual' && !config.enabled)
            return;
        const key = RUN + id + '.' + (slot === 'manual' ? (0, node_crypto_1.randomUUID)() : slot);
        const startedAt = new Date().toISOString();
        try {
            await this.prisma.systemSetting.create({ data: { key, value: { startedAt, status: 'RUNNING', slot }, updatedByUserId: user.id } });
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError && error.code === 'P2002')
                return;
            throw error;
        }
        let result;
        let recovered = [];
        try {
            // FIX: existing WMS ownership must not permanently hide a failed WB operation.
            recovered = await (0, auto_assembly_recovery_1.recoverFailedAutoAssemblies)(this.prisma, id, user.id, config);
            const report = await this.marketplace.runAutoAssembly(id, config, user);
            const groups = [...recovered, ...report.groups];
            result = { startedAt, completedAt: new Date().toISOString(), status: groups.some(g => g.error) ? 'PARTIAL' : 'DONE', slot, ...report, groups };
        }
        catch (error) {
            result = { startedAt, completedAt: new Date().toISOString(), status: 'ERROR', slot, groups: recovered, error: error instanceof Error ? error.message : 'Ошибка запуска' };
        }
        await this.prisma.systemSetting.update({ where: { key }, data: { value: result } });
        return result;
    }
    // FIX: claim the scheduled occurrence in PostgreSQL; multiple API instances cannot replay it.
    async tick() {
        const settings = await this.prisma.systemSetting.findMany({ where: { key: { startsWith: PREFIX } } });
        for (const row of settings) {
            const value = row.value;
            if (!value.enabled || !value.nextAt || Date.parse(value.nextAt) > Date.now())
                continue;
            try {
                const config = (0, auto_assembly_policy_1.parseAutoAssembly)(value);
                const claimed = await this.prisma.systemSetting.updateMany({ where: { key: row.key, updatedAt: row.updatedAt }, data: { value: { ...config, ownerId: value.ownerId, nextAt: (0, auto_assembly_policy_1.nextAutoAssembly)(config.times, new Date()).toISOString() } } });
                if (!claimed.count)
                    continue;
                const owner = await this.prisma.user.findUnique({ where: { id: value.ownerId }, include: { roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } } } });
                if (!owner || owner.isDemo || owner.status !== 'ACTIVE')
                    throw new common_1.ForbiddenException('Администратор расписания недоступен.');
                const user = { id: owner.id, name: owner.name, email: owner.email, roleCodes: owner.roles.map(r => r.role.code), permissionCodes: owner.roles.flatMap(r => r.role.permissions.map(p => p.permission.code)), clientScopeMode: 'ALL', clientIds: [], writableClientIds: [] };
                await this.run(row.key.slice(PREFIX.length), user, value.nextAt);
            }
            catch (error) {
                const message = error instanceof Error ? error.message : 'Ошибка автосборки';
                this.logger.error(message);
                await this.prisma.systemSetting.upsert({ where: { key: RUN + row.key.slice(PREFIX.length) + '.' + value.nextAt }, create: { key: RUN + row.key.slice(PREFIX.length) + '.' + value.nextAt, value: { startedAt: new Date().toISOString(), status: 'ERROR', error: message } }, update: {} });
            }
        }
    }
};
exports.AutoAssemblyService = AutoAssemblyService;
exports.AutoAssemblyService = AutoAssemblyService = AutoAssemblyService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService, marketplace_connections_service_1.MarketplaceConnectionsService])
], AutoAssemblyService);
