"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentFbsTsdUser = void 0;
const common_1 = require("@nestjs/common");
// FIX: forward terminal UI capability without changing authenticated identity or permissions.
exports.CurrentFbsTsdUser = (0, common_1.createParamDecorator)((_data, context) => {
    const request = context.switchToHttp().getRequest();
    if (!request.user)
        return undefined;
    return {
        ...request.user,
        tsdPhysicalPickConfirmation: request.headers['x-tsd-fbs-capability'] === 'physical-pick-v1',
    };
});
