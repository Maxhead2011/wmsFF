"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.kizIdentity = kizIdentity;
exports.scanPeriod = scanPeriod;
exports.withoutConfirmedPrint = withoutConfirmedPrint;
exports.inspectionScope = inspectionScope;
const common_1 = require("@nestjs/common");
// FIX: identify the physical unit without losing punctuation or case in its serial.
function kizIdentity(value) {
    const raw = value.trim().replace(/^\]d2/i, '').replace(/<GS>/gi, '\x1d').replace(/^\(01\)(\d{14})\(21\)/, (_, gtin) => `01${gtin}21`);
    const match = /^(01\d{14}21[^\x1d\r\n]{13})(?:$|\x1d91|91)/.exec(raw);
    return match?.[1] ?? null;
}
function scanPeriod(dateFrom, dateTo) {
    for (const s of [dateFrom, dateTo]) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || !Number.isFinite(Date.parse(s)) || new Date(s).toISOString().slice(0, 10) !== s)
            throw new common_1.BadRequestException('Укажите корректные даты.');
    }
    const from = new Date(dateFrom + 'T00:00:00+03:00'), until = new Date(Date.parse(dateTo + 'T00:00:00+03:00') + 86400000);
    if (until <= from || +until - +from > 31 * 86400000)
        throw new common_1.BadRequestException('Выберите период от 1 до 31 дня.');
    return { from, until };
}
function withoutConfirmedPrint(scan, jobs) {
    const key = kizIdentity(scan.kiz);
    return !jobs.some(j => j.assemblyId === scan.assemblyId && j.requestId === scan.requestId && j.orderId === scan.orderId &&
        key !== null && kizIdentity(j.kiz) === key && j.status === 'PRINTED' && j.printedAt !== null && j.printedAt >= scan.at);
}
// FIX: mutually exclusive scopes; request/supply inspections cover the entire attempt.
function inspectionScope(input) {
    const kinds = Number(Boolean(input.dateFrom || input.dateTo)) + Number(Boolean(input.requestNumber)) + Number(Boolean(input.supplyId));
    if (kinds !== 1)
        throw new common_1.BadRequestException('Выберите период, заявку ВМС или поставку WB.');
    if (input.requestNumber) {
        if (!/^\d{1,9}$/.test(input.requestNumber) || Number(input.requestNumber) < 1)
            throw new common_1.BadRequestException('Укажите номер заявки ВМС.');
        return { kind: 'request', number: Number(input.requestNumber), label: `заявка №${Number(input.requestNumber)}` };
    }
    if (input.supplyId) {
        if (!/^WB-GI-\d+$/.test(input.supplyId))
            throw new common_1.BadRequestException('Укажите номер поставки WB-GI-…');
        return { kind: 'supply', supplyId: input.supplyId, label: `поставка ${input.supplyId}` };
    }
    return { kind: 'period', ...scanPeriod(input.dateFrom ?? '', input.dateTo ?? ''), label: `${input.dateFrom}–${input.dateTo}, МСК` };
}
