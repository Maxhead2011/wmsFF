"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnprintedKizService = void 0;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const warehouse_auth_scope_service_1 = require("../auth/warehouse-auth-scope.service");
const client_request_warehouse_scope_1 = require("../client-requests/client-request-warehouse-scope");
const unprinted_kiz_policy_1 = require("./unprinted-kiz.policy");
const record = (value) => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
const text = (value) => typeof value === 'string' ? value : '';
const CREATED = 'KIZ_SEARCH_CREATED';
const userInclude = { roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } }, clientScopes: { include: { client: { select: { isDemo: true, relabelingEnabled: true } } } }, warehouseScopes: { include: { warehouse: { select: { isActive: true } } } } };
let UnprintedKizService = class UnprintedKizService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    enabled(user) {
        if (!user.permissionCodes.includes('system:admin'))
            throw new common_1.ForbiddenException('Нет доступа к сервисному меню.');
        if (process.env.WMS_UNPRINTED_KIZ_SEARCH !== 'true')
            throw new common_1.NotFoundException('Поиск неотгруженных КИЗ выключен.');
    }
    async check(db, input, user, write = false) {
        this.enabled(user);
        (0, unprinted_kiz_policy_1.inspectionScope)(input);
        this.scopes.requireClientAccess(user, input.clientId, write ? 'write' : 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, { warehouseId: input.warehouseId }, write ? 'write' : 'read');
        const client = await db.client.findFirst({ where: { id: input.clientId, isDemo: Boolean(user.isDemo) }, select: { id: true } });
        const warehouse = await db.warehouse.findFirst({ where: { id: input.warehouseId, isActive: true }, select: { id: true } });
        if (!client || !warehouse)
            throw new common_1.NotFoundException('Клиент или филиал недоступен.');
    }
    async report(input, user) {
        return this.prisma.$transaction(async (db) => {
            await db.$executeRawUnsafe('SET TRANSACTION READ ONLY');
            await this.check(db, input, user);
            return { rows: await this.rows(db, input), checkedAt: new Date().toISOString(), timezone: 'Europe/Moscow' };
        }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.RepeatableRead, timeout: 30000 });
    }
    async rows(db, input) {
        const scope = (0, unprinted_kiz_policy_1.inspectionScope)(input);
        let selectedRequests;
        let selectedAssemblies;
        if (scope.kind !== 'period') {
            const requests = await db.clientRequest.findMany({ where: { clientId: input.clientId, warehouseId: input.warehouseId, ...(scope.kind === 'request' ? { number: scope.number } : {}) }, select: { id: true } });
            selectedRequests = requests.map(r => r.id);
            if (scope.kind === 'supply') {
                const [tasks, links] = await Promise.all([
                    db.fbsTsdAssembly.findMany({ where: { clientId: input.clientId, marketplace: 'WILDBERRIES', requestId: { in: selectedRequests }, supplyId: scope.supplyId }, select: { id: true } }),
                    db.fbsOrderRequestLink.findMany({ where: { clientId: input.clientId, marketplace: 'WILDBERRIES', requestId: { in: selectedRequests }, lastSupplyId: scope.supplyId }, select: { connectionId: true, orderId: true, requestId: true } }),
                ]);
                const linked = links.length ? await db.fbsTsdAssembly.findMany({ where: { clientId: input.clientId, marketplace: 'WILDBERRIES', OR: links.map(l => ({ connectionId: l.connectionId, orderId: l.orderId, requestId: l.requestId })) }, select: { id: true } }) : [];
                selectedAssemblies = [...new Set([...tasks, ...linked].map(t => t.id))];
            }
            if (!selectedRequests.length || selectedAssemblies?.length === 0)
                return [];
        }
        const audits = await db.auditLog.findMany({ where: { entity: 'FbsTsdAssembly', action: { in: ['FBS_KIZ_SCAN_ACCEPTED', 'FBS_WB_KIZ_REPLACED_AFTER_PRODUCT_PICK'] },
                ...(scope.kind === 'period' ? { createdAt: { gte: scope.from, lt: scope.until } } : { AND: [{ OR: selectedRequests.map(id => ({ payload: { path: ['requestId'], equals: id } })) }], ...(selectedAssemblies ? { entityId: { in: selectedAssemblies } } : {}) }), payload: { path: ['clientId'], equals: input.clientId } }, orderBy: [{ createdAt: 'desc' }, { id: 'asc' }], take: 5001 });
        if (audits.length > 5000)
            throw new common_1.BadRequestException('Найдено более 5000 сканирований. Уточните период или выберите отдельную заявку.');
        const ids = audits.map(a => a.entityId).filter((x) => !!x);
        const requestIds = [...new Set(audits.map(a => text(record(a.payload).requestId)).filter(Boolean))];
        const [requests, tasks, attempts, jobs, shipments, markers] = await Promise.all([
            db.clientRequest.findMany({ where: { id: { in: requestIds }, clientId: input.clientId, warehouseId: input.warehouseId }, select: { id: true, number: true } }),
            db.fbsTsdAssembly.findMany({ where: { id: { in: ids }, clientId: input.clientId, marketplace: 'WILDBERRIES' }, select: { id: true, requestId: true, orderId: true, skuId: true, barcode: true, productName: true, kiz: true, connectionId: true, status: true } }),
            db.fbsAssemblyAttemptHistory.findMany({ where: { clientId: input.clientId, requestId: { in: requestIds } }, select: { id: true, requestId: true, orderId: true, kiz: true, taskSnapshot: true } }),
            db.fbsPrintJob.findMany({ where: { assemblyId: { in: ids } }, select: { id: true, assemblyId: true, requestId: true, orderId: true, kiz: true, status: true, printedAt: true } }),
            db.shippedKizHistory.findMany({ where: { clientId: input.clientId, assemblyId: { in: ids } }, select: { assemblyId: true, kiz: true, shippedAt: true } }),
            db.auditLog.findMany({ where: { action: CREATED, entity: 'ClientRequest' }, select: { entityId: true, payload: true } }),
        ]);
        const acknowledgements = await db.auditLog.findMany({ where: { action: 'FBS_TWO_LABELS_PRINTED', entity: 'FbsPrintJob', entityId: { in: jobs.map(j => j.id) } }, select: { entityId: true, createdAt: true } });
        // FIX: a later failed retry must not erase a previously acknowledged successful print.
        const confirmed = [...jobs, ...acknowledgements.flatMap(a => { const j = jobs.find(j => j.id === a.entityId); return j ? [{ ...j, status: 'PRINTED', printedAt: a.createdAt }] : []; })];
        const searches = await db.clientRequest.findMany({ where: { id: { in: markers.map(m => m.entityId).filter((x) => !!x) }, clientId: input.clientId, warehouseId: input.warehouseId }, select: { id: true, number: true, status: true } });
        const actors = await db.user.findMany({ where: { id: { in: audits.map(a => a.userId).filter((x) => !!x) } }, select: { id: true, name: true } });
        const boxes = await db.box.findMany({ where: { clientId: input.clientId, warehouseId: input.warehouseId, code: { in: audits.map(a => text(record(a.payload).boxCode)).filter(Boolean) } }, select: { code: true } });
        const archived = attempts.map(a => { const s = record(a.taskSnapshot); return { id: text(s.id) || a.id, requestId: a.requestId, orderId: a.orderId, skuId: text(s.skuId), barcode: text(s.barcode), productName: text(s.productName), connectionId: text(s.connectionId), status: text(s.status), kiz: a.kiz }; });
        const seen = new Set();
        return audits.flatMap(a => {
            const p = record(a.payload), requestId = text(p.requestId), orderId = text(p.orderId), raw = text(p.kiz) || text(p.scannedKiz), kiz = (0, unprinted_kiz_policy_1.kizIdentity)(raw), assemblyId = a.entityId ?? '';
            const request = requests.find(r => r.id === requestId);
            if (!request || !assemblyId || !kiz || !orderId)
                return [];
            const task = [...tasks, ...archived].find(t => t.id === assemblyId && t.requestId === requestId && t.orderId === orderId && (0, unprinted_kiz_policy_1.kizIdentity)(t.kiz ?? '') === kiz);
            if (task?.status && task.status !== 'COMPLETED')
                return [];
            const replaced = audits.some(e => { const next = record(e.payload); return e.entityId === assemblyId && text(next.requestId) === requestId && text(next.orderId) === orderId && e.action === 'FBS_WB_KIZ_REPLACED_AFTER_PRODUCT_PICK' && e.createdAt >= a.createdAt && Array.isArray(next.previousKiz) && next.previousKiz.some(k => (0, unprinted_kiz_policy_1.kizIdentity)(String(k)) === kiz) && (0, unprinted_kiz_policy_1.kizIdentity)(text(next.scannedKiz)) !== kiz; });
            if (replaced)
                return [];
            const key = [assemblyId, requestId, orderId, kiz].join('|');
            if (seen.has(key))
                return [];
            seen.add(key);
            if (!(0, unprinted_kiz_policy_1.withoutConfirmedPrint)({ assemblyId, requestId, orderId, kiz, at: a.createdAt }, confirmed))
                return [];
            const search = searches.find(r => markers.some(m => m.entityId === r.id && Array.isArray(record(m.payload).targets) && record(m.payload).targets.some(target => {
                const t = record(target);
                return t.sourceAuditId === a.id || (['SUBMITTED', 'IN_WORK'].includes(r.status) && text(t.kiz) === kiz);
            })));
            const shipped = shipments.find(s => s.assemblyId === assemblyId && (0, unprinted_kiz_policy_1.kizIdentity)(s.kiz) === kiz);
            const boxCode = text(p.boxCode);
            const reason = search ? `Уже в заявке поиска №${search.number}` : shipped ? 'Есть запись отгрузки WMS' : !task?.skuId ? 'Привязка КИЗ к сборке изменилась' : !boxes.some(b => b.code === boxCode) ? 'Исходный короб не найден в филиале' : '';
            return [{ id: a.id, assemblyId, requestId, requestNumber: request.number, orderId, connectionId: task?.connectionId ?? '', kiz, scannedAt: a.createdAt.toISOString(),
                    workerName: text(p.workerName) || actors.find(u => u.id === a.userId)?.name || 'Не установлен', boxCode: boxCode || 'Без короба', skuId: task?.skuId ?? '', barcode: task?.barcode ?? '', productName: task?.productName ?? '',
                    printState: jobs.filter(j => j.assemblyId === assemblyId && j.requestId === requestId && (0, unprinted_kiz_policy_1.kizIdentity)(j.kiz) === kiz).map(j => j.status).join(', ') || 'Нет записи печати', searchRequestNumber: search?.number ?? null, shippedAt: shipped?.shippedAt.toISOString() ?? null, blockedReason: reason }];
        });
    }
    async eligible(db, input, id) {
        const users = await db.user.findMany({ where: { status: 'ACTIVE', ...(id ? { id } : {}) }, include: userInclude });
        const result = [];
        for (const u of users) {
            const roleCodes = u.roles.map(r => r.role.code), permissionCodes = [...new Set(u.roles.flatMap(r => r.role.permissions.map(p => p.permission.code)))];
            if (roleCodes.includes('CLIENT') || (!permissionCodes.includes('system:admin') && !['stock:read', 'stock:write'].every(p => permissionCodes.includes(p))))
                continue;
            try {
                const scope = await new warehouse_auth_scope_service_1.WarehouseAuthScopeService(db).resolve({ ...u, activeWarehouseId: input.warehouseId, roleCodes, permissionCodes });
                const auth = { ...u, ...scope, roleCodes, permissionCodes, warehouseIds: u.warehouseScopes.filter(w => w.canRead).map(w => w.warehouseId), writableWarehouseIds: u.warehouseScopes.filter(w => w.canWrite).map(w => w.warehouseId) };
                this.scopes.requireClientAccess(auth, input.clientId, 'write');
                (0, client_request_warehouse_scope_1.assertWarehouseAccess)(auth, { warehouseId: input.warehouseId }, 'write');
                result.push({ id: u.id, name: u.name });
            }
            catch (e) {
                if (!(e instanceof common_1.ForbiddenException || e instanceof common_1.NotFoundException))
                    throw e;
            }
        }
        return result;
    }
    async assignees(input, user) {
        await this.check(this.prisma, input, user);
        return this.eligible(this.prisma, input);
    }
    async create(input, user) {
        this.enabled(user);
        if (process.env.WMS_TSD_KIZ_SEARCH !== 'true')
            throw new common_1.ConflictException('Поиск КИЗ на ТСД ещё не включён.');
        return this.prisma.$transaction(async (db) => {
            await this.check(db, input, user, true);
            // FIX: serialize creators for this client/branch; retries return the same request.
            await db.$queryRaw `SELECT pg_advisory_xact_lock(hashtext(${`unprinted-kiz:${input.clientId}:${input.warehouseId}`}))::text`;
            const fingerprint = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify({ clientId: input.clientId, warehouseId: input.warehouseId, dateFrom: input.dateFrom, dateTo: input.dateTo, requestNumber: input.requestNumber, supplyId: input.supplyId, assignedToUserId: input.assignedToUserId, scanIds: [...input.scanIds].sort() })).digest('hex');
            const previous = await db.auditLog.findFirst({ where: { action: CREATED, payload: { path: ['operationKey'], equals: input.operationId } } });
            if (previous) {
                if (previous.userId !== user.id || record(previous.payload).fingerprint !== fingerprint)
                    throw new common_1.ConflictException('Ключ операции уже использован. Обновите список.');
                return db.clientRequest.findUniqueOrThrow({ where: { id: previous.entityId }, select: { id: true, number: true } });
            }
            if (!(await this.eligible(db, input, input.assignedToUserId)).length)
                throw new common_1.BadRequestException('Сотрудник не имеет доступа к поиску для этого клиента и филиала.');
            const report = await this.rows(db, input), selected = report.filter(r => input.scanIds.includes(r.id));
            if (selected.length !== input.scanIds.length || selected.some(r => r.blockedReason))
                throw new common_1.ConflictException('Список изменился: появилась печать, отгрузка или другая заявка поиска. Повторите проверку.');
            if (new Set(selected.map(r => r.kiz)).size !== selected.length)
                throw new common_1.BadRequestException('Один физический КИЗ выбран несколько раз. Оставьте одну строку.');
            const targets = selected.map(r => ({ itemId: (0, node_crypto_1.randomUUID)(), boxCode: r.boxCode, kiz: r.kiz, order: r.orderId, firstWorker: r.workerName, sourceAuditId: r.id, sourceRequestId: r.requestId, assemblyId: r.assemblyId }));
            const request = await db.clientRequest.create({ data: { clientId: input.clientId, warehouseId: input.warehouseId, type: 'OTHER', status: 'SUBMITTED', assignedToUserId: input.assignedToUserId, createdByUserId: user.id,
                    title: `Поиск ${selected.length} КИЗ без печати · ${(0, unprinted_kiz_policy_1.inspectionScope)(input).label}`,
                    comment: 'Сканируйте исходный короб, затем КИЗ. Найденный товар отложите отдельно. Поиск не изменяет остатки и привязки к заказам.',
                    items: { create: selected.map((r, i) => ({ id: targets[i].itemId, skuId: r.skuId, barcode: r.barcode, quantity: 1, name: r.productName, comment: `Короб: ${r.boxCode}\nЗаказ WB: ${r.orderId}\nКИЗ: ${r.kiz}\nПервый сборщик: ${r.workerName}` })) } }, select: { id: true, number: true } });
            await db.auditLog.create({ data: { userId: user.id, action: CREATED, entity: 'ClientRequest', entityId: request.id, payload: { operationKey: input.operationId, fingerprint, oneOff: true, assignedToUserId: input.assignedToUserId, sourceRequestNumbers: [...new Set(selected.map(r => r.requestNumber))], targets } } });
            await db.clientRequestEvent.create({ data: { requestId: request.id, clientId: input.clientId, eventType: 'CREATED', createdByUserId: user.id, title: 'Создана заявка поиска КИЗ без подтверждённой печати', body: `Проверка: ${(0, unprinted_kiz_policy_1.inspectionScope)(input).label}, МСК. ${selected.length} единиц.` } });
            return request;
        }, { timeout: 30000 });
    }
};
exports.UnprintedKizService = UnprintedKizService;
exports.UnprintedKizService = UnprintedKizService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService])
], UnprintedKizService);
