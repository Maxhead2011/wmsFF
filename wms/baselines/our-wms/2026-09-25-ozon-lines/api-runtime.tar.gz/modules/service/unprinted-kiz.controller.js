"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnprintedKizController = exports.CreateKizSearchDto = exports.UnprintedKizQuery = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const unprinted_kiz_service_1 = require("./unprinted-kiz.service");
class UnprintedKizQuery {
    clientId;
    warehouseId;
    dateFrom;
    dateTo;
    requestNumber;
    supplyId;
}
exports.UnprintedKizQuery = UnprintedKizQuery;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], UnprintedKizQuery.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], UnprintedKizQuery.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], UnprintedKizQuery.prototype, "dateFrom", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], UnprintedKizQuery.prototype, "dateTo", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{1,9}$/),
    __metadata("design:type", String)
], UnprintedKizQuery.prototype, "requestNumber", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^WB-GI-\d+$/),
    __metadata("design:type", String)
], UnprintedKizQuery.prototype, "supplyId", void 0);
class CreateKizSearchDto extends UnprintedKizQuery {
    assignedToUserId;
    operationId;
    scanIds;
}
exports.CreateKizSearchDto = CreateKizSearchDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateKizSearchDto.prototype, "assignedToUserId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateKizSearchDto.prototype, "operationId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(500),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsUUID)('all', { each: true }),
    __metadata("design:type", Array)
], CreateKizSearchDto.prototype, "scanIds", void 0);
// FIX: admin-only inspection and explicit creation, separate from printing and stock mutations.
let UnprintedKizController = class UnprintedKizController {
    service;
    constructor(service) {
        this.service = service;
    }
    report(input, user) { return this.service.report(input, user); }
    assignees(input, user) { return this.service.assignees(input, user); }
    create(input, user) { return this.service.create(input, user); }
};
exports.UnprintedKizController = UnprintedKizController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [UnprintedKizQuery, Object]),
    __metadata("design:returntype", void 0)
], UnprintedKizController.prototype, "report", null);
__decorate([
    (0, common_1.Get)('assignees'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [UnprintedKizQuery, Object]),
    __metadata("design:returntype", void 0)
], UnprintedKizController.prototype, "assignees", null);
__decorate([
    (0, common_1.Post)('requests'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [CreateKizSearchDto, Object]),
    __metadata("design:returntype", void 0)
], UnprintedKizController.prototype, "create", null);
exports.UnprintedKizController = UnprintedKizController = __decorate([
    (0, common_1.Controller)('service/unprinted-kiz'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __metadata("design:paramtypes", [unprinted_kiz_service_1.UnprintedKizService])
], UnprintedKizController);
