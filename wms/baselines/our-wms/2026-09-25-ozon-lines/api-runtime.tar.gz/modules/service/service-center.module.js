"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceCenterModule = void 0;
const common_1 = require("@nestjs/common");
const client_notifications_module_1 = require("../client-notifications/client-notifications.module");
const service_center_controller_1 = require("./service-center.controller");
const service_center_service_1 = require("./service-center.service");
const storage_optimization_service_1 = require("./storage-optimization.service");
const unprinted_kiz_controller_1 = require("./unprinted-kiz.controller");
const unprinted_kiz_service_1 = require("./unprinted-kiz.service");
const auth_module_1 = require("../auth/auth.module");
const wb_print_check_service_1 = require("./wb-print-check.service");
let ServiceCenterModule = class ServiceCenterModule {
};
exports.ServiceCenterModule = ServiceCenterModule;
exports.ServiceCenterModule = ServiceCenterModule = __decorate([
    (0, common_1.Module)({
        imports: [client_notifications_module_1.ClientNotificationsModule, auth_module_1.AuthModule],
        controllers: [service_center_controller_1.ServiceCenterController, unprinted_kiz_controller_1.UnprintedKizController],
        providers: [service_center_service_1.ServiceCenterService, storage_optimization_service_1.StorageOptimizationService, wb_print_check_service_1.WbPrintCheckService, unprinted_kiz_service_1.UnprintedKizService],
    })
], ServiceCenterModule);
