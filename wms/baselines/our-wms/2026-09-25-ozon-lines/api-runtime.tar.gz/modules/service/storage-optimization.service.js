"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorageOptimizationService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const storage_optimization_planner_1 = require("./storage-optimization-planner");
const storage_optimization_xlsx_1 = require("./storage-optimization-xlsx");
let StorageOptimizationService = class StorageOptimizationService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async buildReport(clientId) {
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { id: true, code: true, name: true },
        });
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
        // FIX: recommendations use only positive, available, physically boxed stock.
        const [balances, excluded] = await Promise.all([this.prisma.stockBalance.findMany({
                where: {
                    clientId,
                    status: 'AVAILABLE',
                    quantity: { gt: 0 },
                    boxId: { not: null },
                },
                select: {
                    warehouseId: true,
                    quantity: true,
                    warehouse: { select: { id: true, name: true, city: true } },
                    pallet: { select: { code: true } },
                    box: {
                        select: {
                            code: true,
                            warehouse: { select: { id: true, name: true, city: true } },
                            pallet: { select: { code: true } },
                            storagePlacement: {
                                select: {
                                    pallet: { select: { code: true } },
                                },
                            },
                        },
                    },
                    sku: {
                        select: {
                            id: true,
                            internalSku: true,
                            clientSku: true,
                            article: true,
                            name: true,
                            color: true,
                            size: true,
                            barcodes: {
                                select: { value: true, isPrimary: true },
                                orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }],
                            },
                        },
                    },
                },
                orderBy: [{ warehouseId: 'asc' }, { boxId: 'asc' }, { skuId: 'asc' }],
            }), this.prisma.stockBalance.aggregate({
                where: {
                    clientId,
                    quantity: { gt: 0 },
                    OR: [{ status: { not: 'AVAILABLE' } }, { boxId: null }],
                },
                _sum: { quantity: true },
            })]);
        const sourceRows = balances.flatMap((balance) => {
            if (!balance.box)
                return [];
            const warehouse = balance.warehouse ?? balance.box.warehouse;
            return [{
                    warehouseId: warehouse?.id ?? balance.warehouseId ?? 'WITHOUT_WAREHOUSE',
                    warehouseName: warehouse?.name || warehouse?.city || 'Без филиала',
                    skuId: balance.sku.id,
                    barcode: balance.sku.barcodes[0]?.value ?? null,
                    article: balance.sku.article || balance.sku.clientSku || balance.sku.internalSku,
                    productName: balance.sku.name,
                    color: balance.sku.color,
                    size: balance.sku.size,
                    sourcePalletSort: balance.box.storagePlacement?.pallet.code ??
                        balance.box.pallet?.code ??
                        balance.pallet?.code ??
                        null,
                    sourceBox: balance.box.code,
                    quantity: balance.quantity,
                }];
        });
        const plan = (0, storage_optimization_planner_1.buildStorageOptimizationPlan)(sourceRows);
        return {
            client,
            generatedAt: new Date().toISOString(),
            ...plan,
            summary: {
                ...plan.summary,
                // FIX: active or unboxed stock is visible in the summary but never recommended for movement.
                excludedUnits: excluded._sum.quantity ?? 0,
            },
        };
    }
    async buildReportFile(clientId) {
        const report = await this.buildReport(clientId);
        const timestamp = report.generatedAt.slice(0, 16).replace(/[:T]/g, '-');
        return {
            content: (0, storage_optimization_xlsx_1.buildStorageOptimizationWorkbook)(report),
            mimeType: (0, storage_optimization_xlsx_1.storageOptimizationXlsxMimeType)(),
            fileName: `storage_optimization_${safeFileName(report.client.code)}_${timestamp}.xlsx`,
        };
    }
};
exports.StorageOptimizationService = StorageOptimizationService;
exports.StorageOptimizationService = StorageOptimizationService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StorageOptimizationService);
function safeFileName(value) {
    return value.replace(/[^a-zA-Z0-9А-Яа-я_-]+/g, '_').replace(/^_+|_+$/g, '') || 'client';
}
