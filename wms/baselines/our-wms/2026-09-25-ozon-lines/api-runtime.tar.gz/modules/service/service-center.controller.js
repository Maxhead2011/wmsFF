"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceCenterController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const service_center_service_1 = require("./service-center.service");
const storage_optimization_service_1 = require("./storage-optimization.service");
const wb_print_check_service_1 = require("./wb-print-check.service");
let ServiceCenterController = class ServiceCenterController {
    serviceCenter;
    storageOptimization;
    wbPrintCheck;
    constructor(serviceCenter, storageOptimization, wbPrintCheck) {
        this.serviceCenter = serviceCenter;
        this.storageOptimization = storageOptimization;
        this.wbPrintCheck = wbPrintCheck;
    }
    // FIX: read-only evidence for an exact WB order; never enqueue or reprint labels.
    checkWbPrint(orderId, user) {
        return this.wbPrintCheck.inspect(orderId, user);
    }
    getStorageOptimization(clientId) {
        // FIX: report generation is read-only and scoped to the selected client.
        return this.storageOptimization.buildReport(clientId);
    }
    async downloadStorageOptimization(clientId, response) {
        const file = await this.storageOptimization.buildReportFile(clientId);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    getClientStockCleanupPreview(clientId) {
        return this.serviceCenter.getClientStockCleanupPreview(clientId);
    }
    purgeClientStock(clientId, confirmation, user) {
        return this.serviceCenter.purgeClientStock(clientId, confirmation, user);
    }
    getClientRequestsCleanupPreview(clientId) {
        return this.serviceCenter.getClientRequestsCleanupPreview(clientId);
    }
    purgeClientRequests(clientId, confirmation, user) {
        return this.serviceCenter.purgeClientRequests(clientId, confirmation, user);
    }
    getMaintenanceMode() {
        return this.serviceCenter.getMaintenanceMode();
    }
    updateMaintenanceMode(payload, user) {
        return this.serviceCenter.updateMaintenanceMode(payload, user);
    }
    listRecentSessions() {
        return this.serviceCenter.listRecentSessions();
    }
    closeSession(sessionId, user) {
        return this.serviceCenter.closeSession(sessionId, user);
    }
    getTelegramSettings(clientId) {
        return this.serviceCenter.getTelegramSettings(clientId);
    }
    listTelegramGroups() {
        return this.serviceCenter.listTelegramGroups();
    }
    updateTelegramGlobalSettings(payload, user) {
        return this.serviceCenter.updateTelegramGlobalSettings(payload, user);
    }
    updateTelegramClientSettings(clientId, payload, user) {
        return this.serviceCenter.updateTelegramClientSettings(clientId, payload, user);
    }
    testTelegramFulfillment() {
        return this.serviceCenter.testTelegramFulfillment();
    }
    testTelegramClient(clientId) {
        return this.serviceCenter.testTelegramClient(clientId);
    }
    searchProductMarks(clientId, search) {
        return this.serviceCenter.searchProductMarks({ clientId, search });
    }
};
exports.ServiceCenterController = ServiceCenterController;
__decorate([
    (0, common_1.Get)('wb-print-check'),
    __param(0, (0, common_1.Query)('orderId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "checkWbPrint", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/storage-optimization'),
    __param(0, (0, common_1.Param)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "getStorageOptimization", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/storage-optimization.xlsx'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ServiceCenterController.prototype, "downloadStorageOptimization", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/stock-cleanup'),
    __param(0, (0, common_1.Param)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "getClientStockCleanupPreview", null);
__decorate([
    (0, common_1.Post)('clients/:clientId/stock-cleanup'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)('confirmation')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "purgeClientStock", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/requests-cleanup'),
    __param(0, (0, common_1.Param)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "getClientRequestsCleanupPreview", null);
__decorate([
    (0, common_1.Post)('clients/:clientId/requests-cleanup'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)('confirmation')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "purgeClientRequests", null);
__decorate([
    (0, common_1.Get)('maintenance'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "getMaintenanceMode", null);
__decorate([
    (0, common_1.Patch)('maintenance'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "updateMaintenanceMode", null);
__decorate([
    (0, common_1.Get)('sessions'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "listRecentSessions", null);
__decorate([
    (0, common_1.Post)('sessions/:sessionId/close'),
    __param(0, (0, common_1.Param)('sessionId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "closeSession", null);
__decorate([
    (0, common_1.Get)('telegram'),
    __param(0, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "getTelegramSettings", null);
__decorate([
    (0, common_1.Get)('telegram/groups'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "listTelegramGroups", null);
__decorate([
    (0, common_1.Patch)('telegram/global'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "updateTelegramGlobalSettings", null);
__decorate([
    (0, common_1.Patch)('telegram/clients/:clientId'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "updateTelegramClientSettings", null);
__decorate([
    (0, common_1.Post)('telegram/test/fulfillment'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "testTelegramFulfillment", null);
__decorate([
    (0, common_1.Post)('telegram/test/clients/:clientId'),
    __param(0, (0, common_1.Param)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "testTelegramClient", null);
__decorate([
    (0, common_1.Get)('kiz'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], ServiceCenterController.prototype, "searchProductMarks", null);
exports.ServiceCenterController = ServiceCenterController = __decorate([
    (0, swagger_1.ApiTags)('service'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Controller)('service'),
    __metadata("design:paramtypes", [service_center_service_1.ServiceCenterService,
        storage_optimization_service_1.StorageOptimizationService,
        wb_print_check_service_1.WbPrintCheckService])
], ServiceCenterController);
function contentDisposition(fileName) {
    const fallback = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    return `attachment; filename="${fallback}"; filename*=UTF-8''${encodeURIComponent(fileName)}`;
}
