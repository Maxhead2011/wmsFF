"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TurnoverController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const node_fs_1 = require("node:fs");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const wms_stock_availability_service_1 = require("../stock/wms-stock-availability.service");
const fbs_stock_reports_dto_1 = require("./dto/fbs-stock-reports.dto");
const list_turnover_dto_1 = require("./dto/list-turnover.dto");
const turnover_kiz_report_dto_1 = require("./dto/turnover-kiz-report.dto");
const turnover_action_dto_1 = require("./dto/turnover-action.dto");
const fbs_stock_reports_service_1 = require("./fbs-stock-reports.service");
const turnover_service_1 = require("./turnover.service");
let TurnoverController = class TurnoverController {
    turnover;
    fbsStockReports;
    stockAvailability;
    constructor(turnover, fbsStockReports, stockAvailability) {
        this.turnover = turnover;
        this.fbsStockReports = fbsStockReports;
        this.stockAvailability = stockAvailability;
    }
    // ADDED: isolated read-only reporting endpoints reuse real WMS relations and
    // do not mutate stock, FBS requests or TSD tasks.
    fbsShipments(query, user) {
        return this.fbsStockReports.shipments(query, user);
    }
    async wmsAvailability(query, user) {
        const snapshot = await this.stockAvailability.snapshot(query.clientId, user, { warehouseId: query.warehouseId });
        return {
            totals: snapshot.totals,
            missingBarcodeCount: snapshot.missingBarcodeCount,
            generatedAt: snapshot.generatedAt,
        };
    }
    async fbsShipmentsXlsx(query, user, response) {
        const file = await this.fbsStockReports.exportShipments(query, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.size));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        const stream = (0, node_fs_1.createReadStream)(file.filePath);
        let cleaned = false;
        const cleanup = () => {
            if (cleaned)
                return;
            cleaned = true;
            void file.cleanup();
        };
        stream.once('close', cleanup);
        stream.once('error', cleanup);
        return new common_1.StreamableFile(stream);
    }
    fbsBoxes(query, user) {
        return this.fbsStockReports.boxes(query, user);
    }
    suggestions(query, user) {
        return this.turnover.suggestions(query, user);
    }
    async receiptPeriodXlsx(query, user, response) {
        const file = await this.turnover.getReceiptPeriodXlsx(query, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    async stockXlsx(query, user, response) {
        const file = await this.turnover.getStockXlsx(query, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    // ADDED: таблица и Excel используют один и тот же проверенный источник истории отгрузок.
    kizReport(query, user) {
        return this.turnover.kizReport(query, user);
    }
    async kizReportXlsx(query, user, response) {
        const file = await this.turnover.getKizReportXlsx(query, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    boxDetails(boxCode, query, user) {
        return this.turnover.boxDetails(boxCode, query, user);
    }
    list(query, user) {
        return this.turnover.list(query, user);
    }
    statistics(query, user) {
        return this.turnover.statistics(query, user);
    }
    movementDocument(movementId, user) {
        return this.turnover.getReceiptDocument(movementId, user);
    }
    async movementDocumentXlsx(movementId, user, response) {
        const file = await this.turnover.getReceiptDocumentXlsx(movementId, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    runAction(dto, user) {
        return this.turnover.runAction(dto, user);
    }
};
exports.TurnoverController = TurnoverController;
__decorate([
    (0, common_1.Get)('fbs-stock-reports/shipments'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_reports_dto_1.FbsShipmentReportDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "fbsShipments", null);
__decorate([
    (0, common_1.Get)('fbs-stock-reports/availability'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_reports_dto_1.WmsAvailabilityReportDto, Object]),
    __metadata("design:returntype", Promise)
], TurnoverController.prototype, "wmsAvailability", null);
__decorate([
    (0, common_1.Get)('fbs-stock-reports/shipments.xlsx'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_reports_dto_1.FbsShipmentReportDto, Object, Object]),
    __metadata("design:returntype", Promise)
], TurnoverController.prototype, "fbsShipmentsXlsx", null);
__decorate([
    (0, common_1.Get)('fbs-stock-reports/boxes'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_reports_dto_1.FbsBoxReportDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "fbsBoxes", null);
__decorate([
    (0, common_1.Get)('suggestions'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_turnover_dto_1.TurnoverSuggestionsDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "suggestions", null);
__decorate([
    (0, common_1.Get)('receipts.xlsx'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_turnover_dto_1.ListTurnoverDto, Object, Object]),
    __metadata("design:returntype", Promise)
], TurnoverController.prototype, "receiptPeriodXlsx", null);
__decorate([
    (0, common_1.Get)('stock.xlsx'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_turnover_dto_1.TurnoverStockExportDto, Object, Object]),
    __metadata("design:returntype", Promise)
], TurnoverController.prototype, "stockXlsx", null);
__decorate([
    (0, common_1.Get)('kiz-report'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [turnover_kiz_report_dto_1.TurnoverKizReportDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "kizReport", null);
__decorate([
    (0, common_1.Get)('kiz-report.xlsx'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [turnover_kiz_report_dto_1.TurnoverKizReportDto, Object, Object]),
    __metadata("design:returntype", Promise)
], TurnoverController.prototype, "kizReportXlsx", null);
__decorate([
    (0, common_1.Get)('boxes/:boxCode'),
    __param(0, (0, common_1.Param)('boxCode')),
    __param(1, (0, common_1.Query)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, list_turnover_dto_1.TurnoverBoxDetailsDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "boxDetails", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_turnover_dto_1.ListTurnoverDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('statistics'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_turnover_dto_1.TurnoverStatisticsDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "statistics", null);
__decorate([
    (0, common_1.Get)('movements/:movementId/document'),
    __param(0, (0, common_1.Param)('movementId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "movementDocument", null);
__decorate([
    (0, common_1.Get)('movements/:movementId/document.xlsx'),
    __param(0, (0, common_1.Param)('movementId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TurnoverController.prototype, "movementDocumentXlsx", null);
__decorate([
    (0, common_1.Post)('actions'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [turnover_action_dto_1.TurnoverActionDto, Object]),
    __metadata("design:returntype", void 0)
], TurnoverController.prototype, "runAction", null);
exports.TurnoverController = TurnoverController = __decorate([
    (0, swagger_1.ApiTags)('turnover'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    (0, common_1.Controller)('turnover'),
    __param(0, (0, common_1.Inject)(turnover_service_1.TurnoverService)),
    __param(1, (0, common_1.Inject)(fbs_stock_reports_service_1.FbsStockReportsService)),
    __param(2, (0, common_1.Inject)(wms_stock_availability_service_1.WmsStockAvailabilityService)),
    __metadata("design:paramtypes", [turnover_service_1.TurnoverService,
        fbs_stock_reports_service_1.FbsStockReportsService,
        wms_stock_availability_service_1.WmsStockAvailabilityService])
], TurnoverController);
function contentDisposition(fileName) {
    const asciiName = fileName.replace(/[^\x20-\x7E]+/g, '_').replace(/"/g, '');
    return `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`;
}
