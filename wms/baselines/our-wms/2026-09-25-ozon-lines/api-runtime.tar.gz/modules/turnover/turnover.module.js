"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TurnoverModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const wms_stock_availability_service_1 = require("../stock/wms-stock-availability.service");
const fbs_stock_reports_service_1 = require("./fbs-stock-reports.service");
const turnover_controller_1 = require("./turnover.controller");
const turnover_service_1 = require("./turnover.service");
let TurnoverModule = class TurnoverModule {
};
exports.TurnoverModule = TurnoverModule;
exports.TurnoverModule = TurnoverModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule],
        controllers: [turnover_controller_1.TurnoverController],
        providers: [turnover_service_1.TurnoverService, fbs_stock_reports_service_1.FbsStockReportsService, wms_stock_availability_service_1.WmsStockAvailabilityService],
    })
], TurnoverModule);
