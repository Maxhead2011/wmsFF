"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsStockReportsService = exports.FBS_STOCK_REPORT_XLSX_MIME = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const ExcelJS = __importStar(require("exceljs"));
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const node_os_1 = require("node:os");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
exports.FBS_STOCK_REPORT_XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
let FbsStockReportsService = class FbsStockReportsService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    // ADDED: shipment date is the actual DONE event; each marketplace order is
    // emitted once even if the WMS request contains several product rows.
    async shipments(filter, user) {
        this.clientScopes.requireClientAccess(user, filter.clientId, 'read');
        const effectiveFilter = { ...filter, warehouseId: scopedWarehouseId(user, filter.warehouseId) };
        const period = moscowPeriod(filter.dateFrom, filter.dateTo);
        const page = positiveInteger(filter.page, 1);
        const pageSize = boundedInteger(filter.pageSize, 20, 10, 100);
        const daily = new Map();
        const items = [];
        let orders = 0;
        let units = 0;
        for await (const row of this.iterateShipmentRows(effectiveFilter, period)) {
            const index = orders;
            orders += 1;
            units += row.units;
            const day = moscowDateKey(new Date(row.shippedAt));
            const current = daily.get(day) ?? { orders: 0, units: 0 };
            current.orders += 1;
            current.units += row.units;
            daily.set(day, current);
            if (index >= (page - 1) * pageSize && index < page * pageSize)
                items.push(row);
        }
        return {
            period: { dateFrom: filter.dateFrom, dateTo: filter.dateTo },
            summary: { orders, units },
            daily: [...daily.entries()].map(([date, value]) => ({ date, ...value })),
            items,
            pagination: { page, pageSize, total: orders, pages: Math.max(1, Math.ceil(orders / pageSize)) },
            generatedAt: new Date().toISOString(),
        };
    }
    async exportShipments(filter, user) {
        this.clientScopes.requireClientAccess(user, filter.clientId, 'read');
        const effectiveFilter = { ...filter, warehouseId: scopedWarehouseId(user, filter.warehouseId) };
        const period = moscowPeriod(filter.dateFrom, filter.dateTo);
        const directory = await (0, promises_1.mkdtemp)((0, node_path_1.join)((0, node_os_1.tmpdir)(), 'fbs-shipment-report-'));
        const fileName = `fbs_shipments_${filter.dateFrom}_${filter.dateTo}.xlsx`;
        const filePath = (0, node_path_1.join)(directory, fileName);
        try {
            const workbook = new ExcelJS.stream.xlsx.WorkbookWriter({ filename: filePath, useStyles: true, useSharedStrings: false });
            const sheet = workbook.addWorksheet('Отгруженные FBS-заказы', { views: [{ state: 'frozen', ySplit: 1 }] });
            sheet.columns = [
                { header: 'Заказ', key: 'orderId', width: 22, style: { numFmt: '@' } },
                { header: 'Маркетплейс', key: 'marketplace', width: 18 },
                { header: 'Дата отгрузки', key: 'shippedAt', width: 20 },
                { header: 'Склад', key: 'warehouse', width: 28 },
                { header: 'Количество', key: 'units', width: 14 },
            ];
            sheet.autoFilter = 'A1:E1';
            const header = sheet.getRow(1);
            header.font = { bold: true };
            header.commit();
            let rowCount = 0;
            for await (const item of this.iterateShipmentRows(effectiveFilter, period)) {
                const row = sheet.addRow({ ...item, shippedAt: formatMoscowDateTime(new Date(item.shippedAt)) });
                row.getCell(1).numFmt = '@';
                row.commit();
                rowCount += 1;
            }
            sheet.commit();
            await workbook.commit();
            const fileStat = await (0, promises_1.stat)(filePath);
            return {
                fileName,
                filePath,
                mimeType: exports.FBS_STOCK_REPORT_XLSX_MIME,
                size: fileStat.size,
                rowCount,
                cleanup: () => (0, promises_1.rm)(directory, { recursive: true, force: true }),
            };
        }
        catch (error) {
            await (0, promises_1.rm)(directory, { recursive: true, force: true }).catch(() => undefined);
            throw error;
        }
    }
    // ADDED: the single StoragePalletBox relation partitions boxes into two
    // mutually exclusive groups; quantities are summed from units, never rows.
    async boxes(filter, user) {
        this.clientScopes.requireClientAccess(user, filter.clientId, 'read');
        const warehouseId = scopedWarehouseId(user, filter.warehouseId);
        const page = positiveInteger(filter.page, 1);
        const pageSize = boundedInteger(filter.pageSize, 50, 10, 100);
        const palletPage = positiveInteger(filter.palletPage, 1);
        const palletPageSize = boundedInteger(filter.palletPageSize, 50, 10, 100);
        const withoutItems = [];
        const palletRows = new Map();
        const palletBoxIds = new Set();
        const palletCodes = new Set();
        const palletBarcodes = new Set();
        let withoutBoxes = 0;
        let withoutUnits = 0;
        let withoutRows = 0;
        let palletUnits = 0;
        let cursorId;
        for (;;) {
            const boxes = await this.prisma.box.findMany({
                where: {
                    clientId: filter.clientId,
                    status: { notIn: ['deleted', 'archived', 'shipped'] },
                    balances: { some: { quantity: { gt: 0 } } },
                    ...(warehouseId
                        ? {
                            OR: [
                                { storagePlacement: { is: null }, warehouseId },
                                { storagePlacement: { is: { pallet: { warehouseId } } } },
                            ],
                        }
                        : {}),
                    ...(cursorId ? { id: { gt: cursorId } } : {}),
                },
                select: {
                    id: true,
                    code: true,
                    status: true,
                    warehouse: { select: { id: true, code: true, name: true, city: true } },
                    zone: { select: { id: true, code: true, name: true } },
                    storagePlacement: {
                        select: { pallet: { select: { id: true, code: true, status: true, warehouseId: true } } },
                    },
                    balances: {
                        where: { quantity: { gt: 0 } },
                        select: {
                            skuId: true,
                            quantity: true,
                            status: true,
                            sku: {
                                select: {
                                    article: true,
                                    internalSku: true,
                                    barcodes: {
                                        select: { value: true, isPrimary: true },
                                        orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }],
                                        take: 1,
                                    },
                                },
                            },
                        },
                    },
                },
                orderBy: { id: 'asc' },
                take: 500,
            });
            if (boxes.length === 0)
                break;
            for (const box of boxes) {
                const bySku = new Map();
                for (const balance of box.balances) {
                    const barcode = balance.sku.barcodes[0]?.value.trim() || '';
                    const current = bySku.get(balance.skuId) ?? {
                        barcode,
                        article: balance.sku.article || balance.sku.internalSku,
                        quantity: 0,
                    };
                    current.quantity += Math.max(0, balance.quantity);
                    bySku.set(balance.skuId, current);
                }
                const rows = [...bySku.values()].filter((row) => row.quantity > 0);
                const boxTotal = rows.reduce((sum, row) => sum + row.quantity, 0);
                if (boxTotal <= 0)
                    continue;
                const placement = box.storagePlacement?.pallet ?? null;
                if (!placement) {
                    withoutBoxes += 1;
                    withoutUnits += boxTotal;
                    for (const row of rows) {
                        const index = withoutRows;
                        withoutRows += 1;
                        if (index >= (page - 1) * pageSize && index < page * pageSize) {
                            withoutItems.push({
                                boxCode: box.code,
                                warehouse: warehouseLabel(box.warehouse),
                                location: box.zone?.name || box.zone?.code || 'Местоположение не указано',
                                status: box.status,
                                barcode: row.barcode,
                                article: row.article,
                                quantity: row.quantity,
                                boxTotal,
                            });
                        }
                    }
                    continue;
                }
                palletBoxIds.add(box.id);
                palletCodes.add(placement.code);
                palletUnits += boxTotal;
                for (const row of rows) {
                    if (row.barcode)
                        palletBarcodes.add(row.barcode);
                    const key = `${placement.id}:${row.barcode || `sku:${row.article}`}`;
                    const current = palletRows.get(key) ?? {
                        palletCode: placement.code,
                        barcode: row.barcode,
                        quantity: 0,
                        boxIds: new Set(),
                    };
                    current.quantity += row.quantity;
                    current.boxIds.add(box.id);
                    palletRows.set(key, current);
                }
            }
            cursorId = boxes[boxes.length - 1].id;
            if (boxes.length < 500)
                break;
        }
        const allPalletItems = [...palletRows.values()]
            .map((row) => ({
            palletCode: row.palletCode,
            barcode: row.barcode,
            quantity: row.quantity,
            boxes: row.boxIds.size,
        }))
            .sort((left, right) => left.palletCode.localeCompare(right.palletCode, 'ru-RU', { numeric: true })
            || left.barcode.localeCompare(right.barcode, 'ru-RU', { numeric: true }));
        const palletStart = (palletPage - 1) * palletPageSize;
        return {
            withoutPallet: {
                summary: { boxes: withoutBoxes, units: withoutUnits, rows: withoutRows },
                items: withoutItems,
                pagination: { page, pageSize, total: withoutRows, pages: Math.max(1, Math.ceil(withoutRows / pageSize)) },
            },
            onPallet: {
                summary: {
                    boxes: palletBoxIds.size,
                    units: palletUnits,
                    barcodes: palletBarcodes.size,
                    pallets: palletCodes.size,
                },
                items: allPalletItems.slice(palletStart, palletStart + palletPageSize),
                pagination: {
                    page: palletPage,
                    pageSize: palletPageSize,
                    total: allPalletItems.length,
                    pages: Math.max(1, Math.ceil(allPalletItems.length / palletPageSize)),
                },
            },
            generatedAt: new Date().toISOString(),
        };
    }
    async *iterateShipmentRows(filter, period) {
        const seenRequests = new Set();
        const seenOrders = new Set();
        let cursorId;
        for (;;) {
            const events = await this.prisma.clientRequestEvent.findMany({
                where: {
                    clientId: filter.clientId,
                    statusTo: client_1.ClientRequestStatus.DONE,
                    createdAt: { gte: period.from, lte: period.to },
                    request: {
                        clientId: filter.clientId,
                        type: client_1.ClientRequestType.OUTBOUND,
                        status: client_1.ClientRequestStatus.DONE,
                        ...(filter.warehouseId ? { warehouseId: filter.warehouseId } : {}),
                    },
                },
                select: {
                    id: true,
                    requestId: true,
                    createdAt: true,
                    request: {
                        select: {
                            number: true,
                            warehouseId: true,
                            warehouse: { select: { code: true, name: true, city: true } },
                            fbsOrderLinks: {
                                select: {
                                    connectionId: true,
                                    orderId: true,
                                    marketplace: true,
                                    lastCategory: true,
                                    lastItemCount: true,
                                },
                            },
                        },
                    },
                },
                orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
                take: 500,
                ...(cursorId ? { cursor: { id: cursorId }, skip: 1 } : {}),
            });
            if (events.length === 0)
                break;
            for (const event of events) {
                // TEST support and defence in depth: never trust an adapter to widen
                // the requested time range silently.
                if (event.createdAt < period.from || event.createdAt > period.to)
                    continue;
                if (seenRequests.has(event.requestId))
                    continue;
                seenRequests.add(event.requestId);
                for (const link of event.request.fbsOrderLinks) {
                    if (!['shipped', 'archive'].includes(link.lastCategory || ''))
                        continue;
                    const key = `${link.marketplace}:${link.connectionId}:${link.orderId}`;
                    if (seenOrders.has(key))
                        continue;
                    seenOrders.add(key);
                    yield {
                        orderId: link.orderId,
                        marketplace: link.marketplace,
                        shippedAt: event.createdAt.toISOString(),
                        warehouseId: event.request.warehouseId,
                        warehouse: warehouseLabel(event.request.warehouse),
                        units: Math.max(1, link.lastItemCount ?? 1),
                        requestNumber: event.request.number,
                    };
                }
            }
            cursorId = events[events.length - 1].id;
            if (events.length < 500)
                break;
        }
    }
};
exports.FbsStockReportsService = FbsStockReportsService;
exports.FbsStockReportsService = FbsStockReportsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(prisma_service_1.PrismaService)),
    __param(1, (0, common_1.Inject)(client_scope_service_1.ClientScopeService)),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], FbsStockReportsService);
function moscowPeriod(dateFrom, dateTo) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateFrom) || !/^\d{4}-\d{2}-\d{2}$/.test(dateTo)) {
        throw new common_1.BadRequestException('Укажите корректный период отчёта.');
    }
    const from = new Date(`${dateFrom}T00:00:00.000+03:00`);
    const to = new Date(`${dateTo}T23:59:59.999+03:00`);
    if (from > to)
        throw new common_1.BadRequestException('Дата начала периода не может быть позже даты окончания.');
    return { from, to };
}
function moscowDateKey(date) {
    return new Date(date.getTime() + 3 * 60 * 60_000).toISOString().slice(0, 10);
}
function formatMoscowDateTime(date) {
    return new Intl.DateTimeFormat('ru-RU', {
        timeZone: 'Europe/Moscow',
        dateStyle: 'short',
        timeStyle: 'short',
    }).format(date);
}
function warehouseLabel(warehouse) {
    return warehouse?.name || warehouse?.city || warehouse?.code || 'Склад не указан';
}
function positiveInteger(value, fallback) {
    return Number.isFinite(value) ? Math.max(1, Math.trunc(value)) : fallback;
}
function boundedInteger(value, fallback, min, max) {
    return Number.isFinite(value) ? Math.max(min, Math.min(max, Math.trunc(value))) : fallback;
}
function scopedWarehouseId(user, requestedWarehouseId) {
    if (!user.activeWarehouseId || user.roleCodes.includes('CLIENT') || user.permissionCodes.includes('system:admin')) {
        return requestedWarehouseId;
    }
    return user.activeWarehouseId;
}
