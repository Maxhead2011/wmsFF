"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TurnoverActionDto = exports.TurnoverActionKind = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
var TurnoverActionKind;
(function (TurnoverActionKind) {
    TurnoverActionKind["ADD"] = "ADD";
    TurnoverActionKind["WRITE_OFF"] = "WRITE_OFF";
    TurnoverActionKind["TRANSFER"] = "TRANSFER";
    TurnoverActionKind["UTILIZE"] = "UTILIZE";
    TurnoverActionKind["HOLD"] = "HOLD";
    TurnoverActionKind["REPLACE_BARCODE"] = "REPLACE_BARCODE";
})(TurnoverActionKind || (exports.TurnoverActionKind = TurnoverActionKind = {}));
class TurnoverActionDto {
    clientId;
    skuId;
    barcode;
    action;
    quantity;
    sourceBoxCode;
    sourceBalanceId;
    targetBarcode;
    targetBoxCode;
    reason;
    kiz;
    photoFileName;
    comment;
    idempotencyKey;
}
exports.TurnoverActionDto = TurnoverActionDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.ValidateIf)((dto) => !dto.barcode),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "skuId", void 0);
__decorate([
    (0, class_validator_1.ValidateIf)((dto) => !dto.skuId),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(TurnoverActionKind),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "action", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], TurnoverActionDto.prototype, "quantity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "sourceBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "sourceBalanceId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "targetBarcode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "targetBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "kiz", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "photoFileName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "comment", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TurnoverActionDto.prototype, "idempotencyKey", void 0);
