"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TurnoverService = void 0;
exports.normalizeTurnoverTargetBoxCode = normalizeTurnoverTargetBoxCode;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const crypto_1 = require("crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const inventory_lock_service_1 = require("../../common/inventory/inventory-lock.service");
const box_code_policy_service_1 = require("../../common/boxes/box-code-policy.service");
const receipt_batches_1 = require("../../common/receipt-batches");
const client_scope_service_1 = require("../auth/client-scope.service");
const administration_unpalleted_writeoff_service_1 = require("../administration/administration-unpalleted-writeoff.service");
const turnover_action_dto_1 = require("./dto/turnover-action.dto");
const turnover_kiz_report_xlsx_1 = require("./turnover-kiz-report-xlsx");
const turnover_receipt_xlsx_1 = require("./turnover-receipt-xlsx");
let TurnoverService = class TurnoverService {
    prisma;
    clientScopes;
    inventoryLock;
    boxCodes;
    constructor(prisma, clientScopes, inventoryLock, boxCodes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.inventoryLock = inventoryLock;
        this.boxCodes = boxCodes;
    }
    async list(query, user) {
        // Exact barcode lookup is intentionally cross-client, but still respects the user's accessible client scope.
        const clientFilter = this.clientScopes.resolveClientFilter(user, query.clientId);
        const skuWhere = this.buildSkuWhere(query, clientFilter);
        const movementDateRange = dateRange(query.dateFrom, query.dateTo);
        const kiz = query.kiz?.trim();
        const warehouseScope = await this.resolveWarehouseScope(user, clientFilter);
        const movementScopeWhere = this.movementWarehouseWhere(warehouseScope);
        const movementVisibilityWhere = this.movementVisibilityWhere(user);
        const balanceScopeWhere = this.balanceWarehouseWhere(warehouseScope);
        const balanceVisibilityWhere = this.balanceVisibilityWhere(user);
        const markScopeWhere = this.markWarehouseWhere(warehouseScope);
        const markVisibilityWhere = this.markVisibilityWhere(user);
        const skus = await this.prisma.sku.findMany({
            where: {
                ...skuWhere,
                ...(movementDateRange
                    ? {
                        movements: {
                            some: {
                                AND: [
                                    { createdAt: movementDateRange },
                                    ...(movementScopeWhere ? [movementScopeWhere] : []),
                                    ...(movementVisibilityWhere ? [movementVisibilityWhere] : []),
                                ],
                            },
                        },
                    }
                    : {}),
            },
            include: {
                client: { select: { id: true, code: true, name: true } },
                barcodes: { orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] },
                balances: {
                    ...(balanceScopeWhere || balanceVisibilityWhere
                        ? {
                            where: {
                                AND: [
                                    ...(balanceScopeWhere ? [balanceScopeWhere] : []),
                                    ...(balanceVisibilityWhere ? [balanceVisibilityWhere] : []),
                                ],
                            },
                        }
                        : {}),
                    include: {
                        box: {
                            select: {
                                id: true,
                                code: true,
                                status: true,
                                zone: { select: { id: true, code: true, name: true } },
                                storagePlacement: {
                                    select: {
                                        source: true,
                                        pallet: {
                                            select: {
                                                id: true,
                                                code: true,
                                                zone: { select: { id: true, code: true, name: true } },
                                            },
                                        },
                                    },
                                },
                            },
                        },
                        pallet: {
                            select: {
                                id: true,
                                code: true,
                                status: true,
                                zone: { select: { id: true, code: true, name: true } },
                            },
                        },
                    },
                    orderBy: [{ updatedAt: 'desc' }],
                },
                productMarks: {
                    ...(kiz || markScopeWhere || markVisibilityWhere
                        ? {
                            where: {
                                AND: [
                                    ...(kiz ? [{ value: { contains: kiz, mode: client_1.Prisma.QueryMode.insensitive } }] : []),
                                    ...(markScopeWhere ? [markScopeWhere] : []),
                                    ...(markVisibilityWhere ? [markVisibilityWhere] : []),
                                ],
                            },
                        }
                        : {}),
                    select: { id: true, value: true, status: true, boxId: true, createdAt: true },
                    orderBy: { updatedAt: 'desc' },
                    take: 30,
                },
                movements: {
                    ...(movementDateRange || movementScopeWhere || movementVisibilityWhere
                        ? {
                            where: {
                                AND: [
                                    ...(movementDateRange ? [{ createdAt: movementDateRange }] : []),
                                    ...(movementScopeWhere ? [movementScopeWhere] : []),
                                    ...(movementVisibilityWhere ? [movementVisibilityWhere] : []),
                                ],
                            },
                        }
                        : {}),
                    include: {
                        box: { select: { id: true, code: true, status: true } },
                        productMarks: { select: { id: true, value: true, status: true } },
                    },
                    orderBy: { createdAt: 'asc' },
                    take: 250,
                },
            },
            orderBy: { updatedAt: 'desc' },
            ...(query.limit ? { take: query.limit } : {}),
        });
        const [requestMap, storagePlacementMap] = await Promise.all([
            this.loadRequestMap(skus.flatMap((sku) => sku.movements)),
            this.loadStoragePlacementMap(skus),
        ]);
        const items = skus.map((sku) => this.mapSkuReport(sku, requestMap, storagePlacementMap));
        const totals = items.reduce((acc, item) => ({
            skuCount: acc.skuCount + 1,
            currentQuantity: acc.currentQuantity + item.currentQuantity,
            receivedQuantity: acc.receivedQuantity + item.receivedQuantity,
            shippedQuantity: acc.shippedQuantity + item.shippedQuantity,
            writtenOffQuantity: acc.writtenOffQuantity + item.writtenOffQuantity,
        }), { skuCount: 0, currentQuantity: 0, receivedQuantity: 0, shippedQuantity: 0, writtenOffQuantity: 0 });
        return {
            generatedAt: new Date().toISOString(),
            filters: normalizedFilters(query),
            totals,
            items,
        };
    }
    async statistics(query, user) {
        this.requireInternalStatisticsAccess(user);
        const clientFilter = this.clientScopes.resolveClientFilter(user, query.clientId);
        const skuWhere = this.buildSkuWhere(query, clientFilter);
        const movementDateRange = dateRange(query.dateFrom, query.dateTo);
        const groupBy = query.groupBy ?? 'month';
        const skus = await this.prisma.sku.findMany({
            where: skuWhere,
            include: {
                client: { select: { id: true, code: true, name: true } },
                barcodes: { orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] },
            },
            orderBy: { updatedAt: 'desc' },
            ...(query.limit ? { take: query.limit } : {}),
        });
        const skuIds = skus.map((sku) => sku.id);
        if (skuIds.length === 0) {
            return emptyStatistics(query, groupBy);
        }
        const movementConditions = [
            client_1.Prisma.sql `movement."skuId" IN (${client_1.Prisma.join(skuIds)})`,
        ];
        if (typeof clientFilter === 'string') {
            movementConditions.push(client_1.Prisma.sql `movement."clientId" = ${clientFilter}`);
        }
        else if (clientFilter && 'in' in clientFilter && clientFilter.in.length) {
            movementConditions.push(client_1.Prisma.sql `movement."clientId" IN (${client_1.Prisma.join(clientFilter.in)})`);
        }
        else if (clientFilter && 'notIn' in clientFilter && clientFilter.notIn.length) {
            movementConditions.push(client_1.Prisma.sql `movement."clientId" NOT IN (${client_1.Prisma.join(clientFilter.notIn)})`);
        }
        if (movementDateRange?.gte) {
            movementConditions.push(client_1.Prisma.sql `movement."createdAt" >= ${movementDateRange.gte}`);
        }
        if (movementDateRange?.lte) {
            movementConditions.push(client_1.Prisma.sql `movement."createdAt" <= ${movementDateRange.lte}`);
        }
        const periodExpression = turnoverStatisticsPeriodSql(groupBy);
        const [movementAggregates, balances] = await Promise.all([
            this.prisma.$queryRaw(client_1.Prisma.sql `
        SELECT
          movement."skuId" AS "skuId",
          ${periodExpression} AS "period",
          SUM(
            CASE
              WHEN movement."quantity" > 0
                AND movement."type" IN ('INITIAL_IMPORT', 'RECEIPT', 'RETURN', 'INVENTORY_ADJUSTMENT')
              THEN movement."quantity"
              ELSE 0
            END
          )::bigint AS "receivedQuantity",
          SUM(
            CASE
              WHEN movement."type" = 'SHIP' AND movement."quantity" < 0
              THEN -movement."quantity"
              ELSE 0
            END
          )::bigint AS "shippedQuantity",
          SUM(
            CASE
              WHEN movement."type" = 'INVENTORY_ADJUSTMENT' AND movement."quantity" < 0
              THEN -movement."quantity"
              ELSE 0
            END
          )::bigint AS "writtenOffQuantity"
        FROM "StockMovement" movement
        WHERE ${client_1.Prisma.join(movementConditions, ' AND ')}
        GROUP BY movement."skuId", 2
      `),
            this.prisma.stockBalance.groupBy({
                by: ['skuId'],
                where: {
                    clientId: clientFilter,
                    skuId: { in: skuIds },
                },
                _sum: { quantity: true },
            }),
        ]);
        const currentBySkuId = new Map();
        balances.forEach((balance) => currentBySkuId.set(balance.skuId, balance._sum.quantity ?? 0));
        const rows = new Map();
        skus.forEach((sku) => {
            rows.set(sku.id, emptyStatisticsRow(sku, currentBySkuId.get(sku.id) ?? 0));
        });
        const trend = new Map();
        for (const aggregate of movementAggregates) {
            const row = rows.get(aggregate.skuId);
            if (!row)
                continue;
            const receivedQuantity = Number(aggregate.receivedQuantity);
            const shippedQuantity = Number(aggregate.shippedQuantity);
            const writtenOffQuantity = Number(aggregate.writtenOffQuantity);
            const trendRow = trend.get(aggregate.period) ?? {
                period: aggregate.period,
                receivedQuantity: 0,
                shippedQuantity: 0,
                writtenOffQuantity: 0,
            };
            row.receivedQuantity += receivedQuantity;
            row.shippedQuantity += shippedQuantity;
            row.writtenOffQuantity += writtenOffQuantity;
            trendRow.receivedQuantity += receivedQuantity;
            trendRow.shippedQuantity += shippedQuantity;
            trendRow.writtenOffQuantity += writtenOffQuantity;
            trend.set(aggregate.period, trendRow);
            rows.set(row.skuId, row);
        }
        const rowList = Array.from(rows.values()).sort((a, b) => b.currentQuantity - a.currentQuantity || a.name.localeCompare(b.name));
        const totals = rowList.reduce((acc, row) => ({
            receivedQuantity: acc.receivedQuantity + row.receivedQuantity,
            shippedQuantity: acc.shippedQuantity + row.shippedQuantity,
            writtenOffQuantity: acc.writtenOffQuantity + row.writtenOffQuantity,
            currentQuantity: acc.currentQuantity + row.currentQuantity,
        }), { receivedQuantity: 0, shippedQuantity: 0, writtenOffQuantity: 0, currentQuantity: 0 });
        return {
            generatedAt: new Date().toISOString(),
            filters: normalizedFilters(query),
            groupBy,
            totals,
            rows: rowList,
            trend: Array.from(trend.values()).sort((a, b) => a.period.localeCompare(b.period)),
            clientWidgetCandidate: true,
        };
    }
    async suggestions(query, user) {
        const clientFilter = this.clientScopes.resolveClientFilter(user, query.clientId);
        const search = query.search?.trim();
        const searchText = search ? { contains: search, mode: client_1.Prisma.QueryMode.insensitive } : undefined;
        const warehouseScope = await this.resolveWarehouseScope(user, clientFilter);
        const balanceScopeWhere = this.balanceWarehouseWhere(warehouseScope);
        const balanceVisibilityWhere = this.balanceVisibilityWhere(user);
        const markScopeWhere = this.markWarehouseWhere(warehouseScope);
        const markVisibilityWhere = this.markVisibilityWhere(user);
        const boxScopeWhere = this.boxWarehouseWhere(warehouseScope);
        const boxVisibilityWhere = this.boxVisibilityWhere(user);
        const [skus, barcodeRows, marks, boxes] = await Promise.all([
            this.prisma.sku.findMany({
                where: {
                    clientId: clientFilter,
                    ...(search
                        ? {
                            OR: [
                                { name: searchText },
                                { internalSku: searchText },
                                { clientSku: searchText },
                                { article: searchText },
                                { size: searchText },
                                { barcodes: { some: { value: { contains: search } } } },
                            ],
                        }
                        : {}),
                },
                select: {
                    id: true,
                    client: { select: { id: true, code: true, name: true } },
                    internalSku: true,
                    clientSku: true,
                    article: true,
                    name: true,
                    color: true,
                    size: true,
                    barcodes: { select: { value: true, isPrimary: true }, orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }], take: 5 },
                    balances: {
                        ...(balanceScopeWhere || balanceVisibilityWhere
                            ? {
                                where: {
                                    AND: [
                                        ...(balanceScopeWhere ? [balanceScopeWhere] : []),
                                        ...(balanceVisibilityWhere ? [balanceVisibilityWhere] : []),
                                    ],
                                },
                            }
                            : {}),
                        select: {
                            quantity: true,
                            status: true,
                            updatedAt: true,
                            box: { select: { code: true } },
                        },
                        orderBy: [{ updatedAt: 'desc' }],
                    },
                },
                orderBy: { updatedAt: 'desc' },
                take: 40,
            }),
            this.prisma.barcode.findMany({
                where: {
                    ...(search ? { value: { contains: search } } : {}),
                    sku: { clientId: clientFilter },
                },
                select: {
                    value: true,
                    isPrimary: true,
                    sku: {
                        select: {
                            id: true,
                            client: { select: { id: true, code: true, name: true } },
                            internalSku: true,
                            clientSku: true,
                            article: true,
                            name: true,
                            color: true,
                            size: true,
                        },
                    },
                },
                orderBy: { value: 'asc' },
                take: 60,
            }),
            this.prisma.productMark.findMany({
                where: {
                    clientId: clientFilter,
                    ...(search ? { value: searchText } : {}),
                    ...(markScopeWhere || markVisibilityWhere
                        ? {
                            AND: [
                                ...(markScopeWhere ? [markScopeWhere] : []),
                                ...(markVisibilityWhere ? [markVisibilityWhere] : []),
                            ],
                        }
                        : {}),
                },
                select: {
                    id: true,
                    value: true,
                    status: true,
                    sku: { select: { id: true, internalSku: true, article: true, name: true, barcodes: { select: { value: true }, take: 3 } } },
                    box: { select: { id: true, code: true, status: true } },
                },
                orderBy: { updatedAt: 'desc' },
                take: 50,
            }),
            this.prisma.box.findMany({
                where: {
                    clientId: clientFilter,
                    ...(search ? { code: searchText } : {}),
                    ...(boxScopeWhere || boxVisibilityWhere
                        ? {
                            AND: [
                                ...(boxScopeWhere ? [boxScopeWhere] : []),
                                ...(boxVisibilityWhere ? [boxVisibilityWhere] : []),
                            ],
                        }
                        : {}),
                },
                select: { id: true, code: true, status: true },
                orderBy: { code: 'asc' },
                take: 60,
            }),
        ]);
        const products = skus.map((sku) => {
            const primaryBarcode = sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? sku.barcodes[0]?.value ?? null;
            const firstBalance = sku.balances.find((balance) => balance.box?.code && balance.quantity > 0) ?? sku.balances[0] ?? null;
            return {
                skuId: sku.id,
                client: sku.client,
                label: [sku.name, primaryBarcode ? `ШК ${primaryBarcode}` : null].filter(Boolean).join(' · '),
                name: sku.name,
                internalSku: sku.internalSku,
                clientSku: sku.clientSku,
                article: sku.article,
                color: sku.color,
                size: sku.size,
                barcode: primaryBarcode,
                quantity: sku.balances.reduce((sum, balance) => sum + balance.quantity, 0),
                boxCode: firstBalance?.box?.code ?? null,
                status: firstBalance?.status ?? null,
            };
        });
        const barcodes = uniqueByValue([
            ...products
                .filter((product) => product.barcode)
                .map((product) => ({
                value: product.barcode,
                label: product.barcode,
                skuId: product.skuId,
                client: product.client,
                name: product.name,
                internalSku: product.internalSku,
                clientSku: product.clientSku,
                article: product.article,
                color: product.color,
                size: product.size,
            })),
            ...barcodeRows.map((row) => ({
                value: row.value,
                label: row.value,
                skuId: row.sku.id,
                client: row.sku.client,
                name: row.sku.name,
                internalSku: row.sku.internalSku,
                clientSku: row.sku.clientSku,
                article: row.sku.article,
                color: row.sku.color,
                size: row.sku.size,
            })),
        ], (row) => `${row.client.id}:${row.skuId}:${row.value}`).slice(0, 60);
        return {
            products,
            barcodes,
            kiz: marks.map((mark) => ({
                id: mark.id,
                value: mark.value,
                status: mark.status,
                skuId: mark.sku.id,
                name: mark.sku.name,
                internalSku: mark.sku.internalSku,
                article: mark.sku.article,
                barcode: mark.sku.barcodes[0]?.value ?? null,
                boxCode: mark.box?.code ?? null,
            })),
            boxes: boxes.map((box) => ({
                id: box.id,
                value: box.code,
                code: box.code,
                status: box.status,
            })),
        };
    }
    async boxDetails(boxCode, query, user) {
        const cleanCode = boxCode.trim();
        if (!cleanCode) {
            throw new common_1.BadRequestException('Укажите номер короба.');
        }
        // FIX: never resolve the virtual boxless label to a historical physical Box.
        if (!normalizeTurnoverTargetBoxCode(cleanCode)) {
            throw new common_1.BadRequestException('«Без короба» — обозначение остатка без привязки, а не номер короба.');
        }
        const clientFilter = this.clientScopes.resolveClientFilter(user, query.clientId);
        const warehouseScope = await this.resolveWarehouseScope(user, clientFilter);
        const box = await this.prisma.box.findFirst({
            where: {
                clientId: clientFilter,
                code: { equals: cleanCode, mode: client_1.Prisma.QueryMode.insensitive },
                ...(this.boxWarehouseWhere(warehouseScope) ?? {}),
                ...(this.boxVisibilityWhere(user) ?? {}),
            },
            select: {
                id: true,
                code: true,
                status: true,
                client: { select: { id: true, code: true, name: true } },
                storagePlacement: {
                    select: {
                        source: true,
                        scannedAt: true,
                        pallet: {
                            select: {
                                id: true,
                                code: true,
                                zone: { select: { id: true, code: true, name: true } },
                            },
                        },
                    },
                },
            },
        });
        if (!box) {
            throw new common_1.NotFoundException('Короб не найден или недоступен текущему пользователю.');
        }
        const [balances, marks, movements] = await Promise.all([
            this.prisma.stockBalance.findMany({
                where: {
                    clientId: box.client.id,
                    boxId: box.id,
                    quantity: { gt: 0 },
                },
                include: {
                    sku: {
                        include: {
                            barcodes: { orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] },
                        },
                    },
                },
                orderBy: [{ sku: { name: 'asc' } }, { status: 'asc' }],
            }),
            this.prisma.productMark.findMany({
                where: {
                    clientId: box.client.id,
                    boxId: box.id,
                },
                select: {
                    id: true,
                    value: true,
                    status: true,
                    skuId: true,
                },
                orderBy: [{ skuId: 'asc' }, { value: 'asc' }],
                take: 500,
            }),
            this.prisma.stockMovement.findMany({
                where: {
                    clientId: box.client.id,
                    boxId: box.id,
                    ...(this.movementVisibilityWhere(user) ?? {}),
                },
                include: {
                    sku: {
                        include: {
                            barcodes: { orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] },
                        },
                    },
                },
                orderBy: { createdAt: 'desc' },
                take: 150,
            }),
        ]);
        const marksBySkuAndStatus = new Map();
        marks.forEach((mark) => {
            const key = `${mark.skuId}:${mark.status}`;
            const current = marksBySkuAndStatus.get(key) ?? [];
            current.push(mark.value);
            marksBySkuAndStatus.set(key, current);
        });
        const contents = balances.map((balance) => {
            const primaryBarcode = balance.sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? balance.sku.barcodes[0]?.value ?? null;
            const kiz = marksBySkuAndStatus.get(`${balance.skuId}:${balance.status}`) ?? [];
            return {
                balanceId: balance.id,
                skuId: balance.skuId,
                internalSku: balance.sku.internalSku,
                clientSku: balance.sku.clientSku,
                article: balance.sku.article,
                name: balance.sku.name,
                color: balance.sku.color,
                size: balance.sku.size,
                barcode: primaryBarcode,
                status: balance.status,
                statusLabel: stockStatusLabel(balance.status),
                quantity: balance.quantity,
                kiz: kiz.slice(0, 50),
                kizCount: kiz.length,
            };
        });
        return {
            generatedAt: new Date().toISOString(),
            box,
            totals: {
                rows: contents.length,
                skuCount: uniqueValues(contents.map((item) => item.skuId)).length,
                quantity: contents.reduce((sum, item) => sum + item.quantity, 0),
                kizCount: marks.length,
            },
            contents,
            movements: movements.map((movement) => {
                const primaryBarcode = movement.sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? movement.sku.barcodes[0]?.value ?? null;
                return {
                    id: movement.id,
                    date: movement.createdAt.toISOString(),
                    type: movement.type,
                    typeLabel: movementTypeLabel(movement.type),
                    status: movement.status,
                    statusLabel: stockStatusLabel(movement.status),
                    quantity: movement.quantity,
                    skuId: movement.skuId,
                    name: movement.sku.name,
                    barcode: primaryBarcode,
                    sourceDocument: movement.sourceDocument,
                    comment: movement.comment,
                };
            }),
        };
    }
    async runAction(dto, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        this.clientScopes.requireClientAccess(user, dto.clientId, 'write');
        const idempotencyKey = dto.idempotencyKey?.trim() || `turnover:${dto.action}:${(0, crypto_1.randomUUID)()}`;
        const warehouseScope = await this.resolveWarehouseScope(user, dto.clientId);
        return this.prisma.$transaction(async (tx) => {
            const existing = await tx.stockMovement.findFirst({
                where: {
                    idempotencyKey: { startsWith: `${idempotencyKey}:` },
                    ...(this.movementWarehouseWhere(warehouseScope) ?? {}),
                },
            });
            if (existing) {
                return { status: 'ALREADY_APPLIED', idempotencyKey };
            }
            const sku = await this.resolveSku(tx, dto.clientId, dto.skuId, dto.barcode);
            const comment = this.actionComment(dto, user);
            const kizValues = parseKizValues(dto.kiz);
            await this.assertKizValuesInWarehouse(tx, dto.clientId, kizValues, warehouseScope);
            if (dto.action === turnover_action_dto_1.TurnoverActionKind.REPLACE_BARCODE) {
                const sourceBalanceId = dto.sourceBalanceId?.trim();
                const sourceBoxCode = dto.sourceBoxCode?.trim();
                const targetBarcode = dto.targetBarcode?.trim();
                if (!sourceBalanceId || !sourceBoxCode || !targetBarcode) {
                    throw new common_1.BadRequestException('Укажите строку остатка, исходный короб и новый ШК.');
                }
                if (!dto.reason?.trim()) {
                    throw new common_1.BadRequestException('Укажите причину замены ШК.');
                }
                if (kizValues.length > 0) {
                    throw new common_1.BadRequestException('При замене ШК КИЗы передавать нельзя.');
                }
                const balanceScopeWhere = this.balanceWarehouseWhere(warehouseScope);
                const sourceBalance = await tx.stockBalance.findFirst({
                    where: {
                        AND: [
                            {
                                id: sourceBalanceId,
                                clientId: dto.clientId,
                                skuId: sku.id,
                                quantity: { gt: 0 },
                                boxId: { not: null },
                                status: {
                                    in: [
                                        client_1.StockStatus.AVAILABLE,
                                        client_1.StockStatus.RECEIVING,
                                        client_1.StockStatus.UNMARKED,
                                        client_1.StockStatus.NEEDS_LABEL,
                                        client_1.StockStatus.NEEDS_RELABEL,
                                    ],
                                },
                            },
                            ...(balanceScopeWhere ? [balanceScopeWhere] : []),
                        ],
                    },
                    include: { box: true },
                });
                if (!sourceBalance?.box ||
                    sourceBalance.box.code.localeCompare(sourceBoxCode, 'ru-RU', { sensitivity: 'accent' }) !== 0) {
                    throw new common_1.NotFoundException('Строка товара не найдена в указанном коробе. Обновите карточку короба.');
                }
                if (sourceBalance.quantity < dto.quantity) {
                    throw new common_1.BadRequestException(`В выбранной строке доступно только ${sourceBalance.quantity} шт.`);
                }
                const marksCount = await tx.productMark.count({
                    where: {
                        clientId: dto.clientId,
                        skuId: sku.id,
                        boxId: sourceBalance.boxId,
                        status: sourceBalance.status,
                    },
                });
                if (marksCount > 0) {
                    throw new common_1.BadRequestException('У этой позиции есть КИЗы. Сначала исправьте привязку КИЗов отдельной операцией; автоматическая замена ШК запрещена.');
                }
                const targetSku = await this.resolveSku(tx, dto.clientId, undefined, targetBarcode);
                if (targetSku.id === sku.id) {
                    throw new common_1.BadRequestException('Новый ШК относится к тому же товару. Остаток менять не нужно.');
                }
                const targetWarehouseId = sourceBalance.warehouseId ?? sourceBalance.box.warehouseId ?? warehouseScope?.warehouseId ?? user.activeWarehouseId ?? null;
                if (!targetWarehouseId) {
                    throw new common_1.BadRequestException('Не удалось определить филиал исправляемого остатка.');
                }
                // FIX: change the SKU in-place as one transaction; total box quantity is preserved.
                const reduced = await tx.stockBalance.updateMany({
                    where: { id: sourceBalance.id, quantity: { gte: dto.quantity } },
                    data: { quantity: { decrement: dto.quantity } },
                });
                if (reduced.count !== 1) {
                    throw new common_1.BadRequestException('Остаток уже изменился. Обновите карточку короба и повторите операцию.');
                }
                await tx.stockBalance.deleteMany({ where: { id: sourceBalance.id, quantity: 0 } });
                await this.incrementBalance(tx, {
                    warehouseId: targetWarehouseId,
                    clientId: dto.clientId,
                    skuId: targetSku.id,
                    boxId: sourceBalance.boxId,
                    palletId: sourceBalance.palletId,
                    status: sourceBalance.status,
                    quantity: dto.quantity,
                });
                const sourceBarcode = sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? sku.barcodes[0]?.value ?? 'не указан';
                const correctionComment = `${comment}. Исправление ШК: ${sourceBarcode} → ${targetBarcode}`;
                await tx.stockMovement.createMany({
                    data: [
                        {
                            warehouseId: targetWarehouseId,
                            clientId: dto.clientId,
                            skuId: sku.id,
                            boxId: sourceBalance.boxId,
                            palletId: sourceBalance.palletId,
                            type: client_1.MovementType.INVENTORY_ADJUSTMENT,
                            status: sourceBalance.status,
                            quantity: -dto.quantity,
                            sourceDocument: 'barcode-correction',
                            idempotencyKey: `${idempotencyKey}:barcode-correction:out`,
                            comment: correctionComment,
                        },
                        {
                            warehouseId: targetWarehouseId,
                            clientId: dto.clientId,
                            skuId: targetSku.id,
                            boxId: sourceBalance.boxId,
                            palletId: sourceBalance.palletId,
                            type: client_1.MovementType.INVENTORY_ADJUSTMENT,
                            status: sourceBalance.status,
                            quantity: dto.quantity,
                            sourceDocument: 'barcode-correction',
                            idempotencyKey: `${idempotencyKey}:barcode-correction:in`,
                            comment: correctionComment,
                        },
                    ],
                });
                return this.actionResult('APPLIED', idempotencyKey, targetSku, dto.quantity, sourceBalance.box.code);
            }
            if (dto.action === turnover_action_dto_1.TurnoverActionKind.ADD) {
                // FIX: the UI sentinel means boxless stock; it must never create a physical box.
                const targetBoxCode = normalizeTurnoverTargetBoxCode(dto.targetBoxCode);
                const targetBox = targetBoxCode
                    ? await this.ensureBox(tx, dto.clientId, targetBoxCode, warehouseScope)
                    : null;
                if (!targetBox) {
                    this.assertUnambiguousBoxlessClient(dto.clientId, warehouseScope);
                }
                const targetWarehouseId = targetBox?.warehouseId ?? warehouseScope?.warehouseId ?? user.activeWarehouseId ?? null;
                if (!targetWarehouseId) {
                    throw new common_1.BadRequestException('Выберите филиал перед добавлением остатка без короба.');
                }
                await this.incrementBalance(tx, {
                    warehouseId: targetWarehouseId,
                    clientId: dto.clientId,
                    skuId: sku.id,
                    boxId: targetBox?.id ?? null,
                    palletId: targetBox?.palletId ?? null,
                    status: client_1.StockStatus.AVAILABLE,
                    quantity: dto.quantity,
                });
                const movement = await tx.stockMovement.create({
                    data: {
                        warehouseId: targetWarehouseId,
                        clientId: dto.clientId,
                        skuId: sku.id,
                        boxId: targetBox?.id ?? null,
                        palletId: targetBox?.palletId ?? null,
                        type: client_1.MovementType.RECEIPT,
                        status: client_1.StockStatus.AVAILABLE,
                        quantity: dto.quantity,
                        sourceDocument: 'turnover-action',
                        idempotencyKey: `${idempotencyKey}:receipt`,
                        comment,
                    },
                });
                await this.attachKizValues(tx, dto.clientId, sku.id, targetBox?.id ?? null, movement.id, client_1.StockStatus.AVAILABLE, kizValues);
                return this.actionResult('APPLIED', idempotencyKey, sku, dto.quantity, targetBox?.code ?? null);
            }
            if (dto.action === turnover_action_dto_1.TurnoverActionKind.TRANSFER || dto.action === turnover_action_dto_1.TurnoverActionKind.HOLD) {
                if (!dto.targetBoxCode?.trim()) {
                    throw new common_1.BadRequestException('Укажите ячейку или короб, куда переносим товар.');
                }
                const targetBox = await this.ensureBox(tx, dto.clientId, dto.targetBoxCode, warehouseScope);
                const targetStatus = dto.action === turnover_action_dto_1.TurnoverActionKind.HOLD ? client_1.StockStatus.BLOCKED : client_1.StockStatus.AVAILABLE;
                const allocations = await this.decrementAvailable(tx, dto.clientId, sku.id, dto.quantity, dto.sourceBoxCode, warehouseScope);
                for (const allocation of allocations) {
                    await tx.stockMovement.create({
                        data: {
                            clientId: dto.clientId,
                            skuId: sku.id,
                            boxId: allocation.balance.boxId,
                            palletId: allocation.balance.palletId,
                            type: client_1.MovementType.MOVE,
                            status: allocation.balance.status,
                            quantity: -allocation.quantity,
                            sourceDocument: 'turnover-action',
                            idempotencyKey: `${idempotencyKey}:out:${allocation.balance.id}`,
                            comment,
                        },
                    });
                }
                const targetWarehouseId = targetBox.warehouseId ?? warehouseScope?.warehouseId ?? user.activeWarehouseId ?? null;
                if (!targetWarehouseId) {
                    throw new common_1.BadRequestException('Не удалось определить филиал целевого короба.');
                }
                await this.incrementBalance(tx, {
                    warehouseId: targetWarehouseId,
                    clientId: dto.clientId,
                    skuId: sku.id,
                    boxId: targetBox.id,
                    palletId: targetBox.palletId,
                    status: targetStatus,
                    quantity: dto.quantity,
                });
                const movement = await tx.stockMovement.create({
                    data: {
                        warehouseId: targetWarehouseId,
                        clientId: dto.clientId,
                        skuId: sku.id,
                        boxId: targetBox.id,
                        palletId: targetBox.palletId,
                        type: client_1.MovementType.MOVE,
                        status: targetStatus,
                        quantity: dto.quantity,
                        sourceDocument: 'turnover-action',
                        idempotencyKey: `${idempotencyKey}:in`,
                        comment,
                    },
                });
                await this.moveKizValues(tx, dto.clientId, sku.id, targetBox.id, movement.id, targetStatus, kizValues);
                return this.actionResult('APPLIED', idempotencyKey, sku, dto.quantity, targetBox.code);
            }
            const allocations = await this.decrementAvailable(tx, dto.clientId, sku.id, dto.quantity, dto.sourceBoxCode, warehouseScope);
            for (const allocation of allocations) {
                const movement = await tx.stockMovement.create({
                    data: {
                        clientId: dto.clientId,
                        skuId: sku.id,
                        boxId: allocation.balance.boxId,
                        palletId: allocation.balance.palletId,
                        type: client_1.MovementType.INVENTORY_ADJUSTMENT,
                        status: allocation.balance.status,
                        quantity: -allocation.quantity,
                        sourceDocument: 'turnover-action',
                        idempotencyKey: `${idempotencyKey}:write-off:${allocation.balance.id}`,
                        comment,
                    },
                });
                const markStatus = dto.action === turnover_action_dto_1.TurnoverActionKind.UTILIZE ? client_1.StockStatus.DEFECT : client_1.StockStatus.BLOCKED;
                await this.moveKizValues(tx, dto.clientId, sku.id, null, movement.id, markStatus, kizValues);
            }
            return this.actionResult('APPLIED', idempotencyKey, sku, dto.quantity, null);
        });
    }
    async getReceiptDocument(movementId, user) {
        const clientFilter = this.clientScopes.resolveClientFilter(user);
        const warehouseScope = await this.resolveWarehouseScope(user, clientFilter);
        const movementScopeWhere = this.movementWarehouseWhere(warehouseScope);
        const movementVisibilityWhere = this.movementVisibilityWhere(user);
        const seed = await this.prisma.stockMovement.findFirst({
            where: {
                id: movementId,
                clientId: clientFilter,
                ...((movementScopeWhere || movementVisibilityWhere)
                    ? { AND: [
                            ...(movementScopeWhere ? [movementScopeWhere] : []),
                            ...(movementVisibilityWhere ? [movementVisibilityWhere] : []),
                        ] }
                    : {}),
            },
            include: receiptDocumentInclude,
        });
        if (!seed) {
            throw new common_1.NotFoundException('Движение прихода не найдено.');
        }
        this.clientScopes.requireClientAccess(user, seed.clientId, 'read');
        if (!isDocumentMovement(seed)) {
            throw new common_1.BadRequestException('По этому движению нет отдельного документа для просмотра.');
        }
        const sourceDocument = seed.sourceDocument?.trim() || null;
        const documentWhere = sourceDocument && sourceDocument !== 'turnover-action'
            ? documentGroupWhere(seed, sourceDocument)
            : { id: seed.id };
        const movements = await this.prisma.stockMovement.findMany({
            where: {
                AND: [
                    documentWhere,
                    ...(movementScopeWhere ? [movementScopeWhere] : []),
                    ...(movementVisibilityWhere ? [movementVisibilityWhere] : []),
                ],
            },
            include: receiptDocumentInclude,
            orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
        });
        return buildReceiptDocument(seed.id, movements.length ? movements : [seed], sourceDocument);
    }
    async getReceiptDocumentXlsx(movementId, user) {
        const document = await this.getReceiptDocument(movementId, user);
        // FIX: only client receipt downloads use the summary; staff and shipment documents stay detailed.
        const content = (0, turnover_receipt_xlsx_1.buildTurnoverReceiptWorkbook)(document, this.isExternalClient(user) && document.type !== client_1.MovementType.SHIP);
        return {
            fileName: document.fileName,
            mimeType: (0, turnover_receipt_xlsx_1.turnoverReceiptXlsxMimeType)(),
            content,
        };
    }
    async getReceiptPeriodXlsx(query, user) {
        if (!query.clientId) {
            throw new common_1.BadRequestException('Выберите клиента для выгрузки приемки.');
        }
        this.clientScopes.requireClientAccess(user, query.clientId, 'read');
        const warehouseScope = await this.resolveWarehouseScope(user, query.clientId);
        const movementScopeWhere = this.movementWarehouseWhere(warehouseScope);
        const client = await this.prisma.client.findUnique({
            where: { id: query.clientId },
            select: { id: true, code: true, name: true },
        });
        if (!client) {
            throw new common_1.NotFoundException('Клиент не найден.');
        }
        const receiptBatchDate = query.receiptBatchDate?.trim() || null;
        const configuredReceiptPrefix = this.boxCodes
            ? (await this.boxCodes.getPolicy()).receiptPrefix
            : 'FFL_LKB';
        const receiptBoxPrefix = receiptBatchDate
            ? (0, receipt_batches_1.receiptBoxCodePrefixForDate)(receiptBatchDate, configuredReceiptPrefix)
            : null;
        if (receiptBatchDate && !receiptBoxPrefix) {
            throw new common_1.BadRequestException('Дата партии приемки должна быть корректной датой в формате ГГГГ-ММ-ДД.');
        }
        const movementDateRange = receiptBatchDate ? undefined : dateRange(query.dateFrom, query.dateTo);
        const candidateMovements = await this.prisma.stockMovement.findMany({
            where: {
                AND: [
                    {
                        clientId: client.id,
                        quantity: { gt: 0 },
                        type: receiptBatchDate ? client_1.MovementType.RECEIPT : { in: INCOMING_DOCUMENT_MOVEMENT_TYPES },
                        ...(movementDateRange ? { createdAt: movementDateRange } : {}),
                        ...(receiptBoxPrefix
                            ? { box: { code: { startsWith: receiptBoxPrefix, mode: client_1.Prisma.QueryMode.insensitive } } }
                            : {}),
                    },
                    ...(movementScopeWhere ? [movementScopeWhere] : []),
                ],
            },
            include: receiptPeriodInclude,
            orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
        });
        const movements = receiptBatchDate
            ? candidateMovements.filter((movement) => Boolean(movement.box?.code) &&
                (0, receipt_batches_1.receiptDateFromBoxCode)(movement.box.code, movement.createdAt, configuredReceiptPrefix) === receiptBatchDate)
            : candidateMovements;
        const document = buildReceiptPeriodDocument(client, movements, query);
        const content = (0, turnover_receipt_xlsx_1.buildTurnoverReceiptPeriodWorkbook)(document, this.isExternalClient(user));
        return {
            fileName: document.fileName,
            mimeType: (0, turnover_receipt_xlsx_1.turnoverReceiptXlsxMimeType)(),
            content,
        };
    }
    async getStockXlsx(query, user) {
        this.requireInternalStatisticsAccess(user);
        const clientId = query.clientId?.trim();
        if (!clientId) {
            throw new common_1.BadRequestException('Выберите клиента для выгрузки остатков.');
        }
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { id: true, code: true, name: true },
        });
        if (!client) {
            throw new common_1.NotFoundException('Клиент не найден.');
        }
        const ignoreActiveRequests = parseBooleanFlag(query.ignoreActiveRequests);
        const warehouseScope = await this.resolveWarehouseScope(user, clientId);
        const balanceScopeWhere = this.balanceWarehouseWhere(warehouseScope);
        const markScopeWhere = this.markWarehouseWhere(warehouseScope);
        const balances = await this.prisma.stockBalance.findMany({
            where: {
                clientId,
                quantity: { gt: 0 },
                ...(balanceScopeWhere ? { AND: [balanceScopeWhere] } : {}),
            },
            include: stockExportBalanceInclude,
            orderBy: [{ updatedAt: 'desc' }],
        });
        const marks = await this.prisma.productMark.groupBy({
            by: ['skuId', 'boxId', 'status'],
            where: {
                clientId,
                ...(markScopeWhere ? { AND: [markScopeWhere] } : {}),
            },
            _count: { _all: true },
        });
        const markCountByBalance = new Map(marks.map((mark) => [stockExportMarkKey(mark.skuId, mark.boxId, mark.status), mark._count._all]));
        const rows = balances
            .map((balance) => {
            const barcodes = balance.sku.barcodes.map((barcode) => barcode.value).filter(Boolean);
            const primaryBarcode = balance.sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? barcodes[0] ?? null;
            return {
                position: 0,
                balanceId: balance.id,
                skuId: balance.skuId,
                barcodeSet: new Set(barcodes),
                boxCode: balance.box?.code ?? null,
                palletCode: balance.pallet?.code ?? null,
                internalSku: balance.sku.internalSku,
                clientSku: balance.sku.clientSku,
                article: balance.sku.article,
                name: balance.sku.name,
                color: balance.sku.color,
                size: balance.sku.size,
                barcode: primaryBarcode,
                allBarcodes: barcodes.join(', '),
                status: balance.status,
                statusLabel: stockStatusLabel(balance.status),
                physicalQuantity: balance.quantity,
                reservedQuantity: 0,
                exportQuantity: balance.quantity,
                volumeLiters: nullableNumber(balance.sku.volumeLiters),
                kizCount: markCountByBalance.get(stockExportMarkKey(balance.skuId, balance.boxId, balance.status)) ?? 0,
                updatedAt: balance.updatedAt.toISOString(),
            };
        })
            .sort(stockExportRowSort);
        if (!ignoreActiveRequests && rows.length > 0) {
            await this.applyActiveRequestReservations(clientId, rows, warehouseScope?.warehouseId);
        }
        const exportRows = rows
            .filter((row) => row.exportQuantity > 0)
            .map(({ barcodeSet: _barcodeSet, ...row }, index) => ({ ...row, position: index + 1 }));
        const generatedAt = new Date();
        const document = {
            generatedAt: generatedAt.toISOString(),
            ignoreActiveRequests,
            fileName: `stock-${safeFileName(client.code)}-${formatIsoDate(generatedAt)}-${ignoreActiveRequests ? 'full' : 'available'}.xlsx`,
            client,
            totals: {
                rows: exportRows.length,
                skuCount: uniqueValues(exportRows.map((row) => row.skuId)).length,
                boxesCount: uniqueValues(exportRows.map((row) => row.boxCode).filter((boxCode) => Boolean(boxCode))).length,
                physicalQuantity: rows.reduce((sum, row) => sum + row.physicalQuantity, 0),
                reservedQuantity: rows.reduce((sum, row) => sum + row.reservedQuantity, 0),
                exportQuantity: exportRows.reduce((sum, row) => sum + row.exportQuantity, 0),
            },
            rows: exportRows,
        };
        return {
            fileName: document.fileName,
            mimeType: (0, turnover_receipt_xlsx_1.turnoverReceiptXlsxMimeType)(),
            content: (0, turnover_receipt_xlsx_1.buildTurnoverStockWorkbook)(document),
        };
    }
    // ADDED: отдельный read-only отчет по уже отгруженным КИЗам.
    async kizReport(query, user) {
        const { client, where } = await this.resolveKizReportQuery(query, user);
        const page = query.page ?? 1;
        const limit = query.limit ?? 50;
        const [total, historyRows] = await Promise.all([
            this.prisma.shippedKizHistory.count({ where }),
            this.prisma.shippedKizHistory.findMany({
                where,
                orderBy: [{ shippedAt: 'desc' }, { id: 'desc' }],
                skip: (page - 1) * limit,
                take: limit,
            }),
        ]);
        const items = await this.enrichKizReportRows(historyRows);
        return {
            generatedAt: new Date().toISOString(),
            client,
            filters: this.kizReportFilters(query),
            pagination: {
                page,
                limit,
                total,
                pages: total === 0 ? 0 : Math.ceil(total / limit),
            },
            items,
        };
    }
    async getKizReportXlsx(query, user) {
        const { client, where } = await this.resolveKizReportQuery(query, user);
        const historyRows = await this.prisma.shippedKizHistory.findMany({
            where,
            orderBy: [{ shippedAt: 'desc' }, { id: 'desc' }],
        });
        const generatedAt = new Date();
        const document = {
            generatedAt: generatedAt.toISOString(),
            fileName: `kiz-report-${safeFileName(client.code)}-${formatIsoDate(generatedAt)}.xlsx`,
            client,
            filters: this.kizReportFilters(query),
            rows: await this.enrichKizReportRows(historyRows),
        };
        return {
            fileName: document.fileName,
            mimeType: (0, turnover_kiz_report_xlsx_1.turnoverKizReportXlsxMimeType)(),
            content: (0, turnover_kiz_report_xlsx_1.buildTurnoverKizReportWorkbook)(document),
        };
    }
    async resolveKizReportQuery(query, user) {
        this.clientScopes.requireClientAccess(user, query.clientId, 'read');
        const client = await this.prisma.client.findUnique({
            where: { id: query.clientId },
            select: { id: true, code: true, name: true },
        });
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
        const dateFrom = query.dateFrom ? new Date(`${query.dateFrom}T00:00:00.000Z`) : null;
        const dateTo = query.dateTo ? new Date(`${query.dateTo}T23:59:59.999Z`) : null;
        if (dateFrom && dateTo && dateFrom > dateTo) {
            throw new common_1.BadRequestException('Дата начала отчёта не может быть позже даты окончания.');
        }
        const warehouseScope = await this.resolveWarehouseScope(user, query.clientId);
        const search = query.search?.trim();
        const where = {
            clientId: client.id,
            ...(warehouseScope ? { warehouseId: warehouseScope.warehouseId } : {}),
            ...(dateFrom || dateTo
                ? {
                    shippedAt: {
                        ...(dateFrom ? { gte: dateFrom } : {}),
                        ...(dateTo ? { lte: dateTo } : {}),
                    },
                }
                : {}),
            ...(search
                ? {
                    OR: [
                        { supplyId: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { requestTitle: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { orderId: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { internalSku: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { barcode: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { article: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { productName: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { color: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { size: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { kiz: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                        { sourceBoxCode: { contains: search, mode: client_1.Prisma.QueryMode.insensitive } },
                    ],
                }
                : {}),
        };
        return { client, where };
    }
    kizReportFilters(query) {
        return {
            dateFrom: query.dateFrom?.trim() || null,
            dateTo: query.dateTo?.trim() || null,
            search: query.search?.trim() || null,
        };
    }
    async enrichKizReportRows(historyRows) {
        if (historyRows.length === 0)
            return [];
        const assemblyIds = uniqueValues(historyRows.map((row) => row.assemblyId));
        const kizes = uniqueValues(historyRows.map((row) => row.kiz));
        const orderIds = uniqueValues(historyRows.map((row) => row.orderId).filter((orderId) => Boolean(orderId)));
        const [assemblyChunks, linkChunks, printChunks] = await Promise.all([
            Promise.all(chunkValues(assemblyIds, 5000).map((ids) => this.prisma.fbsTsdAssembly.findMany({
                where: { id: { in: ids } },
                select: {
                    id: true,
                    status: true,
                    stickerPartB: true,
                    stickerBarcode: true,
                },
            }))),
            Promise.all(chunkValues(orderIds, 5000).map((ids) => this.prisma.fbsOrderRequestLink.findMany({
                where: {
                    clientId: historyRows[0].clientId,
                    orderId: { in: ids },
                },
                select: {
                    clientId: true,
                    orderId: true,
                    lastCategory: true,
                    lastSupplierStatus: true,
                    lastWbStatus: true,
                    lastSeenAt: true,
                    updatedAt: true,
                },
                orderBy: [{ lastSeenAt: 'desc' }, { updatedAt: 'desc' }],
            }))),
            Promise.all(
            // FIX: KIZ is unique/indexed; avoid scanning print history by non-indexed assemblyId.
            chunkValues(kizes, 5000).map((values) => this.prisma.fbsWebKizStickerPrint.findMany({
                where: { kiz: { in: values } },
                select: { assemblyId: true, stickerCode: true },
                orderBy: { printedAt: 'desc' },
            }))),
        ]);
        const assemblyById = new Map(assemblyChunks.flat().map((row) => [row.id, row]));
        const printByAssemblyId = new Map();
        for (const row of printChunks.flat()) {
            if (row.stickerCode && !printByAssemblyId.has(row.assemblyId)) {
                printByAssemblyId.set(row.assemblyId, row.stickerCode);
            }
        }
        const linkByOrder = new Map();
        for (const row of linkChunks.flat()) {
            const key = `${row.clientId}:${row.orderId}`;
            if (!linkByOrder.has(key))
                linkByOrder.set(key, row);
        }
        return historyRows.map((row) => {
            const assembly = assemblyById.get(row.assemblyId);
            const link = row.orderId ? linkByOrder.get(`${row.clientId}:${row.orderId}`) : undefined;
            return {
                id: row.id,
                assemblyId: row.assemblyId,
                clientId: row.clientId,
                clientName: row.clientName,
                requestId: row.requestId,
                requestNumber: row.requestNumber,
                requestTitle: row.requestTitle,
                orderId: row.orderId,
                supplyId: row.supplyId,
                skuId: row.skuId,
                internalSku: row.internalSku,
                barcode: row.barcode,
                article: row.article,
                productName: row.productName,
                color: row.color,
                size: row.size,
                kiz: row.kiz,
                sourceBoxCode: row.sourceBoxCode,
                arrivalAt: row.arrivalAt?.toISOString() ?? null,
                shippedAt: row.shippedAt.toISOString(),
                stickerPartB: assembly?.stickerPartB ?? null,
                stickerBarcode: assembly?.stickerBarcode ?? printByAssemblyId.get(row.assemblyId) ?? null,
                assemblyStatus: assembly?.status ?? null,
                wbCategory: link?.lastCategory ?? null,
                wbSupplierStatus: link?.lastSupplierStatus ?? null,
                wbStatus: link?.lastWbStatus ?? null,
                wbStatusUpdatedAt: (link?.lastSeenAt ?? link?.updatedAt)?.toISOString() ?? null,
            };
        });
    }
    async applyActiveRequestReservations(clientId, rows, warehouseId) {
        const requests = await this.prisma.clientRequest.findMany({
            where: {
                clientId,
                ...(warehouseId ? { warehouseId } : {}),
                type: client_1.ClientRequestType.OUTBOUND,
                status: { in: ACTIVE_STOCK_EXPORT_REQUEST_STATUSES },
            },
            select: {
                items: {
                    select: {
                        skuId: true,
                        barcode: true,
                        quantity: true,
                    },
                },
            },
            orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
        });
        if (requests.length === 0) {
            return;
        }
        const rowsBySkuId = new Map();
        const rowsByBarcode = new Map();
        rows.forEach((row) => {
            const skuRows = rowsBySkuId.get(row.skuId) ?? [];
            skuRows.push(row);
            rowsBySkuId.set(row.skuId, skuRows);
            row.barcodeSet.forEach((barcode) => {
                const barcodeRows = rowsByBarcode.get(barcode) ?? [];
                barcodeRows.push(row);
                rowsByBarcode.set(barcode, barcodeRows);
            });
        });
        requests.forEach((request) => {
            request.items.forEach((item) => {
                let remainingQuantity = Math.max(0, item.quantity);
                if (remainingQuantity === 0) {
                    return;
                }
                const skuRows = item.skuId ? rowsBySkuId.get(item.skuId) ?? [] : [];
                const barcodeRows = item.barcode ? rowsByBarcode.get(item.barcode) ?? [] : [];
                const candidates = (skuRows.length > 0 ? skuRows : barcodeRows).slice().sort(stockExportReservationSort);
                for (const row of candidates) {
                    if (remainingQuantity <= 0) {
                        break;
                    }
                    const takeQuantity = Math.min(row.exportQuantity, remainingQuantity);
                    if (takeQuantity <= 0) {
                        continue;
                    }
                    row.reservedQuantity += takeQuantity;
                    row.exportQuantity -= takeQuantity;
                    remainingQuantity -= takeQuantity;
                }
            });
        });
    }
    buildSkuWhere(query, clientFilter) {
        const search = query.search?.trim();
        const barcode = query.barcode?.trim();
        const kiz = query.kiz?.trim();
        return {
            clientId: clientFilter,
            ...(query.skuId ? { id: query.skuId } : {}),
            ...(barcode ? { barcodes: { some: { value: barcode } } } : {}),
            ...(kiz ? { productMarks: { some: { value: { contains: kiz, mode: client_1.Prisma.QueryMode.insensitive } } } } : {}),
            ...(search
                ? {
                    OR: [
                        { name: { contains: search, mode: 'insensitive' } },
                        { internalSku: { contains: search, mode: 'insensitive' } },
                        { clientSku: { contains: search, mode: 'insensitive' } },
                        { article: { contains: search, mode: 'insensitive' } },
                        { barcodes: { some: { value: { contains: search } } } },
                    ],
                }
                : {}),
        };
    }
    async loadRequestMap(movements) {
        const ids = uniqueValues(movements.map((movement) => extractUuid(movement.sourceDocument)).filter((id) => Boolean(id)));
        if (ids.length === 0) {
            return new Map();
        }
        const requests = await this.prisma.clientRequest.findMany({
            where: { id: { in: ids } },
            select: { id: true, title: true, status: true, destinationCity: true, createdAt: true },
        });
        return new Map(requests.map((request) => [request.id, request]));
    }
    async loadStoragePlacementMap(skus) {
        const boxIds = uniqueValues(skus.flatMap((sku) => sku.balances.map((balance) => balance.boxId).filter((id) => Boolean(id))));
        const boxCodes = uniqueValues(skus.flatMap((sku) => sku.balances.map((balance) => balance.box?.code).filter((code) => Boolean(code))));
        if (boxIds.length === 0 && boxCodes.length === 0) {
            return new Map();
        }
        const placements = await this.prisma.storagePalletBox.findMany({
            where: {
                OR: [
                    ...(boxIds.length ? [{ boxId: { in: boxIds } }] : []),
                    ...(boxCodes.length ? [{ boxCode: { in: boxCodes } }] : []),
                ],
            },
            select: {
                boxId: true,
                boxCode: true,
                source: true,
                pallet: {
                    select: {
                        id: true,
                        code: true,
                        zone: { select: { id: true, code: true, name: true } },
                    },
                },
            },
        });
        const result = new Map();
        placements.forEach((placement) => {
            const value = { source: placement.source, pallet: placement.pallet };
            if (placement.boxId)
                result.set(`id:${placement.boxId}`, value);
            result.set(`code:${placement.boxCode.trim().toLocaleUpperCase('ru-RU')}`, value);
        });
        return result;
    }
    mapSkuReport(sku, requestMap, storagePlacementMap) {
        const firstReceipt = sku.movements.find(isReceiptMovement) ?? null;
        const latestShip = [...sku.movements].reverse().find((movement) => movement.type === client_1.MovementType.SHIP && movement.quantity < 0) ?? null;
        const latestNegative = [...sku.movements].reverse().find((movement) => movement.quantity < 0 && movement.type !== client_1.MovementType.PICK) ?? null;
        const currentQuantity = sku.balances.reduce((sum, balance) => sum + balance.quantity, 0);
        const receivedQuantity = sku.movements.filter(isReceiptMovement).reduce((sum, movement) => sum + movement.quantity, 0);
        const shippedQuantity = sku.movements
            .filter((movement) => movement.type === client_1.MovementType.SHIP && movement.quantity < 0)
            .reduce((sum, movement) => sum + Math.abs(movement.quantity), 0);
        const writtenOffQuantity = sku.movements
            .filter((movement) => movement.type === client_1.MovementType.INVENTORY_ADJUSTMENT && movement.quantity < 0)
            .reduce((sum, movement) => sum + Math.abs(movement.quantity), 0);
        const request = latestShip ? requestMap.get(extractUuid(latestShip.sourceDocument) ?? '') ?? null : null;
        const lastExit = currentQuantity === 0 ? latestNegative : null;
        return {
            skuId: sku.id,
            client: sku.client,
            internalSku: sku.internalSku,
            clientSku: sku.clientSku,
            article: sku.article,
            name: sku.name,
            color: sku.color,
            size: sku.size,
            primaryBarcode: sku.barcodes[0]?.value ?? null,
            barcodes: sku.barcodes.map((barcode) => barcode.value),
            volumeLiters: nullableNumber(sku.volumeLiters),
            firstReceiptAt: firstReceipt?.createdAt.toISOString() ?? null,
            firstCell: firstReceipt?.box?.code ?? null,
            shippedByRequest: request,
            latestShipAt: latestShip?.createdAt.toISOString() ?? null,
            writtenOffAt: lastExit?.createdAt.toISOString() ?? null,
            storageDays: firstReceipt ? daysBetween(firstReceipt.createdAt, lastExit?.createdAt ?? latestShip?.createdAt ?? new Date()) : 0,
            receivedQuantity,
            shippedQuantity,
            writtenOffQuantity,
            currentQuantity,
            currentCells: sku.balances.map((balance) => {
                const storagePlacement = balance.box?.storagePlacement
                    ?? (balance.boxId ? storagePlacementMap.get(`id:${balance.boxId}`) : null)
                    ?? (balance.box?.code
                        ? storagePlacementMap.get(`code:${balance.box.code.trim().toLocaleUpperCase('ru-RU')}`)
                        : null)
                    ?? null;
                const storageZone = storagePlacement?.pallet.zone ?? balance.box?.zone ?? balance.pallet?.zone ?? null;
                return {
                    boxId: balance.boxId,
                    boxCode: balance.box?.code ?? 'Без короба',
                    palletCode: balance.pallet?.code ?? null,
                    palletSortCode: storagePlacement?.pallet.code ?? null,
                    storageZone,
                    placementSource: storagePlacement?.source ?? null,
                    status: balance.status,
                    quantity: balance.quantity,
                };
            }),
            kiz: sku.productMarks.map((mark) => ({
                id: mark.id,
                value: mark.value,
                status: mark.status,
                createdAt: mark.createdAt.toISOString(),
            })),
            movements: sku.movements.map((movement) => {
                const movementRequest = requestMap.get(extractUuid(movement.sourceDocument) ?? '') ?? null;
                return {
                    id: movement.id,
                    date: movement.createdAt.toISOString(),
                    type: movement.type,
                    typeLabel: movementTypeLabel(movement.type),
                    status: movement.status,
                    statusLabel: stockStatusLabel(movement.status),
                    quantity: movement.quantity,
                    boxCode: movement.box?.code ?? null,
                    palletCode: null,
                    sourceDocument: movement.sourceDocument,
                    request: movementRequest,
                    comment: movement.comment,
                    kiz: movement.productMarks.map((mark) => mark.value),
                };
            }),
        };
    }
    requireInternalStatisticsAccess(user) {
        if (user.permissionCodes.includes('system:admin')) {
            return;
        }
        if (user.roleCodes.some((role) => ['ADMIN', 'OWNER', 'MANAGER', 'BRANCH_MANAGER'].includes(role))) {
            return;
        }
        throw new common_1.ForbiddenException('Статистика товарооборота доступна администратору, владельцу и менеджеру.');
    }
    async resolveWarehouseScope(user, clientFilter) {
        const warehouseId = warehouseScopedInternalWarehouseId(user);
        if (!warehouseId)
            return null;
        const clients = await this.prisma.client.findMany({
            where: { id: clientFilter, storesWithoutBoxes: true },
            select: {
                id: true,
                warehouseLinks: {
                    where: { status: 'ACTIVE' },
                    select: { warehouseId: true },
                },
            },
        });
        return {
            warehouseId,
            boxlessClientIds: clients
                .filter((client) => client.warehouseLinks.some((link) => link.warehouseId === warehouseId))
                .map((client) => client.id),
            legacyBoxlessClientIds: clients
                .filter((client) => client.warehouseLinks.length === 1 &&
                client.warehouseLinks[0].warehouseId === warehouseId)
                .map((client) => client.id),
        };
    }
    balanceWarehouseWhere(scope) {
        if (!scope)
            return undefined;
        return {
            OR: [
                { warehouseId: scope.warehouseId },
                {
                    warehouseId: null,
                    boxId: { not: null },
                    box: { warehouseId: scope.warehouseId },
                },
                {
                    warehouseId: null,
                    boxId: null,
                    palletId: { not: null },
                    pallet: { zone: { warehouseId: scope.warehouseId } },
                },
            ],
        };
    }
    movementWarehouseWhere(scope) {
        if (!scope)
            return undefined;
        return {
            OR: [
                { warehouseId: scope.warehouseId },
                {
                    warehouseId: null,
                    boxId: { not: null },
                    box: { warehouseId: scope.warehouseId },
                },
                ...(scope.legacyBoxlessClientIds.length
                    ? [{ warehouseId: null, boxId: null, palletId: null, clientId: { in: scope.legacyBoxlessClientIds } }]
                    : []),
            ],
        };
    }
    movementVisibilityWhere(user) {
        // FIX: clients do not see the administrator-only cleanup action.
        return user.roleCodes.includes('CLIENT') && !user.permissionCodes.includes('system:admin')
            ? (0, administration_unpalleted_writeoff_service_1.excludeAdminUnpalletedWriteoffMovement)()
            : undefined;
    }
    balanceVisibilityWhere(user) {
        return this.isExternalClient(user) ? (0, administration_unpalleted_writeoff_service_1.targetClientPlacedBalanceVisibility)() : undefined;
    }
    markVisibilityWhere(user) {
        if (!this.isExternalClient(user))
            return undefined;
        return {
            OR: [
                { clientId: { not: administration_unpalleted_writeoff_service_1.UNPALLETED_WRITEOFF_TARGET_CLIENT_ID } },
                {
                    clientId: administration_unpalleted_writeoff_service_1.UNPALLETED_WRITEOFF_TARGET_CLIENT_ID,
                    boxId: { not: null },
                    box: {
                        status: { notIn: ['deleted', 'archived'] },
                        storagePlacement: { isNot: null },
                    },
                },
            ],
        };
    }
    boxVisibilityWhere(user) {
        if (!this.isExternalClient(user))
            return undefined;
        return {
            OR: [
                { clientId: { not: administration_unpalleted_writeoff_service_1.UNPALLETED_WRITEOFF_TARGET_CLIENT_ID } },
                {
                    clientId: administration_unpalleted_writeoff_service_1.UNPALLETED_WRITEOFF_TARGET_CLIENT_ID,
                    status: { notIn: ['deleted', 'archived'] },
                    storagePlacement: { isNot: null },
                },
            ],
        };
    }
    isExternalClient(user) {
        return user.roleCodes.includes('CLIENT') && !user.permissionCodes.includes('system:admin');
    }
    markWarehouseWhere(scope) {
        if (!scope)
            return undefined;
        return {
            OR: [
                { boxId: { not: null }, box: { warehouseId: scope.warehouseId } },
                ...(scope.legacyBoxlessClientIds.length
                    ? [{ boxId: null, clientId: { in: scope.legacyBoxlessClientIds } }]
                    : []),
            ],
        };
    }
    boxWarehouseWhere(scope) {
        return scope ? { warehouseId: scope.warehouseId } : undefined;
    }
    assertUnambiguousBoxlessClient(clientId, scope) {
        if (scope && !scope.boxlessClientIds.includes(clientId)) {
            throw new common_1.BadRequestException('Операция без короба недоступна: клиент работает более чем в одном филиале.');
        }
    }
    async resolveSku(tx, clientId, skuId, barcode) {
        const sku = skuId
            ? await tx.sku.findFirst({ where: { id: skuId, clientId }, include: { barcodes: true } })
            : await tx.sku.findFirst({
                where: {
                    clientId,
                    barcodes: { some: { value: barcode?.trim() } },
                },
                include: { barcodes: true },
            });
        if (!sku) {
            throw new common_1.NotFoundException('Товар не найден в каталоге клиента.');
        }
        return sku;
    }
    async ensureBox(tx, clientId, code, warehouseScope) {
        const cleanCode = code.trim();
        if (!cleanCode) {
            throw new common_1.BadRequestException('Укажите номер ячейки или короба.');
        }
        const existing = await tx.box.findUnique({
            where: { clientId_code: { clientId, code: cleanCode } },
        });
        if (existing) {
            if (warehouseScope && existing.warehouseId !== warehouseScope.warehouseId) {
                throw new common_1.NotFoundException('Короб не найден в текущем филиале.');
            }
            return existing;
        }
        return tx.box.create({
            data: {
                clientId,
                code: cleanCode,
                ...(warehouseScope ? { warehouseId: warehouseScope.warehouseId } : {}),
            },
        });
    }
    async decrementAvailable(tx, clientId, skuId, quantity, sourceBoxCode, warehouseScope = null) {
        const sourceBox = sourceBoxCode?.trim()
            ? await tx.box.findUnique({ where: { clientId_code: { clientId, code: sourceBoxCode.trim() } } })
            : null;
        if (sourceBoxCode?.trim() && !sourceBox) {
            throw new common_1.NotFoundException('Исходная ячейка или короб не найдены.');
        }
        if (sourceBox && warehouseScope && sourceBox.warehouseId !== warehouseScope.warehouseId) {
            throw new common_1.NotFoundException('Исходный короб не найден в текущем филиале.');
        }
        const balances = await tx.stockBalance.findMany({
            where: {
                clientId,
                skuId,
                quantity: { gt: 0 },
                boxId: sourceBoxCode?.trim() ? sourceBox?.id : undefined,
                status: { in: [client_1.StockStatus.AVAILABLE, client_1.StockStatus.RECEIVING, client_1.StockStatus.UNMARKED, client_1.StockStatus.NEEDS_LABEL, client_1.StockStatus.NEEDS_RELABEL] },
                ...(this.balanceWarehouseWhere(warehouseScope) ?? {}),
            },
            include: {
                box: { select: { id: true, code: true, status: true, palletId: true } },
            },
            orderBy: [{ updatedAt: 'asc' }],
        });
        let remaining = quantity;
        const allocations = [];
        for (const balance of balances) {
            if (remaining <= 0) {
                break;
            }
            const take = Math.min(balance.quantity, remaining);
            const updated = await tx.stockBalance.update({
                where: { id: balance.id },
                data: { quantity: { decrement: take } },
            });
            if (updated.quantity < 0) {
                throw new common_1.BadRequestException('Складская операция увела остаток в минус.');
            }
            if (updated.quantity === 0) {
                await tx.stockBalance.delete({ where: { id: balance.id } });
            }
            allocations.push({ balance, quantity: take });
            remaining -= take;
        }
        if (remaining > 0) {
            throw new common_1.BadRequestException('Недостаточно доступного остатка для операции.');
        }
        return allocations;
    }
    incrementBalance(tx, input) {
        const keyParts = [
            input.clientId,
            input.skuId,
            input.boxId ?? 'no-box',
            input.palletId ?? 'no-pallet',
            input.status,
        ];
        if (!input.boxId && !input.palletId) {
            keyParts.push('warehouse', input.warehouseId);
        }
        const balanceKey = keyParts.join(':');
        return tx.stockBalance.upsert({
            where: { balanceKey },
            update: {
                quantity: { increment: input.quantity },
                warehouseId: input.warehouseId,
            },
            create: {
                balanceKey,
                warehouseId: input.warehouseId,
                clientId: input.clientId,
                skuId: input.skuId,
                boxId: input.boxId,
                palletId: input.palletId,
                status: input.status,
                quantity: input.quantity,
            },
        });
    }
    actionComment(dto, user) {
        const parts = [
            actionLabel(dto.action),
            dto.reason?.trim() ? `Причина: ${dto.reason.trim()}` : null,
            dto.photoFileName?.trim() ? `Фото: ${dto.photoFileName.trim()}` : null,
            dto.comment?.trim() ? dto.comment.trim() : null,
            `Пользователь: ${user.name}`,
        ];
        return parts.filter(Boolean).join('. ');
    }
    async attachKizValues(tx, clientId, skuId, boxId, movementId, status, values) {
        for (const value of values) {
            await tx.productMark.upsert({
                where: { clientId_value: { clientId, value } },
                update: { skuId, boxId, stockMovementId: movementId, status },
                create: { clientId, skuId, boxId, stockMovementId: movementId, value, status, sourceDocument: 'turnover-action' },
            });
        }
    }
    async moveKizValues(tx, clientId, skuId, boxId, movementId, status, values) {
        if (values.length === 0) {
            return;
        }
        await tx.productMark.updateMany({
            where: { clientId, skuId, value: { in: values } },
            data: { boxId, stockMovementId: movementId, status },
        });
    }
    async assertKizValuesInWarehouse(tx, clientId, values, scope) {
        if (!scope || values.length === 0)
            return;
        const existingMarks = await tx.productMark.findMany({
            where: { clientId, value: { in: values } },
            select: {
                value: true,
                boxId: true,
                box: { select: { warehouseId: true } },
            },
        });
        const hasForeignMark = existingMarks.some((mark) => mark.boxId
            ? mark.box?.warehouseId !== scope.warehouseId
            : !scope.boxlessClientIds.includes(clientId));
        if (hasForeignMark) {
            throw new common_1.NotFoundException('КИЗ не найден в текущем филиале.');
        }
    }
    actionResult(status, idempotencyKey, sku, quantity, targetBoxCode) {
        return {
            status,
            idempotencyKey,
            skuId: sku.id,
            skuName: sku.name,
            quantity,
            targetBoxCode,
        };
    }
};
exports.TurnoverService = TurnoverService;
exports.TurnoverService = TurnoverService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        inventory_lock_service_1.InventoryLockService,
        box_code_policy_service_1.BoxCodePolicyService])
], TurnoverService);
const INCOMING_DOCUMENT_MOVEMENT_TYPES = [
    client_1.MovementType.INITIAL_IMPORT,
    client_1.MovementType.RECEIPT,
    client_1.MovementType.RETURN,
];
function normalizeTurnoverTargetBoxCode(value) {
    const cleanCode = value?.trim();
    if (!cleanCode) {
        return null;
    }
    return cleanCode.toLocaleUpperCase('ru-RU') === 'БЕЗ КОРОБА'
        ? null
        : cleanCode;
}
function warehouseScopedInternalWarehouseId(user) {
    if (!user.activeWarehouseId ||
        user.roleCodes.includes('CLIENT')) {
        return null;
    }
    return user.activeWarehouseId;
}
const DOCUMENT_MOVEMENT_TYPES = [...INCOMING_DOCUMENT_MOVEMENT_TYPES, client_1.MovementType.SHIP];
const ACTIVE_STOCK_EXPORT_REQUEST_STATUSES = [
    client_1.ClientRequestStatus.IN_WORK,
];
const stockExportBalanceInclude = {
    sku: {
        include: {
            barcodes: { orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] },
        },
    },
    box: { select: { id: true, code: true, status: true } },
    pallet: { select: { id: true, code: true, status: true } },
};
const receiptDocumentInclude = {
    client: { select: { id: true, code: true, name: true } },
    sku: {
        select: {
            id: true,
            internalSku: true,
            clientSku: true,
            article: true,
            name: true,
            color: true,
            size: true,
            barcodes: { select: { value: true, isPrimary: true }, orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] },
        },
    },
    box: { select: { id: true, code: true, status: true } },
    productMarks: { select: { value: true, sourceRow: true }, orderBy: [{ sourceRow: 'asc' }, { value: 'asc' }] },
};
const receiptPeriodInclude = {
    sku: {
        select: {
            id: true,
            internalSku: true,
            clientSku: true,
            article: true,
            name: true,
            color: true,
            size: true,
            barcodes: { select: { value: true, isPrimary: true }, orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] },
        },
    },
    box: { select: { id: true, code: true } },
    productMarks: { select: { value: true }, orderBy: [{ value: 'asc' }] },
};
function buildReceiptDocument(movementId, movements, sourceDocument) {
    const first = movements[0];
    const last = movements[movements.length - 1] ?? first;
    const rows = movements.map((movement, index) => {
        const primaryBarcode = movement.sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? movement.sku.barcodes[0]?.value ?? null;
        const sourceRows = uniqueValues(movement.productMarks.map((mark) => mark.sourceRow).filter((row) => row != null));
        return {
            position: index + 1,
            movementId: movement.id,
            date: movement.createdAt.toISOString(),
            boxCode: movement.box?.code ?? null,
            barcode: primaryBarcode,
            internalSku: movement.sku.internalSku,
            clientSku: movement.sku.clientSku,
            article: movement.sku.article,
            name: movement.sku.name,
            color: movement.sku.color,
            size: movement.sku.size,
            quantity: Math.abs(movement.quantity),
            status: movement.status,
            statusLabel: stockStatusLabel(movement.status),
            kiz: movement.productMarks.map((mark) => mark.value).join(', ') || null,
            sourceRows,
            comment: movement.comment,
        };
    });
    const sourceName = sourceDocument || `movement-${movementId.slice(0, 8)}`;
    return {
        movementId,
        sourceDocument,
        type: first.type,
        typeLabel: movementTypeLabel(first.type),
        generatedAt: new Date().toISOString(),
        periodFrom: first.createdAt.toISOString(),
        periodTo: last.createdAt.toISOString(),
        totalQuantity: rows.reduce((sum, row) => sum + row.quantity, 0),
        skuCount: uniqueValues(rows.map((row) => row.internalSku)).length,
        boxesCount: uniqueValues(rows.map((row) => row.boxCode).filter((boxCode) => Boolean(boxCode))).length,
        fileName: `movement-${safeFileName(first.client.code)}-${safeFileName(sourceName)}.xlsx`,
        client: first.client,
        rows,
    };
}
function buildReceiptPeriodDocument(client, movements, query) {
    const rows = movements.flatMap((movement) => receiptPeriodRowsFromMovement(movement));
    const periodFrom = query.receiptBatchDate ?? query.dateFrom ?? movements[0]?.createdAt.toISOString() ?? null;
    const periodTo = query.receiptBatchDate ?? query.dateTo ?? movements[movements.length - 1]?.createdAt.toISOString() ?? null;
    const periodName = query.receiptBatchDate
        ? `batch-${query.receiptBatchDate}`
        : [query.dateFrom || 'all', query.dateTo || query.dateFrom || 'all'].join('_');
    return {
        generatedAt: new Date().toISOString(),
        periodFrom,
        periodTo,
        totalQuantity: rows.reduce((sum, row) => sum + row.quantity, 0),
        skuCount: uniqueValues(movements.map((movement) => movement.skuId)).length,
        boxesCount: uniqueValues(rows.map((row) => row.boxCode).filter((boxCode) => Boolean(boxCode))).length,
        fileName: `receipt-${safeFileName(client.code)}-${safeFileName(periodName)}.xlsx`,
        client,
        rows: rows.map((row, index) => ({ ...row, position: index + 1 })),
    };
}
function receiptPeriodRowsFromMovement(movement) {
    const primaryBarcode = movement.sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? movement.sku.barcodes[0]?.value ?? null;
    const marks = movement.productMarks.map((mark) => mark.value).filter(Boolean);
    const baseRow = {
        movementId: movement.id,
        date: movement.createdAt.toISOString(),
        boxCode: movement.box?.code ?? null,
        barcode: primaryBarcode,
        name: movement.sku.name,
        clientSku: movement.sku.clientSku,
        article: movement.sku.article,
        internalSku: movement.sku.internalSku,
        color: movement.sku.color,
        size: movement.sku.size,
        sourceDocument: movement.sourceDocument,
    };
    if (marks.length === 0) {
        return [
            {
                ...baseRow,
                kiz: null,
                quantity: Math.abs(movement.quantity),
            },
        ];
    }
    const rows = marks.map((kiz) => ({
        ...baseRow,
        kiz,
        quantity: 1,
    }));
    const quantityWithoutKiz = Math.max(0, Math.abs(movement.quantity) - marks.length);
    if (quantityWithoutKiz > 0) {
        rows.push({
            ...baseRow,
            kiz: null,
            quantity: quantityWithoutKiz,
        });
    }
    return rows;
}
function isDocumentMovement(movement) {
    if (!DOCUMENT_MOVEMENT_TYPES.includes(movement.type)) {
        return false;
    }
    return movement.type === client_1.MovementType.SHIP ? movement.quantity < 0 : movement.quantity > 0;
}
function documentGroupWhere(seed, sourceDocument) {
    if (seed.type === client_1.MovementType.SHIP) {
        return {
            clientId: seed.clientId,
            sourceDocument,
            type: client_1.MovementType.SHIP,
            quantity: { lt: 0 },
        };
    }
    return {
        clientId: seed.clientId,
        sourceDocument,
        quantity: { gt: 0 },
        type: { in: INCOMING_DOCUMENT_MOVEMENT_TYPES },
    };
}
function isReceiptMovement(movement) {
    const receiptMovementTypes = [
        client_1.MovementType.INITIAL_IMPORT,
        client_1.MovementType.RECEIPT,
        client_1.MovementType.RETURN,
        client_1.MovementType.INVENTORY_ADJUSTMENT,
    ];
    return (movement.quantity > 0 &&
        receiptMovementTypes.includes(movement.type));
}
function dateRange(dateFrom, dateTo) {
    if (!dateFrom && !dateTo) {
        return undefined;
    }
    return {
        ...(dateFrom ? { gte: new Date(dateFrom) } : {}),
        ...(dateTo ? { lte: endOfDay(new Date(dateTo)) } : {}),
    };
}
function endOfDay(date) {
    const next = new Date(date);
    next.setHours(23, 59, 59, 999);
    return next;
}
function normalizedFilters(query) {
    return {
        clientId: query.clientId ?? null,
        skuId: query.skuId ?? null,
        barcode: query.barcode ?? null,
        kiz: query.kiz ?? null,
        search: query.search ?? null,
        dateFrom: query.dateFrom ?? null,
        dateTo: query.dateTo ?? null,
    };
}
function daysBetween(from, to) {
    const start = new Date(from);
    const end = new Date(to);
    start.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);
    return Math.max(0, Math.ceil((end.getTime() - start.getTime()) / 86_400_000));
}
function nullableNumber(value) {
    return value == null ? null : Number(value);
}
function movementTypeLabel(type) {
    const labels = {
        INITIAL_IMPORT: 'Первичная загрузка',
        RECEIPT: 'Приемка',
        MOVE: 'Перемещение',
        RESERVE: 'Резерв',
        PICK: 'Сборка',
        PACK: 'Упаковка',
        SHIP: 'Отгрузка',
        RETURN: 'Возврат',
        INVENTORY_ADJUSTMENT: 'Корректировка',
    };
    return labels[type];
}
function stockStatusLabel(status) {
    const labels = {
        AVAILABLE: 'Доступно',
        IN_TRANSIT: 'В пути между филиалами',
        RESERVED: 'Резерв',
        RECEIVING: 'Приемка',
        PACKING: 'Сборка',
        SHIPPING: 'Отгрузка',
        BLOCKED: 'Отложено',
        DEFECT: 'Дефект',
        QUARANTINE: 'Карантин',
        UNMARKED: 'Без маркировки',
        NEEDS_LABEL: 'Нужна этикетка',
        NEEDS_RELABEL: 'Нужна перемаркировка',
    };
    return labels[status];
}
function actionLabel(action) {
    const labels = {
        ADD: 'Добавление товара',
        WRITE_OFF: 'Списание товара',
        TRANSFER: 'Перенос товара',
        UTILIZE: 'Утилизация товара',
        HOLD: 'Отложено на отдельное хранение',
        REPLACE_BARCODE: 'Исправление ошибочного ШК', // ADDED
    };
    return labels[action];
}
function extractUuid(value) {
    return value?.match(/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/i)?.[0] ?? null;
}
function uniqueValues(values) {
    return Array.from(new Set(values));
}
function chunkValues(values, size) {
    const chunks = [];
    for (let index = 0; index < values.length; index += size) {
        chunks.push(values.slice(index, index + size));
    }
    return chunks;
}
function uniqueByValue(values, key) {
    const seen = new Set();
    const result = [];
    for (const value of values) {
        const id = key(value);
        if (seen.has(id)) {
            continue;
        }
        seen.add(id);
        result.push(value);
    }
    return result;
}
function parseKizValues(value) {
    return uniqueValues((value ?? '')
        .split(/[\n,;]+/)
        .map((item) => item.trim())
        .filter(Boolean));
}
function stockExportRowSort(a, b) {
    return ((a.boxCode ?? '').localeCompare(b.boxCode ?? '', 'ru') ||
        a.name.localeCompare(b.name, 'ru') ||
        (a.barcode ?? '').localeCompare(b.barcode ?? '', 'ru') ||
        a.status.localeCompare(b.status));
}
function stockExportReservationSort(a, b) {
    return (stockExportReservationStatusWeight(a.status) - stockExportReservationStatusWeight(b.status) ||
        stockExportRowSort(a, b));
}
function stockExportReservationStatusWeight(status) {
    const weights = {
        PACKING: 0,
        SHIPPING: 1,
        RESERVED: 2,
        AVAILABLE: 3,
    };
    return weights[status] ?? 9;
}
function stockExportMarkKey(skuId, boxId, status) {
    return [skuId, boxId ?? 'no-box', status].join(':');
}
function parseBooleanFlag(value) {
    return ['true', '1', 'yes', 'on'].includes(String(value ?? '').trim().toLowerCase());
}
function formatIsoDate(value) {
    return value.toISOString().slice(0, 10);
}
function safeFileName(value) {
    return value
        .trim()
        .replace(/[\\/:*?"<>|]+/g, '_')
        .replace(/\s+/g, '_')
        .slice(0, 80) || 'receipt';
}
function emptyStatistics(query, groupBy) {
    return {
        generatedAt: new Date().toISOString(),
        filters: normalizedFilters(query),
        groupBy,
        totals: {
            receivedQuantity: 0,
            shippedQuantity: 0,
            writtenOffQuantity: 0,
            currentQuantity: 0,
        },
        rows: [],
        trend: [],
        clientWidgetCandidate: true,
    };
}
function emptyStatisticsRow(sku, currentQuantity) {
    return {
        skuId: sku.id,
        clientId: sku.clientId,
        client: sku.client ?? null,
        internalSku: sku.internalSku,
        clientSku: sku.clientSku,
        article: sku.article,
        name: sku.name,
        primaryBarcode: sku.barcodes[0]?.value ?? null,
        receivedQuantity: 0,
        shippedQuantity: 0,
        writtenOffQuantity: 0,
        currentQuantity,
    };
}
function turnoverStatisticsPeriodSql(groupBy) {
    if (groupBy === 'day') {
        return client_1.Prisma.sql `to_char(movement."createdAt", 'YYYY-MM-DD')`;
    }
    if (groupBy === 'month') {
        return client_1.Prisma.sql `to_char(movement."createdAt", 'YYYY-MM')`;
    }
    if (groupBy === 'quarter') {
        return client_1.Prisma.sql `to_char(movement."createdAt", 'YYYY') || '-Q' || EXTRACT(QUARTER FROM movement."createdAt")::int::text`;
    }
    return client_1.Prisma.sql `to_char(movement."createdAt", 'YYYY')`;
}
