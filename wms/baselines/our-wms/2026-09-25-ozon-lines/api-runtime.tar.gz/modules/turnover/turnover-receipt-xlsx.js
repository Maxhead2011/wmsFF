"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildTurnoverReceiptWorkbook = buildTurnoverReceiptWorkbook;
exports.buildTurnoverReceiptPeriodWorkbook = buildTurnoverReceiptPeriodWorkbook;
exports.buildTurnoverStockWorkbook = buildTurnoverStockWorkbook;
exports.turnoverReceiptXlsxMimeType = turnoverReceiptXlsxMimeType;
const XLSX = __importStar(require("xlsx"));
const XLSX_MIME_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
function buildTurnoverReceiptWorkbook(document, clientSummary = false) {
    if (clientSummary)
        return buildClientReceiptSummary(document);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheetFromRows(summaryRows(document), [24, 48]), 'Сводка');
    XLSX.utils.book_append_sheet(workbook, sheetFromRows(receiptRows(document), [8, 18, 22, 18, 18, 20, 32, 18, 18, 16, 14, 24, 20, 34]), document.typeLabel);
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
function buildTurnoverReceiptPeriodWorkbook(document, clientSummary = false) {
    if (clientSummary)
        return buildClientReceiptSummary(document);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheetFromRows(periodSummaryRows(document), [24, 48]), 'Сводка');
    XLSX.utils.book_append_sheet(workbook, sheetFromRows(periodReceiptRows(document), [8, 18, 24, 20, 20, 34, 32, 18, 18, 14, 26]), 'Приемка');
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
function buildTurnoverStockWorkbook(document) {
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheetFromRows(stockSummaryRows(document), [28, 52]), 'Сводка');
    XLSX.utils.book_append_sheet(workbook, sheetFromRows(stockRows(document), [8, 24, 22, 22, 20, 20, 24, 32, 34, 20, 18, 22, 18, 16, 16, 18, 18, 16, 18, 18]), 'Остатки');
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
function turnoverReceiptXlsxMimeType() {
    return XLSX_MIME_TYPE;
}
function summaryRows(document) {
    return [
        ['Параметр', 'Значение'],
        ['Документ', document.sourceDocument || document.movementId],
        ['Клиент', `${document.client.code} · ${document.client.name}`],
        ['Тип', document.typeLabel],
        ['Дата с', formatDateTime(document.periodFrom)],
        ['Дата по', formatDateTime(document.periodTo)],
        ['Строк', document.rows.length],
        ['Товаров, шт', document.totalQuantity],
        ['SKU', document.skuCount],
        ['Коробов', document.boxesCount],
    ];
}
function receiptRows(document) {
    const rows = [
        ['№', 'Дата', 'Короб', 'Штрихкод', 'SKU WMS', 'SKU клиента', 'Товар', 'Цвет', 'Размер', 'Артикул', 'Кол-во', 'КИЗ', 'Статус', 'Комментарий'],
    ];
    document.rows.forEach((row) => {
        rows.push([
            row.position,
            formatDateTime(row.date),
            row.boxCode || '',
            row.barcode || '',
            row.internalSku,
            row.clientSku || '',
            row.name,
            row.color || '',
            row.size || '',
            row.article || '',
            row.quantity,
            row.kiz || '',
            row.statusLabel,
            row.comment || '',
        ]);
    });
    if (rows.length === 1) {
        rows.push(['', '', '', '', '', '', 'Строк движения нет', '', '', '', 0, '', '', '']);
    }
    return rows;
}
function periodSummaryRows(document) {
    return [
        ['Параметр', 'Значение'],
        ['Клиент', `${document.client.code} · ${document.client.name}`],
        ['Период с', formatDateOnly(document.periodFrom)],
        ['Период по', formatDateOnly(document.periodTo)],
        ['Строк', document.rows.length],
        ['Товаров, шт', document.totalQuantity],
        ['SKU', document.skuCount],
        ['Коробов', document.boxesCount],
        ['Сформировано', formatDateTime(document.generatedAt)],
    ];
}
function periodReceiptRows(document) {
    const rows = [
        ['№', 'Дата приемки', 'Короб', 'ШК товара', 'SKU клиента', 'КИЗ', 'Наименование', 'Цвет', 'Размер', 'Кол-во', 'Документ'],
    ];
    document.rows.forEach((row) => {
        rows.push([
            row.position,
            formatDateTime(row.date),
            row.boxCode || '',
            row.barcode || '',
            row.clientSku || '',
            row.kiz || '',
            row.name,
            row.color || '',
            row.size || '',
            row.quantity,
            row.sourceDocument || '',
        ]);
    });
    if (rows.length === 1) {
        rows.push(['', '', '', '', '', '', 'За выбранный период приемки не найдены', '', '', 0, '']);
    }
    return rows;
}
function stockSummaryRows(document) {
    return [
        ['Параметр', 'Значение'],
        ['Клиент', `${document.client.code} · ${document.client.name}`],
        ['Режим', document.ignoreActiveRequests ? 'Полный остаток' : 'За вычетом активных заявок'],
        ['Сформировано', formatDateTime(document.generatedAt)],
        ['Строк', document.totals.rows],
        ['SKU', document.totals.skuCount],
        ['Коробов', document.totals.boxesCount],
        ['Остаток в WMS, шт', document.totals.physicalQuantity],
        ['В активных заявках, шт', document.totals.reservedQuantity],
        ['К выгрузке, шт', document.totals.exportQuantity],
    ];
}
function stockRows(document) {
    const rows = [
        [
            '№',
            'Короб',
            'Паллета',
            'SKU WMS',
            'SKU клиента',
            'Артикул',
            'Основной ШК',
            'Все ШК',
            'Наименование',
            'Цвет',
            'Размер',
            'Статус',
            'Остаток WMS',
            'В заявках',
            'К выгрузке',
            'Литров ед.',
            'КИЗ',
            'Дата остатка',
            'ID остатка',
            'ID SKU',
        ],
    ];
    document.rows.forEach((row) => {
        rows.push([
            row.position,
            row.boxCode || '',
            row.palletCode || '',
            row.internalSku,
            row.clientSku || '',
            row.article || '',
            row.barcode || '',
            row.allBarcodes,
            row.name,
            row.color || '',
            row.size || '',
            row.statusLabel,
            row.physicalQuantity,
            row.reservedQuantity,
            row.exportQuantity,
            row.volumeLiters ?? '',
            row.kizCount,
            formatDateTime(row.updatedAt),
            row.balanceId,
            row.skuId,
        ]);
    });
    if (rows.length === 1) {
        rows.push(['', '', '', '', '', '', '', '', 'Остатков для выбранного режима нет', '', '', '', 0, 0, 0, '', 0, '', '', '']);
    }
    return rows;
}
function sheetFromRows(rows, widths) {
    const sheet = XLSX.utils.aoa_to_sheet(rows);
    sheet['!cols'] = widths.map((wch) => ({ wch }));
    sheet['!freeze'] = { xSplit: 0, ySplit: 1 };
    return sheet;
}
function formatDateTime(value) {
    return new Intl.DateTimeFormat('ru-RU', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(value));
}
function formatDateOnly(value) {
    if (!value) {
        return 'весь период';
    }
    return new Intl.DateTimeFormat('ru-RU').format(new Date(value));
}
// FIX: pivot the existing scoped receipt rows by barcode, without touching warehouse accounting.
function buildClientReceiptSummary(document) {
    const groups = new Map();
    for (const row of document.rows) {
        const barcode = row.barcode?.trim() || '';
        // Missing barcodes must not merge unrelated products.
        const key = barcode ? `barcode:${barcode}` : `sku:${row.internalSku}`;
        const group = groups.get(key) ?? { values: [new Set(), new Set(), new Set(), new Set()], quantity: 0, barcode };
        [row.name, row.article, row.color, row.size].forEach((value, index) => {
            if (value)
                group.values[index].add(value);
        });
        group.quantity += row.quantity;
        groups.set(key, group);
    }
    const data = [...groups.values()].map(({ values, quantity, barcode }) => {
        const [name, article, color, size] = values.map((items) => [...items].sort().join(', '));
        return [name, article, barcode, color, size, quantity];
    });
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheetFromRows([
        ['Клиент', `${document.client.code} · ${document.client.name}`],
        ['Период с', formatDateOnly(document.periodFrom)],
        ['Период по', formatDateOnly(document.periodTo)],
        ['Позиций', data.length],
        ['Товаров, шт', document.totalQuantity],
    ], [24, 48]), 'Сводка');
    XLSX.utils.book_append_sheet(workbook, sheetFromRows([
        ['Товар', 'Артикул', 'Баркод', 'Цвет', 'Размер', 'Количество'], ...data,
    ], [40, 32, 22, 24, 16, 16]), 'Приемка');
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
