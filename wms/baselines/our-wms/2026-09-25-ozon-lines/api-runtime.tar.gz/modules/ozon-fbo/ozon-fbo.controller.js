"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonFboController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const ozon_fbo_service_1 = require("./ozon-fbo.service");
let OzonFboController = class OzonFboController {
    fbo;
    constructor(fbo) {
        this.fbo = fbo;
    }
    overview(clientId, user) {
        return this.fbo.overview(clientId, user);
    }
    clusters(connectionId, user) {
        return this.fbo.listClusters(connectionId, user);
    }
    dropoffs(connectionId, search, supplyType, user) {
        return this.fbo.listDropoffWarehouses(connectionId, search, supplyType, user);
    }
    importPlan(body, file, user) {
        return this.fbo.importPlan(body, file, user);
    }
    getPlan(id, user) {
        return this.fbo.getPlan(id, user);
    }
    mapCluster(id, clusterId, body, user) {
        return this.fbo.mapCluster(id, clusterId, body, user);
    }
    setDropoff(id, body, user) {
        return this.fbo.setDropoff(id, body, user);
    }
    createDraft(id, user) {
        return this.fbo.createDraft(id, user);
    }
    refreshDraft(id, user) {
        return this.fbo.refreshDraft(id, user);
    }
    timeslots(id, body, user) {
        return this.fbo.loadTimeslots(id, body, user);
    }
    bookSlot(id, body, user) {
        return this.fbo.bookSlot(id, body, user);
    }
    refreshSupply(id, user) {
        return this.fbo.refreshSupply(id, user);
    }
    refreshOrder(id, user) {
        return this.fbo.refreshOrder(id, user);
    }
    generateBoxes(id, body, user) {
        return this.fbo.generateBoxes(id, body, user);
    }
    scanBox(id, body, user) {
        return this.fbo.scanBox(id, body.code ?? '', user);
    }
    closeBox(id, user) {
        return this.fbo.closeBox(id, user);
    }
    uploadCargoes(id, body, user) {
        return this.fbo.uploadCargoes(id, body, user);
    }
    refreshCargoes(id, user) {
        return this.fbo.refreshCargoes(id, user);
    }
    async assemblyXlsx(id, user, response) {
        const file = await this.fbo.exportAssembly(id, user);
        response.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.buffer);
    }
};
exports.OzonFboController = OzonFboController;
__decorate([
    (0, common_1.Get)('overview'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "overview", null);
__decorate([
    (0, common_1.Get)('clusters'),
    __param(0, (0, common_1.Query)('connectionId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "clusters", null);
__decorate([
    (0, common_1.Get)('dropoff-warehouses'),
    __param(0, (0, common_1.Query)('connectionId')),
    __param(1, (0, common_1.Query)('search')),
    __param(2, (0, common_1.Query)('supplyType')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "dropoffs", null);
__decorate([
    (0, common_1.Post)('plans/import'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 20 * 1024 * 1024 } })),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "importPlan", null);
__decorate([
    (0, common_1.Get)('plans/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "getPlan", null);
__decorate([
    (0, common_1.Patch)('plans/:id/clusters/:clusterId'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('clusterId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "mapCluster", null);
__decorate([
    (0, common_1.Patch)('plans/:id/dropoff'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "setDropoff", null);
__decorate([
    (0, common_1.Post)('plans/:id/draft'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "createDraft", null);
__decorate([
    (0, common_1.Post)('plans/:id/draft/refresh'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "refreshDraft", null);
__decorate([
    (0, common_1.Post)('plans/:id/timeslots'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "timeslots", null);
__decorate([
    (0, common_1.Post)('plans/:id/book-slot'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "bookSlot", null);
__decorate([
    (0, common_1.Post)('plans/:id/supply/refresh'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "refreshSupply", null);
__decorate([
    (0, common_1.Post)('plans/:id/order/refresh'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "refreshOrder", null);
__decorate([
    (0, common_1.Post)('plans/:id/boxes/generate'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "generateBoxes", null);
__decorate([
    (0, common_1.Post)('boxes/:id/scan'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "scanBox", null);
__decorate([
    (0, common_1.Post)('boxes/:id/close'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "closeBox", null);
__decorate([
    (0, common_1.Post)('plans/:id/cargoes/upload'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "uploadCargoes", null);
__decorate([
    (0, common_1.Post)('plans/:id/cargoes/refresh'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboController.prototype, "refreshCargoes", null);
__decorate([
    (0, common_1.Get)('plans/:id/assembly.xlsx'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], OzonFboController.prototype, "assemblyXlsx", null);
exports.OzonFboController = OzonFboController = __decorate([
    (0, swagger_1.ApiTags)('ozon-fbo'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    (0, common_1.Controller)('ozon-fbo'),
    __metadata("design:paramtypes", [ozon_fbo_service_1.OzonFboService])
], OzonFboController);
