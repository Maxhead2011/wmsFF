"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizIssuesModule = void 0;
const common_1 = require("@nestjs/common");
const marketplace_connections_module_1 = require("../marketplace-connections/marketplace-connections.module");
const kiz_issues_controller_1 = require("./kiz-issues.controller");
const kiz_issues_service_1 = require("./kiz-issues.service");
let KizIssuesModule = class KizIssuesModule {
};
exports.KizIssuesModule = KizIssuesModule;
exports.KizIssuesModule = KizIssuesModule = __decorate([
    (0, common_1.Module)({
        imports: [marketplace_connections_module_1.MarketplaceConnectionsModule],
        controllers: [kiz_issues_controller_1.KizIssuesController],
        providers: [kiz_issues_service_1.KizIssuesService],
    })
], KizIssuesModule);
