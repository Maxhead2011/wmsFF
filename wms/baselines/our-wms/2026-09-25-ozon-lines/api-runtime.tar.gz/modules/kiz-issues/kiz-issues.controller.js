"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizIssuesController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const resolve_kiz_issue_dto_1 = require("./dto/resolve-kiz-issue.dto");
const write_off_kiz_discrepancy_dto_1 = require("./dto/write-off-kiz-discrepancy.dto");
const kiz_issues_service_1 = require("./kiz-issues.service");
let KizIssuesController = class KizIssuesController {
    issues;
    constructor(issues) {
        this.issues = issues;
    }
    list(user, status, search, clientId, limit) {
        return this.issues.list({
            status,
            search,
            clientId,
            limit,
        }, user);
    }
    resolve(issueKey, dto, user) {
        return this.issues.resolve(issueKey, dto, user);
    }
    markRead(issueKey, user) {
        return this.issues.markRead(issueKey, user);
    }
    listDiscrepancies(user, search, clientId, limit) {
        return this.issues.listBoxDiscrepancies({ search, clientId, limit }, user);
    }
    writeOffAllDiscrepancies(dto, user, search, clientId) {
        return this.issues.writeOffAllBoxDiscrepancies({ search, clientId }, dto, user);
    }
    writeOffDiscrepancy(boxId, skuId, dto, user) {
        return this.issues.writeOffBoxDiscrepancy(boxId, skuId, dto, user);
    }
};
exports.KizIssuesController = KizIssuesController;
__decorate([
    (0, common_1.Get)('issues'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('status')),
    __param(2, (0, common_1.Query)('search')),
    __param(3, (0, common_1.Query)('clientId')),
    __param(4, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String]),
    __metadata("design:returntype", void 0)
], KizIssuesController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('issues/:issueKey/resolve'),
    __param(0, (0, common_1.Param)('issueKey')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, resolve_kiz_issue_dto_1.ResolveKizIssueDto, Object]),
    __metadata("design:returntype", void 0)
], KizIssuesController.prototype, "resolve", null);
__decorate([
    (0, common_1.Post)('issues/:issueKey/read'),
    __param(0, (0, common_1.Param)('issueKey')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], KizIssuesController.prototype, "markRead", null);
__decorate([
    (0, common_1.Get)('discrepancies'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('search')),
    __param(2, (0, common_1.Query)('clientId')),
    __param(3, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], KizIssuesController.prototype, "listDiscrepancies", null);
__decorate([
    (0, common_1.Post)('discrepancies/write-off-all'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Query)('search')),
    __param(3, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [write_off_kiz_discrepancy_dto_1.WriteOffKizDiscrepancyDto, Object, String, String]),
    __metadata("design:returntype", void 0)
], KizIssuesController.prototype, "writeOffAllDiscrepancies", null);
__decorate([
    (0, common_1.Post)('discrepancies/:boxId/:skuId/write-off'),
    __param(0, (0, common_1.Param)('boxId')),
    __param(1, (0, common_1.Param)('skuId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, write_off_kiz_discrepancy_dto_1.WriteOffKizDiscrepancyDto, Object]),
    __metadata("design:returntype", void 0)
], KizIssuesController.prototype, "writeOffDiscrepancy", null);
exports.KizIssuesController = KizIssuesController = __decorate([
    (0, common_1.Controller)('kiz'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __metadata("design:paramtypes", [kiz_issues_service_1.KizIssuesService])
], KizIssuesController);
