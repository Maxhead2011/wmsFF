"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubmitKizCirculationBatchDto = exports.SetKizCirculationSignatureDto = exports.CreateKizCirculationBatchDto = exports.ImportKizCirculationItemsDto = exports.UpdateKizCirculationItemDto = exports.CheckKizCirculationItemsDto = exports.SyncKizCirculationDto = exports.KizCirculationClientDto = exports.UpsertKizTrueApiConnectionDto = void 0;
const client_1 = require("@prisma/client");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const trimmed = ({ value }) => typeof value === 'string' ? value.trim() : value;
class UpsertKizTrueApiConnectionDto {
    inn;
    kpp;
    fiasId;
    productGroup;
    apiBaseUrl;
    apiToken;
    tokenExpiresAt;
    certificateSubject;
    certificateThumbprint;
    isActive;
}
exports.UpsertKizTrueApiConnectionDto = UpsertKizTrueApiConnectionDto;
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.Matches)(/^\d{10}(?:\d{2})?$/),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "inn", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.Matches)(/^\d{9}$/),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "kpp", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.Matches)(/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "fiasId", void 0);
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.Matches)(/^[a-z][a-z0-9_-]{1,49}$/),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "productGroup", void 0);
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsUrl)({ protocols: ['https'], require_protocol: true }),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "apiBaseUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(12_000),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "apiToken", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "tokenExpiresAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(255),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "certificateSubject", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(128),
    __metadata("design:type", String)
], UpsertKizTrueApiConnectionDto.prototype, "certificateThumbprint", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpsertKizTrueApiConnectionDto.prototype, "isActive", void 0);
class KizCirculationClientDto {
    clientId;
}
exports.KizCirculationClientDto = KizCirculationClientDto;
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 80),
    __metadata("design:type", String)
], KizCirculationClientDto.prototype, "clientId", void 0);
class SyncKizCirculationDto {
    // ADDED: период необязателен для обратной совместимости старых клиентов API.
    periodFrom;
    periodTo;
    marketplace;
}
exports.SyncKizCirculationDto = SyncKizCirculationDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], SyncKizCirculationDto.prototype, "periodFrom", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], SyncKizCirculationDto.prototype, "periodTo", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(client_1.MarketplaceType),
    __metadata("design:type", String)
], SyncKizCirculationDto.prototype, "marketplace", void 0);
class CheckKizCirculationItemsDto extends KizCirculationClientDto {
    itemIds;
}
exports.CheckKizCirculationItemsDto = CheckKizCirculationItemsDto;
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(1000),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], CheckKizCirculationItemsDto.prototype, "itemIds", void 0);
class UpdateKizCirculationItemDto {
    productCostKopecks;
    productGroup;
    excluded;
}
exports.UpdateKizCirculationItemDto = UpdateKizCirculationItemDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], UpdateKizCirculationItemDto.prototype, "productCostKopecks", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.Matches)(/^[a-z][a-z0-9_-]{1,49}$/),
    __metadata("design:type", String)
], UpdateKizCirculationItemDto.prototype, "productGroup", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateKizCirculationItemDto.prototype, "excluded", void 0);
class ImportKizCirculationItemsDto extends KizCirculationClientDto {
    operation;
    marketplace;
    codes;
    eventAt;
}
exports.ImportKizCirculationItemsDto = ImportKizCirculationItemsDto;
__decorate([
    (0, class_validator_1.IsEnum)(client_1.KizCirculationOperation),
    __metadata("design:type", String)
], ImportKizCirculationItemsDto.prototype, "operation", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(client_1.MarketplaceType),
    __metadata("design:type", String)
], ImportKizCirculationItemsDto.prototype, "marketplace", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(1000),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], ImportKizCirculationItemsDto.prototype, "codes", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], ImportKizCirculationItemsDto.prototype, "eventAt", void 0);
class CreateKizCirculationBatchDto extends KizCirculationClientDto {
    operation;
    itemIds;
    actionDate;
    documentType;
    documentNumber;
    documentDate;
    primaryDocumentCustomName;
    paid;
}
exports.CreateKizCirculationBatchDto = CreateKizCirculationBatchDto;
__decorate([
    (0, class_validator_1.IsEnum)(client_1.KizCirculationOperation),
    __metadata("design:type", String)
], CreateKizCirculationBatchDto.prototype, "operation", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(30_000),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], CreateKizCirculationBatchDto.prototype, "itemIds", void 0);
__decorate([
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateKizCirculationBatchDto.prototype, "actionDate", void 0);
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 60),
    __metadata("design:type", String)
], CreateKizCirculationBatchDto.prototype, "documentType", void 0);
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 255),
    __metadata("design:type", String)
], CreateKizCirculationBatchDto.prototype, "documentNumber", void 0);
__decorate([
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateKizCirculationBatchDto.prototype, "documentDate", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 255),
    __metadata("design:type", String)
], CreateKizCirculationBatchDto.prototype, "primaryDocumentCustomName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateKizCirculationBatchDto.prototype, "paid", void 0);
class SetKizCirculationSignatureDto {
    signature;
}
exports.SetKizCirculationSignatureDto = SetKizCirculationSignatureDto;
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(16, 4_000_000),
    __metadata("design:type", String)
], SetKizCirculationSignatureDto.prototype, "signature", void 0);
class SubmitKizCirculationBatchDto {
    confirmation;
}
exports.SubmitKizCirculationBatchDto = SubmitKizCirculationBatchDto;
__decorate([
    (0, class_transformer_1.Transform)(trimmed),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitKizCirculationBatchDto.prototype, "confirmation", void 0);
