"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizCirculationController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const kiz_circulation_dto_1 = require("./dto/kiz-circulation.dto");
const kiz_circulation_service_1 = require("./kiz-circulation.service");
let KizCirculationController = class KizCirculationController {
    service;
    constructor(service) {
        this.service = service;
    }
    overview(clientId, user) {
        return this.service.overview(clientId, user);
    }
    upsertConnection(clientId, dto, user) {
        return this.service.upsertConnection(clientId, dto, user);
    }
    sync(clientId, dto, user) {
        // FIX: выбранный в интерфейсе период доходит до фактической выборки отгрузок.
        return this.service.sync(clientId, dto, user);
    }
    importItems(dto, user) {
        return this.service.importItems(dto, user);
    }
    updateItem(itemId, dto, user) {
        return this.service.updateItem(itemId, dto, user);
    }
    checkItems(dto, user) {
        return this.service.checkItems(dto, user);
    }
    createBatch(dto, user) {
        return this.service.createBatch(dto, user);
    }
    setSignature(batchId, dto, user) {
        return this.service.setSignature(batchId, dto.signature, user);
    }
    submit(batchId, dto, user) {
        return this.service.submit(batchId, dto.confirmation, user);
    }
    refresh(batchId, user) {
        return this.service.refreshBatch(batchId, user);
    }
};
exports.KizCirculationController = KizCirculationController;
__decorate([
    (0, common_1.Get)('overview'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "overview", null);
__decorate([
    (0, common_1.Put)('connections/:clientId'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, kiz_circulation_dto_1.UpsertKizTrueApiConnectionDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "upsertConnection", null);
__decorate([
    (0, common_1.Post)('sync/:clientId'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, kiz_circulation_dto_1.SyncKizCirculationDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "sync", null);
__decorate([
    (0, common_1.Post)('items/import'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [kiz_circulation_dto_1.ImportKizCirculationItemsDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "importItems", null);
__decorate([
    (0, common_1.Patch)('items/:itemId'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Param)('itemId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, kiz_circulation_dto_1.UpdateKizCirculationItemDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "updateItem", null);
__decorate([
    (0, common_1.Post)('items/check'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [kiz_circulation_dto_1.CheckKizCirculationItemsDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "checkItems", null);
__decorate([
    (0, common_1.Post)('batches'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [kiz_circulation_dto_1.CreateKizCirculationBatchDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "createBatch", null);
__decorate([
    (0, common_1.Post)('batches/:batchId/signature'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Param)('batchId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, kiz_circulation_dto_1.SetKizCirculationSignatureDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "setSignature", null);
__decorate([
    (0, common_1.Post)('batches/:batchId/submit'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Param)('batchId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, kiz_circulation_dto_1.SubmitKizCirculationBatchDto, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "submit", null);
__decorate([
    (0, common_1.Post)('batches/:batchId/refresh'),
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:write'),
    __param(0, (0, common_1.Param)('batchId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], KizCirculationController.prototype, "refresh", null);
exports.KizCirculationController = KizCirculationController = __decorate([
    (0, common_1.Controller)('kiz-circulation')
    // FIX: доступ выдаётся отдельным правом; принадлежность clientId проверяет сервис.
    ,
    (0, require_permissions_decorator_1.RequirePermissions)('kiz-circulation:read'),
    __metadata("design:paramtypes", [kiz_circulation_service_1.KizCirculationService])
], KizCirculationController);
