"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.officialTrueApiBase = officialTrueApiBase;
exports.normalizeCisForTrueApi = normalizeCisForTrueApi;
exports.isFinalMarketplaceSale = isFinalMarketplaceSale;
exports.buildKizCirculationDocument = buildKizCirculationDocument;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const OFFICIAL_TRUE_API_BASES = new Set([
    'https://markirovka.crpt.ru/api/v3/true-api',
    'https://markirovka.sandbox.crptech.ru/api/v3/true-api',
]);
function officialTrueApiBase(value) {
    const normalized = value.trim().replace(/\/+$/, '');
    if (!OFFICIAL_TRUE_API_BASES.has(normalized)) {
        throw new common_1.BadRequestException('Разрешены только официальные адреса промышленного или тестового True API v3.');
    }
    return normalized;
}
// ADDED: True API принимает КИ без кода проверки; исходный полный Data Matrix остаётся в аудите.
function normalizeCisForTrueApi(value) {
    const normalized = value
        .trim()
        .replace(/^\]d2/i, '')
        .replace(/<GS>/gi, '\u001d')
        .replace(/\((01|21)\)/g, '$1');
    const separator = normalized.indexOf('\u001d');
    const cis = separator >= 0 && /^(?:91|92|93)/.test(normalized.slice(separator + 1))
        ? normalized.slice(0, separator)
        : normalized;
    if (cis.length < 18 || cis.length > 74) {
        throw new common_1.BadRequestException('Не удалось безопасно получить КИ без криптохвоста. Нужен исходный Data Matrix с разделителем GS.');
    }
    return cis;
}
function isFinalMarketplaceSale(marketplace, supplierStatus, marketplaceStatus) {
    const supplier = (supplierStatus ?? '').trim().toLowerCase();
    const remote = (marketplaceStatus ?? '').trim().toLowerCase();
    if (marketplace === client_1.MarketplaceType.WILDBERRIES)
        return remote === 'sold';
    if (marketplace === client_1.MarketplaceType.OZON)
        return supplier === 'delivered';
    if (marketplace === client_1.MarketplaceType.YANDEX_MARKET)
        return supplier === 'delivered';
    return false;
}
function buildKizCirculationDocument(input) {
    if (input.operation === client_1.KizCirculationOperation.RETIRE) {
        if (input.items.some((item) => !item.productCostKopecks || item.productCostKopecks < 1)) {
            throw new common_1.BadRequestException('Для дистанционной продажи укажите цену каждого КИЗ в копейках.');
        }
        return {
            inn: input.inn,
            action: 'DISTANCE',
            action_date: dateOnly(input.actionDate),
            document_type: input.documentType,
            document_number: input.documentNumber,
            document_date: dateOnly(input.documentDate),
            ...(input.documentType === 'OTHER'
                ? { primary_document_custom_name: input.primaryDocumentCustomName }
                : {}),
            ...(input.kpp ? { kpp: input.kpp } : {}),
            ...(input.fiasId ? { fias_id: input.fiasId } : {}),
            products: input.items.map((item) => ({
                cis: item.cis,
                product_cost: item.productCostKopecks,
            })),
        };
    }
    const paid = Boolean(input.paid);
    return {
        trade_participant_inn: input.inn,
        return_type: 'REMOTE_SALE_RETURN',
        paid,
        ...(paid
            ? {
                primary_document_type: input.documentType,
                primary_document_number: input.documentNumber,
                primary_document_date: dateOnly(input.documentDate),
                ...(input.documentType === 'OTHER'
                    ? { primary_document_custom_name: input.primaryDocumentCustomName }
                    : {}),
            }
            : {}),
        products_list: input.items.map((item) => ({ ki: item.cis })),
    };
}
function dateOnly(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime()))
        throw new common_1.BadRequestException('Укажите корректную дату документа.');
    return date.toISOString().slice(0, 10);
}
