"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizCirculationCryptoService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
let KizCirculationCryptoService = class KizCirculationCryptoService {
    config;
    constructor(config) {
        this.config = config;
    }
    encrypt(value) {
        const iv = (0, crypto_1.randomBytes)(12);
        const cipher = (0, crypto_1.createCipheriv)('aes-256-gcm', this.key(), iv);
        const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
        const tag = cipher.getAuthTag();
        return ['v1', iv.toString('base64url'), tag.toString('base64url'), encrypted.toString('base64url')].join(':');
    }
    decrypt(value) {
        const [version, ivValue, tagValue, encryptedValue] = value.split(':');
        if (version !== 'v1' || !ivValue || !tagValue || !encryptedValue) {
            throw new common_1.InternalServerErrorException('Доступ Честного знака сохранён в неизвестном формате.');
        }
        try {
            const decipher = (0, crypto_1.createDecipheriv)('aes-256-gcm', this.key(), Buffer.from(ivValue, 'base64url'));
            decipher.setAuthTag(Buffer.from(tagValue, 'base64url'));
            return Buffer.concat([decipher.update(Buffer.from(encryptedValue, 'base64url')), decipher.final()]).toString('utf8');
        }
        catch {
            throw new common_1.InternalServerErrorException('Не удалось расшифровать доступ Честного знака.');
        }
    }
    key() {
        const configured = this.config.get('KIZ_CREDENTIALS_SECRET');
        if (!configured && this.config.get('NODE_ENV') === 'production') {
            throw new common_1.InternalServerErrorException('KIZ_CREDENTIALS_SECRET не настроен.');
        }
        return (0, crypto_1.createHash)('sha256').update(configured || 'logoff-kiz-development-secret').digest();
    }
};
exports.KizCirculationCryptoService = KizCirculationCryptoService;
exports.KizCirculationCryptoService = KizCirculationCryptoService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], KizCirculationCryptoService);
