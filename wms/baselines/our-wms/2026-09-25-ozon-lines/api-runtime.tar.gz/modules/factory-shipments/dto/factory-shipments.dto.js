"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReconcileFactoryShipmentDto = exports.ScanFactoryShipmentDto = exports.CreateFactoryShipmentDto = exports.FactoryShipmentItemDto = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class FactoryShipmentItemDto {
    skuId;
    plannedQty;
}
exports.FactoryShipmentItemDto = FactoryShipmentItemDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], FactoryShipmentItemDto.prototype, "skuId", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], FactoryShipmentItemDto.prototype, "plannedQty", void 0);
class CreateFactoryShipmentDto {
    clientId;
    title;
    comment;
    items;
}
exports.CreateFactoryShipmentDto = CreateFactoryShipmentDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFactoryShipmentDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFactoryShipmentDto.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFactoryShipmentDto.prototype, "comment", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FactoryShipmentItemDto),
    __metadata("design:type", Array)
], CreateFactoryShipmentDto.prototype, "items", void 0);
class ScanFactoryShipmentDto {
    barcode;
    quantity;
    deviceId;
}
exports.ScanFactoryShipmentDto = ScanFactoryShipmentDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ScanFactoryShipmentDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], ScanFactoryShipmentDto.prototype, "quantity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ScanFactoryShipmentDto.prototype, "deviceId", void 0);
class ReconcileFactoryShipmentDto {
    requestId;
}
exports.ReconcileFactoryShipmentDto = ReconcileFactoryShipmentDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReconcileFactoryShipmentDto.prototype, "requestId", void 0);
