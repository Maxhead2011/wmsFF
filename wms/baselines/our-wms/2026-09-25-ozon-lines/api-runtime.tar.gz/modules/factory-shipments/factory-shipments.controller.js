"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FactoryShipmentsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const factory_shipments_dto_1 = require("./dto/factory-shipments.dto");
const factory_shipments_service_1 = require("./factory-shipments.service");
let FactoryShipmentsController = class FactoryShipmentsController {
    service;
    constructor(service) {
        this.service = service;
    }
    list(user, clientId) { return this.service.list(user, clientId); }
    bootstrap(user) { return this.service.bootstrap(user); }
    get(id, user) { return this.service.get(id, user); }
    create(dto, user) { return this.service.create(dto, user); }
    scan(id, dto, user) { return this.service.scan(id, dto, user); }
    ship(id, user) { return this.service.ship(id, user); }
    reconcile(id, dto, user) { return this.service.reconcile(id, dto, user); }
};
exports.FactoryShipmentsController = FactoryShipmentsController;
__decorate([
    (0, common_1.Get)(),
    (0, require_permissions_decorator_1.RequirePermissions)('factory-shipments:read'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], FactoryShipmentsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('app/bootstrap'),
    (0, require_permissions_decorator_1.RequirePermissions)('factory-shipments:scan'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FactoryShipmentsController.prototype, "bootstrap", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('factory-shipments:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], FactoryShipmentsController.prototype, "get", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('factory-shipments:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [factory_shipments_dto_1.CreateFactoryShipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FactoryShipmentsController.prototype, "create", null);
__decorate([
    (0, common_1.Post)(':id/scan'),
    (0, require_permissions_decorator_1.RequirePermissions)('factory-shipments:scan'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, factory_shipments_dto_1.ScanFactoryShipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FactoryShipmentsController.prototype, "scan", null);
__decorate([
    (0, common_1.Post)(':id/ship'),
    (0, require_permissions_decorator_1.RequirePermissions)('factory-shipments:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], FactoryShipmentsController.prototype, "ship", null);
__decorate([
    (0, common_1.Post)(':id/reconcile'),
    (0, require_permissions_decorator_1.RequirePermissions)('factory-shipments:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, factory_shipments_dto_1.ReconcileFactoryShipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FactoryShipmentsController.prototype, "reconcile", null);
exports.FactoryShipmentsController = FactoryShipmentsController = __decorate([
    (0, swagger_1.ApiTags)('factory-shipments'),
    (0, common_1.Controller)('factory-shipments'),
    __metadata("design:paramtypes", [factory_shipments_service_1.FactoryShipmentsService])
], FactoryShipmentsController);
