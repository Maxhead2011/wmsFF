"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FactoryShipmentsService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const shipmentInclude = {
    client: { select: { id: true, code: true, name: true, factoryName: true, factoryCode: true } },
    items: { orderBy: [{ name: 'asc' }, { size: 'asc' }] },
    scans: { orderBy: { scannedAt: 'desc' }, take: 50 },
};
let FactoryShipmentsService = class FactoryShipmentsService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    list(user, clientId) {
        const filter = this.scopes.resolveClientFilter(user, clientId);
        return this.prisma.factoryShipment.findMany({
            where: filter === undefined ? {} : { clientId: filter }, include: shipmentInclude,
            orderBy: { createdAt: 'desc' }, take: 250,
        });
    }
    async bootstrap(user) {
        const filter = this.scopes.resolveClientFilter(user);
        const clients = await this.prisma.client.findMany({
            where: { ...(filter === undefined ? {} : { id: filter }), factoryEnabled: true, status: 'ACTIVE' },
            select: { id: true, code: true, name: true, factoryName: true, factoryCode: true }, orderBy: { name: 'asc' },
        });
        const shipments = await this.prisma.factoryShipment.findMany({
            where: { clientId: { in: clients.map((item) => item.id) }, status: { in: [client_1.FactoryShipmentStatus.DRAFT, client_1.FactoryShipmentStatus.PICKING] } },
            include: shipmentInclude, orderBy: { createdAt: 'asc' },
        });
        return { clients, shipments };
    }
    async get(id, user) {
        const shipment = await this.prisma.factoryShipment.findUnique({ where: { id }, include: shipmentInclude });
        if (!shipment)
            throw new common_1.NotFoundException('Отправка с фабрики не найдена.');
        this.scopes.requireClientAccess(user, shipment.clientId, 'read');
        return shipment;
    }
    async create(dto, user) {
        this.scopes.requireClientAccess(user, dto.clientId, 'write');
        if (!dto.items.length)
            throw new common_1.BadRequestException('Добавьте хотя бы один товар.');
        const client = await this.prisma.client.findUnique({ where: { id: dto.clientId } });
        if (!client?.factoryEnabled)
            throw new common_1.BadRequestException('В настройках клиента не включён доступ к фабрике.');
        const grouped = new Map();
        for (const row of dto.items)
            grouped.set(row.skuId, (grouped.get(row.skuId) ?? 0) + row.plannedQty);
        const skus = await this.prisma.sku.findMany({
            where: { clientId: dto.clientId, id: { in: [...grouped.keys()] } },
            include: { barcodes: { orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }], take: 1 } },
        });
        if (skus.length !== grouped.size)
            throw new common_1.BadRequestException('Один или несколько товаров не принадлежат выбранному клиенту.');
        return this.prisma.factoryShipment.create({
            data: {
                clientId: dto.clientId, title: dto.title.trim(), comment: dto.comment?.trim() || null,
                factoryName: client.factoryName?.trim() || 'Бишкек', createdByUserId: user.id,
                items: { create: skus.map((sku) => ({
                        skuId: sku.id, barcode: sku.barcodes[0]?.value ?? null, name: sku.name,
                        article: sku.article ?? sku.internalSku, size: sku.size, plannedQty: grouped.get(sku.id),
                    })) },
            }, include: shipmentInclude,
        });
    }
    async scan(id, dto, user) {
        const shipment = await this.get(id, user);
        this.scopes.requireClientAccess(user, shipment.clientId, 'write');
        if (shipment.status !== client_1.FactoryShipmentStatus.DRAFT && shipment.status !== client_1.FactoryShipmentStatus.PICKING) {
            throw new common_1.BadRequestException('Эта отправка уже закрыта для сканирования.');
        }
        const barcode = dto.barcode.trim();
        const item = await this.prisma.factoryShipmentItem.findFirst({
            where: { shipmentId: id, OR: [{ barcode }, { sku: { barcodes: { some: { value: barcode } } } }] },
        });
        if (!item)
            throw new common_1.BadRequestException('Этот товар не входит в выбранную отправку.');
        const quantity = dto.quantity ?? 1;
        if (item.scannedQty + quantity > item.plannedQty)
            throw new common_1.BadRequestException('Плановое количество этого товара уже отсканировано.');
        await this.prisma.$transaction([
            this.prisma.factoryShipment.update({ where: { id }, data: { status: client_1.FactoryShipmentStatus.PICKING, startedAt: shipment.startedAt ?? new Date() } }),
            this.prisma.factoryShipmentItem.update({ where: { id: item.id }, data: { scannedQty: { increment: quantity } } }),
            this.prisma.factoryShipmentScan.create({ data: { shipmentId: id, itemId: item.id, barcode, quantity, deviceId: dto.deviceId, scannedById: user.id, scannedBy: user.name } }),
        ]);
        return this.get(id, user);
    }
    async ship(id, user) {
        const shipment = await this.get(id, user);
        this.scopes.requireClientAccess(user, shipment.clientId, 'write');
        if (shipment.items.every((item) => item.scannedQty === 0))
            throw new common_1.BadRequestException('В отправке ещё нет отсканированных товаров.');
        return this.prisma.factoryShipment.update({ where: { id }, data: { status: client_1.FactoryShipmentStatus.SHIPPED, shippedAt: new Date() }, include: shipmentInclude });
    }
    async reconcile(id, dto, user) {
        const shipment = await this.get(id, user);
        this.scopes.requireClientAccess(user, shipment.clientId, 'write');
        const request = await this.prisma.clientRequest.findFirst({
            where: { id: dto.requestId, clientId: shipment.clientId, type: 'INBOUND' }, include: { items: true },
        });
        if (!request)
            throw new common_1.BadRequestException('Приёмка этого клиента не найдена.');
        const received = new Map(request.items.map((item) => [item.skuId, item.quantity]));
        await this.prisma.$transaction([
            ...shipment.items.map((item) => this.prisma.factoryShipmentItem.update({ where: { id: item.id }, data: { receivedQty: received.get(item.skuId) ?? 0 } })),
            this.prisma.factoryShipment.update({ where: { id }, data: { receiptRequestId: request.id, receivedAt: new Date(), status: client_1.FactoryShipmentStatus.RECONCILED } }),
        ]);
        return this.get(id, user);
    }
};
exports.FactoryShipmentsService = FactoryShipmentsService;
exports.FactoryShipmentsService = FactoryShipmentsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService])
], FactoryShipmentsService);
