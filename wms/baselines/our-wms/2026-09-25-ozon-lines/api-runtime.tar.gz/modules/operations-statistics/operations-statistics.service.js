"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsStatisticsService = void 0;
exports.servicedBranch = servicedBranch;
exports.statisticsPeriod = statisticsPeriod;
exports.observation = observation;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const order_timing_1 = require("./order-timing");
const acceptance_1 = require("./acceptance");
const key = (marketplace, connectionId, orderId) => JSON.stringify([marketplace, connectionId, orderId]);
const DAY = 86_400_000;
// FIX: scope follows actual service routing, not a warehouse name or a stale request.
function servicedBranch(connection, warehouseId) {
    if (!warehouseId)
        return null;
    const route = connection.fbsWarehouseRoutes.find(r => r.marketplaceWarehouseId === warehouseId);
    if (route) {
        if (route.mode === 'BRANCH')
            return route.executionWarehouseId;
        if (route.mode === 'CENTRAL')
            return connection.fbsExecutionWarehouseId;
        return null; // EXCLUDED and unknown modes fail closed.
    }
    return warehouseId === connection.fbsWarehouseId || connection.fbsAutoRouteNewWarehouses
        ? connection.fbsExecutionWarehouseId : null;
}
function statisticsPeriod(from, to) {
    const start = new Date(`${from}T00:00:00+03:00`), end = new Date(`${to}T00:00:00+03:00`);
    const valid = (text, date) => /^\d{4}-\d{2}-\d{2}$/.test(text) && Number.isFinite(+date)
        && new Date(+date + 3 * 3_600_000).toISOString().slice(0, 10) === text;
    if (!valid(from, start) || !valid(to, end) || start > end || +end - +start >= 93 * DAY) {
        throw new common_1.BadRequestException('Выберите корректный период до 93 дней включительно.');
    }
    return { start, end: new Date(+end + DAY) };
}
function observation(placed, shipped, category, now) {
    if (category === 'cancelled')
        return { state: 'cancelled', elapsedMs: null };
    if (+placed > +now || (shipped && (+shipped < +placed || +shipped > +now)))
        return { state: 'unknown', elapsedMs: null };
    if (shipped)
        return { state: 'shipped', elapsedMs: +shipped - +placed };
    if (category === 'active')
        return { state: 'pending', elapsedMs: +now - +placed };
    return { state: 'unknown', elapsedMs: null };
}
let OperationsStatisticsService = class OperationsStatisticsService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    // FIX: share identical read scopes with the isolated reporting-cache refresh.
    async scope(filter, user) {
        if (user.isDemo)
            throw new common_1.ForbiddenException('Статистика доступна сотрудникам WMS и клиентам вне деморежима.');
        const period = statisticsPeriod(filter.dateFrom, filter.dateTo), now = new Date();
        // FIX: CLIENT never inherits global staff scope, even with ALL/system:admin.
        const isClient = user.roleCodes.includes('CLIENT');
        const ownClientIds = [...new Set((user.clientIds ?? []).filter(id => id && !(user.hiddenClientIds ?? []).includes(id)))];
        if (isClient && (!ownClientIds.length || (filter.clientId && !ownClientIds.includes(filter.clientId)))) {
            throw new common_1.ForbiddenException('Статистика этого клиента недоступна.');
        }
        const admin = user.permissionCodes.includes('system:admin');
        if (!isClient && filter.branchId && !admin && !(user.warehouseIds ?? []).includes(filter.branchId))
            throw new common_1.ForbiddenException('Филиал недоступен.');
        const clientFilter = isClient ? filter.clientId || { in: ownClientIds } : this.scopes.resolveClientFilter(user, filter.clientId);
        const connections = await this.prisma.clientMarketplaceConnection.findMany({ where: { clientId: clientFilter, client: { isDemo: false }, isActive: true,
                marketplace: filter.marketplace ?? { in: ['WILDBERRIES', 'OZON'] } },
            select: { id: true, clientId: true, marketplace: true, accountName: true, fbsWarehouseId: true, fbsWarehouseName: true,
                fbsExecutionWarehouseId: true, fbsAutoRouteNewWarehouses: true, client: { select: { name: true } },
                fbsWarehouseRoutes: { select: { marketplaceWarehouseId: true, marketplaceWarehouseName: true, mode: true, executionWarehouseId: true } } } });
        // FIX: clients need no staff warehouse grants; derive branches from their own service routes.
        const ownBranchIds = [...new Set(connections.flatMap(connection => [
                servicedBranch(connection, connection.fbsWarehouseId),
                ...(connection.fbsAutoRouteNewWarehouses ? [connection.fbsExecutionWarehouseId] : []),
                ...connection.fbsWarehouseRoutes.map(route => servicedBranch(connection, route.marketplaceWarehouseId)),
            ]).filter((id) => !!id))];
        if (isClient && filter.branchId && !ownBranchIds.includes(filter.branchId))
            throw new common_1.ForbiddenException('Филиал недоступен.');
        const branchFilter = filter.branchId ? { id: filter.branchId } : isClient ? { id: { in: ownBranchIds } }
            : admin ? {} : { id: { in: user.warehouseIds ?? [] } };
        const branches = await this.prisma.warehouse.findMany({ where: { ...branchFilter, isActive: true },
            select: { id: true, name: true }, orderBy: [{ sortOrder: 'asc' }, { code: 'asc' }] });
        return { branches, connections, period, now, clientFilter };
    }
    // FIX: read-only; electronic delivery timestamps never substitute marketplace scans.
    async report(filter, user) {
        const { branches, connections, period, now, clientFilter } = await this.scope(filter, user);
        const branchIds = branches.map(b => b.id), connectionIds = connections.map(c => c.id);
        const connectionById = new Map(connections.map(c => [c.id, c]));
        const groups = new Map(branches.map(b => [b.id, { ...b, orders: [], sellers: new Map() }]));
        const seller = (branchId, connectionId, warehouseId, name) => {
            const branch = groups.get(branchId), connection = connectionById.get(connectionId);
            if (!branch || !connection || !groups.has(servicedBranch(connection, warehouseId) ?? ''))
                return null;
            const id = JSON.stringify([connectionId, warehouseId]);
            if (!branch.sellers.has(id))
                branch.sellers.set(id, { id, name: name || (warehouseId ? `Склад ${warehouseId}` : 'Склад продавца не определён'),
                    clientName: connection.client.name, accountName: connection.accountName || '', marketplace: connection.marketplace, orders: [] });
            return branch.sellers.get(id);
        };
        for (const c of connections) {
            for (const r of c.fbsWarehouseRoutes)
                seller(servicedBranch(c, r.marketplaceWarehouseId) ?? '', c.id, r.marketplaceWarehouseId, r.marketplaceWarehouseName);
            if (c.fbsWarehouseId && !c.fbsWarehouseRoutes.some(r => r.marketplaceWarehouseId === c.fbsWarehouseId)) {
                seller(c.fbsExecutionWarehouseId ?? '', c.id, c.fbsWarehouseId, c.fbsWarehouseName);
            }
        }
        let cursor, missingOrderDate = 0, lastSyncedAt = null, oldestCheckedAt = null, uncheckedOrders = 0;
        const totals = [];
        for (;;) {
            const links = await this.prisma.fbsOrderRequestLink.findMany({ where: {
                    clientId: clientFilter, connectionId: { in: connectionIds },
                    request: { clientId: clientFilter, client: { isDemo: false }, warehouseId: { in: branchIds } },
                    OR: [{ orderPlacedAt: { gte: period.start, lt: period.end } }, { orderPlacedAt: null }],
                }, select: { id: true, marketplace: true, connectionId: true, orderId: true, clientId: true, orderPlacedAt: true, handedOverAt: true,
                    sellerWarehouseId: true, sellerWarehouseName: true, lastCategory: true, lastSupplierStatus: true, lastWbStatus: true, lastSupplyId: true, lastSeenAt: true, createdAt: true,
                    request: { select: { warehouseId: true } } }, orderBy: { id: 'asc' }, take: 500,
                ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}) });
            if (!links.length)
                break;
            const facts = await this.prisma.operationsStatisticsFact.findMany({ where: { clientId: clientFilter,
                    OR: links.map(l => ({ marketplace: l.marketplace, connectionId: l.connectionId, orderId: l.orderId })) } });
            const factByKey = new Map(facts.map(f => [key(f.marketplace, f.connectionId, f.orderId), f]));
            const events = links.some(l => !l.orderPlacedAt || !l.sellerWarehouseId) ? await this.prisma.fbsStockMonitorEvent.findMany({ where: { clientId: clientFilter, eventType: 'SALE',
                    OR: links.filter(l => !l.orderPlacedAt || !l.sellerWarehouseId).map(l => ({ marketplace: l.marketplace, connectionId: l.connectionId, orderId: l.orderId })) },
                select: { marketplace: true, connectionId: true, orderId: true, saleAt: true, marketplaceWarehouseId: true, marketplaceWarehouseName: true }, orderBy: { saleAt: 'asc' } }) : [];
            const origins = new Map();
            for (const event of events) {
                const k = key(event.marketplace, event.connectionId, event.orderId);
                if (!origins.has(k))
                    origins.set(k, event);
            }
            for (const link of links) {
                const k = key(link.marketplace, link.connectionId, link.orderId), origin = origins.get(k);
                const fact = factByKey.get(k);
                const warehouseId = fact?.sellerWarehouseId ?? link.sellerWarehouseId ?? origin?.marketplaceWarehouseId ?? null;
                const connection = connectionById.get(link.connectionId);
                if (!connection || !groups.has(servicedBranch(connection, warehouseId) ?? ''))
                    continue;
                // Ozon in_process_at is not the buyer's order creation time. Do not mix it into this KPI.
                const placed = fact?.orderPlacedAt ?? (link.marketplace === 'WILDBERRIES' ? link.orderPlacedAt ?? origin?.saleAt : null);
                // Unknown dates cannot be assigned to an order-date cohort. Report separately, never fabricate durations.
                if (!placed) {
                    missingOrderDate++;
                    continue;
                }
                if (placed < period.start || placed >= period.end)
                    continue;
                const newerLink = !!fact && !!link.lastSeenAt && link.lastSeenAt > fact.checkedAt;
                const supplyChanged = newerLink && link.lastSupplyId !== fact?.supplyId;
                const row = (0, acceptance_1.acceptanceObservation)(placed, {
                    supplierStatus: newerLink ? link.lastSupplierStatus : fact?.supplierStatus ?? link.lastSupplierStatus,
                    wbStatus: newerLink ? link.lastWbStatus : fact?.wbStatus ?? link.lastWbStatus,
                    requiresReshipment: fact?.requiresReshipment,
                    supplyScannedAt: supplyChanged ? null : fact?.supplyScannedAt,
                }, now);
                const branch = groups.get(link.request.warehouseId);
                if (!branch)
                    continue;
                // FIX: a fresh warehouse ID must never inherit another warehouse's stale label.
                const warehouseName = connection.fbsWarehouseRoutes.find(r => r.marketplaceWarehouseId === warehouseId)?.marketplaceWarehouseName
                    ?? (connection.fbsWarehouseId === warehouseId ? connection.fbsWarehouseName : null)
                    ?? (link.sellerWarehouseId === warehouseId ? link.sellerWarehouseName : null)
                    ?? (origin?.marketplaceWarehouseId === warehouseId ? origin.marketplaceWarehouseName : null);
                const s = seller(branch.id, link.connectionId, warehouseId, warehouseName);
                if (!s)
                    continue;
                branch.orders.push(row);
                s.orders.push(row);
                totals.push(row);
                if (!fact)
                    uncheckedOrders++;
                if (fact && (!oldestCheckedAt || fact.checkedAt < oldestCheckedAt))
                    oldestCheckedAt = fact.checkedAt;
                if (fact && (!lastSyncedAt || fact.checkedAt > lastSyncedAt))
                    lastSyncedAt = fact.checkedAt;
            }
            if (links.length < 500)
                break;
            cursor = links[links.length - 1].id;
        }
        return { period: { dateFrom: filter.dateFrom, dateTo: filter.dateTo, basis: 'order-created', timezone: 'Europe/Moscow' },
            generatedAt: now.toISOString(), lastSyncedAt: lastSyncedAt?.toISOString() ?? null, oldestCheckedAt: oldestCheckedAt?.toISOString() ?? null,
            uncheckedOrders, missingOrderDate, timingDefinition: 'marketplace-acceptance',
            summary: (0, order_timing_1.summarizeOrders)(totals), branches: [...groups.values()].filter(b => b.sellers.size > 0).map(b => ({ id: b.id, name: b.name, summary: (0, order_timing_1.summarizeOrders)(b.orders),
                warehouses: [...b.sellers.values()].map(({ orders, ...s }) => ({ ...s, summary: (0, order_timing_1.summarizeOrders)(orders) })) })) };
    }
};
exports.OperationsStatisticsService = OperationsStatisticsService;
exports.OperationsStatisticsService = OperationsStatisticsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(prisma_service_1.PrismaService)),
    __param(1, (0, common_1.Inject)(client_scope_service_1.ClientScopeService)),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], OperationsStatisticsService);
