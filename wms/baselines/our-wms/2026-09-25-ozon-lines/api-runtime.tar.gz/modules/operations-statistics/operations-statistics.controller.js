"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsStatisticsController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const operations_statistics_dto_1 = require("./operations-statistics.dto");
const operations_statistics_service_1 = require("./operations-statistics.service");
const statistics_refresh_service_1 = require("./statistics-refresh.service");
let OperationsStatisticsController = class OperationsStatisticsController {
    statistics;
    refresh;
    constructor(statistics, refresh) {
        this.statistics = statistics;
        this.refresh = refresh;
    }
    report(query, user) { return this.statistics.report(query, user); }
    // FIX: isolated report cache only; no shipment, inventory or assembly writes.
    start(query, user) { return this.refresh.start(query, user); }
    progress(id, user) { return this.refresh.progress(id, user); }
};
exports.OperationsStatisticsController = OperationsStatisticsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [operations_statistics_dto_1.OperationsStatisticsDto, Object]),
    __metadata("design:returntype", void 0)
], OperationsStatisticsController.prototype, "report", null);
__decorate([
    (0, common_1.Post)('refreshes'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [operations_statistics_dto_1.OperationsStatisticsDto, Object]),
    __metadata("design:returntype", void 0)
], OperationsStatisticsController.prototype, "start", null);
__decorate([
    (0, common_1.Get)('refreshes/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OperationsStatisticsController.prototype, "progress", null);
exports.OperationsStatisticsController = OperationsStatisticsController = __decorate([
    (0, common_1.Controller)('operations-statistics'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Inject)(operations_statistics_service_1.OperationsStatisticsService)),
    __param(1, (0, common_1.Inject)(statistics_refresh_service_1.StatisticsRefreshService)),
    __metadata("design:paramtypes", [operations_statistics_service_1.OperationsStatisticsService,
        statistics_refresh_service_1.StatisticsRefreshService])
], OperationsStatisticsController);
