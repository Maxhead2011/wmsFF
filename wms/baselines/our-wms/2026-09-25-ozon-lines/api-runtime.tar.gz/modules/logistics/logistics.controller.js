"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogisticsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const assign_delivery_trip_dto_1 = require("./dto/assign-delivery-trip.dto");
const create_delivery_request_dto_1 = require("./dto/create-delivery-request.dto");
const create_logistics_carrier_dto_1 = require("./dto/create-logistics-carrier.dto");
const create_logistics_trip_dto_1 = require("./dto/create-logistics-trip.dto");
const finalize_delivery_quote_dto_1 = require("./dto/finalize-delivery-quote.dto");
const list_delivery_requests_dto_1 = require("./dto/list-delivery-requests.dto");
const list_logistics_trips_dto_1 = require("./dto/list-logistics-trips.dto");
const quote_logistics_dto_1 = require("./dto/quote-logistics.dto");
const update_delivery_status_dto_1 = require("./dto/update-delivery-status.dto");
const update_logistics_trip_status_dto_1 = require("./dto/update-logistics-trip-status.dto");
const logistics_service_1 = require("./logistics.service");
let LogisticsController = class LogisticsController {
    logistics;
    constructor(logistics) {
        this.logistics = logistics;
    }
    listTariffSets() {
        return this.logistics.listTariffSets();
    }
    getTariffSet(id) {
        return this.logistics.getTariffSet(id);
    }
    listDestinationSuggestions(search, tariffSetId) {
        return this.logistics.listDestinationSuggestions({ search, tariffSetId });
    }
    quote(dto) {
        return this.logistics.quote(dto);
    }
    listCarriers(user) {
        return this.logistics.listCarriers(user);
    }
    createCarrier(dto, user) {
        return this.logistics.createCarrier(dto, user);
    }
    listTrips(query, user) {
        return this.logistics.listTrips(query, user);
    }
    createTrip(dto, user) {
        return this.logistics.createTrip(dto, user);
    }
    updateTripStatus(id, dto, user) {
        return this.logistics.updateTripStatus(id, dto, user);
    }
    listDeliveryRequests(query, user) {
        return this.logistics.listDeliveryRequests(query, user);
    }
    createDeliveryRequest(dto, user) {
        return this.logistics.createDeliveryRequest(dto, user);
    }
    updateDeliveryStatus(id, dto, user) {
        return this.logistics.updateDeliveryStatus(id, dto, user);
    }
    finalizeDeliveryQuote(id, dto, user) {
        return this.logistics.finalizeDeliveryQuote(id, dto, user);
    }
    generateDeliveryBillingCharge(id, user) {
        return this.logistics.generateDeliveryBillingCharge(id, user);
    }
    assignDeliveryTrip(id, dto, user) {
        return this.logistics.assignDeliveryTrip(id, dto, user);
    }
};
exports.LogisticsController = LogisticsController;
__decorate([
    (0, common_1.Get)('tariff-sets'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "listTariffSets", null);
__decorate([
    (0, common_1.Get)('tariff-sets/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "getTariffSet", null);
__decorate([
    (0, common_1.Get)('destinations'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Query)('search')),
    __param(1, (0, common_1.Query)('tariffSetId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "listDestinationSuggestions", null);
__decorate([
    (0, common_1.Post)('quote'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [quote_logistics_dto_1.QuoteLogisticsDto]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "quote", null);
__decorate([
    (0, common_1.Get)('carriers'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "listCarriers", null);
__decorate([
    (0, common_1.Post)('carriers'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_logistics_carrier_dto_1.CreateLogisticsCarrierDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "createCarrier", null);
__decorate([
    (0, common_1.Get)('trips'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_logistics_trips_dto_1.ListLogisticsTripsDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "listTrips", null);
__decorate([
    (0, common_1.Post)('trips'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_logistics_trip_dto_1.CreateLogisticsTripDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "createTrip", null);
__decorate([
    (0, common_1.Patch)('trips/:id/status'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_logistics_trip_status_dto_1.UpdateLogisticsTripStatusDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "updateTripStatus", null);
__decorate([
    (0, common_1.Get)('delivery-requests'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_delivery_requests_dto_1.ListDeliveryRequestsDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "listDeliveryRequests", null);
__decorate([
    (0, common_1.Post)('delivery-requests'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:request'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_delivery_request_dto_1.CreateDeliveryRequestDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "createDeliveryRequest", null);
__decorate([
    (0, common_1.Patch)('delivery-requests/:id/status'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_delivery_status_dto_1.UpdateDeliveryStatusDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "updateDeliveryStatus", null);
__decorate([
    (0, common_1.Patch)('delivery-requests/:id/quote'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, finalize_delivery_quote_dto_1.FinalizeDeliveryQuoteDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "finalizeDeliveryQuote", null);
__decorate([
    (0, common_1.Post)('delivery-requests/:id/billing-charge'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write', 'billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "generateDeliveryBillingCharge", null);
__decorate([
    (0, common_1.Patch)('delivery-requests/:id/trip'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, assign_delivery_trip_dto_1.AssignDeliveryTripDto, Object]),
    __metadata("design:returntype", void 0)
], LogisticsController.prototype, "assignDeliveryTrip", null);
exports.LogisticsController = LogisticsController = __decorate([
    (0, swagger_1.ApiTags)('logistics'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:read'),
    (0, common_1.Controller)('logistics'),
    __metadata("design:paramtypes", [logistics_service_1.LogisticsService])
], LogisticsController);
