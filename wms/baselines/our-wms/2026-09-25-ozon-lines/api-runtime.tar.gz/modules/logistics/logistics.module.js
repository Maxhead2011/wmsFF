"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogisticsModule = void 0;
const common_1 = require("@nestjs/common");
const common_module_1 = require("../../common/common.module");
const auth_module_1 = require("../auth/auth.module");
const client_notifications_module_1 = require("../client-notifications/client-notifications.module");
const logistics_controller_1 = require("./logistics.controller");
const logistics_service_1 = require("./logistics.service");
let LogisticsModule = class LogisticsModule {
};
exports.LogisticsModule = LogisticsModule;
exports.LogisticsModule = LogisticsModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, common_module_1.CommonModule, client_notifications_module_1.ClientNotificationsModule],
        controllers: [logistics_controller_1.LogisticsController],
        providers: [logistics_service_1.LogisticsService],
        exports: [logistics_service_1.LogisticsService],
    })
], LogisticsModule);
