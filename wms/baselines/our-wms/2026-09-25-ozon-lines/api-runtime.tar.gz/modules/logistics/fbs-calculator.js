"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FBS_KAVKAZ = exports.FBS_VNUKOVO = void 0;
exports.calculateFbsBoxes = calculateFbsBoxes;
exports.quoteFixedFbsCalculator = quoteFixedFbsCalculator;
exports.buildFbsCalculatorTotal = buildFbsCalculatorTotal;
const fbs_constants_1 = require("../marketplace-connections/fbs.constants");
exports.FBS_VNUKOVO = 'Внуково';
exports.FBS_KAVKAZ = 'Кавказский Бульвар';
const FBS_BOXES_PER_PALLET = 16;
const FBS_FIXED_DELIVERY_LIMIT = 1000;
function calculateFbsBoxes(quantity) {
    return Math.ceil(quantity / fbs_constants_1.DEFAULT_FBS_ITEMS_PER_CARGO_PLACE);
}
function quoteFixedFbsCalculator(quantityValue, destination) {
    const quantity = Math.max(1, Math.trunc(quantityValue));
    const boxes = calculateFbsBoxes(quantity);
    const deliveryPrice = calculateSpecialFbsDelivery(destination, quantity, boxes);
    return deliveryPrice == null
        ? null
        : buildFbsCalculatorTotal(quantity, boxes, destination, deliveryPrice);
}
function buildFbsCalculatorTotal(quantity, boxes, destination, deliveryPrice) {
    const processingCost = quantity * 10;
    const stickersCost = quantity * 3;
    const boxesCost = boxes * 100;
    const assemblyCost = boxes * 40;
    const servicesWithMarkup = round((processingCost + stickersCost + boxesCost + assemblyCost) * 1.5, 2);
    const subtotalBeforeTax = round(servicesWithMarkup + deliveryPrice, 2);
    const totalWithTax = round((subtotalBeforeTax / 94) * 100, 2);
    return {
        destination,
        quantity,
        boxes,
        processingCost,
        stickersCost,
        boxesCost,
        assemblyCost,
        servicesWithMarkup,
        deliveryPrice,
        subtotalBeforeTax,
        taxGrossUp: round(totalWithTax - subtotalBeforeTax, 2),
        totalWithTax,
        requiresManualReview: false,
    };
}
function calculateSpecialFbsDelivery(destination, quantity, boxes) {
    const normalized = destination.toLocaleLowerCase('ru-RU').replace(/ё/g, 'е').trim();
    const isVnukovo = normalized.includes('внуково');
    const isKavkaz = normalized.includes('кавказ');
    if (!isVnukovo && !isKavkaz)
        return null;
    if (quantity <= FBS_FIXED_DELIVERY_LIMIT) {
        return isVnukovo ? 1500 : 3000;
    }
    const pallets = Math.ceil(boxes / FBS_BOXES_PER_PALLET);
    if (isVnukovo) {
        return pallets * (pallets <= 2 ? 1500 : 1200);
    }
    const pricePerPallet = pallets === 1
        ? 3500
        : pallets === 2
            ? 3000
            : pallets === 3
                ? 2800
                : pallets === 4
                    ? 2500
                    : pallets === 5
                        ? 2300
                        : pallets === 6
                            ? 2200
                            : 2000;
    return pallets * pricePerPallet;
}
function round(value, digits) {
    const factor = 10 ** digits;
    return Math.round(value * factor) / factor;
}
