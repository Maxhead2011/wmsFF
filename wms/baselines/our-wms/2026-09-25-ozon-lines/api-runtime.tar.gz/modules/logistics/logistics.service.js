"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogisticsService = void 0;
exports.calculateLogisticsPalletCount = calculateLogisticsPalletCount;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_notification_preferences_1 = require("../client-notifications/client-notification-preferences");
const telegram_notification_service_1 = require("../client-notifications/telegram-notification.service");
const fbs_calculator_1 = require("./fbs-calculator");
const DEFAULT_LOGISTICS_ORIGIN = 'Москва';
const MAX_BOXES_FOR_BOX_TARIFF = 10;
const BOXES_PER_PALLET = 16;
const EXTRA_BOXES_PER_PALLET = 4;
let LogisticsService = class LogisticsService {
    prisma;
    clientScopes;
    telegram;
    constructor(prisma, clientScopes, telegram) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.telegram = telegram;
    }
    listTariffSets() {
        return this.prisma.logisticsTariffSet.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                _count: { select: { directions: true } },
            },
        });
    }
    getTariffSet(id) {
        return this.prisma.logisticsTariffSet.findUniqueOrThrow({
            where: { id },
            include: {
                _count: { select: { directions: true } },
                directions: {
                    orderBy: [{ origin: 'asc' }, { destination: 'asc' }],
                    include: { tiers: { orderBy: [{ maxBoxes: 'asc' }, { minPallets: 'asc' }] } },
                },
            },
        });
    }
    async listDestinationSuggestions(filter) {
        const search = normalizeText(filter.search);
        const tariffSetId = normalizeText(filter.tariffSetId);
        const directions = await this.prisma.logisticsDirection.findMany({
            where: {
                ...(tariffSetId ? { tariffSetId } : {}),
                ...(search
                    ? {
                        OR: [
                            { destination: { contains: search, mode: 'insensitive' } },
                            { origin: { contains: search, mode: 'insensitive' } },
                        ],
                    }
                    : {}),
            },
            include: {
                tariffSet: {
                    select: {
                        id: true,
                        name: true,
                        sourceFile: true,
                    },
                },
            },
            orderBy: [{ destination: 'asc' }, { origin: 'asc' }],
            take: 200,
        });
        const unique = new Map();
        directions.forEach((direction) => {
            const key = [direction.tariffSetId, this.normalizePoint(direction.origin), this.normalizePoint(direction.destination)].join('|');
            if (!unique.has(key)) {
                unique.set(key, direction);
            }
        });
        return [...unique.values()].slice(0, 50).map((direction) => ({
            value: direction.destination,
            label: direction.destination,
            description: `${direction.origin} -> ${direction.destination} · ${direction.tariffSet.name}`,
            origin: direction.origin,
            destination: direction.destination,
            tariffSetId: direction.tariffSet.id,
            tariffSetName: direction.tariffSet.name,
            sourceFile: direction.tariffSet.sourceFile,
        }));
    }
    async commitTariffSet(parsed, options) {
        if (parsed.issues.length > 0) {
            throw new common_1.BadRequestException({
                message: 'Файл содержит ошибки, импорт тарифов логистики остановлен.',
                issues: parsed.issues,
            });
        }
        const directions = parsed.directions.filter((direction) => direction.tiers.length > 0);
        if (directions.length === 0) {
            throw new common_1.BadRequestException('В файле не найдено ни одного направления с тарифами.');
        }
        return this.prisma.logisticsTariffSet.create({
            data: {
                name: options.name,
                sourceFile: options.sourceFile,
                note: parsed.note || null,
                activeFrom: this.parseDate(options.activeFrom),
                activeTo: this.parseDate(options.activeTo),
                directions: {
                    create: directions.map((direction) => ({
                        origin: direction.origin,
                        destination: direction.destination,
                        note: parsed.note || null,
                        pricingMode: direction.pricingMode,
                        tiers: {
                            create: direction.tiers.map((tier) => ({
                                label: tier.label,
                                minPallets: tier.minPallets,
                                maxPallets: tier.maxPallets,
                                maxBoxes: tier.maxBoxes,
                                pricingMode: tier.pricingMode,
                                priceRub: tier.priceRub,
                            })),
                        },
                    })),
                },
            },
            include: {
                directions: {
                    include: { tiers: true },
                },
            },
        });
    }
    async quote(dto) {
        if (Boolean(dto.boxes) === Boolean(dto.pallets)) {
            throw new common_1.BadRequestException('Для расчета передайте ровно одно значение: boxes или pallets.');
        }
        const quoteDate = dto.quoteDate ? new Date(dto.quoteDate) : new Date();
        const tariffSet = dto.tariffSetId
            ? await this.prisma.logisticsTariffSet.findUnique({ where: { id: dto.tariffSetId } })
            : await this.findActiveTariffSet(quoteDate);
        if (!tariffSet) {
            throw new common_1.NotFoundException('Активный набор тарифов логистики не найден.');
        }
        const directions = await this.prisma.logisticsDirection.findMany({
            where: { tariffSetId: tariffSet.id },
            include: { tiers: true },
        });
        const direction = this.findTariffDirection(directions.filter((item) => this.normalizePoint(item.origin) === this.normalizePoint(DEFAULT_LOGISTICS_ORIGIN)), dto.destination);
        if (!direction) {
            throw new common_1.NotFoundException('Направление логистики не найдено в выбранном наборе тарифов.');
        }
        const pricingInput = dto.boxes != null && dto.boxes > MAX_BOXES_FOR_BOX_TARIFF
            ? { boxes: undefined, pallets: calculateLogisticsPalletCount(dto.boxes) }
            : { boxes: dto.boxes, pallets: dto.pallets };
        const tier = this.selectRateTier(direction.tiers, pricingInput);
        const estimatedTotalRub = this.calculateQuoteTotal(tier, pricingInput.pallets);
        return {
            tariffSet: {
                id: tariffSet.id,
                name: tariffSet.name,
                sourceFile: tariffSet.sourceFile,
            },
            route: {
                origin: DEFAULT_LOGISTICS_ORIGIN,
                destination: direction.destination,
            },
            input: {
                boxes: pricingInput.boxes ?? null,
                pallets: pricingInput.pallets ?? null,
            },
            tier: this.serializeTier(tier),
            estimatedTotalRub,
            requiresManualReview: tier.pricingMode === client_1.LogisticsPricingMode.MANUAL_REVIEW,
            note: tier.pricingMode === client_1.LogisticsPricingMode.MANUAL_REVIEW ? direction.note : tariffSet.note,
        };
    }
    async listFbsCalculatorDestinations() {
        const tariffSet = await this.findActiveTariffSet(new Date());
        if (!tariffSet) {
            throw new common_1.NotFoundException('Активный набор тарифов логистики не найден.');
        }
        const directions = await this.prisma.logisticsDirection.findMany({
            where: {
                tariffSetId: tariffSet.id,
                origin: { equals: DEFAULT_LOGISTICS_ORIGIN, mode: 'insensitive' },
            },
            select: { destination: true },
            orderBy: { destination: 'asc' },
        });
        const unique = new Map();
        directions.forEach((direction) => {
            const destination = direction.destination.trim();
            const key = this.normalizePoint(destination);
            if (destination && !unique.has(key)) {
                unique.set(key, destination);
            }
        });
        [fbs_calculator_1.FBS_VNUKOVO, fbs_calculator_1.FBS_KAVKAZ].forEach((destination) => unique.set(this.normalizePoint(destination), destination));
        const destinations = [...unique.values()].sort((left, right) => left.localeCompare(right, 'ru'));
        return { destinations };
    }
    async quoteFbsCalculator(dto) {
        const boxes = (0, fbs_calculator_1.calculateFbsBoxes)(dto.quantity);
        const fixedQuote = (0, fbs_calculator_1.quoteFixedFbsCalculator)(dto.quantity, dto.destination);
        if (fixedQuote) {
            return {
                destination: fixedQuote.destination,
                totalWithTax: fixedQuote.totalWithTax,
                requiresManualReview: false,
            };
        }
        const logistics = await this.quote({
            destination: dto.destination,
            boxes,
        });
        if (logistics.estimatedTotalRub == null) {
            return {
                destination: logistics.route.destination,
                totalWithTax: null,
                requiresManualReview: true,
            };
        }
        const quote = (0, fbs_calculator_1.buildFbsCalculatorTotal)(dto.quantity, boxes, logistics.route.destination, logistics.estimatedTotalRub);
        return {
            destination: quote.destination,
            totalWithTax: quote.totalWithTax,
            requiresManualReview: false,
        };
    }
    listCarriers(user) {
        const warehouseId = this.scopedWarehouseId(user, 'read');
        return this.prisma.logisticsCarrier.findMany({
            where: { isActive: true },
            include: {
                _count: {
                    select: {
                        trips: warehouseId
                            ? { where: { deliveries: { some: { warehouseId } } } }
                            : true,
                    },
                },
            },
            orderBy: [{ name: 'asc' }],
        });
    }
    createCarrier(dto, user) {
        this.requireNetworkLogisticsWrite(user);
        const name = normalizeRequiredText(dto.name, 'Название перевозчика обязательно.');
        return this.prisma.logisticsCarrier.create({
            data: {
                name,
                phone: normalizeText(dto.phone),
                contactName: normalizeText(dto.contactName),
                comment: normalizeText(dto.comment),
            },
            include: {
                _count: { select: { trips: true } },
            },
        });
    }
    listTrips(query, user) {
        const warehouseId = this.scopedWarehouseId(user, 'read');
        return this.prisma.logisticsTrip.findMany({
            where: {
                carrierId: query.carrierId,
                status: query.status,
                deliveries: warehouseId ? { some: { warehouseId } } : undefined,
            },
            include: warehouseId
                ? {
                    ...logisticsTripInclude,
                    deliveries: {
                        ...logisticsTripInclude.deliveries,
                        where: { warehouseId },
                    },
                }
                : logisticsTripInclude,
            orderBy: [{ plannedDate: 'desc' }, { createdAt: 'desc' }],
            take: 200,
        });
    }
    async createTrip(dto, user) {
        this.requireNetworkLogisticsWrite(user);
        const carrierId = normalizeText(dto.carrierId);
        const plannedDate = this.parseDate(dto.plannedDate);
        if (carrierId) {
            const carrier = await this.prisma.logisticsCarrier.findFirst({
                where: { id: carrierId, isActive: true },
                select: { id: true },
            });
            if (!carrier) {
                throw new common_1.BadRequestException('Перевозчик не найден или отключен.');
            }
        }
        return this.prisma.logisticsTrip.create({
            data: {
                code: normalizeText(dto.code) ?? (await this.generateTripCode(plannedDate)),
                carrierId,
                plannedDate,
                vehicleNumber: normalizeText(dto.vehicleNumber),
                driverName: normalizeText(dto.driverName),
                driverPhone: normalizeText(dto.driverPhone),
                comment: normalizeText(dto.comment),
            },
            include: logisticsTripInclude,
        });
    }
    async updateTripStatus(id, dto, user) {
        this.requireNetworkLogisticsWrite(user);
        const trip = await this.prisma.logisticsTrip.findUnique({
            where: { id },
            select: { id: true },
        });
        if (!trip) {
            throw new common_1.NotFoundException('Рейс доставки не найден.');
        }
        return this.prisma.logisticsTrip.update({
            where: { id },
            data: {
                status: dto.status,
                comment: normalizeText(dto.comment),
            },
            include: logisticsTripInclude,
        });
    }
    listDeliveryRequests(query, user) {
        const warehouseId = this.scopedWarehouseId(user, 'read');
        return this.prisma.logisticsDeliveryRequest.findMany({
            where: {
                clientId: this.clientScopes.resolveClientFilter(user, query.clientId),
                warehouseId: warehouseId ?? undefined,
                status: query.status,
            },
            include: deliveryRequestInclude,
            orderBy: [{ updatedAt: 'desc' }],
            take: 200,
        });
    }
    async createDeliveryRequest(dto, user) {
        this.clientScopes.requireClientAccess(user, dto.clientId, 'write');
        const clientRequest = dto.requestId
            ? await this.prisma.clientRequest.findFirst({
                where: {
                    id: dto.requestId,
                    clientId: dto.clientId,
                },
                select: {
                    warehouseId: true,
                    packages: {
                        select: {
                            packageType: true,
                        },
                    },
                },
            })
            : null;
        if (dto.requestId && !clientRequest) {
            throw new common_1.BadRequestException('Связанная клиентская заявка не найдена у выбранного клиента.');
        }
        const warehouseId = await this.resolveDeliveryWarehouseId(user, dto.clientId, clientRequest?.warehouseId ?? null);
        const actualQuantity = this.resolveDeliveryQuantity(dto, clientRequest?.packages ?? []);
        const quote = await this.tryQuoteForDelivery({
            ...dto,
            boxes: actualQuantity.quoteBoxes,
            pallets: actualQuantity.quotePallets,
        });
        const status = quote.estimatedTotalRub != null && !quote.requiresManualReview
            ? client_1.LogisticsDeliveryStatus.QUOTED
            : client_1.LogisticsDeliveryStatus.REQUESTED;
        // Русский комментарий: заявку создаем даже при ручном тарифе, чтобы менеджер не терял обращение клиента.
        return this.prisma.logisticsDeliveryRequest.create({
            data: {
                clientId: dto.clientId,
                warehouseId,
                requestId: dto.requestId,
                tariffSetId: quote.tariffSetId ?? dto.tariffSetId,
                origin: DEFAULT_LOGISTICS_ORIGIN,
                destination: dto.destination.trim(),
                boxes: actualQuantity.boxes,
                pallets: actualQuantity.pallets,
                desiredShipDate: this.parseDate(dto.desiredShipDate),
                status,
                estimatedTotalRub: quote.estimatedTotalRub,
                requiresManualReview: quote.requiresManualReview,
                comment: normalizeText(dto.comment),
                managerComment: quote.note,
                createdByUserId: user.id,
            },
            include: deliveryRequestInclude,
        });
    }
    async ensurePackedRequestBilling(requestId, user) {
        const clientRequest = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: {
                id: true,
                clientId: true,
                warehouseId: true,
                title: true,
                destinationCity: true,
                desiredDate: true,
            },
        });
        if (!clientRequest) {
            throw new common_1.NotFoundException('Клиентская заявка не найдена.');
        }
        this.clientScopes.requireClientAccess(user, clientRequest.clientId, 'write');
        this.requireDeliveryWarehouseAccess(user, clientRequest.warehouseId, 'write');
        const destination = normalizeText(clientRequest.destinationCity ?? undefined);
        if (!destination) {
            return { status: 'REQUIRES_DESTINATION', deliveryRequest: null };
        }
        let deliveryRequest = await this.prisma.logisticsDeliveryRequest.findFirst({
            where: {
                requestId,
                warehouseId: clientRequest.warehouseId,
                status: { not: client_1.LogisticsDeliveryStatus.CANCELLED },
            },
            include: deliveryRequestInclude,
            orderBy: { createdAt: 'desc' },
        });
        if (!deliveryRequest) {
            deliveryRequest = await this.createDeliveryRequest({
                clientId: clientRequest.clientId,
                requestId,
                destination,
                desiredShipDate: clientRequest.desiredDate?.toISOString(),
                comment: `Автоматически создано после упаковки заявки ${clientRequest.title}.`,
            }, user);
        }
        if (!deliveryRequest.billingChargeId) {
            deliveryRequest = await this.generateDeliveryBillingCharge(deliveryRequest.id, user);
        }
        return {
            status: deliveryRequest.requiresManualReview ? 'PRICE_REVIEW' : 'READY',
            deliveryRequest,
        };
    }
    async assignDeliveryTrip(id, dto, user) {
        const request = await this.prisma.logisticsDeliveryRequest.findUnique({
            where: { id },
            select: {
                id: true,
                clientId: true,
                warehouseId: true,
                status: true,
                plannedShipDate: true,
            },
        });
        if (!request) {
            throw new common_1.NotFoundException('Заявка на доставку не найдена.');
        }
        this.clientScopes.requireClientAccess(user, request.clientId, 'write');
        this.requireDeliveryWarehouseAccess(user, request.warehouseId, 'write');
        const tripId = normalizeText(dto.tripId ?? undefined);
        if (!tripId) {
            return this.prisma.logisticsDeliveryRequest.update({
                where: { id },
                data: { tripId: null },
                include: deliveryRequestInclude,
            });
        }
        const trip = await this.prisma.logisticsTrip.findUnique({
            where: { id: tripId },
            select: {
                id: true,
                status: true,
                plannedDate: true,
            },
        });
        if (!trip) {
            throw new common_1.NotFoundException('Рейс доставки не найден.');
        }
        if (trip.status === client_1.LogisticsTripStatus.COMPLETED || trip.status === client_1.LogisticsTripStatus.CANCELLED) {
            throw new common_1.BadRequestException('Нельзя назначить доставку в завершенный или отмененный рейс.');
        }
        const nextStatus = request.status === client_1.LogisticsDeliveryStatus.REQUESTED || request.status === client_1.LogisticsDeliveryStatus.QUOTED
            ? client_1.LogisticsDeliveryStatus.PLANNED
            : request.status;
        const data = {
            trip: { connect: { id: trip.id } },
            status: nextStatus,
        };
        if (!request.plannedShipDate && trip.plannedDate) {
            data.plannedShipDate = trip.plannedDate;
        }
        // Русский комментарий: назначение на рейс переводит заявку в операционный план без ручной смены статуса менеджером.
        return this.prisma.logisticsDeliveryRequest.update({
            where: { id },
            data,
            include: deliveryRequestInclude,
        });
    }
    async updateDeliveryStatus(id, dto, user) {
        const request = await this.prisma.logisticsDeliveryRequest.findUnique({
            where: { id },
            select: {
                id: true,
                clientId: true,
                warehouseId: true,
                status: true,
                origin: true,
                destination: true,
            },
        });
        if (!request) {
            throw new common_1.NotFoundException('Заявка на доставку не найдена.');
        }
        this.clientScopes.requireClientAccess(user, request.clientId, 'write');
        this.requireDeliveryWarehouseAccess(user, request.warehouseId, 'write');
        const notifyClient = request.status !== dto.status &&
            (await (0, client_notification_preferences_1.isClientNotificationEnabled)(this.prisma, request.clientId, client_1.ClientNotificationEvent.LOGISTICS_DELIVERY_STATUS_CHANGED));
        const updated = await this.prisma.$transaction(async (tx) => {
            const updated = await tx.logisticsDeliveryRequest.update({
                where: { id },
                data: {
                    status: dto.status,
                    plannedShipDate: this.parseDate(dto.plannedShipDate),
                    managerComment: normalizeText(dto.managerComment),
                },
                include: deliveryRequestInclude,
            });
            if (notifyClient) {
                await tx.clientNotification.create({
                    data: {
                        clientId: request.clientId,
                        requestId: updated.requestId,
                        title: 'Статус доставки изменен',
                        body: `${request.origin} -> ${request.destination}: ${deliveryStatusLabel(request.status)} -> ${deliveryStatusLabel(dto.status)}`,
                        severity: dto.status === client_1.LogisticsDeliveryStatus.DELIVERED ? 'SUCCESS' : 'INFO',
                        createdByUserId: user.id,
                    },
                });
            }
            return updated;
        });
        if (notifyClient) {
            void this.telegram?.notifyClient(request.clientId, [
                'LOGOFF WMS: изменен статус доставки.',
                `${request.origin} -> ${request.destination}`,
                `Статус: ${deliveryStatusLabel(request.status)} -> ${deliveryStatusLabel(dto.status)}`,
            ].join('\n'));
        }
        return updated;
    }
    async finalizeDeliveryQuote(id, dto, user) {
        const request = await this.prisma.logisticsDeliveryRequest.findUnique({
            where: { id },
            select: {
                id: true,
                clientId: true,
                warehouseId: true,
                status: true,
                billingChargeId: true,
            },
        });
        if (!request) {
            throw new common_1.NotFoundException('Заявка на доставку не найдена.');
        }
        this.clientScopes.requireClientAccess(user, request.clientId, 'write');
        this.requireDeliveryWarehouseAccess(user, request.warehouseId, 'write');
        if (request.billingChargeId) {
            throw new common_1.BadRequestException('Доставка уже связана с начислением, сумму нельзя менять.');
        }
        if (request.status === client_1.LogisticsDeliveryStatus.CANCELLED) {
            throw new common_1.BadRequestException('Нельзя финализировать расчет отмененной доставки.');
        }
        const nextStatus = request.status === client_1.LogisticsDeliveryStatus.REQUESTED ? client_1.LogisticsDeliveryStatus.QUOTED : request.status;
        // Русский комментарий: ручная финализация снимает флаг проверки и открывает доставку для дальнейшего workflow/биллинга.
        return this.prisma.logisticsDeliveryRequest.update({
            where: { id },
            data: {
                estimatedTotalRub: dto.estimatedTotalRub,
                requiresManualReview: false,
                status: nextStatus,
                managerComment: normalizeText(dto.managerComment),
            },
            include: deliveryRequestInclude,
        });
    }
    async generateDeliveryBillingCharge(id, user) {
        const request = await this.prisma.logisticsDeliveryRequest.findUnique({
            where: { id },
            include: {
                client: { select: { id: true, code: true, name: true } },
                request: { select: { id: true, title: true } },
                tariffSet: { select: { id: true, name: true } },
                billingCharge: { select: { id: true } },
            },
        });
        if (!request) {
            throw new common_1.NotFoundException('Заявка на доставку не найдена.');
        }
        this.clientScopes.requireClientAccess(user, request.clientId, 'write');
        this.requireDeliveryWarehouseAccess(user, request.warehouseId, 'write');
        if (request.billingChargeId) {
            return this.prisma.logisticsDeliveryRequest.findUniqueOrThrow({
                where: { id },
                include: deliveryRequestInclude,
            });
        }
        if (request.status === client_1.LogisticsDeliveryStatus.CANCELLED) {
            throw new common_1.BadRequestException('Нельзя создать начисление для отмененной доставки.');
        }
        const sourceKey = deliverySourceKey(request.id);
        const quotedTotalRub = Number(request.estimatedTotalRub);
        const priceRequiresConfirmation = request.requiresManualReview || request.estimatedTotalRub == null || !Number.isFinite(quotedTotalRub) || quotedTotalRub <= 0;
        const totalRub = priceRequiresConfirmation ? 0 : quotedTotalRub;
        return this.prisma.$transaction(async (tx) => {
            const existingCharge = await tx.billingCharge.findFirst({
                where: { sourceKey },
                select: { id: true },
            });
            const charge = existingCharge ??
                (await tx.billingCharge.create({
                    data: {
                        clientId: request.clientId,
                        serviceId: (await ensureDeliveryBillingService(tx)).id,
                        requestId: request.requestId,
                        description: `Доставка ${request.origin} -> ${request.destination}${priceRequiresConfirmation ? ' (цена требует согласования)' : ''}`,
                        unit: client_1.BillingUnit.SERVICE,
                        quantity: 1,
                        unitPriceRub: totalRub,
                        totalRub,
                        status: client_1.BillingChargeStatus.APPROVED,
                        serviceDate: request.plannedShipDate ?? request.desiredShipDate ?? new Date(),
                        source: client_1.BillingChargeSource.LOGISTICS,
                        sourceKey,
                        metadata: {
                            deliveryRequestId: request.id,
                            route: {
                                origin: request.origin,
                                destination: request.destination,
                            },
                            boxes: request.boxes,
                            pallets: request.pallets,
                            tariffSetId: request.tariffSetId,
                            tariffSetName: request.tariffSet?.name ?? null,
                            clientRequestId: request.requestId,
                            priceRequiresConfirmation,
                        },
                        comment: request.managerComment ??
                            request.comment ??
                            (priceRequiresConfirmation ? 'Тариф не найден. Укажите цену в черновом счете перед выставлением.' : null),
                        createdByUserId: user.id,
                        approvedByUserId: user.id,
                        approvedAt: new Date(),
                    },
                    select: { id: true },
                }));
            // Русский комментарий: связь хранится в заявке, чтобы в логистике сразу было видно, что доставка уже ушла в биллинг.
            return tx.logisticsDeliveryRequest.update({
                where: { id: request.id },
                data: { billingChargeId: charge.id },
                include: deliveryRequestInclude,
            });
        });
    }
    scopedWarehouseId(user, mode) {
        if (user.permissionCodes?.includes('system:admin') ||
            user.roleCodes?.includes('CLIENT') ||
            (user.warehouseIds?.length ?? 0) === 0) {
            return null;
        }
        const warehouseId = user.activeWarehouseId?.trim() ?? '';
        const allowedIds = mode === 'write' ? user.writableWarehouseIds : user.warehouseIds;
        if (!warehouseId || !allowedIds?.includes(warehouseId)) {
            throw new common_1.ForbiddenException('Нет доступа к логистике выбранного филиала.');
        }
        return warehouseId;
    }
    requireNetworkLogisticsWrite(user) {
        if (!user.permissionCodes?.includes('system:admin') &&
            !user.roleCodes?.includes('CLIENT') &&
            (user.warehouseIds?.length ?? 0) > 0) {
            throw new common_1.ForbiddenException('Общие рейсы и перевозчиков изменяет только администратор сети.');
        }
    }
    requireDeliveryWarehouseAccess(user, warehouseId, mode) {
        const scopedWarehouseId = this.scopedWarehouseId(user, mode);
        if (scopedWarehouseId && warehouseId !== scopedWarehouseId) {
            throw new common_1.NotFoundException('Заявка на доставку не найдена в выбранном филиале.');
        }
    }
    async resolveDeliveryWarehouseId(user, clientId, requestWarehouseId) {
        const scopedWarehouseId = this.scopedWarehouseId(user, 'write');
        if (scopedWarehouseId) {
            if (requestWarehouseId && requestWarehouseId !== scopedWarehouseId) {
                throw new common_1.NotFoundException('Связанная заявка не относится к выбранному филиалу.');
            }
            const link = await this.prisma.warehouseClient.findFirst({
                where: {
                    warehouseId: scopedWarehouseId,
                    clientId,
                    status: 'ACTIVE',
                },
                select: { clientId: true },
            });
            if (!link) {
                throw new common_1.ForbiddenException('Клиент не закреплён за выбранным филиалом.');
            }
            return scopedWarehouseId;
        }
        if (requestWarehouseId)
            return requestWarehouseId;
        const activeWarehouseId = user.activeWarehouseId?.trim();
        if (activeWarehouseId)
            return activeWarehouseId;
        const links = await this.prisma.warehouseClient.findMany({
            where: { clientId, status: 'ACTIVE', warehouse: { isActive: true } },
            select: { warehouseId: true },
            take: 2,
        });
        if (links.length === 1)
            return links[0].warehouseId;
        throw new common_1.BadRequestException('Не удалось однозначно определить филиал доставки. Выберите филиал или свяжите доставку с заявкой.');
    }
    selectRateTier(tiers, input) {
        if (input.boxes != null) {
            const candidates = tiers
                .filter((tier) => tier.maxBoxes != null && input.boxes != null && input.boxes <= tier.maxBoxes)
                .sort((left, right) => (left.maxBoxes ?? Number.MAX_SAFE_INTEGER) - (right.maxBoxes ?? Number.MAX_SAFE_INTEGER));
            if (candidates[0]) {
                return candidates[0];
            }
        }
        if (input.pallets != null) {
            const candidates = tiers
                .filter((tier) => this.isPalletTierMatch(tier, input.pallets))
                .sort((left, right) => this.palletTierRank(right) - this.palletTierRank(left));
            if (candidates[0]) {
                return candidates[0];
            }
        }
        throw new common_1.BadRequestException('Подходящая ступень тарифа для указанного количества не найдена.');
    }
    calculateQuoteTotal(tier, pallets) {
        const priceRub = Number(tier.priceRub);
        if (tier.pricingMode === client_1.LogisticsPricingMode.TOTAL) {
            return priceRub;
        }
        if (tier.pricingMode === client_1.LogisticsPricingMode.PER_PALLET && pallets != null) {
            return Number((priceRub * pallets).toFixed(2));
        }
        // Русский комментарий: неоднозначные строки показываем оператору без автоумножения, чтобы не сделать неверный счет.
        return null;
    }
    findActiveTariffSet(at) {
        return this.prisma.logisticsTariffSet.findFirst({
            where: {
                AND: [
                    { OR: [{ activeFrom: null }, { activeFrom: { lte: at } }] },
                    { OR: [{ activeTo: null }, { activeTo: { gte: at } }] },
                ],
            },
            orderBy: [{ activeFrom: 'desc' }, { createdAt: 'desc' }],
        });
    }
    isPalletTierMatch(tier, pallets) {
        if (tier.maxBoxes != null) {
            return false;
        }
        const minPallets = tier.minPallets ?? 1;
        const maxPallets = tier.maxPallets ?? Number.MAX_SAFE_INTEGER;
        return pallets >= minPallets && pallets <= maxPallets;
    }
    palletTierRank(tier) {
        const min = tier.minPallets ?? 1;
        const max = tier.maxPallets ?? Number.MAX_SAFE_INTEGER;
        const specificity = tier.maxPallets == null ? 0 : tier.minPallets === tier.maxPallets ? 2 : 1;
        return specificity * 1_000_000 + min * 1_000 - (max === Number.MAX_SAFE_INTEGER ? 999 : max - min);
    }
    serializeTier(tier) {
        return {
            label: tier.label,
            minPallets: tier.minPallets,
            maxPallets: tier.maxPallets,
            maxBoxes: tier.maxBoxes,
            pricingMode: tier.pricingMode,
            priceRub: Number(tier.priceRub),
        };
    }
    async tryQuoteForDelivery(dto) {
        const quoteDate = dto.desiredShipDate ? new Date(dto.desiredShipDate) : new Date();
        const tariffSet = dto.tariffSetId
            ? await this.prisma.logisticsTariffSet.findUnique({ where: { id: dto.tariffSetId } })
            : await this.findActiveTariffSet(quoteDate);
        try {
            if (!tariffSet) {
                throw new common_1.NotFoundException('Активный набор тарифов логистики не найден.');
            }
            const quote = await this.quote({
                tariffSetId: tariffSet.id,
                destination: dto.destination,
                boxes: dto.boxes,
                pallets: dto.pallets,
                quoteDate: dto.desiredShipDate,
            });
            return {
                tariffSetId: quote.tariffSet.id,
                estimatedTotalRub: quote.estimatedTotalRub,
                requiresManualReview: quote.requiresManualReview || quote.estimatedTotalRub == null,
                note: quote.note,
            };
        }
        catch (caught) {
            const details = caught instanceof Error ? caught.message : 'тариф не найден';
            const message = `Требуется ручной расчет фулфилментом: ${details}`;
            return {
                tariffSetId: tariffSet?.id ?? dto.tariffSetId,
                estimatedTotalRub: null,
                requiresManualReview: true,
                note: message,
            };
        }
    }
    resolveDeliveryQuantity(dto, packages) {
        if (dto.requestId) {
            if (packages.length === 0) {
                throw new common_1.BadRequestException('Для доставки по заявке сначала упакуйте заявку: фактические короба и паллеты берутся из упаковки.');
            }
            const counts = packages.reduce((result, pack) => {
                if (isPalletPackage(pack.packageType)) {
                    result.pallets += 1;
                }
                else {
                    result.boxes += 1;
                }
                return result;
            }, { boxes: 0, pallets: 0 });
            const calculatedPallets = Math.max(counts.pallets, calculateLogisticsPalletCount(counts.boxes));
            const usePalletTariff = counts.pallets > 0 || counts.boxes > MAX_BOXES_FOR_BOX_TARIFF;
            return {
                boxes: counts.boxes || null,
                pallets: usePalletTariff ? calculatedPallets || null : null,
                quoteBoxes: usePalletTariff ? undefined : counts.boxes || undefined,
                quotePallets: usePalletTariff ? calculatedPallets || undefined : undefined,
            };
        }
        if (Boolean(dto.boxes) === Boolean(dto.pallets)) {
            throw new common_1.BadRequestException('Для доставки передайте ровно одно значение: короба или паллеты.');
        }
        const calculatedPallets = dto.boxes != null && dto.boxes > MAX_BOXES_FOR_BOX_TARIFF
            ? calculateLogisticsPalletCount(dto.boxes)
            : dto.pallets;
        const usePalletTariff = dto.pallets != null || calculatedPallets != null;
        return {
            boxes: dto.boxes ?? null,
            pallets: usePalletTariff ? calculatedPallets ?? null : null,
            quoteBoxes: usePalletTariff ? undefined : dto.boxes,
            quotePallets: usePalletTariff ? calculatedPallets : undefined,
        };
    }
    normalizePoint(value) {
        return value.normalize('NFKC').toLowerCase().replace(/ё/g, 'е').replace(/\s*,\s*/g, ', ').replace(/\s+/g, ' ').trim();
    }
    normalizeCity(value) {
        return this.normalizePoint(value.replace(/\([^)]*\)/g, ' '));
    }
    findTariffDirection(directions, destination) {
        const exact = directions.find((item) => this.normalizePoint(item.destination) === this.normalizePoint(destination));
        if (exact) {
            return exact;
        }
        const city = this.normalizeCity(destination);
        const cityMatches = directions.filter((item) => this.normalizeCity(item.destination) === city);
        return cityMatches.length === 1 ? cityMatches[0] : undefined;
    }
    parseDate(value) {
        if (!value) {
            return undefined;
        }
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) {
            throw new common_1.BadRequestException(`Некорректная дата тарифа: ${value}`);
        }
        return date;
    }
    async generateTripCode(plannedDate) {
        const baseDate = plannedDate ?? new Date();
        const prefix = `TRIP-${baseDate.toISOString().slice(0, 10).replace(/-/g, '')}`;
        const sequence = await this.prisma.logisticsTrip.count({
            where: { code: { startsWith: prefix } },
        });
        return `${prefix}-${String(sequence + 1).padStart(3, '0')}`;
    }
};
exports.LogisticsService = LogisticsService;
exports.LogisticsService = LogisticsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        telegram_notification_service_1.TelegramNotificationService])
], LogisticsService);
const DELIVERY_SERVICE_CODE = 'LOGISTICS_DELIVERY';
const logisticsTripInclude = {
    carrier: {
        select: {
            id: true,
            name: true,
            phone: true,
            contactName: true,
            isActive: true,
        },
    },
    deliveries: {
        select: {
            id: true,
            clientId: true,
            origin: true,
            destination: true,
            boxes: true,
            pallets: true,
            desiredShipDate: true,
            plannedShipDate: true,
            status: true,
            client: {
                select: {
                    id: true,
                    code: true,
                    name: true,
                },
            },
        },
        orderBy: [{ updatedAt: 'desc' }],
    },
};
const deliveryRequestInclude = {
    client: {
        select: {
            id: true,
            code: true,
            name: true,
        },
    },
    request: {
        select: {
            id: true,
            title: true,
            type: true,
            status: true,
        },
    },
    tariffSet: {
        select: {
            id: true,
            name: true,
        },
    },
    billingCharge: {
        select: {
            id: true,
            description: true,
            status: true,
            totalRub: true,
        },
    },
    trip: {
        select: {
            id: true,
            code: true,
            plannedDate: true,
            status: true,
            vehicleNumber: true,
            driverName: true,
            carrier: {
                select: {
                    id: true,
                    name: true,
                    phone: true,
                },
            },
        },
    },
    createdBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
};
function ensureDeliveryBillingService(tx) {
    return tx.billingService.upsert({
        where: { code: DELIVERY_SERVICE_CODE },
        update: {
            name: 'Доставка по заявке',
            unit: client_1.BillingUnit.SERVICE,
            isActive: true,
        },
        create: {
            code: DELIVERY_SERVICE_CODE,
            name: 'Доставка по заявке',
            unit: client_1.BillingUnit.SERVICE,
            isActive: true,
        },
    });
}
function deliverySourceKey(deliveryRequestId) {
    return `logistics-delivery:${deliveryRequestId}`;
}
function isPalletPackage(packageType) {
    return ['PALLET', 'PALLETTE', 'ПАЛЛЕТ', 'ПАЛЛЕТА'].includes((packageType ?? '').trim().toUpperCase());
}
function calculateLogisticsPalletCount(boxes) {
    if (!Number.isFinite(boxes) || boxes <= 0) {
        return 0;
    }
    const normalizedBoxes = Math.floor(boxes);
    const fullPallets = Math.floor(normalizedBoxes / BOXES_PER_PALLET);
    const remainder = normalizedBoxes % BOXES_PER_PALLET;
    return fullPallets + (remainder > EXTRA_BOXES_PER_PALLET ? 1 : 0);
}
function deliveryStatusLabel(status) {
    const labels = {
        [client_1.LogisticsDeliveryStatus.REQUESTED]: 'запрос',
        [client_1.LogisticsDeliveryStatus.QUOTED]: 'рассчитано',
        [client_1.LogisticsDeliveryStatus.PLANNED]: 'запланировано',
        [client_1.LogisticsDeliveryStatus.IN_TRANSIT]: 'в пути',
        [client_1.LogisticsDeliveryStatus.DELIVERED]: 'доставлено',
        [client_1.LogisticsDeliveryStatus.CANCELLED]: 'отменено',
    };
    return labels[status];
}
function normalizeText(value) {
    const normalized = value?.trim();
    return normalized ? normalized : undefined;
}
function normalizeRequiredText(value, message) {
    const normalized = normalizeText(value);
    if (!normalized) {
        throw new common_1.BadRequestException(message);
    }
    return normalized;
}
