"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasswordService = void 0;
const common_1 = require("@nestjs/common");
const crypto_1 = require("crypto");
const util_1 = require("util");
const scrypt = (0, util_1.promisify)(crypto_1.scrypt);
const KEY_LENGTH = 64;
let PasswordService = class PasswordService {
    async hash(password) {
        const salt = (0, crypto_1.randomBytes)(16).toString('base64url');
        const derived = (await scrypt(password, salt, KEY_LENGTH));
        return `scrypt$v1$${salt}$${derived.toString('base64url')}`;
    }
    async verify(password, storedHash) {
        const [algorithm, version, salt, hash] = storedHash.split('$');
        if (algorithm !== 'scrypt' || version !== 'v1' || !salt || !hash) {
            return false;
        }
        const expected = Buffer.from(hash, 'base64url');
        const derived = (await scrypt(password, salt, expected.length));
        // Русский комментарий: сравниваем через timingSafeEqual, чтобы не выдавать пароль временем ответа.
        return expected.length === derived.length && (0, crypto_1.timingSafeEqual)(expected, derived);
    }
};
exports.PasswordService = PasswordService;
exports.PasswordService = PasswordService = __decorate([
    (0, common_1.Injectable)()
], PasswordService);
