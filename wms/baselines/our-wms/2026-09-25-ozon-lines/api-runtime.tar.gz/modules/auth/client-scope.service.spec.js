"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const vitest_1 = require("vitest");
const client_scope_service_1 = require("./client-scope.service");
const service = new client_scope_service_1.ClientScopeService();
function demoUser(overrides = {}) {
    return {
        id: 'demo-user',
        email: 'demo',
        name: 'Demo',
        isDemo: true,
        roleCodes: ['CLIENT'],
        permissionCodes: ['system:admin'],
        clientScopeMode: 'ALL',
        clientIds: ['demo-client'],
        writableClientIds: ['demo-client'],
        ...overrides,
    };
}
(0, vitest_1.describe)('ClientScopeService demo isolation', () => {
    (0, vitest_1.it)('keeps a demo user limited even if role settings accidentally grant global access', () => {
        (0, vitest_1.expect)(service.resolveClientFilter(demoUser())).toEqual({ in: ['demo-client'] });
        (0, vitest_1.expect)(() => service.requireGlobalClientAccess(demoUser())).toThrow(common_1.ForbiddenException);
    });
    (0, vitest_1.it)('rejects reading or writing another client', () => {
        (0, vitest_1.expect)(() => service.requireClientAccess(demoUser(), 'real-client', 'read')).toThrow(common_1.ForbiddenException);
        (0, vitest_1.expect)(() => service.requireClientAccess(demoUser(), 'real-client', 'write')).toThrow(common_1.ForbiddenException);
    });
    (0, vitest_1.it)('allows the single assigned demo client', () => {
        (0, vitest_1.expect)(() => service.requireClientAccess(demoUser(), 'demo-client', 'read')).not.toThrow();
        (0, vitest_1.expect)(() => service.requireClientAccess(demoUser(), 'demo-client', 'write')).not.toThrow();
    });
    (0, vitest_1.it)('excludes demo clients from a live global session', () => {
        const liveAdmin = demoUser({
            id: 'admin',
            email: 'admin',
            name: 'Admin',
            isDemo: false,
            clientIds: [],
            writableClientIds: [],
            hiddenClientIds: ['demo-client'],
        });
        (0, vitest_1.expect)(service.resolveClientFilter(liveAdmin)).toEqual({ notIn: ['demo-client'] });
        (0, vitest_1.expect)(() => service.requireClientAccess(liveAdmin, 'real-client', 'read')).not.toThrow();
        (0, vitest_1.expect)(() => service.requireClientAccess(liveAdmin, 'demo-client', 'read')).toThrow(common_1.ForbiddenException);
    });
});
