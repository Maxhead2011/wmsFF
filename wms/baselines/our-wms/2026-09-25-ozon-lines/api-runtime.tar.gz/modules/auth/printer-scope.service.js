"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrinterScopeService = void 0;
exports.normalizePrinterGroupCode = normalizePrinterGroupCode;
const common_1 = require("@nestjs/common");
let PrinterScopeService = class PrinterScopeService {
    resolvePrinterGroupFilter(user, requestedGroupCode, mode = 'print') {
        const groupCode = requestedGroupCode ? normalizePrinterGroupCode(requestedGroupCode) : undefined;
        if (groupCode) {
            this.requirePrinterGroupAccess(user, groupCode, mode);
            return groupCode;
        }
        if (this.hasGlobalPrinterAccess(user)) {
            return undefined;
        }
        return { in: this.allowedGroups(user, mode) };
    }
    requirePrinterGroupAccess(user, groupCode, mode) {
        if (this.hasGlobalPrinterAccess(user)) {
            return;
        }
        const normalizedGroupCode = normalizePrinterGroupCode(groupCode);
        if (!this.allowedGroups(user, mode).includes(normalizedGroupCode)) {
            throw new common_1.ForbiddenException({
                message: 'Нет доступа к группе принтеров.',
                groupCode: normalizedGroupCode,
                mode,
            });
        }
    }
    hasGlobalPrinterAccess(user) {
        return user.permissionCodes.includes('system:admin');
    }
    allowedGroups(user, mode) {
        return (user.printerGroups ?? [])
            .filter((scope) => (mode === 'manage' ? scope.canManage : scope.canPrint))
            .map((scope) => normalizePrinterGroupCode(scope.groupCode));
    }
};
exports.PrinterScopeService = PrinterScopeService;
exports.PrinterScopeService = PrinterScopeService = __decorate([
    (0, common_1.Injectable)()
], PrinterScopeService);
function normalizePrinterGroupCode(value) {
    return value.trim().toUpperCase();
}
