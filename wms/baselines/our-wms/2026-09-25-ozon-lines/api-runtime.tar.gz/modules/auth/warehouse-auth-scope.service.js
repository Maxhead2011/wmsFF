"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WarehouseAuthScopeService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
let WarehouseAuthScopeService = class WarehouseAuthScopeService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async resolve(input) {
        const visibleClientScopes = input.clientScopes.filter((scope) => scope.client.isDemo === input.isDemo);
        const explicitScope = {
            clientIds: visibleClientScopes.filter((scope) => scope.canRead).map((scope) => scope.clientId),
            writableClientIds: visibleClientScopes.filter((scope) => scope.canWrite).map((scope) => scope.clientId),
            relabelingEnabled: visibleClientScopes.some((scope) => scope.canRead && scope.client.relabelingEnabled),
        };
        const isSystemAdmin = input.permissionCodes.includes('system:admin');
        const isClient = input.roleCodes.includes('CLIENT');
        // FIX: API-manager roles are narrow client capabilities, not internal warehouse roles.
        const clientCompatibleRoles = new Set(['CLIENT', 'CLIENT_API_MANAGER', 'WMS_API_MANAGER']);
        if (isClient && input.roleCodes.some((code) => !clientCompatibleRoles.has(code))) {
            throw new common_1.ForbiddenException('Роль клиента нельзя совмещать с внутренними ролями сотрудников.');
        }
        if (!isSystemAdmin && input.roleCodes.includes('BRANCH_MANAGER')) {
            if (input.warehouseScopes.length !== 1 ||
                !input.warehouseScopes[0].canRead ||
                !input.warehouseScopes[0].canWrite) {
                throw new common_1.ForbiddenException('Менеджер филиала должен быть закреплён ровно за одним доступным для работы филиалом.');
            }
        }
        if (isSystemAdmin || isClient) {
            return {
                activeWarehouseId: input.activeWarehouseId,
                clientScopeMode: input.isDemo || isClient || visibleClientScopes.length > 0 ? 'LIMITED' : 'ALL',
                ...explicitScope,
            };
        }
        if (input.warehouseScopes.length === 0) {
            return {
                activeWarehouseId: null,
                clientScopeMode: visibleClientScopes.length > 0 ? 'LIMITED' : 'ALL',
                ...explicitScope,
            };
        }
        const readableWarehouseIds = input.warehouseScopes
            .filter((scope) => scope.canRead && scope.warehouse.isActive)
            .map((scope) => scope.warehouseId);
        let activeWarehouseId = readableWarehouseIds.includes(input.activeWarehouseId ?? '')
            ? input.activeWarehouseId
            : null;
        if (!activeWarehouseId && readableWarehouseIds.length > 0) {
            const [fallback] = await this.prisma.warehouse.findMany({
                where: { id: { in: readableWarehouseIds }, isActive: true },
                select: { id: true },
                orderBy: [{ sortOrder: 'asc' }, { code: 'asc' }],
                take: 1,
            });
            activeWarehouseId = fallback?.id ?? null;
        }
        if (!activeWarehouseId) {
            return {
                activeWarehouseId: null,
                clientScopeMode: 'LIMITED',
                clientIds: [],
                writableClientIds: [],
                relabelingEnabled: false,
            };
        }
        const branchClients = await this.prisma.warehouseClient.findMany({
            where: {
                warehouseId: activeWarehouseId,
                status: 'ACTIVE',
                client: { isDemo: input.isDemo },
            },
            select: {
                clientId: true,
                client: { select: { relabelingEnabled: true } },
            },
            orderBy: { createdAt: 'asc' },
        });
        const clientIds = branchClients.map((link) => link.clientId);
        const canWriteActiveWarehouse = input.warehouseScopes.some((scope) => scope.warehouseId === activeWarehouseId && scope.canWrite);
        return {
            activeWarehouseId,
            clientScopeMode: 'LIMITED',
            clientIds,
            writableClientIds: canWriteActiveWarehouse ? clientIds : [],
            relabelingEnabled: branchClients.some((link) => link.client.relabelingEnabled),
        };
    }
};
exports.WarehouseAuthScopeService = WarehouseAuthScopeService;
exports.WarehouseAuthScopeService = WarehouseAuthScopeService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WarehouseAuthScopeService);
