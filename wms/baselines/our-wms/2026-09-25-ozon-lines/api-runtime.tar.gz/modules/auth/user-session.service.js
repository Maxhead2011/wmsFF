"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserSessionService = void 0;
const common_1 = require("@nestjs/common");
const access_token_service_1 = require("./access-token.service");
const prisma_service_1 = require("../../common/prisma/prisma.service");
let UserSessionService = class UserSessionService {
    prisma;
    tokens;
    constructor(prisma, tokens) {
        this.prisma = prisma;
        this.tokens = tokens;
    }
    async register(userId, token, payload, context = {}) {
        const accessTokenId = this.tokens.fingerprint(token);
        const userAgent = normalizeHeader(context.userAgent);
        const client = describeClient(userAgent);
        return this.prisma.userSession.upsert({
            where: { accessTokenId },
            create: {
                userId,
                accessTokenId,
                ipAddress: context.ip?.trim() || null,
                userAgent: userAgent || null,
                appName: client.appName,
                browserName: client.browserName,
                expiresAt: new Date(payload.exp * 1000),
            },
            update: {
                lastSeenAt: new Date(),
            },
        });
    }
    async assertActive(userId, token, payload, context = {}) {
        const accessTokenId = this.tokens.fingerprint(token);
        const existing = await this.prisma.userSession.findUnique({ where: { accessTokenId } });
        if (existing) {
            if (existing.userId !== userId || (existing.expiresAt && existing.expiresAt.getTime() <= Date.now())) {
                throw new common_1.UnauthorizedException('Сессия закрыта. Войдите в систему повторно.');
            }
            if (Date.now() - existing.lastSeenAt.getTime() >= 60_000) {
                await this.prisma.userSession.update({
                    where: { id: existing.id },
                    data: { lastSeenAt: new Date() },
                });
            }
            return existing;
        }
        return this.register(userId, token, payload, context);
    }
    async revokeByToken(token) {
        const accessTokenId = this.tokens.fingerprint(token);
        const existing = await this.prisma.userSession.findUnique({
            where: { accessTokenId },
            select: { id: true },
        });
        if (!existing)
            return false;
        await this.prisma.userSession.update({
            where: { id: existing.id },
            data: { expiresAt: new Date(), lastSeenAt: new Date() },
        });
        return true;
    }
};
exports.UserSessionService = UserSessionService;
exports.UserSessionService = UserSessionService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        access_token_service_1.AccessTokenService])
], UserSessionService);
function normalizeHeader(value) {
    return Array.isArray(value) ? value.join(', ') : value?.trim() ?? '';
}
function describeClient(userAgent) {
    if (/android|iphone|ipad|mobile/i.test(userAgent)) {
        return {
            appName: /wms|logoff/i.test(userAgent) ? 'LOGOff WMS Mobile' : 'Мобильный браузер',
            browserName: browserName(userAgent),
        };
    }
    return { appName: 'WMS', browserName: browserName(userAgent) };
}
function browserName(userAgent) {
    if (/edg\//i.test(userAgent))
        return 'Microsoft Edge';
    if (/opr\/|opera/i.test(userAgent))
        return 'Opera';
    if (/chrome\//i.test(userAgent))
        return 'Google Chrome';
    if (/firefox\//i.test(userAgent))
        return 'Mozilla Firefox';
    if (/safari\//i.test(userAgent))
        return 'Safari';
    return userAgent ? 'Другой клиент' : 'Не определён';
}
