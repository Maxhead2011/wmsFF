"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccessTokenService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
const TOKEN_TTL_SECONDS = 60 * 60 * 8;
let AccessTokenService = class AccessTokenService {
    config;
    constructor(config) {
        this.config = config;
    }
    sign(userId, options = {}) {
        const now = Math.floor(Date.now() / 1000);
        const payload = {
            sub: userId,
            deviceId: options.deviceId,
            deviceCode: options.deviceCode,
            iat: now,
            exp: now + TOKEN_TTL_SECONDS,
        };
        const header = this.encodeJson({ alg: 'HS256', typ: 'JWT' });
        const body = this.encodeJson(payload);
        const signature = this.signParts(header, body);
        return `${header}.${body}.${signature}`;
    }
    verify(token) {
        const [header, body, signature] = token.split('.');
        if (!header || !body || !signature) {
            throw new common_1.UnauthorizedException('Некорректный access token.');
        }
        const expectedSignature = this.signParts(header, body);
        if (!this.safeEqual(signature, expectedSignature)) {
            throw new common_1.UnauthorizedException('Некорректная подпись access token.');
        }
        const payload = this.decodeJson(body);
        if (!payload.sub || !payload.exp || payload.exp < Math.floor(Date.now() / 1000)) {
            throw new common_1.UnauthorizedException('Access token истек или поврежден.');
        }
        return payload;
    }
    fingerprint(token) {
        return (0, crypto_1.createHash)('sha256').update(token).digest('hex');
    }
    signParts(header, body) {
        return (0, crypto_1.createHmac)('sha256', this.secret()).update(`${header}.${body}`).digest('base64url');
    }
    secret() {
        const secret = this.config.get('JWT_ACCESS_SECRET');
        const isProduction = this.config.get('NODE_ENV') === 'production';
        if (!secret || (isProduction && secret === 'change_me_access')) {
            throw new common_1.UnauthorizedException('JWT_ACCESS_SECRET не настроен.');
        }
        return secret;
    }
    encodeJson(value) {
        return Buffer.from(JSON.stringify(value)).toString('base64url');
    }
    decodeJson(value) {
        try {
            return JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
        }
        catch {
            throw new common_1.UnauthorizedException('Access token не читается.');
        }
    }
    safeEqual(left, right) {
        const leftBuffer = Buffer.from(left);
        const rightBuffer = Buffer.from(right);
        return leftBuffer.length === rightBuffer.length && (0, crypto_1.timingSafeEqual)(leftBuffer, rightBuffer);
    }
};
exports.AccessTokenService = AccessTokenService;
exports.AccessTokenService = AccessTokenService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], AccessTokenService);
