"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientScopeService = void 0;
const common_1 = require("@nestjs/common");
let ClientScopeService = class ClientScopeService {
    resolveClientFilter(user, requestedClientId) {
        if (requestedClientId) {
            this.requireClientAccess(user, requestedClientId, 'read');
            return requestedClientId;
        }
        if (this.hasGlobalClientAccess(user)) {
            return user.hiddenClientIds?.length ? { notIn: user.hiddenClientIds } : undefined;
        }
        return { in: user.clientIds };
    }
    requireClientAccess(user, clientId, mode) {
        if (this.hasGlobalClientAccess(user)) {
            if (user.hiddenClientIds?.includes(clientId)) {
                throw new common_1.ForbiddenException({
                    message: 'Демонстрационные данные доступны только в демо-режиме.',
                    clientId,
                    mode,
                });
            }
            return;
        }
        const allowedClientIds = mode === 'write' ? user.writableClientIds : user.clientIds;
        if (!allowedClientIds.includes(clientId)) {
            throw new common_1.ForbiddenException({
                message: 'Нет доступа к данным этого клиента.',
                clientId,
                mode,
            });
        }
    }
    requireGlobalClientAccess(user) {
        if (this.hasGlobalClientAccess(user)) {
            return;
        }
        throw new common_1.ForbiddenException('Операция доступна только пользователю без клиентского ограничения.');
    }
    hasGlobalClientAccess(user) {
        if (user.isDemo) {
            return false;
        }
        // Русский комментарий: system:admin всегда обходит клиентские scope; остальные зависят от режима, собранного AuthGuard.
        return user.permissionCodes.includes('system:admin') || user.clientScopeMode === 'ALL';
    }
};
exports.ClientScopeService = ClientScopeService;
exports.ClientScopeService = ClientScopeService = __decorate([
    (0, common_1.Injectable)()
], ClientScopeService);
