"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermissionsGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const require_permissions_decorator_1 = require("../decorators/require-permissions.decorator");
const tsd_warehouse_keeper_capability_1 = require("./tsd-warehouse-keeper-capability");
let PermissionsGuard = class PermissionsGuard {
    reflector;
    constructor(reflector) {
        this.reflector = reflector;
    }
    canActivate(context) {
        const request = context.switchToHttp().getRequest();
        (0, tsd_warehouse_keeper_capability_1.assertTsdWarehouseKeeperCapability)(request);
        const required = this.reflector.getAllAndOverride(require_permissions_decorator_1.REQUIRED_PERMISSIONS_KEY, [
            context.getHandler(),
            context.getClass(),
        ]);
        const requiredAny = this.reflector.getAllAndOverride(require_permissions_decorator_1.REQUIRED_ANY_PERMISSIONS_KEY, [
            context.getHandler(),
            context.getClass(),
        ]);
        if (!required?.length && !requiredAny?.length) {
            return true;
        }
        const permissions = new Set(request.user?.permissionCodes ?? []);
        if (permissions.has('system:admin') ||
            ((!required?.length || required.every((permission) => permissions.has(permission))) &&
                (!requiredAny?.length || requiredAny.some((permission) => permissions.has(permission))))) {
            return true;
        }
        // Русский комментарий: guard возвращает список недостающих прав, чтобы администратор быстро понял, какой доступ выдать роли.
        throw new common_1.ForbiddenException({
            message: 'Недостаточно прав для операции.',
            required: required ?? [],
            requiredAny: requiredAny ?? [],
            missing: (required ?? []).filter((permission) => !permissions.has(permission)),
        });
    }
};
exports.PermissionsGuard = PermissionsGuard;
exports.PermissionsGuard = PermissionsGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.Reflector])
], PermissionsGuard);
