"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../../common/prisma/prisma.service");
const system_settings_service_1 = require("../../../common/settings/system-settings.service");
const access_token_service_1 = require("../access-token.service");
const public_decorator_1 = require("../decorators/public.decorator");
const user_session_service_1 = require("../user-session.service");
const warehouse_auth_scope_service_1 = require("../warehouse-auth-scope.service");
let AuthGuard = class AuthGuard {
    reflector;
    tokens;
    prisma;
    settings;
    userSessions;
    warehouseAuthScope;
    demoClientIdsCache = null;
    administrationCache = null;
    constructor(reflector, tokens, prisma, settings, userSessions, warehouseAuthScope) {
        this.reflector = reflector;
        this.tokens = tokens;
        this.prisma = prisma;
        this.settings = settings;
        this.userSessions = userSessions;
        this.warehouseAuthScope = warehouseAuthScope;
    }
    async canActivate(context) {
        const isPublic = this.reflector.getAllAndOverride(public_decorator_1.IS_PUBLIC_KEY, [
            context.getHandler(),
            context.getClass(),
        ]);
        if (isPublic) {
            return true;
        }
        const request = context.switchToHttp().getRequest();
        const token = this.extractBearerToken(request.headers.authorization);
        const payload = this.tokens.verify(token);
        const user = await this.prisma.user.findUnique({
            where: { id: payload.sub },
            include: {
                clientScopes: {
                    include: {
                        client: {
                            select: { isDemo: true, relabelingEnabled: true },
                        },
                    },
                },
                printerScopes: true,
                warehouseScopes: {
                    include: { warehouse: { select: { isActive: true } } },
                },
                roles: {
                    include: {
                        role: {
                            include: {
                                permissions: {
                                    include: { permission: true },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (!user) {
            throw new common_1.UnauthorizedException('Пользователь access token не найден.');
        }
        if (user.status !== client_1.UserStatus.ACTIVE) {
            throw new common_1.ForbiddenException('Пользователь заблокирован.');
        }
        if (!payload.deviceId) {
            await this.userSessions.assertActive(user.id, token, payload, {
                ip: request.ip,
                userAgent: request.headers['user-agent'],
            });
        }
        const roleCodes = user.roles.map((item) => item.role.code);
        const permissionCodes = [
            ...new Set(user.roles.flatMap((item) => item.role.permissions.map((permission) => permission.permission.code))),
        ];
        const resolvedScope = await this.warehouseAuthScope.resolve({
            roleCodes,
            permissionCodes,
            isDemo: user.isDemo,
            activeWarehouseId: user.activeWarehouseId,
            clientScopes: user.clientScopes,
            warehouseScopes: user.warehouseScopes,
        });
        const hasGlobalClientAccess = !user.isDemo && resolvedScope.clientScopeMode === 'ALL';
        const hiddenClientIds = hasGlobalClientAccess ? await this.demoClientIds() : [];
        const administration = await this.administrationControls();
        request.user = {
            id: user.id,
            email: user.email,
            name: user.name,
            isDemo: user.isDemo,
            analyticsEnabled: user.analyticsEnabled,
            relabelingEnabled: hasGlobalClientAccess ||
                resolvedScope.relabelingEnabled,
            administrationEnabled: administration.ownerIds.includes(user.id) ||
                (user.isDemo && permissionCodes.includes('administration:demo')),
            workspaceVisibility: normalizeWorkspaceVisibility(administration.visibility[user.id]),
            roleCodes,
            permissionCodes,
            clientScopeMode: resolvedScope.clientScopeMode,
            clientIds: resolvedScope.clientIds,
            writableClientIds: resolvedScope.writableClientIds,
            activeWarehouseId: resolvedScope.activeWarehouseId,
            warehouseIds: user.warehouseScopes.filter((scope) => scope.canRead).map((scope) => scope.warehouseId),
            writableWarehouseIds: user.warehouseScopes.filter((scope) => scope.canWrite).map((scope) => scope.warehouseId),
            hiddenClientIds,
            printerGroups: user.printerScopes.map((scope) => ({
                groupCode: scope.groupCode,
                canPrint: scope.canPrint,
                canManage: scope.canManage,
            })),
            deviceId: payload.deviceId,
            deviceCode: payload.deviceCode,
        };
        return true;
    }
    async demoClientIds() {
        const now = Date.now();
        if (this.demoClientIdsCache && this.demoClientIdsCache.expiresAt > now) {
            return this.demoClientIdsCache.ids;
        }
        const clients = await this.prisma.client.findMany({
            where: { isDemo: true },
            select: { id: true },
        });
        const ids = clients.map((client) => client.id);
        this.demoClientIdsCache = { ids, expiresAt: now + 60_000 };
        return ids;
    }
    async administrationControls() {
        const now = Date.now();
        if (this.administrationCache && this.administrationCache.expiresAt > now) {
            return this.administrationCache;
        }
        const [ownerIds, visibility] = await Promise.all([
            this.settings.get('administration.ownerUserIds', []),
            this.settings.get('ui.workspaceVisibility', {}),
        ]);
        this.administrationCache = {
            ownerIds: Array.isArray(ownerIds) ? ownerIds.filter((item) => typeof item === 'string') : [],
            visibility: visibility && typeof visibility === 'object' && !Array.isArray(visibility) ? visibility : {},
            expiresAt: now + 5_000,
        };
        return this.administrationCache;
    }
    extractBearerToken(authorization) {
        const value = Array.isArray(authorization) ? authorization[0] : authorization;
        const [scheme, token] = value?.split(' ') ?? [];
        if (scheme !== 'Bearer' || !token) {
            throw new common_1.UnauthorizedException('Нужен Bearer access token.');
        }
        return token;
    }
};
exports.AuthGuard = AuthGuard;
exports.AuthGuard = AuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.Reflector,
        access_token_service_1.AccessTokenService,
        prisma_service_1.PrismaService,
        system_settings_service_1.SystemSettingsService,
        user_session_service_1.UserSessionService,
        warehouse_auth_scope_service_1.WarehouseAuthScopeService])
], AuthGuard);
function normalizeWorkspaceVisibility(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return {};
    return Object.fromEntries(Object.entries(value).filter((entry) => typeof entry[1] === 'boolean'));
}
