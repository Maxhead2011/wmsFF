"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthModule = void 0;
const common_1 = require("@nestjs/common");
const access_model_service_1 = require("./access-model.service");
const access_token_service_1 = require("./access-token.service");
const auth_controller_1 = require("./auth.controller");
const auth_service_1 = require("./auth.service");
const client_scope_service_1 = require("./client-scope.service");
const printer_scope_service_1 = require("./printer-scope.service");
const auth_guard_1 = require("./guards/auth.guard");
const permissions_guard_1 = require("./guards/permissions.guard");
const password_service_1 = require("./password.service");
const user_session_service_1 = require("./user-session.service");
const warehouse_auth_scope_service_1 = require("./warehouse-auth-scope.service");
let AuthModule = class AuthModule {
};
exports.AuthModule = AuthModule;
exports.AuthModule = AuthModule = __decorate([
    (0, common_1.Module)({
        controllers: [auth_controller_1.AuthController],
        providers: [
            access_model_service_1.AccessModelService,
            access_token_service_1.AccessTokenService,
            auth_service_1.AuthService,
            auth_guard_1.AuthGuard,
            client_scope_service_1.ClientScopeService,
            printer_scope_service_1.PrinterScopeService,
            password_service_1.PasswordService,
            permissions_guard_1.PermissionsGuard,
            user_session_service_1.UserSessionService,
            warehouse_auth_scope_service_1.WarehouseAuthScopeService,
        ],
        exports: [
            access_model_service_1.AccessModelService,
            access_token_service_1.AccessTokenService,
            auth_service_1.AuthService,
            auth_guard_1.AuthGuard,
            client_scope_service_1.ClientScopeService,
            printer_scope_service_1.PrinterScopeService,
            password_service_1.PasswordService,
            permissions_guard_1.PermissionsGuard,
            user_session_service_1.UserSessionService,
            warehouse_auth_scope_service_1.WarehouseAuthScopeService,
        ],
    })
], AuthModule);
