"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const client_1 = require("@prisma/client");
const audit_log_service_1 = require("../../common/audit/audit-log.service");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const system_settings_service_1 = require("../../common/settings/system-settings.service");
const access_model_service_1 = require("./access-model.service");
const access_token_service_1 = require("./access-token.service");
const password_service_1 = require("./password.service");
const user_session_service_1 = require("./user-session.service");
const warehouse_auth_scope_service_1 = require("./warehouse-auth-scope.service");
let AuthService = class AuthService {
    prisma;
    config;
    auditLog;
    accessModel;
    passwords;
    tokens;
    settings;
    userSessions;
    warehouseAuthScope;
    constructor(prisma, config, auditLog, accessModel, passwords, tokens, settings, userSessions, warehouseAuthScope) {
        this.prisma = prisma;
        this.config = config;
        this.auditLog = auditLog;
        this.accessModel = accessModel;
        this.passwords = passwords;
        this.tokens = tokens;
        this.settings = settings;
        this.userSessions = userSessions;
        this.warehouseAuthScope = warehouseAuthScope;
    }
    async bootstrapAdmin(dto) {
        this.assertBootstrapSecret(dto.bootstrapSecret);
        const usersCount = await this.prisma.user.count();
        if (usersCount > 0) {
            throw new common_1.BadRequestException('Первичный администратор уже создан.');
        }
        const [adminRole] = await this.accessModel.resolveRoles(['ADMIN']);
        const user = await this.prisma.user.create({
            data: {
                email: this.normalizeEmail(dto.email),
                name: dto.name.trim(),
                passwordHash: await this.passwords.hash(dto.password),
                roles: {
                    create: [{ roleId: adminRole.id }],
                },
            },
            include: this.userAccessInclude(),
        });
        await this.settings.set('administration.ownerUserIds', [user.id], user.id);
        return this.authResponse(user);
    }
    async login(dto, context = {}) {
        const user = await this.findUserWithAccess(this.normalizeEmail(dto.email));
        if (!user || !(await this.passwords.verify(dto.password, user.passwordHash))) {
            throw new common_1.UnauthorizedException('Неверный логин или пароль.');
        }
        if (user.status !== client_1.UserStatus.ACTIVE) {
            throw new common_1.UnauthorizedException('Пользователь заблокирован.');
        }
        const authUser = await this.toAuthUser(user);
        const maintenance = await this.getMaintenanceMode();
        if (maintenance.enabled && !authUser.permissionCodes.includes('system:admin')) {
            throw new common_1.UnauthorizedException(maintenance.message || 'Вход временно закрыт: идут сервисные работы.');
        }
        const accessToken = this.tokens.sign(user.id);
        const session = {
            accessToken,
            tokenType: 'Bearer',
            user: authUser,
        };
        await this.userSessions.register(user.id, accessToken, this.tokens.verify(accessToken), context);
        await this.auditLog.write({
            userId: user.id,
            action: 'auth.login',
            entity: 'user',
            entityId: user.id,
            payload: {
                ip: context.ip,
                userAgent: Array.isArray(context.userAgent) ? context.userAgent.join(', ') : context.userAgent,
                roleCodes: authUser.roleCodes,
                clientIds: authUser.clientIds,
            },
        });
        return session;
    }
    async logout(accessToken) {
        await this.userSessions.revokeByToken(accessToken);
        return { closed: true };
    }
    async findUserWithAccess(email) {
        return this.prisma.user.findUnique({
            where: { email },
            include: this.userAccessInclude(),
        });
    }
    async authResponse(user) {
        const authUser = await this.toAuthUser(user);
        return {
            accessToken: this.tokens.sign(user.id),
            tokenType: 'Bearer',
            user: authUser,
        };
    }
    async toAuthUser(user) {
        const roleCodes = user.roles.map((item) => item.role.code);
        const permissionCodes = [
            ...new Set(user.roles.flatMap((item) => item.role.permissions.map((permission) => permission.permission.code))),
        ];
        const resolvedScope = await this.warehouseAuthScope.resolve({
            roleCodes,
            permissionCodes,
            isDemo: user.isDemo,
            activeWarehouseId: user.activeWarehouseId,
            clientScopes: user.clientScopes,
            warehouseScopes: user.warehouseScopes,
        });
        if (!permissionCodes.includes('system:admin') &&
            resolvedScope.activeWarehouseId !== user.activeWarehouseId) {
            await this.prisma.user.update({
                where: { id: user.id },
                data: { activeWarehouseId: resolvedScope.activeWarehouseId },
            });
        }
        const hasGlobalClientAccess = !user.isDemo && resolvedScope.clientScopeMode === 'ALL';
        const [ownerIds, visibility] = await Promise.all([
            this.settings.get('administration.ownerUserIds', []),
            this.settings.get('ui.workspaceVisibility', {}),
        ]);
        return {
            id: user.id,
            email: user.email,
            name: user.name,
            isDemo: user.isDemo,
            analyticsEnabled: user.analyticsEnabled,
            relabelingEnabled: hasGlobalClientAccess ||
                resolvedScope.relabelingEnabled,
            administrationEnabled: ownerIds.includes(user.id) ||
                (user.isDemo && permissionCodes.includes('administration:demo')),
            workspaceVisibility: normalizeWorkspaceVisibility(visibility[user.id]),
            roleCodes,
            permissionCodes,
            clientScopeMode: resolvedScope.clientScopeMode,
            clientIds: resolvedScope.clientIds,
            writableClientIds: resolvedScope.writableClientIds,
            activeWarehouseId: resolvedScope.activeWarehouseId,
            warehouseIds: user.warehouseScopes.filter((scope) => scope.canRead).map((scope) => scope.warehouseId),
            writableWarehouseIds: user.warehouseScopes.filter((scope) => scope.canWrite).map((scope) => scope.warehouseId),
            printerGroups: user.printerScopes.map((scope) => ({
                groupCode: scope.groupCode,
                canPrint: scope.canPrint,
                canManage: scope.canManage,
            })),
        };
    }
    userAccessInclude() {
        return {
            clientScopes: {
                include: {
                    client: {
                        select: { isDemo: true, relabelingEnabled: true },
                    },
                },
            },
            printerScopes: true,
            warehouseScopes: {
                include: { warehouse: { select: { isActive: true } } },
            },
            roles: {
                include: {
                    role: {
                        include: {
                            permissions: {
                                include: { permission: true },
                            },
                        },
                    },
                },
            },
        };
    }
    assertBootstrapSecret(input) {
        const expected = this.config.get('BOOTSTRAP_ADMIN_SECRET');
        if (!expected || input !== expected) {
            throw new common_1.UnauthorizedException('Неверный bootstrap secret.');
        }
    }
    normalizeEmail(email) {
        return email.trim().toLowerCase();
    }
    async getMaintenanceMode() {
        const event = await this.prisma.auditLog.findFirst({
            where: { action: 'service.maintenance.update', entity: 'system' },
            orderBy: { createdAt: 'desc' },
        });
        const payload = event?.payload;
        if (!isRecord(payload)) {
            return { enabled: false, message: '' };
        }
        return {
            enabled: payload.enabled === true,
            message: typeof payload.message === 'string' ? payload.message : '',
        };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService,
        audit_log_service_1.AuditLogService,
        access_model_service_1.AccessModelService,
        password_service_1.PasswordService,
        access_token_service_1.AccessTokenService,
        system_settings_service_1.SystemSettingsService,
        user_session_service_1.UserSessionService,
        warehouse_auth_scope_service_1.WarehouseAuthScopeService])
], AuthService);
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
function normalizeWorkspaceVisibility(value) {
    if (!isRecord(value))
        return {};
    return Object.fromEntries(Object.entries(value).filter((entry) => typeof entry[1] === 'boolean'));
}
