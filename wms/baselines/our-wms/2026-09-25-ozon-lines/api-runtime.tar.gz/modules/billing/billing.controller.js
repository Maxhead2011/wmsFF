"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const billing_document_service_1 = require("./billing-document.service");
const billing_pdf_service_1 = require("./billing-pdf.service");
const billing_service_1 = require("./billing.service");
const billing_period_service_1 = require("./billing-period.service");
const generate_billing_period_dto_1 = require("./dto/generate-billing-period.dto");
const create_billing_advance_dto_1 = require("./dto/create-billing-advance.dto");
const create_billing_charge_dto_1 = require("./dto/create-billing-charge.dto");
const create_billing_invoice_dto_1 = require("./dto/create-billing-invoice.dto");
const create_billing_payment_dto_1 = require("./dto/create-billing-payment.dto");
const create_incoming_payment_dto_1 = require("./dto/create-incoming-payment.dto");
const create_billing_service_dto_1 = require("./dto/create-billing-service.dto");
const create_manual_billing_invoice_dto_1 = require("./dto/create-manual-billing-invoice.dto");
const generate_storage_charge_dto_1 = require("./dto/generate-storage-charge.dto");
const list_billing_charges_dto_1 = require("./dto/list-billing-charges.dto");
const list_billing_invoices_dto_1 = require("./dto/list-billing-invoices.dto");
const list_billing_reconciliation_dto_1 = require("./dto/list-billing-reconciliation.dto");
const list_billing_service_history_dto_1 = require("./dto/list-billing-service-history.dto");
const merge_fbs_invoices_dto_1 = require("./dto/merge-fbs-invoices.dto");
const preview_fbs_invoices_dto_1 = require("./dto/preview-fbs-invoices.dto");
const merge_billing_invoices_dto_1 = require("./dto/merge-billing-invoices.dto");
const update_billing_charge_status_dto_1 = require("./dto/update-billing-charge-status.dto");
const update_billing_invoice_status_dto_1 = require("./dto/update-billing-invoice-status.dto");
const update_client_fbs_turnkey_dto_1 = require("./dto/update-client-fbs-turnkey.dto");
const update_fbs_logistics_trip_dto_1 = require("./dto/update-fbs-logistics-trip.dto");
const update_invoice_payment_account_dto_1 = require("./dto/update-invoice-payment-account.dto");
const upsert_client_billing_service_dto_1 = require("./dto/upsert-client-billing-service.dto");
let BillingController = class BillingController {
    billing;
    documents;
    pdf;
    periods;
    constructor(billing, documents, pdf, periods) {
        this.billing = billing;
        this.documents = documents;
        this.pdf = pdf;
        this.periods = periods;
    }
    // ADDED: preview is read-only; generation requires its current fingerprint.
    previewPeriod(dto, user) {
        return this.periods.previewPeriod(dto, user);
    }
    generatePeriod(dto, user) {
        return this.periods.generatePeriod(dto, user);
    }
    listServices(user) {
        return this.billing.listServices(user);
    }
    createService(dto, user) {
        return this.billing.createService(dto, user);
    }
    listClientServices(clientId, user) {
        return this.billing.listClientServices(clientId, user);
    }
    upsertClientService(clientId, dto, user) {
        return this.billing.upsertClientService(clientId, dto, user);
    }
    getClientFbsTurnkey(clientId, user) {
        return this.billing.getClientFbsTurnkey(clientId, user);
    }
    updateClientFbsTurnkey(clientId, dto, user) {
        return this.billing.updateClientFbsTurnkey(clientId, dto, user);
    }
    listCharges(query, user) {
        return this.billing.listCharges(query, user);
    }
    listServiceHistory(query, user) {
        return this.billing.listServiceHistory(query, user);
    }
    listReconciliation(query, user) {
        return this.billing.listReconciliation(query, user);
    }
    listAdvances(clientId, user) {
        return this.billing.listAdvances(clientId, user);
    }
    createAdvance(dto, user) {
        return this.billing.createAdvance(dto, user);
    }
    cancelAdvance(id, user) {
        return this.billing.cancelAdvance(id, user);
    }
    applyAdvance(id, user) {
        return this.billing.applyAdvance(id, user);
    }
    restoreAdvance(id, user) {
        return this.billing.restoreAdvance(id, user);
    }
    createCharge(dto, user) {
        return this.billing.createCharge(dto, user);
    }
    generateStorageCharge(dto, user) {
        return this.billing.generateStorageCharge(dto, user);
    }
    updateChargeStatus(id, dto, user) {
        return this.billing.updateChargeStatus(id, dto, user);
    }
    updateFbsLogisticsTrip(id, dto, user) {
        return this.billing.updateFbsLogisticsTrip(id, dto, user);
    }
    getStorageChargeBreakdown(id, user) {
        return this.billing.getStorageChargeBreakdown(id, user);
    }
    deleteStorageChargeDay(id, date, user) {
        return this.billing.deleteStorageChargeDay(id, date, user);
    }
    listInvoices(query, user) {
        return this.billing.listInvoices(query, user);
    }
    async getCombinedInvoicesPdf(query, user, response) {
        const selection = await this.billing.listInvoicesForCombinedPdf(query, user);
        const file = await this.pdf.getCombinedInvoicesPdf(selection.invoiceIds, selection.client.code, user);
        setPdfHeaders(response, file.fileName);
        return new common_1.StreamableFile(file.buffer);
    }
    // FIX: large selections use JSON; same read permission, scope and read-only service as GET.
    previewFbsMerge(dto, user) {
        return this.billing.getFbsMergePreview(dto.clientId, user, dto.invoiceIds);
    }
    getFbsMergePreview(clientId, invoiceIds, user) {
        return this.billing.getFbsMergePreview(clientId, user, invoiceIds?.split(',').map((id) => id.trim()).filter(Boolean));
    }
    recheckInvoice(id, user) {
        return this.billing.recheckInvoice(id, user);
    }
    addInvoicePrimaryProcessing(id, user) {
        return this.billing.addInvoicePrimaryProcessing(id, user);
    }
    mergeFbsInvoices(dto, user) {
        return this.billing.mergeFbsInvoices(dto, user);
    }
    mergeInvoices(dto, user) {
        return this.billing.mergeInvoices(dto, user);
    }
    getInvoiceDocument(id, user) {
        return this.documents.getInvoiceDocument(id, user);
    }
    async getInvoiceDocumentPdf(id, user, response) {
        const file = await this.pdf.getInvoicePdf(id, user);
        setPdfHeaders(response, file.fileName);
        return new common_1.StreamableFile(file.buffer);
    }
    getInvoiceActDocument(id, user) {
        return this.documents.getInvoiceActDocument(id, user);
    }
    async getInvoiceActDocumentPdf(id, user, response) {
        const file = await this.pdf.getInvoiceActPdf(id, user);
        setPdfHeaders(response, file.fileName);
        return new common_1.StreamableFile(file.buffer);
    }
    createInvoice(dto, user) {
        return this.billing.createInvoice(dto, user);
    }
    listClientPaymentAccounts(clientId, user) {
        return this.billing.listClientPaymentAccounts(clientId, user);
    }
    createManualInvoice(dto, user) {
        return this.billing.createManualInvoice(dto, user);
    }
    updateManualInvoice(id, dto, user) {
        return this.billing.updateManualInvoice(id, dto, user);
    }
    updateInvoicePaymentAccount(id, dto, user) {
        return this.billing.updateInvoicePaymentAccount(id, dto, user);
    }
    updateInvoiceStatus(id, dto, user) {
        return this.billing.updateInvoiceStatus(id, dto, user);
    }
    createPayment(dto, user) {
        return this.billing.createPayment(dto, user);
    }
    createIncomingPayment(dto, user) {
        return this.billing.createIncomingPayment(dto, user);
    }
};
exports.BillingController = BillingController;
__decorate([
    (0, common_1.Post)('invoices/period/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [generate_billing_period_dto_1.PreviewBillingPeriodDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "previewPeriod", null);
__decorate([
    (0, common_1.Post)('invoices/period/generate'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [generate_billing_period_dto_1.GenerateBillingPeriodDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "generatePeriod", null);
__decorate([
    (0, common_1.Get)('services'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listServices", null);
__decorate([
    (0, common_1.Post)('services'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_billing_service_dto_1.CreateBillingServiceDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "createService", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/services'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listClientServices", null);
__decorate([
    (0, common_1.Put)('clients/:clientId/services'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, upsert_client_billing_service_dto_1.UpsertClientBillingServiceDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "upsertClientService", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/fbs-turnkey'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "getClientFbsTurnkey", null);
__decorate([
    (0, common_1.Put)('clients/:clientId/fbs-turnkey'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_client_fbs_turnkey_dto_1.UpdateClientFbsTurnkeyDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "updateClientFbsTurnkey", null);
__decorate([
    (0, common_1.Get)('charges'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_billing_charges_dto_1.ListBillingChargesDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listCharges", null);
__decorate([
    (0, common_1.Get)('service-history'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_billing_service_history_dto_1.ListBillingServiceHistoryDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listServiceHistory", null);
__decorate([
    (0, common_1.Get)('reconciliation'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_billing_reconciliation_dto_1.ListBillingReconciliationDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listReconciliation", null);
__decorate([
    (0, common_1.Get)('advances'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listAdvances", null);
__decorate([
    (0, common_1.Post)('advances'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_billing_advance_dto_1.CreateBillingAdvanceDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "createAdvance", null);
__decorate([
    (0, common_1.Patch)('advances/:id/cancel'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "cancelAdvance", null);
__decorate([
    (0, common_1.Post)('advances/:id/apply'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "applyAdvance", null);
__decorate([
    (0, common_1.Post)('advances/:id/restore'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "restoreAdvance", null);
__decorate([
    (0, common_1.Post)('charges'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_billing_charge_dto_1.CreateBillingChargeDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "createCharge", null);
__decorate([
    (0, common_1.Post)('charges/storage'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [generate_storage_charge_dto_1.GenerateStorageChargeDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "generateStorageCharge", null);
__decorate([
    (0, common_1.Patch)('charges/:id/status'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_billing_charge_status_dto_1.UpdateBillingChargeStatusDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "updateChargeStatus", null);
__decorate([
    (0, common_1.Patch)('charges/:id/fbs-logistics-trip'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_fbs_logistics_trip_dto_1.UpdateFbsLogisticsTripDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "updateFbsLogisticsTrip", null);
__decorate([
    (0, common_1.Get)('charges/:id/storage-breakdown'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "getStorageChargeBreakdown", null);
__decorate([
    (0, common_1.Delete)('charges/:id/storage-breakdown/:date'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('date')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "deleteStorageChargeDay", null);
__decorate([
    (0, common_1.Get)('invoices'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_billing_invoices_dto_1.ListBillingInvoicesDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listInvoices", null);
__decorate([
    (0, common_1.Get)('invoices/combined.pdf'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_billing_invoices_dto_1.ListBillingInvoicesDto, Object, Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getCombinedInvoicesPdf", null);
__decorate([
    (0, common_1.Post)('invoices/fbs-merge-preview'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [preview_fbs_invoices_dto_1.PreviewFbsInvoicesDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "previewFbsMerge", null);
__decorate([
    (0, common_1.Get)('invoices/fbs-merge-preview'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('invoiceIds')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "getFbsMergePreview", null);
__decorate([
    (0, common_1.Get)('invoices/:id/recheck'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "recheckInvoice", null);
__decorate([
    (0, common_1.Post)('invoices/:id/primary-processing'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "addInvoicePrimaryProcessing", null);
__decorate([
    (0, common_1.Post)('invoices/fbs-merge'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [merge_fbs_invoices_dto_1.MergeFbsInvoicesDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "mergeFbsInvoices", null);
__decorate([
    (0, common_1.Post)('invoices/merge'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [merge_billing_invoices_dto_1.MergeBillingInvoicesDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "mergeInvoices", null);
__decorate([
    (0, common_1.Get)('invoices/:id/document'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "getInvoiceDocument", null);
__decorate([
    (0, common_1.Get)('invoices/:id/document.pdf'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getInvoiceDocumentPdf", null);
__decorate([
    (0, common_1.Get)('invoices/:id/act'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "getInvoiceActDocument", null);
__decorate([
    (0, common_1.Get)('invoices/:id/act.pdf'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], BillingController.prototype, "getInvoiceActDocumentPdf", null);
__decorate([
    (0, common_1.Post)('invoices'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_billing_invoice_dto_1.CreateBillingInvoiceDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "createInvoice", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/payment-accounts'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "listClientPaymentAccounts", null);
__decorate([
    (0, common_1.Post)('invoices/manual'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_manual_billing_invoice_dto_1.CreateManualBillingInvoiceDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "createManualInvoice", null);
__decorate([
    (0, common_1.Put)('invoices/:id/manual'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_manual_billing_invoice_dto_1.CreateManualBillingInvoiceDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "updateManualInvoice", null);
__decorate([
    (0, common_1.Patch)('invoices/:id/payment-account'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_invoice_payment_account_dto_1.UpdateInvoicePaymentAccountDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "updateInvoicePaymentAccount", null);
__decorate([
    (0, common_1.Patch)('invoices/:id/status'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_billing_invoice_status_dto_1.UpdateBillingInvoiceStatusDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "updateInvoiceStatus", null);
__decorate([
    (0, common_1.Post)('payments'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_billing_payment_dto_1.CreateBillingPaymentDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "createPayment", null);
__decorate([
    (0, common_1.Post)('payments/incoming'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_incoming_payment_dto_1.CreateIncomingPaymentDto, Object]),
    __metadata("design:returntype", void 0)
], BillingController.prototype, "createIncomingPayment", null);
exports.BillingController = BillingController = __decorate([
    (0, swagger_1.ApiTags)('billing'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:read'),
    (0, common_1.Controller)('billing'),
    __metadata("design:paramtypes", [billing_service_1.BillingService,
        billing_document_service_1.BillingDocumentService,
        billing_pdf_service_1.BillingPdfService,
        billing_period_service_1.BillingPeriodService])
], BillingController);
function setPdfHeaders(response, fileName) {
    const asciiName = fileName.replace(/[^\w.-]+/g, '_');
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`);
}
