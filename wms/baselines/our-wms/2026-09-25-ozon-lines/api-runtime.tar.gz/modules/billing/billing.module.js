"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingModule = void 0;
const common_1 = require("@nestjs/common");
const common_module_1 = require("../../common/common.module");
const auth_module_1 = require("../auth/auth.module");
const client_notifications_module_1 = require("../client-notifications/client-notifications.module");
const logistics_module_1 = require("../logistics/logistics.module");
const marketplace_connections_module_1 = require("../marketplace-connections/marketplace-connections.module");
const own_companies_module_1 = require("../own-companies/own-companies.module");
const billing_document_service_1 = require("./billing-document.service");
const billing_pdf_service_1 = require("./billing-pdf.service");
const billing_controller_1 = require("./billing.controller");
const billing_service_1 = require("./billing.service");
const billing_period_service_1 = require("./billing-period.service");
let BillingModule = class BillingModule {
};
exports.BillingModule = BillingModule;
exports.BillingModule = BillingModule = __decorate([
    (0, common_1.Module)({
        imports: [
            auth_module_1.AuthModule,
            common_module_1.CommonModule,
            client_notifications_module_1.ClientNotificationsModule,
            logistics_module_1.LogisticsModule,
            marketplace_connections_module_1.MarketplaceConnectionsModule,
            own_companies_module_1.OwnCompaniesModule,
        ],
        controllers: [billing_controller_1.BillingController],
        providers: [billing_service_1.BillingService, billing_document_service_1.BillingDocumentService, billing_pdf_service_1.BillingPdfService, billing_period_service_1.BillingPeriodService],
        exports: [billing_service_1.BillingService],
    })
], BillingModule);
