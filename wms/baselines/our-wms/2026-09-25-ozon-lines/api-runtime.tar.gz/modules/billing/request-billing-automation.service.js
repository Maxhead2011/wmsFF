"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestBillingAutomationService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const billing_mutation_1 = require("./billing-mutation");
let RequestBillingAutomationService = class RequestBillingAutomationService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async generateForDoneRequest(requestId, user) {
        // FIX: select charges and allocate invoice numbers under the shared financial lock.
        return (0, billing_mutation_1.runBillingMutation)(this.prisma, (db) => (0, billing_mutation_1.withBillingDb)(this, db).generateForDoneRequestLocked(requestId, user));
    }
    async generateForDoneRequestLocked(requestId, user) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: {
                id: true,
                clientId: true,
                warehouseId: true,
                title: true,
                updatedAt: true,
                client: {
                    select: { logisticsInvoiceMode: true },
                },
            },
        });
        if (!request) {
            return { status: 'FAILED', created: 0 };
        }
        const charges = await this.prisma.billingCharge.findMany({
            where: {
                requestId,
                status: client_1.BillingChargeStatus.APPROVED,
                invoiceItems: {
                    none: {
                        invoice: {
                            status: { not: client_1.BillingInvoiceStatus.CANCELLED },
                        },
                    },
                },
            },
            select: {
                id: true,
                clientId: true,
                requestId: true,
                description: true,
                unit: true,
                quantity: true,
                unitPriceRub: true,
                totalRub: true,
                serviceDate: true,
                source: true,
            },
            orderBy: [{ serviceDate: 'asc' }, { createdAt: 'asc' }],
        });
        if (!charges.length) {
            return { status: 'APPLIED', created: 0 };
        }
        const logisticsCharges = charges.filter((charge) => charge.source === client_1.BillingChargeSource.LOGISTICS);
        const serviceCharges = charges.filter((charge) => charge.source !== client_1.BillingChargeSource.LOGISTICS);
        let mainInvoiceId;
        let logisticsInvoiceId;
        const mode = request.client.logisticsInvoiceMode;
        if (mode === client_1.ClientLogisticsInvoiceMode.SAME_INVOICE) {
            const invoice = await this.createDraftInvoice({
                request,
                charges,
                prefix: 'USL',
                source: client_1.BillingInvoiceSource.REQUEST_DONE,
                sourceKey: `request:${request.id}:all-services`,
                user,
            });
            if (invoice) {
                mainInvoiceId = invoice.id;
            }
        }
        else {
            const serviceInvoice = await this.createDraftInvoice({
                request,
                charges: serviceCharges,
                prefix: 'USL',
                source: client_1.BillingInvoiceSource.REQUEST_DONE,
                sourceKey: `request:${request.id}:services`,
                user,
            });
            if (serviceInvoice) {
                mainInvoiceId = serviceInvoice.id;
            }
            if (mode !== client_1.ClientLogisticsInvoiceMode.DISABLED) {
                const logisticsInvoice = await this.createDraftInvoice({
                    request,
                    charges: logisticsCharges,
                    prefix: 'LOG',
                    source: client_1.BillingInvoiceSource.LOGISTICS,
                    sourceKey: `request:${request.id}:logistics`,
                    user,
                });
                if (logisticsInvoice) {
                    logisticsInvoiceId = logisticsInvoice.id;
                }
            }
        }
        return {
            status: 'APPLIED',
            created: [mainInvoiceId, logisticsInvoiceId].filter(Boolean).length,
            mainInvoiceId,
            logisticsInvoiceId,
        };
    }
    async createDraftInvoice(input) {
        if (!input.charges.length) {
            return null;
        }
        const existing = await this.prisma.billingInvoice.findUnique({
            where: { sourceKey: input.sourceKey },
            select: { id: true },
        });
        if (existing) {
            return null;
        }
        const periodFrom = minDate(input.charges.map((charge) => charge.serviceDate)) ?? input.request.updatedAt;
        const periodTo = maxDate(input.charges.map((charge) => charge.serviceDate)) ?? input.request.updatedAt;
        const totalRub = roundMoney(input.charges.reduce((sum, charge) => sum + decimalToNumber(charge.totalRub), 0));
        if (totalRub <= 0) {
            return null;
        }
        const number = await this.nextInvoiceNumber(input.prefix, periodTo);
        return this.prisma.billingInvoice.create({
            data: {
                number,
                clientId: input.request.clientId,
                warehouseId: input.request.warehouseId,
                requestId: input.request.id,
                periodFrom,
                periodTo,
                status: client_1.BillingInvoiceStatus.DRAFT,
                source: input.source,
                sourceKey: input.sourceKey,
                totalRub,
                comment: `Автоматический черновик по заявке ${input.request.title}`,
                createdByUserId: input.user.id,
                items: {
                    create: input.charges.map((charge) => ({
                        chargeId: charge.id,
                        description: charge.description,
                        unit: charge.unit,
                        quantity: charge.quantity,
                        unitPriceRub: charge.unitPriceRub,
                        totalRub: charge.totalRub,
                        serviceDate: charge.serviceDate,
                    })),
                },
            },
            select: { id: true },
        });
    }
    async nextInvoiceNumber(prefix, date) {
        const datePrefix = `${prefix}-${date.getUTCFullYear()}${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
        const count = await this.prisma.billingInvoice.count({
            where: { number: { startsWith: datePrefix } },
        });
        return `${datePrefix}-${String(count + 1).padStart(4, '0')}`;
    }
};
exports.RequestBillingAutomationService = RequestBillingAutomationService;
exports.RequestBillingAutomationService = RequestBillingAutomationService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], RequestBillingAutomationService);
function decimalToNumber(value) {
    return value == null ? 0 : Number(value);
}
function roundMoney(value) {
    return Math.round((value + Number.EPSILON) * 100) / 100;
}
function minDate(dates) {
    return dates.reduce((current, date) => (!current || date < current ? date : current), null);
}
function maxDate(dates) {
    return dates.reduce((current, date) => (!current || date > current ? date : current), null);
}
