"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BILLING_SELLER = void 0;
exports.billingAssetDataUrl = billingAssetDataUrl;
exports.invoiceDisplayNumber = invoiceDisplayNumber;
exports.actDisplayNumber = actDisplayNumber;
exports.formatDate = formatDate;
exports.formatLongDate = formatLongDate;
exports.formatMoney = formatMoney;
exports.formatNumber = formatNumber;
exports.unitLabel = unitLabel;
exports.amountInWordsRub = amountInWordsRub;
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
exports.BILLING_SELLER = {
    shortName: 'ИП Говорова Е. И.',
    fullName: 'Индивидуальный предприниматель Говорова Екатерина Ивановна',
    inn: '616602423102',
    kpp: '',
    ogrn: '324619600095788',
    address: '',
    bankName: 'АО «ТБанк»',
    bankBik: '044525974',
    bankInn: '',
    bankKpp: '',
    bankAccount: '40802810600008484063',
    correspondentAccount: '30101810145250000974',
    paymentCode: '0002820008',
    paymentPurposeCode: 'НК26060000',
    stampDataUrl: null,
    signatureDataUrl: null,
};
const SIGNATURE_PATH = (0, node_path_1.join)(process.cwd(), 'assets', 'billing', 'govorova-signature.png');
const STAMP_PATH = (0, node_path_1.join)(process.cwd(), 'assets', 'billing', 'govorova-stamp.png');
function billingAssetDataUrl(kind) {
    const path = kind === 'signature' ? SIGNATURE_PATH : STAMP_PATH;
    if (!(0, node_fs_1.existsSync)(path)) {
        return null;
    }
    return `data:image/png;base64,${(0, node_fs_1.readFileSync)(path).toString('base64')}`;
}
function invoiceDisplayNumber(number) {
    const match = number.match(/(\d{1,})$/);
    return match ? String(Number(match[1])) : number;
}
function actDisplayNumber(actNumber, invoiceNumber) {
    return invoiceDisplayNumber(actNumber ?? invoiceNumber);
}
function formatDate(value) {
    if (!value) {
        return '-';
    }
    return new Intl.DateTimeFormat('ru-RU').format(new Date(value));
}
function formatLongDate(value) {
    if (!value) {
        return '-';
    }
    return new Intl.DateTimeFormat('ru-RU', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
    }).format(new Date(value));
}
function formatMoney(value) {
    return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2, minimumFractionDigits: 2 }).format(value);
}
function formatNumber(value) {
    return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 3 }).format(value);
}
function unitLabel(unit) {
    const labels = {
        SERVICE: 'усл',
        PIECE: 'шт',
        BOX: 'кор',
        PALLET: 'пал',
        LITER: 'л',
        LITER_DAY: 'л-дн',
        DAY: 'дн',
        HOUR: 'ч',
        ORDER: 'зак.',
    };
    return labels[unit] ?? 'шт';
}
function amountInWordsRub(value) {
    const rubles = Math.floor(Math.abs(value));
    const kopecks = Math.round((Math.abs(value) - rubles) * 100);
    const words = numberToWords(rubles);
    return `${capitalize(words)} ${plural(rubles, ['рубль', 'рубля', 'рублей'])} ${String(kopecks).padStart(2, '0')} ${plural(kopecks, ['копейка', 'копейки', 'копеек'])}`;
}
function numberToWords(value) {
    if (value === 0) {
        return 'ноль';
    }
    const groups = [
        { forms: ['', '', ''], gender: 'm' },
        { forms: ['тысяча', 'тысячи', 'тысяч'], gender: 'f' },
        { forms: ['миллион', 'миллиона', 'миллионов'], gender: 'm' },
        { forms: ['миллиард', 'миллиарда', 'миллиардов'], gender: 'm' },
    ];
    const parts = [];
    let rest = value;
    let groupIndex = 0;
    while (rest > 0 && groupIndex < groups.length) {
        const chunk = rest % 1000;
        if (chunk > 0) {
            const group = groups[groupIndex];
            const chunkWords = threeDigitsToWords(chunk, group.gender);
            if (groupIndex > 0) {
                chunkWords.push(plural(chunk, group.forms));
            }
            parts.unshift(chunkWords.join(' '));
        }
        rest = Math.floor(rest / 1000);
        groupIndex += 1;
    }
    return parts.join(' ');
}
function threeDigitsToWords(value, gender) {
    const hundreds = ['', 'сто', 'двести', 'триста', 'четыреста', 'пятьсот', 'шестьсот', 'семьсот', 'восемьсот', 'девятьсот'];
    const tens = ['', '', 'двадцать', 'тридцать', 'сорок', 'пятьдесят', 'шестьдесят', 'семьдесят', 'восемьдесят', 'девяносто'];
    const teens = [
        'десять',
        'одиннадцать',
        'двенадцать',
        'тринадцать',
        'четырнадцать',
        'пятнадцать',
        'шестнадцать',
        'семнадцать',
        'восемнадцать',
        'девятнадцать',
    ];
    const onesMale = ['', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять'];
    const onesFemale = ['', 'одна', 'две', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять'];
    const words = [];
    words.push(hundreds[Math.floor(value / 100)]);
    const lastTwo = value % 100;
    if (lastTwo >= 10 && lastTwo < 20) {
        words.push(teens[lastTwo - 10]);
    }
    else {
        words.push(tens[Math.floor(lastTwo / 10)]);
        words.push((gender === 'f' ? onesFemale : onesMale)[lastTwo % 10]);
    }
    return words.filter(Boolean);
}
function plural(value, forms) {
    const lastTwo = Math.abs(value) % 100;
    const last = Math.abs(value) % 10;
    if (lastTwo >= 11 && lastTwo <= 14) {
        return forms[2];
    }
    if (last === 1) {
        return forms[0];
    }
    if (last >= 2 && last <= 4) {
        return forms[1];
    }
    return forms[2];
}
function capitalize(value) {
    return value ? value[0].toUpperCase() + value.slice(1) : value;
}
