"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runBillingMutation = runBillingMutation;
exports.isBillingMutationClient = isBillingMutationClient;
exports.isOwnedUnpaidDraft = isOwnedUnpaidDraft;
exports.withBillingDb = withBillingDb;
exports.afterBillingCommit = afterBillingCommit;
const common_1 = require("@nestjs/common");
const node_async_hooks_1 = require("node:async_hooks");
const contexts = new node_async_hooks_1.AsyncLocalStorage();
const clients = new WeakSet();
const logger = new common_1.Logger('BillingMutation');
// FIX: all cooperating invoice/charge/payment writers use the same DB transaction lock,
// including different workers and branches. No process-local mutex or schema migration.
async function runBillingMutation(db, operation) {
    const existing = contexts.getStore();
    if (existing && (existing.root === db || existing.client === db))
        return operation(existing.client);
    const afterCommit = [];
    const result = await db.$transaction(async (tx) => {
        await tx.$queryRaw `SELECT 1 AS locked FROM pg_advisory_xact_lock(1464685395, 1179209294)`;
        // Existing writers contain transaction callbacks. Reuse this transaction instead of
        // opening an independently committed transaction inside the financial operation.
        const client = new Proxy(tx, {
            get(target, property) {
                if (property === '$transaction')
                    return (callback) => {
                        if (typeof callback === 'function')
                            return callback(client);
                        if (Array.isArray(callback))
                            return Promise.all(callback);
                        throw new TypeError('Unsupported nested billing transaction');
                    };
                return Reflect.get(target, property);
            },
        });
        clients.add(client);
        return contexts.run({ root: db, client, afterCommit }, () => operation(client));
    }, { maxWait: 10000, timeout: 60000 });
    // Notifications are deliberately outside the commit; a delivery failure cannot roll
    // back a successful payment or encourage the user to pay the same invoice twice.
    for (const callback of afterCommit)
        await deliver(callback);
    return result;
}
function isBillingMutationClient(db) { return clients.has(db); }
// FIX: another draft is a fixed snapshot, not permission for this automation to recalculate it.
function isOwnedUnpaidDraft(invoice, sourceKey) {
    return invoice.sourceKey === sourceKey && invoice.status === 'DRAFT' &&
        Number(invoice.paidRub) === 0 && invoice._count?.payments === 0;
}
// FIX: isolate transaction DB on a per-call receiver; never mutate the injected singleton.
function withBillingDb(service, client) {
    return Object.create(service, { prisma: { value: client, writable: false, configurable: false } });
}
function afterBillingCommit(callback) {
    const context = contexts.getStore();
    if (context)
        context.afterCommit.push(callback);
    else
        void deliver(callback);
}
async function deliver(callback) {
    try {
        await callback();
    }
    catch {
        logger.warn('Financial operation committed; notification delivery failed.');
    }
}
