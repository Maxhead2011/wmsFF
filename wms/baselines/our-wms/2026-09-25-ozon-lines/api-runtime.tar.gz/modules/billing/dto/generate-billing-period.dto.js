"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateBillingPeriodDto = exports.PreviewBillingPeriodDto = void 0;
const class_validator_1 = require("class-validator");
const billing_period_policy_1 = require("../billing-period-policy");
// ADDED: explicit calendar dates and bounded category selection; no client-supplied prices.
class PreviewBillingPeriodDto {
    clientId;
    periodFrom;
    periodTo;
    categories;
    excludeLukin;
}
exports.PreviewBillingPeriodDto = PreviewBillingPeriodDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], PreviewBillingPeriodDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], PreviewBillingPeriodDto.prototype, "periodFrom", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], PreviewBillingPeriodDto.prototype, "periodTo", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(4),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsIn)(billing_period_policy_1.BILLING_CATEGORIES.filter(c => c !== 'OTHER'), { each: true }),
    __metadata("design:type", Array)
], PreviewBillingPeriodDto.prototype, "categories", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PreviewBillingPeriodDto.prototype, "excludeLukin", void 0);
class GenerateBillingPeriodDto extends PreviewBillingPeriodDto {
    previewHash;
}
exports.GenerateBillingPeriodDto = GenerateBillingPeriodDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^[a-f0-9]{64}$/),
    __metadata("design:type", String)
], GenerateBillingPeriodDto.prototype, "previewHash", void 0);
