"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateClientFbsTurnkeyDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class ClientFbsPrimaryServiceDto {
    serviceId;
    quantityMultiplier;
    matchKeywords;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ClientFbsPrimaryServiceDto.prototype, "serviceId", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.001),
    (0, class_validator_1.Max)(1000),
    __metadata("design:type", Number)
], ClientFbsPrimaryServiceDto.prototype, "quantityMultiplier", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], ClientFbsPrimaryServiceDto.prototype, "matchKeywords", void 0);
class UpdateClientFbsTurnkeyDto {
    enabled;
    unitPriceRub;
    fixedPlusLogisticsEnabled;
    fixedPlusLogisticsUnitPriceRub;
    fixedPlusLogisticsDestination;
    tieredLogisticsEnabled;
    logisticsFreeItemsLimit;
    logisticsCubicMeterLiters;
    logisticsCubicMeterPriceRub;
    logisticsPalletPriceRub;
    primaryProcessingEnabled;
    primaryWhiteUnitPriceRub;
    primaryGrayUnitPriceRub;
    primaryReturnUnitPriceRub;
    primaryServices;
}
exports.UpdateClientFbsTurnkeyDto = UpdateClientFbsTurnkeyDto;
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateClientFbsTurnkeyDto.prototype, "enabled", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "unitPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateClientFbsTurnkeyDto.prototype, "fixedPlusLogisticsEnabled", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "fixedPlusLogisticsUnitPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], UpdateClientFbsTurnkeyDto.prototype, "fixedPlusLogisticsDestination", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateClientFbsTurnkeyDto.prototype, "tieredLogisticsEnabled", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "logisticsFreeItemsLimit", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(1000000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "logisticsCubicMeterLiters", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "logisticsCubicMeterPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "logisticsPalletPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateClientFbsTurnkeyDto.prototype, "primaryProcessingEnabled", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "primaryWhiteUnitPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "primaryGrayUnitPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], UpdateClientFbsTurnkeyDto.prototype, "primaryReturnUnitPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayUnique)((service) => service.serviceId),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => ClientFbsPrimaryServiceDto),
    __metadata("design:type", Array)
], UpdateClientFbsTurnkeyDto.prototype, "primaryServices", void 0);
