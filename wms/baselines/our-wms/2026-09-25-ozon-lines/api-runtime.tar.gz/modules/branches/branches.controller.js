"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BranchesController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const branches_service_1 = require("./branches.service");
let BranchesController = class BranchesController {
    branches;
    constructor(branches) {
        this.branches = branches;
    }
    list(user) {
        return this.branches.list(user);
    }
    create(body, user) {
        return this.branches.create(body, user);
    }
    update(id, body, user) {
        return this.branches.update(id, body, user);
    }
    activate(id, user) {
        return this.branches.activate(id, user);
    }
    assignManager(id, body, user) {
        return this.branches.assignManager(id, body, user);
    }
    stockSummary(clientId, user) {
        return this.branches.stockSummary(clientId, user);
    }
    transfers(clientId, user) {
        return this.branches.listTransfers(clientId, user);
    }
    previewTransferBoxesFile(file, clientId, fromWarehouseId, user) {
        return this.branches.previewTransferBoxesFile(file, clientId, fromWarehouseId, user);
    }
    transfer(body, user) {
        return this.branches.transfer(body, user);
    }
    receiveBox(id, body, user) {
        return this.branches.receiveBox(id, body, user);
    }
};
exports.BranchesController = BranchesController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "list", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/activate'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "activate", null);
__decorate([
    (0, common_1.Put)(':id/manager'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "assignManager", null);
__decorate([
    (0, common_1.Get)('stock-summary'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "stockSummary", null);
__decorate([
    (0, common_1.Get)('transfers'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "transfers", null);
__decorate([
    (0, common_1.Post)('transfers/boxes-xlsx/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({
        description: 'XLSX, XLS или CSV со списком коробов. Поддерживаются колонки «Код короба», «Короб», «ШК короба» и одноколоночный список.',
    }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('fromWarehouseId')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "previewTransferBoxesFile", null);
__decorate([
    (0, common_1.Post)('transfers'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "transfer", null);
__decorate([
    (0, common_1.Post)('transfers/:id/receive-box'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], BranchesController.prototype, "receiveBox", null);
exports.BranchesController = BranchesController = __decorate([
    (0, common_1.Controller)('branches'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('warehouse:read', 'client-requests:write'),
    __metadata("design:paramtypes", [branches_service_1.BranchesService])
], BranchesController);
