"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_BRANCH_TRANSFER_BOXES = void 0;
exports.parseBranchTransferBoxWorkbook = parseBranchTransferBoxWorkbook;
const common_1 = require("@nestjs/common");
const XLSX = __importStar(require("xlsx"));
exports.MAX_BRANCH_TRANSFER_BOXES = 5000;
const headerAliases = new Set([
    'box',
    'boxcode',
    'кодкороба',
    'короб',
    'короба',
    'номеркороба',
    'шккороба',
    'штрихкодкороба',
]);
function parseBranchTransferBoxWorkbook(buffer) {
    let workbook;
    try {
        workbook = XLSX.read(buffer, { type: 'buffer', cellDates: false });
    }
    catch {
        throw new common_1.BadRequestException('Не удалось прочитать файл. Используйте XLSX, XLS или CSV.');
    }
    if (!workbook.SheetNames.length) {
        throw new common_1.BadRequestException('В файле нет листов.');
    }
    for (const sheetName of workbook.SheetNames) {
        const matrix = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            header: 1,
            raw: false,
            defval: '',
            blankrows: false,
        });
        const parsed = parseSheet(matrix);
        if (parsed.boxes.length) {
            return { sheetName, ...parsed };
        }
    }
    throw new common_1.BadRequestException('В файле не найдены коды коробов. Добавьте колонку «Код короба» или одноколоночный список.');
}
function parseSheet(matrix) {
    const header = findHeader(matrix);
    const columnIndex = header?.columnIndex ?? bestBoxColumn(matrix);
    if (columnIndex < 0) {
        return { rows: 0, boxes: [], duplicateCodes: [] };
    }
    const startRow = header ? header.rowIndex + 1 : 0;
    const boxes = [];
    const duplicateCodes = [];
    const seen = new Set();
    let rows = 0;
    for (let rowIndex = startRow; rowIndex < matrix.length; rowIndex += 1) {
        const values = boxCodesFromCell(matrix[rowIndex]?.[columnIndex]);
        if (!values.length)
            continue;
        rows += 1;
        for (const value of values) {
            const normalized = value.toUpperCase();
            if (headerAliases.has(normalizeHeader(value)))
                continue;
            if (seen.has(normalized)) {
                if (!duplicateCodes.includes(value))
                    duplicateCodes.push(value);
                continue;
            }
            seen.add(normalized);
            boxes.push({ code: value, row: rowIndex + 1 });
            if (boxes.length > exports.MAX_BRANCH_TRANSFER_BOXES) {
                throw new common_1.BadRequestException(`В одном файле можно загрузить не больше ${exports.MAX_BRANCH_TRANSFER_BOXES} уникальных коробов.`);
            }
        }
    }
    return { rows, boxes, duplicateCodes };
}
function findHeader(matrix) {
    const rowLimit = Math.min(matrix.length, 25);
    for (let rowIndex = 0; rowIndex < rowLimit; rowIndex += 1) {
        const row = matrix[rowIndex] ?? [];
        const columnLimit = Math.min(row.length, 80);
        for (let columnIndex = 0; columnIndex < columnLimit; columnIndex += 1) {
            if (headerAliases.has(normalizeHeader(row[columnIndex]))) {
                return { rowIndex, columnIndex };
            }
        }
    }
    return null;
}
function bestBoxColumn(matrix) {
    const scores = new Map();
    const rowLimit = Math.min(matrix.length, 250);
    for (let rowIndex = 0; rowIndex < rowLimit; rowIndex += 1) {
        const row = matrix[rowIndex] ?? [];
        const columnLimit = Math.min(row.length, 80);
        for (let columnIndex = 0; columnIndex < columnLimit; columnIndex += 1) {
            const codes = boxCodesFromCell(row[columnIndex]);
            const score = codes.reduce((sum, code) => sum + (looksLikeBoxCode(code) ? 3 : 0), 0);
            if (score)
                scores.set(columnIndex, (scores.get(columnIndex) ?? 0) + score);
        }
    }
    let bestColumn = -1;
    let bestScore = 0;
    for (const [columnIndex, score] of scores) {
        if (score > bestScore) {
            bestColumn = columnIndex;
            bestScore = score;
        }
    }
    return bestColumn;
}
function boxCodesFromCell(value) {
    const source = String(value ?? '').trim();
    if (!source)
        return [];
    return source
        .split(/[\r\n,;]+/)
        .map((part) => part.trim().replace(/^["']|["']$/g, ''))
        .filter(Boolean);
}
function looksLikeBoxCode(value) {
    const normalized = value.trim();
    if (normalized.length < 4 || normalized.length > 120)
        return false;
    return /[A-Za-zА-Яа-я]/.test(normalized) &&
        /[_-]/.test(normalized) &&
        /^[A-Za-zА-Яа-я0-9._/-]+$/.test(normalized);
}
function normalizeHeader(value) {
    return String(value ?? '')
        .trim()
        .toLowerCase()
        .replace(/ё/g, 'е')
        .replace(/[^a-zа-я0-9]+/g, '');
}
