"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdDeviceController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const tsd_fbs_user_decorator_1 = require("./tsd-fbs-user.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const public_decorator_1 = require("../auth/decorators/public.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const resolve_fbs_sync_conflict_dto_1 = require("../marketplace-connections/dto/resolve-fbs-sync-conflict.dto");
const stock_operations_service_1 = require("../stock/stock-operations.service");
const storage_locations_service_1 = require("../warehouse/storage-locations.service");
const create_tsd_device_dto_1 = require("./dto/create-tsd-device.dto");
const login_tsd_device_dto_1 = require("./dto/login-tsd-device.dto");
const tsd_assembly_service_1 = require("./tsd-assembly.service");
const tsd_relabel_print_service_1 = require("./tsd-relabel-print.service");
const tsd_device_service_1 = require("./tsd-device.service");
const tsd_receipt_service_1 = require("./tsd-receipt.service");
const tsd_audit_interceptor_1 = require("./tsd-audit.interceptor");
const sku_collection_service_1 = require("../inventory/sku-collection.service");
const sku_collection_dto_1 = require("../inventory/dto/sku-collection.dto");
const sku_collection_dto_2 = require("../inventory/dto/sku-collection.dto");
const sku_sorting_service_1 = require("../inventory/sku-sorting.service");
let TsdDeviceController = class TsdDeviceController {
    devices;
    assembly;
    relabelPrint;
    receipts;
    marketplace;
    storageLocations;
    stockOperations;
    skuCollections;
    skuSorting;
    constructor(devices, assembly, relabelPrint, receipts, marketplace, storageLocations, stockOperations, skuCollections, skuSorting) {
        this.devices = devices;
        this.assembly = assembly;
        this.relabelPrint = relabelPrint;
        this.receipts = receipts;
        this.marketplace = marketplace;
        this.storageLocations = storageLocations;
        this.stockOperations = stockOperations;
        this.skuCollections = skuCollections;
        this.skuSorting = skuSorting;
    }
    // FIX: a dedicated storage workflow; ordinary FBS/transfers are unchanged.
    startSkuSorting(id, user) {
        return this.skuSorting.start(id, user);
    }
    openSkuSortingSource(id, dto, user) {
        return this.skuSorting.openSource(id, dto.sourceBoxCode, user, dto.recount);
    }
    checkSkuSorting(id, dto, user) {
        return this.skuSorting.check(id, dto, user);
    }
    readySkuSorting(id, dto, user) {
        return this.skuSorting.ready(id, dto, user);
    }
    moveSkuSorting(id, dto, user) {
        return this.skuSorting.move(id, dto, user);
    }
    listSkuCollections(user) {
        return this.skuCollections.list(user);
    }
    getSkuCollection(id, user) {
        return this.skuCollections.get(id, user);
    }
    pickSkuCollection(id, dto, user) {
        return this.skuCollections.pick(id, dto, user);
    }
    receiveSkuCollection(id, dto, user) {
        return this.skuCollections.receive(id, dto, user);
    }
    currentStoragePallet(deviceCode, user) {
        return this.storageLocations.getCurrentTsdPallet(deviceCode || user.deviceCode, user);
    }
    openStoragePallet(body, user) {
        return this.storageLocations.openTsdPallet(body, user);
    }
    scanStoragePalletBox(id, body, user) {
        return this.storageLocations.scanTsdPalletBox(id, body, user);
    }
    restoreStoragePalletBox(id, body, user) {
        return this.storageLocations.restoreTsdPalletBox(id, body, user);
    }
    closeStoragePallet(id, user) {
        return this.storageLocations.closeTsdPallet(id, user);
    }
    deleteStoragePallet(id, user) {
        return this.storageLocations.deleteTsdPallet(id, user);
    }
    listClients(user) {
        return this.devices.listClientsForDevice(user);
    }
    inspectTransferSource(boxCode, user) {
        return this.stockOperations.inspectTsdTransferSource(boxCode, user);
    }
    inspectTransferItem(body, user) {
        return this.stockOperations.inspectTsdTransferItem(body, user);
    }
    executeTransfer(body, user) {
        return this.stockOperations.executeTsdTransfer(body, user);
    }
    // ADDED: explicit preview/confirm; stock permission plus employee/branch checks in the service.
    async previewKizRecount(body, user) {
        const result = await this.stockOperations.previewTsdKizRecount(body, user);
        if (result.state !== 'ADMIN_REVIEW_REQUIRED')
            return result;
        return this.marketplace.adminTsdKizRecount(body, user, false, tx => this.stockOperations.loadAdminKizRecountInput(body, user, tx), (tx, ids) => this.stockOperations.applyAdminKizRecount(tx, body, user, ids));
    }
    async confirmKizRecount(body, user) {
        if (body.adminRelease === true)
            return this.marketplace.adminTsdKizRecount(body, user, true, tx => this.stockOperations.loadAdminKizRecountInput(body, user, tx), (tx, ids) => this.stockOperations.applyAdminKizRecount(tx, body, user, ids));
        const result = await this.stockOperations.confirmTsdKizRecount(body, user);
        if (result.state === 'RECOUNT_APPLIED' && 'affectedRequestIds' in result) {
            try {
                for (const requestId of result.affectedRequestIds ?? [])
                    await this.marketplace.repairFbsRequestSelection(requestId, user);
            }
            catch {
                // FIX: retain the same confirmation on the TSD; the count was committed, only routes need retry.
                throw new common_1.ServiceUnavailableException('Сверка сохранена, но маршруты пока не обновлены. Повторите подтверждение: остатки второй раз не изменятся.');
            }
        }
        return result;
    }
    executeTransferBatch(body, user) {
        return this.stockOperations.executeTsdTransferBatch(body, user);
    }
    getNextFbsAssembly(deviceCode, requestId, user) {
        return this.marketplace.getNextFbsTsdAssembly(deviceCode, user, requestId);
    }
    listFbsAssemblyRequests(deviceCode, archive, user) {
        return this.marketplace.listFbsTsdRequests(deviceCode, user, archive);
    }
    // FIX: print the target SKU directly from the current FBS relabel step.
    fbsRelabelPrintStations(id, user) {
        return this.relabelPrint.fbsStations(id, user);
    }
    fbsRelabelPrint(id, body, user) {
        return this.relabelPrint.fbsCreate(id, body, user);
    }
    fbsRelabelPrintStatus(id, printId, user) {
        return this.relabelPrint.fbsStatus(id, printId, user);
    }
    getFbsCargoPacking(deviceCode, user) {
        return this.marketplace.getFbsCargoPackingQueue(deviceCode, user);
    }
    openFbsCargoPacking(body, user) {
        return this.marketplace.openFbsCargoPacking(body, user);
    }
    scanFbsCargoOrder(id, body, user) {
        return this.marketplace.scanFbsCargoOrder(id, body, user);
    }
    undoLastFbsCargoOrder(id, user) {
        return this.marketplace.undoLastFbsCargoOrder(id, user);
    }
    cancelFbsCargoPacking(id, user) {
        return this.marketplace.cancelFbsCargoPacking(id, user);
    }
    closeFbsCargoPacking(id, user) {
        return this.marketplace.closeFbsCargoPacking(id, user);
    }
    scanFbsBox(id, body, user) {
        return this.marketplace.scanFbsTsdBox(id, body, user);
    }
    scanFbsCode(id, body, user) {
        return this.marketplace.scanFbsTsdCode(id, body, user);
    }
    scanFbsBarcode(id, body, user) {
        return this.marketplace.scanFbsTsdBarcode(id, body, user);
    }
    scanFbsKiz(id, body, user) {
        return this.marketplace.scanFbsTsdKiz(id, body, user);
    }
    // FIX: returning from a KIZ discrepancy requires server verification, including after a TSD restart.
    validateFbsStockAudit(id, body, user) {
        return this.marketplace.validateFbsTsdStockAudit(id, body, user);
    }
    undoFbsKiz(id, user) {
        return this.marketplace.undoFbsTsdKiz(id, user);
    }
    completeFbsAssembly(id, user) {
        return this.marketplace.completeFbsTsdAssembly(id, user);
    }
    releaseFbsAssembly(id, user) {
        return this.marketplace.releaseFbsTsdAssembly(id, user);
    }
    listAssemblyRequests(user, workflow) {
        return this.assembly.listActiveRequests(user, workflow);
    }
    listActiveAssemblyRequests(user) {
        return this.assembly.listActiveRequests(user);
    }
    getAssemblyRequest(id, user) {
        // FIX: avoid building the legacy instruction when opening FBO on a terminal.
        return this.assembly.getDeviceRequestPlan(id, user);
    }
    resolveFbsKizConflict(id, taskId, user) {
        return this.marketplace.resolveFbsKizConflict(id, taskId, user);
    }
    resolveFbsSyncConflict(id, taskId, body, user) {
        return this.marketplace.resolveFbsSyncConflict(id, taskId, body, user);
    }
    resetFbsAssemblyOrder(id, taskId, user) {
        return this.marketplace.resetFbsAssemblyOrder(id, taskId, user);
    }
    markFbsAssemblyPackedWithoutSource(id, taskId, user) {
        return this.marketplace.markFbsAssemblyPackedWithoutSource(id, taskId, user);
    }
    restoreFbsRescanFromWildberries(id, taskId, user) {
        return this.marketplace.restoreFbsRescanFromWildberries(id, taskId, user);
    }
    async downloadOutgoingBoxes(id, user, response) {
        const file = await this.assembly.getOutgoingBoxesXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    async downloadOutgoingContents(id, user, response) {
        const file = await this.assembly.getOutgoingContentsXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    async downloadMovements(id, user, response) {
        const file = await this.assembly.getMovementsXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    getBoxSearch(id, query, user) {
        if (hasScanPayload(query)) {
            return this.assembly.handleStageAction(id, 'box-search', 'scan', mergeActionPayload(undefined, query), user);
        }
        return this.assembly.getRequestStage(id, 'box-search', user);
    }
    scanBoxSearch(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'box-search', 'scan', mergeActionPayload(body, query), user);
    }
    scanBoxSearchByGet(id, query, user) {
        return this.assembly.handleStageAction(id, 'box-search', 'scan', mergeActionPayload(undefined, query), user);
    }
    scanBoxSearchByPostPath(id, code, body, query, user) {
        return this.assembly.handleStageAction(id, 'box-search', 'scan', mergeActionPayload(body, query, { code }), user);
    }
    scanBoxSearchByGetPath(id, code, query, user) {
        return this.assembly.handleStageAction(id, 'box-search', 'scan', mergeActionPayload(undefined, query, { code }), user);
    }
    scanBoxSearchByLegacyPostPath(id, code, body, query, user) {
        return this.assembly.handleStageAction(id, 'box-search', 'scan', mergeActionPayload(body, query, { code }), user);
    }
    scanBoxSearchByLegacyGetPath(id, code, query, user) {
        return this.assembly.handleStageAction(id, 'box-search', 'scan', mergeActionPayload(undefined, query, { code }), user);
    }
    getRelabel(id, user) {
        return this.assembly.getRequestStage(id, 'relabel', user);
    }
    // FIX: printing a target label is separate from the verifying scan and never completes a relabel task.
    listRelabelPrintStations(id, user) {
        return this.relabelPrint.stations(id, user);
    }
    printRelabelTarget(id, body, user) {
        return this.relabelPrint.create(id, body, user);
    }
    relabelPrintStatus(id, printId, user) {
        return this.relabelPrint.status(id, printId, user);
    }
    scanRelabelSource(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'relabel', 'scan-source', mergeActionPayload(body, query), user);
    }
    scanRelabelTarget(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'relabel', 'scan-target', mergeActionPayload(body, query), user);
    }
    getMoves(id, user) {
        return this.assembly.getRequestStage(id, 'moves', user);
    }
    scanMoveTargetBox(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'moves', 'target-box', mergeActionPayload(body, query), user);
    }
    scanMoveItem(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'moves', 'scan-item', mergeActionPayload(body, query), user);
    }
    finishMoves(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'moves', 'finish', mergeActionPayload(body, query), user);
    }
    getBoxlessPacking(id, user) {
        return this.assembly.getRequestStage(id, 'boxless-packing', user);
    }
    openBoxlessBox(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'boxless-packing', 'open-box', mergeActionPayload(body, query), user);
    }
    scanBoxlessItem(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'boxless-packing', 'scan-item', mergeActionPayload(body, query), user);
    }
    closeBoxlessBox(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'boxless-packing', 'close-box', mergeActionPayload(body, query), user);
    }
    finishBoxlessPacking(id, body, query, user) {
        return this.assembly.handleStageAction(id, 'boxless-packing', 'finish', mergeActionPayload(body, query), user);
    }
    findSkuByBarcode(clientId, barcode, user) {
        return this.assembly.findSkuByBarcode({ clientId, barcode }, user);
    }
    checkReceiptKiz(clientId, kiz, user) {
        return this.receipts.checkKiz(clientId, kiz, user);
    }
    openReceiptBox(body, user) {
        return this.receipts.openBox(body, user);
    }
    listDevices() {
        return this.devices.listDevices();
    }
    monitorHeartbeat(body, user) {
        return this.devices.recordMonitorHeartbeat(body, user);
    }
    monitorError(body, user) {
        return this.devices.recordMonitorError(body, user);
    }
    // ADDED: only explicit OK on the recipient TSD records readAt.
    acknowledgeMonitorMessage(id, user) {
        return this.devices.acknowledgeMonitorMessage(id, user);
    }
    uploadMonitorErrorScreenshot(id, file, user) {
        return this.devices.attachMonitorErrorScreenshot(id, file, user);
    }
    createDevice(dto) {
        return this.devices.createDevice(dto);
    }
    login(dto) {
        return this.devices.login(dto);
    }
};
exports.TsdDeviceController = TsdDeviceController;
__decorate([
    (0, common_1.Post)('sku-collections/:id/sorting/start'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "startSkuSorting", null);
__decorate([
    (0, common_1.Post)('sku-collections/:id/sorting/source'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, sku_collection_dto_2.OpenSkuSortingSourceDto, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "openSkuSortingSource", null);
__decorate([
    (0, common_1.Post)('sku-collections/:id/sorting/check'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, sku_collection_dto_2.CheckSkuSortingDto, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "checkSkuSorting", null);
__decorate([
    (0, common_1.Post)('sku-collections/:id/sorting/ready'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, sku_collection_dto_2.ReadySkuSortingSourceDto, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "readySkuSorting", null);
__decorate([
    (0, common_1.Post)('sku-collections/:id/sorting/move'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, sku_collection_dto_2.MoveSkuSortingDto, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "moveSkuSorting", null);
__decorate([
    (0, common_1.Get)('sku-collections'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "listSkuCollections", null);
__decorate([
    (0, common_1.Get)('sku-collections/:id'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getSkuCollection", null);
__decorate([
    (0, common_1.Post)('sku-collections/:id/pick'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, sku_collection_dto_1.ScanSkuCollectionPickDto, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "pickSkuCollection", null);
__decorate([
    (0, common_1.Post)('sku-collections/:id/receive'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, sku_collection_dto_1.ScanSkuCollectionReceiptDto, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "receiveSkuCollection", null);
__decorate([
    (0, common_1.Get)('storage-pallet/current'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('deviceCode')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "currentStoragePallet", null);
__decorate([
    (0, common_1.Post)('storage-pallet/open'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "openStoragePallet", null);
__decorate([
    (0, common_1.Post)('storage-pallet/:id/scan-box'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanStoragePalletBox", null);
__decorate([
    (0, common_1.Post)('storage-pallet/:id/restore-box'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "restoreStoragePalletBox", null);
__decorate([
    (0, common_1.Post)('storage-pallet/:id/close'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "closeStoragePallet", null);
__decorate([
    (0, common_1.Delete)('storage-pallet/:id'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "deleteStoragePallet", null);
__decorate([
    (0, common_1.Get)('clients'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "listClients", null);
__decorate([
    (0, common_1.Get)('transfers/source'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('boxCode')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "inspectTransferSource", null);
__decorate([
    (0, common_1.Post)('transfers/item'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "inspectTransferItem", null);
__decorate([
    (0, common_1.Post)('transfers/execute'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "executeTransfer", null);
__decorate([
    (0, common_1.Post)('transfers/kiz-recount/preview'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TsdDeviceController.prototype, "previewKizRecount", null);
__decorate([
    (0, common_1.Post)('transfers/kiz-recount/confirm'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TsdDeviceController.prototype, "confirmKizRecount", null);
__decorate([
    (0, common_1.Post)('transfers/execute-batch'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "executeTransferBatch", null);
__decorate([
    (0, common_1.Get)('fbs/next'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('deviceCode')),
    __param(1, (0, common_1.Query)('requestId')),
    __param(2, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getNextFbsAssembly", null);
__decorate([
    (0, common_1.Get)('fbs/requests'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('deviceCode')),
    __param(1, (0, common_1.Query)('archive')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "listFbsAssemblyRequests", null);
__decorate([
    (0, common_1.Get)('fbs/tasks/:id/relabel/print-stations'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "fbsRelabelPrintStations", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/relabel/print'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "fbsRelabelPrint", null);
__decorate([
    (0, common_1.Get)('fbs/tasks/:id/relabel/print/:printId'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('printId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "fbsRelabelPrintStatus", null);
__decorate([
    (0, common_1.Get)('fbs/cargo'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('deviceCode')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getFbsCargoPacking", null);
__decorate([
    (0, common_1.Post)('fbs/cargo/open'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "openFbsCargoPacking", null);
__decorate([
    (0, common_1.Post)('fbs/cargo/:id/scan-order'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanFbsCargoOrder", null);
__decorate([
    (0, common_1.Post)('fbs/cargo/:id/undo-last'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "undoLastFbsCargoOrder", null);
__decorate([
    (0, common_1.Post)('fbs/cargo/:id/cancel'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "cancelFbsCargoPacking", null);
__decorate([
    (0, common_1.Post)('fbs/cargo/:id/close'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "closeFbsCargoPacking", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/scan-box'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanFbsBox", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/scan'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanFbsCode", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/scan-barcode'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanFbsBarcode", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/scan-kiz'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanFbsKiz", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/validate-stock-audit'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "validateFbsStockAudit", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/undo-kiz'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "undoFbsKiz", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/complete'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "completeFbsAssembly", null);
__decorate([
    (0, common_1.Post)('fbs/tasks/:id/release'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, tsd_fbs_user_decorator_1.CurrentFbsTsdUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "releaseFbsAssembly", null);
__decorate([
    (0, common_1.Get)('requests'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('workflow')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "listAssemblyRequests", null);
__decorate([
    (0, common_1.Get)('requests/active'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "listActiveAssemblyRequests", null);
__decorate([
    (0, common_1.Get)('requests/:id'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getAssemblyRequest", null);
__decorate([
    (0, common_1.Post)('requests/:id/fbs-kiz-conflicts/:taskId/resolve'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('taskId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "resolveFbsKizConflict", null);
__decorate([
    (0, common_1.Post)('requests/:id/fbs-sync-conflicts/:taskId/resolve'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('taskId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, resolve_fbs_sync_conflict_dto_1.ResolveFbsSyncConflictDto, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "resolveFbsSyncConflict", null);
__decorate([
    (0, common_1.Post)('requests/:id/fbs-assembly/:taskId/reset'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('taskId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "resetFbsAssemblyOrder", null);
__decorate([
    (0, common_1.Post)('requests/:id/fbs-assembly/:taskId/packed-without-source'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('taskId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "markFbsAssemblyPackedWithoutSource", null);
__decorate([
    (0, common_1.Post)('requests/:id/fbs-rescan/:taskId/restore-from-wb'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('taskId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "restoreFbsRescanFromWildberries", null);
__decorate([
    (0, common_1.Get)('requests/:id/outgoing-boxes.xlsx'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TsdDeviceController.prototype, "downloadOutgoingBoxes", null);
__decorate([
    (0, common_1.Get)('requests/:id/outgoing-contents.xlsx'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TsdDeviceController.prototype, "downloadOutgoingContents", null);
__decorate([
    (0, common_1.Get)('requests/:id/movements.xlsx'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TsdDeviceController.prototype, "downloadMovements", null);
__decorate([
    (0, common_1.Get)('requests/:id/box-search'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getBoxSearch", null);
__decorate([
    (0, common_1.Post)('requests/:id/box-search/scan'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanBoxSearch", null);
__decorate([
    (0, common_1.Get)('requests/:id/box-search/scan'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanBoxSearchByGet", null);
__decorate([
    (0, common_1.Post)('requests/:id/box-search/scan/:code'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('code')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, common_1.Query)()),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanBoxSearchByPostPath", null);
__decorate([
    (0, common_1.Get)('requests/:id/box-search/scan/:code'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('code')),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanBoxSearchByGetPath", null);
__decorate([
    (0, common_1.Post)('requests/:id/box-search/:code'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('code')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, common_1.Query)()),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanBoxSearchByLegacyPostPath", null);
__decorate([
    (0, common_1.Get)('requests/:id/box-search/:code'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('code')),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanBoxSearchByLegacyGetPath", null);
__decorate([
    (0, common_1.Get)('requests/:id/relabel'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getRelabel", null);
__decorate([
    (0, common_1.Get)('requests/:id/relabel/print-stations'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "listRelabelPrintStations", null);
__decorate([
    (0, common_1.Post)('requests/:id/relabel/print'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "printRelabelTarget", null);
__decorate([
    (0, common_1.Get)('requests/:id/relabel/print/:printId'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('printId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "relabelPrintStatus", null);
__decorate([
    (0, common_1.Post)('requests/:id/relabel/scan-source'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanRelabelSource", null);
__decorate([
    (0, common_1.Post)('requests/:id/relabel/scan-target'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanRelabelTarget", null);
__decorate([
    (0, common_1.Get)('requests/:id/moves'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getMoves", null);
__decorate([
    (0, common_1.Post)('requests/:id/moves/target-box'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanMoveTargetBox", null);
__decorate([
    (0, common_1.Post)('requests/:id/moves/scan-item'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanMoveItem", null);
__decorate([
    (0, common_1.Post)('requests/:id/moves/finish'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "finishMoves", null);
__decorate([
    (0, common_1.Get)('requests/:id/boxless-packing'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "getBoxlessPacking", null);
__decorate([
    (0, common_1.Post)('requests/:id/boxless-packing/open-box'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "openBoxlessBox", null);
__decorate([
    (0, common_1.Post)('requests/:id/boxless-packing/scan-item'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "scanBoxlessItem", null);
__decorate([
    (0, common_1.Post)('requests/:id/boxless-packing/close-box'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "closeBoxlessBox", null);
__decorate([
    (0, common_1.Post)('requests/:id/boxless-packing/finish'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Query)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "finishBoxlessPacking", null);
__decorate([
    (0, common_1.Get)('sku-by-barcode'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('barcode')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "findSkuByBarcode", null);
__decorate([
    (0, common_1.Get)('receipts/check-kiz'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, common_1.Query)('kiz')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "checkReceiptKiz", null);
__decorate([
    (0, common_1.Post)('receipts/open-box'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "openReceiptBox", null);
__decorate([
    (0, common_1.Get)('devices'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('users:read'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "listDevices", null);
__decorate([
    (0, common_1.Post)('monitor/heartbeat'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "monitorHeartbeat", null);
__decorate([
    (0, common_1.Post)('monitor/error'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "monitorError", null);
__decorate([
    (0, common_1.Post)('monitor/messages/:id/read'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "acknowledgeMonitorMessage", null);
__decorate([
    (0, common_1.Post)('monitor/error/:id/screenshot'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('screenshot', { limits: { fileSize: 750 * 1024 } })),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "uploadMonitorErrorScreenshot", null);
__decorate([
    (0, common_1.Post)('devices'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('users:write'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_tsd_device_dto_1.CreateTsdDeviceDto]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "createDevice", null);
__decorate([
    (0, common_1.Post)('login'),
    (0, public_decorator_1.Public)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [login_tsd_device_dto_1.LoginTsdDeviceDto]),
    __metadata("design:returntype", void 0)
], TsdDeviceController.prototype, "login", null);
exports.TsdDeviceController = TsdDeviceController = __decorate([
    (0, swagger_1.ApiTags)('tsd'),
    (0, common_1.UseInterceptors)(tsd_audit_interceptor_1.TsdAuditInterceptor),
    (0, common_1.Controller)('tsd'),
    __metadata("design:paramtypes", [tsd_device_service_1.TsdDeviceService,
        tsd_assembly_service_1.TsdAssemblyService,
        tsd_relabel_print_service_1.TsdRelabelPrintService,
        tsd_receipt_service_1.TsdReceiptService,
        marketplace_connections_service_1.MarketplaceConnectionsService,
        storage_locations_service_1.StorageLocationsService,
        stock_operations_service_1.StockOperationsService,
        sku_collection_service_1.SkuCollectionService,
        sku_sorting_service_1.SkuSortingService])
], TsdDeviceController);
function mergeActionPayload(body, query, extra = undefined) {
    const payload = {
        ...(query ?? {}),
        ...(extra ?? {}),
    };
    if (body && typeof body === 'object' && !Array.isArray(body)) {
        return {
            ...payload,
            ...body,
        };
    }
    if (typeof body === 'string' && body.trim()) {
        return {
            ...payload,
            scan: body.trim(),
        };
    }
    return payload;
}
function hasScanPayload(query) {
    if (!query) {
        return false;
    }
    const ignored = new Set(['deviceCode', 'device', 'token', 'stage', 'action', 'ts', 'timestamp']);
    return Object.keys(query).some((key) => !ignored.has(key) && query[key] != null && String(query[key]).trim() !== '');
}
function contentDisposition(fileName) {
    const asciiName = fileName.replace(/[^\x20-\x7E]+/g, '_').replace(/"/g, '');
    return `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`;
}
