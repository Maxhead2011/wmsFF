"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdRelabelPrintService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const tsd_assembly_service_1 = require("./tsd-assembly.service");
const tsd_relabel_label_1 = require("./tsd-relabel-label");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const RELABEL_SOURCE = 'TSD_RELABEL';
function required(value, name) {
    if (typeof value !== 'string' || !value.trim() || value.length > 160) {
        throw new common_1.BadRequestException(`Укажите ${name}.`);
    }
    return value.trim();
}
let TsdRelabelPrintService = class TsdRelabelPrintService {
    prisma;
    assembly;
    marketplace;
    constructor(prisma, assembly, marketplace) {
        this.prisma = prisma;
        this.assembly = assembly;
        this.marketplace = marketplace;
    }
    async stations(requestId, user) {
        await this.assembly.getRequestPlan(requestId, user);
        return this.availableStations();
    }
    availableStations() {
        // FIX: offline stations cannot receive a new print job that might run much later.
        return this.prisma.fbsPrintStation.findMany({
            where: { enabled: true, labelWidthMm: 58, labelHeightMm: 40,
                lastSeenAt: { gt: new Date(Date.now() - 45_000) } },
            select: { id: true, name: true, printerName: true }, orderBy: { name: 'asc' },
        });
    }
    // FIX: the FBS picking flow uses its own task, not the separate request relabel stage.
    async fbsStations(taskId, user) {
        await this.marketplace.getFbsTsdRelabelPrintContext(taskId, user);
        return this.availableStations();
    }
    async fbsCreate(taskId, body, user) {
        const printId = required(body.printId, 'идентификатор печати');
        if (!/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(printId))
            throw new common_1.BadRequestException('Неверный идентификатор печати.');
        const stationId = required(body.stationId, 'станцию печати');
        const newBarcode = required(body.newBarcode, 'новый ШК');
        const task = await this.marketplace.getFbsTsdRelabelPrintContext(taskId, user);
        if (!task.targetBarcodes.includes(newBarcode)) {
            throw new common_1.ConflictException('Новый ШК не принадлежит целевому товару этого задания.');
        }
        const prior = await this.prisma.fbsPrintJob.findUnique({ where: { historyId: printId } });
        if (prior)
            return this.ownedFbsStatus(prior, task, stationId, newBarcode, user);
        const station = await this.prisma.fbsPrintStation.findFirst({ where: {
                id: stationId, enabled: true, labelWidthMm: 58, labelHeightMm: 40,
                lastSeenAt: { gt: new Date(Date.now() - 45_000) },
            } });
        if (!station)
            throw new common_1.ConflictException('Печатная станция не на связи или её формат не 58 × 40 мм.');
        const [product, client, request] = await Promise.all([
            this.prisma.sku.findUnique({ where: { id: task.skuId }, select: {
                    id: true, name: true, article: true, color: true, size: true, brand: true, clientId: true,
                } }),
            this.prisma.client.findUnique({ where: { id: task.clientId }, select: { name: true } }),
            this.prisma.clientRequest.findUniqueOrThrow({ where: { id: task.requestId }, select: { number: true } }),
        ]);
        if (!product || product.clientId !== task.clientId || !client) {
            throw new common_1.ConflictException('Целевая карточка клиента недоступна.');
        }
        const imageBase64 = await (0, tsd_relabel_label_1.buildTsdRelabelLabel)(newBarcode, product, client.name);
        try {
            const job = await this.prisma.$transaction(async (tx) => {
                const created = await tx.fbsPrintJob.create({ data: {
                        stationId, historyId: printId, assemblyId: taskId, requestId: task.requestId,
                        requestNumber: request.number, orderId: `RELABEL:${request.number}`,
                        kiz: newBarcode, warehouseName: client.name, productName: product.name,
                        stickerCode: newBarcode, stickerMime: 'image/png', stickerBase64: imageBase64,
                        source: RELABEL_SOURCE, requestedById: user.id, requestedBy: user.name,
                        deviceCode: user.deviceCode ?? null,
                    } });
                await tx.auditLog.create({ data: { userId: user.id, action: 'TSD_FBS_RELABEL_TWO_LABELS_QUEUED',
                        entity: 'FbsPrintJob', entityId: created.id,
                        payload: { taskId, requestId: task.requestId, stationId, oldBarcode: task.sourceBarcode,
                            newBarcode, copies: 2 } } });
                return created;
            });
            return this.ownedFbsStatus(job, task, stationId, newBarcode, user);
        }
        catch (error) {
            if (!(error instanceof client_1.Prisma.PrismaClientKnownRequestError) || error.code !== 'P2002')
                throw error;
            const existing = await this.prisma.fbsPrintJob.findUnique({ where: { historyId: printId } });
            if (!existing)
                throw error;
            return this.ownedFbsStatus(existing, task, stationId, newBarcode, user);
        }
    }
    async fbsStatus(taskId, printId, user) {
        const task = await this.marketplace.getFbsTsdRelabelPrintContext(taskId, user);
        const job = await this.prisma.fbsPrintJob.findUnique({ where: { historyId: printId } });
        if (!job || job.source !== RELABEL_SOURCE || job.assemblyId !== taskId ||
            job.requestId !== task.requestId || job.requestedById !== user.id) {
            throw new common_1.NotFoundException('Задание печати не найдено.');
        }
        return { printId, status: job.status, stationId: job.stationId, barcode: job.stickerCode,
            error: job.errorMessage, printedAt: job.printedAt };
    }
    ownedFbsStatus(job, task, stationId, barcode, user) {
        if (job.source !== RELABEL_SOURCE || job.assemblyId !== task.taskId || job.requestId !== task.requestId ||
            job.stationId !== stationId || job.stickerCode !== barcode || job.requestedById !== user.id) {
            throw new common_1.ConflictException('Этот идентификатор уже использован для другой печати.');
        }
        return { printId: job.historyId, status: job.status, stationId, barcode,
            error: job.errorMessage, printedAt: job.printedAt };
    }
    async create(requestId, body, user) {
        const printId = required(body.printId, 'идентификатор печати');
        if (!/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(printId))
            throw new common_1.BadRequestException('Неверный идентификатор печати.');
        const stationId = required(body.stationId, 'станцию печати');
        const sourceBox = required(body.sourceBox, 'исходный короб');
        const oldBarcode = required(body.oldBarcode, 'старый ШК');
        const newBarcode = required(body.newBarcode, 'новый ШК');
        const size = typeof body.size === 'string' ? body.size.trim() : '';
        const plan = await this.assembly.getRequestPlan(requestId, user);
        const task = plan.relabelTasks.find(row => row.sourceBox === sourceBox && row.oldBarcode === oldBarcode &&
            row.newBarcode === newBarcode && (row.size ?? '') === size && row.remainingQuantity > 0);
        if (!task)
            throw new common_1.ConflictException('Задание переклейки изменилось. Обновите заявку и отсканируйте исходный товар.');
        const prior = await this.prisma.fbsPrintJob.findUnique({ where: { historyId: printId } });
        if (prior)
            return this.ownedStatus(prior, requestId, stationId, newBarcode, user);
        const station = await this.prisma.fbsPrintStation.findFirst({ where: {
                id: stationId, enabled: true, labelWidthMm: 58, labelHeightMm: 40,
                lastSeenAt: { gt: new Date(Date.now() - 45_000) },
            } });
        if (!station)
            throw new common_1.ConflictException('Печатная станция не на связи или её формат не 58 × 40 мм.');
        const products = await this.prisma.sku.findMany({ where: {
                clientId: plan.client.id, barcodes: { some: { value: newBarcode } },
            }, select: { id: true, name: true, article: true, color: true, size: true, brand: true }, take: 2 });
        if (products.length !== 1)
            throw new common_1.ConflictException('Целевой ШК не соответствует одной карточке клиента. Проверьте соответствие переклейки.');
        const imageBase64 = await (0, tsd_relabel_label_1.buildTsdRelabelLabel)(newBarcode, products[0], plan.client.name);
        const request = await this.prisma.clientRequest.findUniqueOrThrow({ where: { id: requestId }, select: { number: true } });
        try {
            const job = await this.prisma.$transaction(async (tx) => {
                const created = await tx.fbsPrintJob.create({ data: {
                        stationId, historyId: printId, assemblyId: requestId, requestId,
                        requestNumber: request.number, orderId: `RELABEL:${request.number}`,
                        kiz: newBarcode, warehouseName: plan.client.name, productName: products[0].name,
                        stickerCode: newBarcode, stickerMime: 'image/png', stickerBase64: imageBase64,
                        source: RELABEL_SOURCE, requestedById: user.id, requestedBy: user.name,
                        deviceCode: user.deviceCode ?? null,
                    } });
                await tx.auditLog.create({ data: { userId: user.id, action: 'TSD_RELABEL_TWO_LABELS_QUEUED',
                        entity: 'FbsPrintJob', entityId: created.id,
                        payload: { requestId, stationId, sourceBox, oldBarcode, newBarcode, size, copies: 2 } } });
                return created;
            });
            return this.ownedStatus(job, requestId, stationId, newBarcode, user);
        }
        catch (error) {
            if (!(error instanceof client_1.Prisma.PrismaClientKnownRequestError) || error.code !== 'P2002')
                throw error;
            const existing = await this.prisma.fbsPrintJob.findUnique({ where: { historyId: printId } });
            if (!existing)
                throw error;
            return this.ownedStatus(existing, requestId, stationId, newBarcode, user);
        }
    }
    async status(requestId, printId, user) {
        await this.assembly.getRequestPlan(requestId, user);
        const job = await this.prisma.fbsPrintJob.findUnique({ where: { historyId: printId } });
        if (!job || job.source !== RELABEL_SOURCE || job.requestId !== requestId || job.requestedById !== user.id) {
            throw new common_1.NotFoundException('Задание переклейки не найдено.');
        }
        return { printId, status: job.status, stationId: job.stationId, barcode: job.stickerCode,
            error: job.errorMessage, printedAt: job.printedAt };
    }
    ownedStatus(job, requestId, stationId, barcode, user) {
        if (job.source !== RELABEL_SOURCE || job.requestId !== requestId || job.stationId !== stationId ||
            job.stickerCode !== barcode || job.requestedById !== user.id) {
            throw new common_1.ConflictException('Этот идентификатор уже использован для другой печати.');
        }
        return { printId: job.historyId, status: job.status, stationId, barcode,
            error: job.errorMessage, printedAt: job.printedAt };
    }
};
exports.TsdRelabelPrintService = TsdRelabelPrintService;
exports.TsdRelabelPrintService = TsdRelabelPrintService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, tsd_assembly_service_1.TsdAssemblyService,
        marketplace_connections_service_1.MarketplaceConnectionsService])
], TsdRelabelPrintService);
