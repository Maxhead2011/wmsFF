"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fboTwoStageEnabled = exports.fboClosePickEnabled = void 0;
exports.closedFboItems = closedFboItems;
exports.hasLegacyFboProgress = hasLegacyFboProgress;
exports.isFboTwoStageRequest = isFboTwoStageRequest;
exports.remainingFboLines = remainingFboLines;
exports.wholeBoxDecision = wholeBoxDecision;
exports.prioritizeFboWholeBoxes = prioritizeFboWholeBoxes;
const common_1 = require("@nestjs/common");
const fboClosePickEnabled = () => process.env.WMS_FBO_CLOSE_PICK_ENABLED === 'true';
exports.fboClosePickEnabled = fboClosePickEnabled;
// FIX: preserve requested quantities while all later stock operations use the frozen physical target.
// A recorded closure remains authoritative even if the rollout flag is subsequently disabled.
function closedFboItems(items, closure) {
    if (closure == null)
        return items;
    const value = closure;
    if (value.version !== 1 || !value.quantities || Array.isArray(value.quantities)
        || Object.keys(value.quantities).length !== items.length
        || items.some(i => !Number.isSafeInteger(value.quantities[i.id]) || value.quantities[i.id] < 0 || value.quantities[i.id] > i.quantity))
        throw new common_1.ConflictException('Результат завершения отбора не совпадает с заявкой. Требуется сверка.');
    return items.map(i => ({ ...i, quantity: value.quantities[i.id] }));
}
const fboTwoStageEnabled = () => process.env.WMS_FBO_TWO_STAGE_ENABLED === 'true';
exports.fboTwoStageEnabled = fboTwoStageEnabled;
async function hasLegacyFboProgress(db, requestId) {
    return !!(await db.stockMovement.findFirst({ where: { sourceDocument: requestId, type: { in: ['PICK', 'PACK', 'SHIP'] } } }) ||
        // Opening a stage and locating a box are not physical picking. Preserve
        // their audit rows without forcing the request back into the old UI.
        await db.tsdOperation.findFirst({ where: { payload: { path: ['requestId'], equals: requestId }, status: 'ACCEPTED', operationType: { in: ['move_scan'] } } }));
}
// FIX: both the new screen and old bulk endpoints use the same eligibility rule.
async function isFboTwoStageRequest(db, requestId) {
    if (!(0, exports.fboTwoStageEnabled)())
        return false;
    const r = await db.clientRequest.findUnique({ where: { id: requestId }, select: { type: true, status: true, client: { select: { storesWithoutBoxes: true } }, _count: { select: { fbsOrderLinks: true, packages: true } } } });
    if (!r || r.type !== 'OUTBOUND' || r._count.fbsOrderLinks || r.client.storesWithoutBoxes)
        return false;
    if (await db.fboAssembly.findUnique({ where: { requestId } }))
        return true;
    if (!['SUBMITTED', 'APPROVED', 'IN_WORK'].includes(r.status))
        return false;
    // Never silently fall back to the old picking screen for an active FBO.
    // Existing physical work must be reconciled before the new unit ledger starts.
    if (r._count.packages || await hasLegacyFboProgress(db, requestId))
        throw new common_1.ConflictException('Старый режим сборки ФБО отключён. В заявке есть прежние перемещения или упаковка: требуется перенос фактического прогресса в новый режим.');
    return true;
}
// FIX: picking and packing count the same physical units; packing is not another pick.
function remainingFboLines(lines, units) {
    return lines.map(line => {
        const active = units.filter(u => u.requestItemId === line.id && u.state !== 'RETURNED');
        return { ...line, needed: line.quantity, picked: active.length,
            packed: active.filter(u => u.state === 'PACKED').length, remaining: Math.max(0, line.quantity - active.length) };
    });
}
// FIX: the whole-box shortcut is allowed only for a complete, reconciled single-SKU box.
function wholeBoxDecision(balances, demand, marks, marked, markedSkuIds) {
    const positive = balances.filter(b => b.quantity > 0);
    // FIX: our installation may take mixed contents only when every SKU and physical mark fits.
    if (process.env.WMS_FBO_MIXED_WHOLE_BOX_ENABLED === 'true') {
        if (balances.some(b => !Number.isSafeInteger(b.quantity) || b.quantity < 0))
            return { allowed: false, recount: true, quantity: 0 };
        if (!positive.length || positive.some(b => b.status !== 'AVAILABLE'))
            return { allowed: false, recount: false, quantity: 0 };
        const quantities = new Map();
        for (const b of positive)
            quantities.set(b.skuId, (quantities.get(b.skuId) ?? 0) + b.quantity);
        const quantity = positive.reduce((sum, b) => sum + b.quantity, 0);
        const validMarks = marks.every(m => quantities.has(m.skuId) && m.status === 'AVAILABLE' && m.identity)
            && new Set(marks.map(m => m.identity)).size === marks.length;
        const consistent = validMarks && [...quantities].every(([skuId, count]) => {
            const actual = marks.filter(m => m.skuId === skuId).length;
            const required = (markedSkuIds ? markedSkuIds.has(skuId) : marked) || actual > 0;
            return actual === (required ? count : 0);
        });
        return { allowed: consistent && [...quantities].every(([skuId, count]) => (demand[skuId] ?? 0) >= count), recount: !consistent, quantity };
    }
    if (balances.some(b => b.quantity < 0))
        return { allowed: false, recount: true, quantity: 0 };
    const skus = new Set(positive.map(b => b.skuId));
    if (skus.size !== 1 || positive.some(b => b.status !== 'AVAILABLE'))
        return { allowed: false, recount: false, quantity: 0 };
    const skuId = positive[0].skuId;
    const quantity = positive.reduce((sum, b) => sum + b.quantity, 0);
    const consistent = marked ? (marks.length === quantity && marks.every(m => m.skuId === skuId && m.status === 'AVAILABLE' && m.identity) && new Set(marks.map(m => m.identity)).size === quantity) : marks.length === 0;
    return { allowed: consistent && (demand[skuId] ?? 0) >= quantity, recount: !consistent, quantity };
}
// FIX: reserve demand for complete reconciled boxes before allocating loose units.
// Re-evaluate after each choice so two boxes cannot consume the same remaining demand.
function prioritizeFboWholeBoxes(boxes, demand, decide) {
    const remaining = { ...demand }, pending = [...boxes], result = [];
    for (;;) {
        let best = -1, quantity = 0, exact = false;
        for (let i = 0; i < pending.length; i++) {
            const decision = decide(pending[i], remaining);
            if (!decision.allowed)
                continue;
            const quantities = new Map();
            for (const b of pending[i].balances.filter(b => b.quantity > 0))
                quantities.set(b.skuId, (quantities.get(b.skuId) ?? 0) + b.quantity);
            const fitsExactly = [...quantities].every(([skuId, count]) => remaining[skuId] === count);
            if (best < 0 || (fitsExactly && !exact) || (fitsExactly === exact && decision.quantity > quantity)) {
                best = i;
                quantity = decision.quantity;
                exact = fitsExactly;
            }
        }
        if (best < 0)
            break;
        const box = pending.splice(best, 1)[0];
        // FIX: a mixed box consumes demand separately for every SKU.
        for (const b of box.balances.filter(b => b.quantity > 0))
            remaining[b.skuId] -= b.quantity;
        result.push(box);
    }
    return [...result, ...pending];
}
