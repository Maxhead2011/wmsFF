"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdAuditInterceptor = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
const rxjs_1 = require("rxjs");
const prisma_service_1 = require("../../common/prisma/prisma.service");
let TsdAuditInterceptor = class TsdAuditInterceptor {
    prisma;
    // FIX: capture the entire authenticated mutation envelope after the business handler completes.
    constructor(prisma) {
        this.prisma = prisma;
    }
    intercept(context, next) {
        const request = context.switchToHttp().getRequest();
        const startedAt = Date.now();
        if (!shouldAudit(request))
            return next.handle();
        return next.handle().pipe((0, rxjs_1.mergeMap)((response) => (0, rxjs_1.from)(this.safeRecord(request, response, null, startedAt)).pipe((0, rxjs_1.mergeMap)(() => [response]))), (0, rxjs_1.catchError)((caught) => (0, rxjs_1.from)(this.safeRecord(request, null, caught, startedAt)).pipe((0, rxjs_1.mergeMap)(() => (0, rxjs_1.throwError)(() => caught)))));
    }
    async safeRecord(request, response, caught, startedAt) {
        try {
            await this.record(request, response, caught, startedAt);
        }
        catch {
            // Audit storage must never turn an already completed warehouse action into a 500 response.
        }
    }
    async record(request, response, caught, startedAt) {
        const actor = request.user;
        const deviceId = text(actor.deviceCode) || text(valueAt(request.body, 'deviceCode')) || `USER:${actor.id}`;
        const message = errorMessage(caught);
        const payload = {
            auditVersion: 1,
            actor: { userId: actor.id, name: actor.name, email: actor.email },
            deviceCode: deviceId,
            request: {
                method: text(request.method).toUpperCase(),
                path: text(request.originalUrl),
                route: text(request.route?.path),
                params: sanitize(request.params),
                query: sanitize(request.query),
                body: sanitize(request.body),
            },
            response: sanitize(response),
            result: {
                ok: !caught,
                durationMs: Math.max(0, Date.now() - startedAt),
                error: message,
                httpStatus: errorStatus(caught),
            },
            recordedAt: new Date().toISOString(),
        };
        await this.prisma.tsdOperation.create({
            data: {
                deviceId,
                operationKey: `tsd-audit:${deviceId}:${Date.now()}:${(0, node_crypto_1.randomUUID)()}`,
                operationType: 'tsd_api_action',
                payload: payload,
                status: caught ? client_1.TsdOperationStatus.REJECTED : client_1.TsdOperationStatus.ACCEPTED,
                serverMessage: message || null,
            },
        });
    }
};
exports.TsdAuditInterceptor = TsdAuditInterceptor;
exports.TsdAuditInterceptor = TsdAuditInterceptor = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], TsdAuditInterceptor);
function shouldAudit(request) {
    if (!request.user)
        return false;
    const method = text(request.method).toUpperCase();
    if (!['POST', 'PATCH', 'PUT', 'DELETE'].includes(method))
        return false;
    const path = text(request.originalUrl).toLowerCase();
    return ![
        '/tsd/login',
        '/tsd/monitor/heartbeat',
        '/tsd/monitor/error',
        '/screenshot',
    ].some((fragment) => path.includes(fragment));
}
function sanitize(value, depth = 0) {
    if (value == null)
        return null;
    if (depth > 7)
        return '[DEPTH_LIMIT]';
    if (typeof value === 'string')
        return compactText(value);
    if (typeof value === 'number' || typeof value === 'boolean')
        return value;
    if (typeof value === 'bigint')
        return value.toString();
    if (value instanceof Date)
        return value.toISOString();
    if (Buffer.isBuffer(value))
        return `[BINARY:${value.length}]`;
    if (Array.isArray(value)) {
        const items = value.slice(0, 250).map((item) => sanitize(item, depth + 1));
        if (value.length > 250)
            items.push(`[${value.length - 250} MORE]`);
        return items;
    }
    if (typeof value !== 'object')
        return String(value);
    const result = {};
    Object.entries(value).slice(0, 300).forEach(([key, nested]) => {
        if (isSecretKey(key)) {
            result[key] = '[REDACTED]';
            return;
        }
        if (isLargeBinaryKey(key) && typeof nested === 'string') {
            result[key] = `[OMITTED:${nested.length} chars]`;
            return;
        }
        result[key] = sanitize(nested, depth + 1);
    });
    return result;
}
function isSecretKey(key) {
    return /password|secret|authorization|access[_-]?token|refresh[_-]?token/i.test(key);
}
function isLargeBinaryKey(key) {
    return /base64|pdfdata|imagedata|labeldata|screenshotdata/i.test(key);
}
function compactText(value) {
    return value.length <= 20_000 ? value : `${value.slice(0, 20_000)}…[TRUNCATED:${value.length}]`;
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function valueAt(value, key) {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? value[key]
        : undefined;
}
function errorMessage(caught) {
    if (!caught)
        return '';
    if (caught instanceof Error)
        return compactText(caught.message);
    return compactText(String(caught));
}
function errorStatus(caught) {
    if (!caught || typeof caught !== 'object')
        return null;
    const value = caught.status ??
        caught.statusCode;
    return typeof value === 'number' ? value : null;
}
