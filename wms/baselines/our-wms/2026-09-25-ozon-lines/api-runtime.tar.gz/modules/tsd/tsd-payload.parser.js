"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdPayloadParser = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
let TsdPayloadParser = class TsdPayloadParser {
    parseMovePayload(payload) {
        const clientId = this.stringValue(payload.clientId, 'clientId');
        const fromBoxCode = this.boxCodeValue(payload.fromBoxCode, 'fromBoxCode');
        const toBoxCode = this.boxCodeValue(payload.toBoxCode, 'toBoxCode');
        const quantity = this.numberValue(payload.quantity, 'quantity');
        const barcode = this.productBarcodeValue(payload.barcode);
        const skuId = this.optionalStringValue(payload.skuId);
        if (!barcode && !skuId) {
            throw new common_1.BadRequestException('Для move_scan нужен barcode или skuId.');
        }
        return {
            clientId,
            barcode,
            skuId,
            fromBoxCode,
            toBoxCode,
            quantity,
            status: this.optionalStockStatus(payload.status),
            comment: this.optionalStringValue(payload.comment),
        };
    }
    parseReceiptPayload(payload) {
        const clientId = this.stringValue(payload.clientId, 'clientId');
        const boxCode = this.optionalBoxCodeValue(payload.boxCode ?? payload.toBoxCode);
        const quantity = this.numberValue(payload.quantity, 'quantity');
        const barcode = this.productBarcodeValue(payload.barcode);
        const skuId = this.optionalStringValue(payload.skuId);
        const kiz = this.kizValue(payload.kiz);
        if (!barcode && !skuId) {
            throw new common_1.BadRequestException('Для receipt_scan нужен barcode или skuId.');
        }
        return {
            clientId,
            barcode,
            skuId,
            kiz,
            boxCode,
            receiptMode: this.optionalReceiptMode(payload.receiptMode),
            quantity,
            status: this.optionalStockStatus(payload.status),
            sourceDocument: this.optionalStringValue(payload.sourceDocument),
            comment: this.optionalStringValue(payload.comment),
        };
    }
    parseInventoryPayload(payload) {
        const clientId = this.stringValue(payload.clientId, 'clientId');
        const boxCode = this.boxCodeValue(payload.boxCode, 'boxCode');
        const countedQuantity = this.nonNegativeNumberValue(payload.countedQuantity ?? payload.quantity, 'countedQuantity');
        const barcode = this.productBarcodeValue(payload.barcode);
        const skuId = this.optionalStringValue(payload.skuId);
        if (!barcode && !skuId) {
            throw new common_1.BadRequestException('Для inventory_scan нужен barcode или skuId.');
        }
        return {
            clientId,
            barcode,
            skuId,
            boxCode,
            countedQuantity,
            status: this.optionalStockStatus(payload.status),
        };
    }
    stringValue(value, field) {
        if (typeof value !== 'string' || !value.trim()) {
            throw new common_1.BadRequestException(`Поле ${field} обязательно для операции ТСД.`);
        }
        return value.trim();
    }
    optionalStringValue(value) {
        return typeof value === 'string' && value.trim() ? value.trim() : undefined;
    }
    boxCodeValue(value, field) {
        const result = this.stringValue(value, field);
        if (!isFflBoxCode(result)) {
            throw new common_1.BadRequestException('Номер короба должен начинаться с FFL. Отсканируйте корректный ШК короба.');
        }
        return result.trim();
    }
    optionalBoxCodeValue(value) {
        const result = this.optionalStringValue(value);
        if (!result) {
            return undefined;
        }
        if (!isFflBoxCode(result)) {
            throw new common_1.BadRequestException('Номер короба должен начинаться с FFL. Отсканируйте корректный ШК короба.');
        }
        return result;
    }
    productBarcodeValue(value) {
        const result = this.optionalStringValue(value);
        if (!result) {
            return undefined;
        }
        if (isFflBoxCode(result)) {
            throw new common_1.BadRequestException('В поле ШК товара отсканирован номер короба. Отсканируйте ШК товара.');
        }
        if (result.length > 13) {
            throw new common_1.BadRequestException('ШК товара не должен быть длиннее 13 символов. Возможно, отсканирован КИЗ.');
        }
        return result;
    }
    kizValue(value) {
        const result = this.optionalStringValue(value);
        if (!result) {
            return undefined;
        }
        if (isFflBoxCode(result)) {
            throw new common_1.BadRequestException('В поле КИЗ отсканирован номер короба. Отсканируйте КИЗ товара.');
        }
        if (result.length <= 20) {
            throw new common_1.BadRequestException('КИЗ должен быть длиннее 20 символов. Возможно, отсканирован ШК товара.');
        }
        return result;
    }
    optionalStockStatus(value) {
        if (value == null || value === '') {
            return undefined;
        }
        if (typeof value !== 'string' || !Object.values(client_1.StockStatus).includes(value)) {
            throw new common_1.BadRequestException('Некорректный stock status в операции ТСД.');
        }
        return value;
    }
    optionalReceiptMode(value) {
        if (value == null || value === '') {
            return undefined;
        }
        const normalized = typeof value === 'string' ? value.trim().toUpperCase() : '';
        if (normalized !== 'STANDARD' && normalized !== 'BOXES') {
            throw new common_1.BadRequestException('Некорректный режим приемки ТСД.');
        }
        return normalized;
    }
    numberValue(value, field) {
        const parsed = typeof value === 'number' ? value : Number(value);
        if (!Number.isInteger(parsed) || parsed <= 0) {
            throw new common_1.BadRequestException(`Поле ${field} должно быть положительным целым числом.`);
        }
        return parsed;
    }
    nonNegativeNumberValue(value, field) {
        const parsed = typeof value === 'number' ? value : Number(value);
        if (!Number.isInteger(parsed) || parsed < 0) {
            throw new common_1.BadRequestException(`Поле ${field} должно быть целым числом от 0.`);
        }
        return parsed;
    }
};
exports.TsdPayloadParser = TsdPayloadParser;
exports.TsdPayloadParser = TsdPayloadParser = __decorate([
    (0, common_1.Injectable)()
], TsdPayloadParser);
function isFflBoxCode(value) {
    return value.trim().toLocaleUpperCase('ru-RU').startsWith('FFL');
}
