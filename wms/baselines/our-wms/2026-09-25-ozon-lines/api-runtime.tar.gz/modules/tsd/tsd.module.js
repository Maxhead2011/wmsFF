"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const stock_module_1 = require("../stock/stock.module");
const marketplace_connections_module_1 = require("../marketplace-connections/marketplace-connections.module");
const warehouse_module_1 = require("../warehouse/warehouse.module");
const inventory_module_1 = require("../inventory/inventory.module");
const tsd_device_controller_1 = require("./tsd-device.controller");
const tsd_assembly_service_1 = require("./tsd-assembly.service");
const tsd_relabel_print_service_1 = require("./tsd-relabel-print.service");
const tsd_device_service_1 = require("./tsd-device.service");
const tsd_operation_log_service_1 = require("./tsd-operation-log.service");
const tsd_payload_parser_1 = require("./tsd-payload.parser");
const tsd_receipt_service_1 = require("./tsd-receipt.service");
const tsd_review_service_1 = require("./tsd-review.service");
const tsd_sync_controller_1 = require("./tsd-sync.controller");
const tsd_sync_service_1 = require("./tsd-sync.service");
const tsd_audit_interceptor_1 = require("./tsd-audit.interceptor");
const fbo_two_stage_service_1 = require("./fbo-two-stage.service");
const fbo_two_stage_controller_1 = require("./fbo-two-stage.controller");
const client_request_marketplace_files_service_1 = require("../client-requests/client-request-marketplace-files.service");
let TsdModule = class TsdModule {
};
exports.TsdModule = TsdModule;
exports.TsdModule = TsdModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, stock_module_1.StockModule, marketplace_connections_module_1.MarketplaceConnectionsModule, warehouse_module_1.WarehouseModule, inventory_module_1.InventoryModule],
        controllers: [tsd_device_controller_1.TsdDeviceController, tsd_sync_controller_1.TsdSyncController, fbo_two_stage_controller_1.FboTwoStageController],
        providers: [
            fbo_two_stage_service_1.FboTwoStageService,
            client_request_marketplace_files_service_1.ClientRequestMarketplaceFilesService,
            tsd_assembly_service_1.TsdAssemblyService,
            tsd_relabel_print_service_1.TsdRelabelPrintService,
            tsd_device_service_1.TsdDeviceService,
            tsd_operation_log_service_1.TsdOperationLogService,
            tsd_payload_parser_1.TsdPayloadParser,
            tsd_receipt_service_1.TsdReceiptService,
            tsd_review_service_1.TsdReviewService,
            tsd_sync_service_1.TsdSyncService,
            tsd_audit_interceptor_1.TsdAuditInterceptor,
        ],
    })
], TsdModule);
