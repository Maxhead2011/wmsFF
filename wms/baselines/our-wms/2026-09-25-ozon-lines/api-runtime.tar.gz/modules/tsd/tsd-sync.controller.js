"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdSyncController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const resolve_tsd_review_dto_1 = require("./dto/resolve-tsd-review.dto");
const list_tsd_operation_history_dto_1 = require("./dto/list-tsd-operation-history.dto");
const scan_operation_dto_1 = require("./dto/scan-operation.dto");
const tsd_review_service_1 = require("./tsd-review.service");
const tsd_sync_service_1 = require("./tsd-sync.service");
const tsd_audit_interceptor_1 = require("./tsd-audit.interceptor");
let TsdSyncController = class TsdSyncController {
    sync;
    review;
    constructor(sync, review) {
        this.sync = sync;
        this.review = review;
    }
    listReviewQueue(user) {
        return this.sync.listReviewQueue(user);
    }
    listReviewHistory(user) {
        return this.review.listReviewHistory(user);
    }
    listOperationHistory(query, user) {
        return this.review.listOperationHistory(user, query);
    }
    getOperationHistoryItem(id, user) {
        return this.review.getOperationHistoryItem(id, user);
    }
    async getOperationScreenshot(id, user, response) {
        const screenshot = await this.review.getOperationScreenshot(id, user);
        response.setHeader('Content-Type', screenshot.mimeType);
        response.setHeader('Content-Length', String(screenshot.content.length));
        response.setHeader('Cache-Control', 'private, max-age=300');
        response.setHeader('Content-Disposition', `inline; filename="tsd-${id}.jpg"`);
        return new common_1.StreamableFile(screenshot.content);
    }
    listReceiptReviewDashboard(user) {
        return this.review.listReceiptReviewDashboard(user);
    }
    async downloadReceiptReviewBoxes(clientId, user, response) {
        const file = await this.review.getReceiptReviewBoxesXlsx(user, clientId);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    acceptOperation(operation, user) {
        return this.sync.acceptOperation(operation, user);
    }
    syncOperations(dto, user) {
        return this.sync.syncOperations(dto, user);
    }
    resolveReviewOperation(id, dto, user) {
        return this.review.resolveReviewOperation(id, dto, user);
    }
};
exports.TsdSyncController = TsdSyncController;
__decorate([
    (0, common_1.Get)('review'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "listReviewQueue", null);
__decorate([
    (0, common_1.Get)('review/history'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "listReviewHistory", null);
__decorate([
    (0, common_1.Get)('history'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_tsd_operation_history_dto_1.ListTsdOperationHistoryDto, Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "listOperationHistory", null);
__decorate([
    (0, common_1.Get)('history/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "getOperationHistoryItem", null);
__decorate([
    (0, common_1.Get)('history/:id/screenshot'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TsdSyncController.prototype, "getOperationScreenshot", null);
__decorate([
    (0, common_1.Get)('review/receipts'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "listReceiptReviewDashboard", null);
__decorate([
    (0, common_1.Get)('review/receipts.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], TsdSyncController.prototype, "downloadReceiptReviewBoxes", null);
__decorate([
    (0, common_1.Post)('operations'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [scan_operation_dto_1.ScanOperationDto, Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "acceptOperation", null);
__decorate([
    (0, common_1.Post)('sync'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [scan_operation_dto_1.SyncTsdOperationsDto, Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "syncOperations", null);
__decorate([
    (0, common_1.Patch)('review/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, resolve_tsd_review_dto_1.ResolveTsdReviewDto, Object]),
    __metadata("design:returntype", void 0)
], TsdSyncController.prototype, "resolveReviewOperation", null);
exports.TsdSyncController = TsdSyncController = __decorate([
    (0, swagger_1.ApiTags)('tsd'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, common_1.UseInterceptors)(tsd_audit_interceptor_1.TsdAuditInterceptor),
    (0, common_1.Controller)('tsd'),
    __metadata("design:paramtypes", [tsd_sync_service_1.TsdSyncService,
        tsd_review_service_1.TsdReviewService])
], TsdSyncController);
function contentDisposition(fileName) {
    const asciiName = fileName.replace(/[^\x20-\x7E]+/g, '_').replace(/"/g, '');
    return `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`;
}
