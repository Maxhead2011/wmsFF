"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FboTwoStageController = void 0;
const fbo_route_dto_1 = require("./dto/fbo-route.dto");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const fbo_two_stage_service_1 = require("./fbo-two-stage.service");
const fbo_action_dto_1 = require("./dto/fbo-action.dto");
const tsd_audit_interceptor_1 = require("./tsd-audit.interceptor");
let FboTwoStageController = class FboTwoStageController {
    fbo;
    constructor(fbo) {
        this.fbo = fbo;
    }
    plan(id, user, route) {
        return this.fbo.plan(id, user, route);
    }
    action(id, dto, user) {
        return this.fbo.act(id, dto, user);
    }
    // FIX: opt-in terminals receive a durable receipt independently of the expensive route.
    acknowledge(id, dto, user) {
        return this.fbo.actAcknowledged(id, dto, user);
    }
    operationStatus(id, dto, user) {
        return this.fbo.operationStatus(id, dto, user);
    }
    // FIX: both files are guarded by the same completed shipment check and user scope.
    async products(id, user, res) {
        const file = await this.fbo.wbFile(id, user, 'products');
        res.setHeader('Content-Type', file.mimeType);
        res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.content);
    }
    async file(id, user, res) {
        const file = await this.fbo.wbFile(id, user);
        res.setHeader('Content-Type', file.mimeType);
        res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.content);
    }
};
exports.FboTwoStageController = FboTwoStageController;
__decorate([
    (0, common_1.Get)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, fbo_route_dto_1.FboRouteDto]),
    __metadata("design:returntype", void 0)
], FboTwoStageController.prototype, "plan", null);
__decorate([
    (0, common_1.Post)('actions'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, fbo_action_dto_1.FboActionDto, Object]),
    __metadata("design:returntype", void 0)
], FboTwoStageController.prototype, "action", null);
__decorate([
    (0, common_1.Post)('actions/ack'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, fbo_action_dto_1.FboActionDto, Object]),
    __metadata("design:returntype", void 0)
], FboTwoStageController.prototype, "acknowledge", null);
__decorate([
    (0, common_1.Post)('actions/status'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, fbo_action_dto_1.FboActionDto, Object]),
    __metadata("design:returntype", void 0)
], FboTwoStageController.prototype, "operationStatus", null);
__decorate([
    (0, common_1.Get)('wb-products.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], FboTwoStageController.prototype, "products", null);
__decorate([
    (0, common_1.Get)('wb-packages.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], FboTwoStageController.prototype, "file", null);
exports.FboTwoStageController = FboTwoStageController = __decorate([
    (0, swagger_1.ApiTags)('tsd'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.Controller)('tsd/requests/:id/fbo'),
    (0, common_1.UseInterceptors)(tsd_audit_interceptor_1.TsdAuditInterceptor),
    __metadata("design:paramtypes", [fbo_two_stage_service_1.FboTwoStageService])
], FboTwoStageController);
