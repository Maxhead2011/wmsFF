"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdDeviceService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const crypto_1 = require("crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const access_token_service_1 = require("../auth/access-token.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const password_service_1 = require("../auth/password.service");
const tsd_monitor_messages_1 = require("./tsd-monitor-messages");
const FBS_TSD_RESERVED_STATUS = 'RESERVED';
const FBS_TSD_AUTO_RESERVATION_DEVICE = 'AUTO:FBS:PALLET_SORT';
const TSD_PHYSICAL_INSTALLATION_PREFIX = 'TSD-INSTALL-';
const TSD_CLOSED_REQUEST_STATUSES = [
    client_1.ClientRequestStatus.DONE,
    client_1.ClientRequestStatus.CANCELLED,
    client_1.ClientRequestStatus.REJECTED,
];
let TsdDeviceService = class TsdDeviceService {
    prisma;
    passwords;
    tokens;
    clientScopes;
    constructor(prisma, passwords, tokens, clientScopes) {
        this.prisma = prisma;
        this.passwords = passwords;
        this.tokens = tokens;
        this.clientScopes = clientScopes;
    }
    listDevices() {
        return this.prisma.tsdDevice.findMany({
            orderBy: { createdAt: 'desc' },
            select: {
                id: true,
                code: true,
                name: true,
                status: true,
                lastLoginAt: true,
                lastSeenAt: true,
                createdAt: true,
                user: {
                    select: {
                        id: true,
                        email: true,
                        name: true,
                        status: true,
                    },
                },
            },
        });
    }
    async recordMonitorHeartbeat(body, user) {
        const reportedDeviceCode = monitorText(body.deviceCode) || user.deviceCode;
        const deviceCode = this.monitorDeviceCode(monitorText(body.installationCode), reportedDeviceCode, user.id);
        if (!deviceCode) {
            throw new common_1.BadRequestException('Не удалось определить код ТСД для мониторинга.');
        }
        await this.touchActiveDevice(user.deviceId);
        const payload = monitorPayload(body, deviceCode, user.name, user.id);
        await this.prisma.tsdOperation.upsert({
            where: { operationKey: `monitor-heartbeat:${deviceCode}` },
            update: {
                payload: payload,
                status: client_1.TsdOperationStatus.ACCEPTED,
                serverMessage: monitorText(body.lastAction) || null,
            },
            create: {
                deviceId: deviceCode,
                operationKey: `monitor-heartbeat:${deviceCode}`,
                operationType: 'monitor_heartbeat',
                payload: payload,
                status: client_1.TsdOperationStatus.ACCEPTED,
                serverMessage: monitorText(body.lastAction) || null,
            },
        });
        const command = await this.prisma.tsdOperation.findFirst({
            where: {
                deviceId: deviceCode,
                operationType: 'monitor_command',
                status: client_1.TsdOperationStatus.NEEDS_REVIEW,
            },
            orderBy: { createdAt: 'asc' },
        });
        if (command) {
            await this.prisma.tsdOperation.update({
                where: { id: command.id },
                data: { status: client_1.TsdOperationStatus.ACCEPTED, serverMessage: 'Команда доставлена на ТСД.' },
            });
        }
        return {
            accepted: true,
            serverTime: new Date().toISOString(),
            // ADDED: optional capability keeps old Android clients unchanged.
            message: body.monitorMessages === true ? await new tsd_monitor_messages_1.TsdMonitorMessages(this.prisma).next(deviceCode, user) : null,
            command: command
                ? {
                    id: command.id,
                    action: monitorText(administrationPayloadValue(command.payload, 'action')),
                }
                : null,
        };
    }
    async recordMonitorError(body, user) {
        const reportedDeviceCode = monitorText(body.deviceCode) || user.deviceCode;
        const deviceCode = this.monitorDeviceCode(monitorText(body.installationCode), reportedDeviceCode, user.id);
        const message = monitorText(body.message);
        if (!deviceCode || !message) {
            throw new common_1.BadRequestException('Для журнала ошибки нужны код ТСД и текст ошибки.');
        }
        await this.touchActiveDevice(user.deviceId);
        const operation = await this.prisma.tsdOperation.create({
            data: {
                deviceId: deviceCode,
                operationKey: `monitor-error:${deviceCode}:${Date.now()}:${(0, crypto_1.randomUUID)()}`,
                operationType: 'monitor_error',
                payload: monitorPayload(body, deviceCode, user.name, user.id),
                status: client_1.TsdOperationStatus.REJECTED,
                serverMessage: message,
            },
        });
        return { accepted: true, operationId: operation.id, serverTime: new Date().toISOString() };
    }
    // ADDED: acknowledgement is an independent, retry-safe action.
    async acknowledgeMonitorMessage(id, user) {
        await this.touchActiveDevice(user.deviceId);
        return new tsd_monitor_messages_1.TsdMonitorMessages(this.prisma).ack(id, user);
    }
    async attachMonitorErrorScreenshot(operationId, file, user) {
        if (!file?.buffer?.length)
            throw new common_1.BadRequestException('Снимок экрана не получен.');
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)) {
            throw new common_1.BadRequestException('Допустимы снимки JPEG, PNG или WebP.');
        }
        if (file.buffer.length > 750 * 1024) {
            throw new common_1.BadRequestException('Снимок экрана превышает 750 КБ.');
        }
        const operation = await this.prisma.tsdOperation.findUnique({
            where: { id: operationId },
            select: { id: true, operationType: true, payload: true },
        });
        const payload = operation ? jsonPayload(operation.payload) : {};
        if (!operation || operation.operationType !== 'monitor_error') {
            throw new common_1.BadRequestException('Операция ошибки ТСД не найдена.');
        }
        if (monitorText(payload.workerUserId) !== user.id) {
            throw new common_1.UnauthorizedException('Нельзя прикрепить снимок к ошибке другого сотрудника.');
        }
        await this.prisma.tsdOperation.update({
            where: { id: operationId },
            data: {
                screenshotData: Uint8Array.from(file.buffer),
                screenshotMimeType: file.mimetype,
                screenshotCapturedAt: new Date(),
            },
        });
        return { accepted: true, operationId, size: file.buffer.length };
    }
    async createDevice(dto) {
        const user = await this.prisma.user.findUnique({
            where: { id: dto.userId },
            include: {
                roles: {
                    include: {
                        role: {
                            include: {
                                permissions: {
                                    include: { permission: true },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (!user || user.status !== client_1.UserStatus.ACTIVE) {
            throw new common_1.BadRequestException('Для ТСД нужен активный пользователь-оператор.');
        }
        const permissionCodes = user.roles.flatMap((item) => item.role.permissions.map((permission) => permission.permission.code));
        if (!permissionCodes.includes('stock:write') && !permissionCodes.includes('system:admin')) {
            throw new common_1.BadRequestException('Пользователь ТСД должен иметь право stock:write.');
        }
        const secret = this.generateSecret();
        const device = await this.prisma.tsdDevice.create({
            data: {
                code: this.normalizeCode(dto.code),
                name: dto.name.trim(),
                userId: user.id,
                secretHash: await this.passwords.hash(secret),
            },
            select: {
                id: true,
                code: true,
                name: true,
                status: true,
                userId: true,
                createdAt: true,
            },
        });
        // Русский комментарий: секрет показываем только один раз при создании устройства; в базе остается только hash.
        return {
            ...device,
            deviceSecret: secret,
        };
    }
    async listClientsForDevice(user) {
        await this.touchActiveDevice(user.deviceId);
        const clientFilter = this.clientScopes.resolveClientFilter(user);
        return this.prisma.client.findMany({
            where: {
                ...(clientFilter === undefined ? {} : { id: clientFilter }),
                status: { not: client_1.ClientStatus.ARCHIVED },
            },
            orderBy: [{ name: 'asc' }, { code: 'asc' }],
            select: {
                id: true,
                code: true,
                name: true,
                storesWithoutBoxes: true,
            },
        });
    }
    async login(dto) {
        if (dto.login !== undefined || dto.password !== undefined) {
            return this.loginByUserCredentials(dto);
        }
        if (dto.code !== undefined || dto.secret !== undefined) {
            return this.loginByDeviceSecret(dto);
        }
        throw new common_1.UnauthorizedException('Укажите логин/пароль или код/секрет ТСД.');
    }
    async loginByUserCredentials(dto) {
        const login = dto.login?.trim();
        const password = dto.password ?? '';
        if (!login || !password) {
            throw new common_1.UnauthorizedException('Неверный логин или пароль.');
        }
        const user = await this.prisma.user.findUnique({
            where: { email: this.normalizeLogin(login) },
            include: {
                roles: {
                    include: {
                        role: {
                            include: {
                                permissions: {
                                    include: { permission: true },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (!user || !(await this.passwords.verify(password, user.passwordHash))) {
            throw new common_1.UnauthorizedException('Неверный логин или пароль.');
        }
        if (user.status !== client_1.UserStatus.ACTIVE) {
            throw new common_1.UnauthorizedException('Пользователь заблокирован.');
        }
        const permissionCodes = [
            ...new Set(user.roles.flatMap((item) => item.role.permissions.map((permission) => permission.permission.code))),
        ];
        const roleCodes = [...new Set(user.roles.map((item) => item.role.code))];
        if (!permissionCodes.includes('stock:write') && !permissionCodes.includes('system:admin')) {
            throw new common_1.UnauthorizedException('У пользователя ТСД нет права stock:write.');
        }
        const installationCode = dto.installationCode?.trim();
        if (!installationCode) {
            throw new common_1.UnauthorizedException({
                code: 'TSD_UPDATE_REQUIRED',
                message: 'Обновите приложение ТСД и войдите заново: старая версия не передаёт код физического устройства.',
            });
        }
        const deviceCode = this.normalizeCode(installationCode);
        let device = await this.prisma.tsdDevice.findUnique({
            where: { code: deviceCode },
            select: { id: true, code: true, name: true, userId: true, status: true },
        });
        if (!device) {
            try {
                device = await this.prisma.tsdDevice.create({
                    data: {
                        code: deviceCode,
                        name: `${user.name} · ${deviceCode.slice(-8)}`,
                        userId: user.id,
                        secretHash: await this.passwords.hash((0, crypto_1.randomBytes)(32).toString('hex')),
                        lastLoginAt: new Date(),
                        lastSeenAt: new Date(),
                    },
                    select: { id: true, code: true, name: true, userId: true, status: true },
                });
            }
            catch (caught) {
                if (!(caught instanceof client_1.Prisma.PrismaClientKnownRequestError) || caught.code !== 'P2002') {
                    throw caught;
                }
                device = await this.prisma.tsdDevice.findUnique({
                    where: { code: deviceCode },
                    select: { id: true, code: true, name: true, userId: true, status: true },
                });
            }
        }
        if (!device) {
            throw new common_1.UnauthorizedException('Не удалось зарегистрировать физический ТСД. Повторите вход.');
        }
        if (device.status !== client_1.TsdDeviceStatus.ACTIVE) {
            throw new common_1.UnauthorizedException('Этот физический ТСД заблокирован администратором.');
        }
        if (device.userId !== user.id) {
            device = await this.rebindSharedInstallation(device, user);
        }
        else {
            await this.prisma.tsdDevice.update({
                where: { id: device.id },
                data: { lastLoginAt: new Date(), lastSeenAt: new Date() },
            });
        }
        await this.releaseUntouchedLegacyFbsLeases(user.id, user.name, deviceCode);
        return {
            accessToken: this.tokens.sign(user.id, {
                deviceId: device.id,
                deviceCode,
            }),
            tokenType: 'Bearer',
            device: {
                id: device.id,
                code: deviceCode,
                name: device.name,
            },
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                roleCodes,
                permissionCodes,
            },
        };
    }
    async loginByDeviceSecret(dto) {
        const code = dto.code?.trim();
        const secret = dto.secret ?? '';
        if (!code || !secret) {
            throw new common_1.UnauthorizedException('Неверный код или секрет ТСД.');
        }
        const device = await this.prisma.tsdDevice.findUnique({
            where: { code: this.normalizeCode(code) },
            include: {
                user: {
                    include: {
                        roles: {
                            include: {
                                role: {
                                    include: {
                                        permissions: {
                                            include: { permission: true },
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (!device || !(await this.passwords.verify(secret, device.secretHash))) {
            throw new common_1.UnauthorizedException('Неверный код или секрет ТСД.');
        }
        if (device.status !== client_1.TsdDeviceStatus.ACTIVE) {
            throw new common_1.UnauthorizedException('ТСД заблокирован.');
        }
        if (device.user.status !== client_1.UserStatus.ACTIVE) {
            throw new common_1.UnauthorizedException('Пользователь ТСД заблокирован.');
        }
        const permissionCodes = [
            ...new Set(device.user.roles.flatMap((item) => item.role.permissions.map((permission) => permission.permission.code))),
        ];
        const roleCodes = [...new Set(device.user.roles.map((item) => item.role.code))];
        if (!permissionCodes.includes('stock:write') && !permissionCodes.includes('system:admin')) {
            throw new common_1.UnauthorizedException('У пользователя ТСД нет права stock:write.');
        }
        await this.prisma.tsdDevice.update({
            where: { id: device.id },
            data: { lastLoginAt: new Date(), lastSeenAt: new Date() },
        });
        return {
            accessToken: this.tokens.sign(device.user.id, {
                deviceId: device.id,
                deviceCode: device.code,
            }),
            tokenType: 'Bearer',
            device: {
                id: device.id,
                code: device.code,
                name: device.name,
            },
            user: {
                id: device.user.id,
                email: device.user.email,
                name: device.user.name,
                roleCodes,
                permissionCodes,
            },
        };
    }
    async touchActiveDevice(deviceId) {
        if (!deviceId) {
            return undefined;
        }
        const device = await this.prisma.tsdDevice.findUnique({
            where: { id: deviceId },
            select: { id: true, status: true },
        });
        if (!device || device.status !== client_1.TsdDeviceStatus.ACTIVE) {
            throw new common_1.UnauthorizedException('ТСД заблокирован или удален.');
        }
        return this.prisma.tsdDevice.update({
            where: { id: deviceId },
            data: { lastSeenAt: new Date() },
        });
    }
    generateSecret() {
        return (0, crypto_1.randomBytes)(24).toString('base64url');
    }
    /**
     * Credential login identifies the employee while installationCode identifies
     * the physical handheld. Shared handhelds can move between employees, but the
     * device code stays stable while its display name follows the employee who
     * actually signed in. The current on-device FBS task moves in the same
     * serializable transaction, so the old token loses its lease immediately
     * and cannot write after the new employee signs in.
     * Device-secret login deliberately remains pinned to its configured user.
     */
    async rebindSharedInstallation(device, user) {
        try {
            return await this.prisma.$transaction(async (tx) => {
                const current = await tx.tsdDevice.findUnique({
                    where: { id: device.id },
                    select: { id: true, code: true, name: true, userId: true, status: true },
                });
                if (!current || current.status !== client_1.TsdDeviceStatus.ACTIVE) {
                    throw new common_1.UnauthorizedException('Этот физический ТСД заблокирован или удалён.');
                }
                // FIX: the original device name contains the first employee's name.
                // Keep the physical suffix but always display the current employee.
                const currentEmployeeDeviceName = `${user.name} · ${current.code.slice(-8)}`;
                // FIX: a closed/deleted request must never follow the physical TSD to
                // every employee who signs in later. Preserve its scan evidence for
                // manager review, but remove the stale lease from the handheld.
                const assignedTasks = await tx.fbsTsdAssembly.findMany({
                    where: {
                        deviceCode: current.code,
                        workerUserId: current.userId,
                        status: 'IN_PROGRESS',
                    },
                    select: { id: true, requestId: true },
                });
                const assignedRequestIds = [...new Set(assignedTasks.map((task) => task.requestId))];
                const openRequests = assignedRequestIds.length
                    ? await tx.clientRequest.findMany({
                        where: {
                            id: { in: assignedRequestIds },
                            status: { notIn: TSD_CLOSED_REQUEST_STATUSES },
                        },
                        select: { id: true },
                    })
                    : [];
                const openRequestIds = new Set(openRequests.map((request) => request.id));
                const liveTaskIds = assignedTasks
                    .filter((task) => openRequestIds.has(task.requestId))
                    .map((task) => task.id);
                const staleTaskIds = assignedTasks
                    .filter((task) => !openRequestIds.has(task.requestId))
                    .map((task) => task.id);
                const parkedStaleTasks = staleTaskIds.length
                    ? await tx.fbsTsdAssembly.updateMany({
                        where: {
                            id: { in: staleTaskIds },
                            deviceCode: current.code,
                            workerUserId: current.userId,
                            status: 'IN_PROGRESS',
                        },
                        data: {
                            status: 'RETURN_REQUIRED',
                            deviceCode: FBS_TSD_AUTO_RESERVATION_DEVICE,
                            workerUserId: null,
                            workerName: null,
                            errorMessage: 'Задание снято с ТСД: исходная FBS-заявка уже закрыта или удалена.',
                        },
                    })
                    : { count: 0 };
                if (parkedStaleTasks.count > 0) {
                    await tx.auditLog.create({
                        data: {
                            userId: user.id,
                            action: 'TSD_STALE_FBS_TASKS_PARKED',
                            entity: 'TsdDevice',
                            entityId: current.id,
                            payload: {
                                deviceCode: current.code,
                                previousUserId: current.userId,
                                staleTaskIds,
                                parkedTasks: parkedStaleTasks.count,
                            },
                        },
                    });
                }
                if (current.userId !== user.id) {
                    const rebound = await tx.tsdDevice.updateMany({
                        where: { id: current.id, userId: current.userId, status: client_1.TsdDeviceStatus.ACTIVE },
                        data: {
                            userId: user.id,
                            name: currentEmployeeDeviceName,
                            lastLoginAt: new Date(),
                            lastSeenAt: new Date(),
                        },
                    });
                    if (rebound.count !== 1) {
                        throw new common_1.UnauthorizedException('Сотрудник на этом ТСД уже изменился. Повторите вход.');
                    }
                    const movedTasks = liveTaskIds.length
                        ? await tx.fbsTsdAssembly.updateMany({
                            where: {
                                id: { in: liveTaskIds },
                                deviceCode: current.code,
                                workerUserId: current.userId,
                                status: 'IN_PROGRESS',
                            },
                            data: {
                                workerUserId: user.id,
                                workerName: user.name,
                                errorMessage: null,
                            },
                        })
                        : { count: 0 };
                    await tx.auditLog.create({
                        data: {
                            userId: user.id,
                            action: 'TSD_SHARED_INSTALLATION_REBOUND',
                            entity: 'TsdDevice',
                            entityId: current.id,
                            payload: {
                                deviceCode: current.code,
                                previousUserId: current.userId,
                                nextUserId: user.id,
                                movedFbsTasks: movedTasks.count,
                                parkedStaleFbsTasks: parkedStaleTasks.count,
                            },
                        },
                    });
                }
                else {
                    await tx.tsdDevice.update({
                        where: { id: current.id },
                        data: {
                            name: currentEmployeeDeviceName,
                            lastLoginAt: new Date(),
                            lastSeenAt: new Date(),
                        },
                    });
                }
                const reboundDevice = await tx.tsdDevice.findUnique({
                    where: { id: current.id },
                    select: { id: true, code: true, name: true, userId: true, status: true },
                });
                if (!reboundDevice || reboundDevice.userId !== user.id) {
                    throw new common_1.UnauthorizedException('Не удалось перепривязать общий ТСД. Повторите вход.');
                }
                return reboundDevice;
            }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
        }
        catch (caught) {
            if (caught instanceof common_1.UnauthorizedException)
                throw caught;
            if (caught instanceof client_1.Prisma.PrismaClientKnownRequestError && caught.code === 'P2034') {
                throw new common_1.UnauthorizedException('Сотрудник на этом ТСД уже изменился. Повторите вход.');
            }
            throw caught;
        }
    }
    /**
     * Versions before physical installation identity assigned FBS tasks to
     * shared codes such as USER:<login> or TSD-01. Once the same employee has
     * successfully logged in with TSD-INSTALL-*, return only completely
     * untouched legacy leases to the automatic reservation queue. Reserved box
     * fields are intentionally not changed. Any physical/WB/label/finalization
     * marker makes the row ineligible and leaves it for explicit review.
     */
    async releaseUntouchedLegacyFbsLeases(userId, userName, physicalDeviceCode) {
        if (!physicalDeviceCode.startsWith(TSD_PHYSICAL_INSTALLATION_PREFIX)) {
            return 0;
        }
        return this.prisma.$transaction(async (tx) => {
            const released = await tx.fbsTsdAssembly.updateMany({
                where: {
                    status: 'IN_PROGRESS',
                    workerUserId: userId,
                    deviceCode: {
                        not: { startsWith: TSD_PHYSICAL_INSTALLATION_PREFIX },
                    },
                    boxId: null,
                    boxCode: null,
                    sourceBarcode: null,
                    barcode: null,
                    kiz: null,
                    relabelConfirmedAt: null,
                    wbMetaStatus: { in: ['PENDING', 'NOT_REQUIRED'] },
                    marketplaceSubmittedAt: null,
                    marketplaceLabelBase64: null,
                    marketplaceLabelContentType: null,
                    marketplaceSubmitError: null,
                    stickerPartA: null,
                    stickerPartB: null,
                    stickerBarcode: null,
                    sourceBoxPending: false,
                    cargoPackingId: null,
                    cargoPackedAt: null,
                    cargoPackedByUserId: null,
                    cargoPackedByName: null,
                    completedAt: null,
                },
                data: {
                    status: FBS_TSD_RESERVED_STATUS,
                    deviceCode: FBS_TSD_AUTO_RESERVATION_DEVICE,
                    workerUserId: null,
                    workerName: null,
                    startedAt: null,
                    errorMessage: `Нетронутое задание старой сессии ${userName} возвращено в автоматический резерв после входа с ${physicalDeviceCode}.`,
                },
            });
            if (released.count > 0) {
                await tx.auditLog.create({
                    data: {
                        userId,
                        action: 'TSD_LEGACY_FBS_LEASES_RELEASED',
                        entity: 'User',
                        entityId: userId,
                        payload: {
                            physicalDeviceCode,
                            releasedTasks: released.count,
                            predicateVersion: 1,
                            preservedReservation: true,
                        },
                    },
                });
            }
            return released.count;
        }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
    }
    normalizeCode(code) {
        return code.trim().toUpperCase();
    }
    normalizeLogin(login) {
        return login.trim().toLowerCase();
    }
    loginDeviceCode(login) {
        return `USER:${login.trim().toLowerCase()}`;
    }
    monitorDeviceCode(installationCode, reportedDeviceCode, userId) {
        const installation = installationCode.trim();
        if (installation)
            return this.normalizeCode(installation);
        const reported = (reportedDeviceCode ?? '').trim();
        if (!reported)
            return '';
        if (/^FFU-TSD-/i.test(reported))
            return this.normalizeCode(reported);
        return `${this.normalizeCode(reported)}@${userId.slice(0, 8).toUpperCase()}`;
    }
};
exports.TsdDeviceService = TsdDeviceService;
exports.TsdDeviceService = TsdDeviceService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        password_service_1.PasswordService,
        access_token_service_1.AccessTokenService,
        client_scope_service_1.ClientScopeService])
], TsdDeviceService);
function monitorPayload(body, deviceCode, workerName, workerUserId) {
    return {
        monitorMessages: body.monitorMessages === true,
        deviceCode,
        workerName,
        workerUserId,
        screen: monitorText(body.screen),
        screenLabel: monitorText(body.screenLabel),
        stage: monitorText(body.stage),
        state: monitorText(body.state),
        requestId: monitorText(body.requestId),
        requestNumber: monitorNumber(body.requestNumber),
        clientName: monitorText(body.clientName),
        orderId: monitorText(body.orderId),
        productName: monitorText(body.productName),
        boxCode: monitorText(body.boxCode),
        palletCode: monitorText(body.palletCode),
        barcode: monitorText(body.barcode),
        kiz: monitorText(body.kiz),
        skuId: monitorText(body.skuId),
        article: monitorText(body.article),
        productSize: monitorText(body.productSize),
        productColor: monitorText(body.productColor),
        inventorySessionId: monitorText(body.inventorySessionId),
        inventoryType: monitorText(body.inventoryType),
        inventoryMandatory: body.inventoryMandatory === true,
        inventoryBoxId: monitorText(body.inventoryBoxId),
        inventoryBoxCode: monitorText(body.inventoryBoxCode),
        total: monitorNumber(body.total),
        completed: monitorNumber(body.completed),
        remaining: monitorNumber(body.remaining),
        accepted: monitorNumber(body.accepted),
        lastAction: monitorText(body.lastAction),
        message: monitorText(body.message),
        appVersion: monitorText(body.appVersion),
        reportedAt: new Date().toISOString(),
    };
}
function jsonPayload(value) {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? value
        : {};
}
function monitorText(value) {
    return typeof value === 'string' ? value.trim().slice(0, 2000) : '';
}
function monitorNumber(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.max(0, Math.trunc(parsed)) : null;
}
function administrationPayloadValue(payload, key) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload))
        return undefined;
    return payload[key];
}
