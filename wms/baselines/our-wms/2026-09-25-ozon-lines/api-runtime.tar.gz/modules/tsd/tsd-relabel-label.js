"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildTsdRelabelLabel = buildTsdRelabelLabel;
const bwipjs = require("bwip-js");
const pdfMake = require("pdfmake");
const pdf_parse_1 = require("pdf-parse");
const pdfmake_1 = require("../../common/pdf/pdfmake");
const MM = 72 / 25.4;
async function buildTsdRelabelLabel(barcode, product, clientName) {
    (0, pdfmake_1.configurePdfMake)();
    const clean = (value) => (value ?? '').replace(/[\x00-\x1f]/g, ' ').trim();
    const line = (value, y, fontSize, bold = false) => ({
        absolutePosition: { x: 2 * MM, y: y * MM },
        columns: [{ width: 54 * MM, text: value, fontSize, bold, noWrap: true, margin: 0 }],
    });
    const fit = (value, max) => value.length > max ? `${value.slice(0, max - 1)}…` : value;
    const name = clean(product.name);
    const nameCut = name.length > 31 ? name.lastIndexOf(' ', 31) : -1;
    const nameLines = nameCut > 15 ? `${name.slice(0, nameCut)}\n${fit(name.slice(nameCut + 1), 34)}` : fit(name, 60);
    // FIX: the same barcode is rendered twice by the existing quiet-print agent.
    // Keep every field inside the 58 × 40 mm paper configured on station 2409.
    const barcodeSvg = bwipjs.toSVG({ bcid: 'code128', text: barcode, scale: 2, height: 12, includetext: false });
    const content = [
        { svg: barcodeSvg, width: 40 * MM, height: 11 * MM, absolutePosition: { x: 2 * MM, y: 1 * MM } },
        { text: 'EAC', bold: true, fontSize: 13, absolutePosition: { x: 44 * MM, y: 3 * MM } },
        line(barcode, 12, 8, true),
        { absolutePosition: { x: 2 * MM, y: 17 * MM }, columns: [{
                    width: 54 * MM, text: nameLines, fontSize: 7, bold: true, lineHeight: 0.9, margin: 0,
                }] },
        ...(product.article ? [line(`Артикул: ${fit(clean(product.article), 41)}`, 25, 6.5)] : []),
        ...(product.color ? [line(`Цвет: ${fit(clean(product.color), 44)}`, 29, 6.5)] : []),
        ...(product.size ? [line(`Размер: ${fit(clean(product.size), 43)}`, 33, 6.5, true)] : []),
        ...(product.brand ? [line(`Бренд: ${fit(clean(product.brand), 29)}`, 36, 6, true)] : []),
        { absolutePosition: { x: 28 * MM, y: 36 * MM }, columns: [{
                    width: 28 * MM, text: fit(clean(clientName), 24), fontSize: 5.5, alignment: 'right', margin: 0,
                }] },
    ];
    const pdf = await pdfMake.createPdf({
        pageSize: { width: 58 * MM, height: 40 * MM }, pageMargins: 0,
        defaultStyle: { font: 'DejaVuSans' }, content,
    }).getBuffer();
    const parser = new pdf_parse_1.PDFParse({ data: pdf });
    try {
        const result = await parser.getScreenshot({ desiredWidth: 696, imageDataUrl: false, imageBuffer: true });
        if (result.pages.length !== 1 || !result.pages[0]?.data?.length)
            throw new Error('Этикетка не поместилась на одну страницу.');
        return Buffer.from(result.pages[0].data).toString('base64');
    }
    finally {
        await parser.destroy();
    }
}
