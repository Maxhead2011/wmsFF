"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentFbsTsdUser = void 0;
const common_1 = require("@nestjs/common");
const fbs_physical_pick_1 = require("../marketplace-connections/fbs-physical-pick");
// FIX: old terminals keep their label screen until their app advertises the new workflow.
exports.CurrentFbsTsdUser = (0, common_1.createParamDecorator)((_data, context) => {
    const request = context.switchToHttp().getRequest();
    return (0, fbs_physical_pick_1.withFbsTsdCapability)(request.user, request.headers['x-tsd-fbs-capability']);
});
