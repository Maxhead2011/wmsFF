"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fboLocalRouteEnabled = void 0;
exports.prioritizeFboLocation = prioritizeFboLocation;
const fboLocalRouteEnabled = () => process.env.WMS_FBO_LOCAL_ROUTE_ENABLED === 'true';
exports.fboLocalRouteEnabled = fboLocalRouteEnabled;
// FIX: location is a preference among already authorized, non-busy boxes, never a reservation.
function prioritizeFboLocation(boxes, demand, context, wholeOrder) {
    const pallet = context.palletCode?.trim();
    if (!pallet)
        return wholeOrder(boxes, demand);
    const remaining = { ...demand };
    const here = boxes.filter(b => (b.storagePlacement?.pallet.code ?? b.pallet?.code) === pallet);
    const selected = here.filter(b => b.code === context.sourceBoxCode);
    const result = [];
    const consume = (group) => {
        for (const box of group) {
            result.push(box);
            for (const b of box.balances)
                if (b.status === 'AVAILABLE' && b.quantity > 0)
                    remaining[b.skuId] = Math.max(0, (remaining[b.skuId] ?? 0) - b.quantity);
        }
    };
    consume(selected);
    consume(wholeOrder(here.filter(b => !selected.includes(b)), remaining));
    consume(wholeOrder(boxes.filter(b => !here.includes(b)), remaining));
    return result;
}
