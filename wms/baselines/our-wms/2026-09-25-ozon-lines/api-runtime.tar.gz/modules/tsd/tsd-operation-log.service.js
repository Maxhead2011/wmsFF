"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdOperationLogService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
let TsdOperationLogService = class TsdOperationLogService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    findExisting(operationKey) {
        return this.prisma.tsdOperation.findUnique({ where: { operationKey } });
    }
    listReviewQueue(user) {
        this.clientScopes.requireGlobalClientAccess(user);
        return this.prisma.tsdOperation.findMany({
            where: { status: client_1.TsdOperationStatus.NEEDS_REVIEW },
            orderBy: { createdAt: 'desc' },
            take: 200,
        });
    }
    async recordResult(operation, status, message, reviewReason, resolutionMessage) {
        const persistedStatus = this.toPersistedStatus(status);
        await this.prisma.tsdOperation.upsert({
            where: { operationKey: operation.operationKey },
            update: {
                status: persistedStatus,
                serverMessage: message,
                reviewReason,
                resolutionMessage,
            },
            create: {
                deviceId: operation.deviceId,
                operationKey: operation.operationKey,
                operationType: operation.operationType,
                payload: operation.payload,
                status: persistedStatus,
                serverMessage: message,
                reviewReason,
                resolutionMessage,
            },
        });
        return this.result(operation, status, message, reviewReason, resolutionMessage);
    }
    existingResult(operation, existing) {
        const message = existing.resolutionMessage ?? existing.serverMessage ?? undefined;
        const reviewReason = existing.reviewReason ?? undefined;
        const resolutionMessage = existing.resolutionMessage ?? undefined;
        if (existing.status === client_1.TsdOperationStatus.ACCEPTED) {
            return this.result(operation, 'ALREADY_APPLIED', message, reviewReason, resolutionMessage);
        }
        return this.result(operation, existing.status, message, reviewReason, resolutionMessage);
    }
    result(operation, status, message, reviewReason, resolutionMessage) {
        return {
            operationKey: operation.operationKey,
            operationType: operation.operationType,
            status,
            message,
            reviewReason,
            resolutionMessage,
            serverTime: new Date().toISOString(),
        };
    }
    toPersistedStatus(status) {
        if (status === 'NEEDS_REVIEW') {
            return client_1.TsdOperationStatus.NEEDS_REVIEW;
        }
        if (status === 'REJECTED') {
            return client_1.TsdOperationStatus.REJECTED;
        }
        // Русский комментарий: APPLIED/ACCEPTED/ALREADY_APPLIED в TSD log считаются закрытой операцией.
        return client_1.TsdOperationStatus.ACCEPTED;
    }
};
exports.TsdOperationLogService = TsdOperationLogService;
exports.TsdOperationLogService = TsdOperationLogService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], TsdOperationLogService);
