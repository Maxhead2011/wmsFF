"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdSyncService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const stock_operations_service_1 = require("../stock/stock-operations.service");
const tsd_device_service_1 = require("./tsd-device.service");
const tsd_assembly_service_1 = require("./tsd-assembly.service");
const tsd_operation_log_service_1 = require("./tsd-operation-log.service");
const tsd_payload_parser_1 = require("./tsd-payload.parser");
const tsd_receipt_service_1 = require("./tsd-receipt.service");
let TsdSyncService = class TsdSyncService {
    stockOperations;
    devices;
    prisma;
    clientScopes;
    payloadParser;
    operationLog;
    assembly;
    receipts;
    requestLocks = new Map();
    constructor(stockOperations, devices, prisma, clientScopes, payloadParser, operationLog, assembly, receipts) {
        this.stockOperations = stockOperations;
        this.devices = devices;
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.payloadParser = payloadParser;
        this.operationLog = operationLog;
        this.assembly = assembly;
        this.receipts = receipts;
    }
    async acceptOperation(operation, user) {
        const [result] = await this.syncOperations({ operations: [operation] }, user);
        return result;
    }
    async syncOperations(dto, user) {
        await this.devices.touchActiveDevice(user.deviceId);
        const results = [];
        for (const operation of dto.operations) {
            results.push(await this.applyOperation(operation, user));
        }
        return results;
    }
    listReviewQueue(user) {
        return this.operationLog.listReviewQueue(user);
    }
    async applyOperation(operation, user) {
        // FIX: close owns its transactional idempotency and scope checks. RETRY must
        // never enter recordResult(), whose persisted statuses are terminal.
        if (operation.operationType === 'receipt_close') {
            try {
                if (!this.receipts)
                    throw new Error('Серверное закрытие приемки временно недоступно.');
                return await this.receipts.closeBox(operation, user);
            }
            catch (caught) {
                return {
                    operationKey: operation.operationKey,
                    operationType: operation.operationType,
                    status: caught instanceof common_1.BadRequestException || caught instanceof common_1.ForbiddenException ? 'REJECTED' : 'RETRY',
                    message: caught instanceof common_1.BadRequestException || caught instanceof common_1.ForbiddenException
                        ? caught.message
                        : 'Не удалось подтвердить закрытие короба. Повторим синхронизацию без повторного прихода.',
                    serverTime: new Date().toISOString(),
                };
            }
        }
        try {
            if (user.deviceCode && operation.deviceId !== user.deviceCode) {
                return await this.operationLog.recordResult(operation, 'REJECTED', 'Операция пришла не от устройства из access token.', client_1.TsdReviewReason.DEVICE_MISMATCH);
            }
            const existing = await this.operationLog.findExisting(operation.operationKey);
            if (existing) {
                return this.operationLog.existingResult(operation, existing);
            }
            if (operation.operationType === 'move_scan') {
                const requestId = optionalText(operation.payload.requestId);
                return requestId
                    ? await this.withRequestLock(requestId, async () => {
                        await this.assembly?.assertMovementProgressAvailable(requestId, operation.payload, user);
                        return this.applyMoveScan(operation, user);
                    })
                    : await this.applyMoveScan(operation, user);
            }
            if (operation.operationType === 'receipt_scan') {
                return await this.applyReceiptScan(operation, user);
            }
            if (operation.operationType === 'assembly_stage') {
                return await this.applyAssemblyProgress(operation, user);
            }
            return await this.applyInventoryScan(operation, user);
        }
        catch (caught) {
            return await this.operationLog.recordResult(operation, 'REJECTED', caught instanceof Error ? caught.message : 'Операция ТСД отклонена.', client_1.TsdReviewReason.VALIDATION_ERROR);
        }
    }
    async applyAssemblyProgress(operation, user) {
        const requestId = optionalText(operation.payload.requestId);
        const action = optionalText(operation.payload.action) ?? optionalText(operation.payload.progressKind);
        if (!requestId || !action || !['relabel-complete', 'outgoing-confirm'].includes(action)) {
            return this.operationLog.recordResult(operation, 'ACCEPTED');
        }
        return this.withRequestLock(requestId, async () => {
            if (action === 'relabel-complete') {
                await this.assembly?.assertRelabelProgressAvailable(requestId, operation.payload, user);
            }
            else {
                await this.assembly?.assertOutgoingBoxAvailable(requestId, operation.payload, user);
            }
            return this.operationLog.recordResult(operation, 'ACCEPTED');
        });
    }
    async withRequestLock(requestId, task) {
        const previous = this.requestLocks.get(requestId) ?? Promise.resolve();
        let release = () => { };
        const gate = new Promise((resolve) => {
            release = resolve;
        });
        const tail = previous.then(() => gate);
        this.requestLocks.set(requestId, tail);
        await previous;
        try {
            return await task();
        }
        finally {
            release();
            if (this.requestLocks.get(requestId) === tail)
                this.requestLocks.delete(requestId);
        }
    }
    async applyMoveScan(operation, user) {
        const payload = this.payloadParser.parseMovePayload(operation.payload);
        const transfer = await this.stockOperations.transferBetweenBoxes({
            clientId: payload.clientId,
            barcode: payload.barcode,
            skuId: payload.skuId,
            fromBoxCode: payload.fromBoxCode,
            toBoxCode: payload.toBoxCode,
            quantity: payload.quantity,
            status: payload.status,
            idempotencyKey: operation.operationKey,
            comment: payload.comment ?? `ТСД ${operation.deviceId}`,
        }, user);
        return this.operationLog.recordResult(operation, transfer.status === 'ALREADY_APPLIED' ? 'ALREADY_APPLIED' : 'APPLIED');
    }
    async applyReceiptScan(operation, user) {
        const payload = this.payloadParser.parseReceiptPayload(operation.payload);
        try {
            const client = await this.prisma.client.findUnique({
                where: { id: payload.clientId },
                select: { storesWithoutBoxes: true },
            });
            if (!client) {
                throw new common_1.BadRequestException('Клиент приемки не найден.');
            }
            const receiptUsesBoxes = payload.receiptMode === 'BOXES' || !client.storesWithoutBoxes;
            if (receiptUsesBoxes && !payload.boxCode) {
                throw new common_1.BadRequestException('Для этого клиента приемка выполняется с коробами. Сначала отсканируйте номер короба.');
            }
            const receipt = await this.stockOperations.receiveIntoBox({
                clientId: payload.clientId,
                barcode: payload.barcode,
                skuId: payload.skuId,
                kiz: payload.kiz,
                boxCode: receiptUsesBoxes ? payload.boxCode : undefined,
                quantity: payload.quantity,
                status: payload.status,
                sourceDocument: payload.sourceDocument,
                idempotencyKey: operation.operationKey,
                comment: payload.comment ?? `Приемка ТСД ${operation.deviceId}`,
            }, user);
            return this.operationLog.recordResult(operation, receipt.status === 'ALREADY_APPLIED' ? 'ALREADY_APPLIED' : 'APPLIED');
        }
        catch (caught) {
            return this.operationLog.recordResult(operation, 'NEEDS_REVIEW', caught instanceof Error ? caught.message : 'Приемка ТСД требует разбора.', client_1.TsdReviewReason.RECEIPT_FAILED);
        }
    }
    async applyInventoryScan(operation, user) {
        const payload = this.payloadParser.parseInventoryPayload(operation.payload);
        this.clientScopes.requireClientAccess(user, payload.clientId, 'write');
        const sku = await this.findSku(payload.clientId, payload);
        if (!sku) {
            return this.operationLog.recordResult(operation, 'NEEDS_REVIEW', 'SKU или штрихкод не найден у клиента.', client_1.TsdReviewReason.SKU_NOT_FOUND);
        }
        const box = await this.prisma.box.findUnique({
            where: { clientId_code: { clientId: payload.clientId, code: payload.boxCode } },
        });
        if (!box) {
            return this.operationLog.recordResult(operation, 'NEEDS_REVIEW', `Короб ${payload.boxCode} не найден.`, client_1.TsdReviewReason.BOX_NOT_FOUND);
        }
        const status = payload.status ?? client_1.StockStatus.AVAILABLE;
        const balance = await this.prisma.stockBalance.findFirst({
            where: {
                clientId: payload.clientId,
                skuId: sku.id,
                boxId: box.id,
                status,
            },
        });
        const currentQuantity = balance?.quantity ?? 0;
        if (currentQuantity !== payload.countedQuantity) {
            return this.operationLog.recordResult(operation, 'NEEDS_REVIEW', `Расхождение инвентаризации: в WMS ${currentQuantity}, на ТСД ${payload.countedQuantity}.`, client_1.TsdReviewReason.INVENTORY_MISMATCH);
        }
        return this.operationLog.recordResult(operation, 'ACCEPTED', 'Инвентаризация совпала с остатком WMS.');
    }
    findSku(clientId, payload) {
        if (payload.skuId) {
            return this.prisma.sku.findFirst({ where: { id: payload.skuId, clientId } });
        }
        return this.prisma.barcode
            .findFirst({
            where: {
                value: payload.barcode,
                sku: { clientId },
            },
            include: { sku: true },
        })
            .then((barcode) => barcode?.sku ?? null);
    }
};
exports.TsdSyncService = TsdSyncService;
exports.TsdSyncService = TsdSyncService = __decorate([
    (0, common_1.Injectable)(),
    __param(6, (0, common_1.Optional)()),
    __param(7, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [stock_operations_service_1.StockOperationsService,
        tsd_device_service_1.TsdDeviceService,
        prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        tsd_payload_parser_1.TsdPayloadParser,
        tsd_operation_log_service_1.TsdOperationLogService,
        tsd_assembly_service_1.TsdAssemblyService,
        tsd_receipt_service_1.TsdReceiptService])
], TsdSyncService);
function optionalText(value) {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
