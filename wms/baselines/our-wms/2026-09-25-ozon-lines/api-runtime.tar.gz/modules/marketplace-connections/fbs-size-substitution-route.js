"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approvedSizeRoutes = approvedSizeRoutes;
const client_1 = require("@prisma/client");
const fbs_size_substitution_1 = require("./fbs-size-substitution");
// FIX: approval follows the exact task/request/source, never a product-wide exception.
async function approvedSizeRoutes(db, tasks) {
    const candidates = tasks.filter(t => t.marketplace === 'WILDBERRIES' && t.sourceSkuId && t.relabelRequired &&
        !t.relabelConfirmedAt && !t.completedAt && !t.kiz && ['RESERVED', 'WAITING_STOCK'].includes(t.status));
    if (!(0, fbs_size_substitution_1.sizeSubstitutionEnabled)() || !candidates.length)
        return new Set();
    const rows = await db.$queryRaw `
    SELECT * FROM "FbsSizeSubstitution" WHERE "taskId" IN (${client_1.Prisma.join(candidates.map(t => t.id))})`;
    return new Set(candidates.filter(t => rows.some(r => r.taskId === t.id && r.requestId === t.requestId &&
        r.clientId === t.clientId && r.sourceSkuId === t.sourceSkuId && r.targetSkuId === t.skuId && r.warehouseId === t.stockWarehouseId)).map(t => t.id));
}
