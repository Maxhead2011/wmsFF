"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WB_CATALOG_INTERVAL_MS = void 0;
exports.catalogIdentityMatches = catalogIdentityMatches;
exports.classifyWbCatalog = classifyWbCatalog;
exports.readWbCatalogBlocks = readWbCatalogBlocks;
exports.verifiedCatalogZeroIds = verifiedCatalogZeroIds;
exports.synchronizeWbCatalog = synchronizeWbCatalog;
const wb_stock_observations_1 = require("./wb-stock-observations");
exports.WB_CATALOG_INTERVAL_MS = 15 * 60_000;
const prefix = 'marketplace.wbCatalog.';
const normalized = (s) => (s ?? '').trim().toLowerCase();
// Article/size changes cannot silently rename physical inventory or historical orders.
function catalogIdentityMatches(sku, product) {
    if (normalized(sku.article) !== normalized(product.article))
        return false;
    if (normalized(sku.size) === normalized(product.size))
        return true;
    // A changed letter label is harmless only with stable card, size ID, barcode
    // and explicit numeric Russian size. Do not infer identity from size text alone.
    const russianSize = (size) => {
        const match = normalized(size).match(/^[a-z]+(?:-[a-z]+)?\s*\/\s*(\d+(?:-\d+)?)$/);
        return match?.[1];
    };
    const oldSize = russianSize(sku.size), newSize = russianSize(product.size);
    return Boolean(oldSize && oldSize === newSize && sku.marketplaceProductId === product.productId
        && sku.marketplaceOfferId && product.barcodes?.includes(sku.marketplaceOfferId));
}
function classifyWbCatalog(skus, products) {
    const byId = new Map(products.map(p => [p.productId, p]));
    if (!products.length || byId.size !== products.length)
        throw new Error('Каталог WB пуст или содержит повторные размеры; исключения не изменены.');
    return skus.flatMap(sku => {
        const chrtId = Number(sku.marketplaceProductId?.split(':')[1]);
        if (!Number.isSafeInteger(chrtId) || chrtId <= 0)
            return [];
        const product = byId.get(sku.marketplaceProductId);
        if (product && catalogIdentityMatches(sku, product))
            return [];
        return [{ skuId: sku.id, chrtId, reason: product ? 'IDENTITY_CHANGED' : 'MISSING',
                article: sku.article, size: sku.size, wbArticle: product?.article ?? null, wbSize: product?.size ?? null }];
    });
}
async function readWbCatalogBlocks(db, clientId, connectionId) {
    const key = prefix + clientId + '.';
    const states = await db.systemSetting.findMany({ where: { key: connectionId ? key + connectionId : { startsWith: key } }, select: { value: true } });
    return states.flatMap(row => {
        const state = row.value;
        if (!state || !Array.isArray(state.excluded))
            throw new Error('Повреждено состояние каталога WB.');
        return state.excluded;
    });
}
// Only a recently completed catalog traversal and an updated matching SKU may
// initialize an absent stock record with zero. A missing response is never proof.
async function verifiedCatalogZeroIds(db, clientId, connectionId, chrtIds) {
    if (!chrtIds.length)
        return new Set();
    const row = await db.systemSetting.findUnique({ where: { key: prefix + clientId + '.' + connectionId } });
    const state = row?.value;
    const started = Date.parse(state?.startedAt ?? ''), completed = Date.parse(state?.completedAt ?? '');
    if (!Number.isFinite(started) || !Number.isFinite(completed) || completed < started || completed > Date.now() || Date.now() - completed > 30 * 60_000 || !Array.isArray(state?.excluded))
        return new Set();
    const blocked = new Set(state.excluded.map(x => x.chrtId));
    const wanted = new Set(chrtIds);
    const skus = await db.sku.findMany({ where: { clientId, marketplace: 'WILDBERRIES', isDraft: false, marketplaceSyncedAt: { gte: new Date(started) } }, select: { marketplaceProductId: true } });
    return new Set(skus.map(s => Number(s.marketplaceProductId?.split(':')[1])).filter(id => wanted.has(id) && !blocked.has(id)));
}
// A full uncached traversal must finish before any SKU/publication changes are made.
async function synchronizeWbCatalog(db, connection, fetchProducts, upsert, force = false) {
    const key = prefix + connection.clientId + '.' + connection.id;
    return db.$transaction(async (lease) => {
        const locks = await lease.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${key})) AS acquired`;
        if (!locks[0]?.acquired)
            return { busy: true };
        const previous = await db.systemSetting.findUnique({ where: { key } });
        const lastSuccess = previous?.value?.completedAt;
        if (!force && lastSuccess && Date.now() - Date.parse(lastSuccess) < exports.WB_CATALOG_INTERVAL_MS)
            return { fresh: true };
        const startedAt = new Date().toISOString();
        const products = await fetchProducts();
        if (!products.length)
            throw new Error('WB вернул пустой каталог. Существующие карточки и исключения сохранены.');
        await lease.$queryRaw `SELECT 1`;
        return new wb_stock_observations_1.WbStockObservations(db).locked(connection.id, false, async () => {
            const existing = await db.sku.findMany({ where: { clientId: connection.clientId, marketplace: 'WILDBERRIES', isDraft: false, marketplaceProductId: { not: null } }, select: { id: true, marketplaceProductId: true, marketplaceOfferId: true, article: true, size: true } });
            const excluded = classifyWbCatalog(existing, products);
            // Publish the block first; a partial upsert failure must remain fail-closed.
            const initial = { startedAt, completedAt: lastSuccess ?? null, excluded };
            await db.systemSetting.upsert({ where: { key }, create: { key, value: initial }, update: { value: initial } });
            const result = { marketplace: 'WILDBERRIES', clientId: connection.clientId, productsReceived: products.length, created: 0, updated: 0, mergedDrafts: 0, barcodesTouched: 0, skipped: 0, errors: [], excluded: excluded.length };
            const blockedProductIds = new Set(existing.filter(s => excluded.some(e => e.skuId === s.id && e.reason === 'IDENTITY_CHANGED')).map(s => s.marketplaceProductId));
            for (const product of products) {
                await lease.$queryRaw `SELECT 1`;
                if (blockedProductIds.has(product.productId)) {
                    result.skipped++;
                    continue;
                }
                try {
                    const saved = await upsert(product);
                    result[saved.created ? 'created' : 'updated']++;
                    result.mergedDrafts += saved.mergedDrafts;
                    result.barcodesTouched += saved.barcodesTouched;
                }
                catch (error) {
                    result.skipped++;
                    result.errors.push({ offerId: product.productId, message: error instanceof Error ? error.message : 'Ошибка обновления карточки.' });
                }
            }
            for (const reason of ['MISSING', 'IDENTITY_CHANGED']) {
                const skuIds = excluded.filter(e => e.reason === reason).map(e => e.skuId);
                if (skuIds.length)
                    await db.fbsStockPublication.updateMany({ where: { connectionId: connection.id, skuId: { in: skuIds } }, data: { lastError: reason === 'MISSING' ? 'WB_CATALOG_MISSING: размер отсутствует в полном каталоге WB; исключён из публикации.' : 'WB_CATALOG_IDENTITY_CHANGED: артикул или размер WB изменён; требуется сверка товара.' } });
            }
            // Preserve the user's enabled switch; restored identical sizes resume on the next stock cycle.
            const excludedIds = new Set(excluded.map(e => e.skuId));
            const restored = (previous?.value?.excluded ?? []).filter(e => !excludedIds.has(e.skuId)).map(e => e.skuId);
            if (restored.length)
                await db.fbsStockPublication.updateMany({ where: { connectionId: connection.id, skuId: { in: restored }, lastError: { startsWith: 'WB_CATALOG_' } }, data: { lastError: null } });
            const completedAt = new Date().toISOString();
            await db.systemSetting.update({ where: { key }, data: { value: { startedAt, completedAt, excluded, result } } });
            await db.auditLog.create({ data: { action: 'WB_CATALOG_SYNC', entity: 'ClientMarketplaceConnection', entityId: connection.id, payload: { startedAt, completedAt, result, excluded } } });
            return result;
        });
    }, { timeout: 600_000, maxWait: 5000 });
}
