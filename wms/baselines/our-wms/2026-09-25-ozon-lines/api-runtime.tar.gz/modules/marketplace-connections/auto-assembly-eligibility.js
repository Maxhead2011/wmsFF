"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isUntouchedAutoAssembly = isUntouchedAutoAssembly;
exports.isUntouchedBackgroundAssembly = isUntouchedBackgroundAssembly;
exports.autoAssemblyOzonError = autoAssemblyOzonError;
// A pre-reservation is not a picking request. Never recycle physical work.
function isUntouchedAutoAssembly(task) {
    return task.requestId === `AUTO:${task.marketplace}:${task.connectionId}:${task.orderId}` &&
        isUntouchedBackgroundAssembly(task);
}
// Real request linkage does not make an untouched background task physical work.
function isUntouchedBackgroundAssembly(task) {
    return task.deviceCode === 'AUTO:FBS:PALLET_SORT' &&
        ['RESERVED', 'WAITING_STOCK', 'RELEASED'].includes(task.status) &&
        !task.workerUserId && !task.workerName && !task.startedAt &&
        !task.boxId && (!task.boxCode || task.boxCode === 'БЕЗ КОРОБА') &&
        !task.sourceBarcode && !task.barcode && !task.kiz && !task.scannedItemCount &&
        !task.relabelConfirmedAt && !task.completedAt && !task.marketplaceSubmittedAt &&
        !task.sourceBoxPending && !task.cargoPackingId && !task.cargoPackedAt;
}
function autoAssemblyOzonError(connection) {
    if (connection.marketplace !== 'OZON')
        return null;
    if (!/^[1-9]\d*$/.test(connection.sellerId ?? ''))
        return 'Для автосборки Ozon нужен числовой Client-Id продавца, а не название магазина.';
    if (!connection.fbsExecutionWarehouseId)
        return 'Для автосборки Ozon назначьте склад исполнения WMS.';
    return null;
}
