"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.canSubstituteSize = exports.sizeSubstitutionEnabled = void 0;
exports.sizeRank = sizeRank;
exports.replacementDistance = replacementDistance;
exports.preferredReplacements = preferredReplacements;
// FIX: size substitution is explicitly enabled per installation.
const sizeSubstitutionEnabled = () => process.env.WMS_FBS_SIZE_SUBSTITUTION_ENABLED === 'true';
exports.sizeSubstitutionEnabled = sizeSubstitutionEnabled;
const canSubstituteSize = (user) => !user.isDemo && user.roleCodes.some(r => r === 'ADMIN' || r === 'OWNER');
exports.canSubstituteSize = canSubstituteSize;
const normalize = (value) => (value ?? '').trim().toLocaleLowerCase('ru-RU').replace(/ё/g, 'е');
function sizeRank(size) {
    const value = (size ?? '').trim().toUpperCase();
    const alpha = /^(XXXS|XXS|XS|S|M|L|XL|XXL|XXXL|2XL|3XL|4XL|5XL)(?:\s*\/\s*\d{2})?$/.exec(value);
    if (alpha)
        return ['XXXS', 'XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', '4XL', '5XL'].indexOf(alpha[1].replace('2XL', 'XXL').replace('3XL', 'XXXL'));
    if (/^\d{2}$/.test(value) && Number(value) >= 36 && Number(value) <= 64 && Number(value) % 2 === 0)
        return (Number(value) - 36) / 2;
    return null;
}
// FIX: never infer a different model/colour from similar names. Unrecognised sizes require a catalogue correction.
function replacementDistance(target, source, mappings = []) {
    const article = normalize(target.article || target.clientSku);
    const sourceArticle = normalize(source.article || source.clientSku);
    const approvedArticle = article === sourceArticle || mappings.some(m => normalize(m.targetArticle) === article && normalize(m.sourceArticle) === sourceArticle);
    if (target.id === source.id || !article || !sourceArticle || !approvedArticle ||
        !normalize(target.color) || normalize(target.color) !== normalize(source.color))
        return null;
    const a = sizeRank(target.size), b = sizeRank(source.size);
    return a === null || b === null || a === b ? null : Math.abs(a - b);
}
function preferredReplacements(rows) {
    const available = rows.filter(row => row.available > 0);
    const adjacent = available.filter(row => row.distance === 1);
    return (adjacent.length ? adjacent : available).sort((a, b) => a.distance - b.distance || b.available - a.available);
}
