"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketplaceConnectionsModule = void 0;
const wb_stock_confirmation_controller_1 = require("./wb-stock-confirmation.controller");
const wb_stock_confirmation_service_1 = require("./wb-stock-confirmation.service");
const duplicate_stock_groups_controller_1 = require("./duplicate-stock-groups.controller");
const duplicate_stock_groups_service_1 = require("./duplicate-stock-groups.service");
const marketplace_allocation_controller_1 = require("./marketplace-allocation.controller");
const marketplace_allocation_service_1 = require("./marketplace-allocation.service");
const fbs_size_substitution_service_1 = require("./fbs-size-substitution.service");
const fbs_size_substitution_controller_1 = require("./fbs-size-substitution.controller");
const wb_sync_health_service_1 = require("./wb-sync-health.service");
const wb_sync_health_controller_1 = require("./wb-sync-health.controller");
const common_1 = require("@nestjs/common");
const client_notifications_module_1 = require("../client-notifications/client-notifications.module");
const auth_module_1 = require("../auth/auth.module");
const logistics_module_1 = require("../logistics/logistics.module");
const wms_stock_availability_service_1 = require("../stock/wms-stock-availability.service");
const fbs_penalties_report_service_1 = require("./fbs-penalties-report.service");
const fbs_product_shipments_report_service_1 = require("./fbs-product-shipments-report.service");
const fbs_stock_allocation_external_controller_1 = require("./fbs-stock-allocation-external.controller");
const fbs_stock_allocation_service_1 = require("./fbs-stock-allocation.service");
const fbs_stock_monitoring_service_1 = require("./fbs-stock-monitoring.service");
const marketplace_connections_controller_1 = require("./marketplace-connections.controller");
const marketplace_connections_service_1 = require("./marketplace-connections.service");
const marketplace_stock_control_service_1 = require("./marketplace-stock-control.service");
const fbs_repeat_assembly_service_1 = require("./fbs-repeat-assembly.service");
const fbs_repeat_assembly_controller_1 = require("./fbs-repeat-assembly.controller");
const fbs_reshipment_controller_1 = require("./fbs-reshipment.controller");
const fbs_reshipment_service_1 = require("./fbs-reshipment.service");
let MarketplaceConnectionsModule = class MarketplaceConnectionsModule {
};
exports.MarketplaceConnectionsModule = MarketplaceConnectionsModule;
exports.MarketplaceConnectionsModule = MarketplaceConnectionsModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, logistics_module_1.LogisticsModule, client_notifications_module_1.ClientNotificationsModule],
        controllers: [wb_stock_confirmation_controller_1.WbStockConfirmationController, duplicate_stock_groups_controller_1.DuplicateStockGroupsController, marketplace_allocation_controller_1.MarketplaceAllocationController, fbs_size_substitution_controller_1.FbsSizeSubstitutionController, wb_sync_health_controller_1.WbSyncHealthController, marketplace_connections_controller_1.MarketplaceConnectionsController, fbs_stock_allocation_external_controller_1.FbsStockAllocationExternalController, fbs_repeat_assembly_controller_1.FbsRepeatAssemblyController, fbs_reshipment_controller_1.FbsReshipmentController],
        providers: [wb_stock_confirmation_service_1.WbStockConfirmationService, duplicate_stock_groups_service_1.DuplicateStockGroupsService, marketplace_allocation_service_1.MarketplaceAllocationService, fbs_size_substitution_service_1.FbsSizeSubstitutionService, wb_sync_health_service_1.WbSyncHealthService,
            marketplace_stock_control_service_1.MarketplaceStockControlService,
            // FIX: keep current stock-control registration when adding independent repeats.
            fbs_repeat_assembly_service_1.FbsRepeatAssemblyService,
            fbs_reshipment_service_1.FbsReshipmentService,
            marketplace_connections_service_1.MarketplaceConnectionsService,
            // ADDED: isolated read-only WB Finance integration for FBS penalties.
            fbs_penalties_report_service_1.FbsPenaltiesReportService,
            fbs_product_shipments_report_service_1.FbsProductShipmentsReportService,
            fbs_stock_allocation_service_1.FbsStockAllocationService,
            fbs_stock_monitoring_service_1.FbsStockMonitoringService,
            // ADDED: one read-only availability calculation is shared by reports and Excel.
            wms_stock_availability_service_1.WmsStockAvailabilityService,
        ],
        exports: [marketplace_connections_service_1.MarketplaceConnectionsService, fbs_stock_monitoring_service_1.FbsStockMonitoringService, marketplace_stock_control_service_1.MarketplaceStockControlService],
    })
], MarketplaceConnectionsModule);
