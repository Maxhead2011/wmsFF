"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.selectKnownWbStockTargets = selectKnownWbStockTargets;
exports.publishWbStockPlan = publishWbStockPlan;
const wb_stock_sync_queue_1 = require("./wb-stock-sync-queue");
const fbs_stock_publication_history_1 = require("./fbs-stock-publication-history");
// FIX: quarantine an unknown size across all warehouses, preserving its existing stock everywhere.
async function selectKnownWbStockTargets(targets, read, record, verifyZeros) {
    const missing = new Set();
    for (const warehouse of new Set(targets.map(t => t.warehouseId))) {
        const rows = targets.filter(t => t.warehouseId === warehouse);
        for (let i = 0; i < rows.length; i += 1000) {
            const batch = rows.slice(i, i + 1000);
            const amounts = await read(warehouse, batch.map(t => t.chrtId));
            for (const row of batch) {
                const amount = amounts.get(row.chrtId);
                if (amount === undefined)
                    missing.add(row.chrtId);
                else if (!Number.isSafeInteger(amount) || amount < 0)
                    throw new Error('WB вернул некорректный остаток.');
            }
        }
    }
    const zeroOnly = [...missing].filter(id => targets.filter(t => t.chrtId === id).every(t => t.amount === 0));
    const allowedZeros = verifyZeros ? await verifyZeros(zeroOnly) : new Set();
    const unknown = targets.filter(t => missing.has(t.chrtId) && !allowedZeros.has(t.chrtId));
    // FIX: retain unknown targets in the durable urgent queue, not just in the UI warning.
    (0, wb_stock_sync_queue_1.deferUnconfirmedWbStock)(unknown);
    for (const row of unknown)
        await record({ ...row, phase: 'STOP', status: 'UNCONFIRMED', error: 'WB не вернул остаток размера на одном из складов. Товар пропущен на всех складах; нужна проверка привязки карточки WB.' });
    return { known: targets.filter(t => !missing.has(t.chrtId) || allowedZeros.has(t.chrtId)).map(t => ({ ...t, initializeZero: allowedZeros.has(t.chrtId) })), unknown };
}
// FIX: all decreases, including stale warehouses, must be verified before ANY increase.
async function publishWbStockPlan(targets, io) {
    const keys = new Set();
    for (const row of targets) {
        const key = `${row.warehouseId}:${row.chrtId}`;
        if (keys.has(key) || !Number.isSafeInteger(row.amount) || row.amount < 0)
            throw new Error('Неоднозначный план остатков WB.');
        keys.add(key);
    }
    const before = new Map();
    const completed = new Set();
    const blocked = new Set();
    const block = (rows) => {
        const ids = rows.map(r => r.chrtId);
        for (const id of [...ids, ...(io.dependentChrtIds?.(ids) ?? [])])
            blocked.add(id);
    };
    const key = (row) => `${row.warehouseId}:${row.chrtId}`;
    async function read(rows, initializing = false) {
        const result = new Map();
        for (const warehouseId of new Set(rows.map(r => r.warehouseId))) {
            const selected = rows.filter(r => r.warehouseId === warehouseId);
            for (let i = 0; i < selected.length; i += 1000) {
                const batch = selected.slice(i, i + 1000);
                const amounts = await io.read(warehouseId, batch.map(r => r.chrtId));
                for (const row of batch) {
                    const amount = amounts.get(row.chrtId);
                    if (amount === undefined && initializing && row.initializeZero && row.amount === 0)
                        continue;
                    if (amount == null || !Number.isSafeInteger(amount) || amount < 0)
                        throw new Error(`WB не вернул достоверный остаток ${row.chrtId} на складе ${warehouseId}.`);
                    result.set(key(row), amount);
                }
            }
        }
        return result;
    }
    try {
        for (const row of targets)
            await io.record({ ...row, phase: 'PLAN', status: 'PLANNED' });
        for (const [id, amount] of await read(targets, true))
            before.set(id, amount);
        const decreases = targets.filter(r => r.amount < before.get(key(r)) || !before.has(key(r)));
        const increases = targets.filter(r => r.amount > before.get(key(r)));
        const unchanged = targets.filter(r => r.amount === before.get(key(r)));
        for (const row of unchanged) {
            await io.record({ ...row, phase: 'CHECK', status: 'CONFIRMED', observedAmount: row.amount });
            completed.add(key(row));
        }
        for (const [phase, rows] of [['DECREASE', decreases], ['INCREASE', increases]]) {
            for (const warehouseId of new Set(rows.map(r => r.warehouseId))) {
                const selected = rows.filter(r => r.warehouseId === warehouseId && (phase === 'DECREASE' || !blocked.has(r.chrtId)));
                for (let i = 0; i < selected.length; i += 1000) {
                    const batch = selected.slice(i, i + 1000).filter(r => phase === 'DECREASE' || !blocked.has(r.chrtId));
                    if (!batch.length)
                        continue;
                    for (const row of batch)
                        await io.record({ ...row, phase, status: 'SENDING', sentAmount: row.amount });
                    let sendMismatch;
                    try {
                        await io.send(warehouseId, batch.map(r => ({ chrtId: r.chrtId, amount: r.amount })), batch.filter(r => r.initializeZero && r.amount === 0).map(r => r.chrtId));
                    }
                    catch (error) {
                        if (!(error instanceof fbs_stock_publication_history_1.WbStockVerificationError))
                            throw error;
                        sendMismatch = error;
                    }
                    for (const row of batch)
                        await io.record({ ...row, phase, status: 'SENT', sentAmount: row.amount });
                    // A cached response or missing row must never be treated as acknowledgement.
                    const actual = sendMismatch ? new Map(batch.map(r => [key(r), sendMismatch.observed.get(r.chrtId)])) : await read(batch);
                    for (const row of batch) {
                        const observedAmount = actual.get(key(row));
                        const status = observedAmount === row.amount ? 'CONFIRMED' : 'MISMATCH';
                        await io.record({ ...row, phase, status, sentAmount: row.amount, observedAmount });
                        completed.add(key(row));
                        if (status === 'MISMATCH')
                            block([row]);
                    }
                    // A failed SKU/pool cannot receive increases, but independent SKUs may finish.
                }
            }
            if (phase === 'DECREASE' && increases.length) {
                // Recheck the complete budget after decreases; sales/external edits require a new plan.
                const eligible = targets.filter(r => !blocked.has(r.chrtId));
                const current = await read(eligible);
                const changed = eligible.filter(r => current.get(key(r)) !== (!before.has(key(r)) || r.amount <= before.get(key(r)) ? r.amount : before.get(key(r))));
                block(changed);
                for (const row of changed)
                    await io.record({ ...row, phase: 'RECHECK', status: 'MISMATCH', observedAmount: current.get(key(row)), error: 'Остатки WB изменились во время распределения. Нужен свежий расчёт.' });
            }
        }
        const confirmedTargets = targets.filter(r => completed.has(key(r)) && !blocked.has(r.chrtId));
        const unconfirmedTargets = targets.filter(r => !completed.has(key(r)) || blocked.has(r.chrtId));
        (0, wb_stock_sync_queue_1.deferUnconfirmedWbStock)(unconfirmedTargets);
        for (const row of unconfirmedTargets)
            if (!completed.has(key(row)))
                await io.record({ ...row, phase: 'STOP', status: 'UNCONFIRMED', error: 'Связанный остаток не подтверждён. Увеличение отложено до нового расчёта.' });
        if (unconfirmedTargets.length && !io.allowPartial)
            throw new Error('WB пока не подтвердил рассчитанные остатки. Требуется новый расчёт.');
        return { verified: confirmedTargets.length, publishedAmount: confirmedTargets.reduce((n, r) => n + r.amount, 0), confirmedTargets, unconfirmedTargets };
    }
    catch (error) {
        for (const row of targets)
            if (!completed.has(key(row)))
                await io.record({ ...row, phase: 'STOP', status: 'UNCONFIRMED', error: (error instanceof Error ? error.message : 'Ошибка проверки WB').slice(0, 500) });
        throw error;
    }
}
