"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WbStockSyncWorker = exports.wbStockRetryDelay = exports.StaleWbStockPlan = exports.isUrgentWbStockSync = exports.inWbStockPlan = exports.urgentWbSkuIds = exports.urgentWbStockSyncEnabled = void 0;
exports.deferUnconfirmedWbStock = deferUnconfirmedWbStock;
exports.stockRevision = stockRevision;
exports.withWbStockPlan = withWbStockPlan;
exports.captureWbStockPlan = captureWbStockPlan;
exports.registerWbStockPlan = registerWbStockPlan;
exports.assertFreshWbStockPlan = assertFreshWbStockPlan;
exports.urgentWbStockScope = urgentWbStockScope;
exports.expandWbStockScope = expandWbStockScope;
const node_async_hooks_1 = require("node:async_hooks");
const node_crypto_1 = require("node:crypto");
const urgentWbStockSyncEnabled = () => process.env.WMS_WB_URGENT_STOCK_SYNC === 'true';
exports.urgentWbStockSyncEnabled = urgentWbStockSyncEnabled;
const urgentWbSkuIds = () => urgent.getStore()?.skuIds ?? null;
exports.urgentWbSkuIds = urgentWbSkuIds;
const plans = new node_async_hooks_1.AsyncLocalStorage();
const urgent = new node_async_hooks_1.AsyncLocalStorage();
const inWbStockPlan = (clientId) => plans.getStore()?.clientId === clientId;
exports.inWbStockPlan = inWbStockPlan;
const isUrgentWbStockSync = () => urgent.getStore() !== undefined;
exports.isUrgentWbStockSync = isUrgentWbStockSync;
// FIX: missing WB observations are incomplete work, even when known targets succeeded.
// Keep identities only: the next attempt must calculate new quantities from WMS.
function deferUnconfirmedWbStock(targets) {
    const context = urgent.getStore();
    if (!context || !(0, exports.urgentWbStockSyncEnabled)())
        return;
    for (const target of targets) {
        if (target.skuId)
            context.unconfirmed.add(target.skuId);
        else
            context.retryAll = true;
    }
}
class StaleWbStockPlan extends Error {
    constructor() { super('Остатки или заказы изменились. Старый расчёт не отправлен; выполняется повторная синхронизация.'); }
}
exports.StaleWbStockPlan = StaleWbStockPlan;
async function stockRevision(db) {
    const rows = await db.$queryRaw `SELECT txid_current_snapshot()::text AS snapshot`;
    return rows[0].snapshot;
}
// FIX: each calculation owns its revision; parallel requests never share mutable plan state.
function withWbStockPlan(clientId, action) {
    if (!(0, exports.urgentWbStockSyncEnabled)() || plans.getStore()?.clientId === clientId)
        return action();
    return plans.run({ clientId }, action);
}
async function captureWbStockPlan(db, clientId) {
    if (!(0, exports.urgentWbStockSyncEnabled)())
        return;
    const scope = plans.getStore();
    if (!scope || scope.clientId !== clientId)
        return; // Read-only screens do not publish.
    if (scope.snapshot === undefined) {
        scope.snapshot = await stockRevision(db);
        scope.capturedAt = Date.now();
    }
}
// FIX: capture complete relabel pools so unrelated SKU activity does not invalidate a send.
function registerWbStockPlan(quantities, meta) {
    const scope = plans.getStore();
    if (!scope)
        return;
    scope.pools ??= new Map();
    for (const [skuId, value] of quantities) {
        const pool = expandWbStockScope([skuId], meta);
        const existing = scope.pools.get(value.chrtId) ?? new Set();
        pool.forEach(id => existing.add(id));
        scope.pools.set(value.chrtId, existing);
    }
}
async function assertFreshWbStockPlan(db, clientId, chrtIds) {
    if (!(0, exports.urgentWbStockSyncEnabled)())
        return;
    const scope = plans.getStore();
    if (!scope || scope.clientId !== clientId || !scope.snapshot || Date.now() - scope.capturedAt > 1_200_000)
        throw new StaleWbStockPlan();
    await urgent.getStore()?.guard?.();
    const ids = new Set();
    // Unknown mappings fail closed by validating all events, never by ignoring a size.
    const scoped = chrtIds?.length && chrtIds.every(id => scope.pools?.has(id));
    if (scoped)
        chrtIds.forEach(id => scope.pools.get(id).forEach(sku => ids.add(sku)));
    const rows = await db.$queryRaw `SELECT EXISTS (
    SELECT 1 FROM "WbStockSyncEvent" WHERE "clientId" = ${clientId}
      AND txid >= txid_snapshot_xmin(${scope.snapshot}::txid_snapshot)
      AND NOT txid_visible_in_snapshot(txid, ${scope.snapshot}::txid_snapshot)
      AND (${!scoped} OR "allSkus" OR "skuIds" && ${[...ids]}::text[])
  ) AS stale`;
    if (rows[0]?.stale !== false)
        throw new StaleWbStockPlan();
}
const wbStockRetryDelay = (attempt) => Math.min(300_000, 5_000 * 2 ** Math.min(6, Math.max(0, attempt - 1)));
exports.wbStockRetryDelay = wbStockRetryDelay;
// FIX: a committed database event survives restart; one lease coalesces a client's changes.
class WbStockSyncWorker {
    db;
    sync;
    warn;
    timer;
    running;
    stopped = false;
    constructor(db, sync, warn) {
        this.db = db;
        this.sync = sync;
        this.warn = warn;
    }
    start() { if ((0, exports.urgentWbStockSyncEnabled)())
        this.schedule(); }
    async stop() { this.stopped = true; clearTimeout(this.timer); await this.running; }
    schedule() {
        if (this.stopped)
            return;
        this.timer = setTimeout(() => {
            this.running = this.tick().catch(() => this.warn('Очередь остатков WB: проверка не завершена; будет повторена.')).finally(() => { this.running = undefined; this.schedule(); });
        }, 2000);
        this.timer.unref?.();
    }
    async tick() {
        if (!(0, exports.urgentWbStockSyncEnabled)())
            return;
        const token = (0, node_crypto_1.randomUUID)();
        // Queue rows are owned only by workers; business transactions merely append events.
        await this.db.$executeRaw `INSERT INTO "WbStockSyncQueue" ("clientId")
      SELECT DISTINCT "clientId" FROM "WbStockSyncEvent" WHERE "processedAt" IS NULL
      ON CONFLICT ("clientId") DO NOTHING`;
        const rows = await this.db.$queryRaw `UPDATE "WbStockSyncQueue" q SET "leaseToken" = ${token}, "leaseUntil" = now() + interval '60 seconds'
      WHERE q."clientId" = (SELECT "clientId" FROM "WbStockSyncQueue" c WHERE "nextAttemptAt" <= now()
        AND ("leaseUntil" IS NULL OR "leaseUntil" < now())
        AND EXISTS (SELECT 1 FROM "WbStockSyncEvent" e WHERE e."clientId" = c."clientId" AND e."processedAt" IS NULL)
        ORDER BY "nextAttemptAt", "requestedAt" LIMIT 1 FOR UPDATE SKIP LOCKED)
      RETURNING "clientId", attempts`;
        const job = rows[0];
        if (!job)
            return;
        const events = await this.db.$queryRaw `SELECT id, "skuIds", "allSkus" FROM "WbStockSyncEvent"
      WHERE "clientId" = ${job.clientId} AND "processedAt" IS NULL ORDER BY id LIMIT 5000`;
        const eventIds = events.map(e => e.id);
        const skuIds = events.some(e => e.allSkus) ? null : [...new Set(events.flatMap(e => e.skuIds))];
        let leaseLost = false;
        const renew = async () => {
            const count = await this.db.$executeRaw `UPDATE "WbStockSyncQueue" SET "leaseUntil" = now() + interval '60 seconds'
        WHERE "clientId" = ${job.clientId} AND "leaseToken" = ${token} AND "leaseUntil" > now()`;
            if (count !== 1)
                leaseLost = true;
            if (leaseLost)
                throw new StaleWbStockPlan();
        };
        const heartbeat = setInterval(() => { void renew().catch(() => { leaseLost = true; }); }, 15_000);
        heartbeat.unref?.();
        const record = (phase, details = {}) => this.db.auditLog.create({ data: {
                action: 'WB_STOCK_URGENT_SYNC', entity: 'Client', entityId: job.clientId,
                payload: { phase, eventCount: events.length, lastEventId: events.at(-1)?.id.toString(), ...details },
            } });
        try {
            await record('STARTED');
            const context = { skuIds, guard: renew, unconfirmed: new Set(), retryAll: false };
            await urgent.run(context, () => this.sync(job.clientId));
            await renew();
            const retrySkuIds = [...context.unconfirmed].sort();
            const partial = context.retryAll || retrySkuIds.length > 0;
            const message = partial ? 'Часть остатков WB не подтверждена. Неподтверждённые товары сохранены для повторного расчёта и проверки.' : null;
            // FIX: acknowledge only events observed before this calculation. A late commit stays pending,
            // even if its sequence ID was allocated before newer already-processed transactions.
            await this.db.$transaction(async (tx) => {
                const owned = await tx.$executeRaw `UPDATE "WbStockSyncQueue" SET attempts = ${partial ? job.attempts + 1 : 0}, "lastError" = ${message},
          "nextAttemptAt" = now() + (${partial ? (0, exports.wbStockRetryDelay)(job.attempts + 1) : 0} * interval '1 millisecond'), "leaseToken" = NULL, "leaseUntil" = NULL
          WHERE "clientId" = ${job.clientId} AND "leaseToken" = ${token} AND "leaseUntil" > now()`;
                if (owned !== 1)
                    throw new StaleWbStockPlan();
                // FIX: replace observed work with its unconfirmed subset atomically. Concurrent
                // business events are untouched; a crash cannot lose the pending subset.
                if (partial) {
                    await tx.$executeRaw `INSERT INTO "WbStockSyncEvent" ("clientId", "skuIds", "allSkus")
            VALUES (${job.clientId}, ${retrySkuIds}::text[], ${context.retryAll})`;
                    await tx.fbsStockAllocationPolicy.updateMany({ where: { clientId: job.clientId, enabled: true }, data: { lastError: message } });
                }
                await tx.$executeRaw `UPDATE "WbStockSyncEvent" SET "processedAt" = now() WHERE id = ANY(${eventIds}::bigint[])`;
                await tx.auditLog.create({ data: { action: 'WB_STOCK_URGENT_SYNC', entity: 'Client', entityId: job.clientId,
                        payload: { phase: partial ? 'PARTIAL_RETRY_REQUIRED' : 'PROCESSED', eventCount: events.length,
                            ...(partial ? { retrySkuIds, retryAll: context.retryAll, message } : {}) } } });
            });
            if (message)
                this.warn(message);
        }
        catch (error) {
            const stale = error instanceof StaleWbStockPlan;
            const message = stale ? error.message : 'Синхронизация WB не подтверждена. Следующая попытка выполнит новый расчёт и проверку.';
            const owned = await this.db.$executeRaw `UPDATE "WbStockSyncQueue" SET attempts = attempts + 1, "lastError" = ${message},
        "nextAttemptAt" = now() + (${stale ? 2000 : (0, exports.wbStockRetryDelay)(job.attempts + 1)} * interval '1 millisecond'),
        "leaseToken" = NULL, "leaseUntil" = NULL WHERE "clientId" = ${job.clientId} AND "leaseToken" = ${token}`;
            if (owned !== 1)
                return; // A replacement worker owns the result; do not overwrite its warning.
            // FIX: the existing allocation screen exposes this warning until a verified run clears it.
            await this.db.fbsStockAllocationPolicy.updateMany({ where: { clientId: job.clientId, enabled: true }, data: { lastError: message } });
            await record(stale ? 'RECALCULATE' : 'RETRY_REQUIRED', { message });
            this.warn(message);
        }
        finally {
            clearInterval(heartbeat);
        }
    }
}
exports.WbStockSyncWorker = WbStockSyncWorker;
// FIX: recalculate the complete shared pool, but send only changed SKUs and their relabel peers.
function urgentWbStockScope(meta) {
    const changed = (0, exports.urgentWbSkuIds)();
    if (!changed)
        return null;
    return expandWbStockScope(changed, meta);
}
function expandWbStockScope(changed, meta) {
    const result = new Set(changed);
    let expanded = true;
    while (expanded) {
        expanded = false;
        for (const [target, info] of meta) {
            const pool = [target, ...(info.sources ?? []).map(s => s.skuId)];
            if (!pool.some(id => result.has(id)))
                continue;
            for (const id of pool)
                if (!result.has(id)) {
                    result.add(id);
                    expanded = true;
                }
        }
    }
    return result;
}
