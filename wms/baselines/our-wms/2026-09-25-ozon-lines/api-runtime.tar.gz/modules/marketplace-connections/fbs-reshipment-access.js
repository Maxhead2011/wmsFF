"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.canUseFbsReshipment = canUseFbsReshipment;
exports.requireFbsReshipmentClientAccess = requireFbsReshipmentClientAccess;
const common_1 = require("@nestjs/common");
// FIX: client self-service never inherits a global/admin scope from an accidental grant.
function canUseFbsReshipment(user) {
    if (user.isDemo)
        return false;
    if (user.roleCodes.includes('CLIENT')) {
        return user.permissionCodes.includes('client-requests:write') &&
            user.clientIds.some(id => user.writableClientIds.includes(id) && !user.hiddenClientIds?.includes(id));
    }
    return user.roleCodes.some(role => role === 'ADMIN' || role === 'OWNER');
}
function requireFbsReshipmentClientAccess(user, clientId) {
    if (!canUseFbsReshipment(user) || (user.roleCodes.includes('CLIENT') &&
        (!user.clientIds.includes(clientId) || !user.writableClientIds.includes(clientId) || user.hiddenClientIds?.includes(clientId)))) {
        throw new common_1.ForbiddenException('Нет права повторной отгрузки для выбранного клиента.');
    }
}
