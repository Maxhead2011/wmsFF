"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.evaluateFbsBoxAvailability = evaluateFbsBoxAvailability;
exports.describeFbsRejectedBox = describeFbsRejectedBox;
exports.fbsRouteFingerprint = fbsRouteFingerprint;
exports.diffFbsRouteBoxes = diffFbsRouteBoxes;
/**
 * // FIX: One calculation is used by route preview, pallet validation and the
 * physical box claim. A route may count only untouched AUTO reservations as
 * releasable; started/scanned tasks always remain protected.
 */
function evaluateFbsBoxAvailability(input) {
    const requiredQuantity = Math.max(1, input.requiredQuantity);
    const boxReservations = input.reservations.filter((reservation) => reservation.boxId === input.boxId);
    const ownReservationQuantity = boxReservations
        .filter((reservation) => reservation.taskId === input.candidateTaskId)
        .reduce((sum, reservation) => sum + Math.max(1, reservation.itemCount), 0);
    const reservedQuantity = boxReservations
        .reduce((sum, reservation) => sum + Math.max(1, reservation.itemCount), 0);
    const releasableBackgroundQuantity = boxReservations
        .filter((reservation) => reservation.taskId !== input.candidateTaskId &&
        reservation.releasableBackground)
        .reduce((sum, reservation) => sum + Math.max(1, reservation.itemCount), 0);
    const freeQuantity = Math.max(0, input.availableQuantity - reservedQuantity);
    // FIX: logical reservations can only release claims against live AVAILABLE
    // stock; they must never recreate a unit already moved to PACKING.
    const effectiveOwnReservationQuantity = input.candidateAssignedBoxId === input.boxId ? ownReservationQuantity : 0;
    const protectedOtherQuantity = Math.max(0, reservedQuantity - effectiveOwnReservationQuantity - releasableBackgroundQuantity);
    const claimableQuantity = Math.max(0, input.availableQuantity - protectedOtherQuantity);
    return {
        availableQuantity: input.availableQuantity,
        reservedQuantity,
        ownReservationQuantity,
        releasableBackgroundQuantity,
        freeQuantity,
        claimableQuantity,
        accepted: claimableQuantity >= requiredQuantity,
    };
}
/**
 * // FIX: Do not claim that another request took the item when the employee
 * scanned a different box that has no stock for the current SKU.
 */
function describeFbsRejectedBox(input) {
    const assignedBoxCode = input.assignedBoxCode?.trim() || null;
    const scannedDifferentBox = Boolean(assignedBoxCode &&
        assignedBoxCode.toUpperCase() !== input.scannedBoxCode.toUpperCase());
    if (scannedDifferentBox && input.availableQuantity <= 0) {
        return {
            code: 'FBS_WRONG_BOX',
            message: `В коробе ${input.scannedBoxCode} нет товара «${input.productLabel}» для текущего задания. Маршрут показывает короб ${assignedBoxCode}; отсканируйте его.`,
        };
    }
    return {
        code: 'FBS_ROUTE_STALE',
        message: `Свободный товар из короба ${input.scannedBoxCode} уже закреплён другой заявкой. Маршрут обновлён; отсканируйте следующий показанный короб.`,
    };
}
/** // ADDED: Stable live-data version; unchanged input always has one version. */
function fbsRouteFingerprint(rows) {
    const value = [...rows]
        .sort((left, right) => left.taskId.localeCompare(right.taskId))
        .map((row) => [
        row.taskId,
        row.status,
        row.skuId,
        Math.max(0, row.quantity),
        row.boxId ?? '',
        row.boxCode ?? '',
        row.palletCode ?? '',
    ].join('|'))
        .join('\n');
    let hash = 2166136261;
    for (let index = 0; index < value.length; index += 1) {
        hash ^= value.charCodeAt(index);
        hash = Math.imul(hash, 16777619) >>> 0;
    }
    return `FBSR-${hash.toString(36).toUpperCase().padStart(7, '0')}`;
}
function diffFbsRouteBoxes(before, after) {
    const beforeSet = new Set(before);
    const afterSet = new Set(after);
    return {
        addedBoxes: [...afterSet].filter((box) => !beforeSet.has(box)).sort(),
        removedBoxes: [...beforeSet].filter((box) => !afterSet.has(box)).sort(),
    };
}
