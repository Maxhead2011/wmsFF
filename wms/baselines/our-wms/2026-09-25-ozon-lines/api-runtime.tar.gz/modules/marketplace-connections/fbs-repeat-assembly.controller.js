"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsRepeatAssemblyController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const fbs_repeat_assembly_dto_1 = require("./dto/fbs-repeat-assembly.dto");
const fbs_repeat_assembly_service_1 = require("./fbs-repeat-assembly.service");
let FbsRepeatAssemblyController = class FbsRepeatAssemblyController {
    repeats;
    constructor(repeats) {
        this.repeats = repeats;
    }
    capabilities(user) { return this.repeats.capabilities(user); }
    preview(dto, user) {
        return this.repeats.preview(dto, user);
    }
    create(dto, user) {
        return this.repeats.create(dto, user);
    }
};
exports.FbsRepeatAssemblyController = FbsRepeatAssemblyController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FbsRepeatAssemblyController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Post)('preview'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_repeat_assembly_dto_1.PreviewFbsRepeatAssemblyDto, Object]),
    __metadata("design:returntype", void 0)
], FbsRepeatAssemblyController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_repeat_assembly_dto_1.CreateFbsRepeatAssemblyDto, Object]),
    __metadata("design:returntype", void 0)
], FbsRepeatAssemblyController.prototype, "create", null);
exports.FbsRepeatAssemblyController = FbsRepeatAssemblyController = __decorate([
    (0, common_1.Controller)(['marketplace-connections/fbs/repeat-assembly', 'marketplace-connection/fbs/repeat-assembly']),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __metadata("design:paramtypes", [fbs_repeat_assembly_service_1.FbsRepeatAssemblyService])
], FbsRepeatAssemblyController);
