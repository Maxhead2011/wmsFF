"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsStockAllocationExternalController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("../auth/decorators/public.decorator");
const fbs_stock_allocation_dto_1 = require("./dto/fbs-stock-allocation.dto");
const fbs_stock_allocation_service_1 = require("./fbs-stock-allocation.service");
const marketplace_connections_service_1 = require("./marketplace-connections.service");
let FbsStockAllocationExternalController = class FbsStockAllocationExternalController {
    allocation;
    connections;
    constructor(allocation, connections) {
        this.allocation = allocation;
        this.connections = connections;
    }
    // ADDED: A service-to-service API key is bound to one client and cannot select another clientId.
    async getAllocation(apiKey, connectionId) {
        const identity = await this.allocation.authenticateApiKey(apiKey);
        return this.connections.listExternalFbsStockAllocation(identity.clientId, connectionId);
    }
    async updateAllocation(apiKey, dto) {
        const identity = await this.allocation.authenticateApiKey(apiKey);
        const saved = await this.allocation.saveExternal(identity.clientId, dto, identity.id);
        if (!saved.duplicate) {
            await this.connections.syncExternalFbsStockAllocation(identity.clientId, dto.connectionId);
        }
        return saved;
    }
    async updateStocks(apiKey, dto) {
        const identity = await this.allocation.authenticateApiKey(apiKey);
        const saved = await this.allocation.saveExternalStockOverrides(identity.clientId, identity.id, dto);
        if (!saved.duplicate) {
            await this.connections.syncExternalFbsStockAllocation(identity.clientId, dto.connectionId);
        }
        return saved;
    }
};
exports.FbsStockAllocationExternalController = FbsStockAllocationExternalController;
__decorate([
    (0, common_1.Get)('stock-allocation'),
    __param(0, (0, common_1.Headers)('x-wms-api-key')),
    __param(1, (0, common_1.Query)('connectionId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], FbsStockAllocationExternalController.prototype, "getAllocation", null);
__decorate([
    (0, common_1.Put)('stock-allocation'),
    __param(0, (0, common_1.Headers)('x-wms-api-key')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, fbs_stock_allocation_dto_1.ExternalFbsStockAllocationDto]),
    __metadata("design:returntype", Promise)
], FbsStockAllocationExternalController.prototype, "updateAllocation", null);
__decorate([
    (0, common_1.Put)('stocks'),
    __param(0, (0, common_1.Headers)('x-wms-api-key')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, fbs_stock_allocation_dto_1.ExternalFbsStocksDto]),
    __metadata("design:returntype", Promise)
], FbsStockAllocationExternalController.prototype, "updateStocks", null);
exports.FbsStockAllocationExternalController = FbsStockAllocationExternalController = __decorate([
    (0, swagger_1.ApiTags)('external-fbs-stocks'),
    (0, swagger_1.ApiHeader)({ name: 'X-WMS-API-Key', required: true }),
    (0, public_decorator_1.Public)(),
    (0, common_1.Controller)('external/v1/fbs'),
    __metadata("design:paramtypes", [fbs_stock_allocation_service_1.FbsStockAllocationService,
        marketplace_connections_service_1.MarketplaceConnectionsService])
], FbsStockAllocationExternalController);
