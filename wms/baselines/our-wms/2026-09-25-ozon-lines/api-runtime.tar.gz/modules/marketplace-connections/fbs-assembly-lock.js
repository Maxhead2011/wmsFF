"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withFbsAssemblyLock = withFbsAssemblyLock;
const common_1 = require("@nestjs/common");
// FIX: manual and scheduled actions share a cross-process PostgreSQL lock.
// No stock changes occur in this transaction; existing services keep their own atomic writes.
async function withFbsAssemblyLock(prisma, clientId, action, orderKeys) {
    if (process.env.WMS_AUTO_ASSEMBLY_ENABLED !== 'true')
        return action();
    return prisma.$transaction(async (tx) => {
        const keys = orderKeys?.length ? [...new Set(orderKeys)].sort().map(key => `fbs-assembly:${clientId}:${key}`) : [`fbs-assembly:${clientId}`];
        for (const key of keys) {
            const rows = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${key})) AS locked`;
            if (!rows[0]?.locked)
                throw new common_1.ConflictException('Для выбранных заказов уже выполняется создание сборки. Остальные заказы доступны для ручной работы.');
        }
        return action();
    }, { timeout: 600000, maxWait: 5000 });
}
