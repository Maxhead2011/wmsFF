"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsConnectionIsolationEnabled = fbsConnectionIsolationEnabled;
exports.collectFbsConnectionOrders = collectFbsConnectionOrders;
function fbsConnectionIsolationEnabled(readOnly, flag = process.env.WMS_FBS_CONNECTION_ISOLATION) {
    return readOnly && flag === 'true';
}
async function collectFbsConnectionOrders(connections, load, allowPartial) {
    const tasks = connections.map(connection => Promise.resolve().then(() => load(connection)));
    // FIX: operational validation and sold deployments must never consume partial results.
    if (!allowPartial)
        return { groups: await Promise.all(tasks), errors: [] };
    const results = await Promise.allSettled(tasks);
    const errors = [];
    const groups = results.map((result, index) => {
        if (result.status === 'fulfilled')
            return result.value;
        const connection = connections[index];
        // FIX: expose the affected cabinet, never credentials or a raw upstream response.
        errors.push({ connectionId: connection.id, marketplace: connection.marketplace,
            accountName: connection.accountName,
            message: `Не удалось загрузить подключение ${connection.marketplace} «${connection.accountName || connection.id}». Показаны заказы доступных подключений.` });
        return [];
    });
    // FIX: preserve the last successful display snapshot when all upstream reads fail.
    if (connections.length && errors.length === connections.length)
        throw new Error('Не удалось загрузить подключение: все подключения недоступны.');
    return { groups, errors };
}
