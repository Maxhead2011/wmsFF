"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsDisplayCache = void 0;
class FbsDisplayCache {
    entries = new Map();
    queue = [];
    running = 0;
    stopped = false;
    get(key) { return this.entries.get(key); }
    refresh(key, load, force = false) {
        let entry = this.entries.get(key);
        if (this.stopped || entry?.pending || (entry && entry.retryAt > Date.now() && (!force || entry.error)))
            return;
        if (entry && Date.now() - entry.startedAt < 5_000)
            return;
        if (this.entries.size >= 128 && !entry) {
            const oldest = [...this.entries].find(([, value]) => !value.pending);
            if (!oldest)
                return;
            this.entries.delete(oldest[0]);
        }
        entry ??= { pending: false, retryAt: 0, startedAt: 0, error: null };
        entry.pending = true;
        entry.startedAt = Date.now();
        this.entries.set(key, entry);
        this.queue.push({ key, load });
        // Yield HTTP first; two workers bound load. Repeated clicks share one refresh.
        setImmediate(() => this.drain());
    }
    stop() { this.stopped = true; this.queue.length = 0; }
    drain() {
        while (!this.stopped && this.running < 2 && this.queue.length) {
            const job = this.queue.shift();
            const entry = this.entries.get(job.key);
            this.running++;
            void Promise.resolve().then(job.load).then(value => {
                entry.value = value;
                entry.error = null;
                entry.retryAt = Date.now() + 60_000;
            }, error => {
                // Never expose external response bodies, tokens or internal SQL to the browser.
                const text = error instanceof Error ? error.message : '';
                entry.error = /401|403|token.*withdrawn/i.test(text)
                    ? 'Маркетплейс отклонил доступ. Проверьте API-ключ кабинета.'
                    : 'Не удалось обновить данные маркетплейса. Показаны сохранённые данные; повторим попытку.';
                entry.retryAt = Date.now() + 30_000;
            }).finally(() => {
                entry.pending = false;
                this.running--;
                this.drain();
            });
        }
    }
}
exports.FbsDisplayCache = FbsDisplayCache;
