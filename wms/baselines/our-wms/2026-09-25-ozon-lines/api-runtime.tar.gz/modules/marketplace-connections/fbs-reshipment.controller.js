"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsReshipmentController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const fbs_reshipment_dto_1 = require("./dto/fbs-reshipment.dto");
const fbs_reshipment_service_1 = require("./fbs-reshipment.service");
// FIX: isolated endpoints; capabilities are false until explicitly enabled.
let FbsReshipmentController = class FbsReshipmentController {
    reshipments;
    constructor(reshipments) {
        this.reshipments = reshipments;
    }
    capabilities(user) { return this.reshipments.capabilities(user); }
    check(dto, user) { return this.reshipments.check(dto, user); }
    preview(dto, user) { return this.reshipments.preview(dto, user); }
    create(dto, user) { return this.reshipments.create(dto, user); }
    // FIX: scoped, one-time browser transfer authorization.
    startPortal(dto, user) { return this.reshipments.startPortal(dto, user); }
    resume(dto, user) { return this.reshipments.resume(dto, user); }
};
exports.FbsReshipmentController = FbsReshipmentController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FbsReshipmentController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Post)('check'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_reshipment_dto_1.CheckFbsReshipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FbsReshipmentController.prototype, "check", null);
__decorate([
    (0, common_1.Post)('preview'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_reshipment_dto_1.PreviewFbsReshipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FbsReshipmentController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)('create'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_reshipment_dto_1.CreateFbsReshipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FbsReshipmentController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('portal/start'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_reshipment_dto_1.ResumeFbsReshipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FbsReshipmentController.prototype, "startPortal", null);
__decorate([
    (0, common_1.Post)('resume'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_reshipment_dto_1.ResumeFbsReshipmentDto, Object]),
    __metadata("design:returntype", void 0)
], FbsReshipmentController.prototype, "resume", null);
exports.FbsReshipmentController = FbsReshipmentController = __decorate([
    (0, common_1.Controller)(['marketplace-connections/fbs/reshipment', 'marketplace-connection/fbs/reshipment']),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'client-requests:write'),
    __metadata("design:paramtypes", [fbs_reshipment_service_1.FbsReshipmentService])
], FbsReshipmentController);
