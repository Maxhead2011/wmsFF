"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsSequentialEnabled = void 0;
exports.fbsLocationRank = fbsLocationRank;
exports.fbsContinuationBox = fbsContinuationBox;
const fbsSequentialEnabled = () => process.env.WMS_FBS_SEQUENTIAL_PICK_ENABLED === 'true';
exports.fbsSequentialEnabled = fbsSequentialEnabled;
// FIX: an order on the physically selected box precedes other boxes on the pallet.
function fbsLocationRank(codes, box, pallet) {
    return box && codes.includes(box) ? 2 : codes.some(code => pallet.has(code)) ? 1 : 0;
}
// FIX: eligible boxes have already been reduced by reservations; a hint cannot create stock.
function fbsContinuationBox(eligible, previous, required) {
    return (0, exports.fbsSequentialEnabled)() ? eligible.find(b => b.code === previous && b.quantity >= required) : undefined;
}
