"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WbStockObservations = void 0;
exports.wbStockCheckDto = wbStockCheckDto;
const node_async_hooks_1 = require("node:async_hooks");
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const context = new node_async_hooks_1.AsyncLocalStorage();
// FIX: Prisma bigint remains internal; the WB HTTP and web contracts use exact safe integers.
function wbStockCheckDto(row) {
    const chrtId = Number(row.chrtId);
    if (!Number.isSafeInteger(chrtId) || chrtId <= 0)
        throw new Error('Некорректный идентификатор размера WB.');
    return { ...row, chrtId };
}
class WbStockObservations {
    db;
    constructor(db) {
        this.db = db;
    }
    // FIX: cross-process account lock; nested PUTs reuse it, timeout forbids further requests.
    async locked(connectionId, rebalance, action) {
        const current = context.getStore();
        if (current?.connectionId === connectionId) {
            await current.guard();
            return action();
        }
        return this.db.$transaction(async (tx) => {
            const lock = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${'wb.stock.publish.' + connectionId})) AS acquired`;
            if (!lock[0]?.acquired)
                throw new common_1.ConflictException('По этому кабинету WB уже выполняется отправка остатков. Дождитесь её завершения.');
            const guard = async () => { await tx.$queryRaw `SELECT 1`; };
            return context.run({ connectionId, rebalance, guard }, action);
        }, { timeout: 600_000, maxWait: 5000 });
    }
    inRebalance(connectionId) { return context.getStore()?.connectionId === connectionId && context.getStore()?.rebalance === true; }
    async guard() { await context.getStore()?.guard(); }
    recorder(clientId, connectionId, runId = (0, node_crypto_1.randomUUID)()) {
        const ids = new Map();
        return async (row) => {
            const key = `${row.warehouseId}:${row.chrtId}`;
            const id = ids.get(key);
            const data = { phase: row.phase, status: row.status, calculatedAmount: row.amount,
                ...(row.sentAmount === undefined ? {} : { sentAmount: row.sentAmount }),
                ...(row.status === 'SENDING' ? { sentAt: new Date() } : {}),
                ...(row.observedAmount === undefined ? {} : { observedAmount: row.observedAmount, checkedAt: new Date() }),
                ...(row.error ? { error: row.error } : {}) };
            if (id)
                await this.db.wbStockPublicationCheck.update({ where: { id }, data });
            else {
                const chrtId = BigInt(wbStockCheckDto(row).chrtId);
                const base = { ...data, clientId, connectionId, runId, warehouseId: row.warehouseId, skuId: row.skuId, chrtId };
                const saved = await this.db.wbStockPublicationCheck.upsert({ where: { connectionId_warehouseId_chrtId: { connectionId, warehouseId: row.warehouseId, chrtId } }, create: base, update: { ...base, sentAmount: null, observedAmount: null, sentAt: null, checkedAt: null, error: null, ...data } });
                ids.set(key, saved.id);
            }
        };
    }
    async observe(clientId, connectionId, warehouseId, amounts, skus, at = new Date()) {
        const msk = new Date(at.getTime() + 3 * 3600000);
        const day = msk.toISOString().slice(0, 10);
        const bit = 1 << msk.getUTCHours();
        const rows = [...amounts].filter(([chrtId]) => skus.has(chrtId));
        // One row per SKU/warehouse/day; repeated polling within an hour does not inflate exposure.
        for (let i = 0; i < rows.length; i += 500) {
            const batch = rows.slice(i, i + 500);
            if (!batch.length)
                continue;
            await this.db.$executeRaw(client_1.Prisma.sql `INSERT INTO "WbStockAvailabilityDay" ("id", "clientId", "connectionId", "warehouseId", "skuId", "day", "observedMask", "positiveMask", "updatedAt") VALUES ${client_1.Prisma.join(batch.map(([chrtId, amount]) => client_1.Prisma.sql `(${(0, node_crypto_1.randomUUID)()}, ${clientId}, ${connectionId}, ${warehouseId}, ${skus.get(chrtId)}, ${day}, ${bit}, ${amount > 0 ? bit : 0}, ${at})`))}
        ON CONFLICT ("connectionId", "warehouseId", "skuId", "day") DO UPDATE SET
        "observedMask" = "WbStockAvailabilityDay"."observedMask" | EXCLUDED."observedMask",
        "positiveMask" = "WbStockAvailabilityDay"."positiveMask" | EXCLUDED."positiveMask", "updatedAt" = EXCLUDED."updatedAt"`);
        }
    }
}
exports.WbStockObservations = WbStockObservations;
