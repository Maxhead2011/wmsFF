"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonActiveLine = exports.ozonPickTotal = exports.ozonPickCount = exports.ozonPickLinesEnabled = void 0;
exports.ozonPostingProducts = ozonPostingProducts;
exports.requireOzonLineComposition = requireOzonLineComposition;
exports.recordOzonLineScan = recordOzonLineScan;
exports.readOzonPickState = readOzonPickState;
exports.writeOzonPickState = writeOzonPickState;
exports.resolveOzonLineSku = resolveOzonLineSku;
const common_1 = require("@nestjs/common");
const ozonPickLinesEnabled = () => process.env.WMS_OZON_MULTILINE_PICKING === 'true';
exports.ozonPickLinesEnabled = ozonPickLinesEnabled;
const ozonPickCount = (state) => state.lines.reduce((n, line) => n + line.picks.length, 0);
exports.ozonPickCount = ozonPickCount;
const ozonPickTotal = (state) => state.lines.reduce((n, line) => n + line.quantity, 0);
exports.ozonPickTotal = ozonPickTotal;
const ozonActiveLine = (state) => state.lines.find(line => line.picks.length < line.quantity);
exports.ozonActiveLine = ozonActiveLine;
// FIX: quantities and identities must be exact; an equal grand total is not proof of composition.
function ozonPostingProducts(posting) {
    if (!Array.isArray(posting?.products) || !posting.products.length)
        throw new common_1.BadRequestException('Ozon не вернул состав заказа.');
    const products = posting.products.map((product) => {
        const productId = Number(product.sku), quantity = Number(product.quantity);
        if (!Number.isSafeInteger(productId) || productId <= 0 || !Number.isSafeInteger(quantity) || quantity <= 0 || !product.offer_id) {
            throw new common_1.BadRequestException('Некорректная товарная строка Ozon. Обновите заказ.');
        }
        return { productId, quantity, offerId: String(product.offer_id), barcodes: Array.isArray(product.barcodes) ? product.barcodes.map(String) : [] };
    });
    if (new Set(products.map(p => p.productId)).size !== products.length)
        throw new common_1.BadRequestException('Ozon вернул повторяющиеся строки товара. Нужна проверка состава.');
    return products;
}
function requireOzonLineComposition(state, posting) {
    const actual = ozonPostingProducts(posting);
    if (actual.length !== state.lines.length || state.lines.some(line => {
        const remote = actual.find(p => p.productId === line.productId && p.offerId === line.offerId);
        return !remote || remote.quantity !== line.quantity || line.picks.length !== line.quantity;
    }))
        throw new common_1.ConflictException('Состав Ozon изменился или не все товары отсканированы. Отправка остановлена; обновите заказ.');
    const marks = posting.requirements?.products_requiring_mandatory_mark;
    if (Array.isArray(marks) && marks.length)
        throw new common_1.BadRequestException('Ozon требует маркировку: для многотоварного заказа нужна отдельная проверка КИЗ.');
}
function recordOzonLineScan(state, barcode, expectedCount, actorId, now = new Date()) {
    const count = (0, exports.ozonPickCount)(state);
    if (!Number.isSafeInteger(expectedCount) || Number(expectedCount) < 0 || Number(expectedCount) > count) {
        throw new common_1.ConflictException('Обновите задание: отсутствует актуальный счётчик сканирования.');
    }
    // FIX: replay of the previous request cannot consume a unit from the next product line.
    if (Number(expectedCount) < count) {
        const accepted = state.lines.flatMap(line => line.picks)[Number(expectedCount)];
        if (accepted?.barcode !== barcode)
            throw new common_1.ConflictException('Этот номер сканирования уже занят другим товаром. Обновите задание.');
        return state;
    }
    if (state.submission !== 'PICKING')
        throw new common_1.ConflictException('Заказ уже передаётся в Ozon. Новые сканы не принимаются.');
    const index = state.lines.findIndex(line => line.picks.length < line.quantity);
    if (index < 0)
        throw new common_1.BadRequestException('Все товары уже отсканированы. Подтвердите отбор.');
    const line = state.lines[index];
    if (!line.barcodes.includes(barcode))
        throw new common_1.BadRequestException(`Неверный товар. Нужен артикул ${line.article}, ШК ${line.barcodes.join(', ')}.`);
    if (!state.source)
        throw new common_1.BadRequestException('Сначала отсканируйте короб или выберите «Без короба».');
    const result = structuredClone(state);
    result.lines[index].picks.push({ barcode, ...state.source, actorId, at: now.toISOString() });
    if (result.lines[index].picks.length === line.quantity)
        result.source = null;
    return result;
}
async function readOzonPickState(db, assemblyId) {
    const rows = await db.$queryRaw `SELECT "data" FROM "OzonFbsPickState" WHERE "assemblyId"=${assemblyId}`;
    return rows[0]?.data ?? null;
}
async function writeOzonPickState(db, assemblyId, state) {
    const data = JSON.stringify(state);
    await db.$executeRaw `INSERT INTO "OzonFbsPickState" ("assemblyId", "data") VALUES (${assemblyId}, ${data}::jsonb)
    ON CONFLICT ("assemblyId") DO UPDATE SET "data"=EXCLUDED."data", "updatedAt"=CURRENT_TIMESTAMP`;
}
// Existing imported SKUs may use a compound marketplaceProductId. Match exact tokens, never substrings.
function resolveOzonLineSku(product, skus) {
    const candidates = skus.filter(sku => {
        const ids = String(sku.marketplaceProductId ?? '').split(':');
        return ids.includes(product.offerId) || ids.includes(String(product.productId)) ||
            sku.marketplaceOfferId === product.offerId ||
            (sku.barcodes ?? []).some((b) => product.barcodes.includes(b.value));
    });
    if (candidates.length !== 1)
        throw new common_1.BadRequestException(`Не найдено однозначное соответствие артикула Ozon ${product.offerId}. Проверьте карточку в WMS.`);
    const sku = candidates[0];
    if ((sku.needsChestnyZnak && !sku.isUnmarked) || sku.needsRelabel)
        throw new common_1.BadRequestException('Многотоварный заказ с КИЗ или переклейкой требует отдельной проверки.');
    if (!sku.barcodes?.length)
        throw new common_1.BadRequestException(`У артикула ${product.offerId} не задан ШК товара.`);
    return sku;
}
