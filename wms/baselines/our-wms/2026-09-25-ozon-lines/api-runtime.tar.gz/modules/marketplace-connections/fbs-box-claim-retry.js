"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsBoxClaimInput = fbsBoxClaimInput;
exports.sameFbsBoxClaimInput = sameFbsBoxClaimInput;
exports.runFbsBoxClaimTransaction = runFbsBoxClaimTransaction;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const FBS_BOX_CLAIM_ATTEMPTS = 3;
function fbsBoxClaimInput(task) {
    return {
        stockSkuId: task.relabelRequired && task.sourceSkuId
            ? task.sourceSkuId
            : task.skuId,
        requiredQuantity: Math.max(1, task.itemCount),
    };
}
function sameFbsBoxClaimInput(left, right) {
    return left.stockSkuId === right.stockSkuId &&
        left.requiredQuantity === right.requiredQuantity;
}
async function runFbsBoxClaimTransaction(operation) {
    for (let attempt = 1; attempt <= FBS_BOX_CLAIM_ATTEMPTS; attempt += 1) {
        try {
            return await operation();
        }
        catch (caught) {
            const isWriteConflict = caught instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                caught.code === 'P2034';
            if (!isWriteConflict)
                throw caught;
            if (attempt === FBS_BOX_CLAIM_ATTEMPTS) {
                // FIX: A background reservation refresh is not another picker. Keep
                // the response retryable and never accuse a different request.
                throw new common_1.ConflictException({
                    code: 'FBS_BOX_CLAIM_BUSY',
                    message: 'Маршрут одновременно обновился фоновым процессом. Повторите сканирование этого же короба.',
                });
            }
        }
    }
    throw new Error('FBS box claim retry loop exhausted unexpectedly.');
}
