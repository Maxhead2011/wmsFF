"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WildberriesRequestScheduler = void 0;
exports.runWithWildberriesRequestPriority = runWithWildberriesRequestPriority;
exports.currentWildberriesRequestPriority = currentWildberriesRequestPriority;
exports.wildberriesRateLimitKey = wildberriesRateLimitKey;
exports.wildberriesReadRequestKey = wildberriesReadRequestKey;
exports.wildberriesSellerIdFromToken = wildberriesSellerIdFromToken;
const node_async_hooks_1 = require("node:async_hooks");
const node_crypto_1 = require("node:crypto");
const priorityContext = new node_async_hooks_1.AsyncLocalStorage();
function runWithWildberriesRequestPriority(priority, action) {
    return priorityContext.run(priority, action);
}
function currentWildberriesRequestPriority() {
    return priorityContext.getStore() ?? 'interactive';
}
class WildberriesRequestScheduler {
    intervalMs;
    queues = new Map();
    constructor(intervalMs = 240) {
        this.intervalMs = intervalMs;
    }
    async waitForSlot(url, init) {
        const key = wildberriesRateLimitKey(url, init);
        if (!key)
            return;
        const signal = init.signal;
        if (signal?.aborted) {
            throw signal.reason ?? new DOMException('The operation was aborted.', 'AbortError');
        }
        const queue = this.queueFor(key);
        await new Promise((resolve, reject) => {
            const entry = {
                priority: currentWildberriesRequestPriority(),
                signal,
                resolve,
                reject,
            };
            if (signal) {
                const onAbort = () => {
                    this.removeEntry(queue, entry);
                    reject(signal.reason ?? new DOMException('The operation was aborted.', 'AbortError'));
                };
                signal.addEventListener('abort', onAbort, { once: true });
                entry.removeAbortListener = () => signal.removeEventListener('abort', onAbort);
            }
            queue[entry.priority].push(entry);
            this.pump(key, queue);
        });
    }
    defer(url, init, delayMs) {
        const key = wildberriesRateLimitKey(url, init);
        if (!key || !Number.isFinite(delayMs) || delayMs <= 0)
            return;
        const queue = this.queueFor(key);
        queue.nextRequestAt = Math.max(queue.nextRequestAt, Date.now() + Math.ceil(delayMs));
        this.pump(key, queue);
    }
    clear() {
        for (const queue of this.queues.values()) {
            for (const entry of [...queue.interactive, ...queue.background]) {
                entry.removeAbortListener?.();
                entry.reject(new Error('Wildberries request scheduler was cleared.'));
            }
        }
        this.queues.clear();
    }
    queueFor(key) {
        const existing = this.queues.get(key);
        if (existing)
            return existing;
        const created = {
            nextRequestAt: 0,
            running: false,
            interactive: [],
            background: [],
        };
        this.queues.set(key, created);
        return created;
    }
    pump(key, queue) {
        if (queue.running)
            return;
        queue.running = true;
        void this.runQueue(key, queue);
    }
    async runQueue(key, queue) {
        try {
            while (queue.interactive.length > 0 || queue.background.length > 0) {
                while (queue.nextRequestAt > Date.now()) {
                    await delay(queue.nextRequestAt - Date.now());
                }
                // Select only when the slot is actually available. An interactive scan
                // that arrived while we waited must overtake queued background work.
                const entry = queue.interactive.shift() ?? queue.background.shift();
                if (!entry)
                    break;
                if (entry.signal?.aborted) {
                    entry.removeAbortListener?.();
                    entry.reject(entry.signal.reason ?? new DOMException('The operation was aborted.', 'AbortError'));
                    continue;
                }
                queue.nextRequestAt = Date.now() + this.intervalMs;
                entry.removeAbortListener?.();
                entry.resolve();
            }
        }
        finally {
            queue.running = false;
            if (queue.interactive.length > 0 || queue.background.length > 0) {
                this.pump(key, queue);
            }
            else if (queue.nextRequestAt <= Date.now()) {
                this.queues.delete(key);
            }
        }
    }
    removeEntry(queue, entry) {
        const entries = queue[entry.priority];
        const index = entries.indexOf(entry);
        if (index >= 0)
            entries.splice(index, 1);
        entry.removeAbortListener?.();
    }
}
exports.WildberriesRequestScheduler = WildberriesRequestScheduler;
function wildberriesRateLimitKey(url, init) {
    let parsedUrl;
    try {
        parsedUrl = new URL(url);
    }
    catch {
        return null;
    }
    if (!parsedUrl.hostname.endsWith('wildberries.ru'))
        return null;
    const token = authorizationToken(init);
    if (!token)
        return null;
    const sellerId = wildberriesSellerIdFromToken(token);
    const sellerKey = sellerId
        ? `seller:${sellerId}`
        : `token:${(0, node_crypto_1.createHash)('sha256').update(token).digest('hex').slice(0, 24)}`;
    return `${sellerKey}:${wildberriesRateLimitGroup(parsedUrl.hostname)}`;
}
function wildberriesReadRequestKey(url, init) {
    if ((init.method ?? 'GET').toUpperCase() !== 'GET')
        return null;
    const rateLimitKey = wildberriesRateLimitKey(url, init);
    const token = authorizationToken(init);
    if (!rateLimitKey || !token)
        return null;
    const tokenKey = (0, node_crypto_1.createHash)('sha256').update(token).digest('hex').slice(0, 24);
    return `${rateLimitKey}:${tokenKey}:${url}`;
}
function wildberriesSellerIdFromToken(token) {
    try {
        const payload = token.split('.')[1];
        if (!payload)
            return null;
        const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
        const sellerId = typeof decoded.sid === 'string' ? decoded.sid.trim() : '';
        return sellerId || null;
    }
    catch {
        return null;
    }
}
function authorizationToken(init) {
    const value = new Headers(init.headers).get('authorization')?.trim() ?? '';
    return value.replace(/^Bearer\s+/i, '').trim();
}
function wildberriesRateLimitGroup(hostname) {
    if (hostname === 'marketplace-api.wildberries.ru')
        return 'marketplace';
    return hostname;
}
function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, Math.max(0, ms)));
}
