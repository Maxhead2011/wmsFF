"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateFbsBillingSettingsDto = void 0;
const client_1 = require("@prisma/client");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class FbsAdditionalServiceDto {
    serviceId;
    quantityMultiplier;
    matchKeywords;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], FbsAdditionalServiceDto.prototype, "serviceId", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.001),
    (0, class_validator_1.Max)(1000),
    __metadata("design:type", Number)
], FbsAdditionalServiceDto.prototype, "quantityMultiplier", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], FbsAdditionalServiceDto.prototype, "matchKeywords", void 0);
class UpdateFbsBillingSettingsDto {
    primaryProcessingEnabled;
    defaultDeliveryDestination;
    pickupPointBasePriceRub;
    vnukovoBasePriceRub;
    baseIncludedItems;
    extraBlockItems;
    extraBlockPriceRub;
    tieredLogisticsEnabled;
    logisticsFreeItemsLimit;
    logisticsCubicMeterLiters;
    logisticsCubicMeterPriceRub;
    logisticsPalletPriceRub;
    boxCapacityItems;
    fbsProcessingPriceRub;
    boxFormationServiceId;
    boxMaterialServiceId;
    palletsEnabled;
    boxesPerPallet;
    palletServiceId;
    additionalServices;
}
exports.UpdateFbsBillingSettingsDto = UpdateFbsBillingSettingsDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateFbsBillingSettingsDto.prototype, "primaryProcessingEnabled", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(client_1.FbsDeliveryDestination),
    __metadata("design:type", String)
], UpdateFbsBillingSettingsDto.prototype, "defaultDeliveryDestination", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "pickupPointBasePriceRub", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "vnukovoBasePriceRub", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(100000),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "baseIncludedItems", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(100000),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "extraBlockItems", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "extraBlockPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateFbsBillingSettingsDto.prototype, "tieredLogisticsEnabled", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100000),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "logisticsFreeItemsLimit", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(1000000),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "logisticsCubicMeterLiters", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "logisticsCubicMeterPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "logisticsPalletPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(100000),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "boxCapacityItems", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "fbsProcessingPriceRub", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== null && value !== ''),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", Object)
], UpdateFbsBillingSettingsDto.prototype, "boxFormationServiceId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== null && value !== ''),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", Object)
], UpdateFbsBillingSettingsDto.prototype, "boxMaterialServiceId", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateFbsBillingSettingsDto.prototype, "palletsEnabled", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(100000),
    __metadata("design:type", Number)
], UpdateFbsBillingSettingsDto.prototype, "boxesPerPallet", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== null && value !== ''),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", Object)
], UpdateFbsBillingSettingsDto.prototype, "palletServiceId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayUnique)((service) => service.serviceId),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FbsAdditionalServiceDto),
    __metadata("design:type", Array)
], UpdateFbsBillingSettingsDto.prototype, "additionalServices", void 0);
