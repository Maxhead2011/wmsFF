"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateFbsRepeatAssemblyDto = exports.PreviewFbsRepeatAssemblyDto = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class RepeatAssemblyOrderDto {
    connectionId;
    id;
    // FIX: stale screens/retries must refer to the exact previous physical attempt.
    assemblyId;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], RepeatAssemblyOrderDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], RepeatAssemblyOrderDto.prototype, "id", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], RepeatAssemblyOrderDto.prototype, "assemblyId", void 0);
class PreviewFbsRepeatAssemblyDto {
    clientId;
    orders;
}
exports.PreviewFbsRepeatAssemblyDto = PreviewFbsRepeatAssemblyDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], PreviewFbsRepeatAssemblyDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(100),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => RepeatAssemblyOrderDto),
    __metadata("design:type", Array)
], PreviewFbsRepeatAssemblyDto.prototype, "orders", void 0);
class CreateFbsRepeatAssemblyDto extends PreviewFbsRepeatAssemblyDto {
    previewToken;
    confirmAdditionalStockConsumption;
}
exports.CreateFbsRepeatAssemblyDto = CreateFbsRepeatAssemblyDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(64, 64),
    __metadata("design:type", String)
], CreateFbsRepeatAssemblyDto.prototype, "previewToken", void 0);
__decorate([
    (0, class_validator_1.Equals)(true, { message: 'Подтвердите дополнительное физическое списание товара.' }),
    __metadata("design:type", Boolean)
], CreateFbsRepeatAssemblyDto.prototype, "confirmAdditionalStockConsumption", void 0);
