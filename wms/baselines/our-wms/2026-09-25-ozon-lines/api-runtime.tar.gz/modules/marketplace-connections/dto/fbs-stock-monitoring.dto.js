"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RepairFbsStockMonitorDto = exports.RefreshFbsStockMonitorDto = exports.UpdateFbsStockMonitorConfigDto = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class UpdateFbsStockMonitorConfigDto {
    enabled;
    allowedDelaySeconds;
    retryIntervalSeconds;
    maxAttempts;
    wbRule;
    wmsRule;
}
exports.UpdateFbsStockMonitorConfigDto = UpdateFbsStockMonitorConfigDto;
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateFbsStockMonitorConfigDto.prototype, "enabled", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(30),
    (0, class_validator_1.Max)(86_400),
    __metadata("design:type", Number)
], UpdateFbsStockMonitorConfigDto.prototype, "allowedDelaySeconds", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(5),
    (0, class_validator_1.Max)(3_600),
    __metadata("design:type", Number)
], UpdateFbsStockMonitorConfigDto.prototype, "retryIntervalSeconds", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], UpdateFbsStockMonitorConfigDto.prototype, "maxAttempts", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['ORDER_AND_STOCK_DELTA']),
    __metadata("design:type", String)
], UpdateFbsStockMonitorConfigDto.prototype, "wbRule", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['ORDER_RESERVATION_OR_SELLABLE_DELTA']),
    __metadata("design:type", String)
], UpdateFbsStockMonitorConfigDto.prototype, "wmsRule", void 0);
class RefreshFbsStockMonitorDto {
    clientId;
    connectionId;
    eventIds;
}
exports.RefreshFbsStockMonitorDto = RefreshFbsStockMonitorDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], RefreshFbsStockMonitorDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], RefreshFbsStockMonitorDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], RefreshFbsStockMonitorDto.prototype, "eventIds", void 0);
// ADDED: confirmation requests carry a client-generated operation key so a
// repeated click or network retry cannot publish WB stock twice.
class RepairFbsStockMonitorDto {
    idempotencyKey;
}
exports.RepairFbsStockMonitorDto = RepairFbsStockMonitorDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], RepairFbsStockMonitorDto.prototype, "idempotencyKey", void 0);
