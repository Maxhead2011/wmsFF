"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateFbsWarehouseRoutesDto = exports.UpdateFbsWarehouseRouteItemDto = exports.FBS_WAREHOUSE_ROUTE_MODES = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
exports.FBS_WAREHOUSE_ROUTE_MODES = [
    'DEFAULT',
    'CENTRAL',
    'BRANCH',
    'EXCLUDED',
];
class UpdateFbsWarehouseRouteItemDto {
    marketplaceWarehouseId;
    marketplaceWarehouseName;
    officeId;
    officeName;
    officeCity;
    mode;
    executionWarehouseId;
    dropoffWarehouseId;
}
exports.UpdateFbsWarehouseRouteItemDto = UpdateFbsWarehouseRouteItemDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 120),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "marketplaceWarehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 240),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "marketplaceWarehouseName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 120),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "officeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 240),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "officeName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 240),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "officeCity", void 0);
__decorate([
    (0, class_validator_1.IsIn)(exports.FBS_WAREHOUSE_ROUTE_MODES),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "mode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "executionWarehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateFbsWarehouseRouteItemDto.prototype, "dropoffWarehouseId", void 0);
class UpdateFbsWarehouseRoutesDto {
    items;
}
exports.UpdateFbsWarehouseRoutesDto = UpdateFbsWarehouseRoutesDto;
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(500),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => UpdateFbsWarehouseRouteItemDto),
    __metadata("design:type", Array)
], UpdateFbsWarehouseRoutesDto.prototype, "items", void 0);
