"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpsertDbsIntegrationDto = void 0;
const client_1 = require("@prisma/client");
const class_validator_1 = require("class-validator");
class UpsertDbsIntegrationDto {
    clientId;
    marketplace;
    senderName;
    contactName;
    phone;
    email;
    city;
    address;
    postalCode;
    deliveryProvider;
    deliveryServiceName;
    deliveryApiUrl;
    deliveryAccountId;
    deliveryApiKey;
    deliveryApiSecret;
    isActive;
}
exports.UpsertDbsIntegrationDto = UpsertDbsIntegrationDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(client_1.MarketplaceType),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "marketplace", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(2, 180),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "senderName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(2, 160),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "contactName", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(5, 40),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsEmail)(),
    (0, class_validator_1.Length)(3, 180),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "email", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(2, 120),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "city", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(5, 500),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "address", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(3, 20),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "postalCode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(2, 80),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "deliveryProvider", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(2, 160),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "deliveryServiceName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(8, 500),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "deliveryApiUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 180),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "deliveryAccountId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(8, 4000),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "deliveryApiKey", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(4, 4000),
    __metadata("design:type", String)
], UpsertDbsIntegrationDto.prototype, "deliveryApiSecret", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpsertDbsIntegrationDto.prototype, "isActive", void 0);
