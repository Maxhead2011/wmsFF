"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResumeFbsReshipmentDto = exports.CreateFbsReshipmentDto = exports.PreviewFbsReshipmentDto = exports.CheckFbsReshipmentDto = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class CheckFbsReshipmentDto {
    clientId;
}
exports.CheckFbsReshipmentDto = CheckFbsReshipmentDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], CheckFbsReshipmentDto.prototype, "clientId", void 0);
class ReshipmentOrderDto {
    id;
    connectionId;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], ReshipmentOrderDto.prototype, "id", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], ReshipmentOrderDto.prototype, "connectionId", void 0);
class PreviewFbsReshipmentDto extends CheckFbsReshipmentDto {
    orders;
    mode;
}
exports.PreviewFbsReshipmentDto = PreviewFbsReshipmentDto;
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(100),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => ReshipmentOrderDto),
    __metadata("design:type", Array)
], PreviewFbsReshipmentDto.prototype, "orders", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['SAME_ITEM', 'NEW_ITEM']),
    __metadata("design:type", String)
], PreviewFbsReshipmentDto.prototype, "mode", void 0);
class CreateFbsReshipmentDto extends PreviewFbsReshipmentDto {
    previewToken;
    // FIX: confirms the preview's mode; NEW_ITEM explicitly means extra consumption.
    confirm;
}
exports.CreateFbsReshipmentDto = CreateFbsReshipmentDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(64, 64),
    __metadata("design:type", String)
], CreateFbsReshipmentDto.prototype, "previewToken", void 0);
__decorate([
    (0, class_validator_1.Equals)(true),
    __metadata("design:type", Boolean)
], CreateFbsReshipmentDto.prototype, "confirm", void 0);
class ResumeFbsReshipmentDto extends CheckFbsReshipmentDto {
    runId;
}
exports.ResumeFbsReshipmentDto = ResumeFbsReshipmentDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], ResumeFbsReshipmentDto.prototype, "runId", void 0);
