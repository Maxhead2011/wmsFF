"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateDbsIntegrationDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const upsert_dbs_integration_dto_1 = require("./upsert-dbs-integration.dto");
class UpdateDbsIntegrationDto extends (0, swagger_1.PartialType)(upsert_dbs_integration_dto_1.UpsertDbsIntegrationDto) {
}
exports.UpdateDbsIntegrationDto = UpdateDbsIntegrationDto;
