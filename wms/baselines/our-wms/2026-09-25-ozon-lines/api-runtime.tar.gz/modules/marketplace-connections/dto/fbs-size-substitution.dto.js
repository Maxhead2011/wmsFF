"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateSizeSubstitutionDto = exports.PreviewSizeSubstitutionDto = void 0;
const class_validator_1 = require("class-validator");
class PreviewSizeSubstitutionDto {
    clientId;
    orderId;
}
exports.PreviewSizeSubstitutionDto = PreviewSizeSubstitutionDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], PreviewSizeSubstitutionDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{1,20}$/),
    __metadata("design:type", String)
], PreviewSizeSubstitutionDto.prototype, "orderId", void 0);
class CreateSizeSubstitutionDto extends PreviewSizeSubstitutionDto {
    taskId;
    sourceSkuId;
    previewToken;
    confirmRelabel;
}
exports.CreateSizeSubstitutionDto = CreateSizeSubstitutionDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], CreateSizeSubstitutionDto.prototype, "taskId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], CreateSizeSubstitutionDto.prototype, "sourceSkuId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(64, 64),
    __metadata("design:type", String)
], CreateSizeSubstitutionDto.prototype, "previewToken", void 0);
__decorate([
    (0, class_validator_1.Equals)(true),
    __metadata("design:type", Boolean)
], CreateSizeSubstitutionDto.prototype, "confirmRelabel", void 0);
