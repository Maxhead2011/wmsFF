"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResolveFbsSyncConflictDto = exports.FbsPickedDisposition = exports.FbsSyncConflictResolutionAction = void 0;
const class_validator_1 = require("class-validator");
var FbsSyncConflictResolutionAction;
(function (FbsSyncConflictResolutionAction) {
    FbsSyncConflictResolutionAction["RETURN_TO_STOCK"] = "RETURN_TO_STOCK";
    FbsSyncConflictResolutionAction["MANAGER_CONFIRMED"] = "MANAGER_CONFIRMED";
})(FbsSyncConflictResolutionAction || (exports.FbsSyncConflictResolutionAction = FbsSyncConflictResolutionAction = {}));
// FIX: an explicit physical outcome never implies receipt into available stock.
var FbsPickedDisposition;
(function (FbsPickedDisposition) {
    FbsPickedDisposition["SHIP_WITH_WB_LABEL"] = "SHIP_WITH_WB_LABEL";
    FbsPickedDisposition["AWAIT_RETURN_RECEIPT"] = "AWAIT_RETURN_RECEIPT";
})(FbsPickedDisposition || (exports.FbsPickedDisposition = FbsPickedDisposition = {}));
class ResolveFbsSyncConflictDto {
    action;
    comment;
    pickedDisposition;
    // FIX: scans are required by the service only for physically picked returns in our WMS.
    returnBoxCode;
    returnBarcode;
    returnKiz;
}
exports.ResolveFbsSyncConflictDto = ResolveFbsSyncConflictDto;
__decorate([
    (0, class_validator_1.IsEnum)(FbsSyncConflictResolutionAction),
    __metadata("design:type", String)
], ResolveFbsSyncConflictDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], ResolveFbsSyncConflictDto.prototype, "comment", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(FbsPickedDisposition),
    __metadata("design:type", String)
], ResolveFbsSyncConflictDto.prototype, "pickedDisposition", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], ResolveFbsSyncConflictDto.prototype, "returnBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(128),
    __metadata("design:type", String)
], ResolveFbsSyncConflictDto.prototype, "returnBarcode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(2048),
    __metadata("design:type", String)
], ResolveFbsSyncConflictDto.prototype, "returnKiz", void 0);
