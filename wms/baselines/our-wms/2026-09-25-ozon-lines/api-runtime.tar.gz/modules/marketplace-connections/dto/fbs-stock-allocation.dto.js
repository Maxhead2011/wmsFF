"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExternalFbsStocksDto = exports.ExternalFbsStockItemDto = exports.ExternalFbsStockAllocationDto = exports.SyncFbsStockAllocationDto = exports.CreateFbsStockIntegrationKeyDto = exports.UpdateFbsStockAllocationDto = exports.FbsStockAllocationShareDto = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class FbsStockAllocationShareDto {
    warehouseId;
    warehouseName;
    percent;
    isPrimary;
}
exports.FbsStockAllocationShareDto = FbsStockAllocationShareDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], FbsStockAllocationShareDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(0, 200),
    __metadata("design:type", String)
], FbsStockAllocationShareDto.prototype, "warehouseName", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], FbsStockAllocationShareDto.prototype, "percent", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], FbsStockAllocationShareDto.prototype, "isPrimary", void 0);
class UpdateFbsStockAllocationDto {
    clientId;
    connectionId;
    enabled;
    lowStockThreshold = 10;
    recommendationDays = 30;
    shares;
}
exports.UpdateFbsStockAllocationDto = UpdateFbsStockAllocationDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], UpdateFbsStockAllocationDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], UpdateFbsStockAllocationDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateFbsStockAllocationDto.prototype, "enabled", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1000),
    __metadata("design:type", Object)
], UpdateFbsStockAllocationDto.prototype, "lowStockThreshold", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(7),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Object)
], UpdateFbsStockAllocationDto.prototype, "recommendationDays", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(100),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FbsStockAllocationShareDto),
    __metadata("design:type", Array)
], UpdateFbsStockAllocationDto.prototype, "shares", void 0);
class CreateFbsStockIntegrationKeyDto {
    clientId;
    name;
}
exports.CreateFbsStockIntegrationKeyDto = CreateFbsStockIntegrationKeyDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], CreateFbsStockIntegrationKeyDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], CreateFbsStockIntegrationKeyDto.prototype, "name", void 0);
class SyncFbsStockAllocationDto {
    clientId;
    connectionId;
}
exports.SyncFbsStockAllocationDto = SyncFbsStockAllocationDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], SyncFbsStockAllocationDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], SyncFbsStockAllocationDto.prototype, "connectionId", void 0);
class ExternalFbsStockAllocationDto {
    connectionId;
    enabled;
    lowStockThreshold = 10;
    externalReference;
    shares;
}
exports.ExternalFbsStockAllocationDto = ExternalFbsStockAllocationDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], ExternalFbsStockAllocationDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], ExternalFbsStockAllocationDto.prototype, "enabled", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1000),
    __metadata("design:type", Object)
], ExternalFbsStockAllocationDto.prototype, "lowStockThreshold", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 120),
    __metadata("design:type", String)
], ExternalFbsStockAllocationDto.prototype, "externalReference", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(100),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FbsStockAllocationShareDto),
    __metadata("design:type", Array)
], ExternalFbsStockAllocationDto.prototype, "shares", void 0);
class ExternalFbsStockItemDto {
    skuId;
    barcode;
    article;
    requestedAmount;
}
exports.ExternalFbsStockItemDto = ExternalFbsStockItemDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], ExternalFbsStockItemDto.prototype, "skuId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 200),
    __metadata("design:type", String)
], ExternalFbsStockItemDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 200),
    __metadata("design:type", String)
], ExternalFbsStockItemDto.prototype, "article", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], ExternalFbsStockItemDto.prototype, "requestedAmount", void 0);
class ExternalFbsStocksDto {
    connectionId;
    externalReference;
    items;
}
exports.ExternalFbsStocksDto = ExternalFbsStocksDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], ExternalFbsStocksDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 120),
    __metadata("design:type", String)
], ExternalFbsStocksDto.prototype, "externalReference", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(5000),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => ExternalFbsStockItemDto),
    __metadata("design:type", Array)
], ExternalFbsStocksDto.prototype, "items", void 0);
