"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpsertMarketplaceConnectionDto = void 0;
const client_1 = require("@prisma/client");
const class_validator_1 = require("class-validator");
class UpsertMarketplaceConnectionDto {
    clientId;
    marketplace;
    accountName;
    sellerId;
    apiKey;
    isActive;
    comment;
    fbsExecutionWarehouseId;
    fbsDropoffWarehouseId;
    fbsAutoRouteNewWarehouses;
}
exports.UpsertMarketplaceConnectionDto = UpsertMarketplaceConnectionDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(client_1.MarketplaceType),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "marketplace", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(2, 120),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "accountName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(2, 120),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "sellerId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(8, 4000),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "apiKey", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpsertMarketplaceConnectionDto.prototype, "isActive", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 500),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "comment", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "fbsExecutionWarehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateIf)((_object, value) => value !== ''),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpsertMarketplaceConnectionDto.prototype, "fbsDropoffWarehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpsertMarketplaceConnectionDto.prototype, "fbsAutoRouteNewWarehouses", void 0);
