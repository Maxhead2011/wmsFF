"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsCancelledOrdersReportDto = exports.FBS_CANCELLED_REPORT_MAX_ORDERS = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const fbs_order_selection_dto_1 = require("./fbs-order-selection.dto");
exports.FBS_CANCELLED_REPORT_MAX_ORDERS = 50_000;
// ADDED: a read-only export DTO keeps bulk reporting limits away from write operations.
class FbsCancelledOrdersReportDto {
    clientId;
    orders;
}
exports.FbsCancelledOrdersReportDto = FbsCancelledOrdersReportDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], FbsCancelledOrdersReportDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1)
    // FIX: cancelled history can exceed the 5,000-item limit used by write operations.
    ,
    (0, class_validator_1.ArrayMaxSize)(exports.FBS_CANCELLED_REPORT_MAX_ORDERS),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => fbs_order_selection_dto_1.FbsOrderSelectionItemDto),
    __metadata("design:type", Array)
], FbsCancelledOrdersReportDto.prototype, "orders", void 0);
