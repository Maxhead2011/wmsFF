"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplyFbsSupplyReconciliationDto = exports.FbsSupplyReconciliationPreviewDto = void 0;
const class_validator_1 = require("class-validator");
// ADDED: strict runtime validation for the manual WB supply reconciliation flow.
class FbsSupplyReconciliationPreviewDto {
    clientId;
    connectionId;
    supplyId;
}
exports.FbsSupplyReconciliationPreviewDto = FbsSupplyReconciliationPreviewDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], FbsSupplyReconciliationPreviewDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], FbsSupplyReconciliationPreviewDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 120),
    __metadata("design:type", String)
], FbsSupplyReconciliationPreviewDto.prototype, "supplyId", void 0);
class ApplyFbsSupplyReconciliationDto extends FbsSupplyReconciliationPreviewDto {
    fingerprint;
}
exports.ApplyFbsSupplyReconciliationDto = ApplyFbsSupplyReconciliationDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^[0-9a-f]{64}$/i, {
        message: 'fingerprint must be a 64-character SHA-256 value',
    }),
    __metadata("design:type", String)
], ApplyFbsSupplyReconciliationDto.prototype, "fingerprint", void 0);
