"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsOrderSelectionDto = exports.FbsOrderSelectionItemDto = void 0;
const class_transformer_1 = require("class-transformer");
const client_1 = require("@prisma/client");
const class_validator_1 = require("class-validator");
class FbsOrderSelectionItemDto {
    connectionId;
    id;
    // Older/open browser sessions can submit the richer order preview object.
    // These display-only properties are deliberately ignored by the service,
    // but accepting their validated shape keeps actions compatible during rollout.
    assemblyId;
    requiresKiz;
    kizAccepted;
}
exports.FbsOrderSelectionItemDto = FbsOrderSelectionItemDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], FbsOrderSelectionItemDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], FbsOrderSelectionItemDto.prototype, "id", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", Object)
], FbsOrderSelectionItemDto.prototype, "assemblyId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], FbsOrderSelectionItemDto.prototype, "requiresKiz", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], FbsOrderSelectionItemDto.prototype, "kizAccepted", void 0);
class FbsOrderSelectionDto {
    clientId;
    orders;
    deliveryDestination;
    // ADDED: WB derives the destination from the orders, but WMS requires the
    // operator to confirm it explicitly before the irreversible delivery call.
    destinationOfficeId;
    // ADDED: the public WB FBS API does not accept a delivery date; WMS stores
    // the operator's logistics plan and includes it in the delivery audit.
    plannedDeliveryDate;
    marketplaceWarehouseKey;
    targetSupplyId;
    // ADDED: protects online-request recovery from replaying a completed move.
    sourceRequestId;
}
exports.FbsOrderSelectionDto = FbsOrderSelectionDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], FbsOrderSelectionDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1)
    // A manager may select several large WMS requests at once. Marketplace
    // operations split the selection into WB-safe chunks inside the service,
    // so the transport DTO must not reject the combined selection at 1,000.
    ,
    (0, class_validator_1.ArrayMaxSize)(5000),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => FbsOrderSelectionItemDto),
    __metadata("design:type", Array)
], FbsOrderSelectionDto.prototype, "orders", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(client_1.FbsDeliveryDestination),
    __metadata("design:type", String)
], FbsOrderSelectionDto.prototype, "deliveryDestination", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d+$/),
    (0, class_validator_1.Length)(1, 20),
    __metadata("design:type", String)
], FbsOrderSelectionDto.prototype, "destinationOfficeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)({ strict: true }),
    __metadata("design:type", String)
], FbsOrderSelectionDto.prototype, "plannedDeliveryDate", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 260),
    __metadata("design:type", String)
], FbsOrderSelectionDto.prototype, "marketplaceWarehouseKey", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], FbsOrderSelectionDto.prototype, "targetSupplyId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], FbsOrderSelectionDto.prototype, "sourceRequestId", void 0);
