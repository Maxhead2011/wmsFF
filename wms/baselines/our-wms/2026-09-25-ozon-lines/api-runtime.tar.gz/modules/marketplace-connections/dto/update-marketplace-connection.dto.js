"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateMarketplaceConnectionDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const upsert_marketplace_connection_dto_1 = require("./upsert-marketplace-connection.dto");
class UpdateMarketplaceConnectionDto extends (0, swagger_1.PartialType)(upsert_marketplace_connection_dto_1.UpsertMarketplaceConnectionDto) {
}
exports.UpdateMarketplaceConnectionDto = UpdateMarketplaceConnectionDto;
