"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuplicateApplyQueue = exports.applyJobKey = exports.applyJobDto = exports.duplicateApplyQueueEnabled = void 0;
exports.completeDuplicateApply = completeDuplicateApply;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const warehouse_auth_scope_service_1 = require("../auth/warehouse-auth-scope.service");
const duplicateApplyQueueEnabled = () => process.env.WMS_DUPLICATE_APPLY_QUEUE_ENABLED === 'true';
exports.duplicateApplyQueueEnabled = duplicateApplyQueueEnabled;
const prefix = 'marketplace.duplicates.apply.';
const applyJobDto = (job) => ({ id: job.id, groupId: job.groupId, name: job.name, status: job.status,
    message: job.message, createdAt: job.createdAt, updatedAt: job.updatedAt });
exports.applyJobDto = applyJobDto;
const json = (value) => JSON.parse(JSON.stringify(value));
const applyJobKey = (clientId, userId, body) => prefix + clientId + '.' +
    (0, node_crypto_1.createHash)('sha256').update(JSON.stringify({ userId, body })).digest('hex');
exports.applyJobKey = applyJobKey;
// FIX: durable requests survive HTTP timeouts/restarts; settings and completion commit together.
async function completeDuplicateApply(tx, key) {
    const row = await tx.systemSetting.findUnique({ where: { key } });
    const job = row?.value;
    if (!job || job.status !== 'WAITING')
        throw new common_1.ConflictException('Запрос применения уже обработан.');
    await tx.systemSetting.update({ where: { key }, data: { value: json({ ...job, status: 'APPLIED', updatedAt: new Date().toISOString(),
                message: 'Настройки применены. Остатки переданы в очередь пересчёта и проверки WB.' }) } });
}
class DuplicateApplyQueue {
    db;
    apply;
    timer;
    busy = false;
    logger = new common_1.Logger(DuplicateApplyQueue.name);
    constructor(db, apply) {
        this.db = db;
        this.apply = apply;
    }
    start() {
        if (!(0, exports.duplicateApplyQueueEnabled)() || this.timer)
            return;
        this.timer = setInterval(() => { void this.tick().catch(e => this.logger.error(e instanceof Error ? e.message : 'Ошибка очереди применения')); }, 5000);
        this.timer.unref();
    }
    stop() { if (this.timer)
        clearInterval(this.timer); this.timer = undefined; }
    async existing(clientId, user, body) {
        const row = await this.db.systemSetting.findUnique({ where: { key: (0, exports.applyJobKey)(clientId, user.id, body) } });
        return row && row.value.status !== 'FAILED' ? (0, exports.applyJobDto)(row.value) : null;
    }
    async list(clientId) {
        if (!(0, exports.duplicateApplyQueueEnabled)())
            return [];
        const scope = { key: { startsWith: prefix + clientId + '.' } };
        const [waiting, recent] = await Promise.all([
            this.db.systemSetting.findMany({ where: { ...scope, value: { path: ['status'], equals: 'WAITING' } }, orderBy: { createdAt: 'asc' } }),
            this.db.systemSetting.findMany({ where: scope, orderBy: { updatedAt: 'desc' }, take: 30 }),
        ]);
        return [...new Map([...waiting, ...recent].map(r => [r.key, r])).values()].map(r => (0, exports.applyJobDto)(r.value));
    }
    async enqueue(clientId, body, user) {
        const group = body.group;
        const key = (0, exports.applyJobKey)(clientId, user.id, body);
        return this.db.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${'marketplace.duplicates.groups.' + clientId}))`;
            const old = await tx.systemSetting.findUnique({ where: { key } });
            if (old && old.value.status !== 'FAILED')
                return (0, exports.applyJobDto)(old.value);
            const setting = await tx.systemSetting.findUnique({ where: { key: 'marketplace.duplicates.groups.' + clientId } });
            if ((setting?.updatedAt.toISOString() ?? null) !== body.revision)
                throw new common_1.ConflictException('Группы изменились. Повторите предпросмотр.');
            const waiting = await tx.systemSetting.findMany({ where: { key: { startsWith: prefix + clientId + '.' }, value: { path: ['status'], equals: 'WAITING' } } });
            if (waiting.some(r => r.value.groupId === group.id))
                throw new common_1.ConflictException('Для этой группы уже ожидает применения другой запрос. Дождитесь результата.');
            const now = new Date().toISOString();
            const job = { version: 1, id: key, clientId, userId: user.id, warehouseId: user.activeWarehouseId ?? null,
                groupId: group.id, name: group.name, body: JSON.parse(JSON.stringify(body)), status: 'WAITING',
                message: 'Ожидает завершения отправки WB. Настройки будут проверены и применены автоматически.', createdAt: now, updatedAt: now, attempts: 0 };
            await tx.systemSetting.upsert({ where: { key }, create: { key, value: json(job), updatedByUserId: user.id }, update: { value: json(job), updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'duplicate.stock.groups.queued', entity: 'Client', entityId: clientId, payload: json({ requestId: key, groupId: group.id }) } });
            return (0, exports.applyJobDto)(job);
        });
    }
    async user(job) {
        const user = await this.db.user.findUnique({ where: { id: job.userId }, include: { roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } },
                clientScopes: { include: { client: { select: { isDemo: true, relabelingEnabled: true } } } }, warehouseScopes: { include: { warehouse: { select: { isActive: true } } } } } });
        if (!user || user.status !== 'ACTIVE' || user.isDemo)
            throw new common_1.ForbiddenException('Доступ автора запроса отозван.');
        const roleCodes = user.roles.map(r => r.role.code), permissionCodes = [...new Set(user.roles.flatMap(r => r.role.permissions.map(p => p.permission.code)))];
        if (!permissionCodes.some(p => ['system:admin', 'clients:write', 'client-requests:write'].includes(p)))
            throw new common_1.ForbiddenException('Нет разрешения применять настройки.');
        const scope = await new warehouse_auth_scope_service_1.WarehouseAuthScopeService(this.db).resolve({ ...user, roleCodes, permissionCodes, activeWarehouseId: job.warehouseId });
        return { id: user.id, email: user.email, name: user.name, isDemo: false, roleCodes, permissionCodes, ...scope,
            warehouseIds: user.warehouseScopes.filter(w => w.canRead && w.warehouse.isActive).map(w => w.warehouseId) };
    }
    async tick() {
        if (!(0, exports.duplicateApplyQueueEnabled)() || this.busy)
            return;
        this.busy = true;
        try {
            await this.db.$transaction(async (tx) => {
                // A database lock serializes workers across replicas without a fragile process lease.
                const lock = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext('duplicate.apply.worker')) AS acquired`;
                if (!lock[0]?.acquired)
                    return;
                const rows = await tx.systemSetting.findMany({ where: { key: { startsWith: prefix }, value: { path: ['status'], equals: 'WAITING' } }, orderBy: { updatedAt: 'asc' }, take: 1 });
                if (!rows.length)
                    return;
                const row = rows[0], job = row.value;
                try {
                    const user = await this.user(job);
                    await this.apply(job.clientId, job.body, user, row.key);
                }
                catch (e) {
                    const code = e?.meta?.code;
                    const transient = code === '55P03' || code === '57014' || ['P2028', 'P1001', 'P1002'].includes(e?.code ?? '') || !(e instanceof common_1.HttpException);
                    const retry = transient && Date.now() - Date.parse(job.createdAt) < 86400000;
                    // Never overwrite a success committed immediately before a connection error.
                    const current = await this.db.systemSetting.findUnique({ where: { key: row.key } });
                    if (current?.value?.status !== 'WAITING')
                        return;
                    const message = retry ? 'Ожидает завершения отправки WB. Повторная попытка выполняется автоматически.' :
                        e instanceof common_1.HttpException ? e.message : 'Не удалось применить настройки. Обновите список и повторите предпросмотр.';
                    await this.db.systemSetting.update({ where: { key: row.key }, data: { value: json({ ...job, status: retry ? 'WAITING' : 'FAILED', message, attempts: job.attempts + 1, updatedAt: new Date().toISOString() }) } });
                    if (!retry)
                        await this.db.auditLog.create({ data: { userId: job.userId, action: 'duplicate.stock.groups.apply_failed', entity: 'Client', entityId: job.clientId, payload: json({ requestId: row.key, message }) } });
                }
            }, { timeout: 60000, maxWait: 5000 });
        }
        finally {
            this.busy = false;
        }
    }
}
exports.DuplicateApplyQueue = DuplicateApplyQueue;
