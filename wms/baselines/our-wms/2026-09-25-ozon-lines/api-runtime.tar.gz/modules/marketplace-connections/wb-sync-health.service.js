"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var WbSyncHealthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WbSyncHealthService = void 0;
exports.wbHealthError = wbHealthError;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const marketplace_stock_control_service_1 = require("./marketplace-stock-control.service");
const wb_sync_health_rules_1 = require("./wb-sync-health.rules");
const PREFIX = 'monitor.wbSync.';
// FIX: only persist bounded operational facts, never API credentials or raw exception payloads.
function wbHealthError(error) {
    const message = error instanceof Error ? error.message : String(error);
    if (/expired transaction|Transaction already closed/i.test(message))
        return 'Тайм-аут транзакции ВМС';
    if (/INT4/i.test(message))
        return 'Переполнение INT4';
    return 'Ошибка обработки; требуется проверка серверного журнала';
}
let WbSyncHealthService = WbSyncHealthService_1 = class WbSyncHealthService {
    prisma;
    scopes;
    stockControl;
    logger = new common_1.Logger(WbSyncHealthService_1.name);
    timer;
    ticking = false;
    constructor(prisma, scopes, stockControl) {
        this.prisma = prisma;
        this.scopes = scopes;
        this.stockControl = stockControl;
    }
    get enabled() { return process.env.WMS_WB_SYNC_HEALTH_ENABLED === 'true'; }
    onModuleInit() {
        if (!this.enabled)
            return;
        this.timer = setInterval(() => { void this.tick(); }, 60_000);
        this.timer.unref();
    }
    onModuleDestroy() { if (this.timer)
        clearInterval(this.timer); }
    initial(clientId) {
        return { clientId, cycles: [], incidentAt: null, failures: 0, nextCheckAt: new Date(Date.now() + wb_sync_health_rules_1.WB_HEALTH_HOUR).toISOString(),
            checkedCycleId: null, lastSuccessAt: null, checkedAt: null };
    }
    // FIX: separate observer failures from order refresh and all financial transactions.
    async begin(clientId) {
        if (!this.enabled)
            return;
        try {
            if (!await this.stockControl.isEnabled(clientId))
                return;
            const count = await this.prisma.clientMarketplaceConnection.count({ where: { clientId, isActive: true, marketplace: 'WILDBERRIES' } });
            if (!count)
                return;
            const cycle = { id: (0, node_crypto_1.randomUUID)(), startedAt: new Date().toISOString(), finishedAt: null, orders: 'В работе', billing: 'Ожидание', error: null, connections: [] };
            await this.save(clientId, state => { state.cycles = [cycle, ...state.cycles].slice(0, 20); });
            return cycle;
        }
        catch {
            this.logger.warn('WB cycle observer could not persist start');
        }
    }
    async finish(clientId, cycle) {
        if (!cycle || !this.enabled)
            return;
        try {
            cycle.finishedAt = new Date().toISOString();
            const connections = await this.prisma.clientMarketplaceConnection.findMany({ where: { clientId, isActive: true, marketplace: 'WILDBERRIES' },
                select: { id: true, fbsExecutionWarehouseId: true } });
            for (const connection of connections) {
                const rows = await this.prisma.wbStockPublicationCheck.findMany({ where: { connectionId: connection.id },
                    select: { runId: true, status: true, phase: true, calculatedAmount: true, observedAmount: true, updatedAt: true, error: true } });
                cycle.connections.push({ id: connection.id, warehouseId: connection.fbsExecutionWarehouseId, proof: (0, wb_sync_health_rules_1.evaluateWbSyncProof)(rows, new Date(cycle.startedAt)) });
            }
            await this.save(clientId, async (state, tx) => {
                state.cycles = [cycle, ...state.cycles.filter(item => item.id !== cycle.id)].slice(0, 20);
                if (state.incidentAt || !state.checkedAt || Date.parse(state.nextCheckAt) <= Date.now())
                    await this.evaluate(state, tx, cycle);
            });
        }
        catch {
            this.logger.warn('WB cycle observer could not persist completion');
        }
    }
    async save(clientId, change) {
        const key = PREFIX + clientId;
        await this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${key}))`;
            const row = await tx.systemSetting.findUnique({ where: { key } });
            const state = row ? row.value : this.initial(clientId);
            await change(state, tx);
            const value = state;
            await tx.systemSetting.upsert({ where: { key }, create: { key, value }, update: { value } });
        }, { timeout: 10_000 });
    }
    async evaluate(state, tx, cycle) {
        const now = new Date();
        const fresh = cycle?.finishedAt && Date.parse(cycle.finishedAt) >= now.getTime() - wb_sync_health_rules_1.WB_HEALTH_HOUR;
        const success = Boolean(fresh && !cycle.error && cycle.orders === 'Завершено' && cycle.billing === 'Завершено'
            && cycle.connections.length && cycle.connections.every(connection => connection.proof.success));
        // FIX: one unfinished or stale cycle never increments the failed-cycle counter repeatedly.
        if (state.incidentAt && state.checkedCycleId === (cycle?.id ?? null))
            return;
        const previousIncident = state.incidentAt;
        Object.assign(state, (0, wb_sync_health_rules_1.nextWbHealthState)(state, !success, now));
        state.checkedAt = now.toISOString();
        state.checkedCycleId = cycle?.id ?? null;
        if (success)
            state.lastSuccessAt = cycle.finishedAt;
        if (!success || previousIncident) {
            const connections = await tx.clientMarketplaceConnection.findMany({ where: { clientId: state.clientId, isActive: true, marketplace: 'WILDBERRIES' }, select: { fbsExecutionWarehouseId: true } });
            const client = await tx.client.findUnique({ where: { id: state.clientId }, select: { name: true, isDemo: true } });
            for (const warehouseId of new Set(connections.map(connection => connection.fbsExecutionWarehouseId))) {
                const incident = state.incidentAt ?? previousIncident;
                const dedupeKey = `wb-sync:${state.clientId}:${warehouseId ?? 'global'}:${incident}`;
                const body = success ? 'Синхронизация восстановлена. Следующая проверка через час.'
                    : `${client?.name ?? 'Клиент'}: ${fresh ? 'цикл завершён с проблемой' : 'нет свежего завершённого цикла'}. Проверок с ошибкой: ${state.failures}. Мониторинг → Синхронизация WB.`;
                const title = success ? 'WB: проблема устранена' : 'WB: требуется проверка синхронизации';
                await tx.adminNotification.upsert({ where: { dedupeKey }, update: { title, body },
                    create: { dedupeKey, type: 'WB_SYNC_HEALTH', title, body, clientId: state.clientId, warehouseId,
                        actorId: 'system', actorName: 'Контроль синхронизации WB', isDemo: client?.isDemo ?? false } });
            }
        }
    }
    async tick() {
        if (!this.enabled || this.ticking)
            return;
        this.ticking = true;
        try {
            const clients = await this.prisma.clientMarketplaceConnection.findMany({ where: { isActive: true, marketplace: 'WILDBERRIES' }, distinct: ['clientId'], select: { clientId: true } });
            for (const { clientId } of clients) {
                if (!await this.stockControl.isEnabled(clientId))
                    continue;
                await this.save(clientId, async (state, tx) => {
                    if (Date.parse(state.nextCheckAt) > Date.now())
                        return;
                    await this.evaluate(state, tx, state.cycles.find(cycle => cycle.finishedAt));
                });
            }
        }
        catch {
            this.logger.warn('WB hourly health check failed; will retry');
        }
        finally {
            this.ticking = false;
        }
    }
    async list(user) {
        if (!user.permissionCodes.includes('system:admin') && !user.roleCodes.some(role => ['ADMIN', 'OWNER'].includes(role)))
            throw new common_1.ForbiddenException('Только для администратора.');
        if (!this.enabled)
            return { enabled: false, items: [] };
        const clientId = this.scopes.resolveClientFilter(user);
        // FIX: branch and demo scopes apply before loading operational details.
        const clients = await this.prisma.client.findMany({ where: { ...(clientId ? { id: clientId } : {}), isDemo: user.isDemo ?? false,
                ...(!user.permissionCodes.includes('system:admin') || user.warehouseIds?.length
                    ? { warehouseLinks: { some: { warehouseId: { in: user.warehouseIds ?? [] } } } } : {}) }, select: { id: true, name: true } });
        const items = [];
        for (const client of clients) {
            const row = await this.prisma.systemSetting.findUnique({ where: { key: PREFIX + client.id } });
            if (row)
                items.push({ clientName: client.name, ...row.value, active: await this.stockControl.isEnabled(client.id) });
        }
        return { enabled: true, items };
    }
};
exports.WbSyncHealthService = WbSyncHealthService;
exports.WbSyncHealthService = WbSyncHealthService = WbSyncHealthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService,
        marketplace_stock_control_service_1.MarketplaceStockControlService])
], WbSyncHealthService);
