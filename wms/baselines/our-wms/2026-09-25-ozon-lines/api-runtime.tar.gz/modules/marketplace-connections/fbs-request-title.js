"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsRequestSyncTitle = fbsRequestSyncTitle;
// FIX: retain the explicit shortage label used by the consolidated FBS display.
function fbsRequestSyncTitle(title, quantity, reshipment, repeat, shortageEnabled) {
    if (reshipment || (shortageEnabled && title.trim().toLocaleLowerCase('ru-RU') === 'logoff нет на складе'))
        return title;
    return repeat ? `Повторная сборка WB — ${quantity} заказов` : `FBS — ${quantity} заказ(а/ов)`;
}
