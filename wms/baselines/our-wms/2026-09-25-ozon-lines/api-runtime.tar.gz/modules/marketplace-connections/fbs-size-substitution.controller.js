"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsSizeSubstitutionController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const fbs_size_substitution_dto_1 = require("./dto/fbs-size-substitution.dto");
const fbs_size_substitution_service_1 = require("./fbs-size-substitution.service");
let FbsSizeSubstitutionController = class FbsSizeSubstitutionController {
    service;
    constructor(service) {
        this.service = service;
    }
    capabilities(user) { return this.service.capabilities(user); }
    preview(dto, user) { return this.service.preview(dto, user); }
    create(dto, user) { return this.service.create(dto, user); }
};
exports.FbsSizeSubstitutionController = FbsSizeSubstitutionController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FbsSizeSubstitutionController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Post)('preview'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_size_substitution_dto_1.PreviewSizeSubstitutionDto, Object]),
    __metadata("design:returntype", void 0)
], FbsSizeSubstitutionController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_size_substitution_dto_1.CreateSizeSubstitutionDto, Object]),
    __metadata("design:returntype", void 0)
], FbsSizeSubstitutionController.prototype, "create", null);
exports.FbsSizeSubstitutionController = FbsSizeSubstitutionController = __decorate([
    (0, common_1.Controller)('marketplace-connections/fbs/size-substitution'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __metadata("design:paramtypes", [fbs_size_substitution_service_1.FbsSizeSubstitutionService])
], FbsSizeSubstitutionController);
