"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsStockMonitorEventKey = fbsStockMonitorEventKey;
exports.fbsStockMonitorExpectedAfter = fbsStockMonitorExpectedAfter;
exports.evaluateFbsStockMonitorWb = evaluateFbsStockMonitorWb;
exports.evaluateFbsStockMonitorWms = evaluateFbsStockMonitorWms;
exports.fbsStockMonitorOverallStatus = fbsStockMonitorOverallStatus;
exports.fbsStockMonitorNeedsRetry = fbsStockMonitorNeedsRetry;
// ADDED: one deterministic key makes repeated WB delivery idempotent.
function fbsStockMonitorEventKey(input) {
    return [
        'WILDBERRIES',
        input.connectionId.trim(),
        input.orderId.trim(),
        input.skuId.trim(),
        input.eventType,
    ].join(':');
}
// ADDED: cancellation/return restore the quantity; sale removes it.
function fbsStockMonitorExpectedAfter(beforeAmount, quantity, eventType) {
    if (beforeAmount == null || !Number.isFinite(beforeAmount))
        return null;
    const normalizedQuantity = Math.max(1, Math.trunc(quantity));
    return eventType === 'SALE'
        ? Math.max(0, Math.trunc(beforeAmount) - normalizedQuantity)
        : Math.max(0, Math.trunc(beforeAmount) + normalizedQuantity);
}
// ADDED: WB success needs the exact order plus the expected aggregate delta.
function evaluateFbsStockMonitorWb(input) {
    return evaluateAmountRule(input, false);
}
// ADDED: WMS may prove a sale through an exact reservation even before a
// physical balance movement; aggregate deltas remain a secondary proof.
function evaluateFbsStockMonitorWms(input) {
    const expectedAfterAmount = input.expectedAfterAmount ?? fbsStockMonitorExpectedAfter(input.beforeAmount, input.quantity, input.eventType);
    if (input.temporarilyUnavailable) {
        return unavailableResult(expectedAfterAmount, input.unavailableMessage);
    }
    if (input.eventType === 'SALE' && input.exactReservationMatched) {
        return {
            status: 'SUCCESS',
            expectedAfterAmount,
            observedDelta: observedDelta(input.beforeAmount, input.currentAmount, input.eventType),
            message: null,
        };
    }
    if (input.eventType !== 'SALE' &&
        input.exactReservationReleased &&
        input.exactOrderMatched) {
        return {
            status: 'SUCCESS',
            expectedAfterAmount,
            observedDelta: observedDelta(input.beforeAmount, input.currentAmount, input.eventType),
            message: null,
        };
    }
    return evaluateAmountRule(input, true);
}
function fbsStockMonitorOverallStatus(wbStatus, wmsStatus) {
    if (wbStatus === 'ERROR' || wmsStatus === 'ERROR')
        return 'ERROR';
    if (wbStatus === 'SUCCESS' && wmsStatus === 'SUCCESS')
        return 'SUCCESS';
    if (wbStatus === 'PENDING' || wmsStatus === 'PENDING')
        return 'PENDING';
    return 'UNAVAILABLE';
}
function fbsStockMonitorNeedsRetry(status) {
    return status === 'PENDING' || status === 'UNAVAILABLE';
}
function evaluateAmountRule(input, allowMatchedAggregate) {
    const expectedAfterAmount = input.expectedAfterAmount ?? fbsStockMonitorExpectedAfter(input.beforeAmount, input.quantity, input.eventType);
    if (input.temporarilyUnavailable) {
        return unavailableResult(expectedAfterAmount, input.unavailableMessage);
    }
    if (input.beforeAmount == null || input.currentAmount == null || expectedAfterAmount == null) {
        return unavailableResult(expectedAfterAmount, 'Недостаточно снимков остатка для точной проверки.');
    }
    const amountMatched = input.eventType === 'SALE'
        ? input.currentAmount <= expectedAfterAmount
        : input.currentAmount >= expectedAfterAmount;
    if (input.exactOrderMatched && amountMatched) {
        return {
            status: 'SUCCESS',
            expectedAfterAmount,
            observedDelta: observedDelta(input.beforeAmount, input.currentAmount, input.eventType),
            message: null,
        };
    }
    const expired = input.nowMs >= input.deadlineMs || input.attempt >= input.maxAttempts;
    if (!expired) {
        return {
            status: 'PENDING',
            expectedAfterAmount,
            observedDelta: observedDelta(input.beforeAmount, input.currentAmount, input.eventType),
            message: amountMatched && !input.exactOrderMatched
                ? 'Количество изменилось, но нет достаточной связи с конкретным заказом.'
                : 'Ожидается синхронизация остатка.',
        };
    }
    const delta = observedDelta(input.beforeAmount, input.currentAmount, input.eventType);
    const required = Math.max(1, Math.trunc(input.quantity));
    const partial = delta != null && delta > 0 && delta < required;
    return {
        status: 'ERROR',
        expectedAfterAmount,
        observedDelta: delta,
        message: partial
            ? `Зафиксировано частичное изменение: ${delta} из ${required} ед.`
            : allowMatchedAggregate && !input.exactOrderMatched
                ? 'Не найдено резервирование этого заказа и не подтверждено связанное изменение остатка.'
                : 'Допустимое время ожидания истекло, ожидаемое изменение остатка не подтверждено.',
    };
}
function unavailableResult(expectedAfterAmount, message) {
    return {
        status: 'UNAVAILABLE',
        expectedAfterAmount,
        observedDelta: null,
        message: message || 'Проверка временно недоступна.',
    };
}
function observedDelta(beforeAmount, currentAmount, eventType) {
    if (beforeAmount == null || currentAmount == null)
        return null;
    return eventType === 'SALE'
        ? Math.max(0, beforeAmount - currentAmount)
        : Math.max(0, currentAmount - beforeAmount);
}
