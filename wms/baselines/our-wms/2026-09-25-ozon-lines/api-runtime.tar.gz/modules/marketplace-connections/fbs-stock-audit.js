"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsKizAuditEnabled = exports.FBS_KIZ_AUDIT_MARKER = void 0;
exports.fbsStockAuditError = fbsStockAuditError;
exports.validateFbsStockAudit = validateFbsStockAudit;
const kiz_physical_identity_1 = require("../../common/kiz-physical-identity");
const common_1 = require("@nestjs/common");
const confirmed_kiz_composition_1 = require("../inventory/confirmed-kiz-composition");
exports.FBS_KIZ_AUDIT_MARKER = '[FBS_KIZ_STOCK_CHECK]';
const fbsKizAuditEnabled = () => process.env.WMS_FBS_KIZ_MANDATORY_AUDIT === 'true';
exports.fbsKizAuditEnabled = fbsKizAuditEnabled;
// FIX: keep legacy errors outside our opt-in deployment; carry authoritative task/box scope to the TSD.
function fbsStockAuditError(task, message) {
    return new common_1.BadRequestException((0, exports.fbsKizAuditEnabled)() && task.id && task.clientId && task.boxId && task.boxCode
        ? { code: 'FBS_STOCK_AUDIT_REQUIRED', message, taskId: task.id, clientId: task.clientId, boxCode: task.boxCode }
        : message);
}
const identity = (value) => (0, kiz_physical_identity_1.kizIdentityTransferEnabled)() ? (0, kiz_physical_identity_1.physicalKizIdentity)(value) : /^(01\d{14}21[^\u0000-\u001f]{13})(?:\u001d|$)/
    .exec(value.replace(/^\]d2/i, '').replace(/<GS>/gi, '\u001d'))?.[1] ?? '';
// FIX: this is a read-only return gate, never a KIZ replacement, WB undo or second stock debit.
// Quantity-only inventory resolution cannot prove that the physical KIZ composition was repaired.
async function validateFbsStockAudit(db, task, sessionId, userId) {
    const stop = (message) => { throw new common_1.ConflictException({ code: 'FBS_STOCK_AUDIT_PENDING', message }); };
    const session = await db.inventorySession.findUnique({ where: { id: sessionId }, include: {
            boxes: { include: { lines: true } },
        } });
    const activePick = task.status === 'IN_PROGRESS';
    if (!session || session.type !== 'BOX_CHECK' || session.clientId !== task.clientId || session.createdByUserId !== userId ||
        !session.comment?.includes(`${exports.FBS_KIZ_AUDIT_MARKER} ${task.id};`) || session.boxes.length !== 1 ||
        (activePick && session.boxes[0].boxId !== task.boxId))
        stop('Проверка не относится к этому заказу и коробу. Откройте обязательную проверку заново.');
    const audit = session.boxes[0];
    if (session.status !== 'COMPLETED' || !['MATCHED', 'RESOLVED'].includes(audit.status) ||
        audit.lines.some(line => line.difference !== 0 && line.decision === 'PENDING')) {
        stop('Сначала завершите пересчёт и разбор расхождений короба.');
    }
    const [box, request] = await Promise.all([
        db.box.findUnique({ where: { id: audit.boxId } }),
        db.clientRequest.findUnique({ where: { id: task.requestId }, select: { warehouseId: true } }),
    ]);
    // FIX: administrator sessions may be unrestricted; the physical box must still match the request warehouse.
    if (!box || !request || box.clientId !== task.clientId || !box.warehouseId ||
        (session.warehouseId !== null && box.warehouseId !== session.warehouseId) || box.warehouseId !== request.warehouseId ||
        !['active', 'receiving'].includes(box.status))
        stop('Короб изменил филиал, клиента или статус. Нужен разбор администратора.');
    const [marks, balances, evidence] = await Promise.all([
        db.productMark.findMany({ where: { boxId: audit.boxId } }),
        db.stockBalance.findMany({ where: { boxId: audit.boxId } }),
        db.auditLog.findMany({ where: { action: 'INVENTORY_KIZ_SCAN', entity: 'InventoryAuditBox', entityId: audit.id,
                createdAt: { gte: audit.startedAt } } }),
    ]);
    const skuIds = [...new Set([...audit.lines.map(line => line.skuId), ...marks.map(mark => mark.skuId), ...balances.map(row => row.skuId)])];
    const skus = await db.sku.findMany({ where: { id: { in: skuIds } }, select: { id: true, needsChestnyZnak: true, isUnmarked: true } });
    if (skus.length !== skuIds.length)
        stop('Не все товары короба найдены. Нужен разбор администратора.');
    // FIX: administrator-confirmed historical packing remains in its shipment ledger,
    // but is outside the physical contents that the worker has just counted.
    const confirmation = (0, exports.fbsKizAuditEnabled)() ? await db.auditLog.findUnique({ where: { id: (0, confirmed_kiz_composition_1.confirmedKizCompositionId)(audit.id, audit.startedAt) } }) : null;
    const confirmed = confirmation?.payload;
    const approved = confirmation?.action === 'INVENTORY_KIZ_COMPOSITION_CONFIRMED' && confirmed?.auditBoxId === audit.id &&
        confirmed.boxId === audit.boxId && confirmed.clientId === task.clientId && confirmed.warehouseId === box.warehouseId &&
        confirmed.roundStartedAt === audit.startedAt.toISOString();
    const isHistorical = (row) => approved && ['PACKING', 'SHIPPING'].includes(row.status) &&
        confirmed?.nonPhysicalBalances?.some(previous => previous.id === row.id && previous.skuId === row.skuId &&
            previous.status === row.status && row.quantity <= previous.quantity);
    if (balances.some(row => row.clientId !== task.clientId || row.warehouseId !== box.warehouseId ||
        row.quantity < 0 || (row.status !== 'AVAILABLE' && row.quantity !== 0 && !isHistorical(row)))) {
        stop('В коробе есть резерв, недоступный остаток или другая принадлежность. Нужен разбор администратора.');
    }
    for (const sku of skus) {
        const line = audit.lines.find(row => row.skuId === sku.id);
        const quantity = balances.filter(row => row.skuId === sku.id && row.status === 'AVAILABLE').reduce((n, row) => n + row.quantity, 0);
        if (quantity !== (line?.countedQuantity ?? 0))
            stop('Остаток после пересчёта не совпадает с фактом. Актуализируйте короб с администратором.');
        if (!sku.needsChestnyZnak || sku.isUnmarked)
            continue;
        const scans = evidence.map(row => row.payload).filter(row => row?.skuId === sku.id && row.roundStartedAt === audit.startedAt.toISOString() && row.clientId === task.clientId &&
            row.boxId === audit.boxId && row.sessionId === sessionId && typeof row.kiz === 'string');
        const scanned = new Set(scans.map(row => identity(row.kiz)));
        const registered = marks.filter(row => row.skuId === sku.id);
        // Missing KIZs are allowed only for the existing quantity-only imported-stock gap.
        // An absent old KIZ is never retired or overwritten by this gate.
        if (scanned.has('') || scanned.size !== quantity || registered.some(row => row.clientId !== task.clientId ||
            row.status !== 'AVAILABLE' || !scanned.has(identity(row.value))) ||
            new Set(registered.map(row => identity(row.value))).size !== registered.length) {
            stop('Количество проверено, но состав КИЗ не подтверждён. Администратору нужно разобрать привязки КИЗ; сборка остаётся на проверке.');
        }
    }
    // FIX: an already picked unit is outside the storage box. Never ask to count it back into that box.
    // A cancellation/return is handled only by the separate scanned return-receipt workflow.
    if (activePick && task.wbMetaStatus === 'ACCEPTED' && task.kiz) {
        const movements = await db.stockMovement.findMany({ where: {
                idempotencyKey: { startsWith: `fbs-sticker-pick:${task.id}:` },
                OR: [{ status: 'PACKING' }, { type: 'RETURN', status: 'SHIPPING', quantity: { lt: 0 } }],
            }, select: { quantity: true } });
        const picked = movements.reduce((n, row) => n + row.quantity, 0) >= Math.max(1, task.itemCount);
        const mark = await db.productMark.findFirst({ where: { clientId: task.clientId, skuId: task.skuId,
                ...await (0, kiz_physical_identity_1.physicalKizLookup)(db, task.kiz, false), status: picked ? 'PACKING' : 'AVAILABLE', ...(picked ? {} : { boxId: audit.boxId }) } });
        if (!mark)
            stop('Не подтверждён остаток для принятого WB КИЗ. Привязка WB сохранена; нужен разбор администратора.');
    }
    return { ready: true, taskId: task.id, sessionId, boxCode: audit.boxCode };
}
