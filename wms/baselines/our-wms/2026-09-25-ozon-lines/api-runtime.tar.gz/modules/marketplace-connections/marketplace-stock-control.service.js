"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketplaceStockControlService = void 0;
exports.stockControlEnabled = stockControlEnabled;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const wb_stock_reserve_1 = require("./wb-stock-reserve");
const RESERVE_PREFIX = 'marketplace.wbReserve.client.';
const PREFIX = 'marketplace.stockControl.client.';
// FIX: an absent setting preserves existing clients; an invalid stored value fails closed.
function stockControlEnabled(setting) {
    return setting === null || setting.value === true;
}
let MarketplaceStockControlService = class MarketplaceStockControlService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    async reserve(clientId) {
        return (await this.reserveSettings(clientId)).reserve;
    }
    // FIX: value and optimistic-lock version come from the same database read.
    async reserveSettings(clientId) {
        if (!(0, wb_stock_reserve_1.fineStockSettingsEnabled)())
            return { reserve: { ...wb_stock_reserve_1.NO_WB_RESERVE }, reserveUpdatedAt: null };
        const setting = await this.prisma.systemSetting.findUnique({ where: { key: RESERVE_PREFIX + clientId } });
        return { reserve: setting ? (0, wb_stock_reserve_1.parseWbStockReserve)(setting.value) : { ...wb_stock_reserve_1.NO_WB_RESERVE }, reserveUpdatedAt: setting?.updatedAt.toISOString() ?? null };
    }
    async updateReserve(clientId, body, user) {
        this.requireReserveEditor(user, clientId);
        this.scopes.requireClientAccess(user, clientId, 'write');
        if (!(0, wb_stock_reserve_1.fineStockSettingsEnabled)())
            throw new common_1.ForbiddenException('Тонкие настройки WB не включены.');
        let value;
        try {
            value = (0, wb_stock_reserve_1.parseWbStockReserve)(body.reserve);
        }
        catch (error) {
            throw new common_1.BadRequestException(error.message);
        }
        if (body.expectedUpdatedAt !== null && typeof body.expectedUpdatedAt !== 'string')
            throw new common_1.BadRequestException('Передайте версию настройки.');
        const key = RESERVE_PREFIX + clientId;
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${key}))`;
            if (!await tx.client.findUnique({ where: { id: clientId }, select: { id: true } }))
                throw new common_1.NotFoundException('Клиент не найден.');
            const before = await tx.systemSetting.findUnique({ where: { key } });
            if ((before?.updatedAt.toISOString() ?? null) !== body.expectedUpdatedAt)
                throw new common_1.ConflictException('Резерв уже изменён. Обновите список.');
            const saved = await tx.systemSetting.upsert({ where: { key }, create: { key, value, updatedByUserId: user.id }, update: { value, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'WB_STOCK_RESERVE_UPDATED', entity: 'Client', entityId: clientId, payload: { before: before?.value ?? wb_stock_reserve_1.NO_WB_RESERVE, after: value } } });
            return { reserve: value, reserveUpdatedAt: saved.updatedAt.toISOString() };
        });
    }
    async skuRules(clientId) {
        const prefix = 'marketplace.wbSkuRule.' + clientId + '.';
        const result = new Map();
        if (!(0, wb_stock_reserve_1.fineStockSettingsEnabled)())
            return result;
        const settings = await this.prisma.systemSetting.findMany({ where: { key: { startsWith: prefix } } });
        for (const row of settings) {
            const value = row.value;
            if (!value || typeof value.blocked !== 'boolean')
                throw new common_1.BadRequestException('Повреждена настройка исключения WB.');
            result.set(row.key.slice(prefix.length), { reserve: value.reserve == null ? null : (0, wb_stock_reserve_1.parseWbStockReserve)(value.reserve), blocked: value.blocked, updatedAt: row.updatedAt.toISOString() });
        }
        return result;
    }
    async analysisSettings(clientId) {
        if (!(0, wb_stock_reserve_1.fineStockSettingsEnabled)())
            return { maxShareChange: 10, updatedAt: null };
        const row = await this.prisma.systemSetting.findUnique({ where: { key: 'marketplace.wbAnalysis.' + clientId } });
        const maxShareChange = row ? row.value.maxShareChange : 10;
        if (!Number.isInteger(maxShareChange) || maxShareChange < 0 || maxShareChange > 100)
            throw new common_1.BadRequestException('Некорректный шаг рекомендации WB.');
        return { maxShareChange, updatedAt: row?.updatedAt.toISOString() ?? null };
    }
    async updateFineRule(clientId, skuId, body, user) {
        if (skuId)
            this.requireReserveEditor(user, clientId);
        else
            this.requireAdmin(user);
        this.scopes.requireClientAccess(user, clientId, 'write');
        if (!(0, wb_stock_reserve_1.fineStockSettingsEnabled)())
            throw new common_1.ForbiddenException('Тонкие настройки WB не включены.');
        if (body.expectedUpdatedAt !== null && typeof body.expectedUpdatedAt !== 'string')
            throw new common_1.BadRequestException('Передайте версию настройки.');
        let value;
        if (skuId) {
            if (typeof body.blocked !== 'boolean' || body.reserve === undefined)
                throw new common_1.BadRequestException('Передайте запрет публикации и резерв (null — наследовать).');
            let reserve;
            try {
                reserve = body.reserve === null ? null : (0, wb_stock_reserve_1.parseWbStockReserve)(body.reserve);
            }
            catch (e) {
                throw new common_1.BadRequestException(e.message);
            }
            if (!await this.prisma.sku.findFirst({ where: { id: skuId, clientId, marketplace: 'WILDBERRIES' }, select: { id: true } }))
                throw new common_1.NotFoundException('Товар WB этого клиента не найден.');
            value = { reserve, blocked: body.blocked };
        }
        else {
            if (typeof body.maxShareChange !== 'number' || !Number.isInteger(body.maxShareChange) || body.maxShareChange < 0 || body.maxShareChange > 100)
                throw new common_1.BadRequestException('Шаг рекомендации: от 0 до 100 процентных пунктов.');
            value = { maxShareChange: body.maxShareChange };
        }
        const key = skuId ? `marketplace.wbSkuRule.${clientId}.${skuId}` : 'marketplace.wbAnalysis.' + clientId;
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${key}))`;
            if (!await tx.client.findUnique({ where: { id: clientId }, select: { id: true } }))
                throw new common_1.NotFoundException('Клиент не найден.');
            const before = await tx.systemSetting.findUnique({ where: { key } });
            if ((before?.updatedAt.toISOString() ?? null) !== body.expectedUpdatedAt)
                throw new common_1.ConflictException('Настройка уже изменена. Обновите раздел.');
            const saved = await tx.systemSetting.upsert({ where: { key }, create: { key, value, updatedByUserId: user.id }, update: { value, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: skuId ? 'WB_SKU_RULE_UPDATED' : 'WB_ANALYSIS_RULE_UPDATED', entity: skuId ? 'Sku' : 'Client', entityId: skuId ?? clientId, payload: { clientId, before: before?.value ?? null, after: value } } });
            return { ...value, updatedAt: saved.updatedAt.toISOString() };
        });
    }
    async isEnabled(clientId) {
        if (!clientId)
            throw new common_1.BadRequestException('Не указан клиент для отправки остатков.');
        return stockControlEnabled(await this.prisma.systemSetting.findUnique({ where: { key: PREFIX + clientId } }));
    }
    // FIX: read the shared database before every outbound batch, without a process-local cache.
    async assertEnabled(clientId) {
        if (!await this.isEnabled(clientId)) {
            throw new common_1.ForbiddenException('Контроль остатков на МП через WMS отключён для клиента. Остатками управляет отдел продаж. Включить контроль можно в разделе «Администрирование → Контроль остатков на МП».');
        }
    }
    // FIX: client managers need explicit writable assignment even with mixed administrative roles.
    requireReserveEditor(user, clientId) {
        if (user.roleCodes.includes('CLIENT')) {
            if (!user.isDemo && (0, wb_stock_reserve_1.fineStockSettingsEnabled)() && user.permissionCodes.includes('stock:read') && user.clientIds.includes(clientId) && user.writableClientIds.includes(clientId))
                return;
            throw new common_1.ForbiddenException('Нет права изменять резерв этого клиента.');
        }
        this.requireAdmin(user);
    }
    requireAdmin(user) {
        if (user.isDemo || user.roleCodes.includes('CLIENT') || !user.permissionCodes.includes('system:admin')) {
            throw new common_1.ForbiddenException('Контроль остатков на МП доступен только администратору.');
        }
    }
    async list(user) {
        this.requireAdmin(user);
        const clients = await this.prisma.client.findMany({
            where: { id: this.scopes.resolveClientFilter(user) },
            select: { id: true, code: true, name: true },
            orderBy: { code: 'asc' },
        });
        const settings = await this.prisma.systemSetting.findMany({
            where: { key: { in: clients.map((client) => PREFIX + client.id) } },
            include: { updatedBy: { select: { name: true } } },
        });
        const byKey = new Map(settings.map((setting) => [setting.key, setting]));
        const reserves = (0, wb_stock_reserve_1.fineStockSettingsEnabled)() ? await this.prisma.systemSetting.findMany({ where: { key: { in: clients.map(client => RESERVE_PREFIX + client.id) } } }) : [];
        const reservesByKey = new Map(reserves.map(setting => [setting.key, setting]));
        return clients.map((client) => {
            const setting = byKey.get(PREFIX + client.id) ?? null;
            const reserveSetting = reservesByKey.get(RESERVE_PREFIX + client.id);
            return { ...client, fineSettingsEnabled: (0, wb_stock_reserve_1.fineStockSettingsEnabled)(), reserve: reserveSetting ? (0, wb_stock_reserve_1.parseWbStockReserve)(reserveSetting.value) : wb_stock_reserve_1.NO_WB_RESERVE, reserveUpdatedAt: reserveSetting?.updatedAt.toISOString() ?? null, enabled: stockControlEnabled(setting), updatedAt: setting?.updatedAt ?? null, updatedBy: setting?.updatedBy?.name ?? null };
        });
    }
    async update(clientId, body, user) {
        this.requireAdmin(user);
        this.scopes.requireClientAccess(user, clientId, 'write');
        if (typeof body.enabled !== 'boolean' || typeof body.expectedEnabled !== 'boolean') {
            throw new common_1.BadRequestException('Передайте enabled и expectedEnabled как true или false.');
        }
        const enabled = body.enabled;
        const key = PREFIX + clientId;
        // FIX: serialize administrator changes and persist the setting together with its audit record.
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${key}))`;
            const client = await tx.client.findUnique({ where: { id: clientId }, select: { id: true, code: true, name: true } });
            if (!client)
                throw new common_1.NotFoundException('Клиент не найден.');
            const previous = await tx.systemSetting.findUnique({ where: { key } });
            const before = stockControlEnabled(previous);
            if (before !== body.expectedEnabled)
                throw new common_1.ConflictException('Настройку уже изменил другой администратор. Обновите список.');
            const setting = await tx.systemSetting.upsert({
                where: { key },
                create: { key, value: enabled, updatedByUserId: user.id },
                update: { value: enabled, updatedByUserId: user.id },
            });
            await tx.auditLog.create({ data: {
                    userId: user.id, action: 'administration.marketplace-stock-control.update', entity: 'Client', entityId: clientId,
                    payload: { clientCode: client.code, clientName: client.name, before, after: enabled, scope: 'ALL_BRANCHES_AND_MARKETPLACE_ACCOUNTS' },
                } });
            return { ...client, enabled, updatedAt: setting.updatedAt, updatedBy: user.name };
        });
    }
};
exports.MarketplaceStockControlService = MarketplaceStockControlService;
exports.MarketplaceStockControlService = MarketplaceStockControlService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService])
], MarketplaceStockControlService);
