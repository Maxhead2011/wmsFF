"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountFbsOrderByWbDto = void 0;
exports.accountFbsOrderByWb = accountFbsOrderByWb;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const class_validator_1 = require("class-validator");
const fbs_wb_accounting_1 = require("../../common/fbs-wb-accounting");
const fbs_wb_kiz_shipment_1 = require("./fbs-wb-kiz-shipment");
class AccountFbsOrderByWbDto {
    comment;
}
exports.AccountFbsOrderByWbDto = AccountFbsOrderByWbDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(3, 1000),
    __metadata("design:type", String)
], AccountFbsOrderByWbDto.prototype, "comment", void 0);
// FIX: no-pair accounting remains separate; a linked pair records an exact warehouse shipment.
async function accountFbsOrderByWb(prisma, scopes, requestId, taskId, dto, user, readStatus, beforeShipment = async () => { }) {
    if (!(0, fbs_wb_accounting_1.fbsWbAccountingEnabled)())
        throw new common_1.ForbiddenException('Учёт по WB не включён для этой WMS.');
    if (user.isDemo || user.roleCodes?.includes('CLIENT') ||
        !user.permissionCodes?.some(code => ['system:admin', 'client-requests:write'].includes(code))) {
        throw new common_1.ForbiddenException('Решение доступно только сотруднику с правом изменения заявок.');
    }
    const comment = dto.comment?.trim();
    if (!comment || comment.length < 3 || comment.length > 1000)
        throw new common_1.BadRequestException('Укажите комментарий менеджера (3–1000 символов).');
    const task = await prisma.fbsTsdAssembly.findUnique({ where: { id: taskId } });
    if (!task || task.requestId !== requestId || task.marketplace !== 'WILDBERRIES')
        throw new common_1.NotFoundException('Заказ WB в этой заявке не найден.');
    scopes.requireClientAccess(user, task.clientId, 'write');
    // FIX: PACKED is eligible only for an exact-pair shipment (or its idempotent replay).
    const shipPair = (0, fbs_wb_accounting_1.isFbsWbKizShipmentCandidate)(task);
    const packedShipment = shipPair || (task.status === fbs_wb_accounting_1.FBS_WB_ACCOUNTED && task.itemCount === 1 && Boolean(task.kiz?.trim() && task.barcode?.trim()));
    const checkRequest = (request) => {
        if (!request?.warehouseId || request.clientId !== task.clientId || request.warehouseId !== user.activeWarehouseId ||
            (!user.permissionCodes.includes('system:admin') && !user.writableWarehouseIds?.includes(request.warehouseId))) {
            throw new common_1.ForbiddenException('Заявка находится в недоступном филиале.');
        }
        if (!['SUBMITTED', 'IN_REVIEW', 'APPROVED', 'IN_WORK', ...(packedShipment ? ['PACKED'] : [])].includes(request.status))
            throw new common_1.ConflictException('Заявка уже закрыта или упакована.');
    };
    const linkWhere = { marketplace_connectionId_orderId: { marketplace: task.marketplace, connectionId: task.connectionId, orderId: task.orderId } };
    const [request, link] = await Promise.all([
        prisma.clientRequest.findUnique({ where: { id: requestId }, select: { clientId: true, warehouseId: true, status: true } }),
        prisma.fbsOrderRequestLink.findUnique({ where: linkWhere }),
    ]);
    checkRequest(request);
    if (shipPair && !user.permissionCodes.some(code => ['stock:write', 'system:admin'].includes(code))) {
        throw new common_1.ForbiddenException('Списание по КИЗ требует права на складские операции.');
    }
    const originalPair = { kiz: task.kiz, barcode: task.barcode, boxId: task.boxId, updatedAt: task.updatedAt.getTime() };
    const response = { clientId: task.clientId, accounted: true, assemblyId: taskId, orderId: task.orderId, requestId,
        shipped: Boolean(task.kiz && task.barcode),
        message: task.kiz && task.barcode ? `Заказ №${task.orderId} отгружен со склада по WB. Пара КИЗ–ШК сохранена в истории.` :
            `Заказ №${task.orderId} учтён по статусу WB. Физическая сборка и списание не создавались.` };
    if (link?.requestId === requestId && link.clientId === task.clientId && link.syncStatus === fbs_wb_accounting_1.FBS_WB_ACCOUNTED && task.status === fbs_wb_accounting_1.FBS_WB_ACCOUNTED)
        return response;
    if (!link || link.requestId !== requestId || link.clientId !== task.clientId ||
        !['ACTIVE', ...(shipPair ? ['RETURN_REQUIRED'] : [])].includes(link.syncStatus) ||
        !(shipPair || (0, fbs_wb_accounting_1.isFbsWbAccountingUntouched)(task))) {
        throw new common_1.ConflictException('Заказ изменён или содержит физические сканы. Требуется отдельное решение по товару.');
    }
    if (shipPair)
        await beforeShipment();
    const wb = await readStatus(task);
    if (!(0, fbs_wb_accounting_1.isFbsWbAccountingStatus)(wb) || wb.isTransferable !== false)
        throw new common_1.ConflictException('WB не подтвердил обработку заказа и запрет переноса. Обновите данные.');
    const checkedAt = new Date();
    await prisma.$transaction(async (tx) => {
        // Serialize against packing/closing this request so the same unit cannot be deducted twice.
        if (shipPair)
            await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id = ${requestId} FOR UPDATE`;
        const [fresh, freshLink, freshRequest] = await Promise.all([
            tx.fbsTsdAssembly.findUnique({ where: { id: taskId } }),
            tx.fbsOrderRequestLink.findUnique({ where: linkWhere }),
            tx.clientRequest.findUnique({ where: { id: requestId }, select: { clientId: true, warehouseId: true, status: true } }),
        ]);
        checkRequest(freshRequest);
        if (fresh?.requestId === requestId && freshLink?.requestId === requestId && fresh.status === fbs_wb_accounting_1.FBS_WB_ACCOUNTED && freshLink.syncStatus === fbs_wb_accounting_1.FBS_WB_ACCOUNTED)
            return;
        if (!fresh || !freshLink || fresh.requestId !== requestId || fresh.clientId !== task.clientId || freshLink.requestId !== requestId ||
            fresh.updatedAt.getTime() !== originalPair.updatedAt || freshLink.updatedAt.getTime() !== link.updatedAt.getTime() ||
            freshLink.syncStatus !== link.syncStatus || fresh.kiz !== originalPair.kiz || fresh.barcode !== originalPair.barcode || fresh.boxId !== originalPair.boxId ||
            !(shipPair ? (0, fbs_wb_accounting_1.isFbsWbKizShipmentCandidate)(fresh) : (0, fbs_wb_accounting_1.isFbsWbAccountingUntouched)(fresh)))
            throw new common_1.ConflictException('Заказ изменился во время проверки WB. Повторите проверку.');
        const shipment = shipPair ? await (0, fbs_wb_kiz_shipment_1.shipWbKiz)(tx, fresh, freshRequest.warehouseId, checkedAt) : null;
        const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: taskId, updatedAt: fresh.updatedAt, requestId, status: fresh.status }, data: {
                status: fbs_wb_accounting_1.FBS_WB_ACCOUNTED, reservedBoxId: null, reservedBoxCode: null, reservedAt: null,
                errorMessage: null,
                ...(shipment ? { sourceBoxPending: false, boxId: shipment.sourceBoxId, boxCode: shipment.sourceBoxCode } : {}),
            } });
        const linked = await tx.fbsOrderRequestLink.updateMany({ where: { id: freshLink.id, updatedAt: freshLink.updatedAt, requestId, syncStatus: freshLink.syncStatus }, data: {
                syncStatus: fbs_wb_accounting_1.FBS_WB_ACCOUNTED, syncIssue: null, lastSupplierStatus: wb.supplierStatus, lastWbStatus: wb.wbStatus, lastSeenAt: checkedAt,
            } });
        if (changed.count !== 1 || linked.count !== 1)
            throw new common_1.ConflictException('Параллельное изменение заказа. Повторите проверку.');
        await tx.auditLog.create({ data: { userId: user.id, action: fbs_wb_accounting_1.FBS_WB_ACCOUNTED_ACTION, entity: 'ClientRequest', entityId: requestId,
                payload: { assemblyId: taskId, orderId: task.orderId, connectionId: task.connectionId, clientId: task.clientId,
                    supplyId: task.supplyId, previousStatus: task.status, confirmedByName: user.name, checkedAt: checkedAt.toISOString(),
                    supplierStatus: wb.supplierStatus, wbStatus: wb.wbStatus, isTransferable: false, stockMutationPerformed: Boolean(shipment), comment,
                    ...(shipment ? { ...shipment, kiz: fresh.kiz, barcode: fresh.barcode } : {}) } } });
        await tx.clientRequestEvent.create({ data: { requestId, clientId: task.clientId, eventType: 'COMMENT', title: 'Заказ учтён по статусу WB',
                body: `№${task.orderId}: WB ${wb.supplierStatus}/${wb.wbStatus}, перенос недоступен. ${shipment ? `Отгрузка КИЗ ${fresh.kiz}, ШК ${fresh.barcode}; источник: ${shipment.sourceBoxCode}.` : 'Физическая сборка и списание не создавались.'} ${comment}`, createdByUserId: user.id } });
    }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
    return response;
}
