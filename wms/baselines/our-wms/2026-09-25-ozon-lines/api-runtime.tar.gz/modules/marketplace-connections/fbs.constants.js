"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FBS_UNLIMITED_CARGO_PLACE_CAPACITY = exports.DEFAULT_FBS_ITEMS_PER_CARGO_PLACE = void 0;
// The billing calculator still uses the client's average physical box size.
exports.DEFAULT_FBS_ITEMS_PER_CARGO_PLACE = 14;
// Operational FBS packing is unlimited. The large persisted value keeps the
// existing integer fields and cargo-place calculations backward compatible.
exports.FBS_UNLIMITED_CARGO_PLACE_CAPACITY = 2_000_000_000;
