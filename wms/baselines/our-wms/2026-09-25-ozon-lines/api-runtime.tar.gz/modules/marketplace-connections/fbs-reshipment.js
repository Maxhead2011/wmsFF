"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reshipmentHash = void 0;
exports.assertReshipmentEnabled = assertReshipmentEnabled;
exports.reshipmentCycle = reshipmentCycle;
exports.reshipmentFingerprint = reshipmentFingerprint;
exports.reshipmentVisibility = reshipmentVisibility;
exports.reshipmentEligibility = reshipmentEligibility;
exports.supplyRecoveryAction = supplyRecoveryAction;
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const reshipmentHash = (value) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(value)).digest('hex');
exports.reshipmentHash = reshipmentHash;
// FIX: deployment opt-in keeps the sold WMS unchanged.
function assertReshipmentEnabled() {
    if (process.env.WMS_FBS_RESHIPMENT_ENABLED !== 'true')
        throw new common_1.ForbiddenException('Повторная отгрузка не включена для этой WMS.');
}
function reshipmentCycle(task) {
    // FIX: WB/sync can change supplyId while this cycle is still in flight.
    return (0, exports.reshipmentHash)([task.id, task.requestId]);
}
function reshipmentFingerprint(clientId, warehouseId, mode, orders) {
    return (0, exports.reshipmentHash)([clientId, warehouseId, mode,
        orders.map(row => JSON.stringify([row.connectionId, row.id, row.cycle])).sort()]);
}
// FIX: discovery history is not a work list. WB complete means "in delivery", not received.
// This presentation classifier deliberately does not grant permission to create/resume.
function reshipmentVisibility(wb, directListed, returnedEvidence) {
    if (!wb)
        return 'UNVERIFIED';
    if (['cancel', 'cancel_carrier'].includes(wb.supplierStatus) ||
        ['sold', 'canceled', 'canceled_by_client', 'declined_by_client', 'defect', 'canceled_by_carrier'].includes(wb.wbStatus))
        return 'HIDDEN';
    if (!['new', 'confirm', 'complete'].includes(wb.supplierStatus) ||
        !['waiting', 'sorted', 'ready_for_pickup', 'postponed_delivery', 'accepted_by_carrier', 'sent_to_carrier'].includes(wb.wbStatus))
        return 'UNVERIFIED';
    if (wb.wbStatus !== 'waiting')
        return 'HIDDEN';
    if (wb.supplierStatus === 'complete' && directListed)
        return 'ACTIONABLE';
    if (wb.supplierStatus === 'confirm' && (directListed || returnedEvidence))
        return 'ACTIONABLE';
    return 'HIDDEN';
}
function reshipmentEligibility(task, link, wb, directCandidate, mode = 'SAME_ITEM', returnedEvidence = false) {
    if (!wb || wb.wbStatus !== 'waiting' || !['complete', 'confirm'].includes(wb.supplierStatus)) {
        return 'WB не подтверждает заказ для повторной сборки: отменён, получен или статус недоступен.';
    }
    const returned = wb.supplierStatus === 'confirm' && (returnedEvidence || (link.lastSupplierStatus === 'complete' &&
        link.lastCategory === 'shipped' && !!link.lastSupplyId && link.lastSupplyId === task.supplyId));
    if (!(directCandidate && wb.supplierStatus === 'complete') && !returned) {
        return 'Нет подтверждения WB о повторной отгрузке или сохранённого перехода из доставки в сборку.';
    }
    if (['REMOVED', 'MOVING', 'RETURN_REQUIRED'].includes(link.syncStatus))
        return 'Заказ ожидает возврата или изменения привязки.';
    if (task.itemCount !== 1)
        return 'Поддерживаются только поштучные заказы WB.';
    if (task.cargoPackingId)
        return 'Заказ находится в грузокоробе: сначала требуется явно распаковать его.';
    // FIX: unpicked orders can receive a NEW_ITEM task, but partial physical scans
    // are not silently discarded. Such tasks do not create completed-attempt history.
    if (mode === 'NEW_ITEM' && ['WAITING_STOCK', 'RESERVED', 'RELEASED'].includes(task.status) &&
        !task.completedAt && !task.barcode && !task.kiz && !task.boxId && !task.sourceBarcode && !task.startedAt)
        return null;
    if (task.status !== 'COMPLETED' || !task.completedAt || !task.barcode || (task.requiresKiz && !task.kiz)) {
        return 'Предыдущая физическая сборка не завершена или не подтверждена сканами.';
    }
    return null;
}
// FIX: after a timeout an empty name search is NOT evidence that POST failed.
function supplyRecoveryAction(phase, supply) {
    if (supply?.done)
        throw new common_1.ConflictException('Поставка уже закрыта. Требуется сверка повторной отгрузки.');
    if (supply)
        return 'USE_EXISTING';
    return phase === 'PLANNED' ? 'CREATE_ONCE' : 'RECONCILE_ONLY';
}
