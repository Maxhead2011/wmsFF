"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WB_HEALTH_HOUR = void 0;
exports.evaluateWbSyncProof = evaluateWbSyncProof;
exports.nextWbHealthState = nextWbHealthState;
function evaluateWbSyncProof(rows, startedAt) {
    const fresh = rows.filter(row => row.updatedAt >= startedAt);
    const runs = [...new Set(fresh.map(row => row.runId))];
    const confirmed = fresh.filter(row => row.status === 'CONFIRMED' && row.observedAmount === row.calculatedAmount).length;
    const mismatch = fresh.filter(row => row.status === 'MISMATCH' || row.status === 'CONFIRMED' && row.observedAmount !== row.calculatedAmount).length;
    const unknown = fresh.filter(row => row.error?.includes('WB не вернул')).length;
    const unconfirmed = fresh.length - confirmed - mismatch;
    return { runIds: runs, confirmed, mismatch, unknown, unconfirmed,
        success: fresh.length > 0 && fresh.length === rows.length && runs.length === 1 && confirmed === fresh.length };
}
exports.WB_HEALTH_HOUR = 3_600_000;
// FIX: repetitions update one incident; recovery restores the hourly cadence.
function nextWbHealthState(previous, problem, now) {
    return { incidentAt: problem ? previous.incidentAt ?? now.toISOString() : null,
        failures: problem ? previous.failures + 1 : 0,
        nextCheckAt: new Date(now.getTime() + (problem ? 60_000 : exports.WB_HEALTH_HOUR)).toISOString() };
}
