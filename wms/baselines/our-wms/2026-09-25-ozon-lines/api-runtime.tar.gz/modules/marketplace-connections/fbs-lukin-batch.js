"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LUKIN_FBS_BATCH_SETTING_KEY = exports.LUKIN_FBS_BATCH_CLIENT_ID = void 0;
exports.lukinBatchApplies = lukinBatchApplies;
exports.selectLukinFbsBatch = selectLukinFbsBatch;
exports.savedLukinFbsBatchIds = savedLukinFbsBatchIds;
// FIX: only the verified Moscow Lukin client uses a fixed, oldest-first TSD queue.
exports.LUKIN_FBS_BATCH_CLIENT_ID = 'c76b78f9-1b83-4e9b-bee3-bc28336ee1c9';
exports.LUKIN_FBS_BATCH_SETTING_KEY = 'tsd:fbs:lukin:batch:v1:' + exports.LUKIN_FBS_BATCH_CLIENT_ID;
// FIX: supervisors need the full queue; only ordinary pickers use the fixed window.
function lukinBatchApplies(roleCodes) {
    return !roleCodes?.some((role) => role === 'ADMIN' || role === 'OWNER');
}
function selectLukinFbsBatch(openRequests, savedIds) {
    const byId = new Map(openRequests.map((request) => [request.requestId, request]));
    const retained = [...new Set(savedIds)].filter((id) => byId.has(id));
    if (retained.length > 0) {
        return { requestIds: savedIds, visible: retained.map((id) => byId.get(id)), rotated: false };
    }
    const next = [...openRequests]
        .sort((left, right) => left.requestNumber - right.requestNumber || left.requestId.localeCompare(right.requestId))
        .slice(0, 5);
    return { requestIds: next.map((request) => request.requestId), visible: next, rotated: true };
}
function savedLukinFbsBatchIds(value) {
    if (!value || typeof value !== 'object' || !('requestIds' in value) || !Array.isArray(value.requestIds))
        return [];
    return value.requestIds.filter((id) => typeof id === 'string' && id.length > 0);
}
