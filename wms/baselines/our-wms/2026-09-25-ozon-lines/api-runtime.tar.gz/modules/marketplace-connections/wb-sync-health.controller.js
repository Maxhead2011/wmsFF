"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WbSyncHealthController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const wb_sync_health_service_1 = require("./wb-sync-health.service");
let WbSyncHealthController = class WbSyncHealthController {
    health;
    constructor(health) {
        this.health = health;
    }
    list(user) { return this.health.list(user); }
};
exports.WbSyncHealthController = WbSyncHealthController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], WbSyncHealthController.prototype, "list", null);
exports.WbSyncHealthController = WbSyncHealthController = __decorate([
    (0, common_1.Controller)('wb-sync-health'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:read'),
    __metadata("design:paramtypes", [wb_sync_health_service_1.WbSyncHealthService])
], WbSyncHealthController);
