"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuplicateStockGroupsController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const duplicate_stock_groups_service_1 = require("./duplicate-stock-groups.service");
let DuplicateStockGroupsController = class DuplicateStockGroupsController {
    groups;
    constructor(groups) {
        this.groups = groups;
    }
    capabilities() { return this.groups.capabilities(); }
    read(id, user) { return this.groups.read(id, user); }
    history(id, user) { return this.groups.history(id, user); }
    confirmation(id, body, user) { return this.groups.confirmation(id, body, user); }
    catalog(id, body, user) { return this.groups.catalog(id, body, user); }
    preview(id, body, user) { return this.groups.preview(id, body, user); }
    apply(id, body, user) { return this.groups.apply(id, body, user); }
    save(id, body, user) { return this.groups.save(id, body, user); }
};
exports.DuplicateStockGroupsController = DuplicateStockGroupsController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)(':clientId'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "read", null);
__decorate([
    (0, common_1.Get)(':clientId/history'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "history", null);
__decorate([
    (0, common_1.Post)(':clientId/confirmation'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "confirmation", null);
__decorate([
    (0, common_1.Post)(':clientId/catalog'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "catalog", null);
__decorate([
    (0, common_1.Post)(':clientId/preview'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(':clientId/apply'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "apply", null);
__decorate([
    (0, common_1.Put)(':clientId'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], DuplicateStockGroupsController.prototype, "save", null);
exports.DuplicateStockGroupsController = DuplicateStockGroupsController = __decorate([
    (0, common_1.Controller)('marketplace-connections/duplicate-groups'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:read', 'clients:write', 'client-requests:read', 'client-requests:write'),
    __metadata("design:paramtypes", [duplicate_stock_groups_service_1.DuplicateStockGroupsService])
], DuplicateStockGroupsController);
