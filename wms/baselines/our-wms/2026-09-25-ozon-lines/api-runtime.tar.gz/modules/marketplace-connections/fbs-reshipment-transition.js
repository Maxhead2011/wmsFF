"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordReshipmentTransition = recordReshipmentTransition;
const node_crypto_1 = require("node:crypto");
// FIX: normal synchronization saves a precise transition before replacing its
// last snapshot. Discovery stays read-only and never infers a return from confirm alone.
async function recordReshipmentTransition(db, link, order, task) {
    if (process.env.WMS_FBS_RESHIPMENT_ENABLED !== 'true' || !task || task.requestId !== link.requestId ||
        order.marketplace !== 'WILDBERRIES' || order.id !== link.orderId || order.connectionId !== link.connectionId ||
        link.syncStatus !== 'ACTIVE' || link.lastSupplierStatus !== 'complete' || link.lastCategory !== 'shipped' ||
        !link.lastSupplyId || !order.supplyId || order.supplierStatus !== 'confirm' || order.wbStatus !== 'waiting')
        return;
    const payload = { clientId: link.clientId, connectionId: link.connectionId, orderId: link.orderId,
        requestId: link.requestId, assemblyId: task.id, sourceSupplyId: link.lastSupplyId, targetSupplyId: order.supplyId,
        supplierStatusFrom: 'complete', supplierStatusTo: 'confirm', wbStatus: order.wbStatus };
    const id = `reship-transition:${(0, node_crypto_1.createHash)('sha256').update(JSON.stringify([link.id, payload])).digest('hex')}`;
    await db.auditLog.upsert({ where: { id }, create: { id, action: 'FBS_WB_RETURNED_TO_ASSEMBLY',
            entity: 'FbsOrderRequestLink', entityId: link.id, payload }, update: {} });
}
