"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.relabelConfirmation = relabelConfirmation;
const node_crypto_1 = require("node:crypto");
const norm = (value) => value.trim().toLowerCase();
function relabelConfirmation(clientId, group, pairs, mappings) {
    const unique = [...new Map(pairs.map(p => [norm(p.sourceArticle) + ':' + norm(p.targetArticle), p])).values()];
    const conflicts = unique.flatMap(pair => {
        const existing = mappings.filter(m => (norm(m.targetArticle) === norm(pair.targetArticle) && norm(m.sourceArticle) !== norm(pair.sourceArticle))
            || norm(m.targetArticle) === norm(pair.sourceArticle) || norm(m.sourceArticle) === norm(pair.targetArticle));
        return existing.length ? [{ ...pair, existing }] : [];
    });
    const snapshot = mappings.map(m => [norm(m.sourceArticle), norm(m.targetArticle)]).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
    const confirmationKey = conflicts.length ? (0, node_crypto_1.createHash)('sha256').update(JSON.stringify({ clientId, group, snapshot })).digest('hex') : null;
    return { confirmationKey, conflicts };
}
