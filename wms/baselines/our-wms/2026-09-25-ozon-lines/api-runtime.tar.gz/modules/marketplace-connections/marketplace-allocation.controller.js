"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketplaceAllocationController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const marketplace_allocation_service_1 = require("./marketplace-allocation.service");
// FIX: separate endpoints do not modify the legacy WB publication path.
let MarketplaceAllocationController = class MarketplaceAllocationController {
    allocation;
    constructor(allocation) {
        this.allocation = allocation;
    }
    capabilities() { return this.allocation.capabilities(); }
    read(clientId, user) { return this.allocation.read(clientId, user); }
    save(clientId, body, user) {
        return this.allocation.save(clientId, body, user);
    }
    preview(clientId, body, user) {
        return this.allocation.preview(clientId, body, user);
    }
    catalog(clientId, body, user) {
        return this.allocation.catalog(clientId, body, user);
    }
    binding(clientId, body, user) {
        return this.allocation.confirmBinding(clientId, body, user);
    }
};
exports.MarketplaceAllocationController = MarketplaceAllocationController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MarketplaceAllocationController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)(':clientId'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceAllocationController.prototype, "read", null);
__decorate([
    (0, common_1.Put)(':clientId'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceAllocationController.prototype, "save", null);
__decorate([
    (0, common_1.Post)(':clientId/preview'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceAllocationController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(':clientId/catalog'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceAllocationController.prototype, "catalog", null);
__decorate([
    (0, common_1.Put)(':clientId/binding'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceAllocationController.prototype, "binding", null);
exports.MarketplaceAllocationController = MarketplaceAllocationController = __decorate([
    (0, common_1.Controller)('marketplace-connections/allocation'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:read', 'clients:write', 'client-requests:read', 'client-requests:write'),
    __metadata("design:paramtypes", [marketplace_allocation_service_1.MarketplaceAllocationService])
], MarketplaceAllocationController);
