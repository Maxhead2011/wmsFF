"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DuplicateStockGroupsService = void 0;
const duplicate_apply_queue_1 = require("./duplicate-apply-queue");
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const marketplace_connections_service_1 = require("./marketplace-connections.service");
const duplicate_stock_plan_1 = require("./duplicate-stock-plan");
const duplicate_stock_groups_1 = require("./duplicate-stock-groups");
const marketplace_allocation_1 = require("./marketplace-allocation");
const duplicate_stock_runtime_1 = require("./duplicate-stock-runtime");
const duplicate_relabel_confirmation_1 = require("./duplicate-relabel-confirmation");
const selfServiceEnabled = () => process.env.WMS_DUPLICATE_STOCK_SELF_SERVICE_ENABLED === 'true';
const previewKey = (group, revision) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify({ group, revision })).digest('hex');
const prefix = 'marketplace.duplicates.groups.';
const select = { id: true, article: true, clientSku: true, internalSku: true, name: true, size: true, color: true, marketplaceProductId: true,
    barcodes: { select: { value: true }, orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }] } };
const norm = (s) => s?.trim().toLowerCase() ?? '';
let DuplicateStockGroupsService = class DuplicateStockGroupsService {
    prisma;
    scopes;
    marketplaces;
    applyQueue;
    constructor(prisma, scopes, marketplaces) {
        this.prisma = prisma;
        this.scopes = scopes;
        this.marketplaces = marketplaces;
        this.applyQueue = new duplicate_apply_queue_1.DuplicateApplyQueue(prisma, (id, body, user, key) => this.applyNow(id, body, user, key));
    }
    onModuleInit() { this.applyQueue.start(); }
    onModuleDestroy() { this.applyQueue.stop(); }
    capabilities() { return { enabled: (0, duplicate_stock_groups_1.duplicateGroupsEnabled)(), publicationEnabled: (0, duplicate_stock_runtime_1.duplicatePublicationEnabled)(), selfServiceEnabled: selfServiceEnabled() }; }
    authorize(id, user, write = false) {
        if (!(0, duplicate_stock_groups_1.duplicateGroupsEnabled)() || user.isDemo)
            throw new common_1.ForbiddenException('Распределение между артикулами недоступно.');
        if (!id?.trim())
            throw new common_1.BadRequestException('Выберите клиента.');
        this.scopes.requireClientAccess(user, id, write && !user.roleCodes.includes('CLIENT') ? 'write' : 'read');
    }
    connections(clientId, db = this.prisma) {
        return db.clientMarketplaceConnection.findMany({ where: { clientId, isActive: true, marketplace: { in: ['WILDBERRIES', 'OZON'] } },
            select: { id: true, marketplace: true, accountName: true, isActive: true, fbsExecutionWarehouseId: true }, orderBy: { id: 'asc' } });
    }
    decode(value) {
        if (value === undefined)
            return [];
        const data = value;
        if (data?.version !== 1 || !Array.isArray(data.groups))
            throw new common_1.ConflictException('Формат групп требует проверки администратора.');
        try {
            return data.groups.map(duplicate_stock_groups_1.validateDuplicateGroup);
        }
        catch {
            throw new common_1.ConflictException('Сохранённые группы требуют проверки администратора.');
        }
    }
    async read(clientId, user) {
        this.authorize(clientId, user);
        const [setting, connections, mappings, client] = await Promise.all([
            this.prisma.systemSetting.findUnique({ where: { key: prefix + clientId } }), this.connections(clientId),
            this.prisma.clientArticleMapping.findMany({ where: { clientId }, select: { id: true, sourceArticle: true, targetArticle: true } }),
            this.prisma.client.findUnique({ where: { id: clientId }, select: { relabelingEnabled: true } }),
        ]);
        return { applyRequests: await this.applyQueue.list(clientId), groups: this.decode(setting?.value), revision: setting?.updatedAt.toISOString() ?? null, mappings,
            commonReserve: await (0, duplicate_stock_runtime_1.commonDuplicateReserve)(this.prisma, clientId), activeGroupIds: (await (0, duplicate_stock_runtime_1.activeDuplicateGroups)(this.prisma, clientId)).map(g => g.id),
            relabelingEnabled: Boolean(client?.relabelingEnabled), connections: connections.filter(c => c.marketplace === 'WILDBERRIES'), publicationEnabled: (0, duplicate_stock_runtime_1.duplicatePublicationEnabled)(), selfServiceEnabled: selfServiceEnabled() };
    }
    async catalog(clientId, body, user) {
        this.authorize(clientId, user);
        if (!body || (body.search !== undefined && typeof body.search !== 'string') || (body.page !== undefined && (!Number.isSafeInteger(body.page) || Number(body.page) < 1)))
            throw new common_1.BadRequestException('Некорректные параметры поиска.');
        if (body.ids !== undefined && (!Array.isArray(body.ids) || body.ids.length > 600 || body.ids.some(id => typeof id !== 'string')))
            throw new common_1.BadRequestException('Некорректный список карточек.');
        const search = String(body.search ?? '').trim().slice(0, 150), page = Number(body.page ?? 1);
        const where = { clientId, marketplace: 'WILDBERRIES', marketplaceProductId: { not: null }, isDraft: false,
            ...(body.ids ? { id: { in: body.ids } } : search ? { OR: [{ article: { contains: search, mode: 'insensitive' } },
                    { clientSku: { contains: search, mode: 'insensitive' } }, { internalSku: { contains: search, mode: 'insensitive' } },
                    { name: { contains: search, mode: 'insensitive' } }, { barcodes: { some: { value: { contains: search } } } }] } : {}) };
        const rows = await this.prisma.sku.findMany({ where, select, orderBy: [{ article: 'asc' }, { size: 'asc' }, { id: 'asc' }],
            skip: body.ids ? 0 : (page - 1) * 50, take: body.ids ? 600 : 51 });
        return { rows: body.ids ? rows : rows.slice(0, 50), page, hasMore: !body.ids && rows.length > 50 };
    }
    async validate(clientId, raw, user, db = this.prisma, allowNewMappings = false, confirmationKey, reviewOnly = false) {
        let group;
        try {
            group = (0, duplicate_stock_groups_1.validateDuplicateGroup)(raw);
        }
        catch (e) {
            throw new common_1.BadRequestException(e.message);
        }
        const connections = await this.connections(clientId, db);
        const connection = connections.find(c => c.id === group.connectionId && c.marketplace === 'WILDBERRIES');
        if (!connection?.fbsExecutionWarehouseId)
            throw new common_1.BadRequestException('Выберите активный кабинет WB с настроенным складом исполнения.');
        const warehouseId = connection.fbsExecutionWarehouseId;
        if (!user.roleCodes.includes('CLIENT') && !user.permissionCodes.includes('system:admin')
            && (user.activeWarehouseId !== warehouseId || (user.warehouseIds && !user.warehouseIds.includes(warehouseId))))
            throw new common_1.ForbiddenException('Выберите доступный филиал исполнения кабинета.');
        const ids = (0, duplicate_stock_groups_1.duplicateGroupSkuIds)(group);
        const [skus, mappings, client] = await Promise.all([
            db.sku.findMany({ where: { clientId, id: { in: ids }, marketplace: 'WILDBERRIES', marketplaceProductId: { not: null }, isDraft: false }, select }),
            db.clientArticleMapping.findMany({ where: { clientId }, select: { sourceArticle: true, targetArticle: true } }),
            db.client.findUnique({ where: { id: clientId }, select: { relabelingEnabled: true } }),
        ]);
        if (!client?.relabelingEnabled)
            throw new common_1.BadRequestException('Сначала включите клиенту действующий механизм переклейки.');
        if (skus.length !== ids.length)
            throw new common_1.BadRequestException('Карточки должны принадлежать этому клиенту и быть доступны. Обновите выбор.');
        const byId = new Map(skus.map(s => [s.id, s]));
        const missingMappings = [];
        const pairs = [];
        for (const v of group.variants)
            for (const t of v.targets) {
                const source = byId.get(v.sourceSkuId), target = byId.get(t.targetId);
                if (!norm(source.size) || norm(source.size) !== norm(target.size))
                    throw new common_1.BadRequestException('Выберите одинаковые непустые размеры исходного и целевого товара.');
                if (!source.barcodes.length || !target.barcodes.length)
                    throw new common_1.BadRequestException('У обеих карточек должен быть ШК.');
                if (t.requiresRelabel)
                    pairs.push({ sourceArticle: source.article?.trim() || source.clientSku?.trim() || '', targetArticle: target.article?.trim() || target.clientSku?.trim() || '' });
                // FIX: share settings cannot create a parallel source mapping different from the picking workflow.
                if (t.requiresRelabel && !mappings.some(m => [target.article, target.clientSku].some(a => norm(a) === norm(m.targetArticle))
                    && ([source.article, source.clientSku, source.internalSku].some(a => norm(a) === norm(m.sourceArticle)) || norm(source.internalSku).startsWith(norm(m.sourceArticle) + '-')))) {
                    if (!allowNewMappings || !selfServiceEnabled())
                        throw new common_1.BadRequestException('Эта пара не настроена в меню «Переклейка». Сначала добавьте там соответствие артикулов.');
                    const sourceArticle = source.article?.trim() || source.clientSku?.trim(), targetArticle = target.article?.trim() || target.clientSku?.trim();
                    if (!sourceArticle || !targetArticle || norm(sourceArticle) === norm(targetArticle))
                        throw new common_1.BadRequestException('Выберите два разных артикула.');
                    // A confirmed group pins exact size-level source IDs; existing mappings are not deleted.
                    if (!missingMappings.some(m => norm(m.sourceArticle) === norm(sourceArticle) && norm(m.targetArticle) === norm(targetArticle)))
                        missingMappings.push({ sourceArticle, targetArticle });
                }
            }
        const confirmation = (0, duplicate_relabel_confirmation_1.relabelConfirmation)(clientId, group, pairs, mappings);
        if (!reviewOnly && confirmation.confirmationKey && confirmationKey !== confirmation.confirmationKey)
            throw new common_1.ConflictException('Подтвердите выбранную переклейку в окне «Да / Нет». Настройки или соответствия могли измениться.');
        return { group, connections, warehouseId, skus, mappings, missingMappings, confirmation };
    }
    async confirmation(clientId, body, user) {
        this.authorize(clientId, user);
        return (await this.validate(clientId, body?.group, user, this.prisma, true, undefined, true)).confirmation;
    }
    async history(clientId, user) {
        this.authorize(clientId, user);
        const rows = await this.prisma.auditLog.findMany({ where: { entity: 'Client', entityId: clientId,
                action: { in: ['duplicate.stock.groups.saved', 'duplicate.stock.groups.applied'] } },
            orderBy: [{ createdAt: 'desc' }, { id: 'desc' }], take: 50,
            select: { id: true, createdAt: true, action: true, userId: true, payload: true } });
        const users = await this.prisma.user.findMany({ where: { id: { in: rows.flatMap(r => r.userId ? [r.userId] : []) } }, select: { id: true, name: true } });
        return rows.map(row => ({ ...row, userName: users.find(u => u.id === row.userId)?.name ?? 'Система / удалённый пользователь' }));
    }
    async save(clientId, body, user) {
        this.authorize(clientId, user, true);
        if (!body || (body.revision !== null && typeof body.revision !== 'string') || (body.deleteId !== undefined && (typeof body.deleteId !== 'string' || body.group !== undefined)))
            throw new common_1.BadRequestException('Передайте группу и версию настроек.');
        const key = prefix + clientId;
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${key}))`;
            const old = await tx.systemSetting.findUnique({ where: { key } });
            if ((old?.updatedAt.toISOString() ?? null) !== body.revision)
                throw new common_1.ConflictException('Группы изменены другим пользователем. Обновите список.');
            const groups = this.decode(old?.value);
            let confirmation = null;
            // FIX: active rules must be changed through a controlled publication transition.
            const active = await (0, duplicate_stock_runtime_1.activeDuplicateGroups)(tx, clientId);
            const changedId = body.deleteId ?? body.group?.id;
            if (active.some(g => g.id === changedId))
                throw new common_1.ConflictException('Группа уже управляет остатками WB. Для изменения требуется пересчёт и переключение действующей публикации.');
            if (body.deleteId !== undefined) {
                if (!groups.some(g => g.id === body.deleteId))
                    throw new common_1.BadRequestException('Группа не найдена.');
            }
            else {
                const checked = await this.validate(clientId, body.group, user, tx, true, body.confirmationKey);
                const { group } = checked;
                confirmation = checked.confirmation;
                try {
                    (0, duplicate_stock_groups_1.assertNoDuplicateGroupOverlap)(group, groups);
                }
                catch (e) {
                    throw new common_1.BadRequestException(e.message);
                }
                const index = groups.findIndex(g => g.id === group.id);
                if (index < 0) {
                    if (groups.length >= 100)
                        throw new common_1.BadRequestException('Достигнут предел 100 групп.');
                    groups.push(group);
                }
                else
                    groups[index] = group;
            }
            const value = { version: 1, groups: groups.filter(g => g.id !== body.deleteId) };
            const saved = await tx.systemSetting.upsert({ where: { key }, create: { key, value, updatedByUserId: user.id }, update: { value, updatedByUserId: user.id,
                    updatedAt: new Date(Math.max(Date.now(), (old?.updatedAt.getTime() ?? 0) + 1)) } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'duplicate.stock.groups.saved', entity: 'Client', entityId: clientId, payload: { before: old?.value ?? null, after: value, publicationEnabled: false, confirmation, explicitlyConfirmed: Boolean(confirmation?.confirmationKey) } } });
            return { groups: this.decode(saved.value), revision: saved.updatedAt.toISOString(), publicationEnabled: false };
        });
    }
    // FIX: settings + relabel mappings + durable queue event commit atomically under the publisher lock.
    async apply(clientId, body, user) {
        if (!(0, duplicate_apply_queue_1.duplicateApplyQueueEnabled)())
            return this.applyNow(clientId, body, user);
        this.authorize(clientId, user, true);
        if (!selfServiceEnabled() || !(0, duplicate_stock_runtime_1.duplicatePublicationEnabled)() || process.env.WMS_WB_URGENT_STOCK_SYNC !== 'true')
            throw new common_1.ForbiddenException('Применение распределения пока недоступно.');
        if (!body || (body.revision !== null && typeof body.revision !== 'string'))
            throw new common_1.BadRequestException('Передайте версию настроек.');
        const existing = await this.applyQueue.existing(clientId, user, body);
        if (existing)
            return { ...await this.read(clientId, user), queued: true, applyRequest: existing };
        const checked = await this.preview(clientId, { group: body.group, confirmationKey: body.confirmationKey }, user);
        if (body.previewKey !== checked.previewKey)
            throw new common_1.ConflictException('Настройки изменились. Повторите предпросмотр.');
        await this.validate(clientId, body.group, user, this.prisma, true, body.confirmationKey);
        const applyRequest = await this.applyQueue.enqueue(clientId, body, user);
        return { ...await this.read(clientId, user), queued: true, applyRequest };
    }
    async applyNow(clientId, body, user, jobKey) {
        this.authorize(clientId, user, true);
        if (!selfServiceEnabled() || !(0, duplicate_stock_runtime_1.duplicatePublicationEnabled)() || process.env.WMS_WB_URGENT_STOCK_SYNC !== 'true')
            throw new common_1.ForbiddenException('Применение распределения пока недоступно.');
        if (!body || (body.revision !== null && typeof body.revision !== 'string'))
            throw new common_1.BadRequestException('Передайте версию настроек.');
        // A fresh calculation verifies catalogue completeness; the worker recalculates again before sending.
        const checked = await this.preview(clientId, { group: body.group, confirmationKey: body.confirmationKey }, user);
        if (body.previewKey !== checked.previewKey)
            throw new common_1.ConflictException('Настройки изменились. Повторите предпросмотр.');
        return this.prisma.$transaction(async (tx) => {
            const key = prefix + clientId;
            const requested = (0, duplicate_stock_groups_1.validateDuplicateGroup)(body.group);
            // FIX: an accepted background request waits its turn; HTTP never waits on the publisher.
            if (jobKey) {
                await tx.$executeRaw `SET LOCAL lock_timeout = '15s'`;
                await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${'wb.stock.publish.' + requested.connectionId}))`;
            }
            else {
                const lock = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${'wb.stock.publish.' + requested.connectionId})) AS acquired`;
                if (!lock[0]?.acquired)
                    throw new common_1.ConflictException('Сейчас выполняется отправка WB. Повторите применение после её завершения.');
            }
            const { group, connections, warehouseId, missingMappings, confirmation } = await this.validate(clientId, body.group, user, tx, true, body.confirmationKey);
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${key}))`;
            const old = await tx.systemSetting.findUnique({ where: { key } });
            if ((old?.updatedAt.toISOString() ?? null) !== body.revision)
                throw new common_1.ConflictException('Группы изменены другим пользователем. Обновите список.');
            if (body.previewKey !== previewKey(group, old?.updatedAt.toISOString() ?? null))
                throw new common_1.ConflictException('Повторите предпросмотр.');
            if (connections.length !== 1 || connections[0].marketplace !== 'WILDBERRIES')
                throw new common_1.BadRequestException('Применение дублей сейчас доступно для одного кабинета WB.');
            if (process.env.WMS_WB_STOCK_FINE_SETTINGS !== 'true' || process.env.WMS_WB_ORDER_STOCK_LIFECYCLE_ENABLED !== 'true')
                throw new common_1.BadRequestException('Не включён единый учёт и подтверждение остатков WB.');
            const control = await tx.systemSetting.findUnique({ where: { key: 'marketplace.stockControl.client.' + clientId } });
            if (control && control.value !== true)
                throw new common_1.BadRequestException('Включите управление остатками клиента.');
            const groups = this.decode(old?.value), active = await (0, duplicate_stock_runtime_1.activeDuplicateGroups)(tx, clientId);
            const previous = active.find(g => g.id === group.id);
            // Changing percentages is safe. Replacing a live physical source requires a separate migration of outstanding picks.
            if (previous && JSON.stringify(previous.variants) !== JSON.stringify(group.variants))
                throw new common_1.ConflictException('У действующей группы можно менять доли. Смена артикулов и состава размеров требует завершения и проверки текущих сборок.');
            try {
                (0, duplicate_stock_groups_1.assertNoDuplicateGroupOverlap)(group, groups);
            }
            catch (e) {
                throw new common_1.BadRequestException(e.message);
            }
            const ids = (0, duplicate_stock_groups_1.duplicateGroupSkuIds)(group);
            const policy = await tx.fbsStockAllocationPolicy.findFirst({ where: { clientId, connectionId: group.connectionId, enabled: true }, include: { overrides: true } });
            if (!policy)
                throw new common_1.BadRequestException('Включите распределение WB по складам.');
            if (policy.overrides.some(o => ids.includes(o.skuId)))
                throw new common_1.ConflictException('У товаров есть индивидуальные лимиты распределения по складам. Сначала согласуйте их с долями.');
            const publications = await tx.fbsStockPublication.findMany({ where: { clientId, connectionId: group.connectionId, skuId: { in: ids } } });
            if (publications.some(p => !p.enabled || p.saleLimit !== null || p.relabelManualAmount !== null))
                throw new common_1.ConflictException('У товаров есть отключённая публикация или ручные лимиты. Сначала снимите конфликтующие настройки.');
            const index = groups.findIndex(g => g.id === group.id);
            if (index < 0) {
                if (groups.length >= 100)
                    throw new common_1.BadRequestException('Достигнут предел 100 групп.');
                groups.push(group);
            }
            else
                groups[index] = group;
            for (const mapping of missingMappings)
                await tx.clientArticleMapping.upsert({ where: { clientId_sourceArticle_targetArticle: { clientId, ...mapping } }, create: { clientId, ...mapping }, update: {} });
            const value = { version: 1, groups };
            const saved = await tx.systemSetting.upsert({ where: { key }, create: { key, value, updatedByUserId: user.id }, update: { value, updatedByUserId: user.id, updatedAt: new Date(Math.max(Date.now(), (old?.updatedAt.getTime() ?? 0) + 1)) } });
            const activeKey = 'marketplace.duplicates.active.' + clientId;
            const activeValue = { version: 1, groupIds: [...new Set([...active.map(g => g.id), group.id])], connectionId: group.connectionId, warehouseId };
            await tx.systemSetting.upsert({ where: { key: activeKey }, create: { key: activeKey, value: activeValue, updatedByUserId: user.id }, update: { value: activeValue, updatedByUserId: user.id } });
            await tx.$executeRaw `INSERT INTO "WbStockSyncEvent" ("clientId", "skuIds", "allSkus") VALUES (${clientId}, ${ids}::text[], false)`;
            await tx.auditLog.create({ data: { userId: user.id, action: 'duplicate.stock.groups.applied', entity: 'Client', entityId: clientId, payload: { before: old?.value ?? null, after: value, createdMappings: missingMappings, active: activeValue, confirmation, explicitlyConfirmed: Boolean(confirmation.confirmationKey) } } });
            if (jobKey)
                await (0, duplicate_apply_queue_1.completeDuplicateApply)(tx, jobKey);
            return { groups: this.decode(saved.value), revision: saved.updatedAt.toISOString(), activeGroupIds: activeValue.groupIds, queued: true, mappingsCreated: missingMappings.length };
        }, { timeout: 30000 });
    }
    async preview(clientId, body, user) {
        this.authorize(clientId, user);
        const { group, connections, warehouseId, skus, mappings, missingMappings } = await this.validate(clientId, body?.group, user, this.prisma, true, body?.confirmationKey);
        const existing = await this.prisma.systemSetting.findUnique({ where: { key: prefix + clientId } });
        try {
            (0, duplicate_stock_groups_1.assertNoDuplicateGroupOverlap)(group, this.decode(existing?.value));
        }
        catch (e) {
            throw new common_1.BadRequestException(e.message);
        }
        let wbPercent = 100;
        if (connections.some(c => c.marketplace === 'OZON')) {
            const allocation = await this.prisma.systemSetting.findUnique({ where: { key: 'marketplace.allocation.draft.' + clientId } });
            try {
                const draft = (0, marketplace_allocation_1.validateAllocationDraft)(allocation?.value, connections);
                if (draft.wbConnectionId !== group.connectionId || connections.find(c => c.id === draft.ozonConnectionId)?.fbsExecutionWarehouseId !== warehouseId)
                    throw new Error();
                wbPercent = draft.wbPercent;
            }
            catch {
                throw new common_1.BadRequestException('Сначала настройте доли WB/Ozon для выбранного кабинета и общего склада исполнения.');
            }
        }
        const quantities = await this.marketplaces.calculateFbsStockQuantities(clientId, (0, duplicate_stock_groups_1.duplicateGroupSkuIds)(group), warehouseId, group.connectionId);
        const reserveRule = group.reserve.mode === 'COMMON' ? await (0, duplicate_stock_runtime_1.commonDuplicateReserve)(this.prisma, clientId) : { mode: group.reserve.mode, value: group.reserve.value };
        const stocks = group.variants.map(v => {
            const q = quantities.get(v.sourceSkuId);
            if (!q)
                throw new common_1.BadRequestException('Не удалось рассчитать исходный SKU. Проверьте ID размера WB.');
            const budget = (0, duplicate_stock_runtime_1.duplicateVariantBudget)(v, quantities, reserveRule);
            return { ...v, size: skus.find(s => s.id === v.sourceSkuId).size, available: budget.sourceBudget,
                marketplaceBudget: (0, marketplace_allocation_1.splitMarketplaceStock)(budget.sourceBudget, wbPercent).wb, total: budget.totalAvailable, reserved: budget.totalReserved,
                freeBeforeSafety: budget.freeBeforeSafety, safetyReserve: budget.safetyReserve, ownByTarget: budget.ownByTarget };
        });
        const plan = (0, duplicate_stock_plan_1.calculateDuplicateStockPlan)(group, stocks);
        const publications = await this.prisma.fbsStockPublication.findMany({ where: { clientId, connectionId: group.connectionId, skuId: { in: (0, duplicate_stock_groups_1.duplicateGroupSkuIds)(group) } },
            select: { skuId: true, enabled: true, saleLimit: true, relabelManualAmount: true } });
        // Before activation legacy mappings still apply; active groups pin exact source SKU IDs.
        const relevantMappings = mappings.filter(m => skus.some(s => [s.article, s.clientSku].some(a => norm(a) === norm(m.targetArticle))));
        const candidates = relevantMappings.length ? await this.prisma.sku.findMany({ where: { clientId,
                OR: relevantMappings.flatMap(m => [
                    { article: { equals: m.sourceArticle, mode: 'insensitive' } },
                    { clientSku: { equals: m.sourceArticle, mode: 'insensitive' } },
                    { internalSku: { equals: m.sourceArticle, mode: 'insensitive' } },
                    { internalSku: { startsWith: m.sourceArticle + '-', mode: 'insensitive' } },
                ]) }, select: { id: true, article: true, clientSku: true, internalSku: true, size: true } }) : [];
        const pickingWarnings = group.variants.flatMap(v => v.targets.filter(t => t.requiresRelabel).flatMap(t => {
            const target = skus.find(s => s.id === t.targetId);
            const rules = relevantMappings.filter(m => [target.article, target.clientSku].some(a => norm(a) === norm(m.targetArticle)));
            const matches = candidates.filter(s => norm(s.size) === norm(target.size) && rules.some(m => [s.article, s.clientSku, s.internalSku].some(a => norm(a) === norm(m.sourceArticle)) || norm(s.internalSku).startsWith(norm(m.sourceArticle) + '-')));
            return matches.some(s => s.id !== v.sourceSkuId) ? [{ sourceSkuId: v.sourceSkuId, targetSkuId: t.targetId,
                    message: `Для ${target.article || target.clientSku || target.id}, размер ${target.size}, есть прежние соответствия с другими исходными товарами. После применения этой группы сборка будет использовать выбранный исходный SKU; сохранение черновика правила сборки не меняет.` }] : [];
        }));
        return { ...plan, missingMappings, previewKey: previewKey(group, existing?.updatedAt.toISOString() ?? null), generatedAt: new Date().toISOString(), warehouseId, wbPercent, publicationEnabled: false, publications, pickingWarnings,
            rows: plan.rows.map((r, i) => ({ ...r, total: stocks[i].total, reserved: stocks[i].reserved, freeBeforeSafety: stocks[i].freeBeforeSafety,
                safetyReserve: stocks[i].safetyReserve, source: skus.find(s => s.id === r.sourceSkuId),
                targets: r.targets.map(t => ({ ...t, card: skus.find(s => s.id === t.targetId), ownStock: stocks[i].ownByTarget.get(t.targetId) ?? 0 })) })) };
    }
};
exports.DuplicateStockGroupsService = DuplicateStockGroupsService;
exports.DuplicateStockGroupsService = DuplicateStockGroupsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService, marketplace_connections_service_1.MarketplaceConnectionsService])
], DuplicateStockGroupsService);
