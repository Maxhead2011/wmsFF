"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requiresFbsReturnReceipt = void 0;
exports.requireFbsReturnScans = requireFbsReturnScans;
exports.validateFbsReturnReceipt = validateFbsReturnReceipt;
const common_1 = require("@nestjs/common");
const box_code_policy_service_1 = require("../../common/boxes/box-code-policy.service");
const fbs_manager_decision_1 = require("./fbs-manager-decision");
// FIX: a logical reservation is different from a physically scanned/completed pick.
const requiresFbsReturnReceipt = (task) => (0, box_code_policy_service_1.permanentStorageBoxesEnabled)() && Boolean(task.completedAt || (task.status === 'RETURN_REQUIRED' && (task.kiz || task.barcode || task.relabelConfirmedAt)));
exports.requiresFbsReturnReceipt = requiresFbsReturnReceipt;
const normalizeKiz = (value) => value.replace(/<GS>/gi, '\u001d').replace(/^\]d2/i, '').trim();
function requireFbsReturnScans(task, dto) {
    if (!(0, exports.requiresFbsReturnReceipt)(task))
        return;
    // FIX: neither manager confirmation nor bulk requests without scans can manufacture a return.
    if (dto.action !== 'RETURN_TO_STOCK' || !dto.returnBoxCode?.trim() || !dto.returnBarcode?.trim() ||
        ((task.requiresKiz || task.kiz) && !dto.returnKiz?.trim())) {
        throw new common_1.BadRequestException('Товар уже изъят из короба. Нужна повторная приёмка: отсканируйте бокс назначения, ШК товара и его КИЗ.');
    }
    if (task.kiz && normalizeKiz(dto.returnKiz) !== normalizeKiz(task.kiz)) {
        throw new common_1.BadRequestException('КИЗ не совпадает с отобранным товаром этого заказа. Остатки не изменены.');
    }
    if (Math.max(1, task.itemCount) !== 1 || task.marketplace !== 'WILDBERRIES') {
        throw new common_1.BadRequestException('Для этого заказа нужна отдельная поштучная приёмка возврата. Автоматический возврат в исходный короб запрещён.');
    }
}
async function validateFbsReturnReceipt(tx, task, dto, user, boxCodes) {
    requireFbsReturnScans(task, dto);
    if (!(0, exports.requiresFbsReturnReceipt)(task))
        return undefined;
    if (user.isDemo || user.roleCodes?.includes('CLIENT'))
        throw new common_1.ForbiddenException('Приёмка возврата доступна только сотрудникам WMS.');
    const request = await tx.clientRequest.findUnique({ where: { id: task.requestId }, select: { clientId: true, warehouseId: true, status: true } });
    // FIX: dispatch of the original request does not receive a separately deferred unit.
    const deferredLink = request?.status === 'DONE' ? await tx.fbsOrderRequestLink.findUnique({
        where: { marketplace_connectionId_orderId: { marketplace: task.marketplace, connectionId: task.connectionId, orderId: task.orderId } },
    }) : null;
    const deferredReceipt = deferredLink?.requestId === task.requestId && (0, fbs_manager_decision_1.fbsManagerDisposition)(deferredLink?.syncStatus) === 'AWAIT_RETURN_RECEIPT';
    if (!request?.warehouseId || request.clientId !== task.clientId || (request.status === 'DONE' && !deferredReceipt)) {
        throw new common_1.BadRequestException('Заявка уже отгружена или её склад не определён. Нужна проверка возврата после отгрузки.');
    }
    if (user.activeWarehouseId !== request.warehouseId ||
        (!user.permissionCodes?.includes('system:admin') && !user.writableWarehouseIds?.includes(request.warehouseId))) {
        throw new common_1.ForbiddenException('Приёмка возврата разрешена только в доступном филиале заявки.');
    }
    if (!boxCodes)
        throw new common_1.BadRequestException('Настройки боксов недоступны. Остатки не изменены.');
    const code = await boxCodes.requireStorageBox(dto.returnBoxCode);
    const [box, sku] = await Promise.all([
        tx.box.findUnique({ where: { code } }),
        tx.sku.findUnique({ where: { id: task.skuId }, include: { barcodes: true } }),
    ]);
    if (!box || box.status !== 'active' || box.clientId !== task.clientId || box.warehouseId !== request.warehouseId) {
        throw new common_1.BadRequestException('Нужен действующий бокс того же клиента и филиала. Сначала создайте или откройте бокс.');
    }
    if (sku?.clientId !== task.clientId || !sku.barcodes.some(b => b.value === dto.returnBarcode.trim())) {
        throw new common_1.BadRequestException('ШК не соответствует товару возвращаемого заказа.');
    }
    if (await tx.inventoryAuditBox.findFirst({ where: { boxId: box.id, status: 'COUNTING' }, select: { id: true } })) {
        throw new common_1.BadRequestException('Бокс назначения сейчас пересчитывается. Завершите проверку или выберите другой бокс.');
    }
    const mark = task.kiz ? await tx.productMark.findFirst({ where: { clientId: task.clientId, value: task.kiz } }) : null;
    if ((task.kiz || task.requiresKiz) && (!mark || mark.skuId !== task.skuId || mark.status !== 'PACKING' ||
        (mark.boxId !== null && mark.boxId !== task.boxId))) {
        throw new common_1.BadRequestException('КИЗ уже перемещён, отгружен или не относится к резерву этого товара. Повторная приёмка не выполнена.');
    }
    return { boxId: box.id, boxCode: box.code, palletId: box.palletId, warehouseId: request.warehouseId, mark };
}
