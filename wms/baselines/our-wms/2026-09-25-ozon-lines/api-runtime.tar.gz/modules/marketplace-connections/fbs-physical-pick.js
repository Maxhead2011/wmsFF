"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withFbsTsdCapability = withFbsTsdCapability;
exports.physicalPickConfirmationEnabled = physicalPickConfirmationEnabled;
// FIX: request capability selects UI behavior, never identity or permissions.
function withFbsTsdCapability(user, capability) {
    return { ...user, tsdPhysicalPickConfirmation: capability === 'physical-pick-v1' };
}
function physicalPickConfirmationEnabled(task, user) {
    return process.env.WMS_TSD_PHYSICAL_PICK_CONFIRMATION === 'true' &&
        user?.tsdPhysicalPickConfirmation === true && ['OZON', 'WILDBERRIES'].includes(task.marketplace);
}
