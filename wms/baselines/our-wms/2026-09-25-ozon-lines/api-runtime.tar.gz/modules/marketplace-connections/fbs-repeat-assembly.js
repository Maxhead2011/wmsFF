"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertRepeatAssemblyEnabled = assertRepeatAssemblyEnabled;
exports.assertRepeatCandidate = assertRepeatCandidate;
exports.createRepeatAttemptData = createRepeatAttemptData;
exports.repeatSelectionFingerprint = repeatSelectionFingerprint;
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
// FIX: opt-in only; deployments for the sold WMS keep their existing workflow.
function assertRepeatAssemblyEnabled() {
    if (process.env.WMS_FBS_REPEAT_ASSEMBLY_ENABLED !== 'true') {
        throw new common_1.ForbiddenException('Отдельная повторная сборка не включена для этой WMS.');
    }
}
function assertRepeatCandidate(task, wb) {
    if (task.status !== 'COMPLETED' || !task.completedAt || !task.barcode ||
        (task.requiresKiz && (!task.kiz || task.wbMetaStatus !== 'ACCEPTED'))) {
        throw new common_1.BadRequestException('Повторная сборка разрешена только после завершённой предыдущей попытки.');
    }
    if (task.itemCount !== 1) {
        throw new common_1.BadRequestException('Повторная сборка поддерживает только поштучные заказы WB.');
    }
    if (task.cargoPackingId) {
        throw new common_1.BadRequestException('Заказ уже включён в грузокороб. Отдельная повторная упаковка грузомест пока не поддерживается; прежний грузокороб не изменён.');
    }
    if (!wb || wb.supplierStatus !== 'complete' || wb.wbStatus !== 'waiting') {
        throw new common_1.BadRequestException('WB не подтверждает состояние complete/waiting. Отменённый или уже доставленный заказ нельзя собирать повторно.');
    }
}
// FIX: old movement/history idempotency keys remain attached to the old id.
// Do not mutate the snapshot, reset stock, return old marks or rewrite WB here.
function createRepeatAttemptData(previous, id, requestId, requestItemId, createdAt) {
    if (!id || id === previous.id)
        throw new common_1.BadRequestException('Для повторной сборки требуется новый идентификатор.');
    return {
        id, requestId, requestItemId, createdAt,
        status: 'WAITING_STOCK', deviceCode: 'AUTO', workerUserId: null, workerName: null,
        startedAt: null, reservedBoxId: null, reservedBoxCode: null, reservedAt: null,
        boxId: null, boxCode: null, sourceBoxPending: false, sourceBarcode: null, barcode: null,
        sourceSkuId: null, sourceProductName: null, sourceArticle: null, sourceBarcodes: [],
        storageBoxes: [], relabelRequired: false, relabelConfirmedAt: null,
        kiz: null, wbMetaStatus: previous.requiresKiz ? 'PENDING' : 'NOT_REQUIRED',
        stickerPartA: null, stickerPartB: null, stickerBarcode: null,
        marketplaceSubmittedAt: null, marketplaceLabelBase64: null,
        marketplaceLabelContentType: null, marketplaceSubmitError: null,
        cargoPackingId: null, cargoPackedAt: null, cargoPackedByUserId: null, cargoPackedByName: null,
        errorMessage: null, completedAt: null,
    };
}
function repeatSelectionFingerprint(clientId, warehouseId, orders) {
    const keys = [...new Set(orders.map(order => JSON.stringify([
            order.connectionId, order.id, order.assemblyId,
        ])))].sort();
    return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([clientId, warehouseId, keys])).digest('hex');
}
