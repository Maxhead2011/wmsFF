"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketplaceConnectionsController = void 0;
const fbs_wb_accounting_1 = require("./fbs-wb-accounting");
const fbs_reshipment_service_1 = require("./fbs-reshipment.service");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const node_fs_1 = require("node:fs");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const logistics_service_1 = require("../logistics/logistics.service");
const apply_fbs_relabel_reconciliation_dto_1 = require("./dto/apply-fbs-relabel-reconciliation.dto");
const fbs_supply_reconciliation_dto_1 = require("./dto/fbs-supply-reconciliation.dto");
const fbs_order_selection_dto_1 = require("./dto/fbs-order-selection.dto");
const fbs_cancelled_orders_report_dto_1 = require("./dto/fbs-cancelled-orders-report.dto");
const fbs_pass_dto_1 = require("./dto/fbs-pass.dto");
const fbs_stock_publication_bulk_dto_1 = require("./dto/fbs-stock-publication-bulk.dto");
const fbs_stock_publication_dto_1 = require("./dto/fbs-stock-publication.dto");
const fbs_stock_monitoring_dto_1 = require("./dto/fbs-stock-monitoring.dto");
const fbs_stock_allocation_dto_1 = require("./dto/fbs-stock-allocation.dto");
const reconcile_fbs_stock_item_dto_1 = require("./dto/reconcile-fbs-stock-item.dto");
const fbs_stock_sync_dto_1 = require("./dto/fbs-stock-sync.dto");
const fbs_supply_request_audit_dto_1 = require("./dto/fbs-supply-request-audit.dto");
const fbs_supply_request_dto_1 = require("./dto/fbs-supply-request.dto");
const quote_fbs_calculator_dto_1 = require("./dto/quote-fbs-calculator.dto");
const update_fbs_billing_settings_dto_1 = require("./dto/update-fbs-billing-settings.dto");
const update_fbs_cargo_packing_ignore_dto_1 = require("./dto/update-fbs-cargo-packing-ignore.dto");
const update_fbs_warehouse_routes_dto_1 = require("./dto/update-fbs-warehouse-routes.dto");
const update_marketplace_connection_dto_1 = require("./dto/update-marketplace-connection.dto");
const update_dbs_integration_dto_1 = require("./dto/update-dbs-integration.dto");
const upsert_dbs_integration_dto_1 = require("./dto/upsert-dbs-integration.dto");
const upsert_marketplace_connection_dto_1 = require("./dto/upsert-marketplace-connection.dto");
const fbs_product_shipments_report_service_1 = require("./fbs-product-shipments-report.service");
const fbs_penalties_report_service_1 = require("./fbs-penalties-report.service");
const fbs_deadline_report_xlsx_1 = require("./fbs-deadline-report-xlsx");
const fbs_cancelled_report_xlsx_1 = require("./fbs-cancelled-report-xlsx");
const fbs_stock_monitoring_service_1 = require("./fbs-stock-monitoring.service");
const marketplace_connections_service_1 = require("./marketplace-connections.service");
let MarketplaceConnectionsController = class MarketplaceConnectionsController {
    connections;
    logistics;
    productShipmentsReport;
    penaltiesReport;
    stockMonitoring;
    reshipment;
    constructor(connections, logistics, productShipmentsReport, 
    // ADDED: read-only WB Finance report for the 13th FBS tile.
    penaltiesReport, stockMonitoring, reshipment) {
        this.connections = connections;
        this.logistics = logistics;
        this.productShipmentsReport = productShipmentsReport;
        this.penaltiesReport = penaltiesReport;
        this.stockMonitoring = stockMonitoring;
        this.reshipment = reshipment;
    }
    list(user, clientId) {
        return this.connections.list(clientId, user);
    }
    listDbsIntegrations(user, clientId, marketplace) {
        return this.connections.listDbsIntegrations(clientId, marketplace, user);
    }
    createDbsIntegration(dto, user) {
        return this.connections.createDbsIntegration(dto, user);
    }
    updateDbsIntegration(id, dto, user) {
        return this.connections.updateDbsIntegration(id, dto, user);
    }
    checkDbsIntegration(id, user) {
        return this.connections.checkDbsIntegration(id, user);
    }
    // FIX: an explicit manager action, never a side effect of a failed WB transfer.
    accountFbsOrderByWb(requestId, taskId, dto, user) {
        return this.connections.accountFbsOrderByWb(requestId, taskId, dto, user);
    }
    async listFbsOrders(user, clientId, refresh, view, allBranches, displayWarehouseId) {
        // FIX: only the screen opts into asynchronous reads; legacy/action callers remain strict.
        const result = view === 'snapshot'
            ? await this.connections.listFbsOrdersForDisplay(clientId, user, refresh === 'true' || refresh === '1', allBranches === '1', displayWarehouseId)
            : await this.connections.listFbsOrders(clientId, user, refresh === 'true' || refresh === '1', allBranches === '1', displayWarehouseId);
        return { ...result, ...(process.env.WMS_FBS_NO_STOCK_TRANSFER_ENABLED === 'true' && process.env.WMS_FBS_RESHIPMENT_ENABLED === 'true' ? { stockTransferEnabled: true } : {}) };
    }
    // FIX: explicit live audit of every WB supply routed to the user's active branch.
    checkFbsBranchDeliveryRecovery(user, clientId) {
        return this.connections.checkFbsBranchDeliveryRecovery(clientId, user);
    }
    createFbsDeliveryRecoveryRequest(dto, user) {
        return this.connections.createFbsDeliveryRecoveryRequest(dto, user);
    }
    listFbsPackedItems(user, clientId, marketplace, dateFrom, dateTo, search, requiresKiz, page, pageSize) {
        return this.connections.listFbsPackedItems({ clientId, marketplace, dateFrom, dateTo, search, requiresKiz, page, pageSize }, user);
    }
    reconcileFbsPackedItems(payload, user) {
        return this.connections.reconcileFbsPackedItems(payload, user);
    }
    productShipments(user, clientId, dateFrom, dateTo, search) {
        return this.productShipmentsReport.report({ clientId, dateFrom, dateTo, search }, user);
    }
    async productShipmentsXlsx(user, response, clientId, dateFrom, dateTo, search) {
        const file = await this.productShipmentsReport.export({ clientId, dateFrom, dateTo, search }, user);
        response.setHeader('Content-Type', fbs_product_shipments_report_service_1.FBS_PRODUCT_REPORT_XLSX_MIME);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="fbs-products.xlsx"; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.buffer);
    }
    penalties(user, clientId, connectionId, dateFrom, dateTo, search) {
        // ADDED: client scope is checked again inside the report service.
        return this.penaltiesReport.report({ clientId, connectionId, dateFrom, dateTo, search }, user);
    }
    async penaltiesXlsx(user, response, clientId, connectionId, dateFrom, dateTo, search) {
        const file = await this.penaltiesReport.export({ clientId, connectionId, dateFrom, dateTo, search }, user);
        response.setHeader('Content-Type', fbs_penalties_report_service_1.FBS_PENALTIES_REPORT_XLSX_MIME);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="fbs-penalties.xlsx"; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.buffer);
    }
    listFbsRelabelReconciliation(user, clientId, dateFrom, dateTo, barcode, refreshWb) {
        return this.connections.listFbsRelabelReconciliation(clientId, dateFrom, dateTo, barcode, user, refreshWb !== 'false' && refreshWb !== '0');
    }
    applyFbsRelabelReconciliation(dto, user) {
        return this.connections.applyFbsRelabelReconciliation(dto, user);
    }
    listFbsActiveClients(user, marketplace, view, allBranches, displayWarehouseId) {
        return this.connections.listFbsActiveClients(user, marketplace, view === 'snapshot', allBranches === '1', displayWarehouseId);
    }
    listFbsCargoPackings(user, clientId) {
        return this.connections.listFbsCargoPackings(clientId, user);
    }
    updateFbsCargoPackingIgnore(planId, dto, user) {
        return this.connections.updateFbsCargoPackingIgnore(planId, dto, user);
    }
    listFbsStocks(user, clientId, connectionId, warehouseId, refresh) {
        return this.connections.listFbsStocks(clientId, connectionId, warehouseId, user, refresh === 'true' || refresh === '1');
    }
    // ADDED: read-only audit monitor; it never changes WB or WMS stock.
    listFbsStockMonitor(user, clientId, connectionId, warehouseId, status, system, product, q, dateFrom, dateTo, sort, direction, page, pageSize) {
        return this.stockMonitoring.list({
            clientId,
            connectionId,
            warehouseId,
            status,
            system,
            product,
            q,
            dateFrom,
            dateTo,
            sort,
            direction,
            page,
            pageSize,
        }, user);
    }
    // FIX: generate and close the complete workbook before response streaming.
    async exportFbsStockMonitorWmsStocks(user, response, clientId, warehouseId) {
        // FIX: the Excel export obeys the same warehouse filter as the report screen.
        const file = await this.stockMonitoring.exportWmsStocks(clientId, user, warehouseId);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.size));
        response.setHeader('Content-Disposition', `attachment; filename="${file.fileName}"`);
        const stream = (0, node_fs_1.createReadStream)(file.filePath);
        let cleaned = false;
        const cleanup = () => {
            if (cleaned)
                return;
            cleaned = true;
            void file.cleanup();
        };
        stream.once('close', cleanup);
        stream.once('error', cleanup);
        return new common_1.StreamableFile(stream);
    }
    getFbsStockMonitorEvent(eventId, user) {
        return this.stockMonitoring.detail(eventId, user);
    }
    getFbsStockMonitorConfig(connectionId, user) {
        return this.stockMonitoring.getConfig(connectionId, user);
    }
    updateFbsStockMonitorConfig(connectionId, dto, user) {
        return this.stockMonitoring.updateConfig(connectionId, dto, user);
    }
    refreshFbsStockMonitor(dto, user) {
        return this.stockMonitoring.refresh(dto, user);
    }
    // ADDED: preview is read-only and obtains live WB/WMS values before the
    // operator sees the confirmation dialog.
    previewFbsStockMonitorRepair(eventId, user) {
        return this.stockMonitoring.previewRepair(eventId, user);
    }
    // ADDED: the confirmed operation remains client-scoped and idempotent.
    repairFbsStockMonitor(eventId, dto, user) {
        return this.stockMonitoring.repair(eventId, dto, user);
    }
    updateFbsStockPublication(dto, user) {
        return this.connections.updateFbsStockPublication(dto, user);
    }
    reconcileFbsStockItem(dto, user) {
        return this.connections.reconcileFbsStockItem(dto, user);
    }
    updateFbsStockPublicationBulk(dto, user) {
        return this.connections.updateFbsStockPublicationBulk(dto, user);
    }
    syncFbsStocks(dto, user) {
        return this.connections.syncFbsStocks(dto, user);
    }
    connectFbsStockWarehouse(dto, user) {
        return this.connections.connectFbsStockWarehouse(dto, user);
    }
    // ADDED: Optional multi-warehouse allocation; disabled policies do not affect legacy stock sync.
    listFbsStockAllocation(user, clientId, connectionId) {
        return this.connections.listFbsStockAllocation(clientId, connectionId, user);
    }
    updateFbsStockAllocation(dto, user) {
        return this.connections.updateFbsStockAllocation(dto, user);
    }
    syncFbsStockAllocation(dto, user) {
        return this.connections.syncFbsStockAllocation(dto, user);
    }
    // FIX: verify actual WB amounts without sending new stock quantities.
    checkFbsStockPublication(dto, user) {
        return this.connections.checkFbsStockPublication(dto, user);
    }
    createFbsStockIntegrationKey(dto, user) {
        return this.connections.createFbsStockIntegrationKey(dto, user);
    }
    revokeFbsStockIntegrationKey(keyId, clientId, user) {
        return this.connections.revokeFbsStockIntegrationKey(clientId, keyId, user);
    }
    acknowledgeFbsStockAllocationChange(changeId, dto, user) {
        return this.connections.acknowledgeFbsStockAllocationChange(dto.clientId, changeId, user);
    }
    listFbsWarehouseRoutes(id, user) {
        return this.connections.listFbsWarehouseRoutes(id, user);
    }
    updateFbsWarehouseRoutes(id, dto, user) {
        return this.connections.updateFbsWarehouseRoutes(id, dto, user);
    }
    assembleFbsOrders(dto, user) {
        return this.connections.assembleFbsOrders(dto, user);
    }
    reshipFbsOrders(dto, user) {
        return this.connections.reshipFbsOrders(dto, user);
    }
    moveFbsOrdersToNewSupply(dto, user) {
        // FIX: sold WMS retains its original endpoint behavior unless explicitly enabled.
        return process.env.WMS_FBS_NO_STOCK_TRANSFER_ENABLED === 'true'
            ? this.reshipment.moveWithStockRouting(dto, user)
            : this.connections.moveFbsOrdersToNewSupply(dto, user);
    }
    // ADDED: safe recovery for mixed/partially unavailable online-request orders.
    repairFbsOrdersMove(dto, user) {
        return this.connections.repairFbsOrdersMove(dto, user);
    }
    cancelFbsOrders(dto, user) {
        return this.connections.cancelFbsOrders(dto, user);
    }
    removeCancelledFbsOrder(dto, user) {
        return this.connections.removeCancelledFbsOrder(dto, user);
    }
    deliverFbsSupplies(dto, user) {
        return this.connections.deliverFbsSupplies(dto, user);
    }
    // ADDED: resolve the current WB destination before showing the irreversible
    // delivery confirmation dialog.
    getFbsSupplyDeliveryOptions(dto, user) {
        return this.connections.getFbsSupplyDeliveryOptions(dto, user);
    }
    changeFbsSuppliesDestination(dto, user) {
        return this.connections.changeFbsSuppliesDestination(dto, user);
    }
    createFbsRequest(dto, user) {
        return this.connections.createFbsRequest(dto, user);
    }
    createFbsRequestFromSupply(dto, user) {
        return this.connections.createFbsRequestFromSupply(dto, user);
    }
    // ADDED: read-only check of WB supplies that have orders but no complete WMS request.
    auditFbsSupplyRequests(dto, user) {
        return this.connections.auditFbsSupplyRequests(dto, user);
    }
    // ADDED: two-step, client-scoped repair for supplies merged manually in WB.
    previewFbsSupplyReconciliation(dto, user) {
        return this.connections.previewFbsSupplyReconciliation(dto, user);
    }
    applyFbsSupplyReconciliation(dto, user) {
        return this.connections.applyFbsSupplyReconciliation(dto, user);
    }
    enableFbsEmergencyAssembly(requestId, user) {
        return this.connections.enableFbsEmergencyAssembly(requestId, user);
    }
    // ADDED: admin authorization is enforced by the service; no full emergency reset.
    enableFbsRemainingSearch(requestId, user) {
        return this.connections.enableFbsRemainingSearch(requestId, user);
    }
    repairFbsRequestSelection(requestId, user) {
        return this.connections.repairFbsRequestSelection(requestId, user);
    }
    getFbsRequestRoute(requestId, user) {
        // ADDED: Always built from live WMS balances; no frontend route cache.
        return this.connections.getFbsRequestRoute(requestId, user);
    }
    rebuildFbsRequestRoute(requestId, user) {
        return this.connections.repairFbsRequestSelection(requestId, user);
    }
    checkFbsRequestSupplyConsistency(requestId, user) {
        return this.connections.checkFbsRequestSupplyConsistency(requestId, user);
    }
    repairFbsRequestSupplyConsistency(requestId, user) {
        return this.connections.repairFbsRequestSupplyConsistency(requestId, user);
    }
    async getFbsOrderStickersPdf(dto, user, response) {
        const file = await this.connections.getFbsOrderStickersPdf(dto, user);
        response.setHeader('Content-Type', file.contentType);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="${file.fileName}"`);
        return new common_1.StreamableFile(file.buffer);
    }
    async exportFbsDeadlineSelectedOrders(dto, user, response) {
        const file = await this.connections.exportFbsDeadlineSelectedOrders(dto, user);
        response.setHeader('Content-Type', fbs_deadline_report_xlsx_1.FBS_DEADLINE_REPORT_XLSX_MIME);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="fbs-selected-deadlines.xlsx"; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.buffer);
    }
    // ADDED: protected XLSX download for the existing cancelled-orders report.
    async exportFbsCancelledOrders(dto, user, response) {
        const file = await this.connections.exportFbsCancelledOrders(dto, user);
        response.setHeader('Content-Type', fbs_cancelled_report_xlsx_1.FBS_CANCELLED_REPORT_XLSX_MIME);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="fbs-cancelled-orders.xlsx"; filename*=UTF-8''${encodeURIComponent(file.fileName)}`);
        return new common_1.StreamableFile(file.buffer);
    }
    async getFbsCargoPlaceStickersPdf(dto, user, response) {
        const file = await this.connections.getFbsCargoPlaceStickersPdf(dto, user);
        response.setHeader('Content-Type', file.contentType);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="${file.fileName}"`);
        return new common_1.StreamableFile(file.buffer);
    }
    async getFbsSupplyStickersPdf(dto, user, response) {
        const file = await this.connections.getFbsSupplyStickersPdf(dto, user);
        response.setHeader('Content-Type', file.contentType);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="${file.fileName}"`);
        return new common_1.StreamableFile(file.buffer);
    }
    async getFbsRequestPickListPdf(requestId, user, response) {
        const file = await this.connections.getFbsRequestPickListPdf(requestId, user);
        response.setHeader('Content-Type', file.contentType);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', `attachment; filename="${file.fileName}"`);
        return new common_1.StreamableFile(file.buffer);
    }
    createFbsConnection(dto, user) {
        return this.connections.createFbsConnection(dto, user);
    }
    listFbsPasses(user, clientId, connectionId) {
        return this.connections.listFbsPasses(clientId, connectionId, user);
    }
    createFbsPass(dto, user) {
        return this.connections.createFbsPass(dto, user);
    }
    updateFbsPass(passId, dto, user) {
        return this.connections.updateFbsPass(passId, dto, user);
    }
    deleteFbsPass(passId, clientId, connectionId, user) {
        return this.connections.deleteFbsPass(passId, clientId, connectionId, user);
    }
    listFbsCalculatorDestinations() {
        return this.logistics.listFbsCalculatorDestinations();
    }
    quoteFbsCalculator(dto) {
        return this.logistics.quoteFbsCalculator(dto);
    }
    getFbsBillingSettings(clientId, user) {
        return this.connections.getFbsBillingSettings(clientId, user);
    }
    updateFbsBillingSettings(clientId, dto, user) {
        return this.connections.updateFbsBillingSettings(clientId, dto, user);
    }
    scanWebOrderAssembly(body, user) {
        return this.connections.scanWebOrderAssembly(body?.code, user, body?.stationId, body?.deviceCode);
    }
    listSosWbRequests(user) {
        return this.connections.listSosWbRequests(user);
    }
    claimSosWbOrder(body, user) {
        return this.connections.claimSosWbOrder(body ?? {}, user);
    }
    acceptSosWbKiz(taskId, body, user) {
        return this.connections.acceptSosWbKiz(taskId, body ?? {}, user);
    }
    releaseSosWbOrder(taskId, body, user) {
        return this.connections.releaseSosWbOrder(taskId, body ?? {}, user);
    }
    webOrderAssemblyHistory(user, orderId) {
        // FIX: reuse the permission-scoped history endpoint for exact order search.
        return this.connections.webOrderAssemblyHistory(user, orderId);
    }
    reprintWebOrderAssemblyHistory(id, user) {
        return this.connections.reprintWebOrderAssemblyHistory(id, user);
    }
    deleteWebOrderAssemblyHistory(id, user) {
        return this.connections.deleteWebOrderAssemblyHistory(id, user);
    }
    listFbsPrintStations(user) {
        return this.connections.listFbsPrintStations(user);
    }
    createFbsPrintStation(body, user) {
        return this.connections.createFbsPrintStation(body ?? {}, user);
    }
    deleteFbsPrintStation(stationId, user) {
        return this.connections.deleteFbsPrintStation(stationId, user);
    }
    heartbeatFbsPrintStation(stationId, body, user) {
        return this.connections.heartbeatFbsPrintStation(stationId, body?.error, user);
    }
    claimFbsPrintJob(stationId, user) {
        return this.connections.claimFbsPrintJob(stationId, user);
    }
    finishFbsPrintJob(jobId, body, user) {
        return this.connections.finishFbsPrintJob(jobId, body?.success === true, body?.error, user);
    }
    create(dto, user) {
        return this.connections.create(dto, user);
    }
    update(id, dto, user) {
        return this.connections.update(id, dto, user);
    }
    delete(id, user) {
        return this.connections.delete(id, user);
    }
    syncProducts(id, user) {
        return this.connections.syncProducts(id, user);
    }
    checkConnection(id, user) {
        return this.connections.checkConnection(id, user);
    }
};
exports.MarketplaceConnectionsController = MarketplaceConnectionsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('dbs/integrations'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('marketplace')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listDbsIntegrations", null);
__decorate([
    (0, common_1.Post)('dbs/integrations'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_dbs_integration_dto_1.UpsertDbsIntegrationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createDbsIntegration", null);
__decorate([
    (0, common_1.Patch)('dbs/integrations/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_dbs_integration_dto_1.UpdateDbsIntegrationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateDbsIntegration", null);
__decorate([
    (0, common_1.Post)('dbs/integrations/:id/check'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "checkDbsIntegration", null);
__decorate([
    (0, common_1.Post)('fbs/requests/:requestId/orders/:taskId/account-by-wb'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('client-requests:write', 'system:admin'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, common_1.Param)('taskId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, fbs_wb_accounting_1.AccountFbsOrderByWbDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "accountFbsOrderByWb", null);
__decorate([
    (0, common_1.Get)('fbs/orders'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('refresh')),
    __param(3, (0, common_1.Query)('view')),
    __param(4, (0, common_1.Query)('allBranches')),
    __param(5, (0, common_1.Query)('displayWarehouseId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "listFbsOrders", null);
__decorate([
    (0, common_1.Get)('fbs/delivery-recovery'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "checkFbsBranchDeliveryRecovery", null);
__decorate([
    (0, common_1.Post)('fbs/delivery-recovery/request'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createFbsDeliveryRecoveryRequest", null);
__decorate([
    (0, common_1.Get)('fbs/packed-items'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('marketplace')),
    __param(3, (0, common_1.Query)('dateFrom')),
    __param(4, (0, common_1.Query)('dateTo')),
    __param(5, (0, common_1.Query)('search')),
    __param(6, (0, common_1.Query)('requiresKiz')),
    __param(7, (0, common_1.Query)('page')),
    __param(8, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsPackedItems", null);
__decorate([
    (0, common_1.Post)('fbs/packed-items/reconcile'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "reconcileFbsPackedItems", null);
__decorate([
    (0, common_1.Get)('fbs/product-shipments-report'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('dateFrom')),
    __param(3, (0, common_1.Query)('dateTo')),
    __param(4, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "productShipments", null);
__decorate([
    (0, common_1.Get)('fbs/product-shipments-report.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __param(2, (0, common_1.Query)('clientId')),
    __param(3, (0, common_1.Query)('dateFrom')),
    __param(4, (0, common_1.Query)('dateTo')),
    __param(5, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String, String, String, String]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "productShipmentsXlsx", null);
__decorate([
    (0, common_1.Get)('fbs/penalties-report'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('connectionId')),
    __param(3, (0, common_1.Query)('dateFrom')),
    __param(4, (0, common_1.Query)('dateTo')),
    __param(5, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "penalties", null);
__decorate([
    (0, common_1.Get)('fbs/penalties-report.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __param(2, (0, common_1.Query)('clientId')),
    __param(3, (0, common_1.Query)('connectionId')),
    __param(4, (0, common_1.Query)('dateFrom')),
    __param(5, (0, common_1.Query)('dateTo')),
    __param(6, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "penaltiesXlsx", null);
__decorate([
    (0, common_1.Get)('fbs/relabel-reconciliation'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('dateFrom')),
    __param(3, (0, common_1.Query)('dateTo')),
    __param(4, (0, common_1.Query)('barcode')),
    __param(5, (0, common_1.Query)('refreshWb')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsRelabelReconciliation", null);
__decorate([
    (0, common_1.Post)('fbs/relabel-reconciliation/apply'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [apply_fbs_relabel_reconciliation_dto_1.ApplyFbsRelabelReconciliationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "applyFbsRelabelReconciliation", null);
__decorate([
    (0, common_1.Get)('fbs/active-clients'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('marketplace')),
    __param(2, (0, common_1.Query)('view')),
    __param(3, (0, common_1.Query)('allBranches')),
    __param(4, (0, common_1.Query)('displayWarehouseId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsActiveClients", null);
__decorate([
    (0, common_1.Get)('fbs/cargo-packings'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsCargoPackings", null);
__decorate([
    (0, common_1.Patch)('fbs/cargo-packings/:planId/ignore'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('planId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_fbs_cargo_packing_ignore_dto_1.UpdateFbsCargoPackingIgnoreDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsCargoPackingIgnore", null);
__decorate([
    (0, common_1.Get)('fbs/stocks'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('connectionId')),
    __param(3, (0, common_1.Query)('warehouseId')),
    __param(4, (0, common_1.Query)('refresh')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsStocks", null);
__decorate([
    (0, common_1.Get)('fbs/stock-monitor'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('connectionId')),
    __param(3, (0, common_1.Query)('warehouseId')),
    __param(4, (0, common_1.Query)('status')),
    __param(5, (0, common_1.Query)('system')),
    __param(6, (0, common_1.Query)('product')),
    __param(7, (0, common_1.Query)('q')),
    __param(8, (0, common_1.Query)('dateFrom')),
    __param(9, (0, common_1.Query)('dateTo')),
    __param(10, (0, common_1.Query)('sort')),
    __param(11, (0, common_1.Query)('direction')),
    __param(12, (0, common_1.Query)('page')),
    __param(13, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String, String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsStockMonitor", null);
__decorate([
    (0, common_1.Get)('fbs/stock-monitor/wms-stocks.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Res)({ passthrough: true })),
    __param(2, (0, common_1.Query)('clientId')),
    __param(3, (0, common_1.Query)('warehouseId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, String, String]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "exportFbsStockMonitorWmsStocks", null);
__decorate([
    (0, common_1.Get)('fbs/stock-monitor/events/:eventId'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('eventId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "getFbsStockMonitorEvent", null);
__decorate([
    (0, common_1.Get)('fbs/stock-monitor/config/:connectionId'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('connectionId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "getFbsStockMonitorConfig", null);
__decorate([
    (0, common_1.Put)('fbs/stock-monitor/config/:connectionId'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('connectionId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, fbs_stock_monitoring_dto_1.UpdateFbsStockMonitorConfigDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsStockMonitorConfig", null);
__decorate([
    (0, common_1.Post)('fbs/stock-monitor/refresh'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_monitoring_dto_1.RefreshFbsStockMonitorDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "refreshFbsStockMonitor", null);
__decorate([
    (0, common_1.Post)('fbs/stock-monitor/events/:eventId/repair-preview'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('eventId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "previewFbsStockMonitorRepair", null);
__decorate([
    (0, common_1.Post)('fbs/stock-monitor/events/:eventId/repair'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('eventId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, fbs_stock_monitoring_dto_1.RepairFbsStockMonitorDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "repairFbsStockMonitor", null);
__decorate([
    (0, common_1.Put)('fbs/stocks/publication'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_publication_dto_1.FbsStockPublicationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsStockPublication", null);
__decorate([
    (0, common_1.Post)('fbs/stocks/reconcile-item'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [reconcile_fbs_stock_item_dto_1.ReconcileFbsStockItemDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "reconcileFbsStockItem", null);
__decorate([
    (0, common_1.Put)('fbs/stocks/publication/bulk'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_publication_bulk_dto_1.FbsStockPublicationBulkDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsStockPublicationBulk", null);
__decorate([
    (0, common_1.Post)('fbs/stocks/sync'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_sync_dto_1.FbsStockSyncDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "syncFbsStocks", null);
__decorate([
    (0, common_1.Put)('fbs/stocks/warehouse'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_sync_dto_1.FbsStockSyncDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "connectFbsStockWarehouse", null);
__decorate([
    (0, common_1.Get)('fbs/stocks/allocation'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('connectionId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsStockAllocation", null);
__decorate([
    (0, common_1.Put)('fbs/stocks/allocation'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_allocation_dto_1.UpdateFbsStockAllocationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsStockAllocation", null);
__decorate([
    (0, common_1.Post)('fbs/stocks/allocation/sync'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_allocation_dto_1.SyncFbsStockAllocationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "syncFbsStockAllocation", null);
__decorate([
    (0, common_1.Post)('fbs/stocks/allocation/check'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_allocation_dto_1.SyncFbsStockAllocationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "checkFbsStockPublication", null);
__decorate([
    (0, common_1.Post)('fbs/stocks/allocation/api-keys'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_stock_allocation_dto_1.CreateFbsStockIntegrationKeyDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createFbsStockIntegrationKey", null);
__decorate([
    (0, common_1.Delete)('fbs/stocks/allocation/api-keys/:keyId'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('keyId')),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "revokeFbsStockIntegrationKey", null);
__decorate([
    (0, common_1.Post)('fbs/stocks/allocation/changes/:changeId/acknowledge'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('changeId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "acknowledgeFbsStockAllocationChange", null);
__decorate([
    (0, common_1.Get)(':id/fbs-warehouse-routes'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsWarehouseRoutes", null);
__decorate([
    (0, common_1.Put)(':id/fbs-warehouse-routes'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_fbs_warehouse_routes_dto_1.UpdateFbsWarehouseRoutesDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsWarehouseRoutes", null);
__decorate([
    (0, common_1.Post)('fbs/orders/assemble'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "assembleFbsOrders", null);
__decorate([
    (0, common_1.Post)('fbs/orders/reship'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "reshipFbsOrders", null);
__decorate([
    (0, common_1.Post)('fbs/orders/move-to-new-supply'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "moveFbsOrdersToNewSupply", null);
__decorate([
    (0, common_1.Post)('fbs/orders/repair-move-to-new-supply'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "repairFbsOrdersMove", null);
__decorate([
    (0, common_1.Post)('fbs/orders/cancel'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "cancelFbsOrders", null);
__decorate([
    (0, common_1.Post)('fbs/orders/remove-cancelled'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "removeCancelledFbsOrder", null);
__decorate([
    (0, common_1.Post)('fbs/supplies/deliver'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "deliverFbsSupplies", null);
__decorate([
    (0, common_1.Post)('fbs/supplies/delivery-options'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "getFbsSupplyDeliveryOptions", null);
__decorate([
    (0, common_1.Post)('fbs/supplies/change-destination'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "changeFbsSuppliesDestination", null);
__decorate([
    (0, common_1.Post)('fbs/orders/request'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createFbsRequest", null);
__decorate([
    (0, common_1.Post)('fbs/supplies/request'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_supply_request_dto_1.FbsSupplyRequestDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createFbsRequestFromSupply", null);
__decorate([
    (0, common_1.Post)('fbs/supplies/request-audit'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_supply_request_audit_dto_1.FbsSupplyRequestAuditDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "auditFbsSupplyRequests", null);
__decorate([
    (0, common_1.Post)('fbs/supplies/reconciliation/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_supply_reconciliation_dto_1.FbsSupplyReconciliationPreviewDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "previewFbsSupplyReconciliation", null);
__decorate([
    (0, common_1.Post)('fbs/supplies/reconciliation/apply'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_supply_reconciliation_dto_1.ApplyFbsSupplyReconciliationDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "applyFbsSupplyReconciliation", null);
__decorate([
    (0, common_1.Post)('fbs/requests/:requestId/emergency-assembly'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "enableFbsEmergencyAssembly", null);
__decorate([
    (0, common_1.Post)('fbs/requests/:requestId/remaining-search'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "enableFbsRemainingSearch", null);
__decorate([
    (0, common_1.Post)('fbs/requests/:requestId/repair-selection'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "repairFbsRequestSelection", null);
__decorate([
    (0, common_1.Get)('fbs/requests/:requestId/route'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "getFbsRequestRoute", null);
__decorate([
    (0, common_1.Post)('fbs/requests/:requestId/route/rebuild'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "rebuildFbsRequestRoute", null);
__decorate([
    (0, common_1.Get)('fbs/requests/:requestId/supply-consistency'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "checkFbsRequestSupplyConsistency", null);
__decorate([
    (0, common_1.Post)('fbs/requests/:requestId/supply-consistency/repair'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "repairFbsRequestSupplyConsistency", null);
__decorate([
    (0, common_1.Post)('fbs/orders/stickers.pdf'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object, Object]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "getFbsOrderStickersPdf", null);
__decorate([
    (0, common_1.Post)('fbs/orders/deadline-report.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object, Object]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "exportFbsDeadlineSelectedOrders", null);
__decorate([
    (0, common_1.Post)('fbs/orders/cancelled-report.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:read'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_cancelled_orders_report_dto_1.FbsCancelledOrdersReportDto, Object, Object]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "exportFbsCancelledOrders", null);
__decorate([
    (0, common_1.Post)('fbs/orders/cargo-place-stickers.pdf'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object, Object]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "getFbsCargoPlaceStickersPdf", null);
__decorate([
    (0, common_1.Post)('fbs/orders/supply-stickers.pdf'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_order_selection_dto_1.FbsOrderSelectionDto, Object, Object]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "getFbsSupplyStickersPdf", null);
__decorate([
    (0, common_1.Get)('fbs/requests/:requestId/pick-list.pdf'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('requestId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], MarketplaceConnectionsController.prototype, "getFbsRequestPickListPdf", null);
__decorate([
    (0, common_1.Post)('fbs/connections')
    // FIX: клиентский API-менеджер может подключать только кабинет из своего client scope.
    ,
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'marketplace-api:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_marketplace_connection_dto_1.UpsertMarketplaceConnectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createFbsConnection", null);
__decorate([
    (0, common_1.Get)('fbs/passes'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('connectionId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsPasses", null);
__decorate([
    (0, common_1.Post)('fbs/passes'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fbs_pass_dto_1.FbsPassDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createFbsPass", null);
__decorate([
    (0, common_1.Put)('fbs/passes/:passId'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('passId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, fbs_pass_dto_1.FbsPassDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsPass", null);
__decorate([
    (0, common_1.Delete)('fbs/passes/:passId'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('passId')),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('connectionId')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "deleteFbsPass", null);
__decorate([
    (0, common_1.Get)('fbs/calculator/destinations'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsCalculatorDestinations", null);
__decorate([
    (0, common_1.Post)('fbs/calculator/quote'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [quote_fbs_calculator_dto_1.QuoteFbsCalculatorDto]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "quoteFbsCalculator", null);
__decorate([
    (0, common_1.Get)('fbs/billing-settings/:clientId'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "getFbsBillingSettings", null);
__decorate([
    (0, common_1.Put)('fbs/billing-settings/:clientId'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_fbs_billing_settings_dto_1.UpdateFbsBillingSettingsDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "updateFbsBillingSettings", null);
__decorate([
    (0, common_1.Post)('fbs/web-order-assembly/scan'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "scanWebOrderAssembly", null);
__decorate([
    (0, common_1.Get)('fbs/sos/requests'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listSosWbRequests", null);
__decorate([
    (0, common_1.Post)('fbs/sos/claim'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "claimSosWbOrder", null);
__decorate([
    (0, common_1.Post)('fbs/sos/tasks/:taskId/kiz'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('taskId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "acceptSosWbKiz", null);
__decorate([
    (0, common_1.Post)('fbs/sos/tasks/:taskId/release'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('taskId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "releaseSosWbOrder", null);
__decorate([
    (0, common_1.Get)('fbs/web-order-assembly/history'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "webOrderAssemblyHistory", null);
__decorate([
    (0, common_1.Post)('fbs/web-order-assembly/history/:id/reprint'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "reprintWebOrderAssemblyHistory", null);
__decorate([
    (0, common_1.Delete)('fbs/web-order-assembly/history/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "deleteWebOrderAssemblyHistory", null);
__decorate([
    (0, common_1.Get)('fbs/print-stations'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "listFbsPrintStations", null);
__decorate([
    (0, common_1.Post)('fbs/print-stations'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "createFbsPrintStation", null);
__decorate([
    (0, common_1.Delete)('fbs/print-stations/:stationId'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('stationId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "deleteFbsPrintStation", null);
__decorate([
    (0, common_1.Post)('fbs/print-stations/:stationId/heartbeat'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('stationId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "heartbeatFbsPrintStation", null);
__decorate([
    (0, common_1.Post)('fbs/print-stations/:stationId/claim'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('stationId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "claimFbsPrintJob", null);
__decorate([
    (0, common_1.Post)('fbs/print-jobs/:jobId/result'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('jobId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "finishFbsPrintJob", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'marketplace-api:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_marketplace_connection_dto_1.UpsertMarketplaceConnectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'marketplace-api:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_marketplace_connection_dto_1.UpdateMarketplaceConnectionDto, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'marketplace-api:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "delete", null);
__decorate([
    (0, common_1.Post)(':id/sync-products'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'marketplace-api:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "syncProducts", null);
__decorate([
    (0, common_1.Post)(':id/check'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('clients:write', 'marketplace-api:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MarketplaceConnectionsController.prototype, "checkConnection", null);
exports.MarketplaceConnectionsController = MarketplaceConnectionsController = __decorate([
    (0, swagger_1.ApiTags)('marketplace-connections'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:read'),
    (0, common_1.Controller)(['marketplace-connections', 'marketplace-connection']),
    __metadata("design:paramtypes", [marketplace_connections_service_1.MarketplaceConnectionsService,
        logistics_service_1.LogisticsService,
        fbs_product_shipments_report_service_1.FbsProductShipmentsReportService,
        fbs_penalties_report_service_1.FbsPenaltiesReportService,
        fbs_stock_monitoring_service_1.FbsStockMonitoringService,
        fbs_reshipment_service_1.FbsReshipmentService])
], MarketplaceConnectionsController);
