"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadFbsDateBillingBranches = loadFbsDateBillingBranches;
exports.branchScopedFbsDateKey = branchScopedFbsDateKey;
const common_1 = require("@nestjs/common");
const wb_order_stock_lifecycle_1 = require("../../common/stock/wb-order-stock-lifecycle");
const isDateGroup = (order) => !order.supplyId?.trim() &&
    Boolean(order.deliveryDate || order.sellerDate || order.createdAt);
// FIX: opt-in only; legacy order/service credits must remain enabled during rollout.
async function loadFbsDateBillingBranches(db, clientId, orders, legacyKey) {
    if (process.env.WMS_FBS_DATE_BRANCH_BILLING_ENABLED !== 'true' || !(0, wb_order_stock_lifecycle_1.wbOrderStockLifecycleEnabled)())
        return undefined;
    const keys = [...new Set(orders.filter(isDateGroup).map(order => legacyKey(order)))];
    const branches = new Map();
    if (!keys.length)
        return branches;
    const invoiceKeys = new Map(keys.flatMap(key => [
        [`fbs-invoice:${clientId}:${key}`, key], [`fbs-primary-invoice:${clientId}:${key}`, key],
    ]));
    const chargeKeys = new Map(keys.map(key => [`fbs-calculator:${clientId}:${key}`, key]));
    const primaryPrefixes = keys.map(key => ({ key, prefix: `fbs-primary:${clientId}:${key}:` }));
    const [invoices, charges] = await Promise.all([
        db.billingInvoice.findMany({ where: { clientId, sourceKey: { in: [...invoiceKeys.keys()] } },
            select: { sourceKey: true, warehouseId: true } }),
        db.billingCharge.findMany({ where: { clientId, OR: [
                    { sourceKey: { in: [...chargeKeys.keys()] } },
                    ...primaryPrefixes.map(p => ({ sourceKey: { startsWith: p.prefix } })),
                ] }, select: { sourceKey: true, metadata: true, request: { select: { warehouseId: true } },
                invoiceItems: { select: { invoice: { select: { warehouseId: true } } } } } }),
    ]);
    // FIX: old grouped charges stored several request IDs in their immutable FBS snapshot.
    // Resolve every saved request within the same client; partial evidence must not choose a branch.
    const savedRequestIds = (metadata) => {
        if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata))
            return [];
        const value = metadata;
        if (value.kind !== 'FBS' || !Array.isArray(value.requestIds) ||
            !value.requestIds.length || value.requestIds.some(id => typeof id !== 'string' || !id.trim()))
            return [];
        return [...new Set(value.requestIds)];
    };
    const fallbackCharges = charges.filter(charge => !charge.request?.warehouseId &&
        !charge.invoiceItems.some(item => item.invoice.warehouseId));
    const requestIds = [...new Set(fallbackCharges.flatMap(charge => savedRequestIds(charge.metadata)))];
    const requests = requestIds.length ? await db.clientRequest.findMany({
        where: { clientId, id: { in: requestIds } }, select: { id: true, warehouseId: true },
    }) : [];
    const requestBranches = new Map(requests.map(request => [request.id, request.warehouseId]));
    const incomplete = new Set();
    const evidence = new Map();
    const add = (key, ids) => {
        if (!key)
            return;
        const found = evidence.get(key) ?? new Set();
        for (const id of ids)
            if (id?.trim())
                found.add(id.trim());
        evidence.set(key, found);
    };
    for (const invoice of invoices)
        add(invoiceKeys.get(invoice.sourceKey ?? ''), [invoice.warehouseId]);
    for (const charge of charges) {
        const key = chargeKeys.get(charge.sourceKey ?? '') ??
            primaryPrefixes.find(p => charge.sourceKey?.startsWith(p.prefix) &&
                /^(SERVICE:.+|WHITE|GRAY|RETURN|RELABEL)$/.test(charge.sourceKey.slice(p.prefix.length)))?.key;
        add(key, [charge.request?.warehouseId, ...charge.invoiceItems.map(i => i.invoice.warehouseId)]);
        if (key && fallbackCharges.includes(charge)) {
            const saved = savedRequestIds(charge.metadata);
            if (saved.length) {
                if (saved.some(id => !requestBranches.get(id)?.trim()))
                    incomplete.add(key);
                add(key, saved.map(id => requestBranches.get(id)));
            }
        }
    }
    // FIX: even cancelled/merged documents retain their keys; never guess a branch for old money.
    for (const [key, ids] of evidence) {
        if (ids.size !== 1 || incomplete.has(key))
            throw new common_1.BadRequestException(`Не удалось однозначно определить филиал старого начисления FBS (${key}). Требуется проверка счёта; повторное начисление не выполнено.`);
        branches.set(key, [...ids][0]);
    }
    // FIX: an old order may lose its live request after shipment. Reuse only its recorded FBS snapshot.
    for (const charge of charges) {
        const key = chargeKeys.get(charge.sourceKey ?? '');
        const metadata = charge.metadata;
        if (!key || !metadata || typeof metadata !== 'object' || Array.isArray(metadata) ||
            metadata.kind !== 'FBS' || !Array.isArray(metadata.orderIds))
            continue;
        const branch = branches.get(key);
        if (branch)
            for (const id of metadata.orderIds)
                if (typeof id === 'string')
                    branches.set(`${key}\0${id}`, branch);
    }
    return branches;
}
// FIX: date is not a supply identity. Keep the legacy key only for its proven original branch.
function branchScopedFbsDateKey(legacyKey, order, branches) {
    if (!branches || !isDateGroup(order))
        return legacyKey;
    const warehouseId = order.request?.warehouseId?.trim() || order.reservation?.warehouseId?.trim();
    const oldBranch = branches.get(legacyKey);
    if (!warehouseId) {
        if (oldBranch && branches.get(`${legacyKey}\0${order.id}`) !== oldBranch)
            throw new common_1.BadRequestException('Не определён филиал заказа для существующего счёта FBS. Повторное начисление не выполнено.');
        return legacyKey;
    }
    return oldBranch === warehouseId ? legacyKey : `${legacyKey}:warehouse:${warehouseId}`;
}
