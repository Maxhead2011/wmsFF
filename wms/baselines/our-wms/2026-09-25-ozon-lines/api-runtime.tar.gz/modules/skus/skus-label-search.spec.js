"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const skus_service_1 = require("./skus.service");
// TEST: a marketplace article must be searchable when choosing a label to print.
(0, vitest_1.describe)('SKU label lookup', () => {
    (0, vitest_1.it)('searches substrings of article, name, and barcode within the selected client scope', async () => {
        const findMany = vitest_1.vi.fn().mockResolvedValue([]);
        const prisma = { sku: { findMany } };
        const scopes = { resolveClientFilter: vitest_1.vi.fn().mockReturnValue('client-1') };
        const service = new skus_service_1.SkusService(prisma, scopes, {});
        await service.list({ clientId: 'client-1', search: 'спорт_синий' }, { warehouseId: null });
        (0, vitest_1.expect)(findMany).toHaveBeenCalledWith(vitest_1.expect.objectContaining({ where: vitest_1.expect.objectContaining({
                clientId: 'client-1', OR: vitest_1.expect.arrayContaining([
                    { article: { contains: 'спорт_синий', mode: 'insensitive' } },
                    { name: { contains: 'спорт_синий', mode: 'insensitive' } },
                    { barcodes: { some: { value: { contains: 'спорт_синий' } } } },
                ]),
            }) }));
    });
});
