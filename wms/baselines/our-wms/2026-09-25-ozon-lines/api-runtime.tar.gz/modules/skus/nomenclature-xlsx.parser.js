"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseNomenclatureSheet = parseNomenclatureSheet;
const MISSING_COLUMN = -1;
const DEFAULT_COLUMNS = {
    name: 0,
    printName: 3,
    article: 1,
    barcode: MISSING_COLUMN,
    unit: 2,
    itemType: 4,
    color: MISSING_COLUMN,
    size: MISSING_COLUMN,
};
function parseNomenclatureSheet(rows, _options = {}) {
    const items = [];
    const issues = [];
    const columns = detectColumns(rows);
    const seenKeys = new Set();
    rows.forEach((row, index) => {
        const sourceRow = index + 1;
        if (looksLikeHeader(row)) {
            return;
        }
        const name = valueAt(row, columns.name) || valueAt(row, columns.printName);
        const article = valueAt(row, columns.article);
        const barcode = valueAt(row, columns.barcode);
        const printName = valueAt(row, columns.printName);
        const unit = valueAt(row, columns.unit);
        const itemType = valueAt(row, columns.itemType);
        const color = valueAt(row, columns.color);
        const size = valueAt(row, columns.size);
        if (!name && !article && !barcode) {
            return;
        }
        if (!name) {
            issues.push({
                row: sourceRow,
                message: 'Не заполнено наименование товара.',
                severity: 'error',
            });
            return;
        }
        const internalSku = buildInternalSku(article || barcode || name);
        const dedupeKey = `${internalSku}|${barcode}`;
        if (seenKeys.has(dedupeKey)) {
            issues.push({
                row: sourceRow,
                internalSku,
                name,
                message: 'Дубль номенклатуры в файле, строка пропущена.',
                severity: 'warning',
            });
            return;
        }
        seenKeys.add(dedupeKey);
        items.push({
            internalSku,
            article: article || undefined,
            barcode: barcode || undefined,
            name,
            printName: printName || undefined,
            unit: unit || undefined,
            itemType: itemType || undefined,
            color: color || undefined,
            size: size || undefined,
            sourceRow,
        });
    });
    return {
        items,
        issues,
        summary: {
            sourceRows: Math.max(rows.length - 1, 0),
            rows: items.length,
            barcodes: new Set(items.map((item) => item.barcode).filter(Boolean)).size,
        },
    };
}
function detectColumns(rows) {
    for (const row of rows) {
        const normalized = row.map((cell) => normalizeHeader(text(cell)));
        if (!normalized.some((cell) => cell.includes('наименование') || cell.includes('номенклатура'))) {
            continue;
        }
        return {
            name: findColumn(normalized, ['наименование', 'номенклатура', 'товар', 'название']) ?? DEFAULT_COLUMNS.name,
            printName: findColumn(normalized, ['наименование для печати', 'печати']) ?? DEFAULT_COLUMNS.printName,
            article: findColumn(normalized, ['артикул', 'код', 'внутренний sku']) ?? DEFAULT_COLUMNS.article,
            barcode: findColumn(normalized, ['штрихкод', 'штрих код', 'баркод', 'шк']) ?? DEFAULT_COLUMNS.barcode,
            unit: findColumn(normalized, ['единица хранения', 'единица', 'ед']) ?? DEFAULT_COLUMNS.unit,
            itemType: findColumn(normalized, ['тип номенклатуры', 'тип']) ?? DEFAULT_COLUMNS.itemType,
            color: findColumn(normalized, ['цвет']) ?? DEFAULT_COLUMNS.color,
            size: findColumn(normalized, ['размер']) ?? DEFAULT_COLUMNS.size,
        };
    }
    return DEFAULT_COLUMNS;
}
function findColumn(cells, needles) {
    const index = cells.findIndex((cell) => needles.some((needle) => cell.includes(needle)));
    return index >= 0 ? index : undefined;
}
function looksLikeHeader(row) {
    const normalized = row.map((cell) => normalizeHeader(text(cell)));
    return normalized.some((cell) => cell.includes('наименование')) && normalized.some((cell) => cell.includes('артикул'));
}
function valueAt(row, index) {
    if (index < 0) {
        return '';
    }
    return cleanText(row[index]);
}
function cleanText(value) {
    const normalized = text(value);
    if (!normalized || normalized === '#N/A' || normalized.toUpperCase() === 'N/A') {
        return '';
    }
    return normalized;
}
function text(value) {
    return value == null ? '' : String(value).trim();
}
function normalizeHeader(value) {
    return value.toLowerCase().replace(/\s+/g, ' ').trim();
}
function buildInternalSku(value) {
    const compact = value.replace(/\s+/g, ' ').trim();
    if (compact.length <= 100) {
        return compact;
    }
    return `${compact.slice(0, 83)}-${hashText(compact)}`;
}
function hashText(value) {
    let hash = 0;
    for (let index = 0; index < value.length; index += 1) {
        hash = (hash * 31 + value.charCodeAt(index)) >>> 0;
    }
    return hash.toString(36).toUpperCase().padStart(6, '0').slice(0, 6);
}
