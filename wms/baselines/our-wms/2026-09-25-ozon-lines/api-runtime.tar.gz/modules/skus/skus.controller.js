"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkusController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const bulk_update_sku_volume_dto_1 = require("./dto/bulk-update-sku-volume.dto");
const create_article_mapping_dto_1 = require("./dto/create-article-mapping.dto");
const create_nomenclature_item_dto_1 = require("./dto/create-nomenclature-item.dto");
const create_sku_dto_1 = require("./dto/create-sku.dto");
const update_sku_dto_1 = require("./dto/update-sku.dto");
const skus_service_1 = require("./skus.service");
let SkusController = class SkusController {
    skus;
    constructor(skus) {
        this.skus = skus;
    }
    list(user, clientId, search, draftsOnly) {
        return this.skus.list({ clientId, search, draftsOnly: draftsOnly === 'true' }, user);
    }
    listNomenclature(search) {
        return this.skus.listNomenclature({ search });
    }
    createNomenclature(dto, user) {
        return this.skus.createNomenclature(dto, user);
    }
    updateNomenclature(id, dto, user) {
        return this.skus.updateNomenclature(id, dto, user);
    }
    importNomenclatureXlsx(file, user) {
        return this.skus.importNomenclatureWorkbook(file, user);
    }
    listArticleMappings(user, clientId) {
        return this.skus.listArticleMappings(clientId, user);
    }
    createArticleMapping(dto, user) {
        return this.skus.createArticleMapping(dto, user);
    }
    importArticleMappingsXlsx(file, clientId, user) {
        return this.skus.importArticleMappingsWorkbook(clientId, file, user);
    }
    deleteArticleMapping(id, user) {
        return this.skus.deleteArticleMapping(id, user);
    }
    listBulkVolume(user, clientId, sourceVolumeFrom, sourceVolumeTo) {
        return this.skus.listBulkVolume({ clientId, sourceVolumeFrom, sourceVolumeTo }, user);
    }
    updateBulkVolume(dto, user) {
        return this.skus.updateBulkVolume(dto, user);
    }
    get(id, user) {
        return this.skus.get(id, user);
    }
    update(id, dto, user) {
        return this.skus.update(id, dto, user);
    }
    delete(id, user) {
        return this.skus.delete(id, user);
    }
    create(dto, user) {
        return this.skus.create(dto, user);
    }
    importXlsx(file, user) {
        return this.skus.importNomenclatureWorkbook(file, user);
    }
};
exports.SkusController = SkusController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('search')),
    __param(3, (0, common_1.Query)('draftsOnly')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('nomenclature'),
    __param(0, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "listNomenclature", null);
__decorate([
    (0, common_1.Post)('nomenclature'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_nomenclature_item_dto_1.CreateNomenclatureItemDto, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "createNomenclature", null);
__decorate([
    (0, common_1.Patch)('nomenclature/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_nomenclature_item_dto_1.CreateNomenclatureItemDto, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "updateNomenclature", null);
__decorate([
    (0, common_1.Post)('nomenclature/import-xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Excel-файл общей номенклатуры' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "importNomenclatureXlsx", null);
__decorate([
    (0, common_1.Get)('article-mappings'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "listArticleMappings", null);
__decorate([
    (0, common_1.Post)('article-mappings'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_article_mapping_dto_1.CreateArticleMappingDto, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "createArticleMapping", null);
__decorate([
    (0, common_1.Post)('article-mappings/import-xlsx'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Excel-файл соответствий артикула на складе и артикула продавца' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "importArticleMappingsXlsx", null);
__decorate([
    (0, common_1.Delete)('article-mappings/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "deleteArticleMapping", null);
__decorate([
    (0, common_1.Get)('bulk-volume'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('sourceVolumeFrom')),
    __param(3, (0, common_1.Query)('sourceVolumeTo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "listBulkVolume", null);
__decorate([
    (0, common_1.Patch)('bulk-volume'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_update_sku_volume_dto_1.BulkUpdateSkuVolumeDto, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "updateBulkVolume", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "get", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_sku_dto_1.UpdateSkuDto, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "delete", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_sku_dto_1.CreateSkuDto, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('import-xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Excel-файл общей номенклатуры' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], SkusController.prototype, "importXlsx", null);
exports.SkusController = SkusController = __decorate([
    (0, swagger_1.ApiTags)('skus'),
    (0, require_permissions_decorator_1.RequirePermissions)('skus:read'),
    (0, common_1.Controller)('skus'),
    __metadata("design:paramtypes", [skus_service_1.SkusService])
], SkusController);
