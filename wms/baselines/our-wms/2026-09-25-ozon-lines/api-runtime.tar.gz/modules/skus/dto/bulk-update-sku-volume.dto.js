"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BulkUpdateSkuVolumeDto = void 0;
const class_validator_1 = require("class-validator");
class BulkUpdateSkuVolumeDto {
    clientId;
    sourceVolumeFrom;
    sourceVolumeTo;
    skuIds;
    newVolumeLiters;
}
exports.BulkUpdateSkuVolumeDto = BulkUpdateSkuVolumeDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(1, 100),
    __metadata("design:type", String)
], BulkUpdateSkuVolumeDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsNumber)({ maxDecimalPlaces: 3 }),
    (0, class_validator_1.Min)(0.001),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], BulkUpdateSkuVolumeDto.prototype, "sourceVolumeFrom", void 0);
__decorate([
    (0, class_validator_1.IsNumber)({ maxDecimalPlaces: 3 }),
    (0, class_validator_1.Min)(0.001),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], BulkUpdateSkuVolumeDto.prototype, "sourceVolumeTo", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(5000),
    (0, class_validator_1.IsUUID)('4', { each: true }),
    __metadata("design:type", Array)
], BulkUpdateSkuVolumeDto.prototype, "skuIds", void 0);
__decorate([
    (0, class_validator_1.IsNumber)({ maxDecimalPlaces: 3 }),
    (0, class_validator_1.Min)(0.001),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], BulkUpdateSkuVolumeDto.prototype, "newVolumeLiters", void 0);
