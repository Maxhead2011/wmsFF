"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientNotificationsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const client_notifications_service_1 = require("./client-notifications.service");
const create_client_notification_dto_1 = require("./dto/create-client-notification.dto");
const list_client_notification_preferences_dto_1 = require("./dto/list-client-notification-preferences.dto");
const list_client_notifications_dto_1 = require("./dto/list-client-notifications.dto");
const update_client_notification_preference_dto_1 = require("./dto/update-client-notification-preference.dto");
let ClientNotificationsController = class ClientNotificationsController {
    notifications;
    constructor(notifications) {
        this.notifications = notifications;
    }
    list(query, user) {
        return this.notifications.list(query, user);
    }
    listPreferences(query, user) {
        return this.notifications.listPreferences(query, user);
    }
    getTelegramSettings(clientId, user) {
        return this.notifications.getTelegramSettings(clientId, user);
    }
    updateTelegramSettings(dto, user) {
        return this.notifications.updateTelegramSettings(dto, user);
    }
    updatePreference(dto, user) {
        return this.notifications.updatePreference(dto, user);
    }
    create(dto, user) {
        return this.notifications.create(dto, user);
    }
    markRead(id, user) {
        return this.notifications.markRead(id, user);
    }
};
exports.ClientNotificationsController = ClientNotificationsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_client_notifications_dto_1.ListClientNotificationsDto, Object]),
    __metadata("design:returntype", void 0)
], ClientNotificationsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('preferences'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_client_notification_preferences_dto_1.ListClientNotificationPreferencesDto, Object]),
    __metadata("design:returntype", void 0)
], ClientNotificationsController.prototype, "listPreferences", null);
__decorate([
    (0, common_1.Get)('telegram-settings'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ClientNotificationsController.prototype, "getTelegramSettings", null);
__decorate([
    (0, common_1.Patch)('telegram-settings'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ClientNotificationsController.prototype, "updateTelegramSettings", null);
__decorate([
    (0, common_1.Patch)('preferences'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [update_client_notification_preference_dto_1.UpdateClientNotificationPreferenceDto, Object]),
    __metadata("design:returntype", void 0)
], ClientNotificationsController.prototype, "updatePreference", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('client-notifications:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_client_notification_dto_1.CreateClientNotificationDto, Object]),
    __metadata("design:returntype", void 0)
], ClientNotificationsController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id/read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientNotificationsController.prototype, "markRead", null);
exports.ClientNotificationsController = ClientNotificationsController = __decorate([
    (0, swagger_1.ApiTags)('client-notifications'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-notifications:read'),
    (0, common_1.Controller)('client-notifications'),
    __metadata("design:paramtypes", [client_notifications_service_1.ClientNotificationsService])
], ClientNotificationsController);
