"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientNotificationsModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const client_notifications_controller_1 = require("./client-notifications.controller");
const client_notifications_service_1 = require("./client-notifications.service");
const telegram_notification_service_1 = require("./telegram-notification.service");
let ClientNotificationsModule = class ClientNotificationsModule {
};
exports.ClientNotificationsModule = ClientNotificationsModule;
exports.ClientNotificationsModule = ClientNotificationsModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule],
        controllers: [client_notifications_controller_1.ClientNotificationsController],
        providers: [client_notifications_service_1.ClientNotificationsService, telegram_notification_service_1.TelegramNotificationService],
        exports: [client_notifications_service_1.ClientNotificationsService, telegram_notification_service_1.TelegramNotificationService],
    })
], ClientNotificationsModule);
