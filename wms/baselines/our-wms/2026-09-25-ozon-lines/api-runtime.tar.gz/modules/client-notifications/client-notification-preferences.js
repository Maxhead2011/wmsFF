"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientNotificationEvents = void 0;
exports.isClientNotificationEnabled = isClientNotificationEnabled;
const client_1 = require("@prisma/client");
exports.clientNotificationEvents = [
    client_1.ClientNotificationEvent.REQUEST_STATUS_CHANGED,
    client_1.ClientNotificationEvent.REQUEST_FILE_UPLOADED,
    client_1.ClientNotificationEvent.REQUEST_COMMENT,
    client_1.ClientNotificationEvent.BILLING_INVOICE_STATUS_CHANGED,
    client_1.ClientNotificationEvent.BILLING_PAYMENT_RECORDED,
    client_1.ClientNotificationEvent.LOGISTICS_DELIVERY_STATUS_CHANGED,
    client_1.ClientNotificationEvent.MANUAL,
];
async function isClientNotificationEnabled(prisma, clientId, eventType) {
    const preference = await prisma.clientNotificationPreference.findUnique({
        where: {
            clientId_eventType: {
                clientId,
                eventType,
            },
        },
        select: {
            isEnabled: true,
        },
    });
    return preference?.isEnabled ?? true;
}
