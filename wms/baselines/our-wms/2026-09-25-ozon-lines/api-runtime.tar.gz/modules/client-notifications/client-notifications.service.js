"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientNotificationPreferenceInclude = exports.clientNotificationInclude = exports.ClientNotificationsService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_notification_preferences_1 = require("./client-notification-preferences");
const telegram_notification_service_1 = require("./telegram-notification.service");
let ClientNotificationsService = class ClientNotificationsService {
    prisma;
    clientScopes;
    telegram;
    constructor(prisma, clientScopes, telegram) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.telegram = telegram;
    }
    list(query, user) {
        const clientId = this.clientScopes.resolveClientFilter(user, query.clientId);
        const warehouseId = this.scopedWarehouseId(user);
        return this.prisma.clientNotification.findMany({
            where: {
                clientId,
                isRead: query.unreadOnly ? false : undefined,
                request: warehouseId ? { is: { warehouseId } } : undefined,
            },
            include: exports.clientNotificationInclude,
            orderBy: { createdAt: 'desc' },
            take: 100,
        });
    }
    async create(dto, user) {
        this.clientScopes.requireClientAccess(user, dto.clientId, 'write');
        const warehouseId = this.scopedWarehouseId(user);
        if (warehouseId && !dto.requestId) {
            throw new common_1.BadRequestException('Для уведомления филиала выберите заявку этого филиала.');
        }
        await this.ensureRequestBelongsToClient(dto.clientId, dto.requestId, warehouseId);
        await this.ensureNotificationEventEnabled(dto.clientId, client_1.ClientNotificationEvent.MANUAL);
        // Русский комментарий: уведомление видно клиенту сразу в кабинете, а статус read хранится отдельно от заявки.
        const notification = await this.prisma.clientNotification.create({
            data: {
                clientId: dto.clientId,
                requestId: normalizeText(dto.requestId),
                title: dto.title.trim(),
                body: normalizeText(dto.body),
                severity: dto.severity ?? 'INFO',
                createdByUserId: user.id,
            },
            include: exports.clientNotificationInclude,
        });
        void this.telegram.notifyClient(dto.clientId, telegramNotificationText(notification.title, notification.body));
        return notification;
    }
    async markRead(id, user) {
        const notification = await this.prisma.clientNotification.findUnique({
            where: { id },
            select: {
                id: true,
                clientId: true,
                isRead: true,
                request: { select: { warehouseId: true } },
            },
        });
        if (!notification) {
            throw new common_1.NotFoundException('Уведомление не найдено.');
        }
        this.clientScopes.requireClientAccess(user, notification.clientId, 'read');
        const warehouseId = this.scopedWarehouseId(user);
        if (warehouseId && notification.request?.warehouseId !== warehouseId) {
            throw new common_1.NotFoundException('Уведомление не найдено в выбранном филиале.');
        }
        if (notification.isRead) {
            return this.prisma.clientNotification.findUniqueOrThrow({
                where: { id },
                include: exports.clientNotificationInclude,
            });
        }
        return this.prisma.clientNotification.update({
            where: { id },
            data: {
                isRead: true,
                readAt: new Date(),
            },
            include: exports.clientNotificationInclude,
        });
    }
    async listPreferences(query, user) {
        const clientId = this.clientScopes.resolveClientFilter(user, query.clientId);
        const warehouseId = this.scopedWarehouseId(user);
        if (warehouseId) {
            await this.ensureBranchLocalClientFilter(clientId, warehouseId);
        }
        const [clients, preferences] = await Promise.all([
            this.prisma.client.findMany({
                where: { id: clientId },
                select: {
                    id: true,
                    code: true,
                    name: true,
                },
                orderBy: { code: 'asc' },
            }),
            this.prisma.clientNotificationPreference.findMany({
                where: { clientId },
                include: exports.clientNotificationPreferenceInclude,
            }),
        ]);
        const preferenceByClientAndEvent = new Map(preferences.map((preference) => [`${preference.clientId}:${preference.eventType}`, preference]));
        return clients.flatMap((client) => client_notification_preferences_1.clientNotificationEvents.map((eventType) => {
            const preference = preferenceByClientAndEvent.get(`${client.id}:${eventType}`);
            return {
                id: preference?.id ?? null,
                clientId: client.id,
                eventType,
                isEnabled: preference?.isEnabled ?? true,
                createdAt: preference?.createdAt ?? null,
                updatedAt: preference?.updatedAt ?? null,
                updatedBy: preference?.updatedBy ?? null,
                client,
            };
        }));
    }
    async updatePreference(dto, user) {
        this.clientScopes.requireClientAccess(user, dto.clientId, 'read');
        await this.ensureClientExists(dto.clientId);
        const warehouseId = this.scopedWarehouseId(user);
        if (warehouseId) {
            await this.ensureBranchLocalClient(dto.clientId, warehouseId);
        }
        return this.prisma.clientNotificationPreference.upsert({
            where: {
                clientId_eventType: {
                    clientId: dto.clientId,
                    eventType: dto.eventType,
                },
            },
            create: {
                clientId: dto.clientId,
                eventType: dto.eventType,
                isEnabled: dto.isEnabled,
                updatedByUserId: user.id,
            },
            update: {
                isEnabled: dto.isEnabled,
                updatedByUserId: user.id,
            },
            include: exports.clientNotificationPreferenceInclude,
        });
    }
    async getTelegramSettings(clientId, user) {
        const resolvedClientId = this.resolveWritableClientId(clientId, user, 'read');
        const warehouseId = this.scopedWarehouseId(user);
        if (warehouseId) {
            await this.ensureBranchLocalClient(resolvedClientId, warehouseId);
        }
        return this.telegram.getClientSettings(resolvedClientId);
    }
    async updateTelegramSettings(dto, user) {
        const clientId = this.resolveWritableClientId(dto.clientId, user, 'write');
        await this.ensureClientExists(clientId);
        const warehouseId = this.scopedWarehouseId(user);
        if (warehouseId) {
            await this.ensureBranchLocalClient(clientId, warehouseId);
        }
        const current = await this.telegram.getClientSettings(clientId);
        return this.telegram.updateClientSettings(clientId, {
            enabled: dto.enabled === true,
            chatId: dto.chatId ?? '',
            sections: current.sections,
        }, user);
    }
    async ensureRequestBelongsToClient(clientId, requestId, warehouseId) {
        if (!requestId) {
            return;
        }
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: { id: true, clientId: true, warehouseId: true },
        });
        if (!request || request.clientId !== clientId || (warehouseId && request.warehouseId !== warehouseId)) {
            throw new common_1.BadRequestException('Заявка не принадлежит выбранному клиенту.');
        }
    }
    scopedWarehouseId(user) {
        if (user.permissionCodes.includes('system:admin') || user.roleCodes.includes('CLIENT')) {
            return null;
        }
        if (!(user.warehouseIds?.length)) {
            return null;
        }
        const warehouseId = user.activeWarehouseId?.trim();
        if (!warehouseId || !user.warehouseIds.includes(warehouseId)) {
            throw new common_1.ForbiddenException('Не выбран доступный филиал.');
        }
        return warehouseId;
    }
    async ensureBranchLocalClient(clientId, warehouseId) {
        const client = await this.prisma.client.findFirst({
            where: {
                id: clientId,
                warehouseLinks: {
                    some: { warehouseId, status: 'ACTIVE' },
                    none: { status: 'ACTIVE', warehouseId: { not: warehouseId } },
                },
            },
            select: { id: true },
        });
        if (!client) {
            throw new common_1.ForbiddenException('Общие настройки клиента доступны только администратору сети.');
        }
    }
    async ensureBranchLocalClientFilter(clientId, warehouseId) {
        const ids = typeof clientId === 'string'
            ? [clientId]
            : clientId && 'in' in clientId && Array.isArray(clientId.in)
                ? clientId.in.filter((value) => typeof value === 'string')
                : [];
        for (const id of ids) {
            await this.ensureBranchLocalClient(id, warehouseId);
        }
    }
    async ensureClientExists(clientId) {
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { id: true },
        });
        if (!client) {
            throw new common_1.NotFoundException('Client not found.');
        }
    }
    resolveWritableClientId(clientId, user, mode) {
        if (clientId) {
            this.clientScopes.requireClientAccess(user, clientId, mode);
            return clientId;
        }
        const candidates = mode === 'write' ? user.writableClientIds : user.clientIds;
        if (candidates.length === 1) {
            return candidates[0];
        }
        throw new common_1.BadRequestException('Выберите клиента для настроек Telegram.');
    }
    async ensureNotificationEventEnabled(clientId, eventType) {
        if (await (0, client_notification_preferences_1.isClientNotificationEnabled)(this.prisma, clientId, eventType)) {
            return;
        }
        throw new common_1.BadRequestException('Notification event disabled by client.');
    }
};
exports.ClientNotificationsService = ClientNotificationsService;
exports.ClientNotificationsService = ClientNotificationsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        telegram_notification_service_1.TelegramNotificationService])
], ClientNotificationsService);
exports.clientNotificationInclude = {
    client: {
        select: {
            id: true,
            code: true,
            name: true,
        },
    },
    request: {
        select: {
            id: true,
            title: true,
            type: true,
            status: true,
        },
    },
    createdBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
};
exports.clientNotificationPreferenceInclude = {
    client: {
        select: {
            id: true,
            code: true,
            name: true,
        },
    },
    updatedBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
};
function normalizeText(value) {
    const normalized = value?.trim();
    return normalized ? normalized : undefined;
}
function telegramNotificationText(title, body) {
    return ['LOGOFF WMS: уведомление для клиента.', title, body ?? ''].filter(Boolean).join('\n');
}
