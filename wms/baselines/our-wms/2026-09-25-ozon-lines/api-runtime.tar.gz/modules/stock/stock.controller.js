"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const create_pick_wave_dto_1 = require("./dto/create-pick-wave.dto");
const fulfill_client_request_dto_1 = require("./dto/fulfill-client-request.dto");
const list_storage_overview_dto_1 = require("./dto/list-storage-overview.dto");
const list_pick_waves_dto_1 = require("./dto/list-pick-waves.dto");
const list_stock_balances_dto_1 = require("./dto/list-stock-balances.dto");
const pick_client_request_dto_1 = require("./dto/pick-client-request.dto");
const run_pick_wave_dto_1 = require("./dto/run-pick-wave.dto");
const transfer_between_boxes_dto_1 = require("./dto/transfer-between-boxes.dto");
const transfer_whole_box_dto_1 = require("./dto/transfer-whole-box.dto");
const update_storage_tariff_dto_1 = require("./dto/update-storage-tariff.dto");
const fulfillment_wave_service_1 = require("./fulfillment-wave.service");
const pick_instruction_service_1 = require("./pick-instruction.service");
const pick_wave_document_service_1 = require("./pick-wave-document.service");
const stock_balances_service_1 = require("./stock-balances.service");
const stock_operations_service_1 = require("./stock-operations.service");
const storage_overview_service_1 = require("./storage-overview.service");
let StockController = class StockController {
    balances;
    operations;
    waves;
    waveDocuments;
    pickInstructions;
    storageOverview;
    constructor(balances, operations, waves, waveDocuments, pickInstructions, storageOverview) {
        this.balances = balances;
        this.operations = operations;
        this.waves = waves;
        this.waveDocuments = waveDocuments;
        this.pickInstructions = pickInstructions;
        this.storageOverview = storageOverview;
    }
    listBalances(query, user) {
        return this.balances.list(query, user);
    }
    listStorage(query, user) {
        return this.storageOverview.getOverview(query, user);
    }
    async downloadStorageOverviewXlsx(query, user, response) {
        const file = await this.storageOverview.getOverviewXlsx(query, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    updateStorageTariff(clientId, dto, user) {
        return this.storageOverview.updateTariff(clientId, dto, user);
    }
    transferBetweenBoxes(dto, user) {
        return this.operations.transferBetweenBoxes(dto, user);
    }
    transferWholeBox(dto, user) {
        return this.operations.transferWholeBox(dto, user);
    }
    importBoxTransfersXlsx(file, clientId, user) {
        return this.operations.importBoxTransfersXlsx(clientId, file, user);
    }
    previewBoxTransfersXlsx(file, clientId, user) {
        return this.operations.previewBoxTransfersXlsx(clientId, file, user);
    }
    commitBoxTransfersXlsx(file, clientId, user) {
        return this.operations.commitBoxTransfersXlsx(clientId, file, user);
    }
    listBoxTransferBatches(clientId, user) {
        return this.operations.listBoxTransferBatches(clientId, user);
    }
    async downloadBoxTransferBatchFile(id, user, response) {
        const file = await this.operations.getBoxTransferBatchFile(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    reverseBoxTransferBatch(id, user) {
        return this.operations.reverseBoxTransferBatch(id, user);
    }
    pickClientRequest(dto, user) {
        return this.operations.pickClientRequest(dto, user);
    }
    listPickWaves(query, user) {
        return this.waves.listWaves(query, user);
    }
    createPickWave(dto, user) {
        return this.waves.createWave(dto, user);
    }
    runPickWave(id, dto, user) {
        return this.waves.runWave(id, dto, user);
    }
    cancelPickWave(id, user) {
        return this.waves.cancelWave(id, user);
    }
    getPickWaveDocument(id, user) {
        return this.waveDocuments.getWaveDocument(id, user);
    }
    async downloadPickWaveDocumentXlsx(id, user, response) {
        const file = await this.waveDocuments.getWaveDocumentXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    getPickInstruction(id, user) {
        return this.pickInstructions.getRequestInstruction(id, user);
    }
    async downloadPickInstructionXlsx(id, user, response) {
        const file = await this.pickInstructions.getRequestInstructionXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    packageClientRequest(dto, user) {
        return this.operations.packageClientRequest(dto, user);
    }
    shipClientRequest(dto, user) {
        return this.operations.shipClientRequest(dto, user);
    }
};
exports.StockController = StockController;
__decorate([
    (0, common_1.Get)('balances'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_stock_balances_dto_1.ListStockBalancesDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "listBalances", null);
__decorate([
    (0, common_1.Get)('storage'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_storage_overview_dto_1.ListStorageOverviewDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "listStorage", null);
__decorate([
    (0, common_1.Get)('storage.xlsx'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_storage_overview_dto_1.ListStorageOverviewDto, Object, Object]),
    __metadata("design:returntype", Promise)
], StockController.prototype, "downloadStorageOverviewXlsx", null);
__decorate([
    (0, common_1.Patch)('storage/:clientId/tariff'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_storage_tariff_dto_1.UpdateStorageTariffDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "updateStorageTariff", null);
__decorate([
    (0, common_1.Post)('transfers/box-to-box'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [transfer_between_boxes_dto_1.TransferBetweenBoxesDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "transferBetweenBoxes", null);
__decorate([
    (0, common_1.Post)('transfers/whole-box'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [transfer_whole_box_dto_1.TransferWholeBoxDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "transferWholeBox", null);
__decorate([
    (0, common_1.Post)('transfers/box-to-box/import-xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "importBoxTransfersXlsx", null);
__decorate([
    (0, common_1.Post)('transfers/box-to-box/preview-xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "previewBoxTransfersXlsx", null);
__decorate([
    (0, common_1.Post)('transfers/box-to-box/commit-xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "commitBoxTransfersXlsx", null);
__decorate([
    (0, common_1.Get)('transfers/box-to-box/batches'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "listBoxTransferBatches", null);
__decorate([
    (0, common_1.Get)('transfers/box-to-box/batches/:id/file'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], StockController.prototype, "downloadBoxTransferBatchFile", null);
__decorate([
    (0, common_1.Delete)('transfers/box-to-box/batches/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "reverseBoxTransferBatch", null);
__decorate([
    (0, common_1.Post)('fulfillment/pick-request'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [pick_client_request_dto_1.PickClientRequestDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "pickClientRequest", null);
__decorate([
    (0, common_1.Get)('fulfillment/waves'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_pick_waves_dto_1.ListPickWavesDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "listPickWaves", null);
__decorate([
    (0, common_1.Post)('fulfillment/waves'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_pick_wave_dto_1.CreatePickWaveDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "createPickWave", null);
__decorate([
    (0, common_1.Post)('fulfillment/waves/:id/pick'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, run_pick_wave_dto_1.RunPickWaveDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "runPickWave", null);
__decorate([
    (0, common_1.Post)('fulfillment/waves/:id/cancel'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "cancelPickWave", null);
__decorate([
    (0, common_1.Get)('fulfillment/waves/:id/document'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "getPickWaveDocument", null);
__decorate([
    (0, common_1.Get)('fulfillment/waves/:id/document.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], StockController.prototype, "downloadPickWaveDocumentXlsx", null);
__decorate([
    (0, common_1.Get)('fulfillment/requests/:id/instruction'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "getPickInstruction", null);
__decorate([
    (0, common_1.Get)('fulfillment/requests/:id/instruction.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], StockController.prototype, "downloadPickInstructionXlsx", null);
__decorate([
    (0, common_1.Post)('fulfillment/package-request'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fulfill_client_request_dto_1.FulfillClientRequestDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "packageClientRequest", null);
__decorate([
    (0, common_1.Post)('fulfillment/ship-request'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [fulfill_client_request_dto_1.FulfillClientRequestDto, Object]),
    __metadata("design:returntype", void 0)
], StockController.prototype, "shipClientRequest", null);
exports.StockController = StockController = __decorate([
    (0, swagger_1.ApiTags)('stock'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    (0, common_1.Controller)('stock'),
    __metadata("design:paramtypes", [stock_balances_service_1.StockBalancesService,
        stock_operations_service_1.StockOperationsService,
        fulfillment_wave_service_1.FulfillmentWaveService,
        pick_wave_document_service_1.PickWaveDocumentService,
        pick_instruction_service_1.PickInstructionService,
        storage_overview_service_1.StorageOverviewService])
], StockController);
function contentDisposition(fileName) {
    const asciiName = fileName.replace(/[^\x20-\x7E]+/g, '_').replace(/"/g, '');
    return `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`;
}
