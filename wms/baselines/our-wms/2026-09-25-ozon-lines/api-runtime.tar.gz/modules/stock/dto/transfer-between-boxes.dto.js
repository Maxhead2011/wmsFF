"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransferBetweenBoxesDto = void 0;
const client_1 = require("@prisma/client");
const class_validator_1 = require("class-validator");
class TransferBetweenBoxesDto {
    clientId;
    skuId;
    barcode;
    fromBoxCode;
    toBoxCode;
    quantity;
    status;
    idempotencyKey;
    comment;
}
exports.TransferBetweenBoxesDto = TransferBetweenBoxesDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.ValidateIf)((dto) => !dto.barcode),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "skuId", void 0);
__decorate([
    (0, class_validator_1.ValidateIf)((dto) => !dto.skuId),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "fromBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "toBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], TransferBetweenBoxesDto.prototype, "quantity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(client_1.StockStatus),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "idempotencyKey", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferBetweenBoxesDto.prototype, "comment", void 0);
