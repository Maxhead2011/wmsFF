"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdatePickWaveBalanceReviewDto = exports.PickWaveBalanceDecisionDto = exports.PickWaveBalanceAllocationDto = void 0;
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class PickWaveBalanceAllocationDto {
    requestId;
    quantity;
    needsRelabel;
    targetBarcode;
    comment;
}
exports.PickWaveBalanceAllocationDto = PickWaveBalanceAllocationDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PickWaveBalanceAllocationDto.prototype, "requestId", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PickWaveBalanceAllocationDto.prototype, "quantity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PickWaveBalanceAllocationDto.prototype, "needsRelabel", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], PickWaveBalanceAllocationDto.prototype, "targetBarcode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], PickWaveBalanceAllocationDto.prototype, "comment", void 0);
class PickWaveBalanceDecisionDto {
    lineId;
    keepQuantity;
    comment;
    allocations;
}
exports.PickWaveBalanceDecisionDto = PickWaveBalanceDecisionDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PickWaveBalanceDecisionDto.prototype, "lineId", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PickWaveBalanceDecisionDto.prototype, "keepQuantity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], PickWaveBalanceDecisionDto.prototype, "comment", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(50),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => PickWaveBalanceAllocationDto),
    __metadata("design:type", Array)
], PickWaveBalanceDecisionDto.prototype, "allocations", void 0);
class UpdatePickWaveBalanceReviewDto {
    decisions;
}
exports.UpdatePickWaveBalanceReviewDto = UpdatePickWaveBalanceReviewDto;
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(1000),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => PickWaveBalanceDecisionDto),
    __metadata("design:type", Array)
], UpdatePickWaveBalanceReviewDto.prototype, "decisions", void 0);
