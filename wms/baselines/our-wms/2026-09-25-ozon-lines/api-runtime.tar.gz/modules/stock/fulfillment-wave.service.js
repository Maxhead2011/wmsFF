"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FulfillmentWaveService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("../client-requests/client-request-warehouse-scope");
const telegram_notification_service_1 = require("../client-notifications/telegram-notification.service");
const pick_wave_include_1 = require("./pick-wave.include");
const pick_instruction_service_1 = require("./pick-instruction.service");
const stock_operations_service_1 = require("./stock-operations.service");
const pickWaveRequestStatuses = [
    client_1.ClientRequestStatus.SUBMITTED,
    client_1.ClientRequestStatus.IN_REVIEW,
    client_1.ClientRequestStatus.APPROVED,
    client_1.ClientRequestStatus.IN_WORK,
];
const balanceReviewInclude = {
    requests: {
        include: {
            request: {
                select: {
                    id: true,
                    clientId: true,
                    warehouseId: true,
                    title: true,
                    status: true,
                    destinationCity: true,
                    client: { select: { id: true, code: true, name: true } },
                },
            },
        },
        orderBy: { requestId: 'asc' },
    },
    balanceLines: {
        include: {
            allocations: { orderBy: [{ createdAt: 'asc' }, { id: 'asc' }] },
        },
        orderBy: [{ sourceBoxCode: 'asc' }, { internalSku: 'asc' }],
    },
    createdBy: { select: { id: true, email: true, name: true } },
    assignedPicker: { select: { id: true, email: true, name: true } },
};
let FulfillmentWaveService = class FulfillmentWaveService {
    prisma;
    clientScopes;
    operations;
    pickInstructions;
    telegram;
    constructor(prisma, clientScopes, operations, pickInstructions, telegram) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.operations = operations;
        this.pickInstructions = pickInstructions;
        this.telegram = telegram;
    }
    listWaves(query, user) {
        return this.prisma.pickWave.findMany({
            where: {
                status: query.status,
                ...(0, client_request_warehouse_scope_1.warehouseScopeWhere)(user),
                requests: {
                    some: {
                        request: {
                            clientId: this.clientScopes.resolveClientFilter(user),
                        },
                    },
                },
            },
            include: pick_wave_include_1.pickWaveInclude,
            orderBy: [{ createdAt: 'desc' }],
            take: 100,
        });
    }
    async createWave(dto, user) {
        const requestIds = [...new Set(dto.requestIds.map((id) => id.trim()).filter(Boolean))];
        const assignedPickerUserId = await this.resolveAssignedPickerId(dto.assignedPickerUserId);
        if (requestIds.length === 0) {
            throw new common_1.BadRequestException('Для волны сборки нужна хотя бы одна заявка.');
        }
        const requests = await this.prisma.clientRequest.findMany({
            where: { id: { in: requestIds } },
            include: { items: true },
        });
        if (requests.length !== requestIds.length) {
            throw new common_1.NotFoundException('Одна или несколько заявок для волны не найдены.');
        }
        const busyLinks = await this.prisma.pickWaveRequest.findMany({
            where: {
                requestId: { in: requestIds },
                wave: { status: { notIn: [client_1.PickWaveStatus.CANCELLED, client_1.PickWaveStatus.DONE] } },
            },
            include: { wave: true },
        });
        if (busyLinks.length > 0) {
            throw new common_1.BadRequestException('Одна или несколько заявок уже входят в активную волну сборки.');
        }
        if (new Set(requests.map((request) => request.clientId)).size !== 1) {
            throw new common_1.BadRequestException('В одной волне могут находиться только заявки одного клиента.');
        }
        const warehouseIds = new Set(requests.map((request) => request.warehouseId));
        if (warehouseIds.size !== 1 || !requests[0].warehouseId) {
            throw new common_1.BadRequestException('Все заявки волны должны относиться к одному выбранному филиалу.');
        }
        const warehouseId = requests[0].warehouseId;
        for (const request of requests) {
            this.clientScopes.requireClientAccess(user, request.clientId, 'write');
            (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'write', 'Заявка волны не найдена в выбранном филиале.');
            if (request.type !== client_1.ClientRequestType.OUTBOUND) {
                throw new common_1.BadRequestException('В волну сборки можно добавлять только outbound-заявки.');
            }
            if (!pickWaveRequestStatuses.includes(request.status)) {
                throw new common_1.BadRequestException('В волну можно добавлять новые, проверяемые, согласованные или уже переданные в работу заявки.');
            }
            if (request.items.length === 0) {
                throw new common_1.BadRequestException('В заявке нет товарных позиций для сборки.');
            }
        }
        const draft = await this.pickInstructions.buildWaveDraft(requestIds, user);
        const waveNumber = this.nextWaveNumber();
        const generatedAt = new Date(draft.generatedAt);
        const needsBalanceReview = draft.balanceLines.length > 0;
        const wave = await this.prisma.$transaction(async (tx) => {
            const created = await tx.pickWave.create({
                data: {
                    waveNumber,
                    warehouseId,
                    status: needsBalanceReview ? client_1.PickWaveStatus.BALANCE_REVIEW : client_1.PickWaveStatus.FROZEN,
                    comment: dto.comment?.trim() || undefined,
                    plan: this.toJson(draft.plan),
                    planGeneratedAt: generatedAt,
                    planFrozenAt: needsBalanceReview ? undefined : generatedAt,
                    balanceReviewStatus: needsBalanceReview
                        ? client_1.PickWaveBalanceReviewStatus.PENDING
                        : client_1.PickWaveBalanceReviewStatus.NOT_REQUIRED,
                    createdByUserId: user.id,
                    assignedPickerUserId,
                    requests: {
                        create: requestIds.map((requestId) => ({ requestId })),
                    },
                    balanceLines: {
                        create: draft.balanceLines.map((line) => ({
                            ...line,
                            sourceBoxId: line.sourceBoxId ?? undefined,
                            barcode: line.barcode ?? undefined,
                            color: line.color ?? undefined,
                            size: line.size ?? undefined,
                        })),
                    },
                },
                include: pick_wave_include_1.pickWaveInclude,
            });
            for (const request of requests) {
                if (request.status !== client_1.ClientRequestStatus.IN_WORK) {
                    await tx.clientRequest.update({
                        where: { id: request.id },
                        data: { status: client_1.ClientRequestStatus.IN_WORK, assignedToUserId: assignedPickerUserId ?? user.id },
                    });
                    await tx.clientRequestEvent.create({
                        data: {
                            requestId: request.id,
                            clientId: request.clientId,
                            eventType: client_1.ClientRequestEventType.STATUS_CHANGED,
                            title: `Заявка включена в волну ${waveNumber}`,
                            body: needsBalanceReview
                                ? 'Сформирована общая инструкция. Требуется проверка складских балансов клиентом.'
                                : 'Общая инструкция сформирована и зафиксирована.',
                            statusFrom: request.status,
                            statusTo: client_1.ClientRequestStatus.IN_WORK,
                            createdByUserId: user.id,
                        },
                    });
                }
            }
            if (needsBalanceReview) {
                await tx.clientNotification.create({
                    data: {
                        clientId: requests[0].clientId,
                        requestId: requests[0].id,
                        title: 'Требуется проверить балансы волны',
                        body: `${waveNumber}: распределите остатки по городам или подтвердите хранение на складе. Строк: ${draft.balanceLines.length}.`,
                        severity: client_1.ClientNotificationSeverity.WARNING,
                        createdByUserId: user.id,
                    },
                });
            }
            return created;
        });
        if (needsBalanceReview) {
            void this.telegram.notifyClient(requests[0].clientId, [
                'LOGOff WMS: требуется проверить балансы.',
                `Волна: ${waveNumber}`,
                `Заявок: ${requests.length}`,
                `Остатков для решения: ${draft.balanceLines.length}`,
                'Откройте раздел заявок и нажмите «Проверить балансы».',
            ].join('\n'));
        }
        requestIds.forEach((requestId) => this.pickInstructions.invalidateRequestInstruction(requestId));
        return wave;
    }
    async listBalanceReviews(user) {
        const waves = await this.prisma.pickWave.findMany({
            where: {
                balanceReviewStatus: {
                    in: [client_1.PickWaveBalanceReviewStatus.PENDING, client_1.PickWaveBalanceReviewStatus.SUBMITTED],
                },
                ...(0, client_request_warehouse_scope_1.warehouseScopeWhere)(user),
                requests: {
                    some: {
                        request: { clientId: this.clientScopes.resolveClientFilter(user) },
                    },
                },
            },
            include: balanceReviewInclude,
            orderBy: [{ createdAt: 'desc' }],
            take: 50,
        });
        return waves.map((wave) => this.toBalanceReviewResponse(wave));
    }
    async getBalanceReview(waveId, user) {
        const wave = await this.loadBalanceReview(waveId);
        this.requireWaveAccess(wave, user, 'read');
        return this.toBalanceReviewResponse(wave);
    }
    async saveBalanceReview(waveId, dto, user) {
        const wave = await this.loadBalanceReview(waveId);
        this.requireWaveAccess(wave, user, 'write');
        if (wave.status !== client_1.PickWaveStatus.BALANCE_REVIEW ||
            wave.balanceReviewStatus !== client_1.PickWaveBalanceReviewStatus.PENDING) {
            throw new common_1.BadRequestException('Проверка балансов этой волны уже закрыта.');
        }
        const linesById = new Map(wave.balanceLines.map((line) => [line.id, line]));
        const requestIds = new Set(wave.requests.map((link) => link.requestId));
        const seenLineIds = new Set();
        for (const decision of dto.decisions) {
            const line = linesById.get(decision.lineId);
            if (!line) {
                throw new common_1.BadRequestException('Строка баланса не относится к выбранной волне.');
            }
            if (seenLineIds.has(decision.lineId)) {
                throw new common_1.BadRequestException('Одна строка баланса передана несколько раз.');
            }
            seenLineIds.add(decision.lineId);
            const allocatedQuantity = decision.allocations.reduce((sum, allocation) => sum + allocation.quantity, 0);
            if (allocatedQuantity + decision.keepQuantity !== line.remainingQuantity) {
                throw new common_1.BadRequestException(`Для ${line.sourceBoxCode} / ${line.internalSku} распределите ровно ${line.remainingQuantity} шт.`);
            }
            for (const allocation of decision.allocations) {
                if (!requestIds.has(allocation.requestId)) {
                    throw new common_1.BadRequestException('Остаток можно отправить только в заявку этой волны.');
                }
                const targetBarcode = allocation.targetBarcode?.trim() ?? '';
                if (allocation.needsRelabel && !targetBarcode) {
                    throw new common_1.BadRequestException('Для перемаркировки укажите новый штрихкод.');
                }
                if (allocation.needsRelabel && targetBarcode === (line.barcode ?? '').trim()) {
                    throw new common_1.BadRequestException('Новый штрихкод перемаркировки должен отличаться от исходного.');
                }
            }
        }
        await this.prisma.$transaction(async (tx) => {
            for (const decision of dto.decisions) {
                await tx.pickWaveBalanceAllocation.deleteMany({ where: { lineId: decision.lineId } });
                await tx.pickWaveBalanceLine.update({
                    where: { id: decision.lineId },
                    data: {
                        keepQuantity: decision.keepQuantity,
                        isReviewed: true,
                        comment: normalizeOptionalText(decision.comment),
                        allocations: {
                            create: decision.allocations.map((allocation) => ({
                                requestId: allocation.requestId,
                                quantity: allocation.quantity,
                                needsRelabel: allocation.needsRelabel === true,
                                targetBarcode: allocation.needsRelabel ? normalizeOptionalText(allocation.targetBarcode) : null,
                                comment: normalizeOptionalText(allocation.comment),
                            })),
                        },
                    },
                });
            }
        });
        return this.getBalanceReview(waveId, user);
    }
    async submitBalanceReview(waveId, user) {
        let wave = await this.loadBalanceReview(waveId);
        this.requireWaveAccess(wave, user, 'write');
        if (wave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.APPROVED) {
            return this.toBalanceReviewResponse(wave);
        }
        if (wave.status !== client_1.PickWaveStatus.BALANCE_REVIEW) {
            throw new common_1.BadRequestException('Волна не ожидает проверки балансов.');
        }
        this.validateCompleteBalanceReview(wave);
        if (wave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.PENDING) {
            await this.prisma.$transaction(async (tx) => {
                const locked = await tx.pickWave.updateMany({
                    where: {
                        id: waveId,
                        status: client_1.PickWaveStatus.BALANCE_REVIEW,
                        balanceReviewStatus: client_1.PickWaveBalanceReviewStatus.PENDING,
                    },
                    data: {
                        balanceReviewStatus: client_1.PickWaveBalanceReviewStatus.SUBMITTED,
                        balanceReviewSubmittedAt: new Date(),
                        balanceReviewSubmittedByUserId: user.id,
                    },
                });
                if (locked.count !== 1) {
                    throw new common_1.BadRequestException('Проверка балансов уже отправляется другим пользователем.');
                }
                const requestById = new Map(wave.requests.map((link) => [link.requestId, link.request]));
                const affectedRequestIds = new Set();
                for (const line of wave.balanceLines) {
                    for (const allocation of line.allocations) {
                        const request = requestById.get(allocation.requestId);
                        if (!request) {
                            throw new common_1.BadRequestException('Заявка назначения не найдена в волне.');
                        }
                        const item = await tx.clientRequestItem.create({
                            data: {
                                requestId: request.id,
                                skuId: line.skuId,
                                barcode: line.barcode,
                                name: line.name,
                                quantity: allocation.quantity,
                                comment: balanceReviewItemComment(wave.waveNumber, line, request, allocation),
                            },
                        });
                        await tx.pickWaveBalanceAllocation.update({
                            where: { id: allocation.id },
                            data: { appliedRequestItemId: item.id },
                        });
                        affectedRequestIds.add(request.id);
                    }
                }
                for (const requestId of affectedRequestIds) {
                    const request = requestById.get(requestId);
                    await tx.clientRequestEvent.create({
                        data: {
                            requestId,
                            clientId: request.clientId,
                            eventType: client_1.ClientRequestEventType.COMMENT,
                            title: `Добавлены товары из балансов волны ${wave.waveNumber}`,
                            body: 'Количество заявки дополнено решением клиента при проверке складских остатков.',
                            createdByUserId: user.id,
                        },
                    });
                }
            });
            wave = await this.loadBalanceReview(waveId);
        }
        const forcedAllocations = wave.balanceLines.flatMap((line) => line.allocations.map((allocation) => {
            if (!allocation.appliedRequestItemId) {
                throw new common_1.BadRequestException('Не удалось связать распределение баланса с позицией заявки.');
            }
            return {
                orderId: allocation.appliedRequestItemId,
                balanceId: line.balanceId,
                quantity: allocation.quantity,
            };
        }));
        const requestIds = wave.requests.map((link) => link.requestId);
        const finalDraft = await this.pickInstructions.buildWaveDraft(requestIds, user, forcedAllocations);
        const approvedAt = new Date();
        await this.prisma.$transaction(async (tx) => {
            await tx.pickWave.update({
                where: { id: waveId },
                data: {
                    status: client_1.PickWaveStatus.FROZEN,
                    balanceReviewStatus: client_1.PickWaveBalanceReviewStatus.APPROVED,
                    plan: this.toJson(finalDraft.plan),
                    planVersion: { increment: 1 },
                    planGeneratedAt: new Date(finalDraft.generatedAt),
                    planFrozenAt: approvedAt,
                },
            });
            await tx.clientNotification.create({
                data: {
                    clientId: wave.requests[0].request.clientId,
                    requestId: wave.requests[0].requestId,
                    title: 'Балансы подтверждены',
                    body: `${wave.waveNumber}: распределение сохранено, инструкция зафиксирована для склада.`,
                    createdByUserId: user.id,
                },
            });
        });
        requestIds.forEach((requestId) => this.pickInstructions.invalidateRequestInstruction(requestId));
        void this.telegram.notifyClient(wave.requests[0].request.clientId, `LOGOff WMS: балансы волны ${wave.waveNumber} подтверждены. Инструкция передана складу.`);
        void this.telegram.notifyFulfillment(`LOGOff WMS: клиент подтвердил балансы волны ${wave.waveNumber}. Можно начинать сборку.`);
        return this.getBalanceReview(waveId, user);
    }
    async runWave(waveId, dto, user) {
        const wave = await this.prisma.pickWave.findUnique({
            where: { id: waveId },
            include: pick_wave_include_1.pickWaveInclude,
        });
        if (!wave) {
            throw new common_1.NotFoundException('Волна сборки не найдена.');
        }
        this.requireWaveAccess(wave, user, 'write');
        if (wave.status === client_1.PickWaveStatus.CANCELLED) {
            throw new common_1.BadRequestException('Отмененную волну сборки нельзя запускать.');
        }
        if (wave.status === client_1.PickWaveStatus.DONE) {
            throw new common_1.BadRequestException('Волна сборки уже завершена.');
        }
        if (wave.status === client_1.PickWaveStatus.BALANCE_REVIEW ||
            wave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.PENDING ||
            wave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.SUBMITTED) {
            throw new common_1.BadRequestException('Сначала клиент должен проверить и подтвердить складские балансы волны.');
        }
        const locked = await this.prisma.pickWave.updateMany({
            where: { id: wave.id, status: wave.status },
            data: { status: client_1.PickWaveStatus.PICKING },
        });
        if (locked.count !== 1) {
            throw new common_1.BadRequestException('Состояние волны изменилось. Обновите список и повторите действие.');
        }
        const runResults = [];
        let failedCount = 0;
        for (const waveRequest of wave.requests) {
            if (waveRequest.status === client_1.PickWaveRequestStatus.PICKED) {
                runResults.push({
                    requestId: waveRequest.requestId,
                    status: 'SKIPPED_ALREADY_PICKED',
                });
                continue;
            }
            try {
                // Русский комментарий: волна использует уже существующий idempotent pick-request,
                // поэтому повтор запуска не дублирует движения stock ledger.
                const result = await this.operations.pickClientRequest({
                    requestId: waveRequest.requestId,
                    idempotencyKey: `${dto.idempotencyKey ?? `wave-pick:${wave.id}`}:${waveRequest.requestId}`,
                    comment: dto.comment?.trim() || `Волна сборки ${wave.waveNumber}`,
                }, user);
                await this.prisma.pickWaveRequest.update({
                    where: { waveId_requestId: { waveId: wave.id, requestId: waveRequest.requestId } },
                    data: {
                        status: client_1.PickWaveRequestStatus.PICKED,
                        pickedAt: new Date(),
                        result: this.toJson(result),
                    },
                });
                runResults.push({
                    requestId: waveRequest.requestId,
                    status: result.status,
                });
            }
            catch (caught) {
                failedCount += 1;
                const message = caught instanceof Error ? caught.message : 'Не удалось собрать заявку в волне.';
                await this.prisma.pickWaveRequest.update({
                    where: { waveId_requestId: { waveId: wave.id, requestId: waveRequest.requestId } },
                    data: {
                        status: client_1.PickWaveRequestStatus.FAILED,
                        result: { message },
                    },
                });
                runResults.push({
                    requestId: waveRequest.requestId,
                    status: 'FAILED',
                    message,
                });
            }
        }
        const status = failedCount > 0 ? client_1.PickWaveStatus.FAILED : client_1.PickWaveStatus.DONE;
        const updatedWave = await this.prisma.pickWave.update({
            where: { id: wave.id },
            data: { status },
            include: pick_wave_include_1.pickWaveInclude,
        });
        return {
            wave: updatedWave,
            results: runResults,
        };
    }
    async cancelWave(waveId, user) {
        const wave = await this.prisma.pickWave.findUnique({
            where: { id: waveId },
            include: pick_wave_include_1.pickWaveInclude,
        });
        if (!wave) {
            throw new common_1.NotFoundException('Волна сборки не найдена.');
        }
        this.requireWaveAccess(wave, user, 'write');
        if (wave.status === client_1.PickWaveStatus.CANCELLED) {
            return wave;
        }
        if (wave.status === client_1.PickWaveStatus.DONE) {
            throw new common_1.BadRequestException('Завершённую волну отменить нельзя.');
        }
        if (wave.status === client_1.PickWaveStatus.PICKING) {
            throw new common_1.BadRequestException('Сборка этой волны уже выполняется. Дождитесь её завершения.');
        }
        if (wave.requests.some((link) => link.status === client_1.PickWaveRequestStatus.PICKED)) {
            throw new common_1.BadRequestException('В волне уже есть собранные заявки. Отмена может повредить складские остатки.');
        }
        const requestIds = wave.requests.map((link) => link.requestId);
        const movementCount = await this.prisma.stockMovement.count({
            where: {
                type: client_1.MovementType.PICK,
                sourceDocument: { in: requestIds },
                idempotencyKey: { contains: wave.id },
            },
        });
        if (movementCount > 0) {
            throw new common_1.BadRequestException('По волне уже проведены складские движения. Безопасная отмена невозможна.');
        }
        const [statusEvents, appliedAllocations] = await Promise.all([
            this.prisma.clientRequestEvent.findMany({
                where: {
                    requestId: { in: requestIds },
                    eventType: client_1.ClientRequestEventType.STATUS_CHANGED,
                    title: `Заявка включена в волну ${wave.waveNumber}`,
                    statusTo: client_1.ClientRequestStatus.IN_WORK,
                },
                orderBy: { createdAt: 'desc' },
            }),
            this.prisma.pickWaveBalanceAllocation.findMany({
                where: {
                    line: { waveId },
                    appliedRequestItemId: { not: null },
                },
                select: { id: true, appliedRequestItemId: true },
            }),
        ]);
        const previousStatusByRequest = new Map();
        for (const event of statusEvents) {
            if (event.statusFrom && !previousStatusByRequest.has(event.requestId)) {
                previousStatusByRequest.set(event.requestId, event.statusFrom);
            }
        }
        const appliedRequestItemIds = appliedAllocations
            .map((allocation) => allocation.appliedRequestItemId)
            .filter((id) => Boolean(id));
        if (appliedRequestItemIds.length > 0) {
            const usedAppliedItems = await this.prisma.clientRequestItem.count({
                where: {
                    id: { in: appliedRequestItemIds },
                    OR: [{ packageItems: { some: {} } }, { boxSelections: { some: {} } }],
                },
            });
            if (usedAppliedItems > 0) {
                throw new common_1.BadRequestException('Добавленные при согласовании позиции уже используются в сборке. Отмена невозможна.');
            }
        }
        const cancelledAt = new Date();
        const cancellationNote = `Отменена ${cancelledAt.toLocaleString('ru-RU')} пользователем ${user.name}.`;
        await this.prisma.$transaction(async (tx) => {
            const locked = await tx.pickWave.updateMany({
                where: { id: wave.id, status: wave.status },
                data: {
                    status: client_1.PickWaveStatus.CANCELLED,
                    balanceReviewStatus: client_1.PickWaveBalanceReviewStatus.NOT_REQUIRED,
                    comment: [wave.comment?.trim(), cancellationNote].filter(Boolean).join('\n'),
                },
            });
            if (locked.count !== 1) {
                throw new common_1.BadRequestException('Состояние волны изменилось. Обновите список и повторите отмену.');
            }
            if (appliedAllocations.length > 0) {
                await tx.pickWaveBalanceAllocation.updateMany({
                    where: { id: { in: appliedAllocations.map((allocation) => allocation.id) } },
                    data: { appliedRequestItemId: null },
                });
            }
            if (appliedRequestItemIds.length > 0) {
                await tx.clientRequestItem.deleteMany({ where: { id: { in: appliedRequestItemIds } } });
            }
            for (const link of wave.requests) {
                const previousStatus = previousStatusByRequest.get(link.requestId);
                const canRestore = link.request.status === client_1.ClientRequestStatus.IN_WORK && previousStatus !== undefined;
                if (canRestore) {
                    await tx.clientRequest.update({
                        where: { id: link.requestId },
                        data: { status: previousStatus },
                    });
                }
                await tx.clientRequestEvent.create({
                    data: {
                        requestId: link.requestId,
                        clientId: link.request.clientId,
                        eventType: canRestore ? client_1.ClientRequestEventType.STATUS_CHANGED : client_1.ClientRequestEventType.COMMENT,
                        title: `Волна ${wave.waveNumber} отменена`,
                        body: canRestore
                            ? 'Заявка освобождена и снова доступна для включения в волну.'
                            : 'Волна отменена без изменения текущего статуса заявки.',
                        statusFrom: canRestore ? link.request.status : undefined,
                        statusTo: canRestore ? previousStatus : undefined,
                        createdByUserId: user.id,
                    },
                });
            }
        });
        requestIds.forEach((requestId) => this.pickInstructions.invalidateRequestInstruction(requestId));
        return this.prisma.pickWave.findUniqueOrThrow({
            where: { id: wave.id },
            include: pick_wave_include_1.pickWaveInclude,
        });
    }
    async loadBalanceReview(waveId) {
        const wave = await this.prisma.pickWave.findUnique({
            where: { id: waveId },
            include: balanceReviewInclude,
        });
        if (!wave) {
            throw new common_1.NotFoundException('Волна сборки не найдена.');
        }
        return wave;
    }
    requireWaveAccess(wave, user, mode) {
        const clientIds = [...new Set(wave.requests.map((link) => link.request.clientId))];
        if (clientIds.length !== 1) {
            throw new common_1.BadRequestException('В волне обнаружены заявки разных клиентов.');
        }
        this.clientScopes.requireClientAccess(user, clientIds[0], mode);
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, wave, mode, 'Волна не найдена в выбранном филиале.');
        if (!wave.warehouseId ||
            wave.requests.some((link) => link.request.warehouseId !== wave.warehouseId)) {
            throw new common_1.BadRequestException('Волна содержит заявки разных филиалов или не привязана к филиалу.');
        }
    }
    validateCompleteBalanceReview(wave) {
        const requestIds = new Set(wave.requests.map((link) => link.requestId));
        for (const line of wave.balanceLines) {
            if (!line.isReviewed || line.keepQuantity === null) {
                throw new common_1.BadRequestException(`Не принято решение по ${line.sourceBoxCode} / ${line.internalSku}.`);
            }
            const allocated = line.allocations.reduce((sum, allocation) => sum + allocation.quantity, 0);
            if (allocated + line.keepQuantity !== line.remainingQuantity) {
                throw new common_1.BadRequestException(`Для ${line.sourceBoxCode} / ${line.internalSku} распределено не ${line.remainingQuantity} шт.`);
            }
            for (const allocation of line.allocations) {
                if (!requestIds.has(allocation.requestId)) {
                    throw new common_1.BadRequestException('Одна из строк распределена в заявку вне волны.');
                }
                if (allocation.needsRelabel && !allocation.targetBarcode?.trim()) {
                    throw new common_1.BadRequestException('Для перемаркировки не указан новый штрихкод.');
                }
            }
        }
    }
    toBalanceReviewResponse(wave) {
        const reviewedLines = wave.balanceLines.filter((line) => line.isReviewed).length;
        const totalRemaining = wave.balanceLines.reduce((sum, line) => sum + line.remainingQuantity, 0);
        const allocatedQuantity = wave.balanceLines.reduce((sum, line) => sum + line.allocations.reduce((lineSum, allocation) => lineSum + allocation.quantity, 0), 0);
        return {
            id: wave.id,
            waveNumber: wave.waveNumber,
            status: wave.status,
            balanceReviewStatus: wave.balanceReviewStatus,
            planVersion: wave.planVersion,
            planGeneratedAt: wave.planGeneratedAt?.toISOString() ?? null,
            planFrozenAt: wave.planFrozenAt?.toISOString() ?? null,
            createdAt: wave.createdAt.toISOString(),
            updatedAt: wave.updatedAt.toISOString(),
            client: wave.requests[0]?.request.client ?? null,
            requests: wave.requests.map((link) => ({
                id: link.request.id,
                title: link.request.title,
                status: link.request.status,
                destinationCity: link.request.destinationCity,
            })),
            summary: {
                lines: wave.balanceLines.length,
                reviewedLines,
                pendingLines: wave.balanceLines.length - reviewedLines,
                totalRemaining,
                allocatedQuantity,
                keepQuantity: totalRemaining - allocatedQuantity,
                smallBalanceLines: wave.balanceLines.filter((line) => line.remainingQuantity <= 5).length,
            },
            lines: wave.balanceLines.map((line) => ({
                id: line.id,
                balanceId: line.balanceId,
                sourceBoxCode: line.sourceBoxCode,
                skuId: line.skuId,
                internalSku: line.internalSku,
                barcode: line.barcode,
                name: line.name,
                color: line.color,
                size: line.size,
                originalQuantity: line.originalQuantity,
                plannedQuantity: line.plannedQuantity,
                remainingQuantity: line.remainingQuantity,
                keepQuantity: line.keepQuantity,
                isReviewed: line.isReviewed,
                isSmallBalance: line.remainingQuantity <= 5,
                comment: line.comment,
                allocations: line.allocations.map((allocation) => ({
                    id: allocation.id,
                    requestId: allocation.requestId,
                    quantity: allocation.quantity,
                    needsRelabel: allocation.needsRelabel,
                    targetBarcode: allocation.targetBarcode,
                    comment: allocation.comment,
                })),
            })),
        };
    }
    async resolveAssignedPickerId(input) {
        const assignedPickerUserId = input?.trim();
        if (!assignedPickerUserId) {
            return undefined;
        }
        const picker = await this.prisma.user.findUnique({
            where: { id: assignedPickerUserId },
            select: { id: true, status: true },
        });
        if (!picker || picker.status !== client_1.UserStatus.ACTIVE) {
            throw new common_1.BadRequestException('Ответственный сборщик для волны не найден или заблокирован.');
        }
        return picker.id;
    }
    nextWaveNumber() {
        const stamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
        const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
        return `WAVE-${stamp}-${suffix}`;
    }
    toJson(value) {
        return JSON.parse(JSON.stringify(value));
    }
};
exports.FulfillmentWaveService = FulfillmentWaveService;
exports.FulfillmentWaveService = FulfillmentWaveService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        stock_operations_service_1.StockOperationsService,
        pick_instruction_service_1.PickInstructionService,
        telegram_notification_service_1.TelegramNotificationService])
], FulfillmentWaveService);
function balanceReviewItemComment(waveNumber, line, request, allocation) {
    return [
        `Добавлено при проверке балансов волны: ${waveNumber}`,
        `Исходный короб: ${line.sourceBoxCode}`,
        request.destinationCity ? `Город: ${request.destinationCity}` : null,
        allocation.needsRelabel ? `Перемаркировка из: ${line.barcode ?? ''}` : null,
        allocation.needsRelabel ? `Перемаркировка в: ${allocation.targetBarcode ?? ''}` : null,
        allocation.needsRelabel ? 'Перемаркировка: да' : null,
        normalizeOptionalText(allocation.comment),
    ]
        .filter(Boolean)
        .join('; ');
}
function normalizeOptionalText(value) {
    const normalized = value?.trim();
    return normalized ? normalized : null;
}
