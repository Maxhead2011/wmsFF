"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FbsRequestBoxAuditService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const pick_instruction_service_1 = require("./pick-instruction.service");
const reservationStatuses = [
    'RESERVED',
    'RESCAN_REQUIRED',
    'IN_PROGRESS',
    'COMPLETED',
    'RETURN_REQUIRED',
];
const outstandingStatuses = [
    'WAITING_STOCK',
    'RELEASED',
    'RESERVED',
    'RESCAN_REQUIRED',
    'IN_PROGRESS',
    'RETURN_REQUIRED',
];
const closedRequestStatuses = [
    client_1.ClientRequestStatus.DONE,
    client_1.ClientRequestStatus.CANCELLED,
    client_1.ClientRequestStatus.REJECTED,
];
let FbsRequestBoxAuditService = class FbsRequestBoxAuditService {
    prisma;
    clientScopes;
    pickInstructions;
    constructor(prisma, clientScopes, pickInstructions) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.pickInstructions = pickInstructions;
    }
    async listActiveRequests(user) {
        const clientId = this.clientScopes.resolveClientFilter(user);
        const requests = await this.prisma.clientRequest.findMany({
            where: {
                clientId,
                type: client_1.ClientRequestType.OUTBOUND,
                status: {
                    in: [
                        client_1.ClientRequestStatus.SUBMITTED,
                        client_1.ClientRequestStatus.IN_REVIEW,
                        client_1.ClientRequestStatus.APPROVED,
                        client_1.ClientRequestStatus.IN_WORK,
                        client_1.ClientRequestStatus.PACKED,
                    ],
                },
                fbsOrderLinks: { some: {} },
            },
            select: {
                id: true,
                number: true,
                title: true,
                status: true,
                updatedAt: true,
                client: { select: { id: true, code: true, name: true } },
                _count: { select: { fbsOrderLinks: true } },
            },
            orderBy: [{ updatedAt: 'desc' }],
            take: 250,
        });
        const requestIds = requests.map((request) => request.id);
        const tasks = requestIds.length
            ? await this.prisma.fbsTsdAssembly.findMany({
                where: { requestId: { in: requestIds } },
                select: { requestId: true, status: true, itemCount: true },
            })
            : [];
        const tasksByRequest = new Map();
        tasks.forEach((task) => {
            const current = tasksByRequest.get(task.requestId) ?? { total: 0, completed: 0, outstanding: 0 };
            const quantity = Math.max(1, task.itemCount);
            current.total += quantity;
            if (task.status === 'COMPLETED')
                current.completed += quantity;
            else if (outstandingStatuses.includes(task.status))
                current.outstanding += quantity;
            tasksByRequest.set(task.requestId, current);
        });
        return requests.map((request) => ({
            id: request.id,
            number: request.number,
            title: request.title,
            status: request.status,
            updatedAt: request.updatedAt.toISOString(),
            client: request.client,
            orders: request._count.fbsOrderLinks,
            tasks: tasksByRequest.get(request.id) ?? { total: 0, completed: 0, outstanding: 0 },
        }));
    }
    async auditRequest(requestId, user) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: { clientId: true },
        });
        if (!request)
            throw new common_1.NotFoundException('Заявка не найдена.');
        this.clientScopes.requireClientAccess(user, request.clientId, 'read');
        const document = await this.pickInstructions.getRequestInstruction(requestId, user);
        const audit = await this.auditDocument(document);
        if (!audit)
            throw new common_1.NotFoundException('У заявки нет связанных FBS-заказов.');
        return audit;
    }
    async auditDocument(document) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: document.requestId },
            select: {
                id: true,
                number: true,
                title: true,
                status: true,
                clientId: true,
                client: { select: { id: true, code: true, name: true } },
                _count: { select: { fbsOrderLinks: true } },
            },
        });
        if (!request)
            throw new common_1.NotFoundException('Заявка не найдена.');
        if (request._count.fbsOrderLinks === 0)
            return null;
        const planBoxCodes = uniqueCodes([
            ...document.warehouseRows.map((row) => row.sourceBox),
            ...document.warehouseBalanceMoves.map((row) => row.sourceBox),
            ...document.warehouseWholeBoxes.map((row) => row.box),
        ]);
        const boxes = planBoxCodes.length
            ? await this.prisma.box.findMany({
                where: { clientId: request.clientId, code: { in: planBoxCodes } },
                select: {
                    id: true,
                    code: true,
                    status: true,
                    storagePlacement: {
                        select: { pallet: { select: { code: true, status: true } } },
                    },
                    balances: {
                        where: { status: client_1.StockStatus.AVAILABLE, quantity: { gt: 0 } },
                        select: {
                            skuId: true,
                            quantity: true,
                            sku: { select: { internalSku: true, name: true } },
                        },
                    },
                },
            })
            : [];
        const boxByCode = new Map(boxes.map((box) => [normalizeCode(box.code), box]));
        const planBoxIds = boxes.map((box) => box.id);
        const allReservationTasks = planBoxIds.length ? await this.prisma.fbsTsdAssembly.findMany({
            where: {
                clientId: request.clientId,
                status: { in: reservationStatuses },
                OR: [
                    { boxId: { in: planBoxIds } },
                    { boxId: null, reservedBoxId: { in: planBoxIds } },
                ],
            },
            select: {
                id: true,
                requestId: true,
                orderId: true,
                status: true,
                itemCount: true,
                skuId: true,
                sourceSkuId: true,
                relabelConfirmedAt: true,
                boxId: true,
                reservedBoxId: true,
            },
        }) : [];
        const completedRequestIds = uniqueCodes(allReservationTasks
            .filter((task) => task.status === 'COMPLETED')
            .map((task) => task.requestId));
        const openCompletedRequests = completedRequestIds.length
            ? await this.prisma.clientRequest.findMany({
                where: { id: { in: completedRequestIds }, status: { notIn: closedRequestStatuses } },
                select: { id: true },
            })
            : [];
        const openCompletedRequestIds = new Set(openCompletedRequests.map((row) => row.id));
        const reservationTasks = allReservationTasks.filter((task) => task.status !== 'COMPLETED' || openCompletedRequestIds.has(task.requestId));
        const allRequestTasks = await this.prisma.fbsTsdAssembly.findMany({
            where: { requestId: request.id },
            select: {
                id: true,
                requestId: true,
                orderId: true,
                status: true,
                itemCount: true,
                skuId: true,
                sourceSkuId: true,
                relabelConfirmedAt: true,
                boxId: true,
                reservedBoxId: true,
            },
        });
        const outstandingTasks = allRequestTasks.filter((task) => outstandingStatuses.includes(task.status));
        const reservationsByBoxSku = new Map();
        reservationTasks.forEach((task) => {
            const boxId = task.boxId ?? task.reservedBoxId;
            if (!boxId)
                return;
            const key = `${boxId}:${effectiveTaskSku(task)}`;
            reservationsByBoxSku.set(key, [...(reservationsByBoxSku.get(key) ?? []), task]);
        });
        const outstandingBySku = new Map();
        outstandingTasks.forEach((task) => {
            const skuId = effectiveTaskSku(task);
            outstandingBySku.set(skuId, [...(outstandingBySku.get(skuId) ?? []), task]);
        });
        const rows = planBoxCodes.map((code) => {
            const box = boxByCode.get(normalizeCode(code));
            if (!box)
                return emptyAuditRow(code, 'MISSING');
            if (['deleted', 'archived'].includes(box.status.toLocaleLowerCase('ru-RU'))) {
                return { ...emptyAuditRow(code, 'ARCHIVED'), palletCode: box.storagePlacement?.pallet.code ?? null };
            }
            if (!box.storagePlacement)
                return emptyAuditRow(code, 'NOT_ON_PALLET_SORT');
            if (box.balances.length === 0) {
                return { ...emptyAuditRow(code, 'EMPTY'), palletCode: box.storagePlacement.pallet.code };
            }
            let canServe = false;
            let hasDemand = false;
            const externalOrders = new Set();
            const products = box.balances.map((balance) => {
                const reservations = reservationsByBoxSku.get(`${box.id}:${balance.skuId}`) ?? [];
                const reserved = reservations.reduce((sum, task) => sum + Math.max(1, task.itemCount), 0);
                const demandTasks = outstandingBySku.get(balance.skuId) ?? [];
                const required = demandTasks.reduce((sum, task) => sum + Math.max(1, task.itemCount), 0);
                if (required > 0)
                    hasDemand = true;
                demandTasks.forEach((task) => {
                    const ownReservation = reservations
                        .filter((reservation) => reservation.id === task.id)
                        .reduce((sum, reservation) => sum + Math.max(1, reservation.itemCount), 0);
                    if (balance.quantity - reserved + ownReservation >= Math.max(1, task.itemCount))
                        canServe = true;
                });
                reservations.forEach((reservation) => {
                    if (reservation.requestId !== request.id)
                        externalOrders.add(reservation.orderId);
                });
                return {
                    skuId: balance.skuId,
                    name: balance.sku.internalSku || balance.sku.name,
                    available: balance.quantity,
                    reserved,
                    free: balance.quantity - reserved,
                    required,
                };
            });
            const availableUnits = products.reduce((sum, product) => sum + product.available, 0);
            const reservedUnits = products.reduce((sum, product) => sum + product.reserved, 0);
            const requiredUnits = products.reduce((sum, product) => sum + product.required, 0);
            let state = 'OK';
            if (!canServe) {
                if (!hasDemand)
                    state = 'NO_REMAINING_DEMAND';
                else if (availableUnits - reservedUnits <= 0)
                    state = 'BLOCKED_BY_RESERVATIONS';
                else
                    state = 'SKU_OR_QUANTITY_MISMATCH';
            }
            const orders = [...externalOrders];
            return {
                code,
                state,
                stateLabel: auditStateLabel(state),
                palletCode: box.storagePlacement.pallet.code,
                availableUnits,
                reservedUnits,
                freeUnits: availableUnits - reservedUnits,
                requiredUnits,
                externalOrders: orders.slice(0, 20),
                externalOrdersCount: orders.length,
                products,
                recommendation: auditRecommendation(state),
            };
        });
        const count = (state) => rows.filter((row) => row.state === state).length;
        const healthy = count('OK');
        return {
            checkedAt: new Date().toISOString(),
            request: {
                id: request.id,
                number: request.number,
                title: request.title,
                status: request.status,
                client: request.client,
            },
            taskSummary: {
                total: allRequestTasks.reduce((sum, task) => sum + Math.max(1, task.itemCount), 0),
                completed: allRequestTasks
                    .filter((task) => task.status === 'COMPLETED')
                    .reduce((sum, task) => sum + Math.max(1, task.itemCount), 0),
                outstanding: outstandingTasks.reduce((sum, task) => sum + Math.max(1, task.itemCount), 0),
                inProgress: allRequestTasks
                    .filter((task) => task.status === 'IN_PROGRESS')
                    .reduce((sum, task) => sum + Math.max(1, task.itemCount), 0),
            },
            summary: {
                planBoxes: rows.length,
                healthy,
                issues: rows.length - healthy,
                noRemainingDemand: count('NO_REMAINING_DEMAND'),
                blockedByReservations: count('BLOCKED_BY_RESERVATIONS'),
                skuOrQuantityMismatch: count('SKU_OR_QUANTITY_MISMATCH'),
                notOnPalletSort: count('NOT_ON_PALLET_SORT'),
                empty: count('EMPTY'),
                archived: count('ARCHIVED'),
                missing: count('MISSING'),
            },
            rows,
        };
    }
};
exports.FbsRequestBoxAuditService = FbsRequestBoxAuditService;
exports.FbsRequestBoxAuditService = FbsRequestBoxAuditService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        pick_instruction_service_1.PickInstructionService])
], FbsRequestBoxAuditService);
function effectiveTaskSku(task) {
    return task.sourceSkuId && !task.relabelConfirmedAt ? task.sourceSkuId : task.skuId;
}
function normalizeCode(value) {
    return value.trim().toLocaleUpperCase('ru-RU');
}
function uniqueCodes(values) {
    return [...new Map(values.map((value) => value?.trim()).filter((value) => Boolean(value))
            .map((value) => [normalizeCode(value), value])).values()].sort((left, right) => left.localeCompare(right, 'ru-RU', { numeric: true }));
}
function emptyAuditRow(code, state) {
    return {
        code,
        state,
        stateLabel: auditStateLabel(state),
        palletCode: null,
        availableUnits: 0,
        reservedUnits: 0,
        freeUnits: 0,
        requiredUnits: 0,
        externalOrders: [],
        externalOrdersCount: 0,
        products: [],
        recommendation: auditRecommendation(state),
    };
}
function auditStateLabel(state) {
    const labels = {
        OK: 'Нужен и доступен',
        NO_REMAINING_DEMAND: 'Больше не нужен заявке',
        BLOCKED_BY_RESERVATIONS: 'Занят другими FBS-заказами',
        SKU_OR_QUANTITY_MISMATCH: 'Нужный товар недоступен',
        NOT_ON_PALLET_SORT: 'Не находится на палетсорте',
        EMPTY: 'Короб пуст по живому остатку',
        ARCHIVED: 'Короб архивирован',
        MISSING: 'Короб отсутствует в базе',
    };
    return labels[state];
}
function auditRecommendation(state) {
    const recommendations = {
        OK: 'Короб можно использовать для сборки.',
        NO_REMAINING_DEMAND: 'Убрать короб из подсказок этой заявки.',
        BLOCKED_BY_RESERVATIONS: 'Пересчитать подбор и показать свободный альтернативный короб.',
        SKU_OR_QUANTITY_MISMATCH: 'Пересчитать подбор по SKU и доступному количеству.',
        NOT_ON_PALLET_SORT: 'Убрать из подсказок либо вернуть короб на палетсорт.',
        EMPTY: 'Убрать из подсказок и проверить физический остаток.',
        ARCHIVED: 'Исключить архивный короб из плана.',
        MISSING: 'Исключить отсутствующий короб из плана.',
    };
    return recommendations[state];
}
