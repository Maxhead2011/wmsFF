"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const request_billing_automation_service_1 = require("../billing/request-billing-automation.service");
const client_notifications_module_1 = require("../client-notifications/client-notifications.module");
const expenses_module_1 = require("../expenses/expenses.module");
const logistics_module_1 = require("../logistics/logistics.module");
const fulfillment_wave_service_1 = require("./fulfillment-wave.service");
const fbs_request_box_audit_service_1 = require("./fbs-request-box-audit.service");
const pick_instruction_service_1 = require("./pick-instruction.service");
const pick_wave_document_service_1 = require("./pick-wave-document.service");
const stock_controller_1 = require("./stock.controller");
const stock_balances_service_1 = require("./stock-balances.service");
const stock_ledger_service_1 = require("./stock-ledger.service");
const stock_operations_service_1 = require("./stock-operations.service");
const storage_overview_service_1 = require("./storage-overview.service");
const volume_service_1 = require("./volume.service");
let StockModule = class StockModule {
};
exports.StockModule = StockModule;
exports.StockModule = StockModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, client_notifications_module_1.ClientNotificationsModule, expenses_module_1.ExpensesModule, logistics_module_1.LogisticsModule],
        controllers: [stock_controller_1.StockController],
        providers: [
            stock_balances_service_1.StockBalancesService,
            stock_ledger_service_1.StockLedgerService,
            stock_operations_service_1.StockOperationsService,
            storage_overview_service_1.StorageOverviewService,
            request_billing_automation_service_1.RequestBillingAutomationService,
            fulfillment_wave_service_1.FulfillmentWaveService,
            fbs_request_box_audit_service_1.FbsRequestBoxAuditService,
            pick_instruction_service_1.PickInstructionService,
            pick_wave_document_service_1.PickWaveDocumentService,
            volume_service_1.VolumeService,
        ],
        exports: [
            stock_balances_service_1.StockBalancesService,
            stock_ledger_service_1.StockLedgerService,
            stock_operations_service_1.StockOperationsService,
            storage_overview_service_1.StorageOverviewService,
            fulfillment_wave_service_1.FulfillmentWaveService,
            fbs_request_box_audit_service_1.FbsRequestBoxAuditService,
            pick_instruction_service_1.PickInstructionService,
            pick_wave_document_service_1.PickWaveDocumentService,
            volume_service_1.VolumeService,
            request_billing_automation_service_1.RequestBillingAutomationService,
        ],
    })
], StockModule);
