"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManualPickInstructionParseError = exports.manualPickInstructionDisplayFilePrefix = exports.manualPickInstructionPlanFilePrefix = exports.manualPickInstructionSourceFilePrefix = void 0;
exports.isManualPickInstructionFileName = isManualPickInstructionFileName;
exports.parseManualPickInstructionWorkbook = parseManualPickInstructionWorkbook;
const XLSX = __importStar(require("xlsx"));
exports.manualPickInstructionSourceFilePrefix = '__wms_manual_pick_instruction_source__';
exports.manualPickInstructionPlanFilePrefix = '__wms_manual_pick_instruction_plan__';
exports.manualPickInstructionDisplayFilePrefix = 'Ручная инструкция - ';
class ManualPickInstructionParseError extends Error {
    issues;
    constructor(issues) {
        super(issues.join('\n'));
        this.issues = issues;
        this.name = 'ManualPickInstructionParseError';
    }
}
exports.ManualPickInstructionParseError = ManualPickInstructionParseError;
function isManualPickInstructionFileName(fileName) {
    return (fileName.startsWith(exports.manualPickInstructionSourceFilePrefix) ||
        fileName.startsWith(exports.manualPickInstructionPlanFilePrefix) ||
        fileName.startsWith(exports.manualPickInstructionDisplayFilePrefix));
}
function parseManualPickInstructionWorkbook(buffer) {
    let workbook;
    try {
        workbook = XLSX.read(buffer, { type: 'buffer', cellDates: false });
    }
    catch {
        throw new ManualPickInstructionParseError(['Не удалось прочитать Excel-файл. Проверьте, что файл имеет формат XLSX.']);
    }
    const instructionSheet = findSheet(workbook, 'Инструкция');
    if (!instructionSheet) {
        throw new ManualPickInstructionParseError(['В файле нет обязательного листа «Инструкция».']);
    }
    const issues = [];
    const rows = parseInstructionRows(sheetMatrix(instructionSheet), issues);
    const wholeBoxesSheet = findSheet(workbook, 'Целые короба');
    const markSheet = findSheet(workbook, 'МАРК');
    const wholeBoxes = wholeBoxesSheet ? parseWholeBoxes(sheetMatrix(wholeBoxesSheet), issues) : [];
    const markRows = markSheet ? parseMarkRows(sheetMatrix(markSheet), issues) : [];
    if (rows.length === 0) {
        issues.push('На листе «Инструкция» нет строк для перестроения заявки.');
    }
    if (issues.length > 0) {
        throw new ManualPickInstructionParseError(issues.slice(0, 20));
    }
    return {
        rows,
        wholeBoxes,
        markRows,
        outboundQuantity: rows
            .filter((row) => row.kind === 'WHOLE' || row.kind === 'SHIPMENT')
            .reduce((sum, row) => sum + row.quantity, 0),
        balanceQuantity: rows.filter((row) => row.kind === 'BALANCE').reduce((sum, row) => sum + row.quantity, 0),
        shortageQuantity: rows.filter((row) => row.kind === 'SHORTAGE').reduce((sum, row) => sum + row.quantity, 0),
    };
}
function parseInstructionRows(matrix, issues) {
    const columns = requireColumns(matrix, 'Инструкция', {
        city: 'Город',
        sourceBox: 'Исходный короб',
        pallet: 'Палета',
        article: 'Артикул продавца',
        barcode: 'Баркод',
        size: 'Размер',
        quantity: 'Количество',
        comment: 'Комментарий',
        relabelNote: 'Переклейка',
        note: 'Примечание',
    }, issues);
    if (!columns) {
        return [];
    }
    const rows = [];
    matrix.slice(1).forEach((source, index) => {
        const sourceRow = index + 2;
        if (isBlankRow(source)) {
            return;
        }
        const sourceBox = textCell(source[columns.sourceBox]);
        const barcode = normalizeIdentifier(source[columns.barcode]);
        const note = textCell(source[columns.note]);
        const comment = textCell(source[columns.comment]);
        const kind = instructionKind(comment, note, sourceBox);
        const quantity = positiveInteger(source[columns.quantity]);
        if (!kind) {
            issues.push(`Лист «Инструкция», строка ${sourceRow}: укажите «ЦЕЛЫЙ», «ПОСТАВКА», «БАЛАНС» или примечание «нет на складе».`);
        }
        if (quantity === null) {
            issues.push(`Лист «Инструкция», строка ${sourceRow}: количество должно быть целым числом больше нуля.`);
        }
        if (!barcode) {
            issues.push(`Лист «Инструкция», строка ${sourceRow}: не указан баркод товара.`);
        }
        if (kind !== 'SHORTAGE' && !sourceBox) {
            issues.push(`Лист «Инструкция», строка ${sourceRow}: не указан исходный короб.`);
        }
        if (sourceBox && !isFflBox(sourceBox)) {
            issues.push(`Лист «Инструкция», строка ${sourceRow}: номер короба должен начинаться с FFL.`);
        }
        if (!kind || quantity === null || !barcode || (kind !== 'SHORTAGE' && !sourceBox) || (sourceBox && !isFflBox(sourceBox))) {
            return;
        }
        rows.push({
            sourceRow,
            city: textCell(source[columns.city]),
            sourceBox,
            pallet: textCell(source[columns.pallet]),
            article: textCell(source[columns.article]),
            barcode,
            size: textCell(source[columns.size]),
            quantity,
            kind,
            comment: canonicalComment(kind, comment),
            relabelNote: normalizeRelabelNote(source[columns.relabelNote]),
            note,
        });
    });
    return rows;
}
function parseWholeBoxes(matrix, issues) {
    if (matrix.length <= 1 || matrix.slice(1).every(isBlankRow)) {
        return [];
    }
    const columns = requireColumns(matrix, 'Целые короба', { box: 'Короб', status: 'Статус', city: 'Город', pallet: 'Палета' }, issues);
    if (!columns) {
        return [];
    }
    const rows = [];
    matrix.slice(1).forEach((source, index) => {
        const sourceRow = index + 2;
        if (isBlankRow(source)) {
            return;
        }
        const box = textCell(source[columns.box]);
        if (!box || !isFflBox(box)) {
            issues.push(`Лист «Целые короба», строка ${sourceRow}: номер короба должен начинаться с FFL.`);
            return;
        }
        rows.push({
            sourceRow,
            box,
            status: textCell(source[columns.status]) || 'ЦЕЛЫЙ',
            city: textCell(source[columns.city]),
            pallet: textCell(source[columns.pallet]),
        });
    });
    return rows;
}
function parseMarkRows(matrix, issues) {
    if (matrix.length <= 1 || matrix.slice(1).every(isBlankRow)) {
        return [];
    }
    const columns = requireColumns(matrix, 'МАРК', {
        comment: 'Комментарий',
        city: 'Город',
        sourceBox: 'Исходный короб',
        brand: 'Бренд',
        ip: 'ИП',
        name: 'Наименование',
        article: 'Артикул',
        wbArticle: 'Артикул WB',
        color: 'Цвет',
        size: 'Размер',
        barcode: 'ШК/баркод',
        quantity: 'Количество в коробе',
    }, issues);
    if (!columns) {
        return [];
    }
    const rows = [];
    matrix.slice(1).forEach((source, index) => {
        const sourceRow = index + 2;
        if (isBlankRow(source)) {
            return;
        }
        const sourceBox = textCell(source[columns.sourceBox]);
        const barcode = normalizeIdentifier(source[columns.barcode]);
        const quantity = positiveInteger(source[columns.quantity]);
        if (!sourceBox || !isFflBox(sourceBox)) {
            issues.push(`Лист «МАРК», строка ${sourceRow}: номер короба должен начинаться с FFL.`);
        }
        if (!barcode) {
            issues.push(`Лист «МАРК», строка ${sourceRow}: не указан ШК/баркод.`);
        }
        if (quantity === null) {
            issues.push(`Лист «МАРК», строка ${sourceRow}: количество должно быть целым числом больше нуля.`);
        }
        if (!sourceBox || !isFflBox(sourceBox) || !barcode || quantity === null) {
            return;
        }
        rows.push({
            sourceRow,
            comment: textCell(source[columns.comment]),
            city: textCell(source[columns.city]),
            sourceBox,
            brand: textCell(source[columns.brand]),
            ip: textCell(source[columns.ip]),
            name: textCell(source[columns.name]),
            article: textCell(source[columns.article]),
            wbArticle: textCell(source[columns.wbArticle]),
            color: textCell(source[columns.color]),
            size: textCell(source[columns.size]),
            barcode,
            quantity,
        });
    });
    return rows;
}
function requireColumns(matrix, sheetName, expected, issues) {
    const headers = matrix[0] ?? [];
    const normalized = headers.map(normalizeHeader);
    const result = {};
    const missing = [];
    for (const key of Object.keys(expected)) {
        const index = normalized.indexOf(normalizeHeader(expected[key]));
        if (index < 0) {
            missing.push(expected[key]);
        }
        else {
            result[key] = index;
        }
    }
    if (missing.length > 0) {
        issues.push(`Лист «${sheetName}»: отсутствуют колонки ${missing.join(', ')}.`);
        return null;
    }
    return result;
}
function findSheet(workbook, expectedName) {
    const expected = normalizeHeader(expectedName);
    const sheetName = workbook.SheetNames.find((name) => normalizeHeader(name) === expected);
    return sheetName ? workbook.Sheets[sheetName] : null;
}
function sheetMatrix(sheet) {
    return XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        raw: false,
        defval: '',
        blankrows: false,
    });
}
function instructionKind(comment, note, sourceBox) {
    const status = normalizeHeader(comment).toUpperCase();
    const normalizedNote = normalizeHeader(note);
    if (!sourceBox && normalizedNote.includes('нет на складе')) {
        return 'SHORTAGE';
    }
    if (status.includes('БАЛАНС')) {
        return 'BALANCE';
    }
    if (status.includes('ЦЕЛЫЙ')) {
        return 'WHOLE';
    }
    if (status.includes('ПОСТАВК')) {
        return 'SHIPMENT';
    }
    return null;
}
function canonicalComment(kind, original) {
    if (kind === 'WHOLE') {
        return normalizeHeader(original).includes('марк') ? 'МАРК ЦЕЛЫЙ' : 'ЦЕЛЫЙ';
    }
    if (kind === 'SHIPMENT') {
        return normalizeHeader(original).includes('марк') ? 'МАРК ПОСТАВКА' : 'ПОСТАВКА';
    }
    return kind === 'BALANCE' ? 'БАЛАНС' : '';
}
function normalizeRelabelNote(value) {
    const text = textCell(value);
    if (['', '-', 'нет', 'no', 'false', '0'].includes(text.toLowerCase())) {
        return '';
    }
    return isNumericIdentifier(text) ? normalizeIdentifier(text) : text;
}
function positiveInteger(value) {
    const normalized = textCell(value).replace(/\s+/g, '').replace(',', '.');
    if (!/^\d+(?:\.0+)?$/.test(normalized)) {
        return null;
    }
    const parsed = Number(normalized);
    return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}
function normalizeIdentifier(value) {
    const normalized = textCell(value).replace(/\s+/g, '').replace(',', '.').replace(/\.0$/, '');
    if (/^\d+(?:\.\d+)?e[+-]?\d+$/i.test(normalized)) {
        const numeric = Number(normalized);
        return Number.isSafeInteger(numeric) ? numeric.toFixed(0) : normalized;
    }
    return normalized;
}
function isNumericIdentifier(value) {
    return /^\d+(?:[.,]\d+)?(?:e[+-]?\d+)?$/i.test(value.replace(/\s+/g, ''));
}
function normalizeHeader(value) {
    return textCell(value)
        .toLowerCase()
        .replace(/ё/g, 'е')
        .replace(/\s+/g, ' ')
        .trim();
}
function textCell(value) {
    return value == null ? '' : String(value).trim();
}
function isBlankRow(row) {
    return row.every((value) => !textCell(value));
}
function isFflBox(value) {
    return value.trim().toUpperCase().startsWith('FFL');
}
