"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recountHash = exports.KizRecountReviewRequired = void 0;
exports.parseRecountScans = parseRecountScans;
exports.planKizRecount = planKizRecount;
exports.requireRecountSnapshot = requireRecountSnapshot;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
class KizRecountReviewRequired extends Error {
}
exports.KizRecountReviewRequired = KizRecountReviewRequired;
const recountHash = (value) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(value)).digest('hex');
exports.recountHash = recountHash;
// FIX: full physical count is explicit; reject duplicate identities before any mutation or review creation.
function parseRecountScans(payload, parse) {
    if (payload.allUnitsScanned !== true || !Array.isArray(payload.kizCodes) || !payload.kizCodes.length || payload.kizCodes.length > 200) {
        throw new common_1.BadRequestException('Подтвердите сканирование всех КИЗов выбранного товара в коробе (от 1 до 200).');
    }
    const scans = payload.kizCodes.map(value => {
        const raw = typeof value === 'string' ? value.trim() : '';
        const identity = raw.length <= 1024 ? parse(raw) : null;
        if (!identity)
            throw new common_1.BadRequestException('Сканируйте полный КИЗ каждой единицы выбранного товара.');
        return { raw, key: `01${identity.gtin}21${identity.serial}`, ...identity };
    }).sort((a, b) => a.key.localeCompare(b.key));
    if (new Set(scans.map(scan => scan.key)).size !== scans.length)
        throw new common_1.BadRequestException('Один КИЗ отсканирован повторно. Каждая единица учитывается один раз.');
    return scans;
}
// FIX: reuse stock, mark and history tables; no new inventory balance or parallel movement ledger.
async function planKizRecount(db, source, skuId, scans, parse, administrator = false, releasedAssemblyIds = [], adoptedMarkIds = []) {
    const review = (message) => { throw new KizRecountReviewRequired(message); };
    if (!source.warehouseId || !['active', 'receiving', ...(administrator ? ['archived'] : [])].includes(source.status))
        review('Короб не находится в активном хранении. Нужен разбор WMS.');
    const balances = await db.stockBalance.findMany({ where: { boxId: source.id, skuId }, orderBy: { id: 'asc' } });
    if (balances.some(row => row.clientId !== source.clientId || row.warehouseId !== source.warehouseId || row.quantity < 0 ||
        (row.status !== 'AVAILABLE' && row.quantity !== 0)))
        review('В коробе есть резерв или недоступный остаток выбранного товара.');
    const quantity = balances.filter(row => row.status === 'AVAILABLE').reduce((sum, row) => sum + row.quantity, 0);
    if (quantity !== scans.length && !administrator)
        review(`Физически отсканировано ${scans.length}, доступно в WMS ${quantity}. Количество автоматически не изменено.`);
    const previousMarks = await db.productMark.findMany({ where: { boxId: source.id, skuId }, orderBy: { id: 'asc' }, take: 201 });
    if (previousMarks.length > 200 || previousMarks.some(row => row.clientId !== source.clientId || row.status !== 'AVAILABLE'))
        review('Состав КИЗов содержит недоступные записи. Нужен разбор WMS.');
    const variants = (gtin, serial) => [`01${gtin}21${serial}`, `]d201${gtin}21${serial}`,
        `(01)${gtin}(21)${serial}`, `01${gtin}\u001d21${serial}`, `]d201${gtin}\u001d21${serial}`, `01${gtin}<GS>21${serial}`];
    const all = [...scans];
    for (const mark of previousMarks) {
        const identity = parse(mark.value);
        if (!identity)
            review('Старый КИЗ имеет неполный формат. Нужен разбор WMS.');
        all.push({ raw: mark.value, key: `01${identity.gtin}21${identity.serial}`, ...identity });
    }
    const identities = [...new Map(all.map(scan => [scan.key, scan])).values()];
    const prefixes = identities.flatMap(scan => variants(scan.gtin, scan.serial));
    const rows = await db.productMark.findMany({ where: { OR: prefixes.map(prefix => ({ value: { startsWith: prefix } })) }, take: 401 });
    if (rows.length > 400)
        review('Слишком много связанных записей КИЗ. Нужен разбор WMS.');
    const known = new Map();
    for (const row of rows) {
        const identity = parse(row.value);
        const key = identity ? `01${identity.gtin}21${identity.serial}` : '';
        if (!identities.some(scan => scan.key === key) || known.has(key) || row.clientId !== source.clientId ||
            row.skuId !== skuId || (row.boxId !== source.id && !(administrator && adoptedMarkIds.includes(row.id))) || row.status !== 'AVAILABLE') {
            review('КИЗ имеет другую принадлежность, статус или дублирующую запись. Нужен разбор WMS.');
        }
        known.set(key, row);
    }
    const kizWhere = { OR: prefixes.map(prefix => ({ kiz: { startsWith: prefix } })) };
    const conflicts = await Promise.all([
        db.fbsTsdAssembly.findFirst({ where: { OR: [kizWhere, { clientId: source.clientId,
                        status: { in: ['IN_PROGRESS', 'RETURN_REQUIRED'] }, AND: [
                            { OR: [{ skuId }, { sourceSkuId: skuId }] }, { OR: [{ boxId: source.id }, { reservedBoxId: source.id }] }
                        ] }] }, select: { id: true } }),
        db.shippedKizHistory.findFirst({ where: kizWhere, select: { id: true } }),
        // FIX: only the assemblies released in this very transaction may retain their immutable print history.
        db.fbsWebKizStickerPrint.findFirst({ where: { ...kizWhere, ...(releasedAssemblyIds.length ? { assemblyId: { notIn: releasedAssemblyIds } } : {}) }, select: { id: true } }),
        db.fbsPrintJob.findFirst({ where: { ...kizWhere, ...(releasedAssemblyIds.length ? { assemblyId: { notIn: releasedAssemblyIds } } : {}) }, select: { id: true } }),
        db.fbsAssemblyAttemptHistory.findFirst({ where: kizWhere, select: { id: true } }),
        db.kizCirculationItem.findFirst({ where: { OR: prefixes.map(prefix => ({ kizRaw: { startsWith: prefix } })) }, select: { id: true } }),
    ]);
    if (conflicts.some(Boolean))
        review('Товар или один из старых/отсканированных КИЗов связан со сборкой, отгрузкой или печатью. История и остаток не изменены.');
    const selected = new Set(scans.map(scan => scan.key));
    const retired = previousMarks.filter(mark => { const id = parse(mark.value); return !selected.has(`01${id.gtin}21${id.serial}`); });
    const registered = scans.filter(scan => !known.has(scan.key));
    return { quantity: scans.length, previousQuantity: quantity, delta: scans.length - quantity,
        balances, previousMarks, retired, registered, snapshot: (0, exports.recountHash)({ source: {
                id: source.id, clientId: source.clientId, warehouseId: source.warehouseId, palletId: source.palletId, status: source.status,
            }, skuId, balances, rows: [...rows].sort((a, b) => a.id.localeCompare(b.id)), scans: scans.map(scan => scan.key) }) };
}
function requireRecountSnapshot(actual, supplied) {
    if (typeof supplied !== 'string' || supplied !== actual)
        throw new common_1.ConflictException('Другой сотрудник изменил короб или КИЗы. Повторите сверку; ничего не изменено.');
}
