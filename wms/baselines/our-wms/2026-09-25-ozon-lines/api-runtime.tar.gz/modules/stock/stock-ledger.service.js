"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockLedgerService = void 0;
const common_1 = require("@nestjs/common");
let StockLedgerService = class StockLedgerService {
    buildInitialImportMovement(input) {
        // Русский комментарий: начальная загрузка остатков тоже идёт через ledger, чтобы история не терялась.
        return {
            ...input,
            type: 'INITIAL_IMPORT',
            status: input.status ?? 'AVAILABLE',
        };
    }
    summarizeBySku(movements) {
        return movements.reduce((acc, movement) => {
            acc[movement.skuId] = (acc[movement.skuId] ?? 0) + movement.quantity;
            return acc;
        }, {});
    }
};
exports.StockLedgerService = StockLedgerService;
exports.StockLedgerService = StockLedgerService = __decorate([
    (0, common_1.Injectable)()
], StockLedgerService);
