"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readWbShippedUnits = readWbShippedUnits;
exports.withoutWbShippedItems = withoutWbShippedItems;
const common_1 = require("@nestjs/common");
const fbs_wb_kiz_shipment_1 = require("../marketplace-connections/fbs-wb-kiz-shipment");
// FIX: immutable shipment evidence remains effective even if the feature is later disabled.
async function readWbShippedUnits(tx, request, warehouseId) {
    if (request.wbShipmentCreditsApplied || !tx.shippedKizHistory?.findMany || !tx.fbsTsdAssembly?.findMany)
        return [];
    const movements = await tx.stockMovement.findMany({ where: { clientId: request.clientId, sourceDocument: request.id,
            type: 'SHIP', quantity: { lt: 0 }, idempotencyKey: { startsWith: fbs_wb_kiz_shipment_1.WB_KIZ_SHIPMENT_PREFIX } } });
    // FIX: loadOutboundRequest has already credited these durable lifecycle facts.
    const credited = new Set(request.lifecycleShipmentAssemblyIds ?? []);
    const exact = movements.filter(row => !credited.has(row.idempotencyKey?.slice(fbs_wb_kiz_shipment_1.WB_KIZ_SHIPMENT_PREFIX.length) ?? "") && row.type === 'SHIP' && row.sourceDocument === request.id &&
        row.clientId === request.clientId && row.idempotencyKey?.startsWith(fbs_wb_kiz_shipment_1.WB_KIZ_SHIPMENT_PREFIX));
    if (!exact.length)
        return [];
    const ids = exact.map(row => row.idempotencyKey.slice(fbs_wb_kiz_shipment_1.WB_KIZ_SHIPMENT_PREFIX.length));
    const [tasks, history] = await Promise.all([
        tx.fbsTsdAssembly.findMany({ where: { id: { in: ids }, requestId: request.id, clientId: request.clientId } }),
        tx.shippedKizHistory.findMany({ where: { assemblyId: { in: ids }, requestId: request.id, clientId: request.clientId } }),
    ]);
    const used = new Map();
    return exact.map(movement => {
        const id = movement.idempotencyKey.slice(fbs_wb_kiz_shipment_1.WB_KIZ_SHIPMENT_PREFIX.length);
        const task = tasks.find(row => row.id === id);
        const record = history.find(row => row.assemblyId === id);
        const item = request.items.find(row => row.id === task?.requestItemId && row.skuId === movement.skuId);
        if (!warehouseId || movement.warehouseId !== warehouseId || movement.quantity !== -1 || !task ||
            task.status !== 'WB_ACCOUNTED' || task.itemCount !== 1 || task.requestId !== request.id || task.clientId !== request.clientId ||
            !record || record.warehouseId !== warehouseId || record.skuId !== movement.skuId || record.orderId !== task.orderId ||
            !task.kiz || record.kiz !== task.kiz || record.barcode !== task.barcode || !item) {
            throw new common_1.ConflictException('Не удалось однозначно связать отгрузку WB с позицией заявки. Повторное списание остановлено.');
        }
        const quantity = (used.get(item.id) ?? 0) + 1;
        if (quantity > item.quantity)
            throw new common_1.ConflictException('Количество отгрузок WB превышает состав заявки.');
        used.set(item.id, quantity);
        return { itemId: item.id, skuId: movement.skuId, quantity: 1, boxId: task.boxId,
            sourceBoxCode: record.sourceBoxCode ?? 'Без короба', warehouseId, movementId: movement.id, shippedAt: record.shippedAt };
    });
}
function withoutWbShippedItems(request, shipped) {
    if (!shipped.length)
        return request;
    return { ...request, wbShipmentCreditsApplied: true, items: request.items.map(item => ({ ...item,
            quantity: item.quantity - shipped.filter(unit => unit.itemId === item.id).length,
        })).filter(item => item.quantity > 0) };
}
