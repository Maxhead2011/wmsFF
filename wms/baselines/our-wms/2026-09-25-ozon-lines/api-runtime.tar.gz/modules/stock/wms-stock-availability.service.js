"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WmsStockAvailabilityService = void 0;
exports.wmsAvailableQuantity = wmsAvailableQuantity;
const wb_order_stock_lifecycle_1 = require("../../common/stock/wb-order-stock-lifecycle");
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const ACTIVE_OUTBOUND_STATUSES = [
    client_1.ClientRequestStatus.SUBMITTED,
    client_1.ClientRequestStatus.IN_REVIEW,
    client_1.ClientRequestStatus.APPROVED,
    client_1.ClientRequestStatus.IN_WORK,
    client_1.ClientRequestStatus.PACKED,
];
const NON_CURRENT_BOX_STATUSES = ['deleted', 'archived', 'shipped'];
let WmsStockAvailabilityService = class WmsStockAvailabilityService {
    prisma;
    clientScopes;
    batchSize;
    constructor(prisma, clientScopes, config) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.batchSize = boundedInteger(config.get('WMS_STOCK_EXPORT_BATCH_SIZE'), 1_000, 1, 5_000);
    }
    // FIX: every consumer now uses the same physical-stock scope and subtracts
    // only the part of an active reserve that has not left AVAILABLE already.
    async snapshot(clientIdValue, user, options = {}) {
        const clientId = clientIdValue.trim();
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const warehouseId = scopedWarehouseId(user, options.warehouseId);
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { id: true, storesWithoutBoxes: true, stockBalanceMode: true },
        });
        if (!client)
            throw new common_1.NotFoundException('Клиент для расчёта остатков не найден.');
        const aggregates = new Map();
        let missingBarcodeCount = 0;
        let cursorId;
        for (;;) {
            const skus = await this.prisma.sku.findMany({
                where: { clientId, ...(cursorId ? { id: { gt: cursorId } } : {}) },
                select: {
                    id: true,
                    barcodes: {
                        select: { value: true, isPrimary: true },
                        orderBy: [{ isPrimary: 'desc' }, { value: 'asc' }],
                    },
                },
                orderBy: { id: 'asc' },
                take: this.batchSize,
            });
            if (skus.length === 0)
                break;
            const skuIds = skus.map((sku) => sku.id);
            const [balances, requestItems] = await Promise.all([
                this.prisma.stockBalance.groupBy({
                    by: ['skuId'],
                    where: sellableBalanceWhere(client, clientId, skuIds, warehouseId),
                    _sum: { quantity: true },
                }),
                this.prisma.clientRequestItem.groupBy({
                    by: ['requestId', 'skuId'],
                    where: {
                        skuId: { in: skuIds },
                        request: {
                            clientId,
                            type: client_1.ClientRequestType.OUTBOUND,
                            status: { in: ACTIVE_OUTBOUND_STATUSES },
                            ...(warehouseId ? { warehouseId } : {}),
                        },
                    },
                    _sum: { quantity: true },
                }),
            ]);
            const requestIds = [...new Set(requestItems.map((row) => row.requestId))];
            const pickedRows = requestIds.length
                ? await this.prisma.stockMovement.groupBy({
                    by: ['sourceDocument', 'skuId'],
                    where: {
                        clientId,
                        skuId: { in: skuIds },
                        sourceDocument: { in: requestIds },
                        status: client_1.StockStatus.PACKING,
                    },
                    _sum: { quantity: true },
                })
                : [];
            const totalBySku = new Map(balances.map((row) => [row.skuId, row._sum.quantity ?? 0]));
            const pickedByRequestSku = new Map(pickedRows.map((row) => [
                requestSkuKey(row.sourceDocument, row.skuId),
                Math.max(0, row._sum.quantity ?? 0),
            ]));
            const reservedBySku = new Map();
            requestItems.forEach((row) => {
                if (!row.skuId)
                    return;
                const requested = Math.max(0, row._sum.quantity ?? 0);
                const picked = pickedByRequestSku.get(requestSkuKey(row.requestId, row.skuId)) ?? 0;
                reservedBySku.set(row.skuId, (reservedBySku.get(row.skuId) ?? 0) + Math.max(0, requested - picked));
            });
            // FIX: our WMS uses the same remaining demand as WB, including FBO picks and incoming orders.
            if ((0, wb_order_stock_lifecycle_1.wbOrderStockLifecycleEnabled)()) {
                const unified = await (0, wb_order_stock_lifecycle_1.wbReservationQuantities)(this.prisma, clientId, skuIds, warehouseId);
                reservedBySku.clear();
                unified.forEach((quantity, skuId) => reservedBySku.set(skuId, quantity));
            }
            skus.forEach((sku) => {
                const barcode = sku.barcodes[0]?.value.trim();
                if (!barcode) {
                    missingBarcodeCount += 1;
                    return;
                }
                const aggregate = aggregates.get(barcode) ?? { total: 0, reserved: 0 };
                aggregate.total += totalBySku.get(sku.id) ?? 0;
                aggregate.reserved += Math.max(0, reservedBySku.get(sku.id) ?? 0);
                aggregates.set(barcode, aggregate);
            });
            cursorId = skus[skus.length - 1].id;
            if (skus.length < this.batchSize)
                break;
        }
        const rows = [...aggregates.entries()]
            .map(([barcode, aggregate]) => ({
            barcode,
            total: aggregate.total,
            reserved: aggregate.reserved,
            available: wmsAvailableQuantity(aggregate.total, aggregate.reserved),
        }))
            .sort((left, right) => left.barcode.localeCompare(right.barcode, 'ru-RU', { numeric: true }));
        return {
            rows,
            totals: rows.reduce((sum, row) => ({
                total: sum.total + row.total,
                reserved: sum.reserved + row.reserved,
                available: sum.available + row.available,
                barcodes: sum.barcodes + 1,
            }), { total: 0, reserved: 0, available: 0, barcodes: 0 }),
            missingBarcodeCount,
            generatedAt: new Date().toISOString(),
        };
    }
};
exports.WmsStockAvailabilityService = WmsStockAvailabilityService;
exports.WmsStockAvailabilityService = WmsStockAvailabilityService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(prisma_service_1.PrismaService)),
    __param(1, (0, common_1.Inject)(client_scope_service_1.ClientScopeService)),
    __param(2, (0, common_1.Inject)(config_1.ConfigService)),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        config_1.ConfigService])
], WmsStockAvailabilityService);
// FIX: clamping happens only after every SKU carrying the same barcode has
// been aggregated, so a negative cell cannot hide stock in another cell.
function wmsAvailableQuantity(total, reserved) {
    return Math.max(0, Math.trunc(total) - Math.max(0, Math.trunc(reserved)));
}
function sellableBalanceWhere(client, clientId, skuIds, warehouseId) {
    const common = {
        clientId,
        skuId: { in: skuIds },
        status: client_1.StockStatus.AVAILABLE,
    };
    if (client.storesWithoutBoxes) {
        return { ...common, boxId: null, palletId: null, ...(warehouseId ? { warehouseId } : {}) };
    }
    const box = {
        status: { notIn: NON_CURRENT_BOX_STATUSES },
        ...(client.stockBalanceMode === client_1.ClientStockBalanceMode.PALLET_SORT
            ? { storagePlacement: warehouseId ? { is: { pallet: { warehouseId } } } : { isNot: null } }
            : warehouseId ? { warehouseId } : {}),
    };
    return { ...common, boxId: { not: null }, box };
}
function requestSkuKey(requestId, skuId) {
    return `${requestId || '-'}:${skuId}`;
}
function boundedInteger(value, fallback, min, max) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.max(min, Math.min(max, Math.trunc(parsed))) : fallback;
}
function scopedWarehouseId(user, requestedWarehouseId) {
    if (!user.activeWarehouseId || user.roleCodes.includes('CLIENT') || user.permissionCodes.includes('system:admin')) {
        return requestedWarehouseId;
    }
    return user.activeWarehouseId;
}
