"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockBalancesService = void 0;
const common_1 = require("@nestjs/common");
const wb_order_stock_lifecycle_1 = require("../../common/stock/wb-order-stock-lifecycle");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
let StockBalancesService = class StockBalancesService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    async list(filter, user) {
        // FIX: our client cabinet/export accepts only located free stock. Internal
        // operations retain physical quantities and other installations opt out.
        const locatedFreeStock = process.env.WMS_CLIENT_PALLET_SORT_FREE_STOCK_ENABLED === 'true';
        const boxStockWarehouses = new Set((process.env.WMS_CLIENT_BOX_STOCK_WAREHOUSE_IDS ?? '').split(',').map(id => id.trim()).filter(Boolean));
        const search = filter.search?.trim();
        const skuWhere = filter.barcode || search
            ? {
                ...(filter.barcode ? { barcodes: { some: { value: filter.barcode } } } : {}),
                ...(search
                    ? {
                        OR: [
                            { name: { contains: search, mode: 'insensitive' } },
                            { internalSku: { contains: search, mode: 'insensitive' } },
                            { clientSku: { contains: search, mode: 'insensitive' } },
                            { article: { contains: search, mode: 'insensitive' } },
                            { barcodes: { some: { value: { contains: search } } } },
                        ],
                    }
                    : {}),
            }
            : undefined;
        const clientFilter = this.clientScopes.resolveClientFilter(user, filter.clientId);
        const scopedWarehouseId = warehouseScopedInternalWarehouseId(user);
        // Lightweight service tests and maintenance scripts may provide a reduced
        // Prisma adapter without the Client delegate. The durable balance dimension
        // is authoritative; physical location is only a legacy fallback.
        if (typeof this.prisma.client?.findMany !== 'function') {
            return this.prisma.stockBalance.findMany({
                where: {
                    ...(scopedWarehouseId
                        ? {
                            AND: [
                                { clientId: clientFilter },
                                {
                                    OR: [
                                        { warehouseId: scopedWarehouseId },
                                        {
                                            warehouseId: null,
                                            boxId: { not: null },
                                            box: { warehouseId: scopedWarehouseId },
                                        },
                                        {
                                            warehouseId: null,
                                            boxId: null,
                                            palletId: { not: null },
                                            pallet: { zone: { warehouseId: scopedWarehouseId } },
                                        },
                                    ],
                                },
                            ],
                        }
                        : { clientId: clientFilter }),
                    skuId: filter.skuId,
                    box: filter.boxCode ? { code: filter.boxCode } : undefined,
                    sku: skuWhere,
                },
                include: {
                    sku: { include: { barcodes: true } },
                    warehouse: true,
                    box: { include: { warehouse: true } },
                    pallet: true,
                },
                orderBy: [{ updatedAt: 'desc' }],
                take: search ? 100 : undefined,
            });
        }
        const clients = await this.prisma.client.findMany({
            where: { id: clientFilter },
            select: {
                id: true,
                storesWithoutBoxes: true,
                stockBalanceMode: true,
            },
        });
        const boxlessClientIds = clients
            .filter((client) => client.storesWithoutBoxes)
            .map((client) => client.id);
        const allBoxClientIds = clients
            .filter((client) => !client.storesWithoutBoxes &&
            client.stockBalanceMode === client_1.ClientStockBalanceMode.BOXES)
            .map((client) => client.id);
        const palletSortClientIds = clients
            .filter((client) => !client.storesWithoutBoxes &&
            client.stockBalanceMode === client_1.ClientStockBalanceMode.PALLET_SORT)
            .map((client) => client.id);
        const stockModeFilter = {
            OR: [
                ...(boxlessClientIds.length
                    ? [{
                            clientId: { in: boxlessClientIds },
                            boxId: null,
                            palletId: null,
                            ...(scopedWarehouseId ? { warehouseId: scopedWarehouseId } : {}),
                        }]
                    : []),
                ...(allBoxClientIds.length
                    ? [
                        {
                            clientId: { in: allBoxClientIds },
                            boxId: { not: null },
                            box: {
                                status: { notIn: ['deleted', 'archived'] },
                                ...(scopedWarehouseId ? { warehouseId: scopedWarehouseId } : {}),
                            },
                        },
                    ]
                    : []),
                ...(palletSortClientIds.length
                    ? [
                        {
                            clientId: { in: palletSortClientIds },
                            boxId: { not: null },
                            box: {
                                status: { notIn: ['deleted', 'archived'] },
                                ...(scopedWarehouseId ? { warehouseId: scopedWarehouseId } : {}),
                                storagePlacement: scopedWarehouseId
                                    ? { is: { pallet: { warehouseId: scopedWarehouseId } } }
                                    : { isNot: null },
                            },
                        },
                    ]
                    : []),
            ],
        };
        const warehouseFilter = scopedWarehouseId
            ? {
                OR: [
                    { warehouseId: scopedWarehouseId },
                    {
                        warehouseId: null,
                        boxId: { not: null },
                        box: { warehouseId: scopedWarehouseId },
                    },
                    {
                        warehouseId: null,
                        boxId: null,
                        palletId: { not: null },
                        pallet: { zone: { warehouseId: scopedWarehouseId } },
                    },
                ],
            }
            : undefined;
        const where = {
            AND: [
                { clientId: clientFilter },
                stockModeFilter,
                ...(warehouseFilter ? [warehouseFilter] : []),
            ],
            skuId: filter.skuId,
            box: filter.boxCode
                ? {
                    ...(filter.boxCode ? { code: filter.boxCode } : {}),
                }
                : undefined,
            sku: skuWhere,
        };
        const rows = await this.prisma.stockBalance.findMany({
            where,
            include: {
                sku: { include: { barcodes: true } },
                warehouse: true,
                box: { include: { warehouse: true, ...(locatedFreeStock ? { storagePlacement: { select: { pallet: { select: { clientId: true, warehouseId: true } } } } } : {}) } },
                pallet: true,
            },
            orderBy: [{ updatedAt: 'desc' }],
            take: search ? 100 : undefined,
        });
        // FIX: preserve physical box quantities; expose free stock separately for the cabinet/export.
        if (!(0, wb_order_stock_lifecycle_1.wbOrderStockLifecycleEnabled)() && !locatedFreeStock)
            return rows;
        const freeById = new Map();
        for (const clientId of [...new Set(rows.map(row => row.clientId))]) {
            for (const warehouseId of [...new Set(rows.filter(row => row.clientId === clientId).map(row => row.warehouseId ?? row.box?.warehouseId).filter((id) => Boolean(id)))]) {
                const scoped = rows.filter(row => row.clientId === clientId && (row.warehouseId ?? row.box?.warehouseId) === warehouseId);
                const reserved = await (0, wb_order_stock_lifecycle_1.wbReservationQuantities)(this.prisma, clientId, [...new Set(scoped.map(row => row.skuId))], warehouseId);
                for (const row of scoped) {
                    const placement = (row.box && 'storagePlacement' in row.box ? row.box.storagePlacement : null);
                    // FIX: only explicitly enabled branches may expose BOXES stock without a pallet.
                    // All other branches retain the existing client-cabinet placement requirement.
                    const boxStockAllowed = boxStockWarehouses.has(warehouseId) && allBoxClientIds.includes(clientId);
                    const located = !locatedFreeStock || boxStockAllowed || Boolean(placement?.pallet && placement.pallet.clientId === clientId && placement.pallet.warehouseId === warehouseId);
                    const physical = row.status === client_1.StockStatus.AVAILABLE && located ? Math.max(0, row.quantity) : 0;
                    const deduction = Math.min(physical, reserved.get(row.skuId) ?? 0);
                    freeById.set(row.id, physical - deduction);
                    reserved.set(row.skuId, Math.max(0, (reserved.get(row.skuId) ?? 0) - deduction));
                }
            }
        }
        const result = rows.map(row => ({ ...row, freeQuantity: freeById.get(row.id) ?? 0 }));
        return locatedFreeStock && user.roleCodes?.includes('CLIENT')
            ? result.filter(row => row.freeQuantity > 0).map(row => ({ ...row, quantity: row.freeQuantity }))
            : result;
    }
    balanceKey(input) {
        // Русский комментарий: отдельный ключ убирает неоднозначность SQL NULL в составных unique-индексах.
        const parts = [
            input.clientId,
            input.skuId,
            input.boxId ?? 'no-box',
            input.palletId ?? 'no-pallet',
            input.status,
        ];
        if (!input.boxId && !input.palletId) {
            const warehouseId = input.warehouseId?.trim();
            if (!warehouseId) {
                throw new common_1.BadRequestException('Для остатка без короба необходимо однозначно указать филиал.');
            }
            parts.push('warehouse', warehouseId);
        }
        return parts.join(':');
    }
};
exports.StockBalancesService = StockBalancesService;
exports.StockBalancesService = StockBalancesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], StockBalancesService);
function warehouseScopedInternalWarehouseId(user) {
    if (!user.activeWarehouseId ||
        user.roleCodes.includes('CLIENT') ||
        user.permissionCodes.includes('system:admin')) {
        return null;
    }
    return user.activeWarehouseId;
}
