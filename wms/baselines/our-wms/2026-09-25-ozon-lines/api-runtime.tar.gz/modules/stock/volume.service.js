"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VolumeService = void 0;
const common_1 = require("@nestjs/common");
let VolumeService = class VolumeService {
    calculateLiters(input) {
        const rawLiters = (input.lengthCm * input.widthCm * input.heightCm) / 1000;
        const precision = input.precision ?? 0.01;
        const multiplier = 1 / precision;
        // Русский комментарий: округление задаётся тарифной политикой склада, поэтому режим вынесен параметром.
        const rounded = (input.mode ?? 'math') === 'ceil'
            ? Math.ceil(rawLiters * multiplier) / multiplier
            : Math.round(rawLiters * multiplier) / multiplier;
        return {
            rawLiters,
            liters: Number(rounded.toFixed(3)),
            source: 'CALCULATED',
        };
    }
    totalLiters(unitLiters, quantity) {
        return Number((unitLiters * quantity).toFixed(3));
    }
};
exports.VolumeService = VolumeService;
exports.VolumeService = VolumeService = __decorate([
    (0, common_1.Injectable)()
], VolumeService);
