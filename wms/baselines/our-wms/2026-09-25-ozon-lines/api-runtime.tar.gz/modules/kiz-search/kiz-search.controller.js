"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizSearchController = exports.KizSearchScanDto = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const kiz_search_service_1 = require("./kiz-search.service");
class KizSearchScanDto {
    boxCode;
    kiz;
}
exports.KizSearchScanDto = KizSearchScanDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(150),
    __metadata("design:type", String)
], KizSearchScanDto.prototype, "boxCode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(512),
    __metadata("design:type", String)
], KizSearchScanDto.prototype, "kiz", void 0);
// FIX: isolated endpoints confirm physical findings without stock movements.
let KizSearchController = class KizSearchController {
    service;
    constructor(service) {
        this.service = service;
    }
    list(user) { return this.service.list(user); }
    get(id, user) { return this.service.get(id, user); }
    scan(id, dto, user) { return this.service.scan(id, dto, user); }
};
exports.KizSearchController = KizSearchController;
__decorate([
    (0, common_1.Get)(),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], KizSearchController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], KizSearchController.prototype, "get", null);
__decorate([
    (0, common_1.Post)(':id/scan'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, KizSearchScanDto, Object]),
    __metadata("design:returntype", void 0)
], KizSearchController.prototype, "scan", null);
exports.KizSearchController = KizSearchController = __decorate([
    (0, common_1.Controller)('tsd/kiz-search'),
    __metadata("design:paramtypes", [kiz_search_service_1.KizSearchService])
], KizSearchController);
