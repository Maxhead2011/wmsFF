"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizSearchService = exports.SEARCH_FOUND = exports.SEARCH_CREATED = void 0;
exports.scanMatchesTarget = scanMatchesTarget;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("../client-requests/client-request-warehouse-scope");
exports.SEARCH_CREATED = 'KIZ_SEARCH_CREATED';
exports.SEARCH_FOUND = 'KIZ_SEARCH_FOUND';
// FIX: compare the physical identity, preserving case and punctuation in the serial.
function scanMatchesTarget(raw, identity) {
    if (!/^01\d{14}21[^\x1d\r\n]{13}$/.test(identity))
        return false;
    const scan = raw.trim().replace(/^\]d2/i, '').replace(/<GS>/gi, '\x1d')
        .replace(/^\(01\)(\d{14})\(21\)/, (_, gtin) => `01${gtin}21`);
    if (!scan.startsWith(identity))
        return false;
    const tail = scan.slice(identity.length);
    return tail === '' || /^\x1d91[^\x1d]{4}\x1d92[^\r\n]+$/.test(tail) || /^91.{4}92[^\r\n]+$/.test(tail);
}
let KizSearchService = class KizSearchService {
    prisma;
    config;
    scope;
    constructor(prisma, config, scope) {
        this.prisma = prisma;
        this.config = config;
        this.scope = scope;
    }
    enabled() {
        if (this.config.get('WMS_TSD_KIZ_SEARCH') !== 'true')
            throw new common_1.NotFoundException();
    }
    async list(user) {
        this.enabled();
        const markers = await this.prisma.auditLog.findMany({ where: { action: exports.SEARCH_CREATED, entity: 'ClientRequest' }, select: { entityId: true } });
        const requests = await this.prisma.clientRequest.findMany({
            where: { id: { in: markers.map(m => m.entityId).filter((id) => !!id) },
                type: 'OTHER', status: { in: ['SUBMITTED', 'IN_WORK'] }, assignedToUserId: user.id,
                clientId: this.scope.resolveClientFilter(user), ...(0, client_request_warehouse_scope_1.warehouseScopeWhere)(user) },
            orderBy: { number: 'asc' },
        });
        return Promise.all(requests.map(r => this.get(r.id, user)));
    }
    async load(db, id, user, write = false) {
        const request = await db.clientRequest.findFirst({ where: { id, type: 'OTHER', assignedToUserId: user.id }, include: { items: true } });
        if (!request)
            throw new common_1.NotFoundException('Заявка поиска не найдена или назначена другому сотруднику.');
        this.scope.requireClientAccess(user, request.clientId, write ? 'write' : 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, write ? 'write' : 'read');
        const marker = await db.auditLog.findFirst({ where: { entity: 'ClientRequest', entityId: id, action: exports.SEARCH_CREATED } });
        const data = marker?.payload;
        const targets = data?.targets;
        if (!Array.isArray(targets) || targets.length === 0 || targets.length !== request.items.length ||
            new Set(targets.map(t => t.itemId)).size !== targets.length || new Set(targets.map(t => t.kiz)).size !== targets.length ||
            targets.some(t => !request.items.some(i => i.id === t.itemId && i.quantity === 1) || !t.boxCode || !scanMatchesTarget(t.kiz, t.kiz))) {
            throw new common_1.BadRequestException('Некорректный список поиска. Обратитесь к менеджеру.');
        }
        const found = await db.auditLog.findMany({ where: { action: exports.SEARCH_FOUND, entity: 'ClientRequestItem', entityId: { in: targets.map(t => t.itemId) } }, select: { entityId: true } });
        return { request, targets, found: new Set(found.map(f => f.entityId)) };
    }
    async get(id, user) {
        this.enabled();
        const { request, targets, found } = await this.load(this.prisma, id, user);
        const boxes = await this.prisma.box.findMany({ where: { code: { in: targets.map(t => t.boxCode) }, clientId: request.clientId, warehouseId: request.warehouseId },
            select: { code: true, pallet: { select: { code: true } }, storagePlacement: { select: { pallet: { select: { code: true } } } } } });
        return { id, number: request.number, title: request.title, status: request.status, total: targets.length, found: found.size,
            items: targets.map(t => {
                const item = request.items.find(i => i.id === t.itemId);
                const box = boxes.find(b => b.code === t.boxCode);
                return { ...t, name: item.name, barcode: item.barcode, found: found.has(t.itemId),
                    pallet: box?.storagePlacement?.pallet.code ?? box?.pallet?.code ?? null };
            }) };
    }
    async scan(id, dto, user) {
        this.enabled();
        const boxCode = dto.boxCode.trim();
        // FIX: lock the request so retries/concurrent scanners cannot double-confirm or finish early.
        return this.prisma.$transaction(async (db) => {
            await db.$queryRaw `SELECT id FROM "ClientRequest" WHERE id = ${id} FOR UPDATE`;
            const { request, targets, found } = await this.load(db, id, user, true);
            if (!['SUBMITTED', 'IN_WORK', 'DONE'].includes(request.status))
                throw new common_1.BadRequestException('Поиск по этой заявке закрыт.');
            if (!targets.some(t => t.boxCode === boxCode))
                throw new common_1.BadRequestException('Этот короб не входит в заявку поиска.');
            const target = targets.find(t => scanMatchesTarget(dto.kiz, t.kiz));
            if (!target)
                return { result: 'NOT_TARGET', message: 'Этот товар не входит в список поиска. Сканируйте следующий КИЗ.', found: found.size, total: targets.length };
            if (target.boxCode !== boxCode)
                throw new common_1.BadRequestException('Нужный КИЗ найден в другом коробе. Сообщите менеджеру; находка пока не подтверждена.');
            if (found.has(target.itemId))
                return { result: 'ALREADY_FOUND', message: 'Этот товар уже найден. Отложите его отдельно.', itemId: target.itemId, found: found.size, total: targets.length };
            if (request.status === 'DONE')
                throw new common_1.BadRequestException('Заявка завершена. Обратитесь к менеджеру.');
            const count = found.size + 1;
            await db.auditLog.create({ data: { userId: user.id, action: exports.SEARCH_FOUND, entity: 'ClientRequestItem', entityId: target.itemId,
                    payload: { requestId: id, boxCode, kiz: target.kiz, order: target.order } } });
            const status = count === targets.length ? 'DONE' : 'IN_WORK';
            await db.clientRequest.update({ where: { id }, data: { status } });
            await db.clientRequestEvent.create({ data: { requestId: id, clientId: request.clientId, eventType: 'COMMENT',
                    title: `Найден товар: ${count} из ${targets.length}`, body: `Короб ${boxCode}, заказ WB ${target.order}. КИЗ подтверждён сканированием.`, createdByUserId: user.id } });
            return { result: 'FOUND', message: 'Найден нужный товар. Отложите его отдельно.', itemId: target.itemId, found: count, total: targets.length };
        });
    }
};
exports.KizSearchService = KizSearchService;
exports.KizSearchService = KizSearchService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, config_1.ConfigService,
        client_scope_service_1.ClientScopeService])
], KizSearchService);
