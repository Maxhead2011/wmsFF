"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OwnCompaniesController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const requisites_document_parser_1 = require("../../common/documents/requisites-document-parser");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const upsert_own_company_dto_1 = require("./dto/upsert-own-company.dto");
const own_companies_service_1 = require("./own-companies.service");
let OwnCompaniesController = class OwnCompaniesController {
    ownCompanies;
    constructor(ownCompanies) {
        this.ownCompanies = ownCompanies;
    }
    list(user) {
        return this.ownCompanies.list(user);
    }
    create(dto, user) {
        return this.ownCompanies.create(dto, user);
    }
    async parseRequisites(file, user) {
        await this.ownCompanies.requireWriteScope(user);
        return (0, requisites_document_parser_1.parseRequisitesDocument)(file);
    }
    update(id, dto, user) {
        return this.ownCompanies.update(id, dto, user);
    }
    uploadAsset(id, kind, file, user) {
        return this.ownCompanies.uploadAsset(id, kind, file, user);
    }
    deleteAsset(id, kind, user) {
        return this.ownCompanies.deleteAsset(id, kind, user);
    }
};
exports.OwnCompaniesController = OwnCompaniesController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], OwnCompaniesController.prototype, "list", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('own-companies:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_own_company_dto_1.UpsertOwnCompanyDto, Object]),
    __metadata("design:returntype", void 0)
], OwnCompaniesController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('parse-requisites'),
    (0, require_permissions_decorator_1.RequirePermissions)('own-companies:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OwnCompaniesController.prototype, "parseRequisites", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('own-companies:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, upsert_own_company_dto_1.UpsertOwnCompanyDto, Object]),
    __metadata("design:returntype", void 0)
], OwnCompaniesController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/assets/:kind'),
    (0, require_permissions_decorator_1.RequirePermissions)('own-companies:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 5 * 1024 * 1024 } })),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('kind')),
    __param(2, (0, common_1.UploadedFile)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", void 0)
], OwnCompaniesController.prototype, "uploadAsset", null);
__decorate([
    (0, common_1.Delete)(':id/assets/:kind'),
    (0, require_permissions_decorator_1.RequirePermissions)('own-companies:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('kind')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], OwnCompaniesController.prototype, "deleteAsset", null);
exports.OwnCompaniesController = OwnCompaniesController = __decorate([
    (0, swagger_1.ApiTags)('own-companies'),
    (0, require_permissions_decorator_1.RequirePermissions)('own-companies:read'),
    (0, common_1.Controller)('own-companies'),
    __metadata("design:paramtypes", [own_companies_service_1.OwnCompaniesService])
], OwnCompaniesController);
