"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OwnCompaniesService = void 0;
exports.ownCompanyToSeller = ownCompanyToSeller;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const billing_printing_1 = require("../billing/billing-printing");
const companyInclude = {
    bankAccounts: {
        orderBy: [{ isDefault: 'desc' }, { createdAt: 'asc' }],
    },
};
let OwnCompaniesService = class OwnCompaniesService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async list(user) {
        const admin = this.isSystemAdmin(user);
        if (admin)
            await this.ensureDefaultCompany();
        const scope = admin ? undefined : await this.companyScope(user, 'read');
        const companies = await this.prisma.ownCompany.findMany({
            where: scope,
            include: companyInclude,
            orderBy: [{ isDefault: 'desc' }, { shortName: 'asc' }],
        });
        return companies.map(serializeCompany);
    }
    async create(dto, user) {
        const admin = this.isSystemAdmin(user);
        const warehouseId = admin
            ? await this.resolveAdminWarehouseId(dto.warehouseId)
            : await this.requireWriteScope(user);
        if (warehouseId && dto.isDefault) {
            throw new common_1.BadRequestException('Компания филиала не может быть глобальной компанией по умолчанию.');
        }
        return this.prisma.$transaction(async (tx) => {
            const shouldBeDefault = warehouseId
                ? false
                : dto.isDefault ?? ((await tx.ownCompany.count({ where: { warehouseId: null } })) === 0);
            const bankAccounts = normalizeBankAccounts(dto.bankAccounts);
            if (shouldBeDefault) {
                await tx.ownCompany.updateMany({ where: { warehouseId: null }, data: { isDefault: false } });
            }
            const company = await tx.ownCompany.create({
                data: {
                    ...this.companyData(dto, shouldBeDefault, bankAccounts),
                    warehouseId,
                    bankAccounts: dto.bankAccounts
                        ? { create: bankAccounts.map(bankAccountData) }
                        : undefined,
                },
                include: companyInclude,
            });
            if (warehouseId) {
                await tx.warehouse.updateMany({
                    where: { id: warehouseId },
                    data: { ownCompanyId: company.id },
                });
            }
            else if ((await tx.ownCompany.count({ where: { isActive: true, warehouseId: null } })) === 1) {
                await tx.client.updateMany({
                    where: {
                        ownCompanyId: null,
                        warehouseLinks: {
                            none: { warehouse: { ownCompanyId: { not: null } } },
                        },
                    },
                    data: { ownCompanyId: company.id },
                });
            }
            return serializeCompany(company);
        });
    }
    async update(id, dto, user) {
        const company = await this.findScopedOrThrow(id, user, 'write');
        const admin = this.isSystemAdmin(user);
        const warehouseId = admin
            ? dto.warehouseId === undefined
                ? company.warehouseId ?? null
                : await this.resolveAdminWarehouseId(dto.warehouseId)
            : company.warehouseId ?? null;
        const isDefault = admin ? dto.isDefault ?? company.isDefault : company.isDefault;
        if (warehouseId && isDefault) {
            throw new common_1.BadRequestException('Компания филиала не может быть глобальной компанией по умолчанию.');
        }
        return this.prisma.$transaction(async (tx) => {
            const bankAccounts = normalizeBankAccounts(dto.bankAccounts);
            if (admin && dto.isDefault) {
                await tx.ownCompany.updateMany({
                    where: { id: { not: id }, warehouseId: null },
                    data: { isDefault: false },
                });
            }
            if (dto.bankAccounts) {
                const existingAccounts = await tx.ownCompanyBankAccount.findMany({
                    where: { companyId: id },
                    select: { id: true },
                });
                const existingIds = new Set(existingAccounts.map((account) => account.id));
                const requestedIds = bankAccounts
                    .map((account) => account.id)
                    .filter((accountId) => Boolean(accountId));
                if (requestedIds.some((accountId) => !existingIds.has(accountId))) {
                    throw new common_1.BadRequestException('Один из расчётных счетов не принадлежит редактируемой компании.');
                }
                await tx.ownCompanyBankAccount.deleteMany({
                    where: {
                        companyId: id,
                        id: requestedIds.length ? { notIn: requestedIds } : undefined,
                    },
                });
                for (const account of bankAccounts) {
                    if (account.id) {
                        await tx.ownCompanyBankAccount.update({
                            where: { id: account.id },
                            data: bankAccountData(account),
                        });
                    }
                    else {
                        await tx.ownCompanyBankAccount.create({
                            data: { companyId: id, ...bankAccountData(account) },
                        });
                    }
                }
            }
            await tx.ownCompany.update({
                where: { id },
                data: {
                    ...this.companyData(dto, isDefault, bankAccounts),
                    warehouseId,
                },
            });
            const updated = await tx.ownCompany.findUnique({
                where: { id },
                include: companyInclude,
            });
            return serializeCompany(updated);
        });
    }
    async findDefaultSeller() {
        await this.ensureDefaultCompany();
        const company = await this.prisma.ownCompany.findFirst({
            where: { isDefault: true, isActive: true, warehouseId: null },
            include: companyInclude,
            orderBy: { updatedAt: 'desc' },
        });
        return company ? ownCompanyToSeller(company) : billing_printing_1.BILLING_SELLER;
    }
    async findSellerForClient(clientId, bankAccountId, warehouseId) {
        const company = await this.findCompanyForClient(clientId, warehouseId);
        if (!company) {
            if (bankAccountId) {
                throw new common_1.BadRequestException('Для клиента не настроена собственная компания с этим расчётным счётом.');
            }
            return billing_printing_1.BILLING_SELLER;
        }
        const account = bankAccountId
            ? company.bankAccounts.find((item) => item.id === bankAccountId)
            : undefined;
        if (bankAccountId && !account) {
            throw new common_1.BadRequestException('Выбранный расчётный счёт не принадлежит компании этого клиента.');
        }
        return ownCompanyToSeller(company, account);
    }
    async listPaymentAccountsForClient(clientId, warehouseId) {
        const company = await this.findCompanyForClient(clientId, warehouseId);
        if (!company) {
            return {
                company: null,
                bankAccounts: [],
            };
        }
        return {
            company: {
                id: company.id,
                shortName: company.shortName,
                fullName: company.fullName,
                inn: company.inn,
            },
            bankAccounts: company.bankAccounts,
        };
    }
    async findCompanyForClient(clientId, warehouseId) {
        await this.ensureDefaultCompany();
        const scopedWarehouse = warehouseId
            ? await this.prisma.warehouse.findFirst({
                where: {
                    id: warehouseId,
                    clients: { some: { clientId, status: 'ACTIVE' } },
                },
                select: {
                    ownCompany: { include: companyInclude },
                },
            })
            : null;
        if (scopedWarehouse?.ownCompany?.isActive) {
            return scopedWarehouse.ownCompany;
        }
        const client = await this.prisma.client.findUnique({
            where: { id: clientId },
            select: { ownCompanyId: true },
        });
        const selectedCompany = client?.ownCompanyId
            ? await this.prisma.ownCompany.findFirst({
                where: {
                    id: client.ownCompanyId,
                    isActive: true,
                    ...(warehouseId
                        ? { OR: [{ warehouseId }, { warehouseId: null }] }
                        : {}),
                },
                include: companyInclude,
            })
            : null;
        const warehouseClient = this.prisma.warehouseClient;
        const legacyBranchLink = !warehouseId && !selectedCompany && warehouseClient?.findFirst
            ? await warehouseClient.findFirst({
                where: {
                    clientId,
                    status: 'ACTIVE',
                    warehouse: { ownCompanyId: { not: null } },
                },
                select: { warehouse: { select: { ownCompanyId: true } } },
                orderBy: { createdAt: 'asc' },
            })
            : null;
        const legacyBranchCompanyId = legacyBranchLink?.warehouse?.ownCompanyId;
        const legacyBranchCompany = legacyBranchCompanyId
            ? await this.prisma.ownCompany.findFirst({
                where: { id: legacyBranchCompanyId, isActive: true },
                include: companyInclude,
            })
            : null;
        return (selectedCompany ??
            legacyBranchCompany ??
            (await this.prisma.ownCompany.findFirst({
                where: { isDefault: true, isActive: true, warehouseId: null },
                include: companyInclude,
                orderBy: { updatedAt: 'desc' },
            })));
    }
    async uploadAsset(id, kindValue, file, user) {
        await this.findScopedOrThrow(id, user, 'write');
        const kind = normalizeAssetKind(kindValue);
        validateCompanyImage(file);
        const prefix = kind === 'stamp' ? 'stamp' : 'signature';
        const company = await this.prisma.ownCompany.update({
            where: { id },
            data: {
                [`${prefix}FileName`]: file.originalname,
                [`${prefix}MimeType`]: file.mimetype,
                [`${prefix}Data`]: file.buffer,
            },
            include: companyInclude,
        });
        return serializeCompany(company);
    }
    async deleteAsset(id, kindValue, user) {
        await this.findScopedOrThrow(id, user, 'write');
        const kind = normalizeAssetKind(kindValue);
        const prefix = kind === 'stamp' ? 'stamp' : 'signature';
        const company = await this.prisma.ownCompany.update({
            where: { id },
            data: {
                [`${prefix}FileName`]: null,
                [`${prefix}MimeType`]: null,
                [`${prefix}Data`]: null,
            },
            include: companyInclude,
        });
        return serializeCompany(company);
    }
    async findOrThrow(id) {
        const company = await this.prisma.ownCompany.findUnique({ where: { id } });
        if (!company) {
            throw new common_1.NotFoundException('Собственная компания не найдена.');
        }
        return company;
    }
    async findScopedOrThrow(id, user, mode) {
        const company = await this.prisma.ownCompany.findUnique({ where: { id } });
        if (!company)
            throw new common_1.NotFoundException('Собственная компания не найдена.');
        if (this.isSystemAdmin(user))
            return company;
        const warehouseId = await this.requireWarehouseScope(user, mode);
        if (company.warehouseId === warehouseId)
            return company;
        // A legacy/global company may be used by a branch as its read-only default,
        // but its requisites must not be edited by that branch manager because the
        // same legal entity can be shared by several branches.
        if (mode === 'write') {
            throw new common_1.ForbiddenException('Собственная компания относится к другому филиалу.');
        }
        const branch = await this.prisma.warehouse.findFirst({
            where: { id: warehouseId, ownCompanyId: id },
            select: { id: true },
        });
        if (!branch)
            throw new common_1.ForbiddenException('Собственная компания относится к другому филиалу.');
        return company;
    }
    async ensureDefaultCompany() {
        if (!this.prisma.ownCompany) {
            return;
        }
        const count = await this.prisma.ownCompany.count({ where: { warehouseId: null } });
        if (count > 0) {
            const activeCompanies = await this.prisma.ownCompany.findMany({
                where: { isActive: true, warehouseId: null },
                select: { id: true },
                take: 2,
            });
            if (activeCompanies.length === 1) {
                await this.prisma.client.updateMany({
                    where: {
                        ownCompanyId: null,
                        warehouseLinks: {
                            none: { warehouse: { ownCompanyId: { not: null } } },
                        },
                    },
                    data: { ownCompanyId: activeCompanies[0].id },
                });
            }
            return;
        }
        await this.prisma.ownCompany.create({
            data: {
                shortName: billing_printing_1.BILLING_SELLER.shortName,
                fullName: billing_printing_1.BILLING_SELLER.fullName,
                inn: billing_printing_1.BILLING_SELLER.inn,
                kpp: billing_printing_1.BILLING_SELLER.kpp || null,
                legalAddress: billing_printing_1.BILLING_SELLER.address || null,
                bankName: billing_printing_1.BILLING_SELLER.bankName,
                bankBik: billing_printing_1.BILLING_SELLER.bankBik,
                bankAccount: billing_printing_1.BILLING_SELLER.bankAccount,
                correspondentAccount: billing_printing_1.BILLING_SELLER.correspondentAccount,
                paymentCode: billing_printing_1.BILLING_SELLER.paymentCode,
                paymentPurposeCode: billing_printing_1.BILLING_SELLER.paymentPurposeCode,
                isDefault: true,
                warehouseId: null,
                bankAccounts: {
                    create: [
                        {
                            bankName: billing_printing_1.BILLING_SELLER.bankName,
                            bankBik: billing_printing_1.BILLING_SELLER.bankBik,
                            bankAccount: billing_printing_1.BILLING_SELLER.bankAccount,
                            correspondentAccount: billing_printing_1.BILLING_SELLER.correspondentAccount,
                            isDefault: true,
                        },
                    ],
                },
            },
        });
    }
    companyData(dto, isDefault, bankAccounts = normalizeBankAccounts(dto.bankAccounts)) {
        const defaultAccount = bankAccounts.find((account) => account.isDefault) ?? bankAccounts[0];
        return {
            shortName: dto.shortName.trim(),
            fullName: dto.fullName.trim(),
            inn: dto.inn.trim(),
            kpp: trimOrNull(dto.kpp),
            ogrn: trimOrNull(dto.ogrn),
            legalAddress: trimOrNull(dto.legalAddress),
            bankName: trimOrNull(defaultAccount?.bankName ?? dto.bankName),
            bankBik: trimOrNull(defaultAccount?.bankBik ?? dto.bankBik),
            bankAccount: trimOrNull(defaultAccount?.bankAccount ?? dto.bankAccount),
            correspondentAccount: trimOrNull(defaultAccount?.correspondentAccount ?? dto.correspondentAccount),
            paymentCode: trimOrNull(dto.paymentCode),
            paymentPurposeCode: trimOrNull(dto.paymentPurposeCode),
            isDefault: Boolean(isDefault),
            isActive: dto.isActive ?? true,
            comment: trimOrNull(dto.comment),
        };
    }
    async requireWriteScope(user) {
        if (this.isSystemAdmin(user))
            return null;
        return this.requireWarehouseScope(user, 'write');
    }
    async companyScope(user, mode) {
        const warehouseId = await this.requireWarehouseScope(user, mode);
        return {
            OR: [
                { warehouseId },
                { warehouses: { some: { id: warehouseId } } },
            ],
        };
    }
    async requireWarehouseScope(user, mode) {
        const warehouseId = user.activeWarehouseId?.trim();
        const allowed = mode === 'write' ? user.writableWarehouseIds ?? [] : user.warehouseIds ?? [];
        if (!warehouseId || !allowed.includes(warehouseId)) {
            throw new common_1.ForbiddenException(mode === 'write'
                ? 'Выберите доступный для изменения филиал.'
                : 'Выберите доступный филиал.');
        }
        const warehouse = await this.prisma.warehouse.findFirst({
            where: { id: warehouseId, isActive: true },
            select: { id: true },
        });
        if (!warehouse)
            throw new common_1.ForbiddenException('Выбранный филиал не найден или отключён.');
        return warehouse.id;
    }
    async resolveAdminWarehouseId(value) {
        const warehouseId = value?.trim() || null;
        if (!warehouseId)
            return null;
        const warehouse = await this.prisma.warehouse.findFirst({
            where: { id: warehouseId, isActive: true },
            select: { id: true },
        });
        if (!warehouse)
            throw new common_1.BadRequestException('Выбранный филиал не найден или отключён.');
        return warehouse.id;
    }
    isSystemAdmin(user) {
        return user.permissionCodes.includes('system:admin');
    }
};
exports.OwnCompaniesService = OwnCompaniesService;
exports.OwnCompaniesService = OwnCompaniesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], OwnCompaniesService);
function ownCompanyToSeller(company, selectedAccount) {
    const account = selectedAccount ??
        company.bankAccounts?.find((item) => item.isDefault) ??
        company.bankAccounts?.[0];
    return {
        shortName: company.shortName,
        fullName: company.fullName,
        inn: company.inn,
        kpp: company.kpp ?? '',
        ogrn: company.ogrn ?? '',
        address: company.legalAddress ?? '',
        bankName: account?.bankName ?? company.bankName ?? '',
        bankBik: account?.bankBik ?? company.bankBik ?? '',
        bankInn: account?.bankInn ?? '',
        bankKpp: account?.bankKpp ?? '',
        bankAccount: account?.bankAccount ?? company.bankAccount ?? '',
        correspondentAccount: account?.correspondentAccount ?? company.correspondentAccount ?? '',
        paymentCode: company.paymentCode ?? '',
        paymentPurposeCode: company.paymentPurposeCode ?? '',
        stampDataUrl: company.stampData
            ? `data:${company.stampMimeType || 'image/png'};base64,${Buffer.from(company.stampData).toString('base64')}`
            : null,
        signatureDataUrl: company.signatureData
            ? `data:${company.signatureMimeType || 'image/png'};base64,${Buffer.from(company.signatureData).toString('base64')}`
            : null,
    };
}
function serializeCompany(company) {
    const { stampData: _stampData, signatureData: _signatureData, ...safe } = company;
    return {
        ...safe,
        hasStamp: Boolean(company.stampData),
        hasSignature: Boolean(company.signatureData),
    };
}
function normalizeAssetKind(value) {
    if (value === 'stamp' || value === 'signature')
        return value;
    throw new common_1.BadRequestException('Тип изображения должен быть stamp или signature.');
}
function validateCompanyImage(file) {
    if (!file?.buffer?.length)
        throw new common_1.BadRequestException('Выберите изображение.');
    if (file.buffer.length > 5 * 1024 * 1024) {
        throw new common_1.BadRequestException('Изображение превышает 5 МБ.');
    }
    const png = file.buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
    const jpeg = file.buffer[0] === 0xff && file.buffer[1] === 0xd8 && file.buffer[2] === 0xff;
    if (!png && !jpeg) {
        throw new common_1.BadRequestException('Поддерживаются только корректные PNG и JPEG.');
    }
    if (!['image/png', 'image/jpeg'].includes(file.mimetype)) {
        throw new common_1.BadRequestException('Поддерживаются только PNG и JPEG.');
    }
}
function normalizeBankAccounts(accounts) {
    if (!accounts?.length) {
        return [];
    }
    const requestedDefault = accounts.findIndex((account) => account.isDefault);
    const defaultIndex = requestedDefault >= 0 ? requestedDefault : 0;
    return accounts.map((account, index) => ({
        ...account,
        isDefault: index === defaultIndex,
    }));
}
function bankAccountData(account) {
    return {
        bankName: account.bankName.trim(),
        bankBik: account.bankBik.trim(),
        bankInn: trimOrNull(account.bankInn),
        bankKpp: trimOrNull(account.bankKpp),
        bankAccount: account.bankAccount.trim(),
        correspondentAccount: trimOrNull(account.correspondentAccount),
        isDefault: account.isDefault,
        comment: trimOrNull(account.comment),
    };
}
function trimOrNull(value) {
    const trimmed = value?.trim();
    return trimmed ? trimmed : null;
}
