"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminNotificationsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../common/prisma/prisma.service");
// FIX: durable operational events, separate from client-facing notifications.
let AdminNotificationsService = class AdminNotificationsService {
    prisma;
    config;
    constructor(prisma, config) {
        this.prisma = prisma;
        this.config = config;
    }
    get enabled() { return this.config.get('ADMIN_OPERATIONAL_NOTIFICATIONS_ENABLED') === 'true'; }
    async record(tx, event) {
        if (!this.enabled)
            return;
        await tx.adminNotification.upsert({
            where: { dedupeKey: event.dedupeKey }, update: {},
            create: { ...event, isDemo: event.isDemo ?? false },
        });
    }
    async withEvent(operation, event) {
        if (!this.enabled)
            return operation(this.prisma);
        return this.prisma.$transaction(async (tx) => {
            const result = await operation(tx);
            const notification = await event(result, tx);
            if (notification)
                await this.record(tx, notification);
            return result;
        });
    }
    scope(user) {
        if (!user.roleCodes.includes('ADMIN'))
            throw new common_1.ForbiddenException('Уведомления доступны только администратору.');
        return {
            isDemo: user.isDemo ?? false,
            AND: [
                { clientId: user.clientScopeMode === 'LIMITED' ? { in: user.clientIds } : { notIn: user.hiddenClientIds ?? [] } },
                { clientId: { notIn: user.hiddenClientIds ?? [] } },
                ...(!user.permissionCodes.includes('system:admin') || (user.warehouseIds?.length ?? 0) > 0
                    ? [{ warehouseId: { in: user.warehouseIds ?? [] } }] : []),
            ],
        };
    }
    async list(user, beforeId) {
        const scope = this.scope(user);
        if (!this.enabled)
            return { enabled: false, items: [], popupCandidates: [], unreadCount: 0, nextBeforeId: null };
        const unread = { ...scope, receipts: { none: { userId: user.id, readAt: { not: null } } } };
        const [rows, unreadCount, pending] = await Promise.all([
            this.prisma.adminNotification.findMany({
                where: { ...scope, ...(beforeId ? { id: { lt: beforeId } } : {}) },
                orderBy: { id: 'desc' }, take: 51,
                include: { receipts: { where: { userId: user.id }, select: { readAt: true } } },
            }),
            this.prisma.adminNotification.count({ where: unread }),
            beforeId ? Promise.resolve([]) : this.prisma.adminNotification.findMany({
                where: { ...scope, receipts: { none: { userId: user.id, OR: [{ readAt: { not: null } }, { popupShownAt: { not: null } }] } } },
                orderBy: { id: 'asc' }, take: 3,
            }),
        ]);
        return {
            enabled: true, unreadCount,
            items: rows.slice(0, 50).map(({ receipts, dedupeKey, ...row }) => ({ ...row, isRead: Boolean(receipts[0]?.readAt) })),
            popupCandidates: pending.map(({ dedupeKey, ...row }) => ({ ...row, isRead: false })),
            nextBeforeId: rows.length > 50 ? rows[49].id : null,
        };
    }
    async visible(id, user) {
        const scope = this.scope(user);
        if (!this.enabled || !await this.prisma.adminNotification.findFirst({ where: { ...scope, id }, select: { id: true } })) {
            throw new common_1.NotFoundException('Уведомление недоступно.');
        }
    }
    async markRead(id, user) {
        await this.visible(id, user);
        await this.prisma.adminNotificationReceipt.upsert({
            where: { notificationId_userId: { notificationId: id, userId: user.id } },
            create: { notificationId: id, userId: user.id, readAt: new Date() }, update: { readAt: new Date() },
        });
        return { isRead: true };
    }
    async claimPopup(id, user) {
        await this.visible(id, user);
        // createMany/skipDuplicates handles simultaneous first claims from multiple tabs.
        await this.prisma.adminNotificationReceipt.createMany({ data: [{ notificationId: id, userId: user.id }], skipDuplicates: true });
        const result = await this.prisma.adminNotificationReceipt.updateMany({
            where: { notificationId: id, userId: user.id, popupShownAt: null, readAt: null },
            data: { popupShownAt: new Date() },
        });
        return { claimed: result.count === 1 };
    }
};
exports.AdminNotificationsService = AdminNotificationsService;
exports.AdminNotificationsService = AdminNotificationsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, config_1.ConfigService])
], AdminNotificationsService);
