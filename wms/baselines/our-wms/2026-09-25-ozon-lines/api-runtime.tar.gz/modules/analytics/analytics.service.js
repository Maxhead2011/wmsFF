"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const analytics_crypto_service_1 = require("./analytics-crypto.service");
const analytics_prisma_service_1 = require("./analytics-prisma.service");
const WB_ANALYTICS_URL = 'https://seller-analytics-api.wildberries.ru';
const WB_COMMON_URL = 'https://common-api.wildberries.ru';
const WB_STATISTICS_URL = 'https://statistics-api.wildberries.ru';
const PAGE_LIMIT = 1000;
const WMS_STOCK_STATUSES = [client_1.StockStatus.AVAILABLE, client_1.StockStatus.PACKING, client_1.StockStatus.SHIPPING];
let AnalyticsService = class AnalyticsService {
    prisma;
    analytics;
    clientScopes;
    crypto;
    constructor(prisma, analytics, clientScopes, crypto) {
        this.prisma = prisma;
        this.analytics = analytics;
        this.clientScopes = clientScopes;
        this.crypto = crypto;
    }
    async listClients(user) {
        this.assertAnalyticsAccess(user);
        const clientFilter = this.clientScopes.resolveClientFilter(user);
        const clients = await this.prisma.client.findMany({
            where: { id: clientFilter },
            orderBy: { name: 'asc' },
            select: { id: true, code: true, name: true },
        });
        const [connections, states] = await Promise.all([
            this.analytics.analyticsConnection.findMany({ where: { clientId: { in: clients.map((client) => client.id) } } }),
            this.analytics.analyticsSyncState.findMany({ where: { clientId: { in: clients.map((client) => client.id) } } }),
        ]);
        const connectionMap = new Map(connections.map((connection) => [connection.clientId, connection]));
        const stateMap = new Map(states.map((state) => [state.clientId, state]));
        return clients.map((client) => {
            const connection = connectionMap.get(client.id);
            const state = stateMap.get(client.id);
            return {
                ...client,
                connection: connection
                    ? {
                        connected: connection.isActive,
                        marketplace: connection.marketplace,
                        accountName: connection.accountName,
                        lastVerifiedAt: connection.lastVerifiedAt,
                    }
                    : { connected: false, marketplace: 'WILDBERRIES', accountName: null, lastVerifiedAt: null },
                sync: state
                    ? {
                        status: state.status,
                        periodDays: state.periodDays,
                        productCount: state.productCount,
                        lastSyncedAt: state.lastSyncedAt,
                        lastError: state.lastError,
                    }
                    : null,
            };
        });
    }
    async upsertConnection(clientId, dto, user) {
        if (!user.permissionCodes.includes('system:admin')) {
            throw new common_1.ForbiddenException('Подключать API аналитики может только администратор.');
        }
        const client = await this.prisma.client.findUnique({ where: { id: clientId }, select: { id: true, code: true, name: true } });
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
        const apiKey = dto.apiKey.trim();
        const seller = await wbJson(`${WB_COMMON_URL}/api/v1/seller-info`, apiKey);
        const accountName = textValue(seller.name) || textValue(seller.tradeMark) || 'Wildberries';
        const sellerSid = textValue(seller.sid) || null;
        const now = new Date();
        const connection = await this.analytics.analyticsConnection.upsert({
            where: { clientId },
            create: {
                clientId,
                marketplace: 'WILDBERRIES',
                accountName,
                sellerSid,
                apiKeyEncrypted: this.crypto.encrypt(apiKey),
                isActive: true,
                lastVerifiedAt: now,
            },
            update: {
                accountName,
                sellerSid,
                apiKeyEncrypted: this.crypto.encrypt(apiKey),
                isActive: true,
                lastVerifiedAt: now,
            },
        });
        return {
            client,
            connected: true,
            marketplace: connection.marketplace,
            accountName: connection.accountName,
            lastVerifiedAt: connection.lastVerifiedAt,
        };
    }
    async sync(dto, user) {
        this.assertAnalyticsAccess(user);
        this.clientScopes.requireClientAccess(user, dto.clientId, 'read');
        const [client, connection, currentState] = await Promise.all([
            this.prisma.client.findUnique({ where: { id: dto.clientId }, select: { id: true, name: true } }),
            this.analytics.analyticsConnection.findUnique({ where: { clientId: dto.clientId } }),
            this.analytics.analyticsSyncState.findUnique({ where: { clientId: dto.clientId } }),
        ]);
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
        if (!connection?.isActive) {
            throw new common_1.BadRequestException('Для клиента не подключён API-ключ аналитики Wildberries.');
        }
        const now = new Date();
        if (currentState?.status === 'RUNNING' && currentState.lastStartedAt && now.getTime() - currentState.lastStartedAt.getTime() < 10 * 60_000) {
            throw new common_1.ConflictException('Синхронизация аналитики уже выполняется.');
        }
        if (currentState?.lastStartedAt && now.getTime() - currentState.lastStartedAt.getTime() < 60_000) {
            throw new common_1.HttpException('Wildberries разрешает обновлять аналитику не чаще одного раза в минуту.', common_1.HttpStatus.TOO_MANY_REQUESTS);
        }
        await this.analytics.analyticsSyncState.upsert({
            where: { clientId: dto.clientId },
            create: { clientId: dto.clientId, status: 'RUNNING', periodDays: dto.periodDays, lastStartedAt: now },
            update: { status: 'RUNNING', periodDays: dto.periodDays, lastStartedAt: now, lastError: null },
        });
        try {
            const apiKey = this.crypto.decrypt(connection.apiKeyEncrypted);
            const periods = analyticsPeriods(dto.periodDays);
            const [stockResult, funnelResult, regionsResult, regionalSalesResult] = await Promise.allSettled([
                this.fetchStockProducts(apiKey, periods.selected),
                this.fetchFunnelProducts(apiKey, periods),
                this.fetchRegions(apiKey, periods.selected),
                this.fetchRegionalSales(apiKey, analyticsPeriods(Math.min(dto.periodDays, 30))),
            ]);
            const syncedAt = new Date();
            const cachedCoreAllowed = (stockResult.status === 'rejected' && isGlobalLimiterError(stockResult.reason)) ||
                (funnelResult.status === 'rejected' && isGlobalLimiterError(funnelResult.reason));
            const cachedProducts = cachedCoreAllowed
                ? await this.analytics.analyticsProduct.findMany({ where: { clientId: dto.clientId } })
                : [];
            if (stockResult.status === 'rejected' && (!isGlobalLimiterError(stockResult.reason) || cachedProducts.length === 0)) {
                throw sourceError('остатки и показатели товаров', stockResult.reason);
            }
            if (funnelResult.status === 'rejected' && (!isGlobalLimiterError(funnelResult.reason) || cachedProducts.length === 0)) {
                throw sourceError('воронка продаж', funnelResult.reason);
            }
            const usingCachedProducts = stockResult.status === 'rejected' || funnelResult.status === 'rejected';
            const products = usingCachedProducts
                ? cachedProducts
                : mergeProducts(dto.clientId, stockResult.value, funnelResult.value, syncedAt);
            const regions = regionsResult.status === 'fulfilled' ? mapRegions(dto.clientId, regionsResult.value, syncedAt) : [];
            const regionalSales = regionalSalesResult.status === 'fulfilled'
                ? mapRegionalSales(dto.clientId, regionalSalesResult.value.current, regionalSalesResult.value.past, syncedAt)
                : [];
            const currency = (funnelResult.status === 'fulfilled' ? funnelResult.value.currency : null) ||
                (stockResult.status === 'fulfilled' ? stockResult.value.currency : null) ||
                currentState?.currency ||
                'RUB';
            const totals = productTotals(products);
            const sourceStatus = {
                products: stockResult.status === 'fulfilled' ? 'READY' : 'CACHED_RATE_LIMITED',
                funnel: funnelResult.status === 'fulfilled' ? 'READY' : 'CACHED_RATE_LIMITED',
                regions: regionsResult.status === 'fulfilled' ? 'READY' : 'CACHED_RATE_LIMITED',
                regionalSales: regionalSalesResult.status === 'fulfilled' ? `READY_${regionalSalesResult.value.source}` : 'CACHED_RATE_LIMITED',
                exactWarehouseProductStock: 'REQUIRES_PERSONAL_OR_SERVICE_TOKEN',
            };
            const warnings = [
                usingCachedProducts ? 'Товары: WB исчерпал лимит запросов, сохранены последние успешно загруженные данные.' : null,
                regionsResult.status === 'rejected' ? `Склады: ${safeErrorMessage(regionsResult.reason)}` : null,
                regionalSalesResult.status === 'rejected' ? `Продажи по регионам: ${safeErrorMessage(regionalSalesResult.reason)}` : null,
            ].filter((value) => Boolean(value));
            const regionalWarning = warnings.join(' · ') || null;
            const snapshotDate = new Date(`${periods.today}T00:00:00.000Z`);
            const productWrites = usingCachedProducts
                ? []
                : [
                    this.analytics.analyticsProduct.deleteMany({ where: { clientId: dto.clientId } }),
                    this.analytics.analyticsProduct.createMany({ data: products }),
                ];
            const regionWrites = regionsResult.status === 'fulfilled'
                ? [
                    this.analytics.analyticsRegion.deleteMany({ where: { clientId: dto.clientId } }),
                    this.analytics.analyticsRegion.createMany({ data: regions }),
                ]
                : [];
            const regionalSalesWrites = regionalSalesResult.status === 'fulfilled'
                ? [
                    this.analytics.analyticsRegionalSale.deleteMany({ where: { clientId: dto.clientId } }),
                    this.analytics.analyticsRegionalSale.createMany({ data: regionalSales }),
                ]
                : [];
            await this.analytics.$transaction([
                ...productWrites,
                ...regionWrites,
                ...regionalSalesWrites,
                this.analytics.analyticsDailySummary.upsert({
                    where: { clientId_snapshotDate: { clientId: dto.clientId, snapshotDate } },
                    create: { clientId: dto.clientId, snapshotDate, periodDays: dto.periodDays, ...totals },
                    update: { periodDays: dto.periodDays, ...totals },
                }),
                this.analytics.analyticsSyncState.update({
                    where: { clientId: dto.clientId },
                    data: {
                        status: regionalWarning ? 'READY_WITH_WARNINGS' : 'READY',
                        periodDays: dto.periodDays,
                        currency,
                        productCount: products.length,
                        lastSyncedAt: syncedAt,
                        lastError: regionalWarning,
                        sourceStatus: sourceStatus,
                    },
                }),
            ]);
            return this.dashboard({ clientId: dto.clientId, limit: 100, offset: 0 }, user);
        }
        catch (caught) {
            const message = safeErrorMessage(caught);
            await this.analytics.analyticsSyncState.update({
                where: { clientId: dto.clientId },
                data: { status: 'ERROR', lastError: message.slice(0, 1000) },
            });
            if (caught instanceof common_1.BadGatewayException || caught instanceof common_1.BadRequestException)
                throw caught;
            throw new common_1.BadGatewayException(`Не удалось обновить аналитику Wildberries: ${message}`);
        }
    }
    async syncRegionalDemand(clientId, periodDays = 30) {
        const [connection, state] = await Promise.all([
            this.analytics.analyticsConnection.findUnique({ where: { clientId } }),
            this.analytics.analyticsSyncState.findUnique({ where: { clientId } }),
        ]);
        if (!connection?.isActive)
            throw new common_1.BadRequestException('Для клиента не подключён API-ключ аналитики Wildberries.');
        const apiKey = this.crypto.decrypt(connection.apiKeyEncrypted);
        const periods = analyticsPeriods(Math.min(periodDays, 30));
        const fetched = await this.fetchRegionalSales(apiKey, periods, 0, 10_500);
        const syncedAt = new Date();
        const rows = mapRegionalSales(clientId, fetched.current, fetched.past, syncedAt);
        if (rows.length === 0)
            throw new common_1.BadGatewayException('Wildberries не вернул продажи по регионам за выбранные периоды.');
        const previousStatus = asRecord(state?.sourceStatus);
        const sourceStatus = { ...previousStatus, regionalSales: `READY_${fetched.source}` };
        const coreCached = ['products', 'funnel', 'regions'].some((key) => textValue(sourceStatus[key]).startsWith('CACHED'));
        await this.analytics.$transaction([
            this.analytics.analyticsRegionalSale.deleteMany({ where: { clientId } }),
            this.analytics.analyticsRegionalSale.createMany({ data: rows }),
            this.analytics.analyticsSyncState.upsert({
                where: { clientId },
                create: {
                    clientId,
                    status: coreCached ? 'READY_WITH_WARNINGS' : 'READY',
                    periodDays,
                    productCount: 0,
                    lastSyncedAt: syncedAt,
                    lastError: coreCached ? 'Региональные продажи обновлены; основные показатели временно сохранены из кэша WB.' : null,
                    sourceStatus: sourceStatus,
                },
                update: {
                    status: coreCached ? 'READY_WITH_WARNINGS' : 'READY',
                    lastSyncedAt: syncedAt,
                    lastError: coreCached ? 'Региональные продажи обновлены; основные показатели временно сохранены из кэша WB.' : null,
                    sourceStatus: sourceStatus,
                },
            }),
        ]);
        return { rows: rows.length, source: fetched.source, syncedAt };
    }
    async dashboard(query, user) {
        this.assertAnalyticsAccess(user);
        this.clientScopes.requireClientAccess(user, query.clientId, 'read');
        const [client, connection, state, storedProducts, regions, regionalSales, history] = await Promise.all([
            this.prisma.client.findUnique({ where: { id: query.clientId }, select: { id: true, code: true, name: true } }),
            this.analytics.analyticsConnection.findUnique({ where: { clientId: query.clientId } }),
            this.analytics.analyticsSyncState.findUnique({ where: { clientId: query.clientId } }),
            this.analytics.analyticsProduct.findMany({ where: { clientId: query.clientId }, orderBy: [{ orderSum: 'desc' }, { stockCount: 'asc' }] }),
            this.analytics.analyticsRegion.findMany({ where: { clientId: query.clientId }, orderBy: [{ stockCount: 'desc' }, { officeName: 'asc' }] }),
            this.analytics.analyticsRegionalSale.findMany({ where: { clientId: query.clientId }, orderBy: { currentQty: 'desc' } }),
            this.analytics.analyticsDailySummary.findMany({ where: { clientId: query.clientId }, orderBy: { snapshotDate: 'asc' }, take: 90 }),
        ]);
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
        const wmsStock = await this.wmsStock(query.clientId, storedProducts.map((product) => product.nmId));
        const products = storedProducts.map((product) => ({
            ...product,
            wmsStock: wmsStock.byNmId.get(product.nmId)?.quantity ?? 0,
            wmsSkuCount: wmsStock.byNmId.get(product.nmId)?.skuCount ?? 0,
        }));
        const totals = dashboardTotals(products, wmsStock);
        const recommendations = buildRecommendations(products);
        const regionalAnalytics = buildRegionalAnalytics(products, regions, regionalSales, Math.min(state?.periodDays ?? 30, 30));
        const filtered = products.filter((product) => matchesProduct(product, query.search, query.availability));
        const offset = query.offset ?? 0;
        const limit = query.limit ?? 100;
        return {
            generatedAt: new Date().toISOString(),
            client,
            access: {
                analyticsEnabled: true,
                canManageConnection: user.permissionCodes.includes('system:admin'),
                canSync: Boolean(connection?.isActive),
            },
            connection: connection
                ? {
                    connected: connection.isActive,
                    marketplace: connection.marketplace,
                    accountName: connection.accountName,
                    lastVerifiedAt: connection.lastVerifiedAt,
                }
                : { connected: false, marketplace: 'WILDBERRIES', accountName: null, lastVerifiedAt: null },
            sync: state
                ? {
                    status: state.status,
                    periodDays: state.periodDays,
                    currency: state.currency,
                    productCount: state.productCount,
                    lastStartedAt: state.lastStartedAt,
                    lastSyncedAt: state.lastSyncedAt,
                    lastError: state.lastError,
                    sourceStatus: state.sourceStatus,
                }
                : null,
            totals,
            recommendations,
            regionalAnalytics,
            products: {
                total: filtered.length,
                limit,
                offset,
                items: filtered.slice(offset, offset + limit),
            },
            regions: regions.map((region) => ({
                regionName: region.regionName,
                officeId: region.officeId,
                officeName: region.officeName,
                stockCount: region.stockCount,
                stockSum: region.stockSum,
                toClientCount: region.toClientCount,
                fromClientCount: region.fromClientCount,
                saleRateDays: region.saleRateDays,
            })),
            history: history.map((item) => ({
                date: item.snapshotDate,
                periodDays: item.periodDays,
                productCount: item.productCount,
                stockCount: item.stockCount,
                stockSum: item.stockSum,
                ordersCount: item.ordersCount,
                ordersSum: item.ordersSum,
                buyoutCount: item.buyoutCount,
                buyoutSum: item.buyoutSum,
                lostOrdersSum: item.lostOrdersSum,
            })),
        };
    }
    async fetchStockProducts(apiKey, period) {
        const items = [];
        let currency = 'RUB';
        for (let offset = 0; offset < 50_000; offset += PAGE_LIMIT) {
            const response = await wbJson(`${WB_ANALYTICS_URL}/api/v2/stocks-report/products/products`, apiKey, {
                nmIDs: [],
                currentPeriod: period,
                stockType: '',
                skipDeletedNm: true,
                orderBy: { field: 'avgOrders', mode: 'desc' },
                availabilityFilters: [],
                limit: PAGE_LIMIT,
                offset,
            });
            const data = asRecord(response.data);
            const page = asArray(data.items).map(asRecord);
            items.push(...page);
            currency = textValue(data.currency) || currency;
            if (page.length < PAGE_LIMIT)
                break;
            await delay(20_500);
        }
        return { items, currency };
    }
    async fetchFunnelProducts(apiKey, periods) {
        const products = [];
        let currency = 'RUB';
        for (let offset = 0; offset < 50_000; offset += PAGE_LIMIT) {
            const response = await wbJson(`${WB_ANALYTICS_URL}/api/analytics/v3/sales-funnel/products`, apiKey, {
                selectedPeriod: periods.selected,
                pastPeriod: periods.past,
                nmIds: [],
                brandNames: [],
                subjectIds: [],
                tagIds: [],
                skipDeletedNm: true,
                orderBy: { field: 'orderCount', mode: 'desc' },
                limit: PAGE_LIMIT,
                offset,
            });
            const data = asRecord(response.data);
            const page = asArray(data.products).map(asRecord);
            products.push(...page);
            currency = textValue(data.currency) || currency;
            if (page.length < PAGE_LIMIT)
                break;
            await delay(20_500);
        }
        return { products, currency };
    }
    async fetchRegions(apiKey, period) {
        const response = await wbJson(`${WB_ANALYTICS_URL}/api/v2/stocks-report/offices`, apiKey, {
            nmIDs: [],
            subjectIDs: [],
            brandNames: [],
            tagIDs: [],
            currentPeriod: period,
            stockType: '',
            skipDeletedNm: true,
        });
        return asArray(asRecord(response.data).regions).map(asRecord);
    }
    async fetchRegionalSales(apiKey, periods, analyticsInitialDelayMs = 20_500, analyticsPeriodDelayMs = 20_500) {
        try {
            return await this.fetchRegionalSalesFromStatistics(apiKey, periods);
        }
        catch {
            return this.fetchRegionalSalesFromAnalytics(apiKey, periods, analyticsInitialDelayMs, analyticsPeriodDelayMs);
        }
    }
    async fetchRegionalSalesFromStatistics(apiKey, periods) {
        const dateFrom = `${periods.past.start}T00:00:00`;
        const rows = await wbArray(`${WB_STATISTICS_URL}/api/v1/supplier/sales?${new URLSearchParams({ dateFrom, flag: '0' })}`, apiKey);
        const current = [];
        const past = [];
        for (const row of rows.map(asRecord)) {
            if (textValue(row.saleID).toLocaleUpperCase('en-US').startsWith('R'))
                continue;
            const date = textValue(row.date).slice(0, 10);
            const target = dateInPeriod(date, periods.selected) ? current : dateInPeriod(date, periods.past) ? past : null;
            if (!target)
                continue;
            target.push({
                cityName: '',
                countryName: row.countryName,
                foName: row.oblastOkrugName,
                regionName: row.regionName,
                nmID: row.nmId,
                saleInvoiceCostPrice: numberValue(row.finishedPrice) || numberValue(row.priceWithDisc),
                saleItemInvoiceQty: 1,
            });
        }
        return { current, past, source: 'STATISTICS_SALES' };
    }
    async fetchRegionalSalesFromAnalytics(apiKey, periods, initialDelayMs, periodDelayMs) {
        // WB applies a seller-wide limiter across analytics methods. Let the core
        // product requests finish, then keep the two region periods apart.
        if (initialDelayMs > 0)
            await delay(initialDelayMs);
        const current = await wbJson(`${WB_ANALYTICS_URL}/api/v1/analytics/region-sale?${periodQuery(periods.selected)}`, apiKey);
        await delay(periodDelayMs);
        const past = await wbJson(`${WB_ANALYTICS_URL}/api/v1/analytics/region-sale?${periodQuery(periods.past)}`, apiKey);
        return {
            current: asArray(current.report).map(asRecord),
            past: asArray(past.report).map(asRecord),
            source: 'REGION_SALE',
        };
    }
    async wmsStock(clientId, nmIds) {
        const requestedNmIds = new Set(nmIds);
        const [total, skus] = await Promise.all([
            this.prisma.stockBalance.aggregate({
                where: { clientId, quantity: { gt: 0 }, status: { in: WMS_STOCK_STATUSES } },
                _sum: { quantity: true },
            }),
            this.prisma.sku.findMany({
                where: {
                    clientId,
                    marketplace: client_1.MarketplaceType.WILDBERRIES,
                    marketplaceProductId: { not: null },
                    balances: { some: { status: { in: WMS_STOCK_STATUSES }, quantity: { gt: 0 } } },
                },
                select: {
                    marketplaceProductId: true,
                    balances: {
                        where: { status: { in: WMS_STOCK_STATUSES }, quantity: { gt: 0 } },
                        select: { quantity: true },
                    },
                },
            }),
        ]);
        const byNmId = new Map();
        let matchedQuantity = 0;
        for (const sku of skus) {
            if (!sku.marketplaceProductId)
                continue;
            // WB stores the product and size as "nmId:sizeId" in the WMS card; analytics is aggregated by nmId.
            const nmId = sku.marketplaceProductId.split(':', 1)[0];
            if (!requestedNmIds.has(nmId))
                continue;
            const current = byNmId.get(nmId) ?? { quantity: 0, skuCount: 0 };
            const quantity = sku.balances.reduce((sum, balance) => sum + balance.quantity, 0);
            current.quantity += quantity;
            current.skuCount += 1;
            matchedQuantity += quantity;
            byNmId.set(nmId, current);
        }
        const totalQuantity = total._sum.quantity ?? 0;
        return {
            byNmId,
            totalQuantity,
            matchedQuantity,
            unlinkedQuantity: Math.max(0, totalQuantity - matchedQuantity),
        };
    }
    assertAnalyticsAccess(user) {
        if (!user.analyticsEnabled) {
            throw new common_1.ForbiddenException('Раздел «Аналитика» отключён в профиле этого логина.');
        }
    }
};
exports.AnalyticsService = AnalyticsService;
exports.AnalyticsService = AnalyticsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        analytics_prisma_service_1.AnalyticsPrismaService,
        client_scope_service_1.ClientScopeService,
        analytics_crypto_service_1.AnalyticsCryptoService])
], AnalyticsService);
function analyticsPeriods(days) {
    const today = moscowDate(new Date());
    const selectedEnd = shiftDate(today, -1);
    const selectedStart = shiftDate(selectedEnd, -(days - 1));
    const pastEnd = shiftDate(selectedStart, -1);
    const pastStart = shiftDate(pastEnd, -(days - 1));
    return { today, selected: { start: selectedStart, end: selectedEnd }, past: { start: pastStart, end: pastEnd } };
}
function moscowDate(date) {
    return new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Moscow', year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
}
function shiftDate(value, days) {
    const date = new Date(`${value}T12:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
}
function mergeProducts(clientId, stockReport, funnelReport, syncedAt) {
    const stocks = new Map(stockReport.items.map((item) => [textValue(item.nmID), item]));
    const funnels = new Map(funnelReport.products.map((item) => {
        const product = asRecord(item.product);
        return [textValue(product.nmId), item];
    }));
    const nmIds = [...new Set([...stocks.keys(), ...funnels.keys()].filter(Boolean))];
    return nmIds.map((nmId) => {
        const stock = stocks.get(nmId) ?? {};
        const funnel = funnels.get(nmId) ?? {};
        const product = asRecord(funnel.product);
        const stockMetrics = asRecord(stock.metrics);
        const statistic = asRecord(funnel.statistic);
        const selected = asRecord(statistic.selected);
        const past = asRecord(statistic.past);
        const comparison = asRecord(statistic.comparison);
        const conversions = asRecord(selected.conversions);
        const price = asRecord(stockMetrics.currentPrice);
        return {
            clientId,
            nmId,
            name: textValue(stock.name) || textValue(product.title) || `Товар WB ${nmId}`,
            vendorCode: nullableText(stock.vendorCode) ?? nullableText(product.vendorCode),
            brandName: nullableText(stock.brandName) ?? nullableText(product.brandName),
            subjectName: nullableText(stock.subjectName) ?? nullableText(product.subjectName),
            photoUrl: nullableText(stock.mainPhoto),
            availability: nullableText(stockMetrics.availability),
            stockCount: numberValue(stockMetrics.stockCount),
            stockSum: numberValue(stockMetrics.stockSum),
            avgOrders: numberValue(stockMetrics.avgOrders),
            ordersCount: numberValue(stockMetrics.ordersCount),
            ordersSum: numberValue(stockMetrics.ordersSum),
            buyoutCount: numberValue(stockMetrics.buyoutCount),
            buyoutSum: numberValue(stockMetrics.buyoutSum),
            buyoutPercent: numberValue(stockMetrics.buyoutPercent),
            lostOrdersCount: numberValue(stockMetrics.lostOrdersCount),
            lostOrdersSum: numberValue(stockMetrics.lostOrdersSum),
            lostBuyoutsCount: numberValue(stockMetrics.lostBuyoutsCount),
            lostBuyoutsSum: numberValue(stockMetrics.lostBuyoutsSum),
            turnoverDays: durationDays(stockMetrics.avgStockTurnover),
            saleRateDays: durationDays(stockMetrics.saleRate),
            currentPriceMin: nullableNumber(price.minPrice),
            currentPriceMax: nullableNumber(price.maxPrice),
            openCount: numberValue(selected.openCount),
            cartCount: numberValue(selected.cartCount),
            orderCount: numberValue(selected.orderCount),
            orderSum: numberValue(selected.orderSum),
            funnelBuyoutCount: numberValue(selected.buyoutCount),
            funnelBuyoutSum: numberValue(selected.buyoutSum),
            cancelCount: numberValue(selected.cancelCount),
            cancelSum: numberValue(selected.cancelSum),
            addToCartPercent: numberValue(conversions.addToCartPercent),
            cartToOrderPercent: numberValue(conversions.cartToOrderPercent),
            funnelBuyoutPercent: numberValue(conversions.buyoutPercent),
            orderCountDynamic: numberValue(comparison.orderCountDynamic),
            orderSumDynamic: numberValue(comparison.orderSumDynamic),
            openCountDynamic: numberValue(comparison.openCountDynamic),
            cartCountDynamic: numberValue(comparison.cartCountDynamic),
            selectedMetrics: selected,
            pastMetrics: past,
            comparisonMetrics: comparison,
            stockMetrics: stockMetrics,
            syncedAt,
        };
    });
}
function mapRegions(clientId, values, syncedAt) {
    const rows = [];
    for (const region of values) {
        const regionName = textValue(region.regionName) || 'Без региона';
        const regionMetrics = asRecord(region.metrics);
        rows.push(regionRow(clientId, `region:${regionName}`, regionName, null, null, regionMetrics, syncedAt));
        for (const officeValue of asArray(region.offices)) {
            const office = asRecord(officeValue);
            const officeId = textValue(office.officeID) || textValue(office.officeId) || textValue(office.officeName);
            rows.push(regionRow(clientId, `office:${officeId}`, regionName, officeId || null, nullableText(office.officeName), asRecord(office.metrics), syncedAt));
        }
    }
    return rows;
}
function regionRow(clientId, regionKey, regionName, officeId, officeName, metrics, syncedAt) {
    return {
        clientId,
        regionKey,
        regionName,
        officeId,
        officeName,
        stockCount: numberValue(metrics.stockCount),
        stockSum: numberValue(metrics.stockSum),
        toClientCount: numberValue(metrics.toClientCount),
        fromClientCount: numberValue(metrics.fromClientCount),
        saleRateDays: durationDays(metrics.saleRate),
        metrics: metrics,
        syncedAt,
    };
}
function mapRegionalSales(clientId, currentRows, pastRows, syncedAt) {
    const buckets = new Map();
    const add = (row, period) => {
        const nmId = textValue(row.nmID);
        if (!nmId)
            return;
        const regionName = normalizeDemandRegion(row);
        const regionKey = regionName.toLocaleLowerCase('ru-RU');
        const key = `${regionKey}:${nmId}`;
        const bucket = buckets.get(key) ?? {
            regionKey,
            regionName,
            nmId,
            currentQty: 0,
            currentAmount: 0,
            pastQty: 0,
            pastAmount: 0,
            locations: new Set(),
        };
        const quantity = Math.max(0, numberValue(row.saleItemInvoiceQty));
        const amount = Math.max(0, numberValue(row.saleInvoiceCostPrice) * quantity);
        if (period === 'current') {
            bucket.currentQty += quantity;
            bucket.currentAmount += amount;
            bucket.locations.add([textValue(row.countryName), textValue(row.regionName), textValue(row.cityName)].join('|'));
        }
        else {
            bucket.pastQty += quantity;
            bucket.pastAmount += amount;
        }
        buckets.set(key, bucket);
    };
    currentRows.forEach((row) => add(row, 'current'));
    pastRows.forEach((row) => add(row, 'past'));
    return [...buckets.values()].map((bucket) => ({
        clientId,
        regionKey: bucket.regionKey,
        regionName: bucket.regionName,
        nmId: bucket.nmId,
        currentQty: roundMetric(bucket.currentQty),
        currentAmount: roundMetric(bucket.currentAmount),
        pastQty: roundMetric(bucket.pastQty),
        pastAmount: roundMetric(bucket.pastAmount),
        locationsCount: bucket.locations.size,
        syncedAt,
    }));
}
function normalizeDemandRegion(row) {
    const country = textValue(row.countryName);
    const district = textValue(row.foName) || textValue(row.oblastOkrugName);
    if (country && country !== 'Россия')
        return country;
    if (district.includes('Централь'))
        return 'Центральный';
    if (district.includes('Южн') || district.includes('Северо-Кавказ'))
        return 'Южный и Северо-Кавказский';
    if (district.includes('Приволж'))
        return 'Приволжский';
    if (district.includes('Ураль'))
        return 'Уральский';
    if (district.includes('Северо-Запад'))
        return 'Северо-Западный';
    if (district.includes('Сибир') || district.includes('Дальневост'))
        return 'Дальневосточный и Сибирский';
    return country || district || 'Другие регионы';
}
function buildRegionalAnalytics(products, regions, regionalSales, periodDays) {
    const targetDays = 30;
    const excessDays = 60;
    const detailedDemandAvailable = regionalSales.length > 0;
    const productMap = new Map(products.map((product) => [product.nmId, product]));
    const regionSales = new Map();
    for (const sale of regionalSales) {
        const current = regionSales.get(sale.regionName) ?? { currentQty: 0, currentAmount: 0, pastQty: 0, pastAmount: 0 };
        current.currentQty += sale.currentQty;
        current.currentAmount += sale.currentAmount;
        current.pastQty += sale.pastQty;
        current.pastAmount += sale.pastAmount;
        regionSales.set(sale.regionName, current);
    }
    const regionStock = new Map(regions
        .filter((region) => !region.officeName && region.regionName !== 'Маркетплейс')
        .map((region) => [region.regionName, region]));
    const topWarehouse = new Map();
    for (const office of regions.filter((region) => Boolean(region.officeName))) {
        const current = topWarehouse.get(office.regionName);
        if (!current || office.stockCount > current.stockCount)
            topWarehouse.set(office.regionName, office);
    }
    const names = [...new Set([...regionStock.keys(), ...regionSales.keys()])];
    const totalSalesQty = detailedDemandAvailable
        ? sum([...regionSales.values()], (region) => region.currentQty)
        : sum([...regionStock.values()], (region) => region.saleRateDays && region.saleRateDays > 0 ? (region.stockCount / region.saleRateDays) * periodDays : 0);
    const totalRegionalStock = sum([...regionStock.values()], (region) => region.stockCount);
    const regionRows = names
        .map((regionName) => {
        const stock = regionStock.get(regionName);
        const directSales = regionSales.get(regionName);
        const wbSaleRateDays = stock?.saleRateDays && stock.saleRateDays > 0 ? stock.saleRateDays : null;
        const fallbackDemand = !directSales && wbSaleRateDays
            ? ((stock?.stockCount ?? 0) / wbSaleRateDays) * periodDays
            : 0;
        const sales = directSales ?? { currentQty: fallbackDemand, currentAmount: 0, pastQty: 0, pastAmount: 0 };
        const dailyDemand = periodDays > 0 ? sales.currentQty / periodDays : 0;
        const coverageDays = dailyDemand > 0 ? (stock?.stockCount ?? 0) / dailyDemand : wbSaleRateDays;
        const targetStock = Math.ceil(dailyDemand * targetDays);
        const recommendedSupply = Math.max(0, targetStock - Math.round(stock?.stockCount ?? 0));
        const excessStock = Math.max(0, Math.round((stock?.stockCount ?? 0) - dailyDemand * excessDays));
        const status = regionalStatus(coverageDays, sales.currentQty, stock?.stockCount ?? 0);
        const warehouse = topWarehouse.get(regionName);
        return {
            regionName,
            salesQty: roundMetric(sales.currentQty),
            salesAmount: roundMetric(sales.currentAmount),
            pastSalesQty: roundMetric(sales.pastQty),
            salesDynamicPercent: directSales ? percentDynamic(sales.currentQty, sales.pastQty) : 0,
            salesSharePercent: totalSalesQty > 0 ? (sales.currentQty / totalSalesQty) * 100 : 0,
            stockCount: stock?.stockCount ?? 0,
            stockSharePercent: totalRegionalStock > 0 ? ((stock?.stockCount ?? 0) / totalRegionalStock) * 100 : 0,
            coverageDays: coverageDays === null ? null : roundMetric(coverageDays),
            wbSaleRateDays,
            targetStock,
            recommendedSupply,
            excessStock,
            toClientCount: stock?.toClientCount ?? 0,
            fromClientCount: stock?.fromClientCount ?? 0,
            estimatedLostSales: totalSalesQty > 0 ? roundMetric(productLostSales(products) * (sales.currentQty / totalSalesQty)) : 0,
            topWarehouse: warehouse?.officeName ?? null,
            topWarehouseStock: warehouse?.stockCount ?? 0,
            status,
        };
    })
        .sort((left, right) => regionalStatusRank(left.status) - regionalStatusRank(right.status) || right.recommendedSupply - left.recommendedSupply);
    const stockShare = new Map(regionRows.map((region) => [region.regionName, region.stockSharePercent / 100]));
    const productRegionalTotal = new Map();
    for (const sale of regionalSales)
        productRegionalTotal.set(sale.nmId, (productRegionalTotal.get(sale.nmId) ?? 0) + sale.currentQty);
    const candidates = regionalSales
        .map((sale) => {
        const product = productMap.get(sale.nmId);
        const totalProductSales = productRegionalTotal.get(sale.nmId) ?? 0;
        if (!product || totalProductSales <= 0 || sale.currentQty <= 0)
            return null;
        const demandShare = sale.currentQty / totalProductSales;
        const estimatedRegionStock = Math.max(0, Math.round(product.stockCount * (stockShare.get(sale.regionName) ?? 0)));
        const targetRegionStock = Math.ceil((sale.currentQty / periodDays) * targetDays);
        const gap = Math.max(0, targetRegionStock - estimatedRegionStock);
        if (gap <= 0)
            return null;
        return {
            nmId: sale.nmId,
            name: product.name,
            vendorCode: product.vendorCode,
            photoUrl: product.photoUrl,
            regionName: sale.regionName,
            salesQty: sale.currentQty,
            pastSalesQty: sale.pastQty,
            salesDynamicPercent: percentDynamic(sale.currentQty, sale.pastQty),
            demandSharePercent: demandShare * 100,
            estimatedRegionStock,
            targetRegionStock,
            gap,
            wmsStock: product.wmsStock,
            recommendedQty: 0,
            uncoveredQty: gap,
            confidence: 'ESTIMATE',
        };
    })
        .filter((value) => Boolean(value));
    const byProduct = new Map();
    for (const candidate of candidates) {
        const list = byProduct.get(candidate.nmId) ?? [];
        list.push(candidate);
        byProduct.set(candidate.nmId, list);
    }
    for (const list of byProduct.values()) {
        let available = list[0]?.wmsStock ?? 0;
        list.sort((left, right) => right.gap - left.gap || right.salesQty - left.salesQty);
        for (const candidate of list) {
            candidate.recommendedQty = Math.min(candidate.gap, Math.max(0, Math.floor(available)));
            candidate.uncoveredQty = candidate.gap - candidate.recommendedQty;
            available -= candidate.recommendedQty;
        }
    }
    const productActions = candidates
        .sort((left, right) => right.recommendedQty - left.recommendedQty || right.uncoveredQty - left.uncoveredQty || right.salesQty - left.salesQty)
        .slice(0, 60)
        .map((candidate) => ({
        ...candidate,
        reason: candidate.recommendedQty > 0
            ? `Покрыть расчётный дефицит на ${targetDays} дней из доступного остатка LOGOFF.`
            : 'Есть расчётный региональный дефицит, но сопоставленного свободного остатка LOGOFF недостаточно.',
    }));
    return {
        available: regionRows.length > 0,
        periodDays,
        targetDays,
        demandSource: detailedDemandAvailable ? 'REGIONAL_SALES' : 'WB_SALE_RATE',
        dynamicsAvailable: detailedDemandAvailable,
        productActionsAvailable: detailedDemandAvailable,
        exactProductWarehouseStockAvailable: false,
        limitation: (detailedDemandAvailable
            ? ''
            : 'Региональный спрос временно рассчитан по оборачиваемости WB; динамика и товарная детализация появятся после снятия лимита Statistics API. ') +
            'Точный остаток каждого товара по складам требует персональный или сервисный токен WB. С текущим базовым токеном распределение товара по регионам является расчётной оценкой.',
        summary: {
            regions: regionRows.length,
            shortageRegions: regionRows.filter((region) => region.status === 'CRITICAL' || region.status === 'SHORTAGE').length,
            recommendedSupply: sum(regionRows, (region) => region.recommendedSupply),
            excessStock: sum(regionRows, (region) => region.excessStock),
            salesQty: totalSalesQty,
            salesAmount: sum([...regionSales.values()], (region) => region.currentAmount),
        },
        regions: regionRows,
        productActions,
    };
}
function regionalStatus(coverageDays, salesQty, stockCount) {
    if (salesQty <= 0)
        return stockCount > 0 ? 'NO_DEMAND' : 'NO_DATA';
    if (stockCount <= 0 || coverageDays === null || coverageDays < 14)
        return 'CRITICAL';
    if (coverageDays < 30)
        return 'SHORTAGE';
    if (coverageDays > 60)
        return 'OVERSTOCK';
    return 'BALANCED';
}
function regionalStatusRank(value) {
    return value === 'CRITICAL' ? 0 : value === 'SHORTAGE' ? 1 : value === 'OVERSTOCK' ? 2 : value === 'BALANCED' ? 3 : 4;
}
function productLostSales(products) {
    return sum(products, (product) => product.lostOrdersSum);
}
function percentDynamic(current, past) {
    if (past <= 0)
        return current > 0 ? 100 : 0;
    return ((current - past) / past) * 100;
}
function periodQuery(period) {
    return new URLSearchParams({ dateFrom: period.start, dateTo: period.end }).toString();
}
function dateInPeriod(value, period) {
    return value >= period.start && value <= period.end;
}
function roundMetric(value) {
    return Math.round(value * 100) / 100;
}
function productTotals(products) {
    return {
        productCount: products.length,
        stockCount: sum(products, (product) => product.stockCount ?? 0),
        stockSum: sum(products, (product) => product.stockSum ?? 0),
        ordersCount: sum(products, (product) => product.orderCount ?? 0),
        ordersSum: sum(products, (product) => product.orderSum ?? 0),
        buyoutCount: sum(products, (product) => product.funnelBuyoutCount ?? 0),
        buyoutSum: sum(products, (product) => product.funnelBuyoutSum ?? 0),
        lostOrdersSum: sum(products, (product) => product.lostOrdersSum ?? 0),
    };
}
function dashboardTotals(products, wmsStock) {
    const orderCount = sum(products, (product) => product.orderCount);
    const buyoutCount = sum(products, (product) => product.funnelBuyoutCount);
    return {
        products: products.length,
        activeProducts: products.filter((product) => product.orderCount > 0).length,
        wbStock: sum(products, (product) => product.stockCount),
        wmsStock: wmsStock.totalQuantity,
        wmsMatchedStock: wmsStock.matchedQuantity,
        wmsUnlinkedStock: wmsStock.unlinkedQuantity,
        wmsMatchPercent: wmsStock.totalQuantity > 0 ? (wmsStock.matchedQuantity / wmsStock.totalQuantity) * 100 : 100,
        orders: orderCount,
        ordersSum: sum(products, (product) => product.orderSum),
        buyouts: buyoutCount,
        buyoutsSum: sum(products, (product) => product.funnelBuyoutSum),
        buyoutPercent: orderCount > 0 ? (buyoutCount / orderCount) * 100 : 0,
        lostOrdersSum: sum(products, (product) => product.lostOrdersSum),
        outOfStock: products.filter((product) => product.stockCount <= 0 && (product.avgOrders > 0 || product.orderCount > 0)).length,
        lowStock: products.filter((product) => product.availability === 'deficient').length,
        overstock: products.filter((product) => product.availability === 'nonLiquid' || product.availability === 'nonActual').length,
    };
}
function buildRecommendations(products) {
    return products
        .flatMap((product) => {
        const base = { nmId: product.nmId, name: product.name, vendorCode: product.vendorCode, photoUrl: product.photoUrl };
        if (product.stockCount <= 0 && (product.avgOrders > 0 || product.orderCount > 0)) {
            return [{ ...base, kind: 'OUT_OF_STOCK', severity: 'CRITICAL', value: product.lostOrdersSum, message: 'Товар продаётся, но остаток WB закончился. Нужна срочная поставка.' }];
        }
        if (product.availability === 'deficient') {
            return [{ ...base, kind: 'LOW_STOCK', severity: 'WARNING', value: product.stockCount, message: 'WB определяет остаток как дефицитный. Подготовьте пополнение.' }];
        }
        if (product.availability === 'nonLiquid' || product.availability === 'nonActual') {
            return [{ ...base, kind: 'OVERSTOCK', severity: 'INFO', value: product.stockCount, message: 'Товар продаётся медленно: проверьте цену, карточку и объём следующей поставки.' }];
        }
        if (product.openCount >= 50 && product.cartToOrderPercent < 10) {
            return [{ ...base, kind: 'LOW_CONVERSION', severity: 'WARNING', value: product.cartToOrderPercent, message: 'Есть просмотры, но слабая конверсия корзины в заказ. Проверьте цену и карточку.' }];
        }
        if (product.orderCountDynamic >= 20) {
            return [{ ...base, kind: 'GROWTH', severity: 'POSITIVE', value: product.orderCountDynamic, message: 'Заказы растут. Стоит заранее увеличить запас.' }];
        }
        return [];
    })
        .sort((left, right) => severityRank(left.severity) - severityRank(right.severity) || right.value - left.value)
        .slice(0, 24);
}
function severityRank(value) {
    return value === 'CRITICAL' ? 0 : value === 'WARNING' ? 1 : value === 'POSITIVE' ? 2 : 3;
}
function matchesProduct(product, search, availability) {
    if (availability && availability !== 'all') {
        if (availability === 'outOfStock') {
            if (product.stockCount > 0)
                return false;
        }
        else if (product.availability !== availability) {
            return false;
        }
    }
    const query = search?.trim().toLocaleLowerCase('ru-RU');
    if (!query)
        return true;
    return [product.name, product.vendorCode, product.brandName, product.subjectName, product.nmId]
        .filter(Boolean)
        .some((value) => String(value).toLocaleLowerCase('ru-RU').includes(query));
}
async function wbJson(url, apiKey, body) {
    const response = await fetch(url, {
        method: body ? 'POST' : 'GET',
        headers: { Authorization: apiKey, 'Content-Type': 'application/json' },
        body: body ? JSON.stringify(body) : undefined,
        signal: AbortSignal.timeout(45_000),
    });
    const raw = await response.text();
    let payload = {};
    try {
        payload = raw ? asRecord(JSON.parse(raw)) : {};
    }
    catch {
        payload = { message: raw.slice(0, 500) };
    }
    if (!response.ok) {
        const message = textValue(payload.detail) || textValue(payload.message) || textValue(payload.error) || `HTTP ${response.status}`;
        throw new common_1.BadGatewayException(`Wildberries: ${message}`);
    }
    return payload;
}
async function wbArray(url, apiKey) {
    const response = await fetch(url, {
        headers: { Authorization: apiKey },
        signal: AbortSignal.timeout(60_000),
    });
    const raw = await response.text();
    let payload;
    try {
        payload = raw ? JSON.parse(raw) : [];
    }
    catch {
        payload = { message: raw.slice(0, 500) };
    }
    if (!response.ok) {
        const error = asRecord(payload);
        const message = textValue(error.detail) || textValue(error.message) || textValue(error.error) || `HTTP ${response.status}`;
        throw new common_1.BadGatewayException(`Wildberries: ${message}`);
    }
    if (!Array.isArray(payload))
        throw new common_1.BadGatewayException('Wildberries вернул неожиданный формат статистики продаж.');
    return payload;
}
function isGlobalLimiterError(value) {
    return safeErrorMessage(value).toLocaleLowerCase('en-US').includes('limited by global limiter');
}
function sourceError(source, reason) {
    return new common_1.BadGatewayException(`Wildberries не вернул источник «${source}»: ${safeErrorMessage(reason)}`);
}
function safeErrorMessage(value) {
    return value instanceof Error ? value.message : typeof value === 'string' ? value : 'неизвестная ошибка';
}
function asRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function asArray(value) {
    return Array.isArray(value) ? value : [];
}
function textValue(value) {
    return value === null || value === undefined ? '' : String(value).trim();
}
function nullableText(value) {
    const text = textValue(value);
    return text || null;
}
function numberValue(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
}
function nullableNumber(value) {
    if (value === null || value === undefined || value === '')
        return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
}
function durationDays(value) {
    const duration = asRecord(value);
    if (Object.keys(duration).length === 0)
        return null;
    return numberValue(duration.days) + numberValue(duration.hours) / 24 + numberValue(duration.mins) / 1440;
}
function sum(items, getter) {
    return items.reduce((total, item) => total + getter(item), 0);
}
function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
