"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsPrismaService = void 0;
const common_1 = require("@nestjs/common");
const analytics_client_1 = require("@logoff/analytics-client");
let AnalyticsPrismaService = class AnalyticsPrismaService extends analytics_client_1.PrismaClient {
    async onModuleInit() {
        await this.$connect();
    }
    async onModuleDestroy() {
        await this.$disconnect();
    }
};
exports.AnalyticsPrismaService = AnalyticsPrismaService;
exports.AnalyticsPrismaService = AnalyticsPrismaService = __decorate([
    (0, common_1.Injectable)()
], AnalyticsPrismaService);
