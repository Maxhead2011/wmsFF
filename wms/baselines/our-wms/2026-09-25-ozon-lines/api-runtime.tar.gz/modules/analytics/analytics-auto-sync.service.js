"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AnalyticsAutoSyncService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsAutoSyncService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const analytics_prisma_service_1 = require("./analytics-prisma.service");
const analytics_service_1 = require("./analytics.service");
const DEFAULT_INTERVAL_MS = 30 * 60_000;
const DEFAULT_INITIAL_DELAY_MS = 5 * 60_000;
const DEFAULT_FAILED_RETRY_MS = 10 * 60_000;
const MINIMUM_RETRY_AGE_MS = 15 * 60_000;
const AUTO_SYNC_USER = {
    id: 'analytics-auto-sync',
    email: 'analytics-auto-sync@system.local',
    name: 'Автообновление аналитики',
    analyticsEnabled: true,
    roleCodes: ['ADMIN'],
    permissionCodes: ['system:admin'],
    clientScopeMode: 'ALL',
    clientIds: [],
    writableClientIds: [],
};
let AnalyticsAutoSyncService = AnalyticsAutoSyncService_1 = class AnalyticsAutoSyncService {
    analytics;
    analyticsPrisma;
    config;
    logger = new common_1.Logger(AnalyticsAutoSyncService_1.name);
    timer;
    running = false;
    regionalPhase = true;
    constructor(analytics, analyticsPrisma, config) {
        this.analytics = analytics;
        this.analyticsPrisma = analyticsPrisma;
        this.config = config;
    }
    onModuleInit() {
        if (this.config.get('ANALYTICS_AUTO_SYNC_ENABLED') === 'false') {
            this.logger.log('Автоматическое обновление аналитики отключено настройкой окружения.');
            return;
        }
        this.schedule(this.duration('ANALYTICS_AUTO_SYNC_INITIAL_DELAY_MS', DEFAULT_INITIAL_DELAY_MS));
    }
    onModuleDestroy() {
        if (this.timer)
            clearTimeout(this.timer);
    }
    schedule(delayMs) {
        this.timer = setTimeout(() => void this.run(), delayMs);
        this.timer.unref?.();
    }
    async run() {
        if (this.running)
            return;
        this.running = true;
        let phaseSucceeded = true;
        try {
            const connections = await this.analyticsPrisma.analyticsConnection.findMany({
                where: { isActive: true },
                select: { clientId: true },
            });
            for (const connection of connections) {
                const state = await this.analyticsPrisma.analyticsSyncState.findUnique({ where: { clientId: connection.clientId } });
                if (!this.regionalPhase && state?.lastStartedAt && Date.now() - state.lastStartedAt.getTime() < MINIMUM_RETRY_AGE_MS) {
                    continue;
                }
                const periodDays = state?.periodDays === 7 || state?.periodDays === 90 ? state.periodDays : 30;
                try {
                    if (this.regionalPhase) {
                        const result = await this.analytics.syncRegionalDemand(connection.clientId, periodDays);
                        this.logger.log(`Региональная аналитика клиента ${connection.clientId} обновлена: ${result.rows} строк.`);
                    }
                    else {
                        const result = await this.analytics.sync({ clientId: connection.clientId, periodDays }, AUTO_SYNC_USER);
                        this.logger.log(`Основная аналитика клиента ${connection.clientId} обновлена: ${result.sync?.status ?? 'READY'}.`);
                    }
                }
                catch (caught) {
                    phaseSucceeded = false;
                    const message = caught instanceof Error ? caught.message : 'неизвестная ошибка';
                    this.logger.warn(`Автообновление аналитики клиента ${connection.clientId} не выполнено: ${message}`);
                }
            }
        }
        catch (caught) {
            phaseSucceeded = false;
            const message = caught instanceof Error ? caught.message : 'неизвестная ошибка';
            this.logger.warn(`Цикл автообновления аналитики не выполнен: ${message}`);
        }
        finally {
            this.running = false;
            if (phaseSucceeded)
                this.regionalPhase = !this.regionalPhase;
            this.schedule(this.duration(phaseSucceeded ? 'ANALYTICS_AUTO_SYNC_INTERVAL_MS' : 'ANALYTICS_AUTO_SYNC_FAILED_RETRY_MS', phaseSucceeded ? DEFAULT_INTERVAL_MS : DEFAULT_FAILED_RETRY_MS));
        }
    }
    duration(name, fallback) {
        const configured = Number(this.config.get(name));
        return Number.isFinite(configured) && configured >= 60_000 ? configured : fallback;
    }
};
exports.AnalyticsAutoSyncService = AnalyticsAutoSyncService;
exports.AnalyticsAutoSyncService = AnalyticsAutoSyncService = AnalyticsAutoSyncService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [analytics_service_1.AnalyticsService,
        analytics_prisma_service_1.AnalyticsPrismaService,
        config_1.ConfigService])
], AnalyticsAutoSyncService);
