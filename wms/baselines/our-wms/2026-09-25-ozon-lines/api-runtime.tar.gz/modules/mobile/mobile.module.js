"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const warehouse_module_1 = require("../warehouse/warehouse.module");
const mobile_auth_service_1 = require("./mobile-auth.service");
const mobile_controller_1 = require("./mobile.controller");
const mobile_push_service_1 = require("./mobile-push.service");
const mobile_service_1 = require("./mobile.service");
let MobileModule = class MobileModule {
};
exports.MobileModule = MobileModule;
exports.MobileModule = MobileModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, warehouse_module_1.WarehouseModule],
        controllers: [mobile_controller_1.MobileController],
        providers: [mobile_auth_service_1.MobileAuthService, mobile_service_1.MobileService, mobile_push_service_1.MobilePushService],
        exports: [mobile_service_1.MobileService, mobile_push_service_1.MobilePushService],
    })
], MobileModule);
