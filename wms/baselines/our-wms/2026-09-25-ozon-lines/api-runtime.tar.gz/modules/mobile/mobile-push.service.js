"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MobilePushService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobilePushService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const app_1 = require("firebase-admin/app");
const messaging_1 = require("firebase-admin/messaging");
const prisma_service_1 = require("../../common/prisma/prisma.service");
let MobilePushService = MobilePushService_1 = class MobilePushService {
    prisma;
    config;
    logger = new common_1.Logger(MobilePushService_1.name);
    timer;
    messaging;
    running = false;
    constructor(prisma, config) {
        this.prisma = prisma;
        this.config = config;
    }
    onModuleInit() {
        this.messaging = this.createMessaging();
        if (!this.messaging) {
            this.logger.warn('FCM отключен: задайте FIREBASE_SERVICE_ACCOUNT_JSON.');
            return;
        }
        this.timer = setInterval(() => void this.dispatch(), 10_000);
        this.timer.unref();
        void this.dispatch();
    }
    onModuleDestroy() {
        if (this.timer)
            clearInterval(this.timer);
    }
    async dispatch() {
        if (!this.messaging || this.running)
            return;
        this.running = true;
        try {
            const notifications = await this.prisma.clientNotification.findMany({
                where: { createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
                orderBy: { createdAt: 'asc' },
                take: 100,
            });
            for (const notification of notifications) {
                const devices = await this.prisma.mobileDevice.findMany({
                    where: {
                        isActive: true,
                        fcmToken: { not: null },
                        pushDeliveries: { none: { notificationId: notification.id } },
                        user: {
                            status: 'ACTIVE',
                            OR: [
                                { clientScopes: { some: { clientId: notification.clientId, canRead: true } } },
                                { roles: { some: { role: { code: { in: ['OWNER', 'ADMIN', 'MANAGER', 'OPERATOR'] } } } } },
                            ],
                        },
                    },
                    select: { id: true, fcmToken: true },
                });
                for (const device of devices)
                    await this.send(notification, device.id, device.fcmToken);
            }
        }
        catch (error) {
            this.logger.error(`Ошибка очереди FCM: ${errorText(error)}`);
        }
        finally {
            this.running = false;
        }
    }
    async send(notification, deviceId, token) {
        try {
            await this.messaging.send({
                token,
                notification: { title: notification.title, body: notification.body ?? '' },
                data: {
                    notificationId: notification.id,
                    clientId: notification.clientId,
                    requestId: notification.requestId ?? '',
                    type: notification.requestId ? 'REQUEST' : 'GENERAL',
                },
                android: { priority: 'high', notification: { channelId: 'wms_events', sound: 'default' } },
            });
            await this.prisma.mobilePushDelivery.create({ data: { deviceId, notificationId: notification.id, status: 'SENT' } });
        }
        catch (error) {
            const message = errorText(error);
            await this.prisma.mobilePushDelivery.create({
                data: { deviceId, notificationId: notification.id, status: 'FAILED', error: message.slice(0, 500) },
            }).catch(() => undefined);
            if (message.includes('registration-token-not-registered') || message.includes('invalid-registration-token')) {
                await this.prisma.mobileDevice.update({ where: { id: deviceId }, data: { isActive: false, fcmToken: null } });
            }
        }
    }
    createMessaging() {
        const raw = this.config.get('FIREBASE_SERVICE_ACCOUNT_JSON');
        if (!raw)
            return undefined;
        try {
            const serviceAccount = JSON.parse(raw);
            const app = (0, app_1.getApps)().length ? (0, app_1.getApp)() : (0, app_1.initializeApp)({ credential: (0, app_1.cert)(serviceAccount) });
            return (0, messaging_1.getMessaging)(app);
        }
        catch (error) {
            this.logger.error(`FIREBASE_SERVICE_ACCOUNT_JSON не читается: ${errorText(error)}`);
            return undefined;
        }
    }
};
exports.MobilePushService = MobilePushService;
exports.MobilePushService = MobilePushService = MobilePushService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService])
], MobilePushService);
function errorText(error) {
    return error instanceof Error ? error.message : String(error);
}
