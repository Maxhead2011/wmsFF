"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const public_decorator_1 = require("../auth/decorators/public.decorator");
const mobile_device_dto_1 = require("./dto/mobile-device.dto");
const mobile_login_dto_1 = require("./dto/mobile-login.dto");
const mobile_list_dto_1 = require("./dto/mobile-list.dto");
const mobile_refresh_dto_1 = require("./dto/mobile-refresh.dto");
const mobile_auth_service_1 = require("./mobile-auth.service");
const mobile_service_1 = require("./mobile.service");
let MobileController = class MobileController {
    auth;
    mobile;
    constructor(auth, mobile) {
        this.auth = auth;
        this.mobile = mobile;
    }
    login(dto, request) {
        return this.auth.login(dto, { ip: request.ip, userAgent: request.headers['user-agent'] });
    }
    refresh(dto) {
        return this.auth.refresh(dto.refreshToken);
    }
    logout(user, dto) {
        return this.auth.logout(user, dto.allDevices === true);
    }
    sessions(user) {
        return this.auth.listSessions(user);
    }
    revokeSession(user, id) {
        return this.auth.revokeSession(user, id);
    }
    registerDevice(user, dto) {
        return this.mobile.registerDevice(user, dto);
    }
    bootstrap(user) {
        return this.mobile.bootstrap(user);
    }
    dashboard(user, clientId) {
        return this.mobile.dashboard(user, clientId);
    }
    requests(user, query) {
        return this.mobile.listRequests(user, query);
    }
    invoices(user, query) {
        return this.mobile.listInvoices(user, query);
    }
    onlineReceipts(user, clientId) {
        if (!clientId)
            throw new common_1.BadRequestException('Выберите клиента.');
        return this.mobile.onlineReceipts(user, clientId);
    }
    nativeModule(user, module, query) {
        return this.mobile.nativeModule(user, module, query);
    }
    notifications(user, query) {
        return this.mobile.listNotifications(user, query);
    }
    markNotificationRead(user, id) {
        return this.mobile.markNotificationRead(user, id);
    }
    markAllNotificationsRead(user, clientId) {
        return this.mobile.markAllNotificationsRead(user, clientId);
    }
    events(user, query) {
        return this.mobile.events(user, query);
    }
    appVersion() {
        return this.mobile.appVersion();
    }
};
exports.MobileController = MobileController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('auth/login'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [mobile_login_dto_1.MobileLoginDto, Object]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "login", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('auth/refresh'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [mobile_refresh_dto_1.MobileRefreshDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "refresh", null);
__decorate([
    (0, common_1.Post)('auth/logout'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mobile_refresh_dto_1.MobileLogoutDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "logout", null);
__decorate([
    (0, common_1.Get)('auth/sessions'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "sessions", null);
__decorate([
    (0, common_1.Delete)('auth/sessions/:id'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "revokeSession", null);
__decorate([
    (0, common_1.Post)('devices'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mobile_device_dto_1.MobileDeviceDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "registerDevice", null);
__decorate([
    (0, common_1.Get)('bootstrap'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "bootstrap", null);
__decorate([
    (0, common_1.Get)('dashboard'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "dashboard", null);
__decorate([
    (0, common_1.Get)('requests'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mobile_list_dto_1.MobileListDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "requests", null);
__decorate([
    (0, common_1.Get)('invoices'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mobile_list_dto_1.MobileListDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "invoices", null);
__decorate([
    (0, common_1.Get)('online-receipts'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "onlineReceipts", null);
__decorate([
    (0, common_1.Get)('modules/:module'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('module')),
    __param(2, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, mobile_list_dto_1.MobileListDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "nativeModule", null);
__decorate([
    (0, common_1.Get)('notifications'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mobile_list_dto_1.MobileListDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "notifications", null);
__decorate([
    (0, common_1.Patch)('notifications/:id/read'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "markNotificationRead", null);
__decorate([
    (0, common_1.Patch)('notifications/read-all'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "markAllNotificationsRead", null);
__decorate([
    (0, common_1.Get)('events'),
    (0, swagger_1.ApiBearerAuth)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, mobile_list_dto_1.MobileEventListDto]),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "events", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('app-version'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MobileController.prototype, "appVersion", null);
exports.MobileController = MobileController = __decorate([
    (0, swagger_1.ApiTags)('mobile'),
    (0, common_1.Controller)('mobile'),
    __metadata("design:paramtypes", [mobile_auth_service_1.MobileAuthService,
        mobile_service_1.MobileService])
], MobileController);
