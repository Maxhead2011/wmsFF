"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileIdempotencyInterceptor = void 0;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const prisma_service_1 = require("../../common/prisma/prisma.service");
let MobileIdempotencyInterceptor = class MobileIdempotencyInterceptor {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async intercept(context, next) {
        const request = context.switchToHttp().getRequest();
        if (['GET', 'HEAD', 'OPTIONS'].includes(request.method) || !request.user || !request.headers['x-mobile-app']) {
            return next.handle();
        }
        const key = header(request.headers['x-idempotency-key']);
        if (!key)
            return next.handle();
        const unique = { userId_idempotencyKey: { userId: request.user.id, idempotencyKey: key } };
        const existing = await this.prisma.mobileCommand.findUnique({ where: unique });
        if (existing?.status === 'COMPLETED')
            return (0, rxjs_1.of)(existing.response ?? { success: true, repeated: true });
        if (existing)
            throw new common_1.ConflictException('Мобильная команда уже выполняется. Повторите проверку данных.');
        const command = await this.prisma.mobileCommand.create({
            data: {
                userId: request.user.id,
                idempotencyKey: key,
                action: `${request.method}:${request.originalUrl ?? request.url ?? ''}`,
                status: 'PROCESSING',
                expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            },
        });
        return next.handle().pipe((0, rxjs_1.mergeMap)((response) => (0, rxjs_1.from)(this.prisma.mobileCommand.update({
            where: { id: command.id },
            data: { status: 'COMPLETED', response: serializable(response) },
        })).pipe((0, rxjs_1.mergeMap)(() => (0, rxjs_1.of)(response)))), (0, rxjs_1.catchError)((error) => (0, rxjs_1.from)(this.prisma.mobileCommand.delete({ where: { id: command.id } }).catch(() => undefined)).pipe((0, rxjs_1.mergeMap)(() => (0, rxjs_1.throwError)(() => error)))));
    }
};
exports.MobileIdempotencyInterceptor = MobileIdempotencyInterceptor;
exports.MobileIdempotencyInterceptor = MobileIdempotencyInterceptor = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], MobileIdempotencyInterceptor);
function header(value) {
    const result = Array.isArray(value) ? value[0] : value;
    return result?.trim().slice(0, 200) || '';
}
function serializable(value) {
    return JSON.parse(JSON.stringify(value ?? { success: true }));
}
