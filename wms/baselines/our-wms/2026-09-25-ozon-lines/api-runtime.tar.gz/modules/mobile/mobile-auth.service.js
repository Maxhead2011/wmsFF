"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobileAuthService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const crypto_1 = require("crypto");
const audit_log_service_1 = require("../../common/audit/audit-log.service");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const access_token_service_1 = require("../auth/access-token.service");
const auth_service_1 = require("../auth/auth.service");
const REFRESH_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const ACCESS_TTL_SECONDS = 8 * 60 * 60;
let MobileAuthService = class MobileAuthService {
    prisma;
    auth;
    tokens;
    audit;
    constructor(prisma, auth, tokens, audit) {
        this.prisma = prisma;
        this.auth = auth;
        this.tokens = tokens;
        this.audit = audit;
    }
    async login(dto, context) {
        const authenticated = await this.auth.login({ email: dto.login, password: dto.password }, context);
        const device = await this.prisma.$transaction(async (tx) => {
            const existing = await tx.mobileDevice.findUnique({ where: { installationId: dto.installationId } });
            if (existing && existing.userId !== authenticated.user.id) {
                await tx.mobileSession.updateMany({
                    where: { deviceId: existing.id, revokedAt: null },
                    data: { revokedAt: new Date() },
                });
            }
            return tx.mobileDevice.upsert({
                where: { installationId: dto.installationId },
                create: {
                    userId: authenticated.user.id,
                    installationId: dto.installationId,
                    name: clean(dto.deviceName),
                    appVersion: clean(dto.appVersion),
                },
                update: {
                    userId: authenticated.user.id,
                    name: clean(dto.deviceName),
                    appVersion: clean(dto.appVersion),
                    isActive: true,
                    lastSeenAt: new Date(),
                },
            });
        });
        const refresh = await this.createRefreshSession(authenticated.user.id, device.id);
        await this.audit.write({
            userId: authenticated.user.id,
            action: 'mobile.auth.login',
            entity: 'mobile-device',
            entityId: device.id,
            payload: { installationId: dto.installationId, appVersion: dto.appVersion, ip: context.ip },
        });
        return {
            accessToken: this.tokens.sign(authenticated.user.id, { deviceId: device.id }),
            refreshToken: refresh.token,
            refreshExpiresAt: refresh.expiresAt,
            expiresInSeconds: ACCESS_TTL_SECONDS,
            tokenType: 'Bearer',
            deviceId: device.id,
            user: authenticated.user,
        };
    }
    async refresh(rawToken) {
        const tokenHash = hashToken(rawToken);
        const session = await this.prisma.mobileSession.findUnique({
            where: { refreshTokenHash: tokenHash },
            include: { user: true, device: true },
        });
        if (!session || session.revokedAt || session.expiresAt <= new Date() || !session.device.isActive) {
            throw new common_1.UnauthorizedException('Мобильная сессия истекла. Войдите снова.');
        }
        if (session.user.status !== client_1.UserStatus.ACTIVE) {
            throw new common_1.ForbiddenException('Пользователь заблокирован.');
        }
        const user = await this.loadAuthUser(session.userId);
        const next = await this.prisma.$transaction(async (tx) => {
            await tx.mobileSession.update({
                where: { id: session.id },
                data: { revokedAt: new Date(), lastUsedAt: new Date() },
            });
            await tx.mobileDevice.update({
                where: { id: session.deviceId },
                data: { lastSeenAt: new Date() },
            });
            return this.createRefreshSession(session.userId, session.deviceId, tx);
        });
        return {
            accessToken: this.tokens.sign(session.userId, { deviceId: session.deviceId }),
            refreshToken: next.token,
            refreshExpiresAt: next.expiresAt,
            expiresInSeconds: ACCESS_TTL_SECONDS,
            tokenType: 'Bearer',
            deviceId: session.deviceId,
            user,
        };
    }
    async logout(user, allDevices) {
        const where = allDevices ? { userId: user.id, revokedAt: null } : { userId: user.id, deviceId: user.deviceId, revokedAt: null };
        const result = await this.prisma.mobileSession.updateMany({ where, data: { revokedAt: new Date() } });
        if (allDevices) {
            await this.prisma.mobileDevice.updateMany({ where: { userId: user.id }, data: { isActive: false } });
        }
        await this.audit.write({
            userId: user.id,
            action: allDevices ? 'mobile.auth.logout-all' : 'mobile.auth.logout',
            entity: 'mobile-device',
            entityId: user.deviceId,
            payload: { revokedSessions: result.count },
        });
        return { success: true, revokedSessions: result.count };
    }
    listSessions(user) {
        return this.prisma.mobileSession.findMany({
            where: { userId: user.id, revokedAt: null, expiresAt: { gt: new Date() } },
            select: {
                id: true,
                deviceId: true,
                createdAt: true,
                lastUsedAt: true,
                expiresAt: true,
                device: { select: { name: true, platform: true, appVersion: true, lastSeenAt: true, installationId: true } },
            },
            orderBy: { lastUsedAt: 'desc' },
        });
    }
    async revokeSession(user, sessionId) {
        const result = await this.prisma.mobileSession.updateMany({
            where: { id: sessionId, userId: user.id, revokedAt: null },
            data: { revokedAt: new Date() },
        });
        return { success: result.count > 0 };
    }
    async createRefreshSession(userId, deviceId, tx = this.prisma) {
        const raw = (0, crypto_1.randomBytes)(48).toString('base64url');
        const expiresAt = new Date(Date.now() + REFRESH_TTL_MS);
        await tx.mobileSession.create({
            data: { userId, deviceId, refreshTokenHash: hashToken(raw), expiresAt },
        });
        return { token: raw, expiresAt };
    }
    async loadAuthUser(userId) {
        const user = await this.prisma.user.findUniqueOrThrow({
            where: { id: userId },
            include: {
                clientScopes: true,
                printerScopes: true,
                roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } },
            },
        });
        const roleCodes = user.roles.map((item) => item.role.code);
        const permissionCodes = [...new Set(user.roles.flatMap((item) => item.role.permissions.map((entry) => entry.permission.code)))];
        const all = permissionCodes.includes('system:admin') || (!roleCodes.includes('CLIENT') && user.clientScopes.length === 0);
        return {
            id: user.id,
            email: user.email,
            name: user.name,
            roleCodes,
            permissionCodes,
            clientScopeMode: all ? 'ALL' : 'LIMITED',
            clientIds: user.clientScopes.filter((scope) => scope.canRead).map((scope) => scope.clientId),
            writableClientIds: user.clientScopes.filter((scope) => scope.canWrite).map((scope) => scope.clientId),
            printerGroups: user.printerScopes.map((scope) => ({ groupCode: scope.groupCode, canPrint: scope.canPrint, canManage: scope.canManage })),
        };
    }
};
exports.MobileAuthService = MobileAuthService;
exports.MobileAuthService = MobileAuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        auth_service_1.AuthService,
        access_token_service_1.AccessTokenService,
        audit_log_service_1.AuditLogService])
], MobileAuthService);
function hashToken(value) {
    return (0, crypto_1.createHash)('sha256').update(value).digest('hex');
}
function clean(value) {
    const result = value?.trim();
    return result || undefined;
}
