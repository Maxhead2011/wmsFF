"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportsService = void 0;
const common_1 = require("@nestjs/common");
const XLSX = __importStar(require("xlsx"));
const prisma_service_1 = require("../../common/prisma/prisma.service");
const inventory_lock_service_1 = require("../../common/inventory/inventory-lock.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const logistics_service_1 = require("../logistics/logistics.service");
const stock_balances_service_1 = require("../stock/stock-balances.service");
const logistics_xlsx_parser_1 = require("./parsers/logistics-xlsx.parser");
const receipt_xlsx_parser_1 = require("./parsers/receipt-xlsx.parser");
const stock_xlsx_parser_1 = require("./parsers/stock-xlsx.parser");
const STOCK_IMPORT_TRANSACTION_OPTIONS = {
    maxWait: 10_000,
    timeout: 180_000,
};
let ImportsService = class ImportsService {
    prisma;
    balances;
    clientScopes;
    logistics;
    inventoryLock;
    constructor(prisma, balances, clientScopes, logistics, inventoryLock) {
        this.prisma = prisma;
        this.balances = balances;
        this.clientScopes = clientScopes;
        this.logistics = logistics;
        this.inventoryLock = inventoryLock;
    }
    async previewStockWorkbook(buffer, clientId, user) {
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const parsed = await this.parseStockWorkbookWithCatalog(buffer, clientId);
        return {
            clientId,
            summary: parsed.summary,
            issues: parsed.issues,
            suggestions: parsed.suggestions,
            sample: parsed.items.slice(0, 20),
        };
    }
    async previewReceiptWorkbook(buffer, clientId, user) {
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        const rows = this.readReceiptSheet(buffer);
        const parsed = (0, receipt_xlsx_parser_1.parseReceiptSheet)(rows, { clientId });
        const issues = [...parsed.issues, ...(await this.duplicateKizIssues(parsed.items))];
        return {
            clientId,
            summary: parsed.summary,
            issues,
            sample: parsed.items.slice(0, 20),
        };
    }
    previewLogisticsWorkbook(buffer) {
        const rows = this.readFirstSheet(buffer);
        const parsed = (0, logistics_xlsx_parser_1.parseLogisticsTariffSheet)(rows);
        return {
            note: parsed.note,
            directionsCount: parsed.directions.length,
            directions: parsed.directions,
            issues: parsed.issues,
        };
    }
    async commitLogisticsWorkbook(buffer, options) {
        const rows = this.readFirstSheet(buffer);
        const parsed = (0, logistics_xlsx_parser_1.parseLogisticsTariffSheet)(rows);
        const tariffSet = await this.logistics.commitTariffSet(parsed, options);
        return {
            tariffSetId: tariffSet.id,
            name: tariffSet.name,
            sourceFile: tariffSet.sourceFile,
            directionsCount: tariffSet.directions.length,
            tiersCount: tariffSet.directions.reduce((sum, direction) => sum + direction.tiers.length, 0),
        };
    }
    async commitStockWorkbook(buffer, options) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        this.clientScopes.requireClientAccess(options.user, options.clientId, 'write');
        const warehouseId = await this.resolveImportWarehouseId(options.user, options.clientId);
        const parsed = await this.parseStockWorkbookWithCatalog(buffer, options.clientId);
        const errors = parsed.issues.filter((issue) => issue.severity === 'error');
        if (errors.length > 0) {
            throw new common_1.BadRequestException({
                message: 'Файл содержит ошибки, импорт в WMS остановлен.',
                errors,
                summary: parsed.summary,
            });
        }
        const result = await this.prisma.$transaction(async (tx) => {
            const counters = {
                boxesTouched: 0,
                skusTouched: 0,
                movementsCreated: 0,
                balancesTouched: 0,
            };
            for (const item of parsed.items) {
                const box = await this.ensureBox(tx, item, warehouseId);
                const sku = await this.ensureSku(tx, item);
                await this.ensureBarcode(tx, sku.id, item.barcode);
                const movementCreated = await this.createInitialMovement(tx, item, sku.id, box.id, warehouseId, options.sourceDocument);
                await this.addToBalance(tx, item, sku.id, box.id, warehouseId, 'AVAILABLE');
                counters.boxesTouched += 1;
                counters.skusTouched += 1;
                counters.movementsCreated += movementCreated ? 1 : 0;
                counters.balancesTouched += 1;
            }
            return counters;
        }, STOCK_IMPORT_TRANSACTION_OPTIONS);
        return {
            sourceDocument: options.sourceDocument,
            summary: parsed.summary,
            suggestions: parsed.suggestions,
            warnings: parsed.issues.filter((issue) => issue.severity === 'warning'),
            result,
        };
    }
    async parseStockWorkbookWithCatalog(buffer, clientId) {
        const rows = this.readFirstSheet(buffer);
        const parsed = (0, stock_xlsx_parser_1.parseStockSheet)(rows, { clientId });
        const enriched = await this.enrichStockItemsFromCatalog(parsed.items);
        return {
            ...parsed,
            items: enriched.items,
            issues: [...parsed.issues, ...enriched.issues],
            suggestions: enriched.suggestions,
            summary: stockImportSummary(enriched.items),
        };
    }
    async commitReceiptWorkbook(buffer, options) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        this.clientScopes.requireClientAccess(options.user, options.clientId, 'write');
        const warehouseId = await this.resolveImportWarehouseId(options.user, options.clientId);
        const rows = this.readReceiptSheet(buffer);
        const parsed = (0, receipt_xlsx_parser_1.parseReceiptSheet)(rows, { clientId: options.clientId });
        const issues = [...parsed.issues, ...(await this.duplicateKizIssues(parsed.items))];
        const errors = issues.filter((issue) => issue.severity === 'error');
        if (errors.length > 0) {
            throw new common_1.BadRequestException({
                message: 'Файл приемки содержит ошибки, запись в WMS остановлена.',
                errors,
                summary: parsed.summary,
            });
        }
        const result = await this.prisma.$transaction(async (tx) => {
            const counters = {
                boxesTouched: 0,
                skusTouched: 0,
                movementsCreated: 0,
                balancesTouched: 0,
                kizCreated: 0,
            };
            for (const item of parsed.items) {
                const box = await this.ensureBox(tx, item, warehouseId);
                const sku = await this.ensureSku(tx, item);
                await this.ensureBarcode(tx, sku.id, item.barcode);
                const movement = await this.createReceiptMovement(tx, item, sku.id, box.id, warehouseId, options.sourceDocument);
                await this.addToBalance(tx, item, sku.id, box.id, warehouseId, 'AVAILABLE');
                await tx.productMark.create({
                    data: {
                        clientId: item.clientId,
                        skuId: sku.id,
                        boxId: box.id,
                        stockMovementId: movement.id,
                        value: item.kiz,
                        sourceDocument: options.sourceDocument,
                        sourceRow: item.sourceRow,
                        status: 'AVAILABLE',
                    },
                });
                counters.boxesTouched += 1;
                counters.skusTouched += 1;
                counters.movementsCreated += 1;
                counters.balancesTouched += 1;
                counters.kizCreated += 1;
            }
            return counters;
        }, STOCK_IMPORT_TRANSACTION_OPTIONS);
        return {
            sourceDocument: options.sourceDocument,
            summary: parsed.summary,
            warnings: issues.filter((issue) => issue.severity === 'warning'),
            result,
        };
    }
    readFirstSheet(buffer) {
        // Русский комментарий: XLSX читаем как матрицу, чтобы не зависеть от кривых merged cells в исходных файлах.
        const workbook = XLSX.read(buffer, { type: 'buffer' });
        const firstSheet = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheet];
        return XLSX.utils.sheet_to_json(worksheet, {
            header: 1,
            raw: false,
            blankrows: false,
        });
    }
    readReceiptSheet(buffer) {
        const workbook = XLSX.read(buffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames.find((name) => name.trim().toLowerCase() === 'тсд') ??
            workbook.SheetNames.find((name) => {
                const rows = XLSX.utils.sheet_to_json(workbook.Sheets[name], {
                    header: 1,
                    raw: false,
                    blankrows: false,
                });
                return rows.some((row) => {
                    const cells = row.map((cell) => String(cell ?? '').toLowerCase());
                    return cells.some((cell) => cell.includes('баркод')) && cells.some((cell) => cell.includes('киз'));
                });
            }) ??
            workbook.SheetNames[0];
        return XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            header: 1,
            raw: false,
            blankrows: false,
        });
    }
    async ensureBox(tx, item, warehouseId) {
        const box = await tx.box.upsert({
            where: {
                clientId_code: {
                    clientId: item.clientId,
                    code: item.boxCode,
                },
            },
            update: {},
            create: {
                clientId: item.clientId,
                warehouseId,
                code: item.boxCode,
            },
        });
        if (box.warehouseId !== warehouseId) {
            throw new common_1.ForbiddenException(`Короб ${item.boxCode} относится к другому филиалу или не имеет безопасной привязки. Импорт остановлен.`);
        }
        return box;
    }
    async ensureSku(tx, item) {
        const existingBarcode = await tx.barcode.findFirst({
            where: {
                value: item.barcode,
                sku: { clientId: item.clientId },
            },
            include: { sku: true },
        });
        if (existingBarcode) {
            return existingBarcode.sku;
        }
        // Русский комментарий: для первичного импорта внутренний SKU строим из штрихкода, потому что это самый стабильный идентификатор в файле.
        return tx.sku.create({
            data: {
                clientId: item.clientId,
                internalSku: `BAR-${item.barcode}`,
                name: item.name,
                color: item.color,
                size: item.size,
            },
        });
    }
    ensureBarcode(tx, skuId, barcode) {
        return tx.barcode.upsert({
            where: {
                skuId_value: {
                    skuId,
                    value: barcode,
                },
            },
            update: { isPrimary: true },
            create: {
                skuId,
                value: barcode,
                isPrimary: true,
            },
        });
    }
    async createInitialMovement(tx, item, skuId, boxId, warehouseId, sourceDocument) {
        const idempotencyKey = ['stock-import', sourceDocument, item.sourceRow, item.boxCode, item.barcode].join(':');
        const exists = await tx.stockMovement.findUnique({ where: { idempotencyKey } });
        if (exists) {
            if (exists.warehouseId && exists.warehouseId !== warehouseId) {
                throw new common_1.ForbiddenException('Строка импорта уже относится к другому филиалу.');
            }
            if (!exists.warehouseId) {
                await tx.stockMovement.update({ where: { id: exists.id }, data: { warehouseId } });
            }
            return false;
        }
        await tx.stockMovement.create({
            data: {
                warehouseId,
                clientId: item.clientId,
                skuId,
                boxId,
                type: 'INITIAL_IMPORT',
                status: 'AVAILABLE',
                quantity: item.quantity,
                sourceDocument,
                idempotencyKey,
                comment: 'Первичная загрузка остатков из XLSX',
            },
        });
        return true;
    }
    async createReceiptMovement(tx, item, skuId, boxId, warehouseId, sourceDocument) {
        return tx.stockMovement.create({
            data: {
                warehouseId,
                clientId: item.clientId,
                skuId,
                boxId,
                type: 'RECEIPT',
                status: 'AVAILABLE',
                quantity: 1,
                sourceDocument,
                idempotencyKey: ['receipt-import', sourceDocument, item.sourceRow, item.boxCode, item.kiz].join(':'),
                comment: 'Приемка товара из XLSX с КИЗ',
            },
        });
    }
    async addToBalance(tx, item, skuId, boxId, warehouseId, status) {
        const balanceKey = this.balances.balanceKey({
            warehouseId,
            clientId: item.clientId,
            skuId,
            boxId,
            status,
        });
        await tx.stockBalance.upsert({
            where: { balanceKey },
            update: {
                warehouseId,
                quantity: { increment: item.quantity },
            },
            create: {
                balanceKey,
                warehouseId,
                clientId: item.clientId,
                skuId,
                boxId,
                status,
                quantity: item.quantity,
            },
        });
    }
    async resolveImportWarehouseId(user, clientId) {
        const activeWarehouseId = user.activeWarehouseId?.trim() || null;
        const isSystemAdmin = user.permissionCodes.includes('system:admin');
        const isClient = user.roleCodes.includes('CLIENT');
        if (activeWarehouseId &&
            !isSystemAdmin &&
            !isClient &&
            !(user.writableWarehouseIds ?? []).includes(activeWarehouseId)) {
            throw new common_1.ForbiddenException('Активный филиал недоступен сотруднику для импорта остатков.');
        }
        if (!activeWarehouseId && !isSystemAdmin && !isClient) {
            throw new common_1.BadRequestException('Перед импортом выберите активный филиал.');
        }
        const links = await this.prisma.warehouseClient.findMany({
            where: {
                clientId,
                status: 'ACTIVE',
                warehouse: { isActive: true },
                ...(activeWarehouseId ? { warehouseId: activeWarehouseId } : {}),
            },
            select: { warehouseId: true },
            orderBy: { createdAt: 'asc' },
            take: activeWarehouseId ? 1 : 2,
        });
        if (activeWarehouseId) {
            if (links.length !== 1) {
                throw new common_1.ForbiddenException('Клиент не подключен к активному филиалу. Импорт остановлен.');
            }
            return activeWarehouseId;
        }
        if (links.length === 1) {
            return links[0].warehouseId;
        }
        if (links.length === 0) {
            throw new common_1.BadRequestException('Клиент не подключен ни к одному активному филиалу.');
        }
        throw new common_1.BadRequestException('Клиент работает в нескольких филиалах. Перед импортом выберите филиал явно.');
    }
    async duplicateKizIssues(items) {
        const uniqueKiz = [...new Set(items.map((item) => item.kiz))];
        if (uniqueKiz.length === 0) {
            return [];
        }
        const existing = await this.prisma.productMark.findMany({
            where: {
                clientId: items[0]?.clientId,
                value: { in: uniqueKiz },
            },
            select: {
                value: true,
            },
        });
        const existingKiz = new Set(existing.map((item) => item.value));
        return items
            .filter((item) => existingKiz.has(item.kiz))
            .map((item) => ({
            row: item.sourceRow,
            message: 'КИЗ уже есть в WMS, повторная приемка запрещена.',
            severity: 'error',
        }));
    }
    async enrichStockItemsFromCatalog(items) {
        const missingBarcodeItems = items.filter((item) => !item.barcode);
        if (missingBarcodeItems.length === 0) {
            return { items, issues: [], suggestions: [] };
        }
        const lookupValues = [...new Set(missingBarcodeItems.map((item) => item.name).filter(Boolean))];
        const catalogRows = lookupValues.length
            ? await this.prisma.nomenclatureItem.findMany({
                where: {
                    OR: [{ name: { in: lookupValues } }, { internalSku: { in: lookupValues } }, { article: { in: lookupValues } }],
                },
                select: {
                    barcode: true,
                    name: true,
                    article: true,
                    internalSku: true,
                    color: true,
                    size: true,
                },
            })
            : [];
        const catalogByKey = new Map();
        for (const row of catalogRows) {
            [row.name, row.internalSku, row.article].forEach((value) => {
                const key = stockCatalogKey(value);
                if (!key) {
                    return;
                }
                catalogByKey.set(key, [...(catalogByKey.get(key) ?? []), row]);
            });
        }
        const issues = [];
        const suggestions = [];
        const enrichedItems = items.map((item) => {
            if (item.barcode) {
                return item;
            }
            const matches = (catalogByKey.get(stockCatalogKey(item.name)) ?? []).filter((row) => stockCatalogPropertiesMatch(row, item));
            const exactMatches = uniqueCatalogRows(matches);
            const matchedBarcode = exactMatches[0]?.barcode;
            if (exactMatches.length === 1 && matchedBarcode) {
                const match = exactMatches[0];
                suggestions.push({
                    row: item.sourceRow,
                    type: 'FILL_BARCODE_FROM_CATALOG',
                    title: 'Баркод взят из каталога',
                    message: `${match.name}: ${matchedBarcode}`,
                    barcode: matchedBarcode,
                    name: match.name,
                    article: match.article,
                    color: match.color,
                    size: match.size,
                    applied: true,
                });
                issues.push({
                    row: item.sourceRow,
                    message: `Штрихкод не был заполнен в файле, WMS взяла его из каталога: ${matchedBarcode}.`,
                    severity: 'warning',
                });
                return {
                    ...item,
                    barcode: matchedBarcode,
                    name: item.name || match.name,
                    color: item.color ?? match.color ?? undefined,
                    size: item.size ?? match.size ?? undefined,
                };
            }
            if (exactMatches.length > 1) {
                suggestions.push({
                    row: item.sourceRow,
                    type: 'FILL_BARCODE_FROM_CATALOG',
                    title: 'Нужно выбрать товар',
                    message: `В каталоге найдено несколько похожих карточек: ${exactMatches
                        .slice(0, 3)
                        .map((match) => [match.name, match.size, match.barcode].filter(Boolean).join(' / '))
                        .join('; ')}.`,
                    applied: false,
                });
                issues.push({
                    row: item.sourceRow,
                    message: 'Штрихкод не заполнен, а в каталоге найдено несколько вариантов. Уточните баркод в файле или карточку товара.',
                    severity: 'error',
                });
                return item;
            }
            const matchedWithoutBarcode = exactMatches[0];
            if (matchedWithoutBarcode && !matchedWithoutBarcode.barcode) {
                suggestions.push({
                    row: item.sourceRow,
                    type: 'FILL_BARCODE_FROM_CATALOG',
                    title: 'Карточка есть без баркода',
                    message: `${matchedWithoutBarcode.name}: заполните баркод в каталоге или в файле остатков.`,
                    name: matchedWithoutBarcode.name,
                    article: matchedWithoutBarcode.article,
                    color: matchedWithoutBarcode.color,
                    size: matchedWithoutBarcode.size,
                    applied: false,
                });
            }
            issues.push({
                row: item.sourceRow,
                message: 'Не заполнен штрихкод. WMS не нашла один точный баркод в каталоге.',
                severity: 'error',
            });
            return item;
        });
        return { items: enrichedItems, issues, suggestions };
    }
};
exports.ImportsService = ImportsService;
exports.ImportsService = ImportsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        stock_balances_service_1.StockBalancesService,
        client_scope_service_1.ClientScopeService,
        logistics_service_1.LogisticsService,
        inventory_lock_service_1.InventoryLockService])
], ImportsService);
function stockImportSummary(items) {
    const uniqueBoxes = new Set(items.map((item) => item.boxCode));
    const uniqueBarcodes = new Set(items.map((item) => item.barcode).filter(Boolean));
    const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0);
    return {
        rows: items.length,
        boxes: uniqueBoxes.size,
        barcodes: uniqueBarcodes.size,
        totalQuantity,
    };
}
function stockCatalogKey(value) {
    return value?.trim().toLowerCase().replace(/\s+/g, ' ') ?? '';
}
function stockCatalogPropertiesMatch(row, item) {
    return stockOptionalMatch(row.color, item.color) && stockOptionalMatch(row.size, item.size);
}
function stockOptionalMatch(left, right) {
    const normalizedRight = stockCatalogKey(right);
    return !normalizedRight || stockCatalogKey(left) === normalizedRight;
}
function uniqueCatalogRows(rows) {
    const result = new Map();
    rows.forEach((row) => result.set(row.internalSku, row));
    return [...result.values()];
}
