"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const imports_service_1 = require("./imports.service");
let ImportsController = class ImportsController {
    importsService;
    constructor(importsService) {
        this.importsService = importsService;
    }
    previewStockFile(file, clientId, user) {
        return this.importsService.previewStockWorkbook(file.buffer, clientId, user);
    }
    commitStockFile(file, clientId, user, sourceDocument) {
        return this.importsService.commitStockWorkbook(file.buffer, {
            clientId,
            sourceDocument: sourceDocument || file.originalname,
            user,
        });
    }
    previewReceiptFile(file, clientId, user) {
        return this.importsService.previewReceiptWorkbook(file.buffer, clientId, user);
    }
    commitReceiptFile(file, clientId, user, sourceDocument) {
        return this.importsService.commitReceiptWorkbook(file.buffer, {
            clientId,
            sourceDocument: sourceDocument || file.originalname,
            user,
        });
    }
    previewLogisticsFile(file) {
        return this.importsService.previewLogisticsWorkbook(file.buffer);
    }
    commitLogisticsFile(file, name, activeFrom, activeTo) {
        return this.importsService.commitLogisticsWorkbook(file.buffer, {
            name: name || file.originalname,
            sourceFile: file.originalname,
            activeFrom,
            activeTo,
        });
    }
};
exports.ImportsController = ImportsController;
__decorate([
    (0, common_1.Post)('stocks/preview'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'XLSX-файл остатков и clientId' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", void 0)
], ImportsController.prototype, "previewStockFile", null);
__decorate([
    (0, common_1.Post)('stocks/commit'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'XLSX-файл остатков, clientId и sourceDocument' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Body)('sourceDocument')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object, String]),
    __metadata("design:returntype", void 0)
], ImportsController.prototype, "commitStockFile", null);
__decorate([
    (0, common_1.Post)('receipts/preview'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'XLSX-файл приемки с коробами, баркодами и КИЗ' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", void 0)
], ImportsController.prototype, "previewReceiptFile", null);
__decorate([
    (0, common_1.Post)('receipts/commit'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'XLSX-файл приемки, clientId и sourceDocument' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('clientId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Body)('sourceDocument')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object, String]),
    __metadata("design:returntype", void 0)
], ImportsController.prototype, "commitReceiptFile", null);
__decorate([
    (0, common_1.Post)('logistics/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'XLSX-файл тарифов логистики' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ImportsController.prototype, "previewLogisticsFile", null);
__decorate([
    (0, common_1.Post)('logistics/commit'),
    (0, require_permissions_decorator_1.RequirePermissions)('logistics:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'XLSX-файл тарифов логистики, имя набора и период активности' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('name')),
    __param(2, (0, common_1.Body)('activeFrom')),
    __param(3, (0, common_1.Body)('activeTo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], ImportsController.prototype, "commitLogisticsFile", null);
exports.ImportsController = ImportsController = __decorate([
    (0, swagger_1.ApiTags)('imports'),
    (0, require_permissions_decorator_1.RequirePermissions)('imports:write'),
    (0, common_1.Controller)('imports'),
    __metadata("design:paramtypes", [imports_service_1.ImportsService])
], ImportsController);
