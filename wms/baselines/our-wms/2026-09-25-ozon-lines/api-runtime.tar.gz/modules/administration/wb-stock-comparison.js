"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseWbStockFile = parseWbStockFile;
const common_1 = require("@nestjs/common");
const XLSX = __importStar(require("xlsx"));
const COLUMN_ALIASES = {
    barcode: new Set(['баркод', 'штрихкод', 'barcode']),
    quantity: new Set(['количество', 'остаток', 'quantity']),
    product: new Set(['предмет']),
    brand: new Set(['бренд']),
    name: new Set(['наименование', 'товар', 'название']),
    size: new Set(['размер']),
    sellerArticle: new Set(['артикулпродавца', 'артикул', 'vendorcode']),
};
function parseWbStockFile(buffer) {
    let workbook;
    try {
        workbook = XLSX.read(buffer, { type: 'buffer', cellDates: false });
    }
    catch {
        throw new common_1.BadRequestException('Не удалось прочитать файл. Загрузите XLSX или XLS с остатками Wildberries.');
    }
    for (const sheetName of workbook.SheetNames) {
        const sheet = workbook.Sheets[sheetName];
        if (!sheet)
            continue;
        const matrix = XLSX.utils.sheet_to_json(sheet, {
            header: 1,
            raw: false,
            defval: '',
            blankrows: false,
        });
        const parsed = parseMatrix(matrix);
        if (parsed)
            return { sheetName, ...parsed };
    }
    throw new common_1.BadRequestException('В файле не найдены обязательные колонки «Баркод» и «Количество».');
}
function parseMatrix(matrix) {
    const header = findHeader(matrix);
    if (!header)
        return null;
    const aggregated = new Map();
    let sourceRows = 0;
    let duplicateRows = 0;
    for (let rowIndex = header.rowIndex + 1; rowIndex < matrix.length; rowIndex += 1) {
        const values = matrix[rowIndex] ?? [];
        const barcode = normalizeBarcode(values[header.columns.barcode]);
        if (!barcode)
            continue;
        const quantity = parseQuantity(values[header.columns.quantity], rowIndex + 1);
        sourceRows += 1;
        const existing = aggregated.get(barcode);
        if (existing) {
            existing.quantity += quantity;
            existing.sourceRows.push(rowIndex + 1);
            duplicateRows += 1;
            continue;
        }
        aggregated.set(barcode, {
            barcode,
            quantity,
            product: optionalText(values[header.columns.product]),
            brand: optionalText(values[header.columns.brand]),
            name: optionalText(values[header.columns.name]),
            size: optionalText(values[header.columns.size]),
            sellerArticle: optionalText(values[header.columns.sellerArticle]),
            sourceRows: [rowIndex + 1],
        });
    }
    if (!sourceRows) {
        throw new common_1.BadRequestException('В файле нет строк с заполненным баркодом.');
    }
    if (aggregated.size > 50_000) {
        throw new common_1.BadRequestException('В одном файле можно проверить не более 50 000 уникальных баркодов.');
    }
    return { sourceRows, duplicateRows, rows: [...aggregated.values()] };
}
function findHeader(matrix) {
    for (let rowIndex = 0; rowIndex < Math.min(matrix.length, 30); rowIndex += 1) {
        const columns = {};
        (matrix[rowIndex] ?? []).forEach((cell, columnIndex) => {
            const normalized = normalizeHeader(cell);
            for (const [key, aliases] of Object.entries(COLUMN_ALIASES)) {
                if (aliases.has(normalized))
                    columns[key] = columnIndex;
            }
        });
        if (columns.barcode != null && columns.quantity != null) {
            return {
                rowIndex,
                columns: {
                    barcode: columns.barcode,
                    quantity: columns.quantity,
                    product: columns.product ?? -1,
                    brand: columns.brand ?? -1,
                    name: columns.name ?? -1,
                    size: columns.size ?? -1,
                    sellerArticle: columns.sellerArticle ?? -1,
                },
            };
        }
    }
    return null;
}
function normalizeHeader(value) {
    return String(value ?? '')
        .trim()
        .toLocaleLowerCase('ru-RU')
        .replace(/ё/g, 'е')
        .replace(/[^a-zа-я0-9]+/gi, '');
}
function normalizeBarcode(value) {
    const text = String(value ?? '').trim().replace(/\s+/g, '');
    if (!text)
        return '';
    if (/^\d+\.0+$/.test(text))
        return text.replace(/\.0+$/, '');
    if (/^\d+(?:[.,]\d+)?e\+?\d+$/i.test(text)) {
        const number = Number(text.replace(',', '.'));
        if (Number.isSafeInteger(number))
            return number.toFixed(0);
    }
    return text;
}
function parseQuantity(value, row) {
    const text = String(value ?? '').trim().replace(/\s+/g, '').replace(',', '.');
    if (!text)
        return 0;
    const number = Number(text);
    if (!Number.isFinite(number) || number < 0 || !Number.isInteger(number)) {
        throw new common_1.BadRequestException(`Некорректное количество в строке ${row}: «${String(value)}».`);
    }
    return number;
}
function optionalText(value) {
    const text = String(value ?? '').trim();
    return text || null;
}
