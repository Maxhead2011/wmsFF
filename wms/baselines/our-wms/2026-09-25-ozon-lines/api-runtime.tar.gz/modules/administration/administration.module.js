"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdministrationModule = void 0;
const fbo_problems_controller_1 = require("./fbo-problems.controller");
const fbo_problems_service_1 = require("./fbo-problems.service");
const fbo_two_stage_service_1 = require("../tsd/fbo-two-stage.service");
const client_request_marketplace_files_service_1 = require("../client-requests/client-request-marketplace-files.service");
const common_1 = require("@nestjs/common");
const auto_assembly_controller_1 = require("./auto-assembly.controller");
const auto_assembly_service_1 = require("./auto-assembly.service");
const auth_module_1 = require("../auth/auth.module");
const administration_controller_1 = require("./administration.controller");
const administration_service_1 = require("./administration.service");
const marketplace_connections_module_1 = require("../marketplace-connections/marketplace-connections.module");
const stock_module_1 = require("../stock/stock.module");
const phantom_stock_service_1 = require("./phantom-stock.service");
const administration_technical_work_service_1 = require("./administration-technical-work.service");
const administration_internal_api_service_1 = require("./administration-internal-api.service");
const administration_unpalleted_writeoff_service_1 = require("./administration-unpalleted-writeoff.service");
const inventory_module_1 = require("../inventory/inventory.module");
const administration_marketplace_stock_control_controller_1 = require("./administration-marketplace-stock-control.controller");
let AdministrationModule = class AdministrationModule {
};
exports.AdministrationModule = AdministrationModule;
exports.AdministrationModule = AdministrationModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, marketplace_connections_module_1.MarketplaceConnectionsModule, stock_module_1.StockModule, inventory_module_1.InventoryModule],
        controllers: [fbo_problems_controller_1.FboProblemsController, auto_assembly_controller_1.AutoAssemblyController, administration_controller_1.AdministrationController, administration_marketplace_stock_control_controller_1.AdministrationMarketplaceStockControlController],
        // ADDED: Internal API diagnostics are isolated from existing technical-work repair logic.
        providers: [fbo_problems_service_1.FboProblemsService, fbo_two_stage_service_1.FboTwoStageService, client_request_marketplace_files_service_1.ClientRequestMarketplaceFilesService,
            auto_assembly_service_1.AutoAssemblyService,
            administration_service_1.AdministrationService,
            administration_technical_work_service_1.AdministrationTechnicalWorkService,
            administration_internal_api_service_1.AdministrationInternalApiService,
            // FIX: destructive unpalleted-box cleanup is isolated from existing repair flows.
            administration_unpalleted_writeoff_service_1.AdministrationUnpalletedWriteoffService,
            phantom_stock_service_1.PhantomStockService,
        ],
        exports: [administration_service_1.AdministrationService],
    })
], AdministrationModule);
