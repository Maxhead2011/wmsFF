"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const XLSX = __importStar(require("xlsx"));
const vitest_1 = require("vitest");
const wb_stock_comparison_1 = require("./wb-stock-comparison");
function workbookBuffer(rows) {
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet(rows), 'stocks');
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
(0, vitest_1.describe)('parseWbStockFile', () => {
    (0, vitest_1.it)('reads the standard WB columns and aggregates duplicate barcodes', () => {
        const result = (0, wb_stock_comparison_1.parseWbStockFile)(workbookBuffer([
            ['Баркод', 'Количество', 'Предмет', 'Бренд', 'Наименование', 'Размер', 'Артикул продавца'],
            ['2049156013036', 19, 'Костюмы', 'LOOK.IN', 'Костюм', 'S', 'Корея_2бежевый'],
            ['2049156013036', 2, 'Костюмы', 'LOOK.IN', 'Костюм', 'S', 'Корея_2бежевый'],
            ['2049156013555', 0, 'Костюмы', 'LOOK.IN', 'Костюм', 'M', 'Корея_2голубой'],
        ]));
        (0, vitest_1.expect)(result.sourceRows).toBe(3);
        (0, vitest_1.expect)(result.duplicateRows).toBe(1);
        (0, vitest_1.expect)(result.rows).toHaveLength(2);
        (0, vitest_1.expect)(result.rows[0]).toMatchObject({ barcode: '2049156013036', quantity: 21, size: 'S' });
    });
    (0, vitest_1.it)('rejects a file without barcode and quantity headers', () => {
        (0, vitest_1.expect)(() => (0, wb_stock_comparison_1.parseWbStockFile)(workbookBuffer([['Товар', 'Остаток WB'], ['A', 2]])))
            .toThrow('Баркод');
    });
});
