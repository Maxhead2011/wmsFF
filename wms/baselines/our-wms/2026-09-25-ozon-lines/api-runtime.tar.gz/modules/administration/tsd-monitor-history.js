"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readTsdMonitorHistory = readTsdMonitorHistory;
const client_1 = require("@prisma/client");
async function readTsdMonitorHistory(db, kind, since) {
    const where = kind === 'errors' ? {
        createdAt: { gte: since }, AND: [
            { operationType: { not: 'monitor_command' } },
            { OR: [{ operationType: 'monitor_error' }, { status: { in: [client_1.TsdOperationStatus.REJECTED, client_1.TsdOperationStatus.NEEDS_REVIEW] } }] },
        ],
    } : { createdAt: { gte: since }, operationType: { notIn: ['monitor_heartbeat', 'monitor_command', 'monitor_message'] } };
    const take = kind === 'errors' ? 500 : 1000;
    if (process.env.WMS_TSD_MONITOR_COMPACT_ENABLED !== 'true') {
        return db.tsdOperation.findMany({ where, orderBy: { createdAt: 'desc' }, take });
    }
    // FIX: project display fields inside PostgreSQL; never transfer audit responses or screenshots to the monitor.
    const filter = kind === 'errors'
        ? client_1.Prisma.sql `"operationType" <> 'monitor_command' AND ("operationType" = 'monitor_error' OR "status" IN ('REJECTED', 'NEEDS_REVIEW'))`
        : client_1.Prisma.sql `"operationType" NOT IN ('monitor_heartbeat', 'monitor_command', 'monitor_message')`;
    return db.$queryRaw(client_1.Prisma.sql `
    SELECT "id", "deviceId", "operationKey", "operationType", "status", "serverMessage", "createdAt", "updatedAt",
      jsonb_strip_nulls(jsonb_build_object(
        'deviceCode', payload->'deviceCode', 'message', payload->'message',
        'screenLabel', payload->'screenLabel', 'screen', payload->'screen',
        'stageLabel', payload->'stageLabel', 'stage', payload->'stage',
        'requestId', payload->'requestId', 'requestNumber', payload->'requestNumber',
        'orderId', payload->'orderId', 'workerName', payload->'workerName',
        'clientName', payload->'clientName', 'boxCode', payload->'boxCode',
        'normalizedBoxCode', payload->'normalizedBoxCode', 'barcode', payload->'barcode'
      )) AS payload
    FROM "TsdOperation" WHERE "createdAt" >= ${since.toISOString()}::timestamp AND ${filter}
    ORDER BY "createdAt" DESC LIMIT ${take}
  `);
}
