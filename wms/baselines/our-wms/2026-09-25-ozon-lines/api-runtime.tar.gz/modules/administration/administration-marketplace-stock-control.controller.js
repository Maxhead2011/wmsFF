"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdministrationMarketplaceStockControlController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const marketplace_stock_control_service_1 = require("../marketplace-connections/marketplace-stock-control.service");
// FIX: a dedicated admin-only boundary; demo administration cannot change client publication.
let AdministrationMarketplaceStockControlController = class AdministrationMarketplaceStockControlController {
    control;
    constructor(control) {
        this.control = control;
    }
    list(user) { return this.control.list(user); }
    updateReserve(clientId, body, user) {
        return this.control.updateReserve(clientId, body, user);
    }
    updateSkuRule(clientId, skuId, body, user) {
        return this.control.updateFineRule(clientId, skuId, body, user);
    }
    updateAnalysis(clientId, body, user) {
        return this.control.updateFineRule(clientId, null, body, user);
    }
    update(clientId, body, user) {
        return this.control.update(clientId, body, user);
    }
};
exports.AdministrationMarketplaceStockControlController = AdministrationMarketplaceStockControlController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationMarketplaceStockControlController.prototype, "list", null);
__decorate([
    (0, common_1.Put)(':clientId/reserve')
    // FIX: service checks writable client assignment; other administration remains restricted.
    ,
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationMarketplaceStockControlController.prototype, "updateReserve", null);
__decorate([
    (0, common_1.Put)(':clientId/skus/:skuId'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Param)('skuId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationMarketplaceStockControlController.prototype, "updateSkuRule", null);
__decorate([
    (0, common_1.Put)(':clientId/analysis'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationMarketplaceStockControlController.prototype, "updateAnalysis", null);
__decorate([
    (0, common_1.Put)(':clientId'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationMarketplaceStockControlController.prototype, "update", null);
exports.AdministrationMarketplaceStockControlController = AdministrationMarketplaceStockControlController = __decorate([
    (0, swagger_1.ApiTags)('administration'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Controller)('administration/marketplace-stock-control'),
    __metadata("design:paramtypes", [marketplace_stock_control_service_1.MarketplaceStockControlService])
], AdministrationMarketplaceStockControlController);
