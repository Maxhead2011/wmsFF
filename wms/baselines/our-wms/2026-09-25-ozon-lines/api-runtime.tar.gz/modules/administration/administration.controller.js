"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdministrationController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const platform_express_1 = require("@nestjs/platform-express");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const administration_service_1 = require("./administration.service");
const phantom_stock_service_1 = require("./phantom-stock.service");
const administration_technical_work_service_1 = require("./administration-technical-work.service");
const administration_internal_api_service_1 = require("./administration-internal-api.service");
const administration_unpalleted_writeoff_service_1 = require("./administration-unpalleted-writeoff.service");
let AdministrationController = class AdministrationController {
    administration;
    technicalWork;
    phantomStock;
    internalApi;
    unpalletedWriteoff;
    constructor(administration, technicalWork, phantomStock, internalApi, unpalletedWriteoff) {
        this.administration = administration;
        this.technicalWork = technicalWork;
        this.phantomStock = phantomStock;
        this.internalApi = internalApi;
        this.unpalletedWriteoff = unpalletedWriteoff;
    }
    overview(user) {
        return this.administration.overview(user);
    }
    // ADDED: Central technical-work registry. Every returned action maps to a real server repair.
    technicalWorkOverview(user) {
        return this.technicalWork.overview(user);
    }
    // ADDED: Read-only status and documentation for every internal controller group.
    internalApiOverview(user) {
        return this.internalApi.overview(user);
    }
    // ADDED: A demo administrator may inspect status but cannot restart the API process.
    restartInternalApi(body, user) {
        return this.internalApi.restart(body, user);
    }
    diagnoseTechnicalWork(body, user) {
        return this.technicalWork.diagnose(body.category, user);
    }
    applyTechnicalWork(body, user) {
        return this.technicalWork.apply(body, user);
    }
    // ADDED: Bulk endpoint keeps one category and one whitelisted action per run.
    applyTechnicalWorkBulk(body, user) {
        return this.technicalWork.applyBulk(body, user);
    }
    // ADDED: Physical scan preview never changes placement.
    previewPalletSortScan(body, user) {
        return this.technicalWork.previewPalletSortScan(body, user);
    }
    // ADDED: Apply revalidates the exact pallet and boxes scanned by the operator.
    applyPalletSortScan(body, user) {
        return this.technicalWork.applyPalletSortScan(body, user);
    }
    // FIX: only a real system administrator can inspect the destructive cleanup queue.
    previewUnpalletedBoxWriteoff(user) {
        return this.unpalletedWriteoff.preview(user);
    }
    // FIX: this endpoint invokes only the existing WB sync and strictly completed inventories.
    recheckUnpalletedBoxBlockers(body, user) {
        return this.unpalletedWriteoff.recheck(body, user);
    }
    // FIX: the service repeats authorization and revalidates every selected box transactionally.
    applyUnpalletedBoxWriteoff(body, user) {
        return this.unpalletedWriteoff.apply(body, user);
    }
    settings(user) {
        return this.administration.listSettings(user);
    }
    updateSetting(key, body, user) {
        return this.administration.updateSetting(key, body.value, body.reason, user);
    }
    workspaceVisibility(user) {
        return this.administration.listWorkspaceVisibility(user);
    }
    updateWorkspaceVisibility(userId, body, user) {
        return this.administration.updateWorkspaceVisibility(userId, body.overrides, body.reason, user);
    }
    marketplaceDiagnostics(body, user) {
        return this.administration.diagnoseMarketplaceConnections(body, user);
    }
    optimizePerformance(user) {
        return this.administration.optimizePerformance(user);
    }
    fbsRequestErrors(user) {
        return this.administration.listFbsRequestErrors(user);
    }
    checkFbsRequestErrors(body, user) {
        return this.administration.checkFbsRequestErrors(body.requestId, user);
    }
    repairFbsRequestErrors(body, user) {
        return this.administration.repairFbsRequestErrors(body.requestId, body.confirmation, user);
    }
    tsdWorkloads(user) {
        return this.administration.listTsdWorkloads(user);
    }
    tsdMonitor(statisticsDate, user) {
        return this.administration.listTsdMonitor(user, statisticsDate);
    }
    tsdMonitorAction(deviceCode, body, user) {
        return this.administration.issueTsdMonitorAction(deviceCode, body.action, user);
    }
    // ADDED: same monitoring owner scope, no client/demo access.
    tsdMessages(code, user) {
        return this.administration.listTsdMessages(code, user);
    }
    sendTsdMessage(code, body, user) {
        return this.administration.sendTsdMessage(code, body, user);
    }
    releaseTsdWorkload(body, user) {
        return this.administration.releaseTsdWorkload(body, user);
    }
    disconnectTsdRequest(body, user) {
        return this.administration.disconnectTsdRequest(body, user);
    }
    phantomStocks() {
        return this.phantomStock.overview();
    }
    fixAllPhantomStocks(user) {
        return this.phantomStock.fixAll(user);
    }
    fixPhantomStock(balanceId, user) {
        return this.phantomStock.fix(balanceId, user);
    }
    compareStockFile(file, clientId, warehouseId, connectionId, marketplaceWarehouseId, user) {
        return this.administration.compareWbStockFile(file, clientId, warehouseId, connectionId, marketplaceWarehouseId, user);
    }
    compareStockFromWb(body, user) {
        return this.administration.compareWbStockApi(body.clientId, body.warehouseId, body.connectionId, body.marketplaceWarehouseId, user);
    }
    audit(search, take, user) {
        return this.administration.listAudit(search, take, user);
    }
    assistantPreview(body, user) {
        return this.administration.previewAssistantChange(body.prompt, user);
    }
    assistantApply(body, user) {
        return this.administration.applyAssistantChange(body.previewId, body.confirmation, user);
    }
    documentation(user) {
        return this.administration.documentation(user);
    }
};
exports.AdministrationController = AdministrationController;
__decorate([
    (0, common_1.Get)('overview'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "overview", null);
__decorate([
    (0, common_1.Get)('technical-work'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "technicalWorkOverview", null);
__decorate([
    (0, common_1.Get)('technical-work/internal-apis'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "internalApiOverview", null);
__decorate([
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Post)('technical-work/internal-apis/restart'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "restartInternalApi", null);
__decorate([
    (0, common_1.Post)('technical-work/diagnose'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "diagnoseTechnicalWork", null);
__decorate([
    (0, common_1.Post)('technical-work/apply'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "applyTechnicalWork", null);
__decorate([
    (0, common_1.Post)('technical-work/apply-bulk'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "applyTechnicalWorkBulk", null);
__decorate([
    (0, common_1.Post)('technical-work/pallet-sorts/scan-preview'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "previewPalletSortScan", null);
__decorate([
    (0, common_1.Post)('technical-work/pallet-sorts/scan-apply'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "applyPalletSortScan", null);
__decorate([
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Post)('technical-work/unpalleted-boxes/preview'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "previewUnpalletedBoxWriteoff", null);
__decorate([
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Post)('technical-work/unpalleted-boxes/recheck'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "recheckUnpalletedBoxBlockers", null);
__decorate([
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Post)('technical-work/unpalleted-boxes/apply'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "applyUnpalletedBoxWriteoff", null);
__decorate([
    (0, common_1.Get)('settings'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "settings", null);
__decorate([
    (0, common_1.Patch)('settings/:key'),
    __param(0, (0, common_1.Param)('key')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "updateSetting", null);
__decorate([
    (0, common_1.Get)('users/workspaces'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "workspaceVisibility", null);
__decorate([
    (0, common_1.Put)('users/:userId/workspaces'),
    __param(0, (0, common_1.Param)('userId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "updateWorkspaceVisibility", null);
__decorate([
    (0, common_1.Post)('marketplaces/diagnostics'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "marketplaceDiagnostics", null);
__decorate([
    (0, common_1.Post)('performance/optimize'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "optimizePerformance", null);
__decorate([
    (0, common_1.Get)('fbs-request-errors/requests'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "fbsRequestErrors", null);
__decorate([
    (0, common_1.Post)('fbs-request-errors/check'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "checkFbsRequestErrors", null);
__decorate([
    (0, common_1.Post)('fbs-request-errors/repair'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "repairFbsRequestErrors", null);
__decorate([
    (0, common_1.Get)('tsd-workloads'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "tsdWorkloads", null);
__decorate([
    (0, common_1.Get)('tsd-monitor'),
    __param(0, (0, common_1.Query)('statisticsDate')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "tsdMonitor", null);
__decorate([
    (0, common_1.Post)('tsd-monitor/devices/:deviceCode/action'),
    __param(0, (0, common_1.Param)('deviceCode')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "tsdMonitorAction", null);
__decorate([
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Get)('tsd-monitor/devices/:deviceCode/messages'),
    __param(0, (0, common_1.Param)('deviceCode')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "tsdMessages", null);
__decorate([
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Post)('tsd-monitor/devices/:deviceCode/messages'),
    __param(0, (0, common_1.Param)('deviceCode')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "sendTsdMessage", null);
__decorate([
    (0, common_1.Post)('tsd-workloads/release'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "releaseTsdWorkload", null);
__decorate([
    (0, common_1.Post)('tsd-workloads/disconnect-request'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "disconnectTsdRequest", null);
__decorate([
    (0, common_1.Get)('phantom-stocks'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "phantomStocks", null);
__decorate([
    (0, common_1.Post)('phantom-stocks/fix-all'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "fixAllPhantomStocks", null);
__decorate([
    (0, common_1.Post)('phantom-stocks/:balanceId/fix'),
    __param(0, (0, common_1.Param)('balanceId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "fixPhantomStock", null);
__decorate([
    (0, common_1.Post)('stocks/compare-file'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('warehouseId')),
    __param(3, (0, common_1.Query)('connectionId')),
    __param(4, (0, common_1.Query)('marketplaceWarehouseId')),
    __param(5, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "compareStockFile", null);
__decorate([
    (0, common_1.Post)('stocks/compare-wb'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "compareStockFromWb", null);
__decorate([
    (0, common_1.Get)('audit'),
    __param(0, (0, common_1.Query)('search')),
    __param(1, (0, common_1.Query)('take')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "audit", null);
__decorate([
    (0, common_1.Post)('assistant/preview'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "assistantPreview", null);
__decorate([
    (0, common_1.Post)('assistant/apply'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "assistantApply", null);
__decorate([
    (0, common_1.Get)('documentation'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AdministrationController.prototype, "documentation", null);
exports.AdministrationController = AdministrationController = __decorate([
    (0, swagger_1.ApiTags)('administration'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('system:admin', 'administration:demo'),
    (0, common_1.Controller)('administration'),
    __metadata("design:paramtypes", [administration_service_1.AdministrationService,
        administration_technical_work_service_1.AdministrationTechnicalWorkService,
        phantom_stock_service_1.PhantomStockService,
        administration_internal_api_service_1.AdministrationInternalApiService,
        administration_unpalleted_writeoff_service_1.AdministrationUnpalletedWriteoffService])
], AdministrationController);
