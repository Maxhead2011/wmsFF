"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoAssemblyController = void 0;
const common_1 = require("@nestjs/common");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const auto_assembly_service_1 = require("./auto-assembly.service");
let AutoAssemblyController = class AutoAssemblyController {
    service;
    constructor(service) {
        this.service = service;
    }
    list(clientId, user) { return this.service.list(clientId, user); }
    save(id, body, user) { return this.service.save(id, body, user); }
    preview(id, body, user) { return this.service.preview(id, body.config, user); }
    run(id, user) { return this.service.run(id, user); }
};
exports.AutoAssemblyController = AutoAssemblyController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AutoAssemblyController.prototype, "list", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AutoAssemblyController.prototype, "save", null);
__decorate([
    (0, common_1.Post)(':id/preview'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], AutoAssemblyController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(':id/run'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AutoAssemblyController.prototype, "run", null);
exports.AutoAssemblyController = AutoAssemblyController = __decorate([
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    (0, common_1.Controller)('administration/auto-assembly'),
    __metadata("design:paramtypes", [auto_assembly_service_1.AutoAssemblyService])
], AutoAssemblyController);
