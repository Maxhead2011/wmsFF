"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateIntegrationStockAdjustmentDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const client_1 = require("@prisma/client");
const class_validator_1 = require("class-validator");
class CreateIntegrationStockAdjustmentDto {
    skuId;
    barcode;
    // FIX: для клиента с бескоробным учетом код короба не передается.
    boxCode;
    countedQuantity;
    status;
    idempotencyKey;
    comment;
}
exports.CreateIntegrationStockAdjustmentDto = CreateIntegrationStockAdjustmentDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'UUID SKU. Передайте skuId или barcode.' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateIntegrationStockAdjustmentDto.prototype, "skuId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Штрихкод товара. Передайте skuId или barcode.' }),
    (0, class_validator_1.ValidateIf)((dto) => !dto.skuId),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], CreateIntegrationStockAdjustmentDto.prototype, "barcode", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Фактический короб WMS. Не передавайте для клиента с бескоробным учетом.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], CreateIntegrationStockAdjustmentDto.prototype, "boxCode", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ minimum: 0, maximum: 1_000_000 }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(1_000_000),
    __metadata("design:type", Number)
], CreateIntegrationStockAdjustmentDto.prototype, "countedQuantity", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ enum: client_1.StockStatus, default: client_1.StockStatus.AVAILABLE }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(client_1.StockStatus),
    __metadata("design:type", String)
], CreateIntegrationStockAdjustmentDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Уникальный ключ операции во внешней системе.' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(180),
    __metadata("design:type", String)
], CreateIntegrationStockAdjustmentDto.prototype, "idempotencyKey", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], CreateIntegrationStockAdjustmentDto.prototype, "comment", void 0);
