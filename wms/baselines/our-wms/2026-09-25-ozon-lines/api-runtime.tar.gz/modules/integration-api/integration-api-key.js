"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateWmsApiKey = generateWmsApiKey;
exports.hashWmsApiKey = hashWmsApiKey;
exports.parseWmsApiKey = parseWmsApiKey;
exports.safeApiKeyHashEquals = safeApiKeyHashEquals;
exports.normalizeIntegrationScopes = normalizeIntegrationScopes;
exports.normalizeAllowedIps = normalizeAllowedIps;
exports.integrationIdempotencyKey = integrationIdempotencyKey;
const node_crypto_1 = require("node:crypto");
const node_net_1 = require("node:net");
const common_1 = require("@nestjs/common");
const integration_api_constants_1 = require("./integration-api.constants");
const PREFIX_BYTES = 6;
const SECRET_BYTES = 32;
function generateWmsApiKey() {
    const keyPrefix = (0, node_crypto_1.randomBytes)(PREFIX_BYTES).toString('hex');
    const secret = (0, node_crypto_1.randomBytes)(SECRET_BYTES).toString('base64url');
    const rawKey = `${integration_api_constants_1.WMS_API_KEY_PREFIX}${keyPrefix}_${secret}`;
    return { rawKey, keyPrefix, keyHash: hashWmsApiKey(rawKey) };
}
function hashWmsApiKey(rawKey) {
    return (0, node_crypto_1.createHash)('sha256').update(rawKey, 'utf8').digest('hex');
}
function parseWmsApiKey(rawKey) {
    const match = /^wms_live_([a-f0-9]{12})_([A-Za-z0-9_-]{40,})$/.exec(rawKey.trim());
    if (!match)
        return null;
    return { keyPrefix: match[1], rawKey: rawKey.trim() };
}
function safeApiKeyHashEquals(storedHash, rawKey) {
    const actual = Buffer.from(hashWmsApiKey(rawKey), 'hex');
    const expected = Buffer.from(storedHash, 'hex');
    return actual.length === expected.length && (0, node_crypto_1.timingSafeEqual)(actual, expected);
}
function normalizeIntegrationScopes(values) {
    const allowed = new Set(integration_api_constants_1.WMS_INTEGRATION_SCOPES);
    const normalized = [...new Set(values.map((value) => value.trim()).filter(Boolean))];
    const unsupported = normalized.filter((value) => !allowed.has(value));
    if (unsupported.length) {
        throw new common_1.BadRequestException(`Неизвестные права API: ${unsupported.join(', ')}.`);
    }
    if (!normalized.length) {
        throw new common_1.BadRequestException('Выберите хотя бы одно право API.');
    }
    return normalized;
}
function normalizeAllowedIps(values) {
    if (!values?.length)
        return [];
    const normalized = [...new Set(values.map((value) => value.trim()).filter(Boolean))];
    for (const value of normalized) {
        if ((0, node_net_1.isIP)(value) === 0) {
            throw new common_1.BadRequestException(`Некорректный IP-адрес: ${value}.`);
        }
    }
    return normalized;
}
function integrationIdempotencyKey(keyPrefix, value) {
    const normalized = value?.trim();
    return normalized
        ? `CLIENT_API:${keyPrefix}:${normalized}`
        : `CLIENT_API:${keyPrefix}:${(0, node_crypto_1.randomUUID)()}`;
}
