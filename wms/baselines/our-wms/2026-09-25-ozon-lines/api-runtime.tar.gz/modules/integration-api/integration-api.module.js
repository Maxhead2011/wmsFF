"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationApiModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const stock_module_1 = require("../stock/stock.module");
const integration_access_controller_1 = require("./integration-access.controller");
const integration_access_service_1 = require("./integration-access.service");
const integration_api_controller_1 = require("./integration-api.controller");
const integration_api_guard_1 = require("./integration-api.guard");
const integration_api_service_1 = require("./integration-api.service");
let IntegrationApiModule = class IntegrationApiModule {
};
exports.IntegrationApiModule = IntegrationApiModule;
exports.IntegrationApiModule = IntegrationApiModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, stock_module_1.StockModule],
        controllers: [integration_access_controller_1.IntegrationAccessController, integration_api_controller_1.IntegrationApiController],
        providers: [integration_access_service_1.IntegrationAccessService, integration_api_guard_1.IntegrationApiGuard, integration_api_service_1.IntegrationApiService],
    })
], IntegrationApiModule);
