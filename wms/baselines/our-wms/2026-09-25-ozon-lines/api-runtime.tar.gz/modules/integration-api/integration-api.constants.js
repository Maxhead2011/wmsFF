"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WMS_API_KEY_PREFIX = exports.WMS_API_KEY_HEADER = exports.WMS_INTEGRATION_SCOPE_LABELS = exports.WMS_INTEGRATION_SCOPES = void 0;
// ADDED: public scopes are deliberately small and additive; credentials never inherit WMS user rights.
exports.WMS_INTEGRATION_SCOPES = [
    'catalog:read',
    'stock:read',
    'stock:write',
    'requests:read',
    'movements:read',
];
exports.WMS_INTEGRATION_SCOPE_LABELS = {
    'catalog:read': 'Чтение справочника товаров',
    'stock:read': 'Чтение остатков',
    'stock:write': 'Корректировка фактического остатка',
    'requests:read': 'Чтение заявок',
    'movements:read': 'Чтение движений товара',
};
exports.WMS_API_KEY_HEADER = 'x-wms-api-key';
exports.WMS_API_KEY_PREFIX = 'wms_live_';
