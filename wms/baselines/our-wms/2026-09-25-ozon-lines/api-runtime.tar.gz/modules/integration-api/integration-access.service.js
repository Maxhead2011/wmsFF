"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationAccessService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const integration_api_constants_1 = require("./integration-api.constants");
const integration_api_key_1 = require("./integration-api-key");
let IntegrationAccessService = class IntegrationAccessService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    scopes() {
        return integration_api_constants_1.WMS_INTEGRATION_SCOPES.map((code) => ({ code, name: integration_api_constants_1.WMS_INTEGRATION_SCOPE_LABELS[code] }));
    }
    async options(user) {
        const global = user.permissionCodes.includes('system:admin') || user.clientScopeMode === 'ALL';
        // FIX: the dedicated role authorizes key management without granting general client editing rights.
        const clientIds = global ? undefined : user.clientIds;
        const clients = await this.prisma.client.findMany({
            where: { status: 'ACTIVE', ...(clientIds ? { id: { in: clientIds } } : {}) },
            select: { id: true, code: true, name: true },
            orderBy: { name: 'asc' },
        });
        const allowedClientIds = clients.map((client) => client.id);
        const warehouseIds = !global && !user.roleCodes.includes('CLIENT') ? user.writableWarehouseIds ?? [] : undefined;
        const links = await this.prisma.warehouseClient.findMany({
            where: {
                status: 'ACTIVE',
                clientId: { in: allowedClientIds },
                warehouse: { isActive: true, ...(warehouseIds ? { id: { in: warehouseIds } } : {}) },
            },
            select: {
                clientId: true,
                warehouse: { select: { id: true, code: true, name: true, city: true } },
            },
            orderBy: { warehouse: { sortOrder: 'asc' } },
        });
        return { clients, warehouses: links.map((link) => ({ clientId: link.clientId, ...link.warehouse })) };
    }
    async list(user) {
        const clientFilter = this.clientScopes.resolveClientFilter(user);
        const credentials = await this.prisma.wmsApiCredential.findMany({
            where: { clientId: clientFilter },
            select: {
                id: true,
                name: true,
                clientId: true,
                warehouseId: true,
                keyPrefix: true,
                scopes: true,
                allowedIps: true,
                expiresAt: true,
                revokedAt: true,
                lastUsedAt: true,
                lastUsedIp: true,
                createdAt: true,
                client: { select: { code: true, name: true } },
                warehouse: { select: { code: true, name: true, city: true } },
                createdBy: { select: { id: true, name: true, email: true } },
            },
            orderBy: { createdAt: 'desc' },
        });
        return credentials.map((credential) => ({
            ...credential,
            scopes: jsonStringArray(credential.scopes),
            allowedIps: jsonStringArray(credential.allowedIps),
        }));
    }
    async create(dto, user) {
        await this.requireCredentialTarget(user, dto.clientId, dto.warehouseId);
        const material = (0, integration_api_key_1.generateWmsApiKey)();
        const scopes = (0, integration_api_key_1.normalizeIntegrationScopes)(dto.scopes);
        const allowedIps = (0, integration_api_key_1.normalizeAllowedIps)(dto.allowedIps);
        const expiresAt = parseFutureExpiry(dto.expiresAt);
        const saved = await this.prisma.wmsApiCredential.create({
            data: {
                name: dto.name.trim(),
                clientId: dto.clientId,
                warehouseId: dto.warehouseId,
                keyPrefix: material.keyPrefix,
                keyHash: material.keyHash,
                scopes: scopes,
                allowedIps: allowedIps,
                expiresAt,
                createdByUserId: user.id,
            },
            select: { id: true, name: true, clientId: true, warehouseId: true, keyPrefix: true, createdAt: true },
        });
        await this.audit(user, 'wms_api.credential.created', saved.id, {
            clientId: dto.clientId,
            warehouseId: dto.warehouseId,
            keyPrefix: material.keyPrefix,
            scopes,
            allowedIps,
            expiresAt,
        });
        // FIX: the raw secret is returned exactly once and is never persisted.
        return { credential: saved, apiKey: material.rawKey, shownOnce: true };
    }
    async rotate(id, user) {
        const credential = await this.requireCredential(id, user);
        const material = (0, integration_api_key_1.generateWmsApiKey)();
        const updated = await this.prisma.wmsApiCredential.update({
            where: { id },
            data: { keyPrefix: material.keyPrefix, keyHash: material.keyHash, revokedAt: null },
            select: { id: true, name: true, clientId: true, warehouseId: true, keyPrefix: true, updatedAt: true },
        });
        await this.audit(user, 'wms_api.credential.rotated', id, {
            previousKeyPrefix: credential.keyPrefix,
            keyPrefix: material.keyPrefix,
        });
        return { credential: updated, apiKey: material.rawKey, shownOnce: true };
    }
    async revoke(id, user) {
        await this.requireCredential(id, user);
        const revokedAt = new Date();
        const credential = await this.prisma.wmsApiCredential.update({
            where: { id },
            data: { revokedAt },
            select: { id: true, name: true, keyPrefix: true, revokedAt: true },
        });
        await this.audit(user, 'wms_api.credential.revoked', id, { revokedAt });
        return credential;
    }
    async requireCredential(id, user) {
        const credential = await this.prisma.wmsApiCredential.findUnique({ where: { id } });
        if (!credential)
            throw new common_1.NotFoundException('API-доступ не найден.');
        await this.requireCredentialTarget(user, credential.clientId, credential.warehouseId);
        return credential;
    }
    async requireCredentialTarget(user, clientId, warehouseId) {
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const isGlobal = user.permissionCodes.includes('system:admin');
        if (!isGlobal && !user.roleCodes.includes('CLIENT') && !user.writableWarehouseIds?.includes(warehouseId)) {
            throw new common_1.ForbiddenException('Нет права создавать API-доступ для этого филиала.');
        }
        const link = await this.prisma.warehouseClient.findUnique({
            where: { warehouseId_clientId: { warehouseId, clientId } },
            include: { warehouse: { select: { isActive: true } } },
        });
        if (!link || link.status !== 'ACTIVE' || !link.warehouse.isActive) {
            throw new common_1.BadRequestException('Клиент не активирован на выбранном складе.');
        }
    }
    audit(user, action, entityId, payload) {
        return this.prisma.auditLog.create({
            data: { userId: user.id, action, entity: 'WmsApiCredential', entityId, payload },
        });
    }
};
exports.IntegrationAccessService = IntegrationAccessService;
exports.IntegrationAccessService = IntegrationAccessService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], IntegrationAccessService);
function parseFutureExpiry(value) {
    if (!value)
        return null;
    const parsed = new Date(value);
    if (parsed.getTime() <= Date.now()) {
        throw new common_1.BadRequestException('Срок действия API-ключа должен быть в будущем.');
    }
    return parsed;
}
function jsonStringArray(value) {
    return Array.isArray(value) ? value.filter((item) => typeof item === 'string') : [];
}
