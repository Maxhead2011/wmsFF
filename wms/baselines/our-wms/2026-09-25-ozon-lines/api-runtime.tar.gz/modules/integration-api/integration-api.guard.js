"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationApiGuard = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const integration_api_constants_1 = require("./integration-api.constants");
const integration_api_key_1 = require("./integration-api-key");
let IntegrationApiGuard = class IntegrationApiGuard {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const rawKey = extractApiKey(request.headers);
        const parsed = rawKey ? (0, integration_api_key_1.parseWmsApiKey)(rawKey) : null;
        if (!parsed) {
            throw new common_1.UnauthorizedException('Передайте действующий API-ключ в заголовке X-WMS-API-Key.');
        }
        const credential = await this.prisma.wmsApiCredential.findUnique({
            where: { keyPrefix: parsed.keyPrefix },
            include: {
                client: { select: { status: true } },
                warehouse: { select: { isActive: true } },
            },
        });
        if (!credential ||
            credential.revokedAt ||
            credential.client.status !== 'ACTIVE' ||
            !credential.warehouse.isActive ||
            (credential.expiresAt && credential.expiresAt.getTime() <= Date.now()) ||
            !(0, integration_api_key_1.safeApiKeyHashEquals)(credential.keyHash, parsed.rawKey)) {
            throw new common_1.UnauthorizedException('API-ключ недействителен, отозван или истёк.');
        }
        const warehouseLink = await this.prisma.warehouseClient.findUnique({
            where: {
                warehouseId_clientId: {
                    warehouseId: credential.warehouseId,
                    clientId: credential.clientId,
                },
            },
            select: { status: true },
        });
        if (warehouseLink?.status !== 'ACTIVE') {
            throw new common_1.UnauthorizedException('Доступ клиента к складу отключён.');
        }
        const clientIp = resolveClientIp(request);
        const allowedIps = jsonStringArray(credential.allowedIps);
        if (allowedIps.length && (!clientIp || !allowedIps.includes(clientIp))) {
            throw new common_1.UnauthorizedException('IP-адрес не входит в белый список этого API-ключа.');
        }
        request.integration = {
            credential,
            scopes: jsonStringArray(credential.scopes),
            clientIp,
        };
        // FIX: usage telemetry never blocks the business request if only the timestamp update fails.
        void this.prisma.wmsApiCredential
            .update({
            where: { id: credential.id },
            data: { lastUsedAt: new Date(), lastUsedIp: clientIp },
        })
            .catch(() => undefined);
        return true;
    }
};
exports.IntegrationApiGuard = IntegrationApiGuard;
exports.IntegrationApiGuard = IntegrationApiGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], IntegrationApiGuard);
function extractApiKey(headers) {
    const explicit = firstHeader(headers[integration_api_constants_1.WMS_API_KEY_HEADER]);
    if (explicit)
        return explicit.trim();
    const authorization = firstHeader(headers.authorization)?.trim() ?? '';
    return /^ApiKey\s+/i.test(authorization) ? authorization.replace(/^ApiKey\s+/i, '').trim() : null;
}
function firstHeader(value) {
    return Array.isArray(value) ? value[0] : value;
}
function jsonStringArray(value) {
    return Array.isArray(value) ? value.filter((item) => typeof item === 'string') : [];
}
function resolveClientIp(request) {
    const direct = normalizeIp(request.ip);
    const forwarded = normalizeIp(firstHeader(request.headers['x-real-ip'])) ??
        normalizeIp(firstHeader(request.headers['x-forwarded-for'])?.split(',')[0]);
    return direct && isTrustedProxy(direct) ? forwarded ?? direct : direct ?? forwarded;
}
function normalizeIp(value) {
    const normalized = value?.trim().replace(/^::ffff:/, '');
    return normalized || null;
}
function isTrustedProxy(ip) {
    if (ip === '127.0.0.1' || ip === '::1' || ip.startsWith('10.') || ip.startsWith('192.168.'))
        return true;
    if (!ip.startsWith('172.'))
        return false;
    const secondOctet = Number(ip.split('.')[1]);
    return secondOctet >= 16 && secondOctet <= 31;
}
