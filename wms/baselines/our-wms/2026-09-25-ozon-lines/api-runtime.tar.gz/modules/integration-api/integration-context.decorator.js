"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationContext = void 0;
const common_1 = require("@nestjs/common");
exports.IntegrationContext = (0, common_1.createParamDecorator)((_data, context) => context.switchToHttp().getRequest().integration);
