"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationApiService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const administration_unpalleted_writeoff_service_1 = require("../administration/administration-unpalleted-writeoff.service");
const stock_operations_service_1 = require("../stock/stock-operations.service");
const integration_api_key_1 = require("./integration-api-key");
let IntegrationApiService = class IntegrationApiService {
    prisma;
    stockOperations;
    constructor(prisma, stockOperations) {
        this.prisma = prisma;
        this.stockOperations = stockOperations;
    }
    async profile(context) {
        const data = await this.prisma.wmsApiCredential.findUniqueOrThrow({
            where: { id: context.credential.id },
            select: {
                id: true,
                name: true,
                keyPrefix: true,
                scopes: true,
                expiresAt: true,
                client: { select: { id: true, code: true, name: true } },
                warehouse: { select: { id: true, code: true, name: true, city: true } },
            },
        });
        return { data };
    }
    async catalog(context, query) {
        this.requireScope(context, 'catalog:read');
        const rows = await this.prisma.sku.findMany({
            where: {
                clientId: context.credential.clientId,
                ...(query.updatedSince ? { updatedAt: { gt: new Date(query.updatedSince) } } : {}),
            },
            include: { barcodes: { select: { value: true, isPrimary: true } } },
            orderBy: { id: 'asc' },
            ...page(query, 200),
        });
        return envelope(rows, query.limit ?? 200);
    }
    async stocks(context, query) {
        this.requireScope(context, 'stock:read');
        const rows = await this.prisma.stockBalance.findMany({
            where: {
                clientId: context.credential.clientId,
                warehouseId: context.credential.warehouseId,
                // FIX: this exact client's API stock is authoritative only for boxes placed on pallet-sorts.
                ...(context.credential.clientId === administration_unpalleted_writeoff_service_1.UNPALLETED_WRITEOFF_TARGET_CLIENT_ID
                    ? { AND: [(0, administration_unpalleted_writeoff_service_1.targetClientPlacedBalanceVisibility)()] }
                    : {}),
                ...(query.status ? { status: query.status } : {}),
                ...(query.updatedSince ? { updatedAt: { gt: new Date(query.updatedSince) } } : {}),
                ...(query.barcode ? { sku: { barcodes: { some: { value: query.barcode } } } } : {}),
            },
            select: {
                id: true,
                skuId: true,
                boxId: true,
                palletId: true,
                status: true,
                quantity: true,
                updatedAt: true,
                sku: {
                    select: {
                        internalSku: true,
                        clientSku: true,
                        article: true,
                        name: true,
                        barcodes: { select: { value: true, isPrimary: true } },
                    },
                },
                box: { select: { code: true } },
                pallet: { select: { code: true } },
            },
            orderBy: { id: 'asc' },
            ...page(query, 500),
        });
        return envelope(rows, query.limit ?? 500);
    }
    async requests(context, query) {
        this.requireScope(context, 'requests:read');
        const rows = await this.prisma.clientRequest.findMany({
            where: {
                clientId: context.credential.clientId,
                warehouseId: context.credential.warehouseId,
                ...(query.status ? { status: query.status } : {}),
                ...(query.updatedSince ? { updatedAt: { gt: new Date(query.updatedSince) } } : {}),
            },
            select: {
                id: true,
                number: true,
                type: true,
                status: true,
                priority: true,
                title: true,
                comment: true,
                desiredDate: true,
                createdAt: true,
                updatedAt: true,
                items: {
                    select: { id: true, skuId: true, barcode: true, name: true, quantity: true, comment: true },
                },
            },
            orderBy: { id: 'asc' },
            ...page(query, 200),
        });
        return envelope(rows, query.limit ?? 200);
    }
    async movements(context, query) {
        this.requireScope(context, 'movements:read');
        const rows = await this.prisma.stockMovement.findMany({
            where: {
                clientId: context.credential.clientId,
                warehouseId: context.credential.warehouseId,
                // FIX: the client API does not expose the internal administrator-only cleanup action.
                ...(0, administration_unpalleted_writeoff_service_1.excludeAdminUnpalletedWriteoffMovement)(),
                ...(query.updatedSince ? { createdAt: { gt: new Date(query.updatedSince) } } : {}),
            },
            select: {
                id: true,
                skuId: true,
                boxId: true,
                palletId: true,
                type: true,
                status: true,
                quantity: true,
                sourceDocument: true,
                idempotencyKey: true,
                comment: true,
                createdAt: true,
                sku: { select: { internalSku: true, article: true, name: true } },
                box: { select: { code: true } },
            },
            orderBy: { id: 'asc' },
            ...page(query, 200),
        });
        return envelope(rows, query.limit ?? 200);
    }
    async adjustStock(context, dto) {
        this.requireScope(context, 'stock:write');
        if (dto.status && dto.status !== client_1.StockStatus.AVAILABLE) {
            throw new common_1.ForbiddenException('Внешний API может корректировать только доступный остаток AVAILABLE.');
        }
        // FIX: the external id is namespaced by credential, preventing cross-client ledger collisions.
        const idempotencyKey = (0, integration_api_key_1.integrationIdempotencyKey)(context.credential.keyPrefix, dto.idempotencyKey);
        const user = integrationStockUser(context);
        const result = await this.stockOperations.adjustInventoryToCounted({
            clientId: context.credential.clientId,
            skuId: dto.skuId,
            barcode: dto.barcode?.trim(),
            // FIX: бескоробный клиент меняет остаток без вымышленного boxCode.
            boxCode: dto.boxCode?.trim() || undefined,
            countedQuantity: dto.countedQuantity,
            status: client_1.StockStatus.AVAILABLE,
            idempotencyKey,
            comment: `[CLIENT_API:${context.credential.keyPrefix}] ${dto.comment?.trim() || 'Остаток изменён внешней системой клиента'}`,
        }, user);
        if (result.status === 'APPLIED') {
            await this.prisma.$transaction([
                this.prisma.auditLog.create({
                    data: {
                        action: 'wms_api.stock.adjusted',
                        entity: 'WmsApiCredential',
                        entityId: context.credential.id,
                        payload: {
                            clientId: context.credential.clientId,
                            warehouseId: context.credential.warehouseId,
                            keyPrefix: context.credential.keyPrefix,
                            clientIp: context.clientIp,
                            result,
                        },
                    },
                }),
                this.prisma.clientNotification.create({
                    data: {
                        clientId: context.credential.clientId,
                        title: 'Остаток изменён клиентом через API',
                        body: `${context.credential.name}: ${result.box ? `короб ${result.box}` : 'без короба'}, количество ${result.previousQuantity} → ${result.countedQuantity}.`,
                        severity: client_1.ClientNotificationSeverity.WARNING,
                    },
                }),
            ]);
        }
        return { data: result };
    }
    requireScope(context, scope) {
        if (!context.scopes.includes(scope)) {
            throw new common_1.ForbiddenException({ message: 'API-ключу не выдано требуемое право.', requiredScope: scope });
        }
    }
};
exports.IntegrationApiService = IntegrationApiService;
exports.IntegrationApiService = IntegrationApiService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        stock_operations_service_1.StockOperationsService])
], IntegrationApiService);
function page(query, fallback) {
    return {
        take: query.limit ?? fallback,
        ...(query.afterId ? { cursor: { id: query.afterId }, skip: 1 } : {}),
    };
}
function envelope(rows, limit) {
    return {
        data: rows,
        meta: {
            count: rows.length,
            limit,
            nextAfterId: rows.length === limit ? rows.at(-1)?.id ?? null : null,
            generatedAt: new Date().toISOString(),
        },
    };
}
function integrationStockUser(context) {
    return {
        id: `integration:${context.credential.id}`,
        email: `integration-${context.credential.keyPrefix}@wms.local`,
        name: context.credential.name,
        roleCodes: ['WMS_INTEGRATION'],
        permissionCodes: ['stock:write'],
        clientScopeMode: 'LIMITED',
        clientIds: [context.credential.clientId],
        writableClientIds: [context.credential.clientId],
        activeWarehouseId: context.credential.warehouseId,
        warehouseIds: [context.credential.warehouseId],
        writableWarehouseIds: [context.credential.warehouseId],
    };
}
