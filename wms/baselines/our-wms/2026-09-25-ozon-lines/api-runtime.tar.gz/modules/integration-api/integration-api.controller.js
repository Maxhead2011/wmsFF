"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationApiController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const public_decorator_1 = require("../auth/decorators/public.decorator");
const create_stock_adjustment_dto_1 = require("./dto/create-stock-adjustment.dto");
const list_integration_data_dto_1 = require("./dto/list-integration-data.dto");
const integration_context_decorator_1 = require("./integration-context.decorator");
const integration_api_guard_1 = require("./integration-api.guard");
const integration_api_service_1 = require("./integration-api.service");
const integration_api_swagger_1 = require("./integration-api.swagger");
let IntegrationApiController = class IntegrationApiController {
    service;
    constructor(service) {
        this.service = service;
    }
    profile(context) {
        return this.service.profile(context);
    }
    catalog(context, query) {
        return this.service.catalog(context, query);
    }
    stocks(context, query) {
        return this.service.stocks(context, query);
    }
    adjustStock(context, dto) {
        return this.service.adjustStock(context, dto);
    }
    requests(context, query) {
        return this.service.requests(context, query);
    }
    movements(context, query) {
        return this.service.movements(context, query);
    }
};
exports.IntegrationApiController = IntegrationApiController;
__decorate([
    (0, common_1.Get)('profile'),
    (0, swagger_1.ApiOperation)({ summary: 'Проверить ключ и получить закреплённые клиента и склад' }),
    (0, swagger_1.ApiOkResponse)({ schema: integration_api_swagger_1.integrationProfileSchema }),
    __param(0, (0, integration_context_decorator_1.IntegrationContext)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], IntegrationApiController.prototype, "profile", null);
__decorate([
    (0, common_1.Get)('catalog'),
    (0, swagger_1.ApiOperation)({ summary: 'Справочник товаров клиента' }),
    (0, swagger_1.ApiOkResponse)({ schema: integration_api_swagger_1.integrationCatalogSchema }),
    __param(0, (0, integration_context_decorator_1.IntegrationContext)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, list_integration_data_dto_1.ListIntegrationDataDto]),
    __metadata("design:returntype", void 0)
], IntegrationApiController.prototype, "catalog", null);
__decorate([
    (0, common_1.Get)('stocks'),
    (0, swagger_1.ApiOperation)({ summary: 'Остатки закреплённого клиента на закреплённом складе' }),
    (0, swagger_1.ApiOkResponse)({ schema: integration_api_swagger_1.integrationStocksSchema }),
    __param(0, (0, integration_context_decorator_1.IntegrationContext)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, list_integration_data_dto_1.ListIntegrationStocksDto]),
    __metadata("design:returntype", void 0)
], IntegrationApiController.prototype, "stocks", null);
__decorate([
    (0, common_1.Post)('stock-adjustments'),
    (0, swagger_1.ApiOperation)({ summary: 'Установить фактический AVAILABLE-остаток через ledger WMS, с коробом или без него' }),
    (0, swagger_1.ApiOkResponse)({ schema: integration_api_swagger_1.integrationAdjustmentSchema }),
    __param(0, (0, integration_context_decorator_1.IntegrationContext)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, create_stock_adjustment_dto_1.CreateIntegrationStockAdjustmentDto]),
    __metadata("design:returntype", void 0)
], IntegrationApiController.prototype, "adjustStock", null);
__decorate([
    (0, common_1.Get)('requests'),
    (0, swagger_1.ApiOperation)({ summary: 'Заявки закреплённого клиента и склада' }),
    (0, swagger_1.ApiOkResponse)({ schema: integration_api_swagger_1.integrationRequestsSchema }),
    __param(0, (0, integration_context_decorator_1.IntegrationContext)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, list_integration_data_dto_1.ListIntegrationRequestsDto]),
    __metadata("design:returntype", void 0)
], IntegrationApiController.prototype, "requests", null);
__decorate([
    (0, common_1.Get)('movements'),
    (0, swagger_1.ApiOperation)({ summary: 'Ledger-движения товара закреплённого клиента и склада' }),
    (0, swagger_1.ApiOkResponse)({ schema: integration_api_swagger_1.integrationMovementsSchema }),
    __param(0, (0, integration_context_decorator_1.IntegrationContext)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, list_integration_data_dto_1.ListIntegrationDataDto]),
    __metadata("design:returntype", void 0)
], IntegrationApiController.prototype, "movements", null);
exports.IntegrationApiController = IntegrationApiController = __decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.UseGuards)(integration_api_guard_1.IntegrationApiGuard),
    (0, swagger_1.ApiSecurity)('WmsApiKey'),
    (0, swagger_1.ApiTags)('WMS Integration API v1'),
    (0, swagger_1.ApiUnauthorizedResponse)({ description: 'Ключ неверен, отозван, истёк или не разрешён для IP/склада.' }),
    (0, swagger_1.ApiForbiddenResponse)({ description: 'API-ключу не выдан требуемый scope.' }),
    (0, common_1.Controller)('integration/v1'),
    __metadata("design:paramtypes", [integration_api_service_1.IntegrationApiService])
], IntegrationApiController);
