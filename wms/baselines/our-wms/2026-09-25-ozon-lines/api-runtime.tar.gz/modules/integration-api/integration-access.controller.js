"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationAccessController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const create_integration_credential_dto_1 = require("./dto/create-integration-credential.dto");
const integration_access_service_1 = require("./integration-access.service");
let IntegrationAccessController = class IntegrationAccessController {
    service;
    constructor(service) {
        this.service = service;
    }
    scopes() {
        return this.service.scopes();
    }
    options(user) {
        return this.service.options(user);
    }
    list(user) {
        return this.service.list(user);
    }
    create(dto, user) {
        return this.service.create(dto, user);
    }
    rotate(id, user) {
        return this.service.rotate(id, user);
    }
    revoke(id, user) {
        return this.service.revoke(id, user);
    }
};
exports.IntegrationAccessController = IntegrationAccessController;
__decorate([
    (0, common_1.Get)('scopes'),
    (0, swagger_1.ApiOperation)({ summary: 'Доступные права внешнего API' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], IntegrationAccessController.prototype, "scopes", null);
__decorate([
    (0, common_1.Get)('options'),
    (0, swagger_1.ApiOperation)({ summary: 'Доступные клиенту склады для выпуска ключа' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], IntegrationAccessController.prototype, "options", null);
__decorate([
    (0, common_1.Get)('credentials'),
    (0, swagger_1.ApiOperation)({ summary: 'Список ключей без секретной части' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], IntegrationAccessController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('credentials'),
    (0, swagger_1.ApiOperation)({ summary: 'Создать API-ключ; секрет возвращается один раз' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_integration_credential_dto_1.CreateIntegrationCredentialDto, Object]),
    __metadata("design:returntype", void 0)
], IntegrationAccessController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('credentials/:id/rotate'),
    (0, swagger_1.ApiOperation)({ summary: 'Заменить ключ и немедленно отключить старый' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], IntegrationAccessController.prototype, "rotate", null);
__decorate([
    (0, common_1.Post)('credentials/:id/revoke'),
    (0, swagger_1.ApiOperation)({ summary: 'Отозвать API-ключ' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], IntegrationAccessController.prototype, "revoke", null);
exports.IntegrationAccessController = IntegrationAccessController = __decorate([
    (0, swagger_1.ApiTags)('integration-access'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, require_permissions_decorator_1.RequirePermissions)('integration-api:manage'),
    (0, common_1.Controller)('integration-access'),
    __metadata("design:paramtypes", [integration_access_service_1.IntegrationAccessService])
], IntegrationAccessController);
