"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelTemplateService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
let LabelTemplateService = class LabelTemplateService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    listTemplates(filter) {
        return this.prisma.labelTemplate.findMany({
            where: {
                type: filter.type,
            },
            orderBy: [{ isActive: 'desc' }, { updatedAt: 'desc' }],
        });
    }
    async createTemplate(dto) {
        const code = dto.code.trim().toUpperCase();
        const tspl = dto.tspl.trim();
        assertRenderableTspl(tspl);
        return this.prisma.$transaction(async (tx) => {
            const template = await tx.labelTemplate.create({
                data: {
                    code,
                    name: dto.name.trim(),
                    type: dto.type,
                    description: dto.description?.trim() || null,
                    widthMm: dto.widthMm ?? 80,
                    heightMm: dto.heightMm ?? 50,
                    tspl,
                    version: 1,
                    isActive: dto.isActive ?? true,
                },
            });
            await tx.labelTemplateVersion.create({
                data: templateVersionSnapshot(template, 'Создание шаблона'),
            });
            return template;
        });
    }
    async updateTemplate(templateId, dto) {
        if (!hasTemplatePatch(dto)) {
            throw new common_1.BadRequestException('Нет изменений для новой версии шаблона.');
        }
        return this.prisma.$transaction(async (tx) => {
            const current = await tx.labelTemplate.findUnique({
                where: { id: templateId },
            });
            if (!current) {
                throw new common_1.NotFoundException('Шаблон этикетки не найден.');
            }
            const existingVersionCount = await tx.labelTemplateVersion.count({
                where: { templateId },
            });
            if (existingVersionCount === 0) {
                await tx.labelTemplateVersion.create({
                    data: templateVersionSnapshot(current, 'Базовая версия перед обновлением'),
                });
            }
            const updated = await tx.labelTemplate.update({
                where: { id: templateId },
                data: {
                    ...templatePatchData(dto),
                    version: { increment: 1 },
                },
            });
            await tx.labelTemplateVersion.create({
                data: templateVersionSnapshot(updated, dto.changeReason),
            });
            return updated;
        });
    }
    async listTemplateVersions(templateId) {
        const template = await this.getTemplateOrThrow(templateId);
        const versions = await this.prisma.labelTemplateVersion.findMany({
            where: { templateId },
            orderBy: { version: 'desc' },
        });
        if (versions.length > 0) {
            return versions;
        }
        // Русский комментарий: старые шаблоны могли появиться до таблицы версий, поэтому показываем текущий снимок.
        return [
            {
                id: `${template.id}-v${template.version}`,
                templateId: template.id,
                version: template.version,
                code: template.code,
                name: template.name,
                type: template.type,
                description: template.description,
                widthMm: template.widthMm,
                heightMm: template.heightMm,
                tspl: template.tspl,
                isActive: template.isActive,
                changeReason: 'Текущая версия без отдельного снимка',
                createdAt: template.updatedAt,
            },
        ];
    }
    async previewTemplate(templateId, dto) {
        const template = await this.getTemplateOrThrow(templateId);
        return {
            printerLanguage: 'TSPL',
            tspl: this.renderTspl(template.tspl, dto.variables ?? {}),
            templateId: template.id,
            templateCode: template.code,
            templateVersion: template.version,
        };
    }
    async getTemplateOrThrow(templateId) {
        const template = await this.prisma.labelTemplate.findUnique({
            where: { id: templateId },
        });
        if (!template) {
            throw new common_1.NotFoundException('Шаблон этикетки не найден.');
        }
        return template;
    }
    renderTspl(tspl, variables) {
        assertRenderableTspl(tspl);
        const placeholders = extractPlaceholders(tspl);
        const missingVariables = placeholders.filter((name) => variables[name] == null);
        if (missingVariables.length > 0) {
            throw new common_1.BadRequestException(`Не заполнены переменные шаблона: ${missingVariables.join(', ')}`);
        }
        // Русский комментарий: подставляем только значения переменных, сами TSPL-команды остаются в сохраненном шаблоне.
        return tspl.replace(/{{\s*([A-Za-z0-9_.-]+)\s*}}/g, (_match, name) => sanitizeTemplateValue(variables[name]));
    }
};
exports.LabelTemplateService = LabelTemplateService;
exports.LabelTemplateService = LabelTemplateService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], LabelTemplateService);
function hasTemplatePatch(dto) {
    return (dto.code !== undefined ||
        dto.name !== undefined ||
        dto.type !== undefined ||
        dto.description !== undefined ||
        dto.widthMm !== undefined ||
        dto.heightMm !== undefined ||
        dto.tspl !== undefined ||
        dto.isActive !== undefined);
}
function templatePatchData(dto) {
    const data = {};
    if (dto.code !== undefined) {
        data.code = dto.code.trim().toUpperCase();
    }
    if (dto.name !== undefined) {
        data.name = dto.name.trim();
    }
    if (dto.type !== undefined) {
        data.type = dto.type;
    }
    if (dto.description !== undefined) {
        data.description = dto.description.trim() || null;
    }
    if (dto.widthMm !== undefined) {
        data.widthMm = dto.widthMm;
    }
    if (dto.heightMm !== undefined) {
        data.heightMm = dto.heightMm;
    }
    if (dto.tspl !== undefined) {
        const tspl = dto.tspl.trim();
        assertRenderableTspl(tspl);
        data.tspl = tspl;
    }
    if (dto.isActive !== undefined) {
        data.isActive = dto.isActive;
    }
    return data;
}
function templateVersionSnapshot(template, reason) {
    return {
        templateId: template.id,
        version: template.version,
        code: template.code,
        name: template.name,
        type: template.type,
        description: template.description,
        widthMm: template.widthMm,
        heightMm: template.heightMm,
        tspl: template.tspl,
        isActive: template.isActive,
        changeReason: reason?.trim() || null,
    };
}
function extractPlaceholders(tspl) {
    return Array.from(tspl.matchAll(/{{\s*([A-Za-z0-9_.-]+)\s*}}/g), (match) => match[1]).filter((name, index, list) => list.indexOf(name) === index);
}
function sanitizeTemplateValue(value) {
    return String(value ?? '')
        .replace(/["\r\n\t]/g, ' ')
        .replace(/[\u0000-\u001f\u007f]/g, '')
        .trim();
}
function assertRenderableTspl(tspl) {
    if (!tspl.trim()) {
        throw new common_1.BadRequestException('TSPL шаблон не может быть пустым.');
    }
    const rawPlaceholders = tspl.match(/{{[^{}]*}}/g) ?? [];
    const invalidPlaceholders = rawPlaceholders.filter((placeholder) => {
        const name = placeholder.replace(/^{{\s*/, '').replace(/\s*}}$/, '');
        return !/^[A-Za-z0-9_.-]+$/.test(name);
    });
    const templateWithoutValidPlaceholders = tspl.replace(/{{\s*[A-Za-z0-9_.-]+\s*}}/g, '');
    if (invalidPlaceholders.length > 0 ||
        templateWithoutValidPlaceholders.includes('{{') ||
        templateWithoutValidPlaceholders.includes('}}')) {
        throw new common_1.BadRequestException('Шаблон содержит некорректные переменные. Используйте формат {{variableName}}.');
    }
}
