"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PrintQueueWorkerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintQueueWorkerService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const node_net_1 = require("node:net");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const printer_scope_service_1 = require("../auth/printer-scope.service");
let PrintQueueWorkerService = PrintQueueWorkerService_1 = class PrintQueueWorkerService {
    prisma;
    config;
    printerScopes;
    logger = new common_1.Logger(PrintQueueWorkerService_1.name);
    timer = null;
    isProcessing = false;
    constructor(prisma, config, printerScopes) {
        this.prisma = prisma;
        this.config = config;
        this.printerScopes = printerScopes;
    }
    onModuleInit() {
        if (this.config.get('PRINT_WORKER_DISABLED') === 'true') {
            return;
        }
        const intervalMs = this.config.get('PRINT_WORKER_INTERVAL_MS') ?? 5000;
        this.timer = setInterval(() => {
            void this.processQueued().catch((error) => {
                this.logger.error(error instanceof Error ? error.message : 'Print worker failed');
            });
        }, Math.max(intervalMs, 1000));
        if (typeof this.timer === 'object' && 'unref' in this.timer) {
            this.timer.unref();
        }
    }
    onModuleDestroy() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
    }
    async processQueued(limit = 20, user, groupCode) {
        if (this.isProcessing) {
            return { processed: 0, printed: 0, sent: 0, failed: 0, skipped: 1 };
        }
        this.isProcessing = true;
        try {
            const printers = await this.prisma.printPrinter.findMany({
                where: {
                    isActive: true,
                    autoProcess: true,
                    groupCode: user ? this.printerScopes.resolvePrinterGroupFilter(user, groupCode, 'manage') : undefined,
                },
            });
            if (user) {
                for (const printer of printers) {
                    this.printerScopes.requirePrinterGroupAccess(user, printer.groupCode, 'manage');
                }
            }
            const printerByCode = new Map(printers.map((printer) => [printer.code, printer]));
            if (printerByCode.size === 0) {
                return { processed: 0, printed: 0, sent: 0, failed: 0, skipped: 0 };
            }
            const jobs = await this.prisma.printJob.findMany({
                where: {
                    status: 'queued',
                    printerCode: { in: [...printerByCode.keys()] },
                },
                orderBy: { createdAt: 'asc' },
                take: limit,
            });
            const result = { processed: 0, printed: 0, sent: 0, failed: 0, skipped: 0 };
            for (const job of jobs) {
                const printer = printerByCode.get(job.printerCode);
                if (!printer) {
                    result.skipped += 1;
                    continue;
                }
                const outcome = await this.processJob(job, printer);
                if (outcome === 'skipped') {
                    result.skipped += 1;
                    continue;
                }
                result.processed += 1;
                result[outcome] += 1;
            }
            return result;
        }
        finally {
            this.isProcessing = false;
        }
    }
    async processJob(job, printer) {
        const claimed = await this.prisma.printJob.updateMany({
            where: { id: job.id, status: 'queued' },
            data: {
                status: 'sent',
                attempts: { increment: 1 },
                payload: mergePrintPayload(job.payload, {
                    sentAt: new Date().toISOString(),
                    printerCode: printer.code,
                    printerName: printer.name,
                }),
            },
        });
        if (claimed.count === 0) {
            return 'skipped';
        }
        try {
            const sentAt = new Date().toISOString();
            if (printer.connectionType === 'tcp') {
                await this.sendTcp(printer, job.tspl);
                await this.prisma.printPrinter.update({
                    where: { id: printer.id },
                    data: { lastSeenAt: new Date() },
                });
                await this.prisma.printJob.update({
                    where: { id: job.id },
                    data: {
                        status: 'sent',
                        processedAt: new Date(),
                        payload: mergePrintPayload(job.payload, {
                            sentAt,
                            printerCode: printer.code,
                            printerName: printer.name,
                            statusMessage: 'TSPL отправлен на TCP-принтер.',
                        }),
                    },
                });
                return 'sent';
            }
            await this.prisma.printPrinter.update({
                where: { id: printer.id },
                data: { lastSeenAt: new Date() },
            });
            await this.prisma.printJob.update({
                where: { id: job.id },
                data: {
                    status: 'printed',
                    processedAt: new Date(),
                    payload: mergePrintPayload(job.payload, {
                        sentAt,
                        printerCode: printer.code,
                        printerName: printer.name,
                        printedAt: new Date().toISOString(),
                        statusMessage: 'Dry-run printer: TSPL принят без физической отправки.',
                    }),
                },
            });
            return 'printed';
        }
        catch (caught) {
            const message = caught instanceof Error ? caught.message : 'Не удалось отправить TSPL на принтер.';
            await this.prisma.printJob.update({
                where: { id: job.id },
                data: {
                    status: 'failed',
                    processedAt: new Date(),
                    payload: mergePrintPayload(job.payload, { statusMessage: message }),
                },
            });
            return 'failed';
        }
    }
    sendTcp(printer, tspl) {
        const host = printer.host;
        const port = printer.port;
        if (!host || !port) {
            throw new Error('У TCP-принтера не заполнены host или port.');
        }
        return new Promise((resolve, reject) => {
            const socket = (0, node_net_1.createConnection)({ host, port, timeout: 5000 }, () => {
                socket.write(tspl, 'utf8', () => {
                    socket.end();
                });
            });
            socket.once('error', reject);
            socket.once('timeout', () => {
                socket.destroy();
                reject(new Error('Таймаут отправки TSPL на принтер.'));
            });
            socket.once('close', (hadError) => {
                if (!hadError) {
                    resolve();
                }
            });
        });
    }
};
exports.PrintQueueWorkerService = PrintQueueWorkerService;
exports.PrintQueueWorkerService = PrintQueueWorkerService = PrintQueueWorkerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService,
        printer_scope_service_1.PrinterScopeService])
], PrintQueueWorkerService);
function mergePrintPayload(payload, patch) {
    const currentPayload = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
    return {
        ...currentPayload,
        ...patch,
    };
}
