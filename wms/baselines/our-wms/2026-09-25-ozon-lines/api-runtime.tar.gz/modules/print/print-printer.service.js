"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintPrinterService = void 0;
exports.normalizePrinterCode = normalizePrinterCode;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const printer_scope_service_1 = require("../auth/printer-scope.service");
let PrintPrinterService = class PrintPrinterService {
    prisma;
    config;
    printerScopes;
    constructor(prisma, config, printerScopes) {
        this.prisma = prisma;
        this.config = config;
        this.printerScopes = printerScopes;
    }
    async onModuleInit() {
        await this.ensureDefaultPrinter();
    }
    listPrinters(user) {
        return this.prisma.printPrinter.findMany({
            where: user ? { groupCode: this.printerScopes.resolvePrinterGroupFilter(user) } : undefined,
            orderBy: [{ isActive: 'desc' }, { code: 'asc' }],
        });
    }
    async listPrinterGroups(user) {
        if (!this.printerScopes.hasGlobalPrinterAccess(user)) {
            return this.printerScopes.allowedGroups(user, 'print').map((groupCode) => ({ groupCode }));
        }
        const [printerGroups, scopedGroups] = await Promise.all([
            this.prisma.printPrinter.findMany({
                select: { groupCode: true },
                distinct: ['groupCode'],
                orderBy: { groupCode: 'asc' },
            }),
            this.prisma.userPrinterGroup.findMany({
                select: { groupCode: true },
                distinct: ['groupCode'],
                orderBy: { groupCode: 'asc' },
            }),
        ]);
        const groups = new Set([...printerGroups, ...scopedGroups].map((item) => (0, printer_scope_service_1.normalizePrinterGroupCode)(item.groupCode)));
        groups.add('DEFAULT');
        return [...groups].sort((left, right) => left.localeCompare(right)).map((groupCode) => ({ groupCode }));
    }
    async upsertPrinter(dto, user) {
        const code = normalizePrinterCode(dto.code);
        const connectionType = dto.connectionType ?? 'dry_run';
        this.assertConnectionSettings(connectionType, dto);
        const currentPrinter = await this.prisma.printPrinter.findUnique({
            where: { code },
            select: { groupCode: true },
        });
        const groupCode = (0, printer_scope_service_1.normalizePrinterGroupCode)(dto.groupCode ?? currentPrinter?.groupCode ?? 'DEFAULT');
        if (user) {
            if (currentPrinter) {
                this.printerScopes.requirePrinterGroupAccess(user, currentPrinter.groupCode, 'manage');
            }
            this.printerScopes.requirePrinterGroupAccess(user, groupCode, 'manage');
        }
        return this.prisma.printPrinter.upsert({
            where: { code },
            update: {
                groupCode,
                name: dto.name.trim(),
                connectionType,
                host: connectionType === 'tcp' ? dto.host?.trim() : null,
                port: connectionType === 'tcp' ? dto.port : null,
                isActive: dto.isActive ?? true,
                autoProcess: dto.autoProcess ?? true,
            },
            create: {
                code,
                groupCode,
                name: dto.name.trim(),
                connectionType,
                host: connectionType === 'tcp' ? dto.host?.trim() : null,
                port: connectionType === 'tcp' ? dto.port : null,
                isActive: dto.isActive ?? true,
                autoProcess: dto.autoProcess ?? true,
            },
        });
    }
    async getActivePrinterOrThrow(code) {
        const printer = await this.prisma.printPrinter.findUnique({
            where: { code: normalizePrinterCode(code) },
        });
        if (!printer || !printer.isActive) {
            throw new common_1.BadRequestException('Принтер не зарегистрирован или отключен.');
        }
        return printer;
    }
    async ensureDefaultPrinter() {
        const code = normalizePrinterCode(this.config.get('DEFAULT_PRINTER_CODE') ?? 'TSC-01');
        const name = this.config.get('DEFAULT_PRINTER_NAME') ?? 'TSC dry-run';
        // Русский комментарий: dry_run-принтер нужен для пилота и автотестов, пока не подключен реальный TCP-принтер.
        await this.prisma.printPrinter.upsert({
            where: { code },
            update: {},
            create: {
                code,
                groupCode: 'DEFAULT',
                name,
                connectionType: 'dry_run',
                isActive: true,
                autoProcess: true,
            },
        });
    }
    assertConnectionSettings(connectionType, dto) {
        if (connectionType !== 'tcp') {
            return;
        }
        if (!dto.host?.trim() || !dto.port) {
            throw new common_1.BadRequestException('Для TCP-принтера нужны host и port.');
        }
    }
};
exports.PrintPrinterService = PrintPrinterService;
exports.PrintPrinterService = PrintPrinterService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        config_1.ConfigService,
        printer_scope_service_1.PrinterScopeService])
], PrintPrinterService);
function normalizePrinterCode(value) {
    const normalized = value.trim().toUpperCase();
    if (!normalized) {
        throw new common_1.BadRequestException('Код принтера обязателен.');
    }
    return normalized;
}
