"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const auth_module_1 = require("../auth/auth.module");
const label_template_service_1 = require("./label-template.service");
const print_job_service_1 = require("./print-job.service");
const print_agent_service_1 = require("./print-agent.service");
const print_printer_service_1 = require("./print-printer.service");
const print_queue_worker_service_1 = require("./print-queue-worker.service");
const print_controller_1 = require("./print.controller");
const tspl_label_service_1 = require("./tspl-label.service");
const kiz_duplicate_controller_1 = require("./kiz-duplicate.controller");
const kiz_duplicate_service_1 = require("./kiz-duplicate.service");
let PrintModule = class PrintModule {
};
exports.PrintModule = PrintModule;
exports.PrintModule = PrintModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, config_1.ConfigModule],
        controllers: [print_controller_1.PrintController, kiz_duplicate_controller_1.KizDuplicateController],
        providers: [label_template_service_1.LabelTemplateService, print_job_service_1.PrintJobService, print_agent_service_1.PrintAgentService, print_printer_service_1.PrintPrinterService, print_queue_worker_service_1.PrintQueueWorkerService, tspl_label_service_1.TsplLabelService, kiz_duplicate_service_1.KizDuplicateService],
        exports: [label_template_service_1.LabelTemplateService, print_job_service_1.PrintJobService, print_printer_service_1.PrintPrinterService, print_queue_worker_service_1.PrintQueueWorkerService, tspl_label_service_1.TsplLabelService],
    })
], PrintModule);
