"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildKizDuplicateLabel = buildKizDuplicateLabel;
const bwipjs = require("bwip-js");
const pdfMake = require("pdfmake");
const pdf_parse_1 = require("pdf-parse");
const pdfmake_1 = require("../../common/pdf/pdfmake");
const kiz_duplicate_code_1 = require("./kiz-duplicate-code");
const MM = 72 / 25.4;
async function buildKizDuplicateLabel(kiz, product) {
    (0, pdfmake_1.configurePdfMake)();
    const identity = (0, kiz_duplicate_code_1.parseDuplicateKiz)(kiz).identity;
    const svg = bwipjs.toSVG((0, kiz_duplicate_code_1.duplicateBarcodeOptions)(kiz));
    const clean = (s) => (s || '—').replace(/[\x00-\x1f]/g, ' ');
    const line = (text, x, y, width, fontSize, bold = false) => ({
        absolutePosition: { x: x * MM, y: y * MM }, columns: [{ width: width * MM, text, fontSize, bold, lineHeight: 1.05 }],
    });
    // FIX: fixed-size, single-label layout; long names are explicitly abbreviated.
    const shorten = (text, max) => text.length > max ? text.slice(0, max - 1) + '…' : text;
    const pdf = await pdfMake.createPdf({ pageSize: { width: 58 * MM, height: 40 * MM }, pageMargins: 0,
        defaultStyle: { font: 'DejaVuSans' }, content: [
            line(identity, 2, 1.5, 54, 5),
            { svg, width: 26 * MM, height: 26 * MM, absolutePosition: { x: 1.5 * MM, y: 6 * MM } },
            line(shorten(clean(product.name), 55), 29, 6, 27, 6, true),
            line(shorten(clean(product.article), 55), 29, 17, 27, 6, true),
            line('Цвет: ' + shorten(clean(product.color), 28), 29, 28, 27, 5.5),
            line('Размер: ' + shorten(clean(product.size), 20), 2, 34, 54, 8, true),
        ],
    }).getBuffer();
    const parser = new pdf_parse_1.PDFParse({ data: pdf });
    try {
        const result = await parser.getScreenshot({ desiredWidth: 696, imageDataUrl: false, imageBuffer: true });
        if (result.pages.length !== 1 || !result.pages[0].data?.length)
            throw new Error('Этикетка не поместилась на одну страницу.');
        return Buffer.from(result.pages[0].data).toString('base64');
    }
    finally {
        await parser.destroy();
    }
}
