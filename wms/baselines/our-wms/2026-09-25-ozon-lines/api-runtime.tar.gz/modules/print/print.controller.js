"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const create_label_template_dto_1 = require("./dto/create-label-template.dto");
const create_print_job_dto_1 = require("./dto/create-print-job.dto");
const list_label_templates_dto_1 = require("./dto/list-label-templates.dto");
const list_print_jobs_dto_1 = require("./dto/list-print-jobs.dto");
const process_print_queue_dto_1 = require("./dto/process-print-queue.dto");
const preview_label_template_dto_1 = require("./dto/preview-label-template.dto");
const preview_box_label_dto_1 = require("./dto/preview-box-label.dto");
const preview_pallet_label_dto_1 = require("./dto/preview-pallet-label.dto");
const preview_sku_label_dto_1 = require("./dto/preview-sku-label.dto");
const reprint_print_job_dto_1 = require("./dto/reprint-print-job.dto");
const update_label_template_dto_1 = require("./dto/update-label-template.dto");
const update_print_job_status_dto_1 = require("./dto/update-print-job-status.dto");
const upsert_print_printer_dto_1 = require("./dto/upsert-print-printer.dto");
const label_template_service_1 = require("./label-template.service");
const print_job_service_1 = require("./print-job.service");
const print_printer_service_1 = require("./print-printer.service");
const print_queue_worker_service_1 = require("./print-queue-worker.service");
const print_agent_service_1 = require("./print-agent.service");
const tspl_label_service_1 = require("./tspl-label.service");
let PrintController = class PrintController {
    labels;
    templates;
    jobs;
    printers;
    queue;
    agent;
    constructor(labels, templates, jobs, printers, queue, agent) {
        this.labels = labels;
        this.templates = templates;
        this.jobs = jobs;
        this.printers = printers;
        this.queue = queue;
        this.agent = agent;
    }
    listPrinters(user) {
        return this.printers.listPrinters(user);
    }
    listAgentStations() {
        return this.agent.listStations();
    }
    createAgentSkuJob(body, user) {
        return this.agent.createSkuJob(body ?? {}, user);
    }
    createAgentCustomJob(body, user) {
        return this.agent.createCustomJob(body ?? {}, user);
    }
    claimAgentJob(stationId) {
        return this.agent.claim(stationId);
    }
    finishAgentJob(id, body) {
        return this.agent.finish(id, body?.success === true, body?.error);
    }
    listPrinterGroups(user) {
        return this.printers.listPrinterGroups(user);
    }
    upsertPrinter(body, user) {
        return this.printers.upsertPrinter(body, user);
    }
    listTemplates(query) {
        return this.templates.listTemplates(query);
    }
    createTemplate(body) {
        return this.templates.createTemplate(body);
    }
    updateTemplate(templateId, body) {
        return this.templates.updateTemplate(templateId, body);
    }
    listTemplateVersions(templateId) {
        return this.templates.listTemplateVersions(templateId);
    }
    previewTemplate(templateId, body) {
        return this.templates.previewTemplate(templateId, body);
    }
    createJobFromTemplate(templateId, body, user) {
        return this.jobs.createFromTemplate(templateId, body, user);
    }
    listJobs(query, user) {
        return this.jobs.listJobs(query, user);
    }
    updateJobStatus(jobId, body, user) {
        return this.jobs.updateStatus(jobId, body, user);
    }
    reprintJob(jobId, user, body = {}) {
        return this.jobs.reprintJob(jobId, body, user);
    }
    processQueue(body = {}, user) {
        return this.queue.processQueued(body.limit, user, body.groupCode);
    }
    previewBoxLabel(body) {
        return {
            printerLanguage: 'TSPL',
            tspl: this.labels.boxLabel(body),
        };
    }
    previewSkuLabel(body) {
        return {
            printerLanguage: 'TSPL',
            tspl: this.labels.skuLabel(body),
        };
    }
    previewPalletLabel(body) {
        return {
            printerLanguage: 'TSPL',
            tspl: this.labels.palletLabel(body),
        };
    }
};
exports.PrintController = PrintController;
__decorate([
    (0, common_1.Get)('printers'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "listPrinters", null);
__decorate([
    (0, common_1.Get)('agent-stations'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "listAgentStations", null);
__decorate([
    (0, common_1.Post)('agent-jobs'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "createAgentSkuJob", null);
__decorate([
    (0, common_1.Post)('agent-custom-jobs'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "createAgentCustomJob", null);
__decorate([
    (0, common_1.Post)('agent-stations/:stationId/claim'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('stationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "claimAgentJob", null);
__decorate([
    (0, common_1.Post)('agent-jobs/:id/result'),
    (0, require_permissions_decorator_1.RequirePermissions)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "finishAgentJob", null);
__decorate([
    (0, common_1.Get)('printer-groups'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "listPrinterGroups", null);
__decorate([
    (0, common_1.Post)('printers'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [upsert_print_printer_dto_1.UpsertPrintPrinterDto, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "upsertPrinter", null);
__decorate([
    (0, common_1.Get)('templates'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_label_templates_dto_1.ListLabelTemplatesDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "listTemplates", null);
__decorate([
    (0, common_1.Post)('templates'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_label_template_dto_1.CreateLabelTemplateDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "createTemplate", null);
__decorate([
    (0, common_1.Patch)('templates/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_label_template_dto_1.UpdateLabelTemplateDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "updateTemplate", null);
__decorate([
    (0, common_1.Get)('templates/:id/versions'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "listTemplateVersions", null);
__decorate([
    (0, common_1.Post)('templates/:id/preview'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, preview_label_template_dto_1.PreviewLabelTemplateDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "previewTemplate", null);
__decorate([
    (0, common_1.Post)('templates/:id/jobs'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_print_job_dto_1.CreatePrintJobFromTemplateDto, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "createJobFromTemplate", null);
__decorate([
    (0, common_1.Get)('jobs'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_print_jobs_dto_1.ListPrintJobsDto, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "listJobs", null);
__decorate([
    (0, common_1.Patch)('jobs/:id/status'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_print_job_status_dto_1.UpdatePrintJobStatusDto, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "updateJobStatus", null);
__decorate([
    (0, common_1.Post)('jobs/:id/reprint'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, reprint_print_job_dto_1.ReprintPrintJobDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "reprintJob", null);
__decorate([
    (0, common_1.Post)('jobs/process'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [process_print_queue_dto_1.ProcessPrintQueueDto, Object]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "processQueue", null);
__decorate([
    (0, common_1.Post)('box-label/preview'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [preview_box_label_dto_1.PreviewBoxLabelDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "previewBoxLabel", null);
__decorate([
    (0, common_1.Post)('sku-label/preview'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [preview_sku_label_dto_1.PreviewSkuLabelDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "previewSkuLabel", null);
__decorate([
    (0, common_1.Post)('pallet-label/preview'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [preview_pallet_label_dto_1.PreviewPalletLabelDto]),
    __metadata("design:returntype", void 0)
], PrintController.prototype, "previewPalletLabel", null);
exports.PrintController = PrintController = __decorate([
    (0, swagger_1.ApiTags)('print'),
    (0, require_permissions_decorator_1.RequirePermissions)('print:write'),
    (0, common_1.Controller)('print'),
    __metadata("design:paramtypes", [tspl_label_service_1.TsplLabelService,
        label_template_service_1.LabelTemplateService,
        print_job_service_1.PrintJobService,
        print_printer_service_1.PrintPrinterService,
        print_queue_worker_service_1.PrintQueueWorkerService,
        print_agent_service_1.PrintAgentService])
], PrintController);
