"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdatePrintJobStatusDto = void 0;
const class_validator_1 = require("class-validator");
const print_job_status_1 = require("../print-job-status");
class UpdatePrintJobStatusDto {
    status;
    message;
}
exports.UpdatePrintJobStatusDto = UpdatePrintJobStatusDto;
__decorate([
    (0, class_validator_1.IsIn)(print_job_status_1.PRINT_JOB_STATUSES),
    __metadata("design:type", String)
], UpdatePrintJobStatusDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdatePrintJobStatusDto.prototype, "message", void 0);
