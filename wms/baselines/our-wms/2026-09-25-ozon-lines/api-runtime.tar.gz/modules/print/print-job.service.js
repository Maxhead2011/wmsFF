"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintJobService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const printer_scope_service_1 = require("../auth/printer-scope.service");
const label_template_service_1 = require("./label-template.service");
const print_printer_service_1 = require("./print-printer.service");
let PrintJobService = class PrintJobService {
    prisma;
    templates;
    printers;
    printerScopes;
    constructor(prisma, templates, printers, printerScopes) {
        this.prisma = prisma;
        this.templates = templates;
        this.printers = printers;
        this.printerScopes = printerScopes;
    }
    async listJobs(query, user) {
        const printerCodes = await this.resolvePrinterCodesForScope(user, query.groupCode);
        return this.prisma.printJob.findMany({
            where: {
                status: query.status,
                printerCode: printerCodes ? { in: printerCodes } : undefined,
            },
            orderBy: { createdAt: 'desc' },
            take: query.limit ?? 100,
        });
    }
    async createFromTemplate(templateId, dto, user) {
        const printerCode = (0, print_printer_service_1.normalizePrinterCode)(dto.printerCode);
        const copies = dto.copies ?? 1;
        const template = await this.templates.getTemplateOrThrow(templateId);
        const printer = await this.printers.getActivePrinterOrThrow(printerCode);
        this.printerScopes.requirePrinterGroupAccess(user, printer.groupCode, 'print');
        if (!template.isActive) {
            throw new common_1.BadRequestException('Шаблон этикетки отключен.');
        }
        const variables = dto.variables ?? {};
        // FIX: copies must alter the command sent to the printer, not just job metadata.
        const tspl = applyPrintCopies(this.templates.renderTspl(template.tspl, variables), copies);
        // Русский комментарий: очередь хранит уже готовый TSPL, чтобы будущий печатный воркер не зависел от изменений шаблона.
        return this.prisma.printJob.create({
            data: {
                printerCode,
                labelType: template.type,
                payload: {
                    source: 'label-template',
                    templateId: template.id,
                    templateCode: template.code,
                    templateName: template.name,
                    templateVersion: template.version,
                    variables,
                    copies,
                },
                tspl,
                status: 'queued',
            },
        });
    }
    async updateStatus(jobId, dto, user) {
        const job = await this.prisma.printJob.findUnique({
            where: { id: jobId },
            select: { id: true, payload: true, printerCode: true },
        });
        if (!job) {
            throw new common_1.NotFoundException('Задание печати не найдено.');
        }
        const printer = await this.printers.getActivePrinterOrThrow(job.printerCode);
        this.printerScopes.requirePrinterGroupAccess(user, printer.groupCode, 'manage');
        return this.prisma.printJob.update({
            where: { id: jobId },
            data: {
                status: dto.status,
                payload: mergeStatusMessage(job.payload, dto.message),
            },
        });
    }
    async reprintJob(jobId, dto, user) {
        const job = await this.prisma.printJob.findUnique({
            where: { id: jobId },
        });
        if (!job) {
            throw new common_1.NotFoundException('Задание печати не найдено.');
        }
        if (job.printerCode.startsWith('AGENT:')) {
            const station = await this.prisma.fbsPrintStation.findFirst({ where: { id: job.printerCode.slice('AGENT:'.length), enabled: true }, select: { id: true } });
            if (!station)
                throw new common_1.BadRequestException('Печатная станция отключена.');
        }
        else {
            const printer = await this.printers.getActivePrinterOrThrow(job.printerCode);
            this.printerScopes.requirePrinterGroupAccess(user, printer.groupCode, 'print');
        }
        // Русский комментарий: перепечатка создает новое задание, а связь с оригиналом хранится в payload для аудита.
        return this.prisma.printJob.create({
            data: {
                printerCode: job.printerCode,
                labelType: job.labelType,
                payload: reprintPayload(job.payload, job.id, dto.reason),
                tspl: job.tspl,
                status: 'queued',
            },
        });
    }
    async resolvePrinterCodesForScope(user, requestedGroupCode) {
        const groupCode = this.printerScopes.resolvePrinterGroupFilter(user, requestedGroupCode);
        if (!groupCode) {
            return undefined;
        }
        const printers = await this.prisma.printPrinter.findMany({
            where: { groupCode },
            select: { code: true },
        });
        return printers.map((printer) => printer.code);
    }
};
exports.PrintJobService = PrintJobService;
exports.PrintJobService = PrintJobService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        label_template_service_1.LabelTemplateService,
        print_printer_service_1.PrintPrinterService,
        printer_scope_service_1.PrinterScopeService])
], PrintJobService);
function mergeStatusMessage(payload, message) {
    const currentPayload = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
    if (!message?.trim()) {
        return currentPayload;
    }
    return {
        ...currentPayload,
        statusMessage: message.trim(),
    };
}
function reprintPayload(payload, jobId, reason) {
    const currentPayload = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
    const trimmedReason = reason?.trim();
    return {
        ...currentPayload,
        reprintOfJobId: jobId,
        reprintReason: trimmedReason || 'Повторная печать',
        reprintedAt: new Date().toISOString(),
    };
}
function applyPrintCopies(tspl, copies) {
    if (!Number.isInteger(copies) || copies < 1 || copies > 100) {
        throw new common_1.BadRequestException('Количество копий должно быть от 1 до 100.');
    }
    const normalized = tspl.replace(/\r\n?/g, '\n');
    const command = /^[ \t]*PRINT[ \t]+\d+(?:[ \t]*,[ \t]*\d+)?[ \t]*$/gim;
    const matches = [...normalized.matchAll(command)];
    if (matches.length > 1)
        throw new common_1.BadRequestException('Шаблон содержит несколько команд PRINT.');
    return matches.length ? normalized.replace(command, `PRINT ${copies}`) : `${normalized.trimEnd()}\nPRINT ${copies}`;
}
