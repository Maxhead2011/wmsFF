"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PRINT_JOB_STATUSES = void 0;
exports.PRINT_JOB_STATUSES = ['queued', 'sent', 'printed', 'failed', 'cancelled'];
