"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizDuplicateController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const kiz_duplicate_service_1 = require("./kiz-duplicate.service");
let KizDuplicateController = class KizDuplicateController {
    service;
    constructor(service) {
        this.service = service;
    }
    clients(user) { return this.service.clients(user); }
    stations(user) { return this.service.stations(user); }
    lookup(body, user) { return this.service.lookup(body ?? {}, user); }
    create(body, user) { return this.service.create(body ?? {}, user); }
    history(user) { return this.service.history(user); }
    status(id, user) { return this.service.status(id, user); }
    verify(id, body, user) { return this.service.verify(id, body?.kiz, user); }
    heartbeat(id, user) { return this.service.heartbeat(id, user); }
    claim(id, user) { return this.service.claim(id, user); }
    finish(stationId, id, body, user) { return this.service.finish(stationId, id, body?.success, body?.error, user); }
};
exports.KizDuplicateController = KizDuplicateController;
__decorate([
    (0, common_1.Get)('clients'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "clients", null);
__decorate([
    (0, common_1.Get)('stations'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "stations", null);
__decorate([
    (0, common_1.Post)('lookup'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "lookup", null);
__decorate([
    (0, common_1.Post)('jobs'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('jobs'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "history", null);
__decorate([
    (0, common_1.Get)('jobs/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "status", null);
__decorate([
    (0, common_1.Post)('jobs/:id/verify'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "verify", null);
__decorate([
    (0, common_1.Post)('stations/:id/heartbeat'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "heartbeat", null);
__decorate([
    (0, common_1.Post)('stations/:id/claim'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "claim", null);
__decorate([
    (0, common_1.Post)('stations/:stationId/jobs/:id/result'),
    __param(0, (0, common_1.Param)('stationId')),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", void 0)
], KizDuplicateController.prototype, "finish", null);
exports.KizDuplicateController = KizDuplicateController = __decorate([
    (0, common_1.Controller)('print/kiz-duplicates'),
    (0, require_permissions_decorator_1.RequirePermissions)('print:write'),
    __metadata("design:paramtypes", [kiz_duplicate_service_1.KizDuplicateService])
], KizDuplicateController);
