"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizLocationController = exports.DecideKizReviewDto = exports.CheckKizLocationDto = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const kiz_location_service_1 = require("./kiz-location.service");
class CheckKizLocationDto {
    kiz;
}
exports.CheckKizLocationDto = CheckKizLocationDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1024),
    __metadata("design:type", String)
], CheckKizLocationDto.prototype, "kiz", void 0);
class DecideKizReviewDto {
    resolution;
    reason;
    confirmed;
}
exports.DecideKizReviewDto = DecideKizReviewDto;
__decorate([
    (0, class_validator_1.IsIn)(['REUSE', 'RELABEL']),
    __metadata("design:type", String)
], DecideKizReviewDto.prototype, "resolution", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(5),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], DecideKizReviewDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DecideKizReviewDto.prototype, "confirmed", void 0);
// FIX: authenticate globally and authorize in the service; scanning does not modify stock.
let KizLocationController = class KizLocationController {
    location;
    constructor(location) {
        this.location = location;
    }
    reviews(user, cursor) {
        return this.location.reviews(user, cursor);
    }
    decide(id, dto, user) {
        return this.location.decideReview(id, dto.resolution, dto.reason, dto.confirmed, user);
    }
    check(dto, user) {
        return this.location.lookup(dto.kiz, user);
    }
};
exports.KizLocationController = KizLocationController;
__decorate([
    (0, common_1.Get)('reviews'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('cursor')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], KizLocationController.prototype, "reviews", null);
__decorate([
    (0, common_1.Post)('reviews/:id/decision'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, DecideKizReviewDto, Object]),
    __metadata("design:returntype", void 0)
], KizLocationController.prototype, "decide", null);
__decorate([
    (0, common_1.Post)('check'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [CheckKizLocationDto, Object]),
    __metadata("design:returntype", void 0)
], KizLocationController.prototype, "check", null);
exports.KizLocationController = KizLocationController = __decorate([
    (0, common_1.Controller)('inventory/kiz-location'),
    __metadata("design:paramtypes", [kiz_location_service_1.KizLocationService])
], KizLocationController);
