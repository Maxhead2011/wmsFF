"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.skuSortingAllowed = skuSortingAllowed;
// FIX: pilot authorization uses the signed device identity, never a body/header supplied by the scanner.
function skuSortingAllowed(user, requestId) {
    if (process.env.WMS_SKU_SORTING_ENABLED === 'true')
        return true;
    const device = process.env.WMS_SKU_SORTING_PILOT_DEVICE_ID?.trim();
    const request = process.env.WMS_SKU_SORTING_PILOT_REQUEST_ID?.trim();
    return Boolean(device && request && user?.deviceId === device && requestId === request);
}
