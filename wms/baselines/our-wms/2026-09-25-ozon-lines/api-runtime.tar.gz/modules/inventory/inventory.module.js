"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const stock_module_1 = require("../stock/stock.module");
const inventory_controller_1 = require("./inventory.controller");
const inventory_service_1 = require("./inventory.service");
const sku_collection_service_1 = require("./sku-collection.service");
const sku_sorting_service_1 = require("./sku-sorting.service");
const marketplace_connections_module_1 = require("../marketplace-connections/marketplace-connections.module");
const pallet_sorting_controller_1 = require("./pallet-sorting.controller");
const pallet_sorting_service_1 = require("./pallet-sorting.service");
const kiz_location_controller_1 = require("./kiz-location.controller");
const kiz_location_service_1 = require("./kiz-location.service");
let InventoryModule = class InventoryModule {
};
exports.InventoryModule = InventoryModule;
exports.InventoryModule = InventoryModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, stock_module_1.StockModule, marketplace_connections_module_1.MarketplaceConnectionsModule],
        controllers: [inventory_controller_1.InventoryController, pallet_sorting_controller_1.PalletSortingController, kiz_location_controller_1.KizLocationController],
        providers: [inventory_service_1.InventoryService, sku_collection_service_1.SkuCollectionService, sku_sorting_service_1.SkuSortingService, pallet_sorting_service_1.PalletSortingService, kiz_location_service_1.KizLocationService],
        // FIX: administration reuses the inventory-owned resolved-session invariant.
        exports: [inventory_service_1.InventoryService, sku_collection_service_1.SkuCollectionService, sku_sorting_service_1.SkuSortingService],
    })
], InventoryModule);
