"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkuCollectionService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const stock_balances_service_1 = require("../stock/stock-balances.service");
const sku_collection_policy_1 = require("./sku-collection-policy");
const sku_sorting_policy_1 = require("./sku-sorting-policy");
const requestInclude = {
    client: { select: { id: true, name: true } },
    items: { include: { sku: { include: { barcodes: true } } } },
    skuCollectionSources: { orderBy: { sourceBoxCode: 'asc' } },
    skuCollectionScans: { orderBy: { pickedAt: 'desc' } },
};
let SkuCollectionService = class SkuCollectionService {
    prisma;
    clientScopes;
    balances;
    constructor(prisma, clientScopes, balances) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.balances = balances;
    }
    async search(clientId, search, user) {
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const warehouseId = this.requireWarehouse(user, 'read');
        const query = search.trim();
        if (!query)
            return [];
        const skus = await this.prisma.sku.findMany({
            where: {
                clientId,
                OR: [
                    { name: { contains: query, mode: 'insensitive' } },
                    { internalSku: { contains: query, mode: 'insensitive' } },
                    { clientSku: { contains: query, mode: 'insensitive' } },
                    { article: { contains: query, mode: 'insensitive' } },
                    { barcodes: { some: { value: { contains: query } } } },
                ],
                balances: {
                    some: {
                        warehouseId,
                        status: client_1.StockStatus.AVAILABLE,
                        quantity: { gt: 0 },
                        boxId: { not: null },
                    },
                },
            },
            include: {
                barcodes: true,
                balances: {
                    where: {
                        warehouseId,
                        status: client_1.StockStatus.AVAILABLE,
                        quantity: { gt: 0 },
                        boxId: { not: null },
                    },
                    include: { box: { include: { pallet: true } } },
                },
            },
            orderBy: { name: 'asc' },
            take: 50,
        });
        return skus.map((sku) => ({
            id: sku.id,
            internalSku: sku.internalSku,
            clientSku: sku.clientSku,
            article: sku.article,
            name: sku.name,
            color: sku.color,
            size: sku.size,
            needsChestnyZnak: sku.needsChestnyZnak,
            barcodes: sku.barcodes.map((barcode) => barcode.value),
            availableQuantity: sku.balances.reduce((sum, balance) => sum + balance.quantity, 0),
            boxes: sku.balances.map((balance) => ({
                id: balance.box.id,
                code: balance.box.code,
                palletCode: balance.box.pallet?.code ?? null,
                quantity: balance.quantity,
            })),
        }));
    }
    async create(dto, user) {
        this.clientScopes.requireClientAccess(user, dto.clientId, 'write');
        const warehouseId = this.requireWarehouse(user, 'write');
        return this.prisma.$transaction(async (tx) => {
            const sku = await tx.sku.findFirst({
                where: { id: dto.skuId, clientId: dto.clientId },
                include: { barcodes: { orderBy: { isPrimary: 'desc' } } },
            });
            if (!sku)
                throw new common_1.NotFoundException('Товар клиента не найден.');
            if (!sku.needsChestnyZnak || sku.isUnmarked) {
                throw new common_1.BadRequestException('Сборка по SKU доступна только для маркированного товара с КИЗ.');
            }
            // FIX: lock the source balance rows before snapshotting the whole SKU into this request.
            await tx.$queryRaw(client_1.Prisma.sql `
        SELECT "id"
        FROM "StockBalance"
        WHERE "clientId" = ${dto.clientId}
          AND "warehouseId" = ${warehouseId}
          AND "skuId" = ${sku.id}
          AND "status" = 'AVAILABLE'
          AND "boxId" IS NOT NULL
        FOR UPDATE
      `);
            const available = await tx.stockBalance.findMany({
                where: {
                    clientId: dto.clientId,
                    warehouseId,
                    skuId: sku.id,
                    status: client_1.StockStatus.AVAILABLE,
                    quantity: { gt: 0 },
                    boxId: { not: null },
                    box: { status: { notIn: ['deleted', 'archived'] } },
                },
                include: { box: true },
                orderBy: { box: { code: 'asc' } },
            });
            if (available.length === 0)
                throw new common_1.BadRequestException('Для товара нет доступного остатка в коробах этого филиала.');
            const quantity = available.reduce((sum, balance) => sum + balance.quantity, 0);
            const barcode = sku.barcodes[0]?.value ?? sku.internalSku;
            const request = await tx.clientRequest.create({
                data: {
                    clientId: dto.clientId,
                    warehouseId,
                    type: client_1.ClientRequestType.SKU_COLLECTION,
                    status: client_1.ClientRequestStatus.APPROVED,
                    priority: client_1.ClientRequestPriority.NORMAL,
                    title: `Сборка по SKU · ${sku.name}`,
                    comment: process.env.WMS_SKU_SORTING_ENABLED === 'true'
                        ? '[SKU_SORTING_V2] Внутрискладская сортировка без резервирования.'
                        : '[SKU_COLLECTION] Внутренняя сборка для повторной приёмки по коробам.',
                    createdByUserId: user.id,
                    items: { create: { skuId: sku.id, barcode, name: sku.name, quantity } },
                    skuCollectionSources: {
                        create: available.map((balance) => ({
                            clientId: dto.clientId,
                            warehouseId,
                            skuId: sku.id,
                            sourceBoxId: balance.box.id,
                            sourceBoxCode: balance.box.code,
                            plannedQuantity: balance.quantity,
                        })),
                    },
                    events: {
                        create: {
                            clientId: dto.clientId,
                            eventType: client_1.ClientRequestEventType.CREATED,
                            title: 'Создана внутренняя сборка по SKU',
                            body: `${quantity} ед. из ${available.length} коробов`,
                            createdByUserId: user.id,
                        },
                    },
                },
            });
            for (const balance of available) {
                // FIX: sorting is a route snapshot, not a reservation of saleable stock.
                if (process.env.WMS_SKU_SORTING_ENABLED === 'true')
                    continue;
                // FIX: reserve the exact current stock so ordinary routes cannot select it while consolidation is active.
                await this.moveBalance(tx, balance, client_1.StockStatus.RESERVED, balance.quantity);
                await tx.stockMovement.createMany({
                    data: [
                        {
                            warehouseId,
                            clientId: dto.clientId,
                            skuId: sku.id,
                            boxId: balance.boxId,
                            palletId: balance.palletId,
                            type: client_1.MovementType.RESERVE,
                            status: client_1.StockStatus.AVAILABLE,
                            quantity: -balance.quantity,
                            sourceDocument: request.id,
                            comment: 'Резерв для сборки по SKU',
                        },
                        {
                            warehouseId,
                            clientId: dto.clientId,
                            skuId: sku.id,
                            boxId: balance.boxId,
                            palletId: balance.palletId,
                            type: client_1.MovementType.RESERVE,
                            status: client_1.StockStatus.RESERVED,
                            quantity: balance.quantity,
                            sourceDocument: request.id,
                            comment: 'Резерв для сборки по SKU',
                        },
                    ],
                });
                const marks = await tx.productMark.findMany({
                    where: { clientId: dto.clientId, skuId: sku.id, boxId: balance.boxId, status: client_1.StockStatus.AVAILABLE },
                    select: { id: true },
                    take: balance.quantity,
                });
                if (marks.length) {
                    await tx.productMark.updateMany({ where: { id: { in: marks.map((mark) => mark.id) } }, data: { status: client_1.StockStatus.RESERVED } });
                }
            }
            return this.summary(tx, request.id, user);
        }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
    }
    async list(user) {
        const warehouseId = this.requireWarehouse(user, 'read');
        const clientId = this.clientScopes.resolveClientFilter(user);
        const requests = await this.prisma.clientRequest.findMany({
            where: {
                warehouseId,
                clientId,
                type: client_1.ClientRequestType.SKU_COLLECTION,
                status: { in: [client_1.ClientRequestStatus.APPROVED, client_1.ClientRequestStatus.IN_WORK, client_1.ClientRequestStatus.PACKED] },
            },
            include: requestInclude,
            orderBy: { createdAt: 'asc' },
        });
        return this.withRoutes(requests, this.prisma, user);
    }
    async get(id, user) {
        const request = await this.prisma.clientRequest.findFirst({
            where: { id, type: client_1.ClientRequestType.SKU_COLLECTION },
            include: requestInclude,
        });
        if (!request)
            throw new common_1.NotFoundException('Заявка «Сборка по SKU» не найдена.');
        this.clientScopes.requireClientAccess(user, request.clientId, 'read');
        if (request.warehouseId !== this.requireWarehouse(user, 'read'))
            throw new common_1.NotFoundException('Заявка относится к другому филиалу.');
        return (await this.withRoutes([request], this.prisma, user))[0];
    }
    async pick(id, dto, user) {
        const scan = (0, sku_collection_policy_1.assertSkuCollectionPick)(dto);
        return this.prisma.$transaction(async (tx) => {
            // FIX: one request-level row lock prevents two TSDs from consuming the same last unit.
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "ClientRequest" WHERE "id" = ${id} FOR UPDATE`);
            const request = await this.requireRequest(tx, id, user, [client_1.ClientRequestStatus.APPROVED, client_1.ClientRequestStatus.IN_WORK]);
            // FIX: old APKs must not run the legacy two-phase picker on an unreserved route.
            if (request.comment?.includes('[SKU_SORTING_V2]')) {
                throw new common_1.BadRequestException('Откройте единую сортировку в обновлённом ТСД: ШК → КИЗ → целевой короб.');
            }
            const existing = await tx.skuCollectionScan.findUnique({ where: { requestId_kiz: { requestId: id, kiz: scan.kiz } } });
            if (existing)
                return this.summary(tx, id, user);
            const source = request.skuCollectionSources.find((item) => item.sourceBoxCode.toLocaleUpperCase('ru-RU') === scan.sourceBoxCode.toLocaleUpperCase('ru-RU') && item.pickedQuantity < item.plannedQuantity);
            if (!source)
                throw new common_1.BadRequestException('Этот короб не содержит неотобранный товар данной заявки.');
            await this.assertBarcode(tx, source.skuId, scan.barcode);
            const mark = await tx.productMark.findFirst({
                where: { clientId: request.clientId, value: { equals: scan.kiz, mode: 'insensitive' } },
            });
            if (mark && (mark.skuId !== source.skuId || (mark.boxId && mark.boxId !== source.sourceBoxId))) {
                throw new common_1.BadRequestException('КИЗ зарегистрирован за другим товаром или другим коробом.');
            }
            const reserved = await tx.stockBalance.findFirst({
                where: { warehouseId: source.warehouseId, clientId: source.clientId, skuId: source.skuId, boxId: source.sourceBoxId, status: client_1.StockStatus.RESERVED, quantity: { gt: 0 } },
            });
            if (!reserved)
                throw new common_1.BadRequestException('Зарезервированный товар в исходном коробе закончился. Обновите заявку.');
            await this.moveBalance(tx, reserved, client_1.StockStatus.PACKING, 1, null, null);
            const movement = await tx.stockMovement.create({
                data: { warehouseId: source.warehouseId, clientId: source.clientId, skuId: source.skuId, type: client_1.MovementType.PICK, status: client_1.StockStatus.PACKING, quantity: 1, sourceDocument: id, comment: `Сборка по SKU из ${source.sourceBoxCode}` },
            });
            if (mark) {
                await tx.productMark.update({ where: { id: mark.id }, data: { skuId: source.skuId, boxId: null, status: client_1.StockStatus.PACKING, sourceDocument: id, stockMovementId: movement.id } });
            }
            else {
                await tx.productMark.create({ data: { clientId: source.clientId, skuId: source.skuId, value: scan.kiz, boxId: null, status: client_1.StockStatus.PACKING, sourceDocument: id, stockMovementId: movement.id } });
            }
            await tx.skuCollectionScan.create({
                data: { requestId: id, sourceId: source.id, skuId: source.skuId, barcode: scan.barcode, kiz: scan.kiz, sourceBoxId: source.sourceBoxId, sourceBoxCode: source.sourceBoxCode, pickedByUserId: user.id, pickedByName: user.name },
            });
            await tx.skuCollectionSource.update({ where: { id: source.id }, data: { pickedQuantity: { increment: 1 } } });
            await this.refreshRequestStatus(tx, id);
            return this.summary(tx, id, user);
        }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
    }
    async receive(id, dto, user) {
        const existing = await this.prisma.skuCollectionScan.findUnique({ where: { requestId_kiz: { requestId: id, kiz: dto.kiz.trim() } } });
        const scan = (0, sku_collection_policy_1.assertSkuCollectionReceipt)({ ...dto, pickedByThisRequest: Boolean(existing) });
        return this.prisma.$transaction(async (tx) => {
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "ClientRequest" WHERE "id" = ${id} FOR UPDATE`);
            // FIX: legacy items already in PACKING can be placed without finishing every source first.
            const request = await this.requireRequest(tx, id, user, (0, sku_sorting_policy_1.skuSortingAllowed)(user, id)
                ? [client_1.ClientRequestStatus.APPROVED, client_1.ClientRequestStatus.IN_WORK, client_1.ClientRequestStatus.PACKED, client_1.ClientRequestStatus.DONE]
                : [client_1.ClientRequestStatus.PACKED]);
            // FIX: the legacy endpoint must not bypass the one-device pilot after conversion.
            if (request.comment?.includes('[SKU_SORTING_V2]') && !(0, sku_sorting_policy_1.skuSortingAllowed)(user, id)) {
                throw new common_1.ForbiddenException('Эта заявка доступна только на пилотном ТСД.');
            }
            const picked = await tx.skuCollectionScan.findUnique({ where: { requestId_kiz: { requestId: id, kiz: scan.kiz } } });
            if (!picked)
                throw new common_1.BadRequestException('КИЗ не был отобран этой заявкой.');
            if (picked.status === client_1.SkuCollectionScanStatus.RECEIVED) {
                if ((0, sku_sorting_policy_1.skuSortingAllowed)(user, id) && picked.targetBoxCode?.toUpperCase() !== scan.targetBoxCode.toUpperCase()) {
                    throw new common_1.BadRequestException('КИЗ уже размещён в другом коробе. Повторное размещение не выполнено.');
                }
                return this.summary(tx, id, user);
            }
            if ((0, sku_sorting_policy_1.skuSortingAllowed)(user, id)) {
                const mark = await tx.productMark.findFirst({ where: { clientId: request.clientId, value: scan.kiz, sourceDocument: id, status: client_1.StockStatus.PACKING, boxId: null } });
                if (!mark || mark.skuId !== picked.skuId)
                    throw new common_1.BadRequestException('КИЗ больше не находится в отборе этой заявки. Остатки не изменены.');
            }
            await this.assertBarcode(tx, picked.skuId, scan.barcode);
            const targetBox = await tx.box.findFirst({
                where: { code: { equals: scan.targetBoxCode, mode: 'insensitive' }, clientId: request.clientId, warehouseId: request.warehouseId, status: { notIn: ['deleted', 'archived'] } },
            });
            if (!targetBox)
                throw new common_1.BadRequestException('Короб приёмки не найден у этого клиента в активном филиале.');
            const packing = await tx.stockBalance.findFirst({ where: { warehouseId: request.warehouseId, clientId: request.clientId, skuId: picked.skuId, boxId: null, palletId: null, status: client_1.StockStatus.PACKING, quantity: { gt: 0 } } });
            if (!packing)
                throw new common_1.BadRequestException('Отобранный товар уже принят или отсутствует в промежуточном остатке.');
            await this.moveBalance(tx, packing, client_1.StockStatus.AVAILABLE, 1, targetBox.id, targetBox.palletId);
            const sorting = (0, sku_sorting_policy_1.skuSortingAllowed)(user, id);
            // FIX: recovering a legacy pick must not look like newly received stock in the ledger.
            if (sorting)
                await tx.stockMovement.create({ data: { warehouseId: request.warehouseId, clientId: request.clientId, skuId: picked.skuId,
                        type: client_1.MovementType.MOVE, status: client_1.StockStatus.PACKING, quantity: -1, sourceDocument: id, comment: `Размещение ранее отобранного SKU в ${targetBox.code}` } });
            const movement = await tx.stockMovement.create({ data: { warehouseId: request.warehouseId, clientId: request.clientId, skuId: picked.skuId, boxId: targetBox.id, palletId: targetBox.palletId, type: sorting ? client_1.MovementType.MOVE : client_1.MovementType.RECEIPT, status: client_1.StockStatus.AVAILABLE, quantity: 1, sourceDocument: id, comment: sorting ? `Размещение ранее отобранного SKU в ${targetBox.code}` : `Повторная приёмка сборки по SKU в ${targetBox.code}` } });
            // FIX: this is the only duplicate-KIZ exception; the same mark is moved instead of being recreated.
            const updatedMark = await tx.productMark.updateMany({ where: { clientId: request.clientId,
                    value: sorting ? scan.kiz : { equals: scan.kiz, mode: 'insensitive' }, sourceDocument: id,
                    ...(sorting ? { status: client_1.StockStatus.PACKING, boxId: null, skuId: picked.skuId } : {}) },
                data: { boxId: targetBox.id, skuId: picked.skuId, status: client_1.StockStatus.AVAILABLE, stockMovementId: movement.id } });
            if (sorting && updatedMark.count !== 1)
                throw new common_1.BadRequestException('КИЗ изменился параллельно. Размещение не выполнено.');
            await tx.skuCollectionScan.update({ where: { id: picked.id }, data: { status: client_1.SkuCollectionScanStatus.RECEIVED, targetBoxId: targetBox.id, targetBoxCode: targetBox.code, receivedByUserId: user.id, receivedByName: user.name, receivedAt: new Date() } });
            await tx.skuCollectionSource.update({ where: { id: picked.sourceId }, data: { receivedQuantity: { increment: 1 } } });
            await this.refreshRequestStatus(tx, id);
            return this.summary(tx, id, user);
        }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
    }
    async requireRequest(tx, id, user, statuses) {
        const request = await tx.clientRequest.findFirst({ where: { id, type: client_1.ClientRequestType.SKU_COLLECTION, status: { in: statuses } }, include: { skuCollectionSources: true } });
        if (!request)
            throw new common_1.BadRequestException('Заявка уже не находится на этом этапе работы. Обновите список.');
        this.clientScopes.requireClientAccess(user, request.clientId, 'write');
        if (request.warehouseId !== this.requireWarehouse(user, 'write'))
            throw new common_1.ForbiddenException('Заявка относится к другому филиалу.');
        return request;
    }
    async assertBarcode(tx, skuId, code) {
        const sku = await tx.sku.findUnique({ where: { id: skuId }, include: { barcodes: true } });
        const normalized = code.trim().toLocaleUpperCase('ru-RU');
        const codes = [sku?.internalSku, sku?.clientSku, sku?.article, ...(sku?.barcodes.map((item) => item.value) ?? [])]
            .filter(Boolean)
            .map((item) => item.trim().toLocaleUpperCase('ru-RU'));
        if (!codes.includes(normalized))
            throw new common_1.BadRequestException('Отсканирован другой товар.');
    }
    async refreshRequestStatus(tx, requestId) {
        const totals = await tx.skuCollectionSource.aggregate({ where: { requestId }, _sum: { plannedQuantity: true, pickedQuantity: true, receivedQuantity: true } });
        const planned = totals._sum.plannedQuantity ?? 0;
        const picked = totals._sum.pickedQuantity ?? 0;
        const received = totals._sum.receivedQuantity ?? 0;
        const status = received >= planned
            ? client_1.ClientRequestStatus.DONE
            : picked >= planned
                ? client_1.ClientRequestStatus.PACKED
                : client_1.ClientRequestStatus.IN_WORK;
        await tx.clientRequest.update({ where: { id: requestId }, data: { status } });
    }
    async summary(tx, requestId, user) {
        const request = await tx.clientRequest.findUniqueOrThrow({ where: { id: requestId }, include: requestInclude });
        return (await this.withRoutes([request], tx, user))[0];
    }
    async withRoutes(requests, db = this.prisma, user) {
        // FIX: read current pallet-sort placement (as FBO does), never the legacy Box.pallet snapshot.
        const scopes = requests.filter((request) => request.warehouseId && request.skuCollectionSources.length);
        const placements = scopes.length ? await db.storagePalletBox.findMany({
            where: {
                OR: scopes.map((request) => ({
                    pallet: { warehouseId: request.warehouseId, clientId: request.clientId },
                    OR: request.skuCollectionSources.flatMap((source) => [
                        { boxId: source.sourceBoxId },
                        { boxCode: { equals: source.sourceBoxCode, mode: 'insensitive' } },
                    ]),
                })),
            },
            include: { pallet: { include: { zone: true } } },
        }) : [];
        const key = (clientId, warehouseId, value) => JSON.stringify([clientId, warehouseId, value.trim().toLocaleUpperCase('ru-RU')]);
        const byId = new Map(placements.filter((item) => item.boxId).map((item) => [key(item.pallet.clientId, item.pallet.warehouseId, item.boxId), item]));
        const byCode = new Map(placements.filter((item) => !item.boxId).map((item) => [key(item.pallet.clientId, item.pallet.warehouseId, item.boxCode), item]));
        const compare = new Intl.Collator('ru', { numeric: true }).compare;
        return requests.map((request) => ({
            ...request,
            // FIX: capability drives the LOGOFF-only UI; other installations keep legacy behavior.
            sortingWorkflow: (0, sku_sorting_policy_1.skuSortingAllowed)(user, request.id),
            skuCollectionSources: request.skuCollectionSources.map((source) => {
                const placement = byId.get(key(request.clientId, request.warehouseId, source.sourceBoxId))
                    ?? byCode.get(key(request.clientId, request.warehouseId, source.sourceBoxCode));
                return {
                    ...source,
                    storageLocation: placement ? {
                        palletId: placement.palletId,
                        palletCode: placement.pallet.code,
                        zoneId: placement.pallet.zoneId,
                        zoneCode: placement.pallet.zone?.code ?? null,
                        zoneName: placement.pallet.zone?.name ?? null,
                    } : null,
                };
            }).sort((a, b) => compare(a.storageLocation?.zoneName ?? a.storageLocation?.zoneCode ?? '\uffff', b.storageLocation?.zoneName ?? b.storageLocation?.zoneCode ?? '\uffff') ||
                compare(a.storageLocation?.palletCode ?? '\uffff', b.storageLocation?.palletCode ?? '\uffff') ||
                compare(a.sourceBoxCode, b.sourceBoxCode)),
        }));
    }
    async moveBalance(tx, source, targetStatus, quantity, targetBoxId = source.boxId, targetPalletId = source.palletId) {
        if (source.quantity < quantity)
            throw new common_1.BadRequestException('Недостаточно остатка для операции.');
        if (source.quantity === quantity)
            await tx.stockBalance.delete({ where: { id: source.id } });
        else
            await tx.stockBalance.update({ where: { id: source.id }, data: { quantity: { decrement: quantity } } });
        const warehouseId = source.warehouseId;
        if (!warehouseId)
            throw new common_1.BadRequestException('У остатка не указан филиал.');
        const input = { warehouseId, clientId: source.clientId, skuId: source.skuId, boxId: targetBoxId, palletId: targetPalletId, status: targetStatus };
        await tx.stockBalance.upsert({
            where: { balanceKey: this.balances.balanceKey(input) },
            update: { quantity: { increment: quantity }, warehouseId },
            create: { ...input, balanceKey: this.balances.balanceKey(input), quantity },
        });
    }
    requireWarehouse(user, access) {
        const warehouseId = user.activeWarehouseId?.trim();
        const allowed = access === 'write' ? user.writableWarehouseIds : user.warehouseIds;
        if (!warehouseId || (!user.permissionCodes.includes('system:admin') && !(allowed ?? []).includes(warehouseId))) {
            throw new common_1.ForbiddenException(access === 'write' ? 'Выберите филиал, доступный для изменения.' : 'Выберите активный филиал.');
        }
        return warehouseId;
    }
};
exports.SkuCollectionService = SkuCollectionService;
exports.SkuCollectionService = SkuCollectionService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        stock_balances_service_1.StockBalancesService])
], SkuCollectionService);
