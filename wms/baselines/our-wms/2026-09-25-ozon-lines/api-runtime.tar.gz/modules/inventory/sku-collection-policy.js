"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertSkuCollectionPick = assertSkuCollectionPick;
exports.assertSkuCollectionReceipt = assertSkuCollectionReceipt;
const common_1 = require("@nestjs/common");
function required(value, message) {
    const normalized = value?.trim();
    if (!normalized)
        throw new common_1.BadRequestException(message);
    return normalized;
}
function assertSkuCollectionPick(input) {
    // FIX: the internal collection flow always records physical origin, product and KIZ.
    return {
        sourceBoxCode: required(input.sourceBoxCode, 'Сканируйте исходный короб.'),
        barcode: required(input.barcode, 'Сканируйте ШК товара.'),
        kiz: required(input.kiz, 'Сканируйте КИЗ.'),
    };
}
function assertSkuCollectionReceipt(input) {
    const normalized = {
        targetBoxCode: required(input.targetBoxCode, 'Сканируйте короб приёмки.'),
        barcode: required(input.barcode, 'Сканируйте ШК товара.'),
        kiz: required(input.kiz, 'Сканируйте КИЗ.'),
    };
    if (!input.pickedByThisRequest) {
        throw new common_1.BadRequestException('КИЗ не был отобран этой заявкой. Обычный дубликат принимать нельзя.');
    }
    return normalized;
}
