"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const vitest_1 = require("vitest");
const sku_collection_policy_1 = require("./sku-collection-policy");
(0, vitest_1.describe)('sku collection policy', () => {
    (0, vitest_1.it)('requires both product barcode and KIZ during picking', () => {
        // TEST: the dedicated flow never accepts a quantity-only scan.
        (0, vitest_1.expect)(() => (0, sku_collection_policy_1.assertSkuCollectionPick)({ barcode: '', kiz: '010-test', sourceBoxCode: 'BOX-1' }))
            .toThrow('Сканируйте ШК товара');
        (0, vitest_1.expect)(() => (0, sku_collection_policy_1.assertSkuCollectionPick)({ barcode: '460000000001', kiz: '', sourceBoxCode: 'BOX-1' }))
            .toThrow('Сканируйте КИЗ');
    });
    (0, vitest_1.it)('accepts an existing KIZ only when it was picked by the same request', () => {
        // TEST: normal duplicate acceptance must not leak into ordinary receipt.
        (0, vitest_1.expect)(() => (0, sku_collection_policy_1.assertSkuCollectionReceipt)({
            barcode: '460000000001',
            kiz: '010-test',
            targetBoxCode: 'BOX-2',
            pickedByThisRequest: false,
        })).toThrow('КИЗ не был отобран этой заявкой');
        (0, vitest_1.expect)((0, sku_collection_policy_1.assertSkuCollectionReceipt)({
            barcode: '460000000001',
            kiz: '010-test',
            targetBoxCode: 'BOX-2',
            pickedByThisRequest: true,
        })).toEqual({ barcode: '460000000001', kiz: '010-test', targetBoxCode: 'BOX-2' });
    });
});
