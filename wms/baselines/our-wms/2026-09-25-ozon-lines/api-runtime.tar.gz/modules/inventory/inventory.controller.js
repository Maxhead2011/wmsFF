"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryController = void 0;
const class_validator_1 = require("class-validator");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const inventory_dto_1 = require("./dto/inventory.dto");
const inventory_service_1 = require("./inventory.service");
const sku_collection_dto_1 = require("./dto/sku-collection.dto");
const sku_collection_service_1 = require("./sku-collection.service");
const sku_sorting_service_1 = require("./sku-sorting.service");
class OpenedCheckDto {
    auditBoxId;
    openingId;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], OpenedCheckDto.prototype, "auditBoxId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], OpenedCheckDto.prototype, "openingId", void 0);
let InventoryController = class InventoryController {
    inventory;
    skuCollections;
    skuSorting;
    constructor(inventory, skuCollections, skuSorting) {
        this.inventory = inventory;
        this.skuCollections = skuCollections;
        this.skuSorting = skuSorting;
    }
    skuCollectionCapabilities(user) {
        return this.skuSorting.cancelCapabilities(user);
    }
    // FIX: dedicated cancellation preserves collection evidence and releases only its own reserves.
    cancelSkuCollection(id, user) {
        return this.skuSorting.cancel(id, user);
    }
    searchSkuCollection(dto, user) {
        return this.skuCollections.search(dto.clientId, dto.search, user);
    }
    createSkuCollection(dto, user) {
        return this.skuCollections.create(dto, user);
    }
    dashboard(workOnly, user) {
        return this.inventory.dashboard(user, workOnly === 'true');
    }
    list(type, user) {
        return this.inventory.listSessions(type, user);
    }
    get(id, workOnly, user) {
        return this.inventory.getSession(id, user, workOnly === 'true');
    }
    start(dto, user) {
        return this.inventory.startSession(dto, user);
    }
    // FIX: deliberate opening is distinct from background inventory GET requests.
    opened(id, dto, user) {
        return this.inventory.recordViewed(id, dto.auditBoxId, dto.openingId, user);
    }
    openBox(id, dto, user) {
        return this.inventory.openBox(id, dto.boxCode, user);
    }
    scan(id, dto, user) {
        return this.inventory.scanItem(id, dto, user);
    }
    setCount(id, dto, user) {
        return this.inventory.setCount(id, dto, user);
    }
    finishBox(id, user) {
        return this.inventory.finishBox(id, user);
    }
    approveRescan(id, user) {
        return this.inventory.approveRescanRequest(id, user);
    }
    review(id, user) {
        return this.inventory.sendToReview(id, user);
    }
    decide(id, dto, user) {
        return this.inventory.decideLine(id, dto, user);
    }
    resolveBox(id, dto, user) {
        return this.inventory.resolveBox(id, dto, user);
    }
    complete(id, dto, user) {
        return this.inventory.completeSession(id, dto.comment, user);
    }
    cancel(id, dto, user) {
        return this.inventory.cancelSession(id, dto.comment, user);
    }
};
exports.InventoryController = InventoryController;
__decorate([
    (0, common_1.Get)('sku-collections/capabilities'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "skuCollectionCapabilities", null);
__decorate([
    (0, common_1.Post)('sku-collections/:id/cancel'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "cancelSkuCollection", null);
__decorate([
    (0, common_1.Get)('sku-collections/search'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [sku_collection_dto_1.SearchSkuCollectionDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "searchSkuCollection", null);
__decorate([
    (0, common_1.Post)('sku-collections'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [sku_collection_dto_1.CreateSkuCollectionDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "createSkuCollection", null);
__decorate([
    (0, common_1.Get)('dashboard'),
    __param(0, (0, common_1.Query)('workOnly')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "dashboard", null);
__decorate([
    (0, common_1.Get)('sessions'),
    __param(0, (0, common_1.Query)('type')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('sessions/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('workOnly')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "get", null);
__decorate([
    (0, common_1.Post)('sessions'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [inventory_dto_1.StartInventoryDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "start", null);
__decorate([
    (0, common_1.Post)('sessions/:id/opened'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, OpenedCheckDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "opened", null);
__decorate([
    (0, common_1.Post)('sessions/:id/boxes/open'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.OpenInventoryBoxDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "openBox", null);
__decorate([
    (0, common_1.Post)('boxes/:id/scan'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.CountInventoryItemDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "scan", null);
__decorate([
    (0, common_1.Patch)('boxes/:id/count'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.SetInventoryCountDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "setCount", null);
__decorate([
    (0, common_1.Post)('boxes/:id/finish'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "finishBox", null);
__decorate([
    (0, common_1.Post)('rescan-requests/:id/approve'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "approveRescan", null);
__decorate([
    (0, common_1.Post)('sessions/:id/review'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "review", null);
__decorate([
    (0, common_1.Patch)('lines/:id/decision'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.InventoryDecisionDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "decide", null);
__decorate([
    (0, common_1.Post)('boxes/:id/resolve'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.ResolveInventoryBoxDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "resolveBox", null);
__decorate([
    (0, common_1.Post)('sessions/:id/complete'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.CompleteInventoryDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "complete", null);
__decorate([
    (0, common_1.Post)('sessions/:id/cancel'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.CompleteInventoryDto, Object]),
    __metadata("design:returntype", void 0)
], InventoryController.prototype, "cancel", null);
exports.InventoryController = InventoryController = __decorate([
    (0, swagger_1.ApiTags)('inventory'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:read'),
    (0, common_1.Controller)('inventory'),
    __metadata("design:paramtypes", [inventory_service_1.InventoryService,
        sku_collection_service_1.SkuCollectionService,
        sku_sorting_service_1.SkuSortingService])
], InventoryController);
