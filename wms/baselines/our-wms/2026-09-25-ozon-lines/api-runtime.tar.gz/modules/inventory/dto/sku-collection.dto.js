"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReadySkuSortingSourceDto = exports.OpenSkuSortingSourceDto = exports.MoveSkuSortingDto = exports.CheckSkuSortingDto = exports.ScanSkuCollectionReceiptDto = exports.ScanSkuCollectionPickDto = exports.CreateSkuCollectionDto = exports.SearchSkuCollectionDto = void 0;
const class_validator_1 = require("class-validator");
class SearchSkuCollectionDto {
    clientId;
    search;
}
exports.SearchSkuCollectionDto = SearchSkuCollectionDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], SearchSkuCollectionDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], SearchSkuCollectionDto.prototype, "search", void 0);
class CreateSkuCollectionDto {
    clientId;
    skuId;
}
exports.CreateSkuCollectionDto = CreateSkuCollectionDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateSkuCollectionDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateSkuCollectionDto.prototype, "skuId", void 0);
class ScanSkuCollectionPickDto {
    sourceBoxCode;
    barcode;
    kiz;
}
exports.ScanSkuCollectionPickDto = ScanSkuCollectionPickDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], ScanSkuCollectionPickDto.prototype, "sourceBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], ScanSkuCollectionPickDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(512),
    __metadata("design:type", String)
], ScanSkuCollectionPickDto.prototype, "kiz", void 0);
class ScanSkuCollectionReceiptDto {
    targetBoxCode;
    barcode;
    kiz;
}
exports.ScanSkuCollectionReceiptDto = ScanSkuCollectionReceiptDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], ScanSkuCollectionReceiptDto.prototype, "targetBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], ScanSkuCollectionReceiptDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(512),
    __metadata("design:type", String)
], ScanSkuCollectionReceiptDto.prototype, "kiz", void 0);
// FIX: the source inventory and physical pair are required before a storage move.
class CheckSkuSortingDto extends ScanSkuCollectionPickDto {
    auditBoxId;
}
exports.CheckSkuSortingDto = CheckSkuSortingDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CheckSkuSortingDto.prototype, "auditBoxId", void 0);
class MoveSkuSortingDto extends CheckSkuSortingDto {
    targetBoxCode;
}
exports.MoveSkuSortingDto = MoveSkuSortingDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], MoveSkuSortingDto.prototype, "targetBoxCode", void 0);
class OpenSkuSortingSourceDto {
    sourceBoxCode;
    recount;
}
exports.OpenSkuSortingSourceDto = OpenSkuSortingSourceDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], OpenSkuSortingSourceDto.prototype, "sourceBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], OpenSkuSortingSourceDto.prototype, "recount", void 0);
class ReadySkuSortingSourceDto extends OpenSkuSortingSourceDto {
    auditBoxId;
}
exports.ReadySkuSortingSourceDto = ReadySkuSortingSourceDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], ReadySkuSortingSourceDto.prototype, "auditBoxId", void 0);
