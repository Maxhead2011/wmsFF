"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompleteInventoryDto = exports.ResolveInventoryBoxDto = exports.InventoryDecisionDto = exports.SetInventoryCountDto = exports.CountInventoryItemDto = exports.OpenInventoryBoxDto = exports.StartInventoryDto = exports.InventoryResolutionAction = void 0;
const client_1 = require("@prisma/client");
const class_validator_1 = require("class-validator");
var InventoryResolutionAction;
(function (InventoryResolutionAction) {
    InventoryResolutionAction["APPLY_ACTUAL"] = "APPLY_ACTUAL";
    InventoryResolutionAction["DELETE_FROM_BOX"] = "DELETE_FROM_BOX";
    InventoryResolutionAction["ACCEPT_AS_IS"] = "ACCEPT_AS_IS";
    InventoryResolutionAction["LEAVE_FOR_LATER"] = "LEAVE_FOR_LATER";
})(InventoryResolutionAction || (exports.InventoryResolutionAction = InventoryResolutionAction = {}));
class StartInventoryDto {
    type;
    clientId;
    title;
    comment;
}
exports.StartInventoryDto = StartInventoryDto;
__decorate([
    (0, class_validator_1.IsEnum)(client_1.InventorySessionType),
    __metadata("design:type", String)
], StartInventoryDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], StartInventoryDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], StartInventoryDto.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], StartInventoryDto.prototype, "comment", void 0);
class OpenInventoryBoxDto {
    boxCode;
}
exports.OpenInventoryBoxDto = OpenInventoryBoxDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], OpenInventoryBoxDto.prototype, "boxCode", void 0);
class CountInventoryItemDto {
    barcode;
    quantity;
    kiz;
    requireKiz;
    // ADDED: opt-in physical barcode/KIZ counting; legacy barcode-only clients stay unchanged.
    captureKiz;
    // FIX: new TSD explicitly opts into a non-counting correction prompt.
    allowScanCorrection;
    replaceEvidenceToken;
}
exports.CountInventoryItemDto = CountInventoryItemDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(14, { message: 'В поле ШК товара отсканирован КИЗ. При инвентаризации сканируйте только ШК товара.' }),
    __metadata("design:type", String)
], CountInventoryItemDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CountInventoryItemDto.prototype, "quantity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(512),
    __metadata("design:type", String)
], CountInventoryItemDto.prototype, "kiz", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CountInventoryItemDto.prototype, "requireKiz", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CountInventoryItemDto.prototype, "captureKiz", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CountInventoryItemDto.prototype, "allowScanCorrection", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], CountInventoryItemDto.prototype, "replaceEvidenceToken", void 0);
class SetInventoryCountDto {
    lineId;
    countedQuantity;
}
exports.SetInventoryCountDto = SetInventoryCountDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], SetInventoryCountDto.prototype, "lineId", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SetInventoryCountDto.prototype, "countedQuantity", void 0);
class InventoryDecisionDto {
    decision;
    action;
    comment;
}
exports.InventoryDecisionDto = InventoryDecisionDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(client_1.InventoryLineDecision),
    __metadata("design:type", String)
], InventoryDecisionDto.prototype, "decision", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(InventoryResolutionAction),
    __metadata("design:type", String)
], InventoryDecisionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], InventoryDecisionDto.prototype, "comment", void 0);
class ResolveInventoryBoxDto {
    action;
    comment;
}
exports.ResolveInventoryBoxDto = ResolveInventoryBoxDto;
__decorate([
    (0, class_validator_1.IsIn)([InventoryResolutionAction.APPLY_ACTUAL, InventoryResolutionAction.ACCEPT_AS_IS]),
    __metadata("design:type", String)
], ResolveInventoryBoxDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], ResolveInventoryBoxDto.prototype, "comment", void 0);
class CompleteInventoryDto {
    comment;
}
exports.CompleteInventoryDto = CompleteInventoryDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], CompleteInventoryDto.prototype, "comment", void 0);
