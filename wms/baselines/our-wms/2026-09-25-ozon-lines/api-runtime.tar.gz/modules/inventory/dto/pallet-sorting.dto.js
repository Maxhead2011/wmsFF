"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PalletSortingActionDto = exports.StartPalletSortingDto = void 0;
const class_validator_1 = require("class-validator");
class StartPalletSortingDto {
    id;
    code;
}
exports.StartPalletSortingDto = StartPalletSortingDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], StartPalletSortingDto.prototype, "id", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], StartPalletSortingDto.prototype, "code", void 0);
class PalletSortingActionDto {
    operationId;
    version;
    action;
    code;
    sourceBoxCode;
    palletCode;
    barcode;
    kiz;
    fingerprint;
    confirmWriteOff;
    // ADDED: separate consent for a +1 found-unit receipt, not a shortage write-off.
    confirmRestore;
    restoreFingerprint;
}
exports.PalletSortingActionDto = PalletSortingActionDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "operationId", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PalletSortingActionDto.prototype, "version", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['SCAN_SOURCE', 'ARCHIVE_MISSING', 'BEGIN_FORMING', 'OPEN_TARGET', 'MOVE', 'CLOSE_TARGET', 'COMPLETE']),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "code", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "sourceBoxCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "palletCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(32),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "barcode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(300),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "kiz", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "fingerprint", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PalletSortingActionDto.prototype, "confirmWriteOff", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PalletSortingActionDto.prototype, "confirmRestore", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], PalletSortingActionDto.prototype, "restoreFingerprint", void 0);
