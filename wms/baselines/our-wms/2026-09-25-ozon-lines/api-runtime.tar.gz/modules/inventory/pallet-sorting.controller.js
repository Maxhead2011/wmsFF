"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PalletSortingController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const pallet_sorting_service_1 = require("./pallet-sorting.service");
const pallet_sorting_dto_1 = require("./dto/pallet-sorting.dto");
// ADDED: web and TSD share the same authorized, idempotent workflow.
let PalletSortingController = class PalletSortingController {
    sorting;
    constructor(sorting) {
        this.sorting = sorting;
    }
    capabilities(user) { return this.sorting.capabilities(user); }
    list(user) { return this.sorting.list(user); }
    start(dto, user) { return this.sorting.start(dto, user); }
    get(id, user) { return this.sorting.get(id, user); }
    preview(id, kind, user) {
        return this.sorting.preview(id, kind === 'missing' ? 'missing' : 'remaining', user);
    }
    action(id, dto, user) { return this.sorting.action(id, dto, user); }
    routes(id, user) { return this.sorting.rebuildRoutes(id, user); }
};
exports.PalletSortingController = PalletSortingController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PalletSortingController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PalletSortingController.prototype, "list", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [pallet_sorting_dto_1.StartPalletSortingDto, Object]),
    __metadata("design:returntype", void 0)
], PalletSortingController.prototype, "start", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PalletSortingController.prototype, "get", null);
__decorate([
    (0, common_1.Get)(':id/preview'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('kind')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], PalletSortingController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(':id/actions'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, pallet_sorting_dto_1.PalletSortingActionDto, Object]),
    __metadata("design:returntype", void 0)
], PalletSortingController.prototype, "action", null);
__decorate([
    (0, common_1.Post)(':id/routes'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PalletSortingController.prototype, "routes", null);
exports.PalletSortingController = PalletSortingController = __decorate([
    (0, swagger_1.ApiTags)('pallet-sorting'),
    (0, common_1.Controller)('pallet-sorting')
    // FIX: every service entry enforces ADMIN + the installation flag. No second
    // stock:write permission is required; global authentication remains unchanged.
    ,
    __metadata("design:paramtypes", [pallet_sorting_service_1.PalletSortingService])
], PalletSortingController);
