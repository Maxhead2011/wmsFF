"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmedKizRediscovery = confirmedKizRediscovery;
const common_1 = require("@nestjs/common");
const kiz_physical_identity_1 = require("../../common/kiz-physical-identity");
// FIX: a receipt KIZ can be BLOCKED solely because a previous count did not find it.
// Call only after validating current physical scans and administrator scope, inside
// the same Serializable transaction. This proof does not credit stock or erase history.
async function confirmedKizRediscovery(tx, input) {
    const { mark, clientId, warehouseId, skuId, identity, startedAt } = input;
    if (process.env.WMS_INVENTORY_FOUND_KIZ_RESTORE_ENABLED !== 'true' ||
        mark.status !== 'BLOCKED' || mark.boxId !== null || !(mark.updatedAt < startedAt) ||
        mark.clientId !== clientId || mark.skuId !== skuId || (0, kiz_physical_identity_1.physicalKizIdentity)(mark.value) !== identity)
        return null;
    const proof = await tx.auditLog.findFirst({ where: {
            action: 'INVENTORY_KIZ_COMPOSITION_CONFIRMED', entity: 'InventoryAuditBox',
            createdAt: { gte: mark.updatedAt, lt: startedAt },
            payload: { path: ['archivedMarkIds'], array_contains: [mark.id] },
        }, orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
        select: { id: true, entityId: true, createdAt: true, payload: true } });
    const p = proof?.payload;
    if (!proof || !p || p.auditBoxId !== proof.entityId || p.clientId !== clientId || p.warehouseId !== warehouseId ||
        p.archiveReason !== 'Не подтверждено при пересчёте' || !Array.isArray(p.archivedMarkIds) ||
        !p.archivedMarkIds.includes(mark.id) || !Array.isArray(p.retiredMarks) ||
        typeof p.roundStartedAt !== 'string' || !(new Date(p.roundStartedAt) < mark.updatedAt) ||
        !(mark.updatedAt <= proof.createdAt && proof.createdAt < startedAt))
        return null;
    const previous = p.retiredMarks.filter((row) => Boolean(row) &&
        typeof row === 'object' && !Array.isArray(row) && row.id === mark.id);
    if (previous.length !== 1)
        return null;
    const old = previous[0];
    if (!['AVAILABLE', 'RESERVED'].includes(String(old.status)) || typeof old.boxId !== 'string' || old.boxId !== p.boxId ||
        old.clientId !== clientId || old.skuId !== skuId || typeof old.value !== 'string' ||
        (0, kiz_physical_identity_1.physicalKizIdentity)(old.value) !== identity || old.sourceDocument !== mark.sourceDocument ||
        old.stockMovementId !== mark.stockMovementId || typeof old.updatedAt !== 'string' ||
        !(new Date(old.updatedAt) < mark.updatedAt))
        return null;
    const prefixes = [identity, ']d2' + identity, ']D2' + identity];
    const where = { OR: prefixes.map(prefix => ({ kiz: { startsWith: prefix } })) };
    const history = await Promise.all([
        tx.fbsTsdAssembly.findFirst({ where, select: { id: true } }),
        tx.shippedKizHistory.findFirst({ where, select: { id: true } }),
        tx.fbsWebKizStickerPrint.findFirst({ where, select: { id: true } }),
        tx.fbsAssemblyAttemptHistory.findFirst({ where, select: { id: true } }),
        tx.fbsPrintJob.findFirst({ where, select: { id: true } }),
        tx.kizCirculationItem.findFirst({ where: { OR: prefixes.map(prefix => ({ kizRaw: { startsWith: prefix } })) }, select: { id: true } }),
        tx.fboAssemblyUnit.findFirst({ where: { OR: [{ markId: mark.id }, { activeMarkId: mark.id }, ...where.OR] }, select: { id: true } }),
        tx.wbOrderShipment.findFirst({ where, select: { id: true } }),
    ]);
    if (history.some(Boolean))
        throw new common_1.ConflictException('У найденного КИЗ есть история заказа или передачи. Нужна отдельная проверка возврата или переклейка КИЗ.');
    return { markId: mark.id, exclusionProofId: proof.id };
}
