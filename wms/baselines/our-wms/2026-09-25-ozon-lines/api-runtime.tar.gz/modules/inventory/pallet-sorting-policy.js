"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.canUsePalletSorting = canUsePalletSorting;
exports.assertSortingAdmin = assertSortingAdmin;
exports.missingSortingBoxes = missingSortingBoxes;
exports.confirmSortingSnapshot = confirmSortingSnapshot;
exports.sortingKizIdentity = sortingKizIdentity;
exports.sortingTaskCanReroute = sortingTaskCanReroute;
const common_1 = require("@nestjs/common");
// ADDED: opt-in, role-based, branch-scoped access; no effect on the sold installation.
// FIX: OWNER has ADMIN sorting authority without an additional role assignment.
function canUsePalletSorting(user) {
    return process.env.WMS_PALLET_SORTING_ENABLED === 'true' &&
        user.roleCodes.some(role => role === 'ADMIN' || role === 'OWNER') && !user.isDemo;
}
function assertSortingAdmin(user) {
    // FIX: the menu capability and all sorting actions share the same OWNER/ADMIN policy.
    if (!canUsePalletSorting(user)) {
        throw new common_1.ForbiddenException('Сортировка и перемещение доступны администратору и собственнику при включённом сервисе.');
    }
    if (!user.activeWarehouseId)
        throw new common_1.BadRequestException('Сначала выберите филиал.');
}
function missingSortingBoxes(expected, scanned) {
    if (scanned.some(id => !expected.includes(id)))
        throw new common_1.ConflictException('Короб не входит в исходный состав сортировки.');
    return expected.filter(id => !scanned.includes(id));
}
function confirmSortingSnapshot(current, supplied, consent, quantity) {
    if (!supplied || current !== supplied)
        throw new common_1.ConflictException('Остатки или задания изменились. Получите свежие расхождения и подтвердите их заново.');
    if (quantity > 0 && consent !== true)
        throw new common_1.ConflictException('Требуется отдельное подтверждение списания недостающего товара.');
}
function sortingKizIdentity(value) {
    const identity = value.trim().replace(/<GS>/gi, '\u001d').split('\u001d')[0];
    if (!/^01\d{14}21[^\u0000-\u001f]{13}$/.test(identity))
        throw new common_1.BadRequestException('Отсканируйте полный КИЗ товара.');
    return identity;
}
function sortingTaskCanReroute(task, removedBoxIds) {
    // FIX: a box scan alone can be rerouted; physical item scans and returns cannot be reset.
    return ['RESERVED', 'WAITING_STOCK', 'RELEASED', 'IN_PROGRESS'].includes(task.status) &&
        Boolean((task.boxId && removedBoxIds.includes(task.boxId)) ||
            (task.reservedBoxId && removedBoxIds.includes(task.reservedBoxId))) &&
        !task.barcode && !task.kiz && !task.sourceBarcode && !task.relabelConfirmedAt;
}
