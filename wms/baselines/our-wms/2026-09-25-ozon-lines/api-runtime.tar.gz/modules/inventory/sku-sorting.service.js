"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkuSortingService = void 0;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const archived_empty_box_pallet_detach_service_1 = require("../../common/boxes/archived-empty-box-pallet-detach.service");
const box_code_policy_service_1 = require("../../common/boxes/box-code-policy.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const stock_balances_service_1 = require("../stock/stock-balances.service");
const inventory_service_1 = require("./inventory.service");
const sku_sorting_policy_1 = require("./sku-sorting-policy");
const sku_collection_service_1 = require("./sku-collection.service");
// FIX: opt-in only on our WMS; the sold installation keeps its previous workflow.
const marker = '[SKU_SORTING_V2]';
const same = (a, b) => a.trim().toUpperCase() === b.trim().toUpperCase();
let SkuSortingService = class SkuSortingService {
    prisma;
    scopes;
    balances;
    collections;
    inventory;
    emptyBoxes;
    boxCodes;
    constructor(prisma, scopes, balances, collections, inventory, emptyBoxes, boxCodes) {
        this.prisma = prisma;
        this.scopes = scopes;
        this.balances = balances;
        this.collections = collections;
        this.inventory = inventory;
        this.emptyBoxes = emptyBoxes;
        this.boxCodes = boxCodes;
    }
    async request(db, id, user, statuses = ['APPROVED', 'IN_WORK', 'PACKED', 'DONE'], requireSorting = true) {
        if (requireSorting && !(0, sku_sorting_policy_1.skuSortingAllowed)(user, id))
            throw new common_1.ForbiddenException('Единая сортировка недоступна для этой пары ТСД и заявки.');
        const request = await db.clientRequest.findFirst({ where: { id, type: 'SKU_COLLECTION',
                status: { in: statuses } }, include: { skuCollectionSources: true } });
        if (!request)
            throw new common_1.BadRequestException('Активная заявка сортировки не найдена.');
        this.scopes.requireClientAccess(user, request.clientId, 'write');
        if (!request.warehouseId || request.warehouseId !== user.activeWarehouseId ||
            (!user.permissionCodes.includes('system:admin') && !(user.writableWarehouseIds ?? []).includes(request.warehouseId))) {
            throw new common_1.ForbiddenException('Заявка относится к другому или недоступному филиалу.');
        }
        return request;
    }
    // FIX: cancellation is opt-in independently of the existing TSD sorting workflow.
    cancelCapabilities(user) {
        return { canCancel: process.env.WMS_SKU_COLLECTION_CANCEL_ENABLED === 'true' && !user.isDemo &&
                !user.roleCodes?.includes('CLIENT') && user.permissionCodes.some(code => ['stock:write', 'system:admin'].includes(code)) };
    }
    async cancel(id, user) {
        if (!this.cancelCapabilities(user).canCancel)
            throw new common_1.ForbiddenException('Снятие задачи сборки по SKU недоступно.');
        return this.prisma.$transaction(async (tx) => {
            // FIX: the same lock as TSD pick/move/receive prevents cancellation racing a physical scan.
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "ClientRequest" WHERE "id" = ${id} FOR UPDATE`);
            const request = await this.request(tx, id, user, ['APPROVED', 'IN_WORK', 'PACKED', 'CANCELLED'], false);
            if (request.status === 'CANCELLED')
                return { id, status: client_1.ClientRequestStatus.CANCELLED };
            const previousStatus = request.status;
            const unreceived = await tx.skuCollectionScan.count({ where: { requestId: id, status: 'PICKED' } });
            if (unreceived || request.skuCollectionSources.some(source => source.pickedQuantity !== source.receivedQuantity)) {
                throw new common_1.ConflictException('Есть изъятый товар без завершённой приёмки. Сначала разместите его в коробах по ШК и КИЗ, затем снимите задачу.');
            }
            const counting = await tx.inventoryAuditBox.findFirst({ where: {
                    boxId: { in: request.skuCollectionSources.map(source => source.sourceBoxId) }, status: 'COUNTING',
                }, select: { id: true } });
            if (counting)
                throw new common_1.ConflictException('В исходном коробе идёт пересчёт. Завершите проверку перед снятием задачи.');
            if (!request.comment?.includes(marker))
                await this.releaseLegacyReservation(tx, request);
            await tx.clientRequest.update({ where: { id }, data: { status: 'CANCELLED', assignedToUserId: null } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'SKU_COLLECTION_CANCELLED', entity: 'ClientRequest', entityId: id,
                    payload: { clientId: request.clientId, warehouseId: request.warehouseId, previousStatus,
                        completedUnits: request.skuCollectionSources.reduce((sum, source) => sum + source.receivedQuantity, 0),
                        physicalMovementsPreserved: true, legacyReservationReleased: !request.comment?.includes(marker) } } });
            await tx.clientRequestEvent.create({ data: { requestId: id, clientId: request.clientId, eventType: 'STATUS_CHANGED',
                    title: 'Задача сборки по SKU снята', body: 'Задача убрана из активной очереди ВМС и ТСД. Выполненные перемещения и история сохранены.',
                    statusFrom: previousStatus, statusTo: 'CANCELLED', createdByUserId: user.id } });
            return { id, status: client_1.ClientRequestStatus.CANCELLED };
        }, { isolationLevel: 'Serializable', timeout: 30000 });
    }
    // FIX: start and cancellation release the same provable legacy reserve under the request lock.
    async releaseLegacyReservation(tx, request) {
        const id = request.id;
        await this.assertMovementAllowed(tx);
        for (const source of request.skuCollectionSources) {
            const remaining = source.plannedQuantity - source.pickedQuantity;
            if (remaining <= 0)
                continue;
            const scope = { warehouseId: request.warehouseId, clientId: request.clientId, skuId: source.skuId, boxId: source.sourceBoxId };
            const [reserved, evidence, assembly] = await Promise.all([
                tx.stockBalance.findMany({ where: { ...scope, status: 'RESERVED', quantity: { gt: 0 } } }),
                tx.stockMovement.aggregate({ where: { ...scope, sourceDocument: id, type: 'RESERVE', status: 'RESERVED' }, _sum: { quantity: true } }),
                tx.fbsTsdAssembly.findFirst({ where: { clientId: request.clientId, skuId: source.skuId,
                        status: { in: ['IN_PROGRESS', 'RETURN_REQUIRED'] }, OR: [{ boxId: source.sourceBoxId }, { reservedBoxId: source.sourceBoxId }] }, select: { id: true } }),
            ]);
            if (assembly || reserved.length !== 1 || reserved[0].quantity !== remaining ||
                (evidence._sum.quantity ?? 0) - source.pickedQuantity !== remaining) {
                throw new common_1.ConflictException(`Резерв короба ${source.sourceBoxCode} нельзя однозначно отнести к этой заявке. Остатки не изменены.`);
            }
            const row = reserved[0];
            await tx.stockBalance.delete({ where: { id: row.id } });
            const input = { ...scope, palletId: row.palletId, status: client_1.StockStatus.AVAILABLE };
            await tx.stockBalance.upsert({ where: { balanceKey: this.balances.balanceKey(input) },
                create: { ...input, balanceKey: this.balances.balanceKey(input), quantity: remaining }, update: { quantity: { increment: remaining } } });
            await tx.stockMovement.createMany({ data: [
                    { ...scope, palletId: row.palletId, type: 'RESERVE', status: 'RESERVED', quantity: -remaining, sourceDocument: id, comment: 'Снятие собственного резерва: сортировка без блокировки продаж' },
                    { ...scope, palletId: row.palletId, type: 'RESERVE', status: 'AVAILABLE', quantity: remaining, sourceDocument: id, comment: 'Снятие собственного резерва: сортировка без блокировки продаж' },
                ] });
            await tx.productMark.updateMany({ where: { clientId: request.clientId, skuId: source.skuId, boxId: source.sourceBoxId, status: 'RESERVED' }, data: { status: 'AVAILABLE' } });
        }
    }
    async start(id, user) {
        // FIX: explicit POST, never a mutating GET. Release only a provable legacy reservation once.
        await this.prisma.$transaction(async (tx) => {
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "ClientRequest" WHERE "id" = ${id} FOR UPDATE`);
            const request = await this.request(tx, id, user);
            if (request.comment?.includes(marker))
                return;
            await this.releaseLegacyReservation(tx, request);
            await tx.clientRequest.update({ where: { id }, data: { comment: `${request.comment ?? ''}\n${marker}` } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'SKU_SORTING_RESERVATION_RELEASED', entity: 'ClientRequest', entityId: id,
                    payload: { warehouseId: request.warehouseId, clientId: request.clientId } } });
        }, { isolationLevel: 'Serializable', timeout: 30000 });
        return this.collections.get(id, user);
    }
    async openSource(id, sourceBoxCode, user, recount = false) {
        const request = await this.request(this.prisma, id, user);
        if (!request.comment?.includes(marker))
            throw new common_1.ConflictException('Сначала откройте заявку в единой сортировке.');
        const source = request.skuCollectionSources.find(s => same(s.sourceBoxCode, sourceBoxCode));
        if (!source || source.pickedQuantity >= source.plannedQuantity)
            throw new common_1.BadRequestException('Этот короб не требуется в маршруте сортировки.');
        // FIX: counting is the existing inventory workflow, with original correction permissions.
        const title = `Сортировка №${request.number} · ${source.sourceBoxCode}`;
        let session = await this.prisma.inventorySession.findFirst({ where: { title, clientId: request.clientId,
                warehouseId: request.warehouseId, createdByUserId: user.id, status: 'ACTIVE' }, orderBy: { createdAt: 'desc' }, include: { boxes: { include: { lines: true } } } });
        const active = await this.prisma.inventoryAuditBox.findFirst({ where: { boxId: source.sourceBoxId, status: 'COUNTING' }, select: { sessionId: true } });
        if (active && active.sessionId !== session?.id)
            throw new common_1.ConflictException('Этот короб уже проверяет другой сотрудник.');
        if (recount) {
            if (active)
                throw new common_1.ConflictException('Сначала завершите текущий подсчёт. Его данные не удалены.');
            session = null; // FIX: preserve the old decisions and start a genuinely fresh snapshot.
        }
        if (!session)
            session = await this.inventory.startSession({ type: client_1.InventorySessionType.BOX_CHECK, clientId: request.clientId, title, comment: '[SKU_SORTING_SOURCE]' }, user);
        const existing = session.boxes.find(b => b.boxId === source.sourceBoxId);
        const box = existing ?? await this.inventory.openBox(session.id, source.sourceBoxCode, user, true);
        return { session, box };
    }
    async checkedSource(tx, id, dto, user) {
        const request = await this.request(tx, id, user);
        await this.assertMovementAllowed(tx);
        if (!request.comment?.includes(marker) || request.status === 'DONE')
            throw new common_1.ConflictException('Обновите заявку сортировки.');
        const source = request.skuCollectionSources.find(s => same(s.sourceBoxCode, dto.sourceBoxCode));
        if (!source)
            throw new common_1.BadRequestException('Исходный короб не входит в заявку.');
        const audit = await tx.inventoryAuditBox.findUnique({ where: { id: dto.auditBoxId }, include: { session: true, lines: true } });
        if (!audit || audit.boxId !== source.sourceBoxId || audit.clientId !== request.clientId || audit.session.warehouseId !== request.warehouseId ||
            !['MATCHED', 'RESOLVED'].includes(audit.status) || audit.lines.some(l => l.decision === 'PENDING' ||
            (l.difference && !l.decisionComment?.startsWith('[APPLY_ACTUAL]')))) {
            throw new common_1.ConflictException('Сначала завершите сверку и актуализацию исходного короба.');
        }
        const counting = await tx.inventoryAuditBox.findFirst({ where: { boxId: source.sourceBoxId, status: 'COUNTING' }, select: { id: true } });
        if (counting)
            throw new common_1.ConflictException('В исходном коробе начат новый подсчёт. Завершите его перед перемещением.');
        return { request, source, audit };
    }
    async ready(id, dto, user) {
        // FIX: refresh the route from actual AVAILABLE stock, including a now-empty source.
        await this.prisma.$transaction(async (tx) => {
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "ClientRequest" WHERE "id" = ${id} FOR UPDATE`);
            if ((await this.request(tx, id, user)).status === 'DONE')
                return; // FIX: retry after zero-stock completion.
            const { request, source } = await this.checkedSource(tx, id, dto, user);
            const total = await tx.stockBalance.aggregate({ where: { warehouseId: request.warehouseId, clientId: request.clientId,
                    skuId: source.skuId, boxId: source.sourceBoxId, status: 'AVAILABLE', quantity: { gt: 0 } }, _sum: { quantity: true } });
            await tx.skuCollectionSource.update({ where: { id: source.id }, data: { plannedQuantity: source.pickedQuantity + (total._sum.quantity ?? 0) } });
            await this.refreshTotals(tx, id);
        }, { isolationLevel: 'Serializable' });
        return this.collections.get(id, user);
    }
    async candidate(tx, id, dto, user) {
        const { request, source, audit } = await this.checkedSource(tx, id, dto, user);
        const sku = await tx.sku.findUnique({ where: { id: source.skuId }, include: { barcodes: true } });
        if (!sku?.barcodes.some(b => b.value === dto.barcode.trim()))
            throw new common_1.BadRequestException('ШК не соответствует SKU заявки.');
        // FIX: KIZ identity is case-sensitive. Never seize a mark already picked/shipped for another task.
        const identity = dto.kiz.trim().split('\u001d')[0];
        const mark = await tx.productMark.findFirst({ where: { clientId: request.clientId, value: { startsWith: identity } } });
        if (mark && (mark.skuId !== source.skuId || mark.boxId !== source.sourceBoxId || mark.status !== 'AVAILABLE')) {
            throw new common_1.ConflictException('КИЗ не числится доступным за этим товаром в исходном коробе. Остатки не изменены.');
        }
        const [assembly, shipped, printed] = await Promise.all([
            tx.fbsTsdAssembly.findFirst({ where: { kiz: { startsWith: identity }, status: { in: ['IN_PROGRESS', 'RETURN_REQUIRED', 'COMPLETED'] } }, select: { id: true } }),
            tx.shippedKizHistory.findFirst({ where: { kiz: { startsWith: identity } }, select: { id: true } }),
            tx.fbsWebKizStickerPrint.findFirst({ where: { kiz: { startsWith: identity } }, select: { id: true } }),
        ]);
        if (assembly || shipped || printed)
            throw new common_1.ConflictException('КИЗ связан с заказом или отгрузкой. Перемещение не выполнено.');
        const balance = await tx.stockBalance.findFirst({ where: { warehouseId: request.warehouseId, clientId: request.clientId, skuId: source.skuId,
                boxId: source.sourceBoxId, status: 'AVAILABLE', quantity: { gt: 0 } } });
        if (!balance)
            throw new common_1.ConflictException('Свободный товар в исходном коробе закончился. Обновите маршрут.');
        if (!mark) {
            // FIX: reuse actualization scan evidence to bind an unrecorded KIZ without adding stock.
            if (!/^01\d{14}21[^\u0000-\u001f]{13}$/.test(identity))
                throw new common_1.BadRequestException('Отсканируйте полный КИЗ единицы из проверки короба.');
            const evidenceId = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([dto.auditBoxId, audit.startedAt.toISOString(), identity])).digest('hex');
            const evidence = await tx.auditLog.findUnique({ where: { id: evidenceId } });
            const payload = evidence?.payload;
            const registered = await tx.productMark.count({ where: { clientId: request.clientId, skuId: source.skuId, boxId: source.sourceBoxId, status: 'AVAILABLE' } });
            if (evidence?.action !== 'INVENTORY_KIZ_SCAN' || payload?.skuId !== source.skuId || payload.boxId !== source.sourceBoxId || registered >= balance.quantity) {
                throw new common_1.ConflictException('Новый КИЗ не подтверждён этой актуализацией или все единицы уже имеют КИЗ. Остатки не изменены.');
            }
        }
        return { request, source, mark, balance };
    }
    async check(id, dto, user) {
        await this.candidate(this.prisma, id, dto, user);
        return { state: 'TARGET_BOX', message: 'Отсканируйте целевой короб. До этого остатки не перемещаются.' };
    }
    async move(id, dto, user) {
        await this.prisma.$transaction(async (tx) => {
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "ClientRequest" WHERE "id" = ${id} FOR UPDATE`);
            await this.request(tx, id, user);
            const existing = await tx.skuCollectionScan.findUnique({ where: { requestId_kiz: { requestId: id, kiz: dto.kiz.trim() } } });
            if (existing) {
                if (existing.status === 'RECEIVED' && same(existing.targetBoxCode ?? '', dto.targetBoxCode) && same(existing.sourceBoxCode, dto.sourceBoxCode) && existing.barcode === dto.barcode.trim())
                    return;
                throw new common_1.ConflictException('Этот КИЗ уже учтён в заявке. Для ранее отобранного товара используйте «Разместить отобранное».');
            }
            const { request, source, mark, balance } = await this.candidate(tx, id, dto, user);
            const target = await tx.box.findFirst({ where: { code: { equals: dto.targetBoxCode.trim(), mode: 'insensitive' },
                    clientId: request.clientId, warehouseId: request.warehouseId, status: { notIn: ['deleted', 'archived'] } } });
            if (!target || target.id === source.sourceBoxId)
                throw new common_1.BadRequestException('Нужен другой действующий целевой короб того же клиента и филиала.');
            const targetCounting = await tx.inventoryAuditBox.findFirst({ where: { boxId: target.id, status: 'COUNTING' }, select: { id: true } });
            if (targetCounting)
                throw new common_1.ConflictException('Целевой короб сейчас пересчитывается. Выберите другой или завершите проверку.');
            if (request.skuCollectionSources.some(s => s.sourceBoxId === target.id && s.pickedQuantity < s.plannedQuantity)) {
                throw new common_1.ConflictException('Целевой короб ещё есть в маршруте отбора. Выберите другой короб, чтобы не отбирать перемещённое повторно.');
            }
            const changed = await tx.stockBalance.updateMany({ where: { id: balance.id, quantity: { gte: 1 } }, data: { quantity: { decrement: 1 } } });
            if (changed.count !== 1)
                throw new common_1.ConflictException('Остаток изменился. Повторите сканирование.');
            const input = { warehouseId: request.warehouseId, clientId: request.clientId, skuId: source.skuId, boxId: target.id, palletId: target.palletId, status: client_1.StockStatus.AVAILABLE };
            await tx.stockBalance.upsert({ where: { balanceKey: this.balances.balanceKey(input) },
                create: { ...input, balanceKey: this.balances.balanceKey(input), quantity: 1 }, update: { quantity: { increment: 1 } } });
            const movementId = (0, node_crypto_1.randomUUID)();
            await tx.stockMovement.createMany({ data: [
                    { ...input, boxId: source.sourceBoxId, palletId: balance.palletId, type: 'MOVE', quantity: -1, sourceDocument: id, comment: `Сортировка: в ${target.code}` },
                    { ...input, id: movementId, type: 'MOVE', quantity: 1, sourceDocument: id, comment: `Сортировка: из ${source.sourceBoxCode}` },
                ] });
            if (mark) {
                const updated = await tx.productMark.updateMany({ where: { id: mark.id, boxId: source.sourceBoxId, status: 'AVAILABLE' }, data: { boxId: target.id, stockMovementId: movementId } });
                if (updated.count !== 1)
                    throw new common_1.ConflictException('КИЗ изменился параллельно. Остатки не изменены.');
            }
            else {
                await tx.productMark.create({ data: { clientId: request.clientId, skuId: source.skuId, value: dto.kiz.trim(), boxId: target.id,
                        status: 'AVAILABLE', sourceDocument: id, stockMovementId: movementId } });
            }
            await tx.skuCollectionScan.create({ data: { requestId: id, sourceId: source.id, skuId: source.skuId, barcode: dto.barcode.trim(), kiz: dto.kiz.trim(),
                    sourceBoxId: source.sourceBoxId, sourceBoxCode: source.sourceBoxCode, targetBoxId: target.id, targetBoxCode: target.code,
                    status: 'RECEIVED', pickedByUserId: user.id, pickedByName: user.name, receivedByUserId: user.id, receivedByName: user.name, receivedAt: new Date() } });
            await tx.skuCollectionSource.update({ where: { id: source.id }, data: {
                    plannedQuantity: source.pickedQuantity + balance.quantity, pickedQuantity: { increment: 1 }, receivedQuantity: { increment: 1 },
                } });
            await this.refreshTotals(tx, id);
            // FIX: sorting removes units, not the reusable source storage location.
            const archived = await (0, box_code_policy_service_1.preserveEmptyStorageBox)(source.sourceBoxCode, this.boxCodes)
                ? { count: 0 }
                : await tx.box.updateMany({ where: { id: source.sourceBoxId, balances: { none: { quantity: { gt: 0 } } } }, data: { status: 'archived' } });
            if (archived.count)
                await this.emptyBoxes.detachIfArchivedAndEmpty({ boxId: source.sourceBoxId, userId: user.id, reason: 'sku-sorting' }, tx);
        }, { isolationLevel: 'Serializable', timeout: 15000 });
        return this.collections.get(id, user);
    }
    async refreshTotals(tx, id) {
        const totals = await tx.skuCollectionSource.aggregate({ where: { requestId: id }, _sum: { plannedQuantity: true, pickedQuantity: true, receivedQuantity: true } });
        const planned = totals._sum.plannedQuantity ?? 0;
        await tx.clientRequestItem.updateMany({ where: { requestId: id }, data: { quantity: planned } });
        await tx.clientRequest.update({ where: { id }, data: { status: (totals._sum.receivedQuantity ?? 0) >= planned ? client_1.ClientRequestStatus.DONE : client_1.ClientRequestStatus.IN_WORK } });
    }
    async assertMovementAllowed(tx) {
        const full = await tx.inventorySession.findFirst({ where: { type: 'FULL', status: { in: ['ACTIVE', 'REVIEW'] } }, select: { id: true } });
        if (full)
            throw new common_1.ConflictException('Перемещения остановлены на время полной инвентаризации.');
    }
};
exports.SkuSortingService = SkuSortingService;
exports.SkuSortingService = SkuSortingService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        stock_balances_service_1.StockBalancesService,
        sku_collection_service_1.SkuCollectionService,
        inventory_service_1.InventoryService,
        archived_empty_box_pallet_detach_service_1.ArchivedEmptyBoxPalletDetachService,
        box_code_policy_service_1.BoxCodePolicyService])
], SkuSortingService);
