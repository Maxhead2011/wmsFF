"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpensesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const expenses_dto_1 = require("./dto/expenses.dto");
const expense_report_xlsx_1 = require("./expense-report-xlsx");
const expenses_service_1 = require("./expenses.service");
let ExpensesController = class ExpensesController {
    expenses;
    constructor(expenses) {
        this.expenses = expenses;
    }
    listEntries(query, user) {
        return this.expenses.listEntries(query, user);
    }
    createEntry(dto, user) {
        return this.expenses.createEntry(dto, user);
    }
    cancelEntry(id, user) {
        return this.expenses.cancelEntry(id, user);
    }
    listMaterials(user) {
        return this.expenses.listMaterials(user);
    }
    createMaterial(dto, user) {
        return this.expenses.createMaterial(dto, user);
    }
    updateMaterial(id, dto, user) {
        return this.expenses.updateMaterial(id, dto, user);
    }
    addMaterialStock(id, dto, user) {
        return this.expenses.addMaterialStock(id, dto, user);
    }
    listMaterialMovements(id, user) {
        return this.expenses.listMaterialMovements(id, user);
    }
    listClientMaterialRules(clientId, user) {
        return this.expenses.listClientMaterialRules(clientId, user);
    }
    upsertClientMaterialRule(clientId, materialId, dto, user) {
        return this.expenses.upsertClientMaterialRule(clientId, materialId, dto, user);
    }
    getReport(query, user) {
        return this.expenses.getReport(query, user);
    }
    getPayroll(query, user) {
        return this.expenses.getPayroll(query, user);
    }
    updatePayrollRate(userId, dto, user) {
        return this.expenses.updatePayrollRate(userId, dto, user);
    }
    resetPayrollCounter(userId, user) {
        return this.expenses.resetPayrollCounter(userId, user);
    }
    getDebts(clientId, user) {
        return this.expenses.getDebts(clientId, user);
    }
    async getReportXlsx(query, user, response) {
        const [report, debts] = await Promise.all([
            this.expenses.getReport(query, user),
            this.expenses.getDebts(query.clientId, user),
        ]);
        const fileName = `Расходы_${report.periodFrom.slice(0, 10)}_${report.periodTo.slice(0, 10)}.xlsx`;
        response.setHeader('Content-Type', expense_report_xlsx_1.expenseReportXlsxMimeType);
        response.setHeader('Content-Disposition', `attachment; filename="expenses.xlsx"; filename*=UTF-8''${encodeURIComponent(fileName)}`);
        return new common_1.StreamableFile((0, expense_report_xlsx_1.buildExpenseReportWorkbook)(report, debts));
    }
};
exports.ExpensesController = ExpensesController;
__decorate([
    (0, common_1.Get)('entries'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [expenses_dto_1.ListExpensesDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "listEntries", null);
__decorate([
    (0, common_1.Post)('entries'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [expenses_dto_1.CreateExpenseEntryDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "createEntry", null);
__decorate([
    (0, common_1.Patch)('entries/:id/cancel'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "cancelEntry", null);
__decorate([
    (0, common_1.Get)('materials'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "listMaterials", null);
__decorate([
    (0, common_1.Post)('materials'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [expenses_dto_1.CreateExpenseMaterialDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "createMaterial", null);
__decorate([
    (0, common_1.Patch)('materials/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, expenses_dto_1.UpdateExpenseMaterialDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "updateMaterial", null);
__decorate([
    (0, common_1.Post)('materials/:id/stock'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, expenses_dto_1.AddExpenseMaterialStockDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "addMaterialStock", null);
__decorate([
    (0, common_1.Get)('materials/:id/movements'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "listMaterialMovements", null);
__decorate([
    (0, common_1.Get)('clients/:clientId/material-rules'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "listClientMaterialRules", null);
__decorate([
    (0, common_1.Put)('clients/:clientId/material-rules/:materialId'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Param)('materialId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, expenses_dto_1.UpsertClientExpenseMaterialRuleDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "upsertClientMaterialRule", null);
__decorate([
    (0, common_1.Get)('report'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [expenses_dto_1.ListExpensesDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "getReport", null);
__decorate([
    (0, common_1.Get)('payroll'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [expenses_dto_1.ListExpensesDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "getPayroll", null);
__decorate([
    (0, common_1.Put)('payroll/users/:userId/rate'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('userId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, expenses_dto_1.UpdateExpensePayrollRateDto, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "updatePayrollRate", null);
__decorate([
    (0, common_1.Post)('payroll/users/:userId/reset'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('userId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "resetPayrollCounter", null);
__decorate([
    (0, common_1.Get)('debts'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ExpensesController.prototype, "getDebts", null);
__decorate([
    (0, common_1.Get)('report.xlsx'),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [expenses_dto_1.ListExpensesDto, Object, Object]),
    __metadata("design:returntype", Promise)
], ExpensesController.prototype, "getReportXlsx", null);
exports.ExpensesController = ExpensesController = __decorate([
    (0, swagger_1.ApiTags)('expenses'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:read'),
    (0, common_1.Controller)('expenses'),
    __metadata("design:paramtypes", [expenses_service_1.ExpensesService])
], ExpensesController);
