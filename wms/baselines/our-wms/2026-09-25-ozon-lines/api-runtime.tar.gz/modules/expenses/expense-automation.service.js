"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpenseAutomationService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
let ExpenseAutomationService = class ExpenseAutomationService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async consumeForDoneRequest(requestId, user) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: {
                id: true,
                number: true,
                title: true,
                clientId: true,
                status: true,
                updatedAt: true,
                items: { select: { quantity: true } },
                client: {
                    select: {
                        expenseMaterialRules: {
                            where: { isEnabled: true, material: { isActive: true } },
                            include: { material: true },
                            orderBy: { material: { name: 'asc' } },
                        },
                    },
                },
            },
        });
        if (!request || request.status !== client_1.ClientRequestStatus.DONE) {
            return {
                status: 'SKIPPED',
                reason: 'REQUEST_NOT_DONE',
                consumedMaterials: 0,
                billingCharges: 0,
                shortages: [],
            };
        }
        const shippedUnits = request.items.reduce((sum, item) => sum + Math.max(0, item.quantity), 0);
        if (shippedUnits <= 0 || request.client.expenseMaterialRules.length === 0) {
            return {
                status: 'APPLIED',
                shippedUnits,
                consumedMaterials: 0,
                billingCharges: 0,
                shortages: [],
            };
        }
        let consumedMaterials = 0;
        let billingCharges = 0;
        const shortages = [];
        for (const rule of request.client.expenseMaterialRules) {
            const sourceKey = `request-material:${request.id}:${rule.id}`;
            const result = await this.prisma.$transaction(async (tx) => {
                const existing = await tx.expenseMaterialMovement.findUnique({
                    where: { sourceKey },
                    select: { id: true },
                });
                if (existing)
                    return { applied: false, charged: false, stock: null };
                const freshMaterial = await tx.expenseMaterial.findUnique({
                    where: { id: rule.materialId },
                });
                if (!freshMaterial || !freshMaterial.isActive) {
                    return { applied: false, charged: false, stock: null };
                }
                const quantity = roundQuantity(shippedUnits * Number(rule.quantityPerShippedUnit));
                if (quantity <= 0) {
                    return { applied: false, charged: false, stock: null };
                }
                const currentStock = Number(freshMaterial.stockQuantity);
                const nextStock = roundQuantity(currentStock - quantity);
                const internalUnitCost = Number(freshMaterial.averageUnitCostRub);
                const internalAmount = roundMoney(quantity * internalUnitCost);
                const expense = await tx.expenseEntry.create({
                    data: {
                        category: client_1.ExpenseCategory.MATERIALS,
                        source: client_1.ExpenseSource.AUTO_MATERIAL_CONSUMPTION,
                        expenseDate: request.updatedAt,
                        amountRub: moneyDecimal(internalAmount),
                        description: `Расход на заявку №${String(request.number).padStart(6, '0')}: ${freshMaterial.name}`,
                        clientId: request.clientId,
                        requestId: request.id,
                        materialId: freshMaterial.id,
                        quantity: quantityDecimal(quantity),
                        unit: freshMaterial.unit,
                        unitPriceRub: costDecimal(internalUnitCost),
                        sourceKey,
                        comment: `Автоматически: ${shippedUnits} отправленных ед. × ${Number(rule.quantityPerShippedUnit)} ${freshMaterial.unit}.`,
                        createdByUserId: user.id,
                    },
                });
                await tx.expenseMaterialMovement.create({
                    data: {
                        materialId: freshMaterial.id,
                        type: client_1.ExpenseMaterialMovementType.CONSUMPTION,
                        quantity: quantityDecimal(-quantity),
                        unitCostRub: costDecimal(internalUnitCost),
                        clientId: request.clientId,
                        requestId: request.id,
                        expenseEntryId: expense.id,
                        sourceKey,
                        comment: `Заявка №${String(request.number).padStart(6, '0')}: ${request.title}`,
                        createdByUserId: user.id,
                    },
                });
                await tx.expenseMaterial.update({
                    where: { id: freshMaterial.id },
                    data: { stockQuantity: quantityDecimal(nextStock) },
                });
                let charged = false;
                if (rule.chargeSeparately) {
                    const unitPrice = Number(rule.billingUnitPriceRub ?? 0);
                    await tx.billingCharge.create({
                        data: {
                            clientId: request.clientId,
                            requestId: request.id,
                            description: `Расходный материал: ${freshMaterial.name}`,
                            unit: client_1.BillingUnit.PIECE,
                            quantity: quantityDecimal(quantity),
                            unitPriceRub: moneyDecimal(unitPrice),
                            totalRub: moneyDecimal(quantity * unitPrice),
                            status: client_1.BillingChargeStatus.APPROVED,
                            serviceDate: request.updatedAt,
                            source: client_1.BillingChargeSource.MANUAL,
                            sourceKey: `expense-material-charge:${request.id}:${rule.id}`,
                            metadata: {
                                expenseMaterialId: freshMaterial.id,
                                expenseMaterialCode: freshMaterial.code,
                                autoConsumption: true,
                                shippedUnits,
                                quantityPerShippedUnit: Number(rule.quantityPerShippedUnit),
                                includedInProcessing: false,
                            },
                            comment: `Автоматическое отдельное начисление расходного материала по заявке №${String(request.number).padStart(6, '0')}.`,
                            createdByUserId: user.id,
                            approvedByUserId: user.id,
                            approvedAt: new Date(),
                        },
                    });
                    charged = true;
                }
                return {
                    applied: true,
                    charged,
                    stock: {
                        materialId: freshMaterial.id,
                        materialName: freshMaterial.name,
                        stockQuantity: nextStock,
                        shortageQuantity: Math.max(0, -nextStock),
                        unit: freshMaterial.unit,
                    },
                };
            }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
            if (!result.applied)
                continue;
            consumedMaterials += 1;
            if (result.charged)
                billingCharges += 1;
            if (result.stock && result.stock.shortageQuantity > 0) {
                shortages.push(result.stock);
            }
        }
        return {
            status: 'APPLIED',
            shippedUnits,
            consumedMaterials,
            billingCharges,
            shortages,
        };
    }
};
exports.ExpenseAutomationService = ExpenseAutomationService;
exports.ExpenseAutomationService = ExpenseAutomationService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ExpenseAutomationService);
function quantityDecimal(value) {
    return new client_1.Prisma.Decimal(roundQuantity(value).toFixed(3));
}
function moneyDecimal(value) {
    return new client_1.Prisma.Decimal(roundMoney(value).toFixed(2));
}
function costDecimal(value) {
    return new client_1.Prisma.Decimal(roundCost(value).toFixed(4));
}
function roundQuantity(value) {
    return Math.round((value + Number.EPSILON) * 1000) / 1000;
}
function roundMoney(value) {
    return Math.round((value + Number.EPSILON) * 100) / 100;
}
function roundCost(value) {
    return Math.round((value + Number.EPSILON) * 10000) / 10000;
}
