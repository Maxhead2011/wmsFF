"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientRequestFileSummarySelect = exports.ClientRequestFilesService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_notification_preferences_1 = require("../client-notifications/client-notification-preferences");
const telegram_notification_service_1 = require("../client-notifications/telegram-notification.service");
const manual_pick_instruction_1 = require("../stock/manual-pick-instruction");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const maxFileSizeBytes = 10 * 1024 * 1024;
let ClientRequestFilesService = class ClientRequestFilesService {
    prisma;
    clientScopes;
    telegram;
    constructor(prisma, clientScopes, telegram) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.telegram = telegram;
    }
    async listForRequest(requestId, user) {
        const request = await this.getRequestForAccess(requestId);
        this.clientScopes.requireClientAccess(user, request.clientId, 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'read', 'Заявка не найдена в выбранном филиале.');
        const files = await this.prisma.clientRequestFile.findMany({
            where: { requestId, NOT: { fileName: { startsWith: manual_pick_instruction_1.manualPickInstructionPlanFilePrefix } } },
            select: exports.clientRequestFileSummarySelect,
            orderBy: { createdAt: 'desc' },
        });
        return files.map((file) => ({ ...file, fileName: normalizeFileName(file.fileName) }));
    }
    async uploadToRequest(requestId, file, user) {
        if (!file?.buffer?.length) {
            throw new common_1.BadRequestException('Файл не передан.');
        }
        if (file.size > maxFileSizeBytes) {
            throw new common_1.BadRequestException('Файл больше 10 МБ.');
        }
        const request = await this.getRequestForAccess(requestId);
        this.clientScopes.requireClientAccess(user, request.clientId, 'write');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'write', 'Заявка не найдена в выбранном филиале.');
        const notifyClient = await (0, client_notification_preferences_1.isClientNotificationEnabled)(this.prisma, request.clientId, client_1.ClientNotificationEvent.REQUEST_FILE_UPLOADED);
        // Русский комментарий: файл хранится рядом с заявкой, чтобы клиент видел вложения без внешнего файлового сервиса.
        const savedFile = await this.prisma.$transaction(async (tx) => {
            const savedFile = await tx.clientRequestFile.create({
                data: {
                    requestId,
                    clientId: request.clientId,
                    fileName: normalizeFileName(file.originalname),
                    mimeType: file.mimetype || 'application/octet-stream',
                    sizeBytes: file.size,
                    content: Uint8Array.from(file.buffer),
                    uploadedByUserId: user.id,
                },
                select: exports.clientRequestFileSummarySelect,
            });
            if (notifyClient) {
                await tx.clientNotification.create({
                    data: {
                        clientId: request.clientId,
                        requestId,
                        title: 'Добавлен файл к заявке',
                        body: `${savedFile.fileName} · ${request.title}`,
                        severity: 'INFO',
                        createdByUserId: user.id,
                    },
                });
            }
            await tx.clientRequestEvent.create({
                data: {
                    requestId,
                    clientId: request.clientId,
                    eventType: client_1.ClientRequestEventType.FILE_UPLOADED,
                    title: 'Файл приложен к заявке',
                    body: savedFile.fileName,
                    createdByUserId: user.id,
                },
            });
            return savedFile;
        });
        if (notifyClient) {
            void this.telegram?.notifyClient(request.clientId, ['LOGOFF WMS: файл добавлен к заявке.', `Заявка: ${request.title}`, `Файл: ${savedFile.fileName}`].join('\n'));
        }
        return savedFile;
    }
    async getFileContent(requestId, fileId, user) {
        const request = await this.getRequestForAccess(requestId);
        this.clientScopes.requireClientAccess(user, request.clientId, 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'read', 'Заявка не найдена в выбранном филиале.');
        const file = await this.prisma.clientRequestFile.findFirst({
            where: { id: fileId, requestId },
            select: {
                ...exports.clientRequestFileSummarySelect,
                content: true,
            },
        });
        if (!file) {
            throw new common_1.NotFoundException('Файл заявки не найден.');
        }
        if (file.fileName.startsWith(manual_pick_instruction_1.manualPickInstructionPlanFilePrefix)) {
            throw new common_1.NotFoundException('Файл заявки не найден.');
        }
        return { ...file, fileName: normalizeFileName(file.fileName) };
    }
    async getRequestForAccess(requestId) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: { id: true, clientId: true, warehouseId: true, title: true },
        });
        if (!request) {
            throw new common_1.NotFoundException('Клиентская заявка не найдена.');
        }
        return request;
    }
};
exports.ClientRequestFilesService = ClientRequestFilesService;
exports.ClientRequestFilesService = ClientRequestFilesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        telegram_notification_service_1.TelegramNotificationService])
], ClientRequestFilesService);
exports.clientRequestFileSummarySelect = {
    id: true,
    requestId: true,
    clientId: true,
    fileName: true,
    mimeType: true,
    sizeBytes: true,
    uploadedByUserId: true,
    createdAt: true,
    uploadedBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
};
function normalizeFileName(value) {
    const source = value?.trim() ?? '';
    const mojibakeStart = source.search(/[ÃÐÑ]/);
    const decoded = mojibakeStart >= 0
        ? `${source.slice(0, mojibakeStart)}${Buffer.from(source.slice(mojibakeStart), 'latin1').toString('utf8')}`
        : source;
    const readable = decoded.includes('�') ? source : decoded;
    const normalized = readable.replace(/[\\/:*?"<>|]+/g, '_').trim();
    return normalized || 'attachment.bin';
}
