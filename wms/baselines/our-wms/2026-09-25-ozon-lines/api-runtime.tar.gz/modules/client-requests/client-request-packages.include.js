"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientRequestPackageInclude = void 0;
exports.clientRequestPackageInclude = {
    createdBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
    items: {
        include: {
            requestItem: {
                select: {
                    id: true,
                    barcode: true,
                    name: true,
                    quantity: true,
                    sku: {
                        select: {
                            id: true,
                            internalSku: true,
                            name: true,
                        },
                    },
                },
            },
            sku: {
                select: {
                    id: true,
                    internalSku: true,
                    name: true,
                },
            },
        },
        orderBy: {
            id: 'asc',
        },
    },
};
