"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestXlsxService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const XLSX = __importStar(require("xlsx"));
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_requests_service_1 = require("./client-requests.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const outbound_request_xlsx_parser_1 = require("./parsers/outbound-request-xlsx.parser");
let ClientRequestXlsxService = class ClientRequestXlsxService {
    prisma;
    clientScopes;
    clientRequests;
    constructor(prisma, clientScopes, clientRequests) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.clientRequests = clientRequests;
    }
    async previewOutboundRequest(file, dto, user) {
        this.assertFile(file);
        return this.buildPreview(file.buffer, dto, user);
    }
    async createOutboundRequest(file, dto, user) {
        this.assertFile(file);
        const preview = await this.buildPreview(file.buffer, dto, user);
        const errors = preview.issues.filter((issue) => issue.severity === 'error');
        if (errors.length > 0) {
            throw new common_1.BadRequestException({
                message: 'Excel-файл содержит ошибки, заявка не создана.',
                errors,
                summary: preview.summary,
            });
        }
        const request = await this.clientRequests.create({
            clientId: preview.clientId,
            // FIX: creation must use the same branch as the Excel availability check.
            warehouseId: dto.warehouseId,
            type: client_1.ClientRequestType.OUTBOUND,
            priority: dto.priority ?? client_1.ClientRequestPriority.NORMAL,
            title: preview.title,
            comment: this.buildImportComment(dto.comment, normalizeUploadedFileName(file.originalname), preview),
            contactName: normalizeText(dto.contactName),
            contactPhone: normalizeText(dto.contactPhone),
            destinationCity: normalizeRequiredText(dto.destinationCity, 'Город поставки обязателен.'),
            deliveryAddress: normalizeText(dto.deliveryAddress),
            desiredDate: dto.desiredDate,
            items: preview.lines.flatMap((line) => this.buildRequestItemsFromLine(line)),
        }, user);
        await this.attachSourceWorkbook(request.id, request.clientId, file, user);
        return {
            request,
            preview,
        };
    }
    async buildPreview(buffer, dto, user) {
        const clientId = normalizeRequiredText(dto.clientId, 'Клиент обязателен.');
        normalizeRequiredText(dto.destinationCity, 'Город поставки обязателен.');
        this.clientScopes.requireClientAccess(user, clientId, 'write');
        // FIX: client users select the branch per request; internal scope still takes precedence.
        const warehouseId = ((0, client_request_warehouse_scope_1.effectiveWarehouseId)(user, 'write') ?? (user.roleCodes.includes('CLIENT')
            ? dto.warehouseId?.trim()
            : user.activeWarehouseId || dto.warehouseId?.trim())) || undefined;
        const parsed = (0, outbound_request_xlsx_parser_1.parseOutboundRequestXlsxRows)(this.readFirstSheet(buffer));
        const barcodes = parsed.lines.map((line) => line.barcode).filter((barcode) => Boolean(barcode));
        const productNames = [
            ...new Set(parsed.lines
                .map((line) => line.name || line.artSeller)
                .map((value) => normalizeText(value))
                .filter((value) => Boolean(value))),
        ];
        const barcodeRows = barcodes.length
            ? await this.prisma.barcode.findMany({
                where: {
                    value: { in: barcodes },
                    sku: { clientId },
                },
                include: {
                    sku: {
                        select: {
                            id: true,
                            internalSku: true,
                            clientSku: true,
                            article: true,
                            name: true,
                            size: true,
                            needsRelabel: true,
                            barcodes: {
                                select: {
                                    value: true,
                                    isPrimary: true,
                                },
                            },
                        },
                    },
                },
            })
            : [];
        const skuRows = productNames.length
            ? await this.prisma.sku.findMany({
                where: {
                    clientId,
                    OR: [
                        { internalSku: { in: productNames } },
                        { clientSku: { in: productNames } },
                        { article: { in: productNames } },
                        { name: { in: productNames } },
                    ],
                },
                select: {
                    id: true,
                    internalSku: true,
                    clientSku: true,
                    article: true,
                    name: true,
                    size: true,
                    needsRelabel: true,
                    barcodes: {
                        select: {
                            value: true,
                            isPrimary: true,
                        },
                    },
                },
            })
            : [];
        const barcodeMatches = new Map();
        for (const row of barcodeRows) {
            barcodeMatches.set(row.value, [...(barcodeMatches.get(row.value) ?? []), row]);
        }
        const skuMatches = buildSkuMatchesByProductName(skuRows);
        const resolvedLines = parsed.lines.map((line) => this.resolveParsedLine(line, barcodeMatches, skuMatches));
        const actionSuggestionsByLine = await this.buildCatalogActionSuggestions(clientId, parsed.lines, resolvedLines, skuMatches, warehouseId);
        const relabelSourceOptions = await this.buildRelabelSourceOptions(clientId, warehouseId);
        const availability = await this.clientRequests.previewAvailability({
            clientId,
            warehouseId: dto.warehouseId,
            type: client_1.ClientRequestType.OUTBOUND,
            items: resolvedLines.map(({ line, match }) => ({
                skuId: match && match !== 'duplicate' ? match.sku.id : undefined,
                barcode: line.barcode,
                quantity: line.quantity,
            })),
        }, user);
        const issues = [...parsed.issues];
        const lines = [];
        for (const [lineIndex, resolvedLine] of resolvedLines.entries()) {
            const { line, match, issueMessage } = resolvedLine;
            const firstRow = line.sourceRows[0] ?? 1;
            const availabilityLine = availability.lines[lineIndex];
            const actionSuggestions = actionSuggestionsByLine.get(lineIndex) ?? [];
            if (!match) {
                issues.push({
                    row: firstRow,
                    barcode: line.barcode,
                    message: issueMessage,
                    severity: 'error',
                });
                lines.push(this.emptyHydratedLine(line, actionSuggestions));
                continue;
            }
            if (match === 'duplicate') {
                issues.push({
                    row: firstRow,
                    barcode: line.barcode,
                    message: issueMessage,
                    severity: 'error',
                });
                lines.push(this.emptyHydratedLine(line, actionSuggestions));
                continue;
            }
            const stockQuantity = availabilityLine?.stockQuantity ?? 0;
            const reservedQuantity = availabilityLine?.reservedQuantity ?? 0;
            const availableQuantity = availabilityLine?.availableQuantity ?? 0;
            const shortageQuantity = Math.max(0, line.quantity - availableQuantity);
            const conflicts = availabilityLine?.conflicts ?? [];
            if (shortageQuantity > 0) {
                issues.push({
                    row: firstRow,
                    barcode: line.barcode,
                    message: shortageMessage(line.quantity, availableQuantity, conflicts),
                    severity: 'error',
                });
            }
            lines.push({
                barcode: line.barcode,
                originalName: line.name || line.artSeller,
                requestedQuantity: line.quantity,
                relabelTargetBarcode: line.relabelTargetBarcode,
                relabelQuantity: line.relabelQuantity,
                city: line.city,
                artSeller: line.artSeller,
                size: line.size,
                needsRelabel: Boolean(match.sku.needsRelabel),
                stockQuantity,
                reservedQuantity,
                availableQuantity,
                shortageQuantity,
                sourceRows: line.sourceRows,
                skuId: match.sku.id,
                internalSku: match.sku.internalSku,
                name: match.sku.name,
                canFulfill: shortageQuantity === 0,
                conflicts,
                actionSuggestions,
            });
        }
        const totalAvailableQuantity = lines.reduce((sum, line) => sum + Math.min(line.availableQuantity, line.requestedQuantity), 0);
        const totalShortageQuantity = lines.reduce((sum, line) => sum + line.shortageQuantity, 0);
        const errorsCount = issues.filter((issue) => issue.severity === 'error').length;
        return {
            clientId,
            title: normalizeText(dto.title) ?? defaultTitle(),
            canCommit: errorsCount === 0 && lines.length > 0,
            summary: {
                ...parsed.summary,
                availableQuantity: totalAvailableQuantity,
                shortageQuantity: totalShortageQuantity,
            },
            issues,
            relabelSourceOptions,
            lines,
        };
    }
    readFirstSheet(buffer) {
        // Русский комментарий: для клиентского шаблона берем первый лист, чтобы файл мог называться и оформляться свободно.
        const workbook = XLSX.read(buffer, { type: 'buffer' });
        const firstSheet = workbook.SheetNames[0];
        if (!firstSheet) {
            throw new common_1.BadRequestException('В Excel-файле нет листов.');
        }
        return XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet], {
            header: 1,
            raw: false,
            blankrows: false,
        });
    }
    resolveParsedLine(line, barcodeMatches, skuMatches) {
        if (line.barcode) {
            const matches = barcodeMatches.get(line.barcode) ?? [];
            if (matches.length === 0) {
                return { line, match: null, issueMessage: 'Баркод не найден в SKU клиента.' };
            }
            const uniqueMatches = uniqueSkus(matches.map((match) => match.sku));
            if (uniqueMatches.length !== 1) {
                return { line, match: 'duplicate', issueMessage: 'Баркод привязан к нескольким SKU клиента.' };
            }
            const skuByBarcode = uniqueMatches[0];
            if (line.size && !sizesMatch(skuByBarcode.size, line.size)) {
                return {
                    line,
                    match: null,
                    issueMessage: 'Размер в файле не совпадает с размером SKU по баркоду.',
                };
            }
            const productName = normalizeText(line.name || line.artSeller);
            if (productName) {
                const matchesByName = filterSkusBySize(skuMatches.get(normalizeLookupKey(productName)) ?? [], line.size);
                if (matchesByName.length === 0) {
                    return {
                        line,
                        match: null,
                        issueMessage: line.size
                            ? 'Баркод найден, но наименование и размер не найдены в SKU клиента.'
                            : 'Баркод найден, но наименование товара не найдено в SKU клиента.',
                    };
                }
                if (!matchesByName.some((sku) => sku.id === skuByBarcode.id)) {
                    return {
                        line,
                        match: null,
                        issueMessage: line.size
                            ? 'Баркод, наименование и размер относятся к разным SKU клиента.'
                            : 'Баркод и наименование товара относятся к разным SKU клиента.',
                    };
                }
            }
            return { line, match: { sku: skuByBarcode }, issueMessage: '' };
        }
        const productName = normalizeText(line.name || line.artSeller);
        if (!productName) {
            return { line, match: null, issueMessage: 'Не заполнен товар или баркод.' };
        }
        const allMatches = skuMatches.get(normalizeLookupKey(productName)) ?? [];
        const matches = filterSkusBySize(allMatches, line.size);
        if (matches.length === 0) {
            return {
                line,
                match: null,
                issueMessage: allMatches.length > 0 && line.size
                    ? 'Наименование найдено, но размер не совпал ни с одним SKU клиента.'
                    : 'Наименование товара не найдено в SKU клиента.',
            };
        }
        return matches.length === 1
            ? { line, match: { sku: matches[0] }, issueMessage: '' }
            : { line, match: 'duplicate', issueMessage: 'Наименование товара совпало с несколькими SKU клиента.' };
    }
    emptyHydratedLine(line, actionSuggestions = []) {
        return {
            barcode: line.barcode,
            originalName: line.name || line.artSeller,
            requestedQuantity: line.quantity,
            relabelTargetBarcode: line.relabelTargetBarcode,
            relabelQuantity: line.relabelQuantity,
            city: line.city,
            artSeller: line.artSeller,
            size: line.size,
            needsRelabel: false,
            stockQuantity: 0,
            reservedQuantity: 0,
            availableQuantity: 0,
            shortageQuantity: line.quantity,
            sourceRows: line.sourceRows,
            skuId: null,
            internalSku: null,
            name: null,
            canFulfill: false,
            conflicts: [],
            actionSuggestions,
        };
    }
    async buildCatalogActionSuggestions(clientId, lines, resolvedLines, skuMatches, warehouseId) {
        const candidateSkuIds = new Set();
        const lineCandidates = new Map();
        lines.forEach((line, index) => {
            const productName = normalizeText(line.name || line.artSeller);
            const targetBarcode = line.barcode || line.relabelTargetBarcode;
            if (!productName || !targetBarcode) {
                return;
            }
            const candidates = filterSkusBySize(skuMatches.get(normalizeLookupKey(productName)) ?? [], line.size);
            const currentSkuId = resolvedLines[index]?.match && resolvedLines[index].match !== 'duplicate' ? resolvedLines[index].match.sku.id : null;
            const relabelCandidates = candidates.filter((sku) => sku.id !== currentSkuId || !skuHasBarcode(sku, targetBarcode));
            if (relabelCandidates.length === 0) {
                return;
            }
            lineCandidates.set(index, relabelCandidates);
            relabelCandidates.forEach((sku) => candidateSkuIds.add(sku.id));
        });
        const stockBySkuId = await this.stockQuantityBySkuId(clientId, [...candidateSkuIds], warehouseId);
        const nomenclatureByBarcode = await this.nomenclatureByBarcode(lines.map((line) => line.barcode).filter((barcode) => Boolean(barcode)));
        const result = new Map();
        lines.forEach((line, index) => {
            const targetBarcode = line.barcode || line.relabelTargetBarcode;
            const suggestions = [];
            for (const sku of lineCandidates.get(index) ?? []) {
                const availableQuantity = stockBySkuId.get(sku.id) ?? 0;
                if (!targetBarcode || availableQuantity <= 0) {
                    continue;
                }
                const sourceBarcode = primaryBarcodeValue(sku);
                suggestions.push({
                    type: 'RELABEL',
                    title: 'Можно переклеить',
                    message: `В каталоге найден ${sku.internalSku} с остатком ${availableQuantity} шт. Можно взять этот SKU и переклеить на ${targetBarcode}.`,
                    sourceSkuId: sku.id,
                    sourceInternalSku: sku.internalSku,
                    sourceName: sku.name,
                    sourceBarcode: sourceBarcode ?? undefined,
                    targetBarcode,
                    availableQuantity,
                    quantity: Math.min(line.quantity, availableQuantity),
                });
            }
            if (suggestions.length === 0 && targetBarcode && nomenclatureByBarcode.has(targetBarcode)) {
                const item = nomenclatureByBarcode.get(targetBarcode);
                suggestions.push({
                    type: 'CREATE_SKU',
                    title: 'Есть в общей номенклатуре',
                    message: `Баркод есть в общем справочнике: ${item.name}. Создайте SKU клиента или загрузите остатки по этому товару.`,
                    targetBarcode,
                });
            }
            if (suggestions.length > 0) {
                result.set(index, suggestions);
            }
        });
        return result;
    }
    async stockQuantityBySkuId(clientId, skuIds, warehouseId) {
        const stockBalance = this.prisma.stockBalance;
        if (skuIds.length === 0 || !stockBalance?.groupBy) {
            return new Map();
        }
        const rows = await stockBalance.groupBy({
            by: ['skuId'],
            where: {
                clientId,
                warehouseId,
                skuId: { in: skuIds },
                status: client_1.StockStatus.AVAILABLE,
            },
            _sum: { quantity: true },
        });
        return new Map(rows.map((row) => [row.skuId, Number(row._sum.quantity ?? 0)]));
    }
    async nomenclatureByBarcode(barcodes) {
        const nomenclatureItem = this.prisma.nomenclatureItem;
        if (barcodes.length === 0 || !nomenclatureItem?.findMany) {
            return new Map();
        }
        const rows = await nomenclatureItem.findMany({
            where: { barcode: { in: [...new Set(barcodes)] } },
            select: { barcode: true, name: true },
        });
        return new Map(rows.filter((row) => row.barcode).map((row) => [row.barcode, { barcode: row.barcode, name: row.name }]));
    }
    async buildRelabelSourceOptions(clientId, warehouseId) {
        const stockBalance = this.prisma.stockBalance;
        if (!stockBalance?.findMany) {
            return [];
        }
        const rows = await stockBalance.findMany({
            where: {
                clientId,
                warehouseId,
                status: client_1.StockStatus.AVAILABLE,
                quantity: { gt: 0 },
            },
            select: {
                skuId: true,
                quantity: true,
                sku: {
                    select: {
                        id: true,
                        internalSku: true,
                        clientSku: true,
                        article: true,
                        name: true,
                        size: true,
                        barcodes: {
                            select: {
                                value: true,
                                isPrimary: true,
                            },
                        },
                    },
                },
            },
        });
        const bySku = new Map();
        for (const row of rows) {
            const existing = bySku.get(row.skuId);
            bySku.set(row.skuId, {
                sku: row.sku,
                availableQuantity: (existing?.availableQuantity ?? 0) + Number(row.quantity ?? 0),
            });
        }
        return [...bySku.values()]
            .map(({ sku, availableQuantity }) => ({
            skuId: sku.id,
            internalSku: sku.internalSku,
            clientSku: sku.clientSku,
            article: sku.article,
            name: sku.name,
            barcode: primaryBarcodeValue(sku),
            size: sku.size,
            availableQuantity,
        }))
            .sort((left, right) => left.internalSku.localeCompare(right.internalSku, 'ru'));
    }
    buildImportComment(comment, sourceFile, preview) {
        return [
            normalizeText(comment),
            `Создано из Excel: ${sourceFile}. Позиций: ${preview.summary.lines}, количество: ${preview.summary.totalQuantity}.`,
        ]
            .filter(Boolean)
            .join('\n');
    }
    buildLineComment(line) {
        return [
            line.city ? `Город: ${line.city}` : null,
            line.artSeller ? `Артикул продавца: ${line.artSeller}` : null,
            line.size ? `Размер: ${line.size}` : null,
            line.relabelTargetBarcode && line.relabelQuantity ? `Перемаркировка из: ${line.barcode ?? ''}` : null,
            line.relabelTargetBarcode && line.relabelQuantity ? `Перемаркировка в: ${line.relabelTargetBarcode}` : null,
            line.relabelTargetBarcode && line.relabelQuantity ? `Количество перемаркировки: ${line.relabelQuantity}` : null,
            line.needsRelabel ? 'Перемаркировка: да' : null,
            `Excel rows: ${line.sourceRows.join(', ')}`,
        ]
            .filter(Boolean)
            .join('; ');
    }
    buildRequestItemsFromLine(line) {
        const relabelQuantity = line.relabelTargetBarcode ? Math.min(line.relabelQuantity ?? 0, line.requestedQuantity) : 0;
        const normalQuantity = line.requestedQuantity - relabelQuantity;
        const base = {
            skuId: line.skuId ?? undefined,
            barcode: line.barcode,
            name: line.name ?? undefined,
        };
        const items = [];
        if (normalQuantity > 0) {
            items.push({
                ...base,
                quantity: normalQuantity,
                comment: this.buildLineComment({ ...line, relabelTargetBarcode: undefined, relabelQuantity: undefined }),
            });
        }
        if (relabelQuantity > 0) {
            items.push({
                ...base,
                quantity: relabelQuantity,
                comment: this.buildLineComment({ ...line, requestedQuantity: relabelQuantity, needsRelabel: true }),
            });
        }
        return items;
    }
    async attachSourceWorkbook(requestId, clientId, file, user) {
        await this.prisma.clientRequestFile?.create({
            data: {
                requestId,
                clientId,
                fileName: normalizeUploadedFileName(file.originalname),
                mimeType: file.mimetype || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                sizeBytes: file.size,
                content: Uint8Array.from(file.buffer),
                uploadedByUserId: user.id,
            },
        });
    }
    assertFile(file) {
        if (!file?.buffer?.length) {
            throw new common_1.BadRequestException('Нужно приложить Excel-файл.');
        }
    }
};
exports.ClientRequestXlsxService = ClientRequestXlsxService;
exports.ClientRequestXlsxService = ClientRequestXlsxService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        client_requests_service_1.ClientRequestsService])
], ClientRequestXlsxService);
function normalizeText(value) {
    const normalized = value?.trim();
    return normalized ? normalized : undefined;
}
function normalizeUploadedFileName(value) {
    const normalized = normalizeText(value);
    if (!normalized) {
        return 'request.xlsx';
    }
    if (!/[ÃÐÑ]/.test(normalized)) {
        return normalized;
    }
    const decoded = Buffer.from(normalized, 'latin1').toString('utf8');
    return decoded.includes('�') ? normalized : decoded;
}
function normalizeRequiredText(value, message) {
    const normalized = normalizeText(value);
    if (!normalized) {
        throw new common_1.BadRequestException(message);
    }
    return normalized;
}
function buildSkuMatchesByProductName(skus) {
    const result = new Map();
    skus.forEach((sku) => {
        [sku.internalSku, sku.clientSku, sku.article, sku.name].forEach((value) => {
            const key = normalizeLookupKey(value);
            if (!key) {
                return;
            }
            const existing = result.get(key) ?? [];
            if (!existing.some((item) => item.id === sku.id)) {
                result.set(key, [...existing, sku]);
            }
        });
    });
    return result;
}
function uniqueSkus(skus) {
    const byId = new Map();
    skus.forEach((sku) => byId.set(sku.id, sku));
    return [...byId.values()];
}
function filterSkusBySize(skus, size) {
    if (!size) {
        return skus;
    }
    return skus.filter((sku) => sizesMatch(sku.size, size));
}
function primaryBarcodeValue(sku) {
    return sku.barcodes?.find((barcode) => barcode.isPrimary)?.value ?? sku.barcodes?.[0]?.value ?? null;
}
function skuHasBarcode(sku, barcode) {
    return Boolean(sku.barcodes?.some((item) => item.value === barcode));
}
function sizesMatch(skuSize, requestedSize) {
    const left = normalizeSize(skuSize);
    const right = normalizeSize(requestedSize);
    return !right || Boolean(left && left === right);
}
function normalizeSize(value) {
    const raw = normalizeText(value)?.toUpperCase().replace(/М/g, 'M').replace(/Х/g, 'X') ?? '';
    const match = raw.match(/\(([^)]+)\)/);
    return (match?.[1] ?? raw).replace(/\s+/g, '');
}
function normalizeLookupKey(value) {
    return normalizeText(value)?.toLowerCase().replace(/\s+/g, ' ') ?? '';
}
function shortageMessage(needed, available, conflicts) {
    const base = `Недостаточно доступного остатка: нужно ${needed}, доступно ${available}.`;
    if (conflicts.length === 0) {
        return base;
    }
    const conflictText = conflicts
        .slice(0, 3)
        .map((conflict) => `${conflict.title} от ${new Date(conflict.createdAt).toLocaleDateString('ru-RU')} (${conflict.type})`)
        .join('; ');
    return `${base} Товар участвует в активной заявке: ${conflictText}.`;
}
function defaultTitle() {
    return `Сборка из Excel ${new Date().toLocaleDateString('ru-RU')}`;
}
