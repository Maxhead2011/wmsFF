"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestsModule = void 0;
const common_1 = require("@nestjs/common");
const common_module_1 = require("../../common/common.module");
const auth_module_1 = require("../auth/auth.module");
const client_notifications_module_1 = require("../client-notifications/client-notifications.module");
const logistics_module_1 = require("../logistics/logistics.module");
const marketplace_connections_module_1 = require("../marketplace-connections/marketplace-connections.module");
const stock_module_1 = require("../stock/stock.module");
const client_request_document_service_1 = require("./client-request-document.service");
const client_request_emergency_service_1 = require("./client-request-emergency.service");
const client_request_files_service_1 = require("./client-request-files.service");
const client_request_history_service_1 = require("./client-request-history.service");
const client_request_marketplace_files_service_1 = require("./client-request-marketplace-files.service");
const client_request_pdf_service_1 = require("./client-request-pdf.service");
const client_request_xlsx_service_1 = require("./client-request-xlsx.service");
const client_requests_controller_1 = require("./client-requests.controller");
const client_requests_service_1 = require("./client-requests.service");
let ClientRequestsModule = class ClientRequestsModule {
};
exports.ClientRequestsModule = ClientRequestsModule;
exports.ClientRequestsModule = ClientRequestsModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, common_module_1.CommonModule, client_notifications_module_1.ClientNotificationsModule, stock_module_1.StockModule, logistics_module_1.LogisticsModule, marketplace_connections_module_1.MarketplaceConnectionsModule],
        controllers: [client_requests_controller_1.ClientRequestsController],
        providers: [
            client_requests_service_1.ClientRequestsService,
            client_request_document_service_1.ClientRequestDocumentService,
            client_request_emergency_service_1.ClientRequestEmergencyService,
            client_request_pdf_service_1.ClientRequestPdfService,
            client_request_files_service_1.ClientRequestFilesService,
            client_request_history_service_1.ClientRequestHistoryService,
            client_request_marketplace_files_service_1.ClientRequestMarketplaceFilesService,
            client_request_xlsx_service_1.ClientRequestXlsxService,
        ],
    })
], ClientRequestsModule);
