"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateClientRequestStatusDto = exports.ClientRequestPhysicalStockSourceDto = void 0;
const client_1 = require("@prisma/client");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const fulfill_client_request_dto_1 = require("../../stock/dto/fulfill-client-request.dto");
class ClientRequestPhysicalStockSourceDto {
    requestItemId;
    boxCode;
    noBox;
    quantity;
}
exports.ClientRequestPhysicalStockSourceDto = ClientRequestPhysicalStockSourceDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ClientRequestPhysicalStockSourceDto.prototype, "requestItemId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ClientRequestPhysicalStockSourceDto.prototype, "boxCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], ClientRequestPhysicalStockSourceDto.prototype, "noBox", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], ClientRequestPhysicalStockSourceDto.prototype, "quantity", void 0);
class UpdateClientRequestStatusDto {
    status;
    managerComment;
    boxes;
    pallets;
    packedUnits;
    packages;
    /** Явное решение менеджера пропустить ограничение веса упаковочного места. */
    allowOverweightPackages;
    /**
     * Фактические источники указываются менеджером только после неудачного
     * штатного закрытия. Можно подтвердить физический короб либо отсутствие
     * короба; складская операция зафиксирует расхождение отдельным движением.
     */
    stockSources;
}
exports.UpdateClientRequestStatusDto = UpdateClientRequestStatusDto;
__decorate([
    (0, class_validator_1.IsEnum)(client_1.ClientRequestStatus),
    __metadata("design:type", String)
], UpdateClientRequestStatusDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateClientRequestStatusDto.prototype, "managerComment", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateClientRequestStatusDto.prototype, "boxes", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateClientRequestStatusDto.prototype, "pallets", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateClientRequestStatusDto.prototype, "packedUnits", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => fulfill_client_request_dto_1.PackageClientRequestPlaceDto),
    __metadata("design:type", Array)
], UpdateClientRequestStatusDto.prototype, "packages", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateClientRequestStatusDto.prototype, "allowOverweightPackages", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(5000),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => ClientRequestPhysicalStockSourceDto),
    __metadata("design:type", Array)
], UpdateClientRequestStatusDto.prototype, "stockSources", void 0);
