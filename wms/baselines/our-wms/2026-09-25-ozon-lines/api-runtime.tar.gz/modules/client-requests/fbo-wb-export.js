"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildFboWbExport = buildFboWbExport;
const common_1 = require("@nestjs/common");
const XLSX = __importStar(require("xlsx"));
// FIX: export immutable physical packing evidence, grouped by barcode and destination box.
function buildFboWbExport(assembly, expectedUnits, kind) {
    if (assembly.phase !== 'COMPLETED' || !assembly.boxes.length || assembly.boxes.some(b => !b.closedAt || !b.confirmedAt))
        throw new common_1.ConflictException('Сначала подтвердите все короба поставки.');
    const totals = new Map(), perBox = new Map();
    const boxes = new Map(assembly.boxes.map(b => [b.boxId, b.boxCode]));
    if (!assembly.units.length || assembly.units.length !== expectedUnits || new Set(assembly.units.map(u => u.id)).size !== assembly.units.length)
        throw new common_1.ConflictException('Количество упакованных единиц расходится с составом поставки.');
    for (const u of assembly.units) {
        if (u.state !== 'PACKED' || !u.barcode.trim() || !u.targetBoxId || boxes.get(u.targetBoxId) !== u.targetBoxCode)
            throw new common_1.ConflictException('Не подтверждено распределение товара по коробам поставки.');
        totals.set(u.barcode, (totals.get(u.barcode) || 0) + 1);
        const rows = perBox.get(u.targetBoxCode) ?? new Map();
        rows.set(u.barcode, (rows.get(u.barcode) || 0) + 1);
        perBox.set(u.targetBoxCode, rows);
    }
    if (perBox.size !== assembly.boxes.length)
        throw new common_1.ConflictException('В поставке обнаружен пустой или повторный короб.');
    const sort = (a, b) => a.localeCompare(b, 'ru', { numeric: true });
    const rows = kind === 'products'
        ? [['Баркод', 'Количество'], ...[...totals].sort(([a], [b]) => sort(a, b))]
        : [['Баркод товара', 'Кол-во товаров', 'ШК короба', 'Срок годности', 'ШК короба для печати в стороннем сервисе'],
            ...[...perBox].sort(([a], [b]) => sort(a, b)).flatMap(([box, items]) => [...items].sort(([a], [b]) => sort(a, b)).map(([barcode, quantity]) => [barcode, quantity, box, '', '']))];
    const sheet = XLSX.utils.aoa_to_sheet(rows);
    sheet['!cols'] = (kind === 'products' ? [24, 16] : [24, 18, 28, 20, 52]).map(wch => ({ wch }));
    // FIX: identifiers remain text, including leading zeroes; quantities remain numeric.
    for (const address of Object.keys(sheet))
        if (!address.startsWith('!') && typeof sheet[address].v === 'string') {
            sheet[address].t = 's';
            sheet[address].z = '@';
        }
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, 'Sheet1');
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
