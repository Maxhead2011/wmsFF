"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const pick_instruction_service_1 = require("../stock/pick-instruction.service");
const fulfillment_wave_service_1 = require("../stock/fulfillment-wave.service");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const update_pick_wave_balance_review_dto_1 = require("../stock/dto/update-pick-wave-balance-review.dto");
const client_request_files_service_1 = require("./client-request-files.service");
const client_request_emergency_service_1 = require("./client-request-emergency.service");
const client_request_history_service_1 = require("./client-request-history.service");
const client_request_marketplace_files_service_1 = require("./client-request-marketplace-files.service");
const client_request_document_service_1 = require("./client-request-document.service");
const client_request_pdf_service_1 = require("./client-request-pdf.service");
const client_request_xlsx_service_1 = require("./client-request-xlsx.service");
const client_requests_service_1 = require("./client-requests.service");
const create_client_request_comment_dto_1 = require("./dto/create-client-request-comment.dto");
const create_client_request_dto_1 = require("./dto/create-client-request.dto");
const import_outbound_request_xlsx_dto_1 = require("./dto/import-outbound-request-xlsx.dto");
const list_client_requests_dto_1 = require("./dto/list-client-requests.dto");
const merge_fbs_request_tails_dto_1 = require("./dto/merge-fbs-request-tails.dto");
const preview_client_request_availability_dto_1 = require("./dto/preview-client-request-availability.dto");
const update_client_request_dto_1 = require("./dto/update-client-request.dto");
const update_client_request_box_selection_dto_1 = require("./dto/update-client-request-box-selection.dto");
const update_client_request_status_dto_1 = require("./dto/update-client-request-status.dto");
const resolve_fbs_synchronization_dto_1 = require("./dto/resolve-fbs-synchronization.dto");
let ClientRequestsController = class ClientRequestsController {
    clientRequests;
    documents;
    pdf;
    files;
    emergency;
    marketplaceFiles;
    history;
    xlsx;
    pickInstructions;
    waves;
    marketplace;
    constructor(clientRequests, documents, pdf, files, emergency, marketplaceFiles, history, xlsx, pickInstructions, waves, marketplace) {
        this.clientRequests = clientRequests;
        this.documents = documents;
        this.pdf = pdf;
        this.files = files;
        this.emergency = emergency;
        this.marketplaceFiles = marketplaceFiles;
        this.history = history;
        this.xlsx = xlsx;
        this.pickInstructions = pickInstructions;
        this.waves = waves;
        this.marketplace = marketplace;
    }
    list(query, user) {
        return this.clientRequests.list(query, user);
    }
    boxOverlaps(user) {
        return this.pickInstructions.getActiveRequestBoxOverlaps(user);
    }
    listBalanceReviews(user) {
        return this.waves.listBalanceReviews(user);
    }
    getBalanceReview(waveId, user) {
        return this.waves.getBalanceReview(waveId, user);
    }
    saveBalanceReview(waveId, dto, user) {
        return this.waves.saveBalanceReview(waveId, dto, user);
    }
    submitBalanceReview(waveId, user) {
        return this.waves.submitBalanceReview(waveId, user);
    }
    mergeFbsRequestTails(dto, user) {
        return this.marketplace.mergeFbsRequestTails(dto, user);
    }
    previewFbsRequestTails(dto, user) {
        return this.marketplace.previewFbsRequestTails(dto, user);
    }
    getManualBoxSelection(id, user) {
        return this.clientRequests.getManualBoxSelection(id, user);
    }
    getFbsBoxSearch(id, user) {
        return this.clientRequests.getFbsBoxSearch(id, user);
    }
    async downloadFbsBoxSearchXlsx(id, user, response) {
        const file = await this.clientRequests.getFbsBoxSearchXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    saveManualBoxSelection(id, dto, user) {
        return this.clientRequests.saveManualBoxSelection(id, dto, user);
    }
    get(id, user) {
        return this.clientRequests.get(id, user);
    }
    getDocument(id, user) {
        return this.documents.getRequestDocument(id, user);
    }
    async getDocumentPdf(id, user, response) {
        const file = await this.pdf.getRequestPdf(id, user);
        response.setHeader('Content-Type', file.contentType);
        response.setHeader('Content-Length', String(file.buffer.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.buffer);
    }
    async downloadRequestItemsXlsx(id, user, response) {
        const file = await this.documents.getRequestItemsXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    getPickInstruction(id, user) {
        return this.pickInstructions.getRequestInstruction(id, user);
    }
    async downloadPickInstructionXlsx(id, user, response) {
        const file = await this.pickInstructions.getRequestInstructionXlsx(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    refreshPickInstruction(id, user) {
        return this.pickInstructions.refreshRequestInstruction(id, user);
    }
    async syncToTsd(id, user) {
        const fbsResult = await this.marketplace.syncFbsRequestForTsd(id, user);
        if (fbsResult) {
            return fbsResult;
        }
        // The regular queue is read by the TSD on demand. Rebuilding the current
        // instruction here makes a newly created request immediately available on
        // the next list refresh without changing its workflow status.
        this.pickInstructions.invalidateRequestInstruction(id);
        const instruction = await this.pickInstructions.getRequestInstruction(id, user);
        return {
            mode: 'OUTBOUND',
            requestId: id,
            message: `Заявка подготовлена для ТСД: ${instruction.rows.length} строк. Обновите список заявок на устройстве.`,
        };
    }
    async downloadWbProductsTemplate(id, user, response) {
        const file = await this.marketplaceFiles.getWbProductsTemplate(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    async downloadWbPackagesTemplate(id, user, response) {
        const file = await this.marketplaceFiles.getWbPackagingTemplate(id, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.content.length));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(file.content);
    }
    uploadManualPickInstruction(id, file, user) {
        return this.pickInstructions.uploadManualRequestInstruction(id, file, user);
    }
    listFiles(id, user) {
        return this.files.listForRequest(id, user);
    }
    getTimeline(id, user) {
        return this.history.getTimeline(id, user);
    }
    async downloadFile(id, fileId, user, response) {
        const file = await this.files.getFileContent(id, fileId, user);
        response.setHeader('Content-Type', file.mimeType);
        response.setHeader('Content-Length', String(file.sizeBytes));
        response.setHeader('Content-Disposition', contentDisposition(file.fileName));
        return new common_1.StreamableFile(Buffer.from(file.content));
    }
    create(dto, user) {
        return this.clientRequests.create(dto, user);
    }
    update(id, dto, user) {
        return this.clientRequests.update(id, dto, user);
    }
    previewAvailability(dto, user) {
        return this.clientRequests.previewAvailability(dto, user);
    }
    previewOutboundXlsx(file, dto, user) {
        return this.xlsx.previewOutboundRequest(file, dto, user);
    }
    createOutboundFromXlsx(file, dto, user) {
        return this.xlsx.createOutboundRequest(file, dto, user);
    }
    uploadFile(id, file, user) {
        return this.files.uploadToRequest(id, file, user);
    }
    emergencyPackedXlsx(id, file, user) {
        return this.emergency.closeFromPackedXlsx(id, file, user);
    }
    rollbackEmergencyPackedXlsx(id, user) {
        return this.emergency.rollbackPackedXlsx(id, user);
    }
    addComment(id, dto, user) {
        return this.history.addComment(id, dto, user);
    }
    cancel(id, user) {
        return this.clientRequests.cancel(id, user);
    }
    updateStatus(id, dto, user) {
        return this.clientRequests.updateStatus(id, dto, user);
    }
    resolveFbsSynchronization(id, dto, user) {
        return this.clientRequests.resolveFbsSynchronization(id, dto.action, dto.requestNumber, user);
    }
};
exports.ClientRequestsController = ClientRequestsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_client_requests_dto_1.ListClientRequestsDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)('box-overlaps'),
    (0, require_permissions_decorator_1.RequirePermissions)('system:admin'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "boxOverlaps", null);
__decorate([
    (0, common_1.Get)('balance-reviews/pending'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "listBalanceReviews", null);
__decorate([
    (0, common_1.Get)('balance-reviews/:waveId'),
    __param(0, (0, common_1.Param)('waveId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "getBalanceReview", null);
__decorate([
    (0, common_1.Patch)('balance-reviews/:waveId'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('waveId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_pick_wave_balance_review_dto_1.UpdatePickWaveBalanceReviewDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "saveBalanceReview", null);
__decorate([
    (0, common_1.Post)('balance-reviews/:waveId/submit'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('waveId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "submitBalanceReview", null);
__decorate([
    (0, common_1.Post)('fbs/merge-tails'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [merge_fbs_request_tails_dto_1.MergeFbsRequestTailsDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "mergeFbsRequestTails", null);
__decorate([
    (0, common_1.Post)('fbs/merge-tails/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [merge_fbs_request_tails_dto_1.MergeFbsRequestTailsDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "previewFbsRequestTails", null);
__decorate([
    (0, common_1.Get)(':id/manual-box-selection'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "getManualBoxSelection", null);
__decorate([
    (0, common_1.Get)(':id/fbs-box-search'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "getFbsBoxSearch", null);
__decorate([
    (0, common_1.Get)(':id/fbs-box-search.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "downloadFbsBoxSearchXlsx", null);
__decorate([
    (0, common_1.Put)(':id/manual-box-selection'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_client_request_box_selection_dto_1.UpdateClientRequestBoxSelectionDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "saveManualBoxSelection", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "get", null);
__decorate([
    (0, common_1.Get)(':id/document'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "getDocument", null);
__decorate([
    (0, common_1.Get)(':id/document.pdf'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "getDocumentPdf", null);
__decorate([
    (0, common_1.Get)(':id/items.xlsx'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "downloadRequestItemsXlsx", null);
__decorate([
    (0, common_1.Get)(':id/pick-instruction'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "getPickInstruction", null);
__decorate([
    (0, common_1.Get)(':id/pick-instruction.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "downloadPickInstructionXlsx", null);
__decorate([
    (0, common_1.Post)(':id/pick-instruction/refresh'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "refreshPickInstruction", null);
__decorate([
    (0, common_1.Post)(':id/sync-tsd'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "syncToTsd", null);
__decorate([
    (0, common_1.Get)(':id/marketplace/wb-products.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "downloadWbProductsTemplate", null);
__decorate([
    (0, common_1.Get)(':id/marketplace/wb-packages.xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "downloadWbPackagesTemplate", null);
__decorate([
    (0, common_1.Post)(':id/pick-instruction/manual'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Ручная складская инструкция XLSX, которая немедленно заменяет автоматический план заявки.' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "uploadManualPickInstruction", null);
__decorate([
    (0, common_1.Get)(':id/files'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "listFiles", null);
__decorate([
    (0, common_1.Get)(':id/timeline'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "getTimeline", null);
__decorate([
    (0, common_1.Get)(':id/files/:fileId'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('fileId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", Promise)
], ClientRequestsController.prototype, "downloadFile", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_client_request_dto_1.CreateClientRequestDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_client_request_dto_1.UpdateClientRequestDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "update", null);
__decorate([
    (0, common_1.Post)('availability-preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [preview_client_request_availability_dto_1.PreviewClientRequestAvailabilityDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "previewAvailability", null);
__decorate([
    (0, common_1.Post)('outbound-xlsx/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Excel-файл сборки: баркод товара и количество.' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, import_outbound_request_xlsx_dto_1.ImportOutboundRequestXlsxDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "previewOutboundXlsx", null);
__decorate([
    (0, common_1.Post)('outbound-xlsx/commit'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Создание outbound-заявки из Excel-файла сборки.' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, import_outbound_request_xlsx_dto_1.ImportOutboundRequestXlsxDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "createOutboundFromXlsx", null);
__decorate([
    (0, common_1.Post)(':id/files'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Файл, который нужно приложить к клиентской заявке.' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "uploadFile", null);
__decorate([
    (0, common_1.Post)(':id/emergency-packed-xlsx'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ description: 'Аварийная упаковка заявки: XLSX со списком фактических коробов FFL.' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "emergencyPackedXlsx", null);
__decorate([
    (0, common_1.Post)(':id/emergency-packed-xlsx/rollback'),
    (0, require_permissions_decorator_1.RequirePermissions)('stock:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "rollbackEmergencyPackedXlsx", null);
__decorate([
    (0, common_1.Post)(':id/comments'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_client_request_comment_dto_1.CreateClientRequestCommentDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "addComment", null);
__decorate([
    (0, common_1.Post)(':id/cancel'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "cancel", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:status'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_client_request_status_dto_1.UpdateClientRequestStatusDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Post)(':id/fbs-synchronization/resolve'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:status'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, resolve_fbs_synchronization_dto_1.ResolveFbsSynchronizationDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestsController.prototype, "resolveFbsSynchronization", null);
exports.ClientRequestsController = ClientRequestsController = __decorate([
    (0, swagger_1.ApiTags)('client-requests'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:read'),
    (0, common_1.Controller)('client-requests'),
    __metadata("design:paramtypes", [client_requests_service_1.ClientRequestsService,
        client_request_document_service_1.ClientRequestDocumentService,
        client_request_pdf_service_1.ClientRequestPdfService,
        client_request_files_service_1.ClientRequestFilesService,
        client_request_emergency_service_1.ClientRequestEmergencyService,
        client_request_marketplace_files_service_1.ClientRequestMarketplaceFilesService,
        client_request_history_service_1.ClientRequestHistoryService,
        client_request_xlsx_service_1.ClientRequestXlsxService,
        pick_instruction_service_1.PickInstructionService,
        fulfillment_wave_service_1.FulfillmentWaveService,
        marketplace_connections_service_1.MarketplaceConnectionsService])
], ClientRequestsController);
function contentDisposition(fileName) {
    const asciiName = fileName.replace(/[^\x20-\x7E]+/g, '_').replace(/"/g, '');
    return `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`;
}
