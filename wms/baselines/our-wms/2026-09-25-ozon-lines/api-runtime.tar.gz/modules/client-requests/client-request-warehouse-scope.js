"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isWarehouseScopedInternalUser = isWarehouseScopedInternalUser;
exports.effectiveWarehouseId = effectiveWarehouseId;
exports.warehouseScopeWhere = warehouseScopeWhere;
exports.assertWarehouseAccess = assertWarehouseAccess;
const common_1 = require("@nestjs/common");
/**
 * Branch isolation is intentionally limited to internal users with an explicit
 * warehouse scope. System administrators and client-cabinet users keep their
 * existing cross-warehouse behaviour.
 */
function isWarehouseScopedInternalUser(user) {
    const permissionCodes = user.permissionCodes ?? [];
    const roleCodes = user.roleCodes ?? [];
    return (!permissionCodes.includes('system:admin') &&
        !roleCodes.includes('CLIENT') &&
        (roleCodes.includes('BRANCH_MANAGER') ||
            Array.isArray(user.warehouseIds) ||
            Array.isArray(user.writableWarehouseIds)));
}
function effectiveWarehouseId(user, mode) {
    if (!isWarehouseScopedInternalUser(user)) {
        return null;
    }
    const warehouseId = user.activeWarehouseId?.trim() ?? '';
    const readableWarehouseIds = user.warehouseIds ?? [];
    if (!warehouseId || !readableWarehouseIds.includes(warehouseId)) {
        throw new common_1.ForbiddenException('Активный филиал не выбран или недоступен пользователю.');
    }
    if (mode === 'write' && !(user.writableWarehouseIds ?? []).includes(warehouseId)) {
        throw new common_1.ForbiddenException('В выбранном филиале доступен только просмотр.');
    }
    return warehouseId;
}
function warehouseScopeWhere(user, mode = 'read') {
    const warehouseId = effectiveWarehouseId(user, mode);
    return warehouseId ? { warehouseId } : {};
}
function assertWarehouseAccess(user, entity, mode, notFoundMessage = 'Объект не найден в выбранном филиале.') {
    const warehouseId = effectiveWarehouseId(user, mode);
    if (warehouseId && entity.warehouseId !== warehouseId) {
        throw new common_1.NotFoundException(notFoundMessage);
    }
    return warehouseId;
}
