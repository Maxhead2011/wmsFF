"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestMarketplaceFilesService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const XLSX = __importStar(require("xlsx"));
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const fbo_two_stage_policy_1 = require("../tsd/fbo-two-stage-policy");
const fbo_wb_export_1 = require("./fbo-wb-export");
const xlsxMimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const marketplaceReadyStatuses = new Set([
    client_1.ClientRequestStatus.PACKED,
    client_1.ClientRequestStatus.DONE,
]);
let ClientRequestMarketplaceFilesService = class ClientRequestMarketplaceFilesService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    async getWbProductsTemplate(requestId, user) {
        const request = await this.loadReadyRequest(requestId, user);
        const fbo = await this.fboFile(request, 'products');
        if (fbo)
            return fbo;
        const totals = new Map();
        request.packages.forEach((packagePlace) => {
            packagePlace.items.forEach((item) => {
                const barcode = resolveItemBarcode(item);
                if (barcode) {
                    totals.set(barcode, (totals.get(barcode) ?? 0) + item.quantity);
                }
            });
        });
        const rows = [['Баркод', 'Количество']];
        [...totals.entries()]
            .sort(([left], [right]) => left.localeCompare(right, 'ru', { numeric: true }))
            .forEach(([barcode, quantity]) => rows.push([barcode, quantity]));
        if (rows.length === 1) {
            throw new common_1.BadRequestException('В упакованной заявке нет строк с баркодами для шаблона товаров WB.');
        }
        return {
            fileName: `${safeFileName(`wb-products-${request.title}-${request.id.slice(0, 8)}`)}.xlsx`,
            mimeType: xlsxMimeType,
            content: buildWorkbook('Sheet1', rows, [22, 14]),
        };
    }
    async getWbPackagingTemplate(requestId, user) {
        const request = await this.loadReadyRequest(requestId, user);
        const fbo = await this.fboFile(request, 'packages');
        if (fbo)
            return fbo;
        const rows = [['Баркод товара', 'Кол-во товаров', 'ШК короба', 'Срок годности']];
        request.packages
            .slice()
            .sort((left, right) => left.packageCode.localeCompare(right.packageCode, 'ru', { numeric: true }))
            .forEach((packagePlace) => {
            packagePlace.items.forEach((item) => {
                const barcode = resolveItemBarcode(item);
                if (!barcode) {
                    return;
                }
                rows.push([
                    barcode,
                    item.quantity,
                    packagePlace.packageCode,
                    formatDate(item.sku?.shelfLifeUntil ?? item.requestItem.sku?.shelfLifeUntil ?? null),
                ]);
            });
        });
        if (rows.length === 1) {
            throw new common_1.BadRequestException('В упакованной заявке нет строк с коробами для шаблона упаковки WB.');
        }
        return {
            fileName: `${safeFileName(`wb-packages-${request.title}-${request.id.slice(0, 8)}`)}.xlsx`,
            mimeType: xlsxMimeType,
            content: buildWorkbook('TDSheet', rows, [22, 16, 24, 16]),
        };
    }
    // FIX: retain legacy/sold exports unless this request uses the enabled two-stage FBO workflow.
    async fboFile(request, kind) {
        if (!(0, fbo_two_stage_policy_1.fboTwoStageEnabled)())
            return null;
        const assembly = await this.prisma.fboAssembly.findUnique({ where: { requestId: request.id }, include: { units: true, boxes: true } });
        if (!assembly)
            return null;
        const expectedUnits = request.packages.reduce((n, p) => n + p.items.reduce((sum, i) => sum + i.quantity, 0), 0);
        return { fileName: `wb-${kind}-${request.id}.xlsx`, mimeType: xlsxMimeType, content: (0, fbo_wb_export_1.buildFboWbExport)(assembly, expectedUnits, kind) };
    }
    async loadReadyRequest(requestId, user) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            ...marketplaceRequestArgs,
        });
        if (!request) {
            throw new common_1.NotFoundException('Клиентская заявка не найдена.');
        }
        this.clientScopes.requireClientAccess(user, request.clientId, 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'read', 'Заявка не найдена в выбранном филиале.');
        if (request.type !== client_1.ClientRequestType.OUTBOUND) {
            throw new common_1.BadRequestException('Файлы WB доступны только для заявок на отгрузку.');
        }
        if (!marketplaceReadyStatuses.has(request.status)) {
            throw new common_1.BadRequestException('Файлы WB доступны после упаковки заявки.');
        }
        if (request.packages.length === 0) {
            throw new common_1.BadRequestException('Сначала зафиксируйте упаковочные места по заявке.');
        }
        return request;
    }
};
exports.ClientRequestMarketplaceFilesService = ClientRequestMarketplaceFilesService;
exports.ClientRequestMarketplaceFilesService = ClientRequestMarketplaceFilesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], ClientRequestMarketplaceFilesService);
const skuForMarketplaceSelect = {
    id: true,
    internalSku: true,
    clientSku: true,
    article: true,
    name: true,
    shelfLifeUntil: true,
    barcodes: {
        select: {
            value: true,
            isPrimary: true,
        },
    },
};
const marketplaceRequestArgs = {
    include: {
        packages: {
            include: {
                items: {
                    include: {
                        sku: { select: skuForMarketplaceSelect },
                        requestItem: {
                            select: {
                                id: true,
                                barcode: true,
                                name: true,
                                quantity: true,
                                sku: { select: skuForMarketplaceSelect },
                            },
                        },
                    },
                    orderBy: { id: 'asc' },
                },
            },
            orderBy: { createdAt: 'asc' },
        },
    },
};
function buildWorkbook(sheetName, rows, widths) {
    const workbook = XLSX.utils.book_new();
    const sheet = XLSX.utils.aoa_to_sheet(rows);
    sheet['!cols'] = widths.map((width) => ({ wch: width }));
    for (const address of Object.keys(sheet)) {
        if (!address.startsWith('!')) {
            const cell = sheet[address];
            if (typeof cell?.v === 'string') {
                cell.t = 's';
                cell.z = '@';
            }
        }
    }
    XLSX.utils.book_append_sheet(workbook, sheet, sheetName);
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
function resolveItemBarcode(item) {
    return (normalizeText(item.barcode) ??
        normalizeText(item.requestItem.barcode) ??
        primaryBarcode(item.sku?.barcodes ?? []) ??
        primaryBarcode(item.requestItem.sku?.barcodes ?? []) ??
        null);
}
function primaryBarcode(barcodes) {
    return normalizeText(barcodes.find((barcode) => barcode.isPrimary)?.value) ?? normalizeText(barcodes[0]?.value);
}
function formatDate(value) {
    if (!value) {
        return '';
    }
    return new Intl.DateTimeFormat('ru-RU', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        timeZone: 'Europe/Moscow',
    }).format(value);
}
function normalizeText(value) {
    const normalized = value?.trim();
    return normalized ? normalized : undefined;
}
function safeFileName(value) {
    return value.replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, '_').replace(/^_+|_+$/g, '') || 'wb-template';
}
