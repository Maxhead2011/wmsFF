"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.attachConfirmedRequestAuthors = attachConfirmedRequestAuthors;
// FIX: a null user is not evidence of automatic creation. Only an explicit audit confirmation is.
async function attachConfirmedRequestAuthors(db, requests) {
    const ids = requests.filter(r => r.createdByUserId === null).map(r => r.id);
    if (!ids.length)
        return requests;
    const evidence = await db.auditLog.findMany({
        where: { action: 'client_request.author_confirmed', entity: 'ClientRequest', entityId: { in: ids } },
        select: { entityId: true, payload: true },
    });
    const confirmed = new Set(evidence.filter(e => e.payload && typeof e.payload === 'object' &&
        !Array.isArray(e.payload) && e.payload.author === 'WMS').map(e => e.entityId));
    return requests.map(r => r.createdByUserId === null && confirmed.has(r.id)
        ? { ...r, creationAuthorLabel: 'WMS' } : r);
}
