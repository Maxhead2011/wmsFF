"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientRequestEventInclude = exports.clientRequestCommentInclude = exports.ClientRequestHistoryService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_notification_preferences_1 = require("../client-notifications/client-notification-preferences");
const telegram_notification_service_1 = require("../client-notifications/telegram-notification.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
let ClientRequestHistoryService = class ClientRequestHistoryService {
    prisma;
    clientScopes;
    telegram;
    constructor(prisma, clientScopes, telegram) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.telegram = telegram;
    }
    async getTimeline(requestId, user) {
        const request = await this.getRequestForAccess(requestId);
        this.clientScopes.requireClientAccess(user, request.clientId, 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'read', 'Заявка не найдена в выбранном филиале.');
        const includeInternal = canSeeInternalComments(user);
        const [comments, events] = await Promise.all([
            this.prisma.clientRequestComment.findMany({
                where: {
                    requestId,
                    isInternal: includeInternal ? undefined : false,
                },
                include: exports.clientRequestCommentInclude,
                orderBy: { createdAt: 'asc' },
            }),
            this.prisma.clientRequestEvent.findMany({
                where: { requestId },
                include: exports.clientRequestEventInclude,
                orderBy: { createdAt: 'asc' },
            }),
        ]);
        return {
            request,
            comments,
            events,
        };
    }
    async addComment(requestId, dto, user) {
        const request = await this.getRequestForAccess(requestId);
        this.clientScopes.requireClientAccess(user, request.clientId, 'write');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'write', 'Заявка не найдена в выбранном филиале.');
        const isInternal = dto.isInternal === true;
        if (isInternal && !canSeeInternalComments(user)) {
            throw new common_1.ForbiddenException('Внутренний комментарий доступен только сотрудникам.');
        }
        const body = dto.body.trim();
        if (!body) {
            throw new common_1.BadRequestException('Комментарий не должен быть пустым.');
        }
        const notifyClient = !isInternal &&
            shouldNotifyClient(user) &&
            (await (0, client_notification_preferences_1.isClientNotificationEnabled)(this.prisma, request.clientId, client_1.ClientNotificationEvent.REQUEST_COMMENT));
        // Русский комментарий: комментарий, событие и уведомление пишем одной транзакцией, чтобы история заявки не расходилась с кабинетом клиента.
        const comment = await this.prisma.$transaction(async (tx) => {
            const comment = await tx.clientRequestComment.create({
                data: {
                    requestId,
                    clientId: request.clientId,
                    authorUserId: user.id,
                    body,
                    isInternal,
                },
                include: exports.clientRequestCommentInclude,
            });
            await tx.clientRequestEvent.create({
                data: {
                    requestId,
                    clientId: request.clientId,
                    eventType: client_1.ClientRequestEventType.COMMENT,
                    title: isInternal ? 'Внутренний комментарий' : 'Добавлен комментарий',
                    body: isInternal ? undefined : body,
                    createdByUserId: user.id,
                },
            });
            if (notifyClient) {
                await tx.clientNotification.create({
                    data: {
                        clientId: request.clientId,
                        requestId,
                        title: 'Новый комментарий по заявке',
                        body: `${request.title}: ${body.slice(0, 180)}`,
                        severity: 'INFO',
                        createdByUserId: user.id,
                    },
                });
            }
            return comment;
        });
        if (notifyClient) {
            void this.telegram?.notifyClient(request.clientId, ['LOGOFF WMS: новый комментарий по заявке.', `Заявка: ${request.title}`, body].join('\n'));
        }
        return comment;
    }
    async getRequestForAccess(requestId) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: {
                id: true,
                number: true,
                clientId: true,
                warehouseId: true,
                title: true,
                type: true,
                status: true,
                createdAt: true,
                client: {
                    select: {
                        id: true,
                        code: true,
                        name: true,
                    },
                },
            },
        });
        if (!request) {
            throw new common_1.NotFoundException('Клиентская заявка не найдена.');
        }
        return request;
    }
};
exports.ClientRequestHistoryService = ClientRequestHistoryService;
exports.ClientRequestHistoryService = ClientRequestHistoryService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        telegram_notification_service_1.TelegramNotificationService])
], ClientRequestHistoryService);
exports.clientRequestCommentInclude = {
    author: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
};
exports.clientRequestEventInclude = {
    createdBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
};
function canSeeInternalComments(user) {
    return user.permissionCodes.includes('system:admin') || user.permissionCodes.includes('client-requests:status');
}
function shouldNotifyClient(user) {
    return user.permissionCodes.includes('system:admin') || user.permissionCodes.includes('client-requests:status');
}
