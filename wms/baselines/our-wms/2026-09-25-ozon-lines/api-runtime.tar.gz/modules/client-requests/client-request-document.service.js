"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestDocumentService = void 0;
const common_1 = require("@nestjs/common");
const XLSX = __importStar(require("xlsx"));
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_packages_include_1 = require("./client-request-packages.include");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
let ClientRequestDocumentService = class ClientRequestDocumentService {
    prisma;
    clientScopes;
    constructor(prisma, clientScopes) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
    }
    async getRequestDocument(requestId, user) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            include: requestDocumentInclude,
        });
        if (!request) {
            throw new common_1.NotFoundException('Клиентская заявка не найдена.');
        }
        this.clientScopes.requireClientAccess(user, request.clientId, 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, 'read', 'Заявка не найдена в выбранном филиале.');
        const rows = request.items.map((item, index) => ({
            position: index + 1,
            skuId: item.skuId,
            internalSku: item.sku?.internalSku ?? null,
            clientSku: item.sku?.clientSku ?? null,
            article: item.sku?.article ?? null,
            barcode: item.barcode,
            name: item.name ?? item.sku?.name ?? null,
            color: item.sku?.color ?? null,
            size: item.sku?.size ?? null,
            quantity: item.quantity,
            comment: item.comment,
        }));
        const payload = {
            requestId: request.id,
            requestNumber: request.number,
            title: `Заявка №${formatRequestNumber(request.number)} — ${request.title}`,
            fileName: `${safeFileName(`request-${formatRequestNumber(request.number)}-${request.title}`)}.html`,
            type: request.type,
            typeLabel: requestTypeLabel(request.type),
            status: request.status,
            statusLabel: requestStatusLabel(request.status),
            priority: request.priority,
            priorityLabel: requestPriorityLabel(request.priority),
            createdAt: request.createdAt.toISOString(),
            updatedAt: request.updatedAt.toISOString(),
            desiredDate: request.desiredDate?.toISOString() ?? null,
            comment: request.comment,
            managerComment: request.managerComment,
            contactName: request.contactName,
            contactPhone: request.contactPhone,
            destinationCity: request.destinationCity,
            deliveryAddress: request.deliveryAddress,
            rowsCount: rows.length,
            totalQuantity: rows.reduce((sum, row) => sum + row.quantity, 0),
            client: {
                id: request.client.id,
                code: request.client.code,
                name: request.client.name,
                inn: request.client.inn,
                kpp: request.client.kpp,
                legalAddress: request.client.legalAddress,
                actualAddress: request.client.actualAddress,
                email: request.client.email,
                phone: request.client.phone,
            },
            rows,
            packages: request.packages.map((packagePlace) => ({
                id: packagePlace.id,
                packageCode: packagePlace.packageCode,
                packageType: packagePlace.packageType,
                weightGrams: packagePlace.weightGrams,
                lengthCm: packagePlace.lengthCm == null ? null : Number(packagePlace.lengthCm),
                widthCm: packagePlace.widthCm == null ? null : Number(packagePlace.widthCm),
                heightCm: packagePlace.heightCm == null ? null : Number(packagePlace.heightCm),
                comment: packagePlace.comment,
                items: packagePlace.items.map((item) => ({
                    requestItemId: item.requestItemId,
                    skuId: item.skuId,
                    internalSku: item.sku?.internalSku ?? item.requestItem.sku?.internalSku ?? null,
                    name: item.requestItem.name ?? item.sku?.name ?? item.requestItem.sku?.name ?? null,
                    barcode: item.barcode ?? item.requestItem.barcode,
                    quantity: item.quantity,
                })),
            })),
            createdBy: request.createdBy
                ? {
                    id: request.createdBy.id,
                    email: request.createdBy.email,
                    name: request.createdBy.name,
                }
                : null,
            assignedTo: request.assignedTo
                ? {
                    id: request.assignedTo.id,
                    email: request.assignedTo.email,
                    name: request.assignedTo.name,
                }
                : null,
        };
        return {
            ...payload,
            html: renderRequestHtml(payload),
        };
    }
    async getRequestItemsXlsx(requestId, user) {
        const document = await this.getRequestDocument(requestId, user);
        const rows = [
            ['№', 'ШК товара', 'SKU клиента', 'SKU WMS', 'Артикул', 'Наименование', 'Цвет', 'Размер', 'Количество', 'Комментарий'],
            ...document.rows.map((row) => [
                row.position,
                row.barcode ?? '',
                row.clientSku ?? '',
                row.internalSku ?? '',
                row.article ?? '',
                row.name ?? '',
                row.color ?? '',
                row.size ?? '',
                row.quantity,
                row.comment ?? '',
            ]),
            [],
            ['', '', '', '', '', '', '', 'Итого', document.totalQuantity, `${document.rowsCount} позиций`],
        ];
        const workbook = XLSX.utils.book_new();
        const sheet = XLSX.utils.aoa_to_sheet(rows);
        sheet['!cols'] = [6, 20, 18, 18, 18, 46, 16, 14, 12, 36].map((wch) => ({ wch }));
        XLSX.utils.book_append_sheet(workbook, sheet, 'Состав заявки');
        return {
            fileName: `${safeFileName(`sostav-${document.title}-${requestId.slice(0, 8)}`)}.xlsx`,
            mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            content: XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' }),
        };
    }
};
exports.ClientRequestDocumentService = ClientRequestDocumentService;
exports.ClientRequestDocumentService = ClientRequestDocumentService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService])
], ClientRequestDocumentService);
const requestDocumentInclude = {
    client: {
        select: {
            id: true,
            code: true,
            name: true,
            inn: true,
            kpp: true,
            legalAddress: true,
            actualAddress: true,
            email: true,
            phone: true,
        },
    },
    createdBy: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
    assignedTo: {
        select: {
            id: true,
            email: true,
            name: true,
        },
    },
    items: {
        include: {
            sku: {
                select: {
                    id: true,
                    internalSku: true,
                    clientSku: true,
                    article: true,
                    name: true,
                    color: true,
                    size: true,
                },
            },
        },
        orderBy: {
            id: 'asc',
        },
    },
    packages: {
        include: client_request_packages_include_1.clientRequestPackageInclude,
        orderBy: {
            createdAt: 'asc',
        },
    },
};
function renderRequestHtml(document) {
    // Русский комментарий: документ заявки строим в HTML, чтобы один и тот же источник можно было печатать и скачать.
    return `<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(document.title)}</title>
  <style>
    body { color: #111827; font-family: Arial, sans-serif; margin: 32px; }
    h1 { font-size: 24px; margin: 0 0 8px; }
    h2 { font-size: 16px; margin: 24px 0 10px; }
    .muted { color: #64748b; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-top: 20px; }
    .box { border: 1px solid #d7dde5; border-radius: 6px; padding: 12px; }
    table { border-collapse: collapse; margin-top: 14px; width: 100%; }
    th, td { border-bottom: 1px solid #d7dde5; font-size: 13px; padding: 8px; text-align: left; vertical-align: top; }
    th { background: #f8fafc; color: #334155; text-transform: uppercase; }
    .right { text-align: right; }
    .total { font-size: 15px; font-weight: 700; }
    @media print { body { margin: 16mm; } }
  </style>
</head>
<body>
  <h1>${escapeHtml(document.title)}</h1>
  <p class="muted">${escapeHtml(document.typeLabel)} · ${escapeHtml(document.priorityLabel)} · ${escapeHtml(document.statusLabel)}</p>
  <div class="grid">
    <section class="box">
      <strong>Клиент</strong>
      <p>${escapeHtml(document.client.name)} (${escapeHtml(document.client.code)})</p>
      <p>ИНН: ${escapeHtml(document.client.inn ?? '-')} · КПП: ${escapeHtml(document.client.kpp ?? '-')}</p>
      <p>${escapeHtml(document.client.legalAddress ?? document.client.actualAddress ?? '-')}</p>
    </section>
    <section class="box">
      <strong>Заявка</strong>
      <p>Создана: ${formatDate(document.createdAt)}</p>
      <p>Город поставки: ${escapeHtml(document.destinationCity ?? '-')}</p>
      <p>Желаемая дата: ${formatDate(document.desiredDate)}</p>
      <p>Ответственный: ${escapeHtml(document.assignedTo?.name ?? document.createdBy?.name ?? '-')}</p>
    </section>
    <section class="box">
      <strong>Контакт</strong>
      <p>${escapeHtml(document.contactName ?? '-')}</p>
      <p>${escapeHtml(document.contactPhone ?? '-')}</p>
      <p>Адрес: ${escapeHtml(document.deliveryAddress ?? '-')}</p>
    </section>
    <section class="box">
      <strong>Комментарии</strong>
      <p>${escapeHtml(document.comment ?? '-')}</p>
      <p>${escapeHtml(document.managerComment ?? '-')}</p>
    </section>
  </div>
  <h2>Состав заявки</h2>
  <table>
    <thead>
      <tr>
        <th>№</th>
        <th>SKU</th>
        <th>Штрихкод</th>
        <th>Наименование</th>
        <th class="right">Кол-во</th>
        <th>Комментарий</th>
      </tr>
    </thead>
    <tbody>
      ${document.rows.length
        ? document.rows
            .map((row) => `<tr>
        <td>${row.position}</td>
        <td>${escapeHtml(row.internalSku ?? row.clientSku ?? row.article ?? '-')}</td>
        <td>${escapeHtml(row.barcode ?? '-')}</td>
        <td>${escapeHtml(row.name ?? '-')}</td>
        <td class="right">${formatNumber(row.quantity)}</td>
        <td>${escapeHtml(row.comment ?? '-')}</td>
      </tr>`)
            .join('')
        : '<tr><td colspan="6">Позиции не указаны.</td></tr>'}
    </tbody>
  </table>
  <p class="right total">Позиций: ${formatNumber(document.rowsCount)} · Количество: ${formatNumber(document.totalQuantity)}</p>
  ${document.packages.length
        ? `<h2>Упаковочные места</h2>
  <table>
    <thead>
      <tr>
        <th>Место</th>
        <th>Параметры</th>
        <th>Состав</th>
        <th>Комментарий</th>
      </tr>
    </thead>
    <tbody>
      ${document.packages
            .map((packagePlace) => `<tr>
        <td>${escapeHtml(packagePlace.packageCode)}</td>
        <td>${escapeHtml(packageDimensions(packagePlace))}</td>
        <td>${escapeHtml(packageItemsSummary(packagePlace))}</td>
        <td>${escapeHtml(packagePlace.comment ?? '-')}</td>
      </tr>`)
            .join('')}
    </tbody>
  </table>`
        : ''}
</body>
</html>`;
}
function packageDimensions(packagePlace) {
    const dimensions = packagePlace.lengthCm && packagePlace.widthCm && packagePlace.heightCm
        ? `${formatNumber(packagePlace.lengthCm)}x${formatNumber(packagePlace.widthCm)}x${formatNumber(packagePlace.heightCm)} см`
        : null;
    const weight = packagePlace.weightGrams ? `${formatNumber(packagePlace.weightGrams)} г` : null;
    return [packagePlace.packageType, dimensions, weight].filter(Boolean).join(' · ') || '-';
}
function packageItemsSummary(packagePlace) {
    return packagePlace.items
        .map((item) => `${item.internalSku ?? item.name ?? item.barcode ?? item.requestItemId} x ${formatNumber(item.quantity)}`)
        .join(', ');
}
function requestTypeLabel(value) {
    const labels = {
        INBOUND: 'Приемка',
        OUTBOUND: 'Отгрузка',
        RETURN: 'Возврат',
        DELIVERY: 'Доставка',
        SERVICE: 'Услуга',
        SKU_COLLECTION: 'Сборка по SKU',
        OTHER: 'Другое',
    };
    return labels[value];
}
function requestStatusLabel(value) {
    const labels = {
        SUBMITTED: 'Новая',
        IN_REVIEW: 'На проверке',
        APPROVED: 'Согласована',
        IN_WORK: 'В работе',
        PACKED: 'Упакована',
        DONE: 'Сдано',
        CANCELLED: 'Отменена',
        REJECTED: 'Отклонена',
    };
    return labels[value];
}
function requestPriorityLabel(value) {
    const labels = {
        LOW: 'Низкий',
        NORMAL: 'Обычный',
        HIGH: 'Высокий',
        URGENT: 'Срочный',
    };
    return labels[value];
}
function escapeHtml(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
function formatDate(value) {
    if (!value) {
        return '-';
    }
    return new Intl.DateTimeFormat('ru-RU').format(new Date(value));
}
function formatNumber(value) {
    return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 3 }).format(value);
}
function formatRequestNumber(value) {
    return String(value).padStart(6, '0');
}
function safeFileName(value) {
    return value.replace(/[^a-zA-Z0-9а-яА-ЯёЁ._-]+/g, '_');
}
