"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestEmergencyService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const XLSX = __importStar(require("xlsx"));
const prisma_service_1 = require("../../common/prisma/prisma.service");
const inventory_lock_service_1 = require("../../common/inventory/inventory-lock.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const request_billing_automation_service_1 = require("../billing/request-billing-automation.service");
const logistics_service_1 = require("../logistics/logistics.service");
const client_request_packages_include_1 = require("./client-request-packages.include");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const xlsxMimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const maxFileSizeBytes = 10 * 1024 * 1024;
const emergencyPackageComment = 'Фактический короб из аварийного Excel';
const emergencyItemComment = 'Добавлено автоматически по фактическому составу аварийной упаковки.';
const emergencyFilePrefix = 'Аварийная упаковка - ';
const emergencyMovementPrefix = 'emergency-box-list:';
const emergencyRollbackPrefix = 'emergency-box-list-rollback:';
const blockedEmergencyStatuses = new Set([
    client_1.ClientRequestStatus.DONE,
    client_1.ClientRequestStatus.CANCELLED,
    client_1.ClientRequestStatus.REJECTED,
]);
const emergencyRequestInclude = {
    items: {
        include: {
            sku: {
                include: {
                    barcodes: true,
                },
            },
        },
        orderBy: { id: 'asc' },
    },
};
const emergencyBoxInclude = {
    balances: {
        where: { quantity: { gt: 0 } },
        include: {
            sku: {
                include: {
                    barcodes: true,
                },
            },
        },
        orderBy: [{ skuId: 'asc' }, { status: 'asc' }],
    },
};
let ClientRequestEmergencyService = class ClientRequestEmergencyService {
    prisma;
    clientScopes;
    logistics;
    billingAutomation;
    inventoryLock;
    constructor(prisma, clientScopes, logistics, billingAutomation, inventoryLock) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.logistics = logistics;
        this.billingAutomation = billingAutomation;
        this.inventoryLock = inventoryLock;
    }
    async closeFromPackedXlsx(requestId, file, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        validateFile(file);
        requireEmergencyAccess(user);
        const boxCodes = parseEmergencyBoxCodes(file.buffer);
        if (boxCodes.length === 0) {
            throw new common_1.BadRequestException('В файле не найдены номера коробов, начинающиеся с FFL.');
        }
        const requestAccess = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: { id: true, clientId: true, warehouseId: true },
        });
        if (!requestAccess) {
            throw new common_1.NotFoundException('Клиентская заявка не найдена.');
        }
        this.clientScopes.requireClientAccess(user, requestAccess.clientId, 'write');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, requestAccess, 'write', 'Заявка не найдена в выбранном филиале.');
        const result = await this.prisma.$transaction(async (tx) => {
            const request = await tx.clientRequest.findUnique({
                where: { id: requestId },
                include: emergencyRequestInclude,
            });
            if (!request) {
                throw new common_1.NotFoundException('Клиентская заявка не найдена.');
            }
            validateRequest(request);
            const existingEmergencyPackage = await tx.clientRequestPackage.findFirst({
                where: {
                    requestId: request.id,
                    comment: emergencyPackageComment,
                },
                select: { id: true },
            });
            if (existingEmergencyPackage) {
                const packages = await tx.clientRequestPackage.findMany({
                    where: { requestId: request.id },
                    select: {
                        id: true,
                        items: {
                            select: { quantity: true },
                        },
                    },
                    orderBy: { createdAt: 'asc' },
                });
                const packedUnits = countPackageUnits(packages);
                return {
                    status: 'ALREADY_APPLIED',
                    requestId: request.id,
                    boxes: packages.length,
                    pallets: calculatePalletCount(packages.length),
                    packedUnits,
                    rows: boxCodes.length,
                    wbFilesReady: true,
                    warnings: [],
                    shortageQuantity: 0,
                    excessQuantity: 0,
                };
            }
            const boxes = await loadBoxes(tx, request.clientId, request.warehouseId, boxCodes);
            const [previousPackages, previousMarkStatuses, previousInvoiceIds, previousChargeIds, previousDeliveryIds] = await Promise.all([
                tx.clientRequestPackage.findMany({
                    where: { requestId: request.id },
                    include: { items: true },
                    orderBy: { createdAt: 'asc' },
                }),
                tx.productMark.findMany({
                    where: { boxId: { in: boxes.map((box) => box.id) } },
                    select: { id: true, status: true },
                }),
                tx.billingInvoice.findMany({ where: { requestId: request.id }, select: { id: true } }),
                tx.billingCharge.findMany({ where: { requestId: request.id }, select: { id: true } }),
                tx.logisticsDeliveryRequest.findMany({ where: { requestId: request.id }, select: { id: true } }),
            ]);
            const actualRequestItems = await ensureRequestItemsForActualStock(tx, request, boxes);
            const packagePlan = buildPackagePlan(actualRequestItems.items, boxes, boxCodes, actualRequestItems.warnings);
            const plan = packagePlan.plan;
            const packedAt = new Date();
            const closureToken = `${packedAt.getTime()}`;
            await tx.clientRequestPackage.deleteMany({ where: { requestId: request.id } });
            const packages = [];
            const createdMovementIds = [];
            for (const packagePlan of plan) {
                packages.push(await tx.clientRequestPackage.create({
                    data: {
                        requestId: request.id,
                        clientId: request.clientId,
                        packageCode: packagePlan.box.code,
                        packageType: 'BOX',
                        comment: emergencyPackageComment,
                        createdByUserId: user.id,
                        items: {
                            create: packagePlan.items,
                        },
                    },
                    include: client_request_packages_include_1.clientRequestPackageInclude,
                }));
                for (const balance of packagePlan.box.balances) {
                    await tx.stockBalance.delete({ where: { id: balance.id } });
                    const movement = await tx.stockMovement.create({
                        data: {
                            clientId: request.clientId,
                            skuId: balance.skuId,
                            boxId: packagePlan.box.id,
                            palletId: balance.palletId,
                            type: client_1.MovementType.SHIP,
                            status: balance.status,
                            quantity: -balance.quantity,
                            sourceDocument: request.id,
                            idempotencyKey: `${emergencyMovementPrefix}${request.id}:${closureToken}:${packagePlan.box.id}:${balance.id}:out`,
                            comment: `Аварийная упаковка заявки ${request.title}: короб ${packagePlan.box.code}`,
                        },
                        select: { id: true },
                    });
                    createdMovementIds.push(movement.id);
                }
                await tx.productMark.updateMany({
                    where: { boxId: packagePlan.box.id },
                    data: { status: client_1.StockStatus.SHIPPING },
                });
                await tx.box.update({
                    where: { id: packagePlan.box.id },
                    data: { status: 'shipped' },
                });
            }
            const packedUnits = countPackageUnits(packages);
            await tx.clientRequest.update({
                where: { id: request.id },
                data: {
                    status: client_1.ClientRequestStatus.PACKED,
                    assignedToUserId: user.id,
                    managerComment: `Аварийно упаковано по списку коробов: ${packages.length} коробов, ${packedUnits} шт.${packagePlan.warnings.length > 0 ? ` Расхождений: ${packagePlan.warnings.length}.` : ''}`,
                },
            });
            const sourceFile = await tx.clientRequestFile.create({
                data: {
                    requestId: request.id,
                    clientId: request.clientId,
                    fileName: `${emergencyFilePrefix}${safeFileName(file.originalname)}`,
                    mimeType: file.mimetype || xlsxMimeType,
                    sizeBytes: file.size,
                    content: Uint8Array.from(file.buffer),
                    uploadedByUserId: user.id,
                },
                select: { id: true },
            });
            const closureSnapshot = {
                version: 1,
                closedAt: packedAt.toISOString(),
                previousStatus: request.status,
                previousManagerComment: request.managerComment,
                previousAssignedToUserId: request.assignedToUserId,
                previousPackages: previousPackages.map(storePackage),
                previousBoxStatuses: boxes.map((box) => ({ id: box.id, status: box.status })),
                previousMarkStatuses,
                previousInvoiceIds: previousInvoiceIds.map((entry) => entry.id),
                previousChargeIds: previousChargeIds.map((entry) => entry.id),
                previousDeliveryIds: previousDeliveryIds.map((entry) => entry.id),
                createdPackageIds: packages.map((entry) => entry.id),
                createdMovementIds,
                autoAddedRequestItemIds: actualRequestItems.createdItemIds,
                sourceFileId: sourceFile.id,
            };
            if (packages[0]) {
                await tx.clientRequestPackage.update({
                    where: { id: packages[0].id },
                    data: {
                        metadata: {
                            emergencyClosure: closureSnapshot,
                        },
                    },
                });
            }
            const events = [
                {
                    requestId: request.id,
                    clientId: request.clientId,
                    eventType: client_1.ClientRequestEventType.STATUS_CHANGED,
                    title: 'Заявка аварийно упакована',
                    body: `Коробов: ${packages.length}, единиц: ${packedUnits}.`,
                    statusFrom: request.status,
                    statusTo: client_1.ClientRequestStatus.PACKED,
                    createdByUserId: user.id,
                    createdAt: packedAt,
                },
                {
                    requestId: request.id,
                    clientId: request.clientId,
                    eventType: client_1.ClientRequestEventType.FILE_UPLOADED,
                    title: 'Загружен аварийный список коробов',
                    body: safeFileName(file.originalname),
                    createdByUserId: user.id,
                    createdAt: packedAt,
                },
            ];
            if (packagePlan.warnings.length > 0) {
                events.push({
                    requestId: request.id,
                    clientId: request.clientId,
                    eventType: client_1.ClientRequestEventType.COMMENT,
                    title: 'Расхождения аварийной упаковки',
                    body: packagePlan.warnings.map((warning) => warning.message).slice(0, 12).join('\n'),
                    createdByUserId: user.id,
                    createdAt: packedAt,
                });
            }
            await tx.clientRequestEvent.createMany({
                data: events,
            });
            return {
                status: 'APPLIED',
                requestId: request.id,
                boxes: packages.length,
                pallets: calculatePalletCount(packages.length),
                packedUnits,
                rows: boxCodes.length,
                wbFilesReady: true,
                warnings: packagePlan.warnings,
                shortageQuantity: packagePlan.shortageQuantity,
                excessQuantity: packagePlan.excessQuantity,
            };
        });
        let logistics;
        try {
            logistics = await this.logistics?.ensurePackedRequestBilling(result.requestId, user);
        }
        catch (caught) {
            logistics = { status: 'FAILED', message: exceptionMessage(caught) };
        }
        let billing;
        try {
            billing = await this.billingAutomation?.generateForDoneRequest(result.requestId, user);
        }
        catch (caught) {
            billing = { status: 'FAILED', message: exceptionMessage(caught) };
        }
        return { ...result, logistics, billing };
    }
    async rollbackPackedXlsx(requestId, user) {
        await this.inventoryLock?.assertStockMovementsAllowed();
        requireEmergencyAccess(user);
        const requestAccess = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: { id: true, clientId: true, warehouseId: true },
        });
        if (!requestAccess) {
            throw new common_1.NotFoundException('Клиентская заявка не найдена.');
        }
        this.clientScopes.requireClientAccess(user, requestAccess.clientId, 'write');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, requestAccess, 'write', 'Заявка не найдена в выбранном филиале.');
        return this.prisma.$transaction(async (tx) => {
            const request = await tx.clientRequest.findUnique({
                where: { id: requestId },
                select: {
                    id: true,
                    warehouseId: true,
                    clientId: true,
                    title: true,
                    type: true,
                    status: true,
                    managerComment: true,
                    assignedToUserId: true,
                },
            });
            if (!request) {
                throw new common_1.NotFoundException('Клиентская заявка не найдена.');
            }
            if (request.type !== client_1.ClientRequestType.OUTBOUND) {
                throw new common_1.BadRequestException('Отмена аварийного закрытия доступна только для заявки на отгрузку.');
            }
            if (request.status !== client_1.ClientRequestStatus.PACKED) {
                throw new common_1.BadRequestException('Отменить аварийное закрытие можно только пока заявка находится в статусе «Упакована».');
            }
            const activePackages = await tx.clientRequestPackage.findMany({
                where: { requestId: request.id, comment: emergencyPackageComment },
                select: { id: true, metadata: true },
                orderBy: { createdAt: 'asc' },
            });
            if (activePackages.length === 0) {
                throw new common_1.BadRequestException('У заявки нет активного аварийного закрытия.');
            }
            const snapshot = readClosureSnapshot(activePackages);
            const emergencyEvent = await tx.clientRequestEvent.findFirst({
                where: {
                    requestId: request.id,
                    eventType: client_1.ClientRequestEventType.STATUS_CHANGED,
                    statusTo: client_1.ClientRequestStatus.PACKED,
                    title: 'Заявка аварийно упакована',
                },
                select: { statusFrom: true, createdAt: true },
                orderBy: { createdAt: 'desc' },
            });
            const closedAt = snapshot ? new Date(snapshot.closedAt) : emergencyEvent?.createdAt ?? new Date(0);
            const movementWhere = snapshot?.createdMovementIds.length
                ? { id: { in: snapshot.createdMovementIds } }
                : {
                    sourceDocument: request.id,
                    type: client_1.MovementType.SHIP,
                    quantity: { lt: 0 },
                    idempotencyKey: { startsWith: `${emergencyMovementPrefix}${request.id}:` },
                    createdAt: { gte: closedAt },
                };
            const movements = await tx.stockMovement.findMany({
                where: movementWhere,
                select: {
                    id: true,
                    warehouseId: true,
                    clientId: true,
                    skuId: true,
                    boxId: true,
                    palletId: true,
                    status: true,
                    quantity: true,
                },
                orderBy: { createdAt: 'asc' },
            });
            if (movements.length === 0) {
                throw new common_1.BadRequestException('Не найдены складские движения аварийного закрытия. Откат остановлен без изменений.');
            }
            const financialRollback = await rollbackEmergencyFinancialArtifacts(tx, request.id, snapshot, closedAt);
            let restoredUnits = 0;
            for (const movement of movements) {
                const quantity = Math.abs(movement.quantity);
                const warehouseId = movement.warehouseId ??
                    request.warehouseId ??
                    null;
                if (!warehouseId) {
                    throw new common_1.BadRequestException('Не удалось определить филиал возвращаемого остатка. Откат остановлен без изменений.');
                }
                restoredUnits += quantity;
                const balanceKey = stockBalanceKey({ ...movement, warehouseId });
                await tx.stockBalance.upsert({
                    where: { balanceKey },
                    update: {
                        quantity: { increment: quantity },
                        warehouseId,
                    },
                    create: {
                        balanceKey,
                        warehouseId,
                        clientId: movement.clientId,
                        skuId: movement.skuId,
                        boxId: movement.boxId,
                        palletId: movement.palletId,
                        status: movement.status,
                        quantity,
                    },
                });
                await tx.stockMovement.create({
                    data: {
                        warehouseId,
                        clientId: movement.clientId,
                        skuId: movement.skuId,
                        boxId: movement.boxId,
                        palletId: movement.palletId,
                        type: client_1.MovementType.INVENTORY_ADJUSTMENT,
                        status: movement.status,
                        quantity,
                        sourceDocument: request.id,
                        idempotencyKey: `${emergencyRollbackPrefix}${request.id}:${movement.id}`,
                        comment: `Отмена аварийного закрытия заявки ${request.title}`,
                    },
                });
            }
            await restoreProductMarks(tx, snapshot, movements);
            await restoreBoxStatuses(tx, snapshot, movements);
            await tx.clientRequestPackage.deleteMany({ where: { requestId: request.id } });
            if (snapshot) {
                await restorePackages(tx, request.id, request.clientId, snapshot.previousPackages);
            }
            const autoAddedItemIds = snapshot?.autoAddedRequestItemIds ?? (await tx.clientRequestItem.findMany({
                where: { requestId: request.id, comment: emergencyItemComment },
                select: { id: true },
            })).map((item) => item.id);
            if (autoAddedItemIds.length > 0) {
                await tx.clientRequestItem.deleteMany({ where: { id: { in: autoAddedItemIds } } });
            }
            if (snapshot?.sourceFileId) {
                await tx.clientRequestFile.deleteMany({ where: { id: snapshot.sourceFileId, requestId: request.id } });
            }
            else {
                const legacyFile = await tx.clientRequestFile.findFirst({
                    where: {
                        requestId: request.id,
                        fileName: { startsWith: emergencyFilePrefix },
                        createdAt: { gte: closedAt },
                    },
                    select: { id: true },
                    orderBy: { createdAt: 'desc' },
                });
                if (legacyFile) {
                    await tx.clientRequestFile.delete({ where: { id: legacyFile.id } });
                }
            }
            const restoredStatus = snapshot?.previousStatus ?? emergencyEvent?.statusFrom ?? client_1.ClientRequestStatus.IN_WORK;
            await tx.clientRequest.update({
                where: { id: request.id },
                data: {
                    status: restoredStatus,
                    managerComment: snapshot?.previousManagerComment ?? null,
                    assignedToUserId: snapshot?.previousAssignedToUserId ?? null,
                },
            });
            await tx.clientRequestEvent.create({
                data: {
                    requestId: request.id,
                    clientId: request.clientId,
                    eventType: client_1.ClientRequestEventType.STATUS_CHANGED,
                    title: 'Аварийное закрытие отменено',
                    body: `Восстановлено ${restoredUnits} шт. в ${new Set(movements.map((movement) => movement.boxId).filter(Boolean)).size} коробах.`,
                    statusFrom: client_1.ClientRequestStatus.PACKED,
                    statusTo: restoredStatus,
                    createdByUserId: user.id,
                },
            });
            return {
                status: 'REVERSED',
                requestId: request.id,
                restoredStatus,
                restoredBoxes: new Set(movements.map((movement) => movement.boxId).filter(Boolean)).size,
                restoredUnits,
                removedPackages: activePackages.length,
                restoredPackages: snapshot?.previousPackages.length ?? 0,
                removedAutoItems: autoAddedItemIds.length,
                ...financialRollback,
            };
        });
    }
};
exports.ClientRequestEmergencyService = ClientRequestEmergencyService;
exports.ClientRequestEmergencyService = ClientRequestEmergencyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        logistics_service_1.LogisticsService,
        request_billing_automation_service_1.RequestBillingAutomationService,
        inventory_lock_service_1.InventoryLockService])
], ClientRequestEmergencyService);
async function rollbackEmergencyFinancialArtifacts(tx, requestId, snapshot, closedAt) {
    const generatedInvoiceKeys = [
        `request:${requestId}:all-services`,
        `request:${requestId}:services`,
        `request:${requestId}:logistics`,
    ];
    const invoices = await tx.billingInvoice.findMany({
        where: {
            requestId,
            sourceKey: { in: generatedInvoiceKeys },
            ...(snapshot
                ? { id: { notIn: snapshot.previousInvoiceIds } }
                : { createdAt: { gte: closedAt } }),
        },
        select: {
            id: true,
            number: true,
            status: true,
            payments: { select: { id: true } },
        },
    });
    const blockingInvoice = invoices.find((invoice) => invoice.payments.length > 0 ||
        !new Set([client_1.BillingInvoiceStatus.DRAFT, client_1.BillingInvoiceStatus.CANCELLED]).has(invoice.status));
    if (blockingInvoice) {
        throw new common_1.BadRequestException(`Счет ${blockingInvoice.number} уже выставлен или оплачен. Сначала отмените его в биллинге; складской откат не выполнен.`);
    }
    if (invoices.length > 0) {
        await tx.billingInvoice.deleteMany({ where: { id: { in: invoices.map((invoice) => invoice.id) } } });
    }
    const deliveries = (await tx.logisticsDeliveryRequest.findMany({
        where: {
            requestId,
            ...(snapshot
                ? { id: { notIn: snapshot.previousDeliveryIds } }
                : { createdAt: { gte: closedAt } }),
        },
        select: {
            id: true,
            status: true,
            tripId: true,
            billingChargeId: true,
            comment: true,
        },
    })).filter((delivery) => delivery.comment?.startsWith('Автоматически создано после упаковки заявки'));
    const blockingDelivery = deliveries.find((delivery) => delivery.tripId ||
        !new Set([
            client_1.LogisticsDeliveryStatus.REQUESTED,
            client_1.LogisticsDeliveryStatus.QUOTED,
            client_1.LogisticsDeliveryStatus.CANCELLED,
        ]).has(delivery.status));
    if (blockingDelivery) {
        throw new common_1.BadRequestException('Автоматическая заявка на логистику уже передана в рейс. Сначала отмените рейс; складской откат не выполнен.');
    }
    const deliveryChargeIds = deliveries
        .map((delivery) => delivery.billingChargeId)
        .filter((id) => Boolean(id));
    if (deliveries.length > 0) {
        await tx.logisticsDeliveryRequest.updateMany({
            where: { id: { in: deliveries.map((delivery) => delivery.id) } },
            data: { billingChargeId: null },
        });
        await tx.logisticsDeliveryRequest.deleteMany({ where: { id: { in: deliveries.map((delivery) => delivery.id) } } });
    }
    const logisticsCharges = await tx.billingCharge.findMany({
        where: {
            requestId,
            source: client_1.BillingChargeSource.LOGISTICS,
            OR: [
                ...(deliveryChargeIds.length > 0 ? [{ id: { in: deliveryChargeIds } }] : []),
                snapshot
                    ? { id: { notIn: snapshot.previousChargeIds } }
                    : { createdAt: { gte: closedAt } },
            ],
        },
        select: {
            id: true,
            invoiceItems: { select: { id: true } },
            deliveryRequests: { select: { id: true } },
        },
    });
    const removableCharges = logisticsCharges.filter((charge) => charge.invoiceItems.length === 0 && charge.deliveryRequests.length === 0);
    if (removableCharges.length > 0) {
        await tx.billingCharge.deleteMany({ where: { id: { in: removableCharges.map((charge) => charge.id) } } });
    }
    return {
        removedInvoices: invoices.length,
        removedDeliveryRequests: deliveries.length,
        removedBillingCharges: removableCharges.length,
    };
}
async function restoreProductMarks(tx, snapshot, movements) {
    if (snapshot?.previousMarkStatuses.length) {
        const idsByStatus = new Map();
        snapshot.previousMarkStatuses.forEach((mark) => {
            idsByStatus.set(mark.status, [...(idsByStatus.get(mark.status) ?? []), mark.id]);
        });
        for (const [status, ids] of idsByStatus) {
            await tx.productMark.updateMany({ where: { id: { in: ids } }, data: { status } });
        }
        return;
    }
    const boxIds = uniqueStrings(movements.map((movement) => movement.boxId));
    if (boxIds.length > 0) {
        await tx.productMark.updateMany({
            where: { boxId: { in: boxIds }, status: client_1.StockStatus.SHIPPING },
            data: { status: client_1.StockStatus.AVAILABLE },
        });
    }
}
async function restoreBoxStatuses(tx, snapshot, movements) {
    if (snapshot?.previousBoxStatuses.length) {
        for (const box of snapshot.previousBoxStatuses) {
            await tx.box.update({ where: { id: box.id }, data: { status: box.status } });
        }
        return;
    }
    const boxIds = uniqueStrings(movements.map((movement) => movement.boxId));
    if (boxIds.length > 0) {
        await tx.box.updateMany({ where: { id: { in: boxIds } }, data: { status: 'active' } });
    }
}
async function restorePackages(tx, requestId, clientId, packages) {
    for (const packagePlace of packages) {
        await tx.clientRequestPackage.create({
            data: {
                id: packagePlace.id,
                requestId,
                clientId,
                packageCode: packagePlace.packageCode,
                packageType: packagePlace.packageType,
                weightGrams: packagePlace.weightGrams,
                lengthCm: packagePlace.lengthCm,
                widthCm: packagePlace.widthCm,
                heightCm: packagePlace.heightCm,
                comment: packagePlace.comment,
                metadata: packagePlace.metadata === null
                    ? client_1.Prisma.JsonNull
                    : packagePlace.metadata,
                createdByUserId: packagePlace.createdByUserId,
                createdAt: new Date(packagePlace.createdAt),
                items: {
                    create: packagePlace.items.map((item) => ({
                        id: item.id,
                        requestItemId: item.requestItemId,
                        skuId: item.skuId,
                        barcode: item.barcode,
                        quantity: item.quantity,
                    })),
                },
            },
        });
    }
}
function storePackage(packagePlace) {
    return {
        id: packagePlace.id,
        packageCode: packagePlace.packageCode,
        packageType: packagePlace.packageType,
        weightGrams: packagePlace.weightGrams,
        lengthCm: packagePlace.lengthCm?.toString() ?? null,
        widthCm: packagePlace.widthCm?.toString() ?? null,
        heightCm: packagePlace.heightCm?.toString() ?? null,
        comment: packagePlace.comment,
        metadata: packagePlace.metadata,
        createdByUserId: packagePlace.createdByUserId,
        createdAt: packagePlace.createdAt.toISOString(),
        items: packagePlace.items.map((item) => ({
            id: item.id,
            requestItemId: item.requestItemId,
            skuId: item.skuId,
            barcode: item.barcode,
            quantity: item.quantity,
        })),
    };
}
function readClosureSnapshot(packages) {
    for (const packagePlace of packages) {
        if (!isJsonObject(packagePlace.metadata)) {
            continue;
        }
        const value = packagePlace.metadata.emergencyClosure;
        if (isJsonObject(value) && value.version === 1 && typeof value.closedAt === 'string') {
            return value;
        }
    }
    return null;
}
function stockBalanceKey(input) {
    const parts = [
        input.clientId,
        input.skuId,
        input.boxId ?? 'no-box',
        input.palletId ?? 'no-pallet',
        input.status,
    ];
    if (!input.boxId && !input.palletId) {
        parts.push('warehouse', input.warehouseId);
    }
    return parts.join(':');
}
function uniqueStrings(values) {
    return [...new Set(values.filter((value) => Boolean(value)))];
}
function isJsonObject(value) {
    return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}
async function loadBoxes(tx, clientId, warehouseId, boxCodes) {
    const boxes = await tx.box.findMany({
        where: {
            clientId,
            warehouseId: warehouseId ?? undefined,
            OR: boxCodes.map((code) => ({ code: { equals: code, mode: client_1.Prisma.QueryMode.insensitive } })),
        },
        include: emergencyBoxInclude,
    });
    const boxByCode = new Map(boxes.map((box) => [normalizeCode(box.code), box]));
    const missing = boxCodes.filter((code) => !boxByCode.has(normalizeCode(code)));
    if (missing.length > 0) {
        throw new common_1.BadRequestException(`Короба не найдены у клиента: ${missing.slice(0, 12).join(', ')}.`);
    }
    return boxCodes.map((code) => boxByCode.get(normalizeCode(code)));
}
async function ensureRequestItemsForActualStock(tx, request, boxes) {
    const items = [...request.items];
    const warnings = [];
    const createdItemIds = [];
    const balancesBySku = new Map();
    for (const box of boxes) {
        for (const balance of box.balances) {
            const current = balancesBySku.get(balance.skuId) ?? [];
            current.push(balance);
            balancesBySku.set(balance.skuId, current);
        }
    }
    for (const balances of balancesBySku.values()) {
        const sample = balances[0];
        if (!sample || items.some((item) => requestItemMatchesBalance(item, sample))) {
            continue;
        }
        const quantity = balances.reduce((sum, balance) => sum + balance.quantity, 0);
        const barcode = primaryBarcode(sample);
        const created = await tx.clientRequestItem.create({
            data: {
                requestId: request.id,
                skuId: sample.skuId,
                barcode,
                name: sample.sku.name,
                quantity,
                comment: emergencyItemComment,
            },
            include: {
                sku: {
                    include: {
                        barcodes: true,
                    },
                },
            },
        });
        items.push(created);
        createdItemIds.push(created.id);
        warnings.push({
            code: 'UNLISTED_ITEM',
            message: `В фактических коробах найден товар ${sample.sku.name} (${barcode ?? sample.sku.internalSku}), которого не было в заявке: ${quantity} шт. Позиция добавлена в фактическую упаковку и списана.`,
            quantity,
            skuId: sample.skuId,
            barcode,
        });
    }
    return { items, warnings, createdItemIds };
}
function requestItemMatchesBalance(item, balance) {
    if (item.skuId === balance.skuId) {
        return true;
    }
    const itemBarcodes = new Set();
    if (item.barcode) {
        itemBarcodes.add(normalizeCode(item.barcode));
    }
    item.sku?.barcodes.forEach((barcode) => itemBarcodes.add(normalizeCode(barcode.value)));
    const relabel = parseRelabelComment(item.comment);
    if (relabel.sourceBarcode) {
        itemBarcodes.add(normalizeCode(relabel.sourceBarcode));
    }
    if (relabel.targetBarcode) {
        itemBarcodes.add(normalizeCode(relabel.targetBarcode));
    }
    return balance.sku.barcodes.some((barcode) => itemBarcodes.has(normalizeCode(barcode.value)));
}
function buildPackagePlan(items, boxes, boxCodes, initialWarnings = []) {
    const requestLines = buildRequestLines(items);
    const warnings = [...initialWarnings];
    const plan = [];
    let excessQuantity = initialWarnings.reduce((sum, warning) => sum + (warning.code === 'UNLISTED_ITEM' ? warning.quantity : 0), 0);
    boxes.forEach((box, boxIndex) => {
        if (box.balances.length === 0) {
            warnings.push({
                code: 'EMPTY_BOX',
                message: `Короб ${boxCodes[boxIndex]} пуст или уже был списан. Короб включен в фактическую упаковку без товара.`,
                quantity: 0,
                boxCode: box.code,
            });
            plan.push({ box, items: [] });
            return;
        }
        const packageItems = new Map();
        for (const balance of box.balances) {
            excessQuantity += allocateBalance(requestLines, balance, packageItems, warnings, box.code);
        }
        plan.push({ box, items: [...packageItems.values()] });
    });
    let shortageQuantity = 0;
    for (const line of requestLines) {
        if (line.remaining > 0) {
            shortageQuantity += line.remaining;
            const relabelDifference = Boolean(line.relabelSourceBarcode || line.relabelTargetBarcode);
            warnings.push({
                code: relabelDifference ? 'RELABEL_DIFFERENCE' : 'SHORTAGE',
                message: relabelDifference
                    ? `По перемаркировке ${line.relabelSourceBarcode ?? 'исходный ШК'} → ${line.relabelTargetBarcode ?? 'новый ШК'} не сопоставлено ${line.remaining} шт. Возможно, товар уже перемаркирован. Повторное списание не выполнялось; заявка упакована по фактическим коробам.`
                    : `В выбранных коробах не хватает ${line.remaining} шт. по позиции ${line.label}. Заявка все равно упакована по фактическому списку коробов.`,
                quantity: line.remaining,
                skuId: line.skuId ?? undefined,
            });
        }
    }
    return { plan, warnings, shortageQuantity, excessQuantity };
}
function allocateBalance(requestLines, balance, packageItems, warnings, boxCode) {
    let remaining = balance.quantity;
    const balanceBarcodes = new Set(balance.sku.barcodes.map((barcode) => normalizeCode(barcode.value)));
    const candidates = requestLines.filter((line) => (line.skuId === balance.skuId || [...line.barcodes].some((barcode) => balanceBarcodes.has(barcode))));
    for (const line of candidates.filter((candidate) => candidate.remaining > 0)) {
        if (remaining <= 0) {
            break;
        }
        const quantity = Math.min(remaining, line.remaining);
        line.remaining -= quantity;
        remaining -= quantity;
        addPackageAllocation(packageItems, line, balance, quantity);
    }
    if (remaining <= 0) {
        return 0;
    }
    const fallbackLine = candidates[0];
    if (fallbackLine) {
        addPackageAllocation(packageItems, fallbackLine, balance, remaining);
    }
    warnings.push({
        code: 'EXCESS',
        message: `В коробе ${boxCode} на ${remaining} шт. больше товара ${balance.sku.name} (${primaryBarcode(balance) ?? balance.sku.internalSku}), чем в заявке. Фактический излишек списан вместе с коробом.`,
        quantity: remaining,
        boxCode,
        skuId: balance.skuId,
        barcode: primaryBarcode(balance),
    });
    return remaining;
}
function addPackageAllocation(packageItems, line, balance, quantity) {
    const barcode = preferredBarcode(line, balance);
    const key = `${line.id}:${balance.skuId}:${barcode ?? ''}`;
    const current = packageItems.get(key) ?? {
        requestItemId: line.id,
        skuId: balance.skuId,
        barcode,
        quantity: 0,
    };
    current.quantity += quantity;
    packageItems.set(key, current);
}
function buildRequestLines(items) {
    return items.map((item) => {
        const relabel = parseRelabelComment(item.comment);
        const barcodes = new Set();
        if (item.barcode) {
            barcodes.add(normalizeCode(item.barcode));
        }
        item.sku?.barcodes.forEach((barcode) => barcodes.add(normalizeCode(barcode.value)));
        if (relabel.sourceBarcode) {
            barcodes.add(normalizeCode(relabel.sourceBarcode));
        }
        if (relabel.targetBarcode) {
            barcodes.add(normalizeCode(relabel.targetBarcode));
        }
        return {
            id: item.id,
            skuId: item.skuId,
            label: item.name ?? item.sku?.name ?? item.sku?.internalSku ?? item.barcode ?? item.id,
            remaining: item.quantity,
            barcodes,
            relabelSourceBarcode: relabel.sourceBarcode,
            relabelTargetBarcode: relabel.targetBarcode,
        };
    });
}
function preferredBarcode(line, balance) {
    if (line.relabelTargetBarcode) {
        return line.relabelTargetBarcode;
    }
    const matching = balance.sku.barcodes.find((barcode) => line.barcodes.has(normalizeCode(barcode.value)));
    return matching?.value ?? primaryBarcode(balance) ?? null;
}
function parseRelabelComment(comment) {
    let sourceBarcode = null;
    let targetBarcode = null;
    comment?.split(';').forEach((part) => {
        const [rawKey, ...rawValue] = part.split(':');
        const key = rawKey.trim().toLowerCase();
        const value = rawValue.join(':').trim();
        if (key === 'перемаркировка из' && value) {
            sourceBarcode = value;
        }
        else if (key === 'перемаркировка в' && value) {
            targetBarcode = value;
        }
    });
    return { sourceBarcode, targetBarcode };
}
function primaryBarcode(balance) {
    return balance.sku.barcodes.find((barcode) => barcode.isPrimary)?.value ?? balance.sku.barcodes[0]?.value ?? null;
}
function countPackageUnits(packages) {
    return packages.reduce((packageTotal, packagePlace) => packageTotal + packagePlace.items.reduce((itemTotal, item) => itemTotal + item.quantity, 0), 0);
}
function parseEmergencyBoxCodes(buffer) {
    const workbook = XLSX.read(buffer, { type: 'buffer', cellDates: false });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    if (!sheet) {
        return [];
    }
    const matrix = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        raw: false,
        defval: '',
        blankrows: false,
    });
    const seen = new Set();
    const result = [];
    for (const row of matrix) {
        const code = row.map((cell) => String(cell ?? '').trim()).find(isBoxCode);
        if (!code) {
            continue;
        }
        const normalized = normalizeCode(code);
        if (!seen.has(normalized)) {
            seen.add(normalized);
            result.push(code.trim());
        }
    }
    return result;
}
function validateFile(file) {
    if (!file?.buffer?.length) {
        throw new common_1.BadRequestException('Файл не передан.');
    }
    if (file.size > maxFileSizeBytes) {
        throw new common_1.BadRequestException('Файл больше 10 МБ.');
    }
}
function validateRequest(request) {
    if (request.type !== client_1.ClientRequestType.OUTBOUND) {
        throw new common_1.BadRequestException('Аварийная упаковка доступна только для заявок на отгрузку.');
    }
    if (blockedEmergencyStatuses.has(request.status)) {
        throw new common_1.BadRequestException('Нельзя аварийно упаковать закрытую, отмененную или отклоненную заявку.');
    }
    if (request.items.length === 0) {
        throw new common_1.BadRequestException('В заявке нет товаров для сверки с коробами.');
    }
}
function requireEmergencyAccess(user) {
    const allowed = user.permissionCodes.includes('system:admin') ||
        user.roleCodes.some((role) => role === 'ADMIN' || role === 'OWNER');
    if (!allowed) {
        throw new common_1.ForbiddenException('Аварийная упаковка доступна только владельцу или администратору.');
    }
}
function calculatePalletCount(boxes) {
    const fullPallets = Math.floor(boxes / 16);
    return fullPallets + (boxes % 16 > 4 ? 1 : 0);
}
function isBoxCode(value) {
    return /^FFL[_\w-]*$/iu.test(value.trim());
}
function normalizeCode(value) {
    return value.trim().toLocaleUpperCase('ru-RU');
}
function safeFileName(value) {
    const normalized = normalizeUploadedFileName(value);
    return normalized.replace(/[\\/:*?"<>|]+/g, '_').trim() || 'emergency.xlsx';
}
function normalizeUploadedFileName(value) {
    const normalized = value?.trim() ?? '';
    if (!/[ÃÐÑ]/.test(normalized)) {
        return normalized;
    }
    const decoded = Buffer.from(normalized, 'latin1').toString('utf8');
    return decoded.includes('�') ? normalized : decoded;
}
function exceptionMessage(caught) {
    return caught instanceof Error ? caught.message : 'Не удалось автоматически подготовить биллинг заявки.';
}
