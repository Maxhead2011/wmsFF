"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FBS_WB_ACCOUNTED_ACTION = exports.FBS_WB_ACCOUNTED = void 0;
exports.fbsWbAccountingEnabled = fbsWbAccountingEnabled;
exports.isFbsWbAccounted = isFbsWbAccounted;
exports.isFbsWbAccountingStatus = isFbsWbAccountingStatus;
exports.isFbsWbKizShipmentCandidate = isFbsWbKizShipmentCandidate;
exports.isFbsWbAccountingUntouched = isFbsWbAccountingUntouched;
exports.FBS_WB_ACCOUNTED = 'WB_ACCOUNTED';
exports.FBS_WB_ACCOUNTED_ACTION = 'FBS_WB_ORDER_ACCOUNTED';
// FIX: only our explicitly enabled FBS workflow offers manager accounting.
function fbsWbAccountingEnabled() {
    return process.env.WMS_FBS_NO_STOCK_TRANSFER_ENABLED === 'true' &&
        process.env.WMS_FBS_RESHIPMENT_ENABLED === 'true' &&
        process.env.WMS_FBS_TERMINAL_QUEUE_FILTER_ENABLED === 'true';
}
function isFbsWbAccounted(row) {
    return row?.marketplace === 'WILDBERRIES' && row.syncStatus === exports.FBS_WB_ACCOUNTED;
}
// FIX: absence of transfer permission alone is insufficient (cancellations are excluded).
function isFbsWbAccountingStatus(status) {
    return status?.supplierStatus === 'complete' && ['sorted', 'sold', 'ready_for_pickup', 'accepted_by_carrier'].includes(status.wbStatus ?? '');
}
// FIX: a linked exact pair can be shipped after WB verification, including an unknown source box.
function isFbsWbKizShipmentCandidate(task) {
    return task.itemCount === 1 && Boolean(task.kiz?.trim() && task.barcode?.trim()) &&
        ['WAITING_STOCK', 'RESERVED', 'RELEASED', 'IN_PROGRESS', 'COMPLETED', 'RETURN_REQUIRED'].includes(task.status);
}
function isFbsWbAccountingUntouched(task) {
    return ['WAITING_STOCK', 'RESERVED', 'RELEASED'].includes(task.status) && task.itemCount === 1 &&
        !task.boxId && !task.barcode && !task.sourceBarcode && !task.kiz && !task.completedAt &&
        !task.sourceBoxPending && !task.relabelConfirmedAt && !task.cargoPackingId && !task.cargoPackedAt &&
        !task.marketplaceSubmittedAt && !task.stickerBarcode && !task.stickerPartA && !task.stickerPartB;
}
