"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.doneRequestPackingEnabled = void 0;
exports.donePackingQuantity = donePackingQuantity;
exports.reconcileDoneRequestPacking = reconcileDoneRequestPacking;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
// FIX: opt-in only for our installation; sold WMS retains its existing behavior.
const doneRequestPackingEnabled = () => process.env.WMS_DONE_PACKING_RECONCILIATION_ENABLED === 'true';
exports.doneRequestPackingEnabled = doneRequestPackingEnabled;
// FIX: a request may consume only its proven residual, never another request's stock.
function donePackingQuantity(requestId, quantity, ledger) {
    const byRequest = new Map();
    for (const row of ledger)
        byRequest.set(row.sourceDocument, (byRequest.get(row.sourceDocument) ?? 0) + row.quantity);
    const own = byRequest.get(requestId) ?? 0;
    if (own <= 0)
        return 0;
    // FIX: an earlier deduction cannot consume a later pick. Missing timestamps
    // or deductions after this request's first pick remain ambiguous and blocked.
    const ownCredits = ledger.filter(row => row.sourceDocument === requestId && row.quantity > 0);
    const firstPick = ownCredits.every(row => row.createdAt && Number.isFinite(row.createdAt.getTime()))
        ? Math.min(...ownCredits.map(row => row.createdAt.getTime())) : NaN;
    const ambiguous = [...byRequest].some(([document, total]) => total < 0 &&
        (!Number.isFinite(firstPick) || ledger.some(row => row.sourceDocument === document && row.quantity < 0 &&
            (!row.createdAt || !Number.isFinite(row.createdAt.getTime()) || row.createdAt.getTime() >= firstPick))));
    if (ambiguous ||
        ledger.reduce((sum, row) => sum + row.quantity, 0) !== quantity || own > quantity) {
        throw new common_1.ConflictException('Остаток «В сборке» не сходится с движениями заявок. Требуется сверка, автоматическое списание остановлено.');
    }
    return own;
}
// FIX: run inside the caller's transaction; all balances are checked before any debit.
async function reconcileDoneRequestPacking(tx, requestId, dryRun = false) {
    if (!dryRun && !(0, exports.doneRequestPackingEnabled)())
        return 0;
    if (!dryRun)
        await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${requestId} FOR UPDATE`;
    const request = await tx.clientRequest.findUnique({ where: { id: requestId }, select: {
            id: true, number: true, clientId: true, warehouseId: true, status: true, type: true,
        } });
    if (!request || request.status !== 'DONE' || !['OUTBOUND', 'DELIVERY'].includes(request.type))
        return 0;
    const groups = await tx.stockMovement.groupBy({ by: ['warehouseId', 'skuId', 'boxId', 'palletId'],
        where: { clientId: request.clientId, sourceDocument: request.id, status: 'PACKING' }, _sum: { quantity: true },
    });
    const candidates = groups.filter(group => (group._sum.quantity ?? 0) > 0);
    if (!candidates.length)
        return 0;
    // FIX: request -> task -> balance matches print/transfer lock order.
    const picks = await tx.stockMovement.findMany({ where: { clientId: request.clientId, sourceDocument: request.id,
            status: 'PACKING', quantity: { gt: 0 }, idempotencyKey: { startsWith: 'fbs-sticker-pick:' } }, select: { idempotencyKey: true } });
    const taskIds = [...new Set(picks.map(row => row.idempotencyKey.split(':')[1]))].sort();
    for (let offset = 0; offset < taskIds.length; offset += 1000) {
        const ids = taskIds.slice(offset, offset + 1000);
        if (!dryRun)
            await tx.$queryRaw `SELECT id FROM "FbsTsdAssembly" WHERE id IN (${client_1.Prisma.join(ids)}) ORDER BY id FOR UPDATE`;
        if (await tx.fbsTsdAssembly.count({ where: { id: { in: ids }, requestId: { not: request.id } } })) {
            throw new common_1.ConflictException('Отбор перенесён в другую заявку. Требуется сверка истории переноса.');
        }
    }
    const plans = [];
    // FIX: fixed lock order protects shared packing balances across concurrent requests.
    candidates.sort((a, b) => JSON.stringify([a.warehouseId, a.skuId, a.boxId, a.palletId]).localeCompare(JSON.stringify([b.warehouseId, b.skuId, b.boxId, b.palletId])));
    for (const group of candidates) {
        if (!request.warehouseId || group.warehouseId !== request.warehouseId) {
            throw new common_1.ConflictException('Филиал движений не совпадает со сданной заявкой. Требуется сверка.');
        }
        const where = { clientId: request.clientId, warehouseId: group.warehouseId, skuId: group.skuId,
            boxId: group.boxId, palletId: group.palletId, status: 'PACKING' };
        const found = await tx.stockBalance.findMany({ where, select: { id: true } });
        if (found.length !== 1)
            throw new common_1.ConflictException('Не найден однозначный остаток сданной заявки. Требуется сверка.');
        if (!dryRun)
            await tx.$queryRaw `SELECT id FROM "StockBalance" WHERE id=${found[0].id} FOR UPDATE`;
        const balance = await tx.stockBalance.findUniqueOrThrow({ where: { id: found[0].id } });
        const ledger = await tx.stockMovement.findMany({ where, select: { sourceDocument: true, quantity: true, idempotencyKey: true, createdAt: true } });
        const quantity = donePackingQuantity(request.id, balance.quantity, ledger);
        plans.push({ balance, quantity });
    }
    if (dryRun)
        return plans.reduce((sum, plan) => sum + plan.quantity, 0);
    for (const { balance, quantity } of plans) {
        if (!quantity)
            continue;
        const changed = await tx.stockBalance.updateMany({ where: { id: balance.id, quantity: balance.quantity }, data: { quantity: { decrement: quantity } } });
        if (changed.count !== 1)
            throw new common_1.ConflictException('Остаток изменился. Повторите закрытие заявки.');
        await tx.stockMovement.create({ data: { clientId: request.clientId, warehouseId: balance.warehouseId,
                skuId: balance.skuId, boxId: balance.boxId, palletId: balance.palletId, status: 'PACKING', type: 'SHIP', quantity: -quantity,
                sourceDocument: request.id, idempotencyKey: `done-packing:${request.id}:${balance.id}`,
                comment: `Закрытие остатка «В сборке» сданной заявки №${request.number}. Без повторного списания AVAILABLE.`,
            } });
    }
    return plans.reduce((sum, plan) => sum + plan.quantity, 0);
}
