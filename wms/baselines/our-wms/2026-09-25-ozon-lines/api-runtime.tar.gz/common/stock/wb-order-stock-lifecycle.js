"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wbOrderStockLifecycleEnabled = void 0;
exports.calculateWbFreeStock = calculateWbFreeStock;
exports.wbReservationQuantities = wbReservationQuantities;
exports.finalizeWbOrderShipment = finalizeWbOrderShipment;
const client_1 = require("@prisma/client");
const common_1 = require("@nestjs/common");
// FIX: our WMS opts in; installations without the flag retain their current policy.
const wbOrderStockLifecycleEnabled = () => process.env.WMS_WB_ORDER_STOCK_LIFECYCLE_ENABLED === 'true';
exports.wbOrderStockLifecycleEnabled = wbOrderStockLifecycleEnabled;
const pending = new Set(['RESERVED', 'WAITING_STOCK', 'IN_PROGRESS', 'COMPLETED', 'RETURN_REQUIRED']);
// FIX: request demand and its WB orders are the same units, not two reservations.
function calculateWbFreeStock(stock, tasks, requests) {
    const taskQuantityByRequest = new Map();
    let reserved = 0;
    for (const task of tasks) {
        taskQuantityByRequest.set(task.requestId, (taskQuantityByRequest.get(task.requestId) ?? 0) + task.itemCount);
        if (!task.shipped && pending.has(task.status))
            reserved += Math.max(0, task.itemCount - task.pickedQuantity);
    }
    for (const request of requests)
        reserved += Math.max(0, request.quantity - (taskQuantityByRequest.get(request.id) ?? 0));
    return Math.max(0, stock - reserved);
}
async function wbReservationQuantities(db, clientId, skuIds, warehouseId, excludeRequestId) {
    if (!skuIds.length)
        return new Map();
    const fast = process.env.WMS_FBS_ALLOCATION_FAST_ENABLED === 'true';
    const skus = await db.sku.findMany({ where: { clientId, id: { in: skuIds } }, select: { id: true, barcodes: { select: { value: true } } } });
    const skuByBarcode = new Map(skus.flatMap(sku => sku.barcodes.map(barcode => [barcode.value, sku.id])));
    const tasks = await db.fbsTsdAssembly.findMany({ where: { clientId, marketplace: 'WILDBERRIES',
            OR: [{ skuId: { in: skuIds } }, { sourceSkuId: { in: skuIds } }],
            ...(warehouseId ? { stockWarehouseId: warehouseId } : { stockWarehouseId: { not: null } }),
        }, ...(fast ? { select: {
                // FIX: reservation arithmetic needs identity and quantity, not sticker/event payloads.
                id: true, orderId: true, connectionId: true, requestId: true, skuId: true,
                sourceSkuId: true, relabelConfirmedAt: true, itemCount: true, status: true,
            } } : {}) });
    const requests = await db.clientRequest.findMany({ where: { clientId, type: 'OUTBOUND',
            status: { in: ['SUBMITTED', 'IN_REVIEW', 'APPROVED', 'IN_WORK', 'PACKED'] },
            ...(warehouseId ? { warehouseId } : {}),
            ...(excludeRequestId ? { id: { not: excludeRequestId } } : {}),
            items: { some: { OR: [{ skuId: { in: skuIds } }, { skuId: null, barcode: { in: [...skuByBarcode.keys()] } }] } },
        }, select: { id: true, items: { select: { skuId: true, barcode: true, quantity: true } } } });
    // FIX: a client's historical order ids can exceed PostgreSQL's bind-parameter limit.
    const linkBatches = [];
    for (const ids of chunksOf([...new Set(tasks.map(task => task.orderId))], 10000)) {
        linkBatches.push(await db.fbsOrderRequestLink.findMany({ where: { clientId, marketplace: 'WILDBERRIES', orderId: { in: ids } },
            select: { connectionId: true, orderId: true, requestId: true, lastCategory: true, request: { select: { status: true, fbsEmergencyAssemblyAt: true } } } }));
    }
    const links = linkBatches.flat();
    const terminalOrders = new Set(links.filter(link => ['shipped', 'archive', 'cancelled'].includes(link.lastCategory ?? '') && !link.request.fbsEmergencyAssemblyAt).map(link => `${link.connectionId}:${link.orderId}`));
    const requestByOrder = new Map(links.filter(link => !['CANCELLED', 'REJECTED'].includes(link.request.status)).map(link => [`${link.connectionId}:${link.orderId}`, link.requestId]));
    const picked = [];
    // FIX: a supply transfer can change requestId; physical evidence belongs to the exact task.
    if (fast) {
        // FIX: read this client's physical pick history once instead of rescanning it for every 100 tasks.
        if (tasks.length) {
            const taskIds = new Set(tasks.map(task => task.id));
            const rows = await db.stockMovement.findMany({ where: { clientId, status: client_1.StockStatus.PACKING,
                    ...(warehouseId ? { warehouseId } : {}), idempotencyKey: { startsWith: 'fbs-sticker-pick:' },
                }, select: { idempotencyKey: true, quantity: true } });
            for (const row of rows) {
                const parts = row.idempotencyKey?.split(':');
                if (parts && parts.length >= 3 && taskIds.has(parts[1]))
                    picked.push(row);
            }
        }
    }
    else {
        for (let offset = 0; offset < tasks.length; offset += 100) {
            picked.push(...await db.stockMovement.findMany({ where: { clientId, status: client_1.StockStatus.PACKING,
                    ...(warehouseId ? { warehouseId } : {}),
                    OR: tasks.slice(offset, offset + 100).map(task => ({ idempotencyKey: { startsWith: `fbs-sticker-pick:${task.id}:` } })),
                }, select: { idempotencyKey: true, quantity: true } }));
        }
    }
    // FIX: ordinary WMS picks also leave AVAILABLE and must stop reserving it.
    const requestPicks = requests.length ? await db.stockMovement.groupBy({ by: ['sourceDocument', 'skuId'], where: {
            clientId, ...(warehouseId ? { warehouseId } : {}), sourceDocument: { in: requests.map(r => r.id) },
            // FIX: FBO picks use MOVE; net AVAILABLE movement also cancels out storage-only transfers.
            status: 'AVAILABLE', type: { in: ['PICK', 'PACK', 'SHIP', 'RETURN', 'MOVE'] },
            OR: [{ idempotencyKey: null }, { NOT: { idempotencyKey: { startsWith: 'fbs-sticker-pick:' } } }],
        }, _sum: { quantity: true } }) : [];
    const shipmentBatches = [];
    for (const ids of chunksOf(tasks.map(task => task.id), 10000))
        shipmentBatches.push(await db.wbOrderShipment.findMany({
            where: { clientId, assemblyId: { in: ids } }, select: { assemblyId: true },
        }));
    const shipped = new Set(shipmentBatches.flat().map(s => s.assemblyId));
    const pickedByTask = new Map();
    for (const row of picked) {
        const id = row.idempotencyKey?.split(':')[1];
        if (id)
            pickedByTask.set(id, (pickedByTask.get(id) ?? 0) + row.quantity);
    }
    const taskGroups = new Map();
    const relabelDeductions = new Map();
    for (const task of tasks) {
        // FIX: the request link can commit before the automatic task is rebound.
        const requestId = requestByOrder.get(`${task.connectionId}:${task.orderId}`) ?? task.requestId;
        if (requestId === excludeRequestId)
            continue;
        const skuId = task.sourceSkuId && !task.relabelConfirmedAt ? task.sourceSkuId : task.skuId;
        const group = taskGroups.get(skuId) ?? [];
        group.push({ ...task, requestId, pickedQuantity: Math.max(0, pickedByTask.get(task.id) ?? 0), shipped: shipped.has(task.id) || terminalOrders.has(`${task.connectionId}:${task.orderId}`) });
        taskGroups.set(skuId, group);
        if (skuId !== task.skuId) {
            const key = `${requestId}:${task.skuId}`;
            relabelDeductions.set(key, (relabelDeductions.get(key) ?? 0) + task.itemCount);
        }
    }
    const physicalByRequestSku = new Map(requestPicks.map(row => [`${row.sourceDocument}:${row.skuId}`, Math.max(0, -(row._sum.quantity ?? 0))]));
    const requestGroups = new Map();
    for (const request of requests) {
        const quantities = new Map();
        for (const item of request.items) {
            const skuId = item.skuId ?? skuByBarcode.get(item.barcode ?? '');
            if (skuId)
                quantities.set(skuId, (quantities.get(skuId) ?? 0) + item.quantity);
        }
        for (const [skuId, quantity] of quantities) {
            const key = `${request.id}:${skuId}`;
            const group = requestGroups.get(skuId) ?? [];
            group.push({ id: request.id, quantity: Math.max(0, quantity - (physicalByRequestSku.get(key) ?? 0) - (relabelDeductions.get(key) ?? 0)) });
            requestGroups.set(skuId, group);
        }
    }
    return new Map(skuIds.map(skuId => {
        const ceiling = Number.MAX_SAFE_INTEGER;
        return [skuId, ceiling - calculateWbFreeStock(ceiling, taskGroups.get(skuId) ?? [], requestGroups.get(skuId) ?? [])];
    }));
}
// FIX: serialize shipment against retries; the movement, mark and immutable fact commit together.
async function finalizeWbOrderShipment(db, assemblyId, source, snapshot, occurredAt = new Date()) {
    const header = await db.fbsTsdAssembly.findUniqueOrThrow({ where: { id: assemblyId }, select: { requestId: true } });
    // FIX: same lock order as whole-request close: request before task/balances.
    await db.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${header.requestId} FOR UPDATE`;
    await db.$queryRaw `SELECT id FROM "FbsTsdAssembly" WHERE id=${assemblyId} FOR UPDATE`;
    const task = await db.fbsTsdAssembly.findUniqueOrThrow({ where: { id: assemblyId } });
    if (task.marketplace !== 'WILDBERRIES')
        return null;
    // FIX: retries share an assembly; an explicit repeat gets a different assembly and cannot erase this fact.
    const existing = await db.wbOrderShipment.findUnique({ where: { assemblyId: task.id } });
    if (existing)
        return existing;
    const request = await db.clientRequest.findUnique({ where: { id: task.requestId }, include: { client: true, items: true } });
    const warehouseId = task.stockWarehouseId ?? request?.warehouseId;
    if (!warehouseId || !request)
        throw new common_1.ConflictException('Не определена заявка или филиал отгрузки WB. Требуется сверка.');
    const legacy = await db.shippedKizHistory.findFirst({ where: { assemblyId: task.id } });
    const count = Math.max(1, task.itemCount);
    // FIX: an unmarked item may have been shipped by a whole-request operation too.
    const manualShip = request.status === 'DONE' ? await db.stockMovement.aggregate({ where: {
            clientId: task.clientId, warehouseId, sourceDocument: request.id, type: 'SHIP', quantity: { lt: 0 },
        }, _sum: { quantity: true }, _min: { createdAt: true } }) : null;
    const wholeRequestShipped = Boolean(manualShip && request.items.length &&
        -(manualShip._sum.quantity ?? 0) >= request.items.reduce((sum, item) => sum + item.quantity, 0));
    const alreadyShipped = Boolean(legacy) || wholeRequestShipped;
    const shippedAt = legacy?.shippedAt ?? (wholeRequestShipped ? manualShip._min.createdAt : occurredAt);
    if (!alreadyShipped) {
        const movements = await db.stockMovement.findMany({ where: { clientId: task.clientId, warehouseId,
                idempotencyKey: { startsWith: `fbs-sticker-pick:${task.id}:` }, status: 'PACKING',
            } });
        if (movements.reduce((sum, row) => sum + row.quantity, 0) < count) {
            throw new common_1.ConflictException('Отгрузка WB подтверждена, но физическое списание товара не найдено. Требуется сверка источника.');
        }
        let remaining = count;
        const balances = await db.stockBalance.findMany({ where: { clientId: task.clientId, warehouseId,
                skuId: task.skuId, status: { in: ['PACKING', 'SHIPPING'] }, quantity: { gt: 0 },
                OR: [{ boxId: null }, ...(task.boxId ? [{ boxId: task.boxId }] : [])],
            }, orderBy: { updatedAt: 'asc' } });
        for (const balance of balances) {
            const quantity = Math.min(remaining, balance.quantity);
            if (!quantity)
                break;
            const changed = await db.stockBalance.updateMany({ where: { id: balance.id, quantity: { gte: quantity } }, data: { quantity: { decrement: quantity } } });
            if (changed.count !== 1)
                throw new common_1.ConflictException('Остаток упаковки изменился. Повторите подтверждение отгрузки.');
            await db.stockMovement.create({ data: { clientId: task.clientId, warehouseId, skuId: task.skuId,
                    boxId: balance.boxId, palletId: balance.palletId, status: balance.status, type: 'SHIP', quantity: -quantity,
                    sourceDocument: task.requestId, idempotencyKey: `wb-order-shipment:${task.id}:${balance.id}`,
                    comment: `Отгрузка WB ${task.orderId}: ${source}`,
                } });
            remaining -= quantity;
        }
        if (remaining)
            throw new common_1.ConflictException('Недостаточно товара в упаковке для подтверждения отгрузки WB.');
    }
    // FIX: the request summary excludes import files and full request-wide metadata.
    const requestSnapshot = { id: request.id, number: request.number, title: request.title, status: request.status,
        warehouseId: request.warehouseId, fbsEmergencyAssemblyAt: request.fbsEmergencyAssemblyAt,
        fbsEmergencyAssemblyByUserId: request.fbsEmergencyAssemblyByUserId, fbsEmergencyAssemblyByName: request.fbsEmergencyAssemblyByName };
    // FIX: raw marketplace product payloads are not shipment evidence and can consume gigabytes during reconciliation.
    const order = snapshot;
    const product = order.product && typeof order.product === 'object' ? order.product : null;
    const productKeys = ['id', 'name', 'internalSku', 'clientSku', 'article', 'size', 'needsChestnyZnak', 'isUnmarked'];
    const orderSnapshot = JSON.parse(JSON.stringify({ ...order, request: requestSnapshot, storageBoxes: [],
        ...(product ? { product: Object.fromEntries(productKeys.filter(key => key in product).map(key => [key, product[key]])) } : {}),
    }));
    const { storageBoxes: _suggestedBoxes, marketplaceLabelBase64: _labelImage, ...assemblyEvidence } = task;
    const repeat = await db.fbsAssemblyAttemptHistory.findUnique({ where: { successorId: task.id }, select: { id: true } }) ||
        await db.wbOrderShipment.findFirst({ where: { clientId: task.clientId, connectionId: task.connectionId, orderId: task.orderId }, select: { id: true } });
    const fact = await db.wbOrderShipment.create({ data: { clientId: task.clientId, connectionId: task.connectionId,
            orderId: task.orderId, assemblyId: task.id, requestId: task.requestId, warehouseId, skuId: task.skuId,
            quantity: count, kiz: task.kiz, source, shippedAt, orderSnapshot,
            assemblySnapshot: JSON.parse(JSON.stringify({ ...assemblyEvidence, billingAttemptId: repeat ? task.id : null })),
        } });
    if (task.kiz) {
        if (!alreadyShipped)
            await db.productMark.updateMany({ where: { clientId: task.clientId, skuId: task.skuId, value: task.kiz, status: { in: ['PACKING', 'SHIPPING'] } },
                data: { status: 'SHIPPING', boxId: null } });
        const sku = await db.sku.findUniqueOrThrow({ where: { id: task.skuId } });
        await db.shippedKizHistory.createMany({ skipDuplicates: true, data: [{ assemblyId: task.id, clientId: task.clientId,
                    warehouseId, clientName: request.client.name, requestId: request.id, requestNumber: request.number,
                    requestTitle: request.title, orderId: task.orderId, supplyId: task.supplyId, skuId: sku.id,
                    internalSku: sku.internalSku, barcode: task.barcode, article: sku.article, productName: sku.name,
                    color: sku.color, size: sku.size, kiz: task.kiz, sourceBoxCode: task.boxCode, shippedAt,
                }] });
    }
    return fact;
}
function* chunksOf(values, size) {
    for (let offset = 0; offset < values.length; offset += size)
        yield values.slice(offset, offset + size);
}
