"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsTerminalQueueFilterEnabled = fbsTerminalQueueFilterEnabled;
exports.isFbsTerminalQueueOrder = isFbsTerminalQueueOrder;
const fbs_wb_accounting_1 = require("./fbs-wb-accounting");
// FIX: opt-in for our WMS only. Read-side exclusion never reverses physical stock.
function fbsTerminalQueueFilterEnabled() {
    return process.env.WMS_FBS_TERMINAL_QUEUE_FILTER_ENABLED === 'true';
}
const terminalSupplierStatuses = new Set(['cancel', 'cancelled', 'canceled', 'cancel_carrier']);
const terminalWbStatuses = new Set([
    'canceled', 'cancelled', 'canceled_by_client', 'declined_by_client', 'canceled_by_carrier', 'sold', 'defect',
]);
const normalized = (value) => value?.trim().toLowerCase() ?? '';
function isFbsTerminalQueueOrder(snapshot) {
    if (!fbsTerminalQueueFilterEnabled() || snapshot?.marketplace !== 'WILDBERRIES')
        return false;
    if ((0, fbs_wb_accounting_1.isFbsWbAccounted)(snapshot))
        return true;
    // complete/waiting is intentionally NOT terminal: local emergency collection can still be required.
    return normalized(snapshot.lastCategory) === 'cancelled' ||
        terminalSupplierStatuses.has(normalized(snapshot.lastSupplierStatus)) ||
        terminalWbStatuses.has(normalized(snapshot.lastWbStatus));
}
