"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommonModule = void 0;
const common_1 = require("@nestjs/common");
const audit_log_service_1 = require("./audit/audit-log.service");
const archived_empty_box_pallet_detach_service_1 = require("./boxes/archived-empty-box-pallet-detach.service");
const box_code_policy_service_1 = require("./boxes/box-code-policy.service");
const inventory_lock_service_1 = require("./inventory/inventory-lock.service");
const prisma_service_1 = require("./prisma/prisma.service");
const system_settings_service_1 = require("./settings/system-settings.service");
let CommonModule = class CommonModule {
};
exports.CommonModule = CommonModule;
exports.CommonModule = CommonModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        providers: [
            prisma_service_1.PrismaService,
            audit_log_service_1.AuditLogService,
            inventory_lock_service_1.InventoryLockService,
            system_settings_service_1.SystemSettingsService,
            box_code_policy_service_1.BoxCodePolicyService,
            // FIX: one canonical archived-empty rule is available to every stock workflow.
            archived_empty_box_pallet_detach_service_1.ArchivedEmptyBoxPalletDetachService,
        ],
        exports: [
            prisma_service_1.PrismaService,
            audit_log_service_1.AuditLogService,
            inventory_lock_service_1.InventoryLockService,
            system_settings_service_1.SystemSettingsService,
            box_code_policy_service_1.BoxCodePolicyService,
            archived_empty_box_pallet_detach_service_1.ArchivedEmptyBoxPalletDetachService,
        ],
    })
], CommonModule);
