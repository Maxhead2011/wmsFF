"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.manualKizPrefixes = exports.manualKizIdentity = void 0;
exports.manualWriteoffRecovery = manualWriteoffRecovery;
exports.canReuseAfterManualWriteoff = canReuseAfterManualWriteoff;
exports.releaseWrittenOffBindings = releaseWrittenOffBindings;
const common_1 = require("@nestjs/common");
const kiz_physical_identity_1 = require("./kiz-physical-identity");
const manualKizIdentity = (v) => (0, kiz_physical_identity_1.physicalKizIdentity)(v.replace(/^\(01\)(\d{14})\(21\)/, '01$121').replace(/^(01\d{14})\u001d21/, '$121'));
exports.manualKizIdentity = manualKizIdentity;
const manualKizPrefixes = (identity) => [identity, ']d2' + identity, ']D2' + identity, '(01)' + identity.slice(2, 16) + '(21)' + identity.slice(18), identity.slice(0, 16) + '\u001d' + identity.slice(16)];
exports.manualKizPrefixes = manualKizPrefixes;
const obj = (v) => v && typeof v === 'object' && !Array.isArray(v) ? v : {};
// Exact serial, explicit human writeoff and subsequent audited physical recovery are mandatory.
async function manualWriteoffRecovery(db, clientId, kiz) {
    const identity = (0, exports.manualKizIdentity)(kiz);
    if (!identity)
        return null;
    const marks = (await db.productMark.findMany({ where: { clientId, OR: (0, exports.manualKizPrefixes)(identity).map(p => ({ value: { startsWith: p } })) }, include: { box: true } })).filter(m => (0, exports.manualKizIdentity)(m.value) === identity);
    if (marks.length !== 1)
        return null;
    const m = marks[0];
    if (m.status !== 'AVAILABLE' || !m.boxId || !m.stockMovementId || !m.box || m.box.clientId !== clientId || !m.box.warehouseId || ['archived', 'deleted'].includes(m.box.status))
        return null;
    const writeoffs = await db.$queryRaw `SELECT id,"userId","createdAt",payload FROM "AuditLog"
    WHERE action='KIZ_BOX_DISCREPANCY_WRITTEN_OFF' AND "userId" IS NOT NULL
    AND payload->'sku'->>'clientId'=${clientId}
    AND EXISTS (SELECT 1 FROM jsonb_array_elements(CASE WHEN jsonb_typeof(payload->'removedKiz')='array' THEN payload->'removedKiz' ELSE '[]'::jsonb END) item WHERE item->>'value' LIKE ${'%' + identity.slice(18) + '%'})
    ORDER BY "createdAt" DESC LIMIT 20`;
    const writeoff = writeoffs.find(w => obj(w.payload).sku?.id === m.skuId && obj(w.payload).removedKiz?.some((r) => (0, exports.manualKizIdentity)(String(r.value ?? '')) === identity));
    if (!writeoff?.userId)
        return null;
    const recoveries = await db.auditLog.findMany({ where: { userId: { not: null }, createdAt: { gt: writeoff.createdAt },
            action: { in: ['PALLET_SORTING_UNIT_RECOVERED', 'PALLET_SORTING_WRITTEN_OFF_KIZ_RESTORED'] },
            OR: [{ payload: { path: ['markId'], equals: m.id } }, { entity: 'ProductMark', entityId: m.id }] }, orderBy: { createdAt: 'desc' }, take: 20 });
    const recovery = recoveries.find(r => { const p = obj(r.payload); return (0, exports.manualKizIdentity)(String(p.identity ?? '')) === identity && p.movementId === m.stockMovementId && p.targetBoxId === m.boxId && p.quantity === 1; });
    if (!recovery?.userId)
        return null;
    const movement = await db.stockMovement.findUnique({ where: { id: m.stockMovementId } });
    if (!movement || movement.clientId !== clientId || movement.skuId !== m.skuId || movement.boxId !== m.boxId || movement.quantity !== 1 || movement.status !== 'AVAILABLE' || movement.createdAt <= writeoff.createdAt)
        return null;
    const balance = await db.stockBalance.aggregate({ where: { clientId, skuId: m.skuId, boxId: m.boxId, warehouseId: m.box.warehouseId, status: 'AVAILABLE' }, _sum: { quantity: true } });
    if ((balance._sum.quantity ?? 0) < 1)
        return null;
    return { writeoffId: writeoff.id, writtenOffAt: writeoff.createdAt.toISOString(), writtenOffById: writeoff.userId, recoveryId: recovery.id, recoveredAt: recovery.createdAt.toISOString(), recoveredById: recovery.userId, markId: m.id, movementId: m.stockMovementId, boxId: m.boxId, skuId: m.skuId };
}
function canReuseAfterManualWriteoff(decision, proof, orders, history) {
    return decision === 'REVIEW' && !!proof && orders.length > 0 && orders.every(o => o.verified && o.containsKiz === false)
        && history.length > 0 && history.every(h => !!h.at && h.at.getTime() < new Date(proof.writtenOffAt).getTime());
}
// Release only closed historical bindings, preserving full snapshots in immutable audit.
// This does not delete shipment history, change quantities, or alter external WB orders.
async function releaseWrittenOffBindings(tx, task, kiz, proof) {
    const identity = (0, exports.manualKizIdentity)(kiz);
    await tx.$queryRaw `SELECT 1 FROM pg_advisory_xact_lock(hashtextextended(${identity},0))`;
    await tx.$queryRaw `SELECT id FROM "ProductMark" WHERE id=${proof.markId} FOR UPDATE`;
    const fresh = await manualWriteoffRecovery(tx, task.clientId, kiz);
    if (!fresh || JSON.stringify(fresh) !== JSON.stringify(proof) || fresh.boxId !== task.boxId || fresh.skuId !== task.skuId)
        throw new common_1.ConflictException('Подтверждение ручного списания или восстановленная единица изменились. Повторите проверку.');
    const links = (await tx.fbsTsdAssembly.findMany({ where: { id: { not: task.id }, clientId: task.clientId, OR: (0, exports.manualKizPrefixes)(identity).map(p => ({ kiz: { startsWith: p } })) } })).filter(t => (0, exports.manualKizIdentity)(t.kiz ?? '') === identity);
    const requests = await tx.clientRequest.findMany({ where: { clientId: task.clientId, id: { in: links.map(t => t.requestId) }, status: { in: ['DONE', 'CANCELLED', 'REJECTED'] } } });
    if (links.some(t => t.status !== 'COMPLETED' || !t.completedAt || t.completedAt >= new Date(proof.writtenOffAt) || !requests.some(r => r.id === t.requestId)))
        throw new common_1.ConflictException('КИЗ занят незавершённой или более новой сборкой. Ручное списание не разрешает повторное использование.');
    for (const old of links) {
        const shipped = (await tx.shippedKizHistory.findMany({ where: { clientId: task.clientId, orderId: old.orderId, OR: (0, exports.manualKizPrefixes)(identity).map(p => ({ kiz: { startsWith: p } })) } })).some(h => (0, exports.manualKizIdentity)(h.kiz) === identity);
        if (!shipped)
            throw new common_1.ConflictException('Нет независимой архивной истории КИЗа. Требуется проверка администратора.');
        await tx.auditLog.create({ data: { userId: task.workerUserId, action: 'KIZ_MANUAL_WRITEOFF_BINDING_ARCHIVED', entity: 'FbsTsdAssembly', entityId: old.id, payload: JSON.parse(JSON.stringify({ reason: 'MANUAL_WRITEOFF_PHYSICAL_RECOVERY', kizIdentity: identity, successorTaskId: task.id, proof, before: old })) } });
        const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: old.id, kiz: old.kiz, updatedAt: old.updatedAt, status: 'COMPLETED' }, data: { kiz: null } });
        if (changed.count !== 1)
            throw new common_1.ConflictException('Прежняя сборка изменилась. Повторите сканирование.');
    }
}
