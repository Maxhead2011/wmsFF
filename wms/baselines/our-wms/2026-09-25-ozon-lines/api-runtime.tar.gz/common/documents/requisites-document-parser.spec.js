"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const XLSX = __importStar(require("xlsx"));
const pdf_lib_1 = require("pdf-lib");
const vitest_1 = require("vitest");
const requisites_document_parser_1 = require("./requisites-document-parser");
(0, vitest_1.describe)('parseRequisitesDocument', () => {
    (0, vitest_1.it)('extracts Russian company and bank requisites from xlsx', async () => {
        const workbook = XLSX.utils.book_new();
        const sheet = XLSX.utils.aoa_to_sheet([
            ['Полное наименование', 'Общество с ограниченной ответственностью «Логистика Юг»'],
            ['Сокращенное наименование', 'ООО «Логистика Юг»'],
            ['ИНН', '2312345678'],
            ['КПП', '231201001'],
            ['ОГРН', '1232300001234'],
            ['Юридический адрес', '350000, г. Краснодар, ул. Северная, д. 1'],
            ['Наименование банка', 'ПАО СБЕРБАНК'],
            ['БИК', '044525225'],
            ['Расчетный счет', '40702810123450001234'],
            ['Корреспондентский счет', '30101810400000000225'],
            ['Телефон', '+7 (861) 222-33-44'],
            ['Email', 'office@example.ru'],
        ]);
        XLSX.utils.book_append_sheet(workbook, sheet, 'Реквизиты');
        const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
        const result = await (0, requisites_document_parser_1.parseRequisitesDocument)({
            originalname: 'реквизиты.xlsx',
            buffer,
        });
        (0, vitest_1.expect)(result.sourceType).toBe('EXCEL');
        (0, vitest_1.expect)(result.fields).toMatchObject({
            clientKind: 'LEGAL_ENTITY',
            shortName: 'ООО «Логистика Юг»',
            fullName: 'Общество с ограниченной ответственностью «Логистика Юг»',
            inn: '2312345678',
            kpp: '231201001',
            ogrn: '1232300001234',
            bankName: 'ПАО СБЕРБАНК',
            bankBik: '044525225',
            bankAccount: '40702810123450001234',
            correspondentAccount: '30101810400000000225',
            email: 'office@example.ru',
        });
    });
    (0, vitest_1.it)('extracts labeled requisites from a text PDF', async () => {
        const pdfDocument = await pdf_lib_1.PDFDocument.create();
        const page = pdfDocument.addPage([600, 800]);
        const font = await pdfDocument.embedFont(pdf_lib_1.StandardFonts.Helvetica);
        const lines = [
            'Company name: LOGOFF TEST LLC',
            'INN: 7712345678',
            'KPP: 771201001',
            'OGRN: 1237700001234',
            'BIK: 044525225',
            'Bank account: 40702810123450001234',
        ];
        lines.forEach((line, index) => page.drawText(line, { x: 40, y: 740 - index * 24, size: 12, font }));
        const buffer = Buffer.from(await pdfDocument.save({ useObjectStreams: false }));
        const result = await (0, requisites_document_parser_1.parseRequisitesDocument)({
            originalname: 'requisites.pdf',
            buffer,
        });
        (0, vitest_1.expect)(result.sourceType).toBe('PDF');
        (0, vitest_1.expect)(result.fields.inn).toBe('7712345678');
        (0, vitest_1.expect)(result.fields.kpp).toBe('771201001');
        (0, vitest_1.expect)(result.fields.ogrn).toBe('1237700001234');
        (0, vitest_1.expect)(result.fields.bankBik).toBe('044525225');
    });
});
