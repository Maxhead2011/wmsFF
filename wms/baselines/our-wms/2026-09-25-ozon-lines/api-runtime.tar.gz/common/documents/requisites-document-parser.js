"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseRequisitesDocument = parseRequisitesDocument;
exports.extractRequisitesFields = extractRequisitesFields;
const common_1 = require("@nestjs/common");
const pdf_parse_1 = require("pdf-parse");
const XLSX = __importStar(require("xlsx"));
const MAX_FILE_SIZE = 10 * 1024 * 1024;
async function parseRequisitesDocument(file) {
    validateFile(file);
    const extension = file.originalname.toLocaleLowerCase('ru').split('.').pop() ?? '';
    const sourceType = extension === 'pdf' ? 'PDF' : 'EXCEL';
    const document = sourceType === 'PDF' ? await readPdf(file.buffer) : readWorkbook(file.buffer);
    const fields = extractRequisitesFields(document);
    const recognizedFields = Object.entries(fields)
        .filter(([key, value]) => key !== 'clientKind' && Boolean(value))
        .map(([key]) => key);
    const warnings = [];
    if (!fields.inn)
        warnings.push('ИНН не найден — заполните его вручную.');
    if (!fields.fullName)
        warnings.push('Название организации не найдено — заполните его вручную.');
    if (!fields.bankAccount)
        warnings.push('Расчетный счет не найден.');
    if (recognizedFields.length === 0) {
        throw new common_1.BadRequestException(sourceType === 'PDF'
            ? 'В PDF не удалось распознать текст реквизитов. Если это скан, сохраните его как PDF с текстовым слоем или загрузите Excel.'
            : 'В Excel не удалось найти реквизиты. Проверьте, что названия полей и значения находятся на одном листе.');
    }
    return {
        fileName: file.originalname,
        sourceType,
        fields,
        recognizedFields,
        warnings,
    };
}
function extractRequisitesFields(document) {
    const inn = labeledDigits(document, ['инн', 'inn'], [10, 12]);
    const kpp = labeledDigits(document, ['кпп', 'kpp'], [9]);
    const ogrn = labeledDigits(document, ['огрнип', 'огрн', 'ogrnip', 'ogrn'], [13, 15]);
    const bankBik = labeledDigits(document, ['бик банка', 'бик', 'bank bik', 'bik'], [9]);
    const correspondentAccount = labeledDigits(document, ['корреспондентский счет', 'корреспондентский счёт', 'корр. счет', 'корр. счёт', 'корсчет', 'к/с'], [20]);
    const bankAccount = labeledDigits(document, ['расчетный счет', 'расчётный счёт', 'расч. счет', 'расч. счёт', 'р/с', 'bank account', 'settlement account'], [20]);
    const explicitFullName = findValue(document, [
        'полное наименование организации',
        'полное наименование',
        'наименование юридического лица',
        'наименование организации',
        'company name',
    ]);
    const explicitShortName = findValue(document, [
        'сокращенное наименование организации',
        'сокращённое наименование организации',
        'сокращенное наименование',
        'сокращённое наименование',
        'краткое наименование',
    ]);
    const fallbackName = findOrganizationName(document.lines);
    const fullName = cleanCompanyName(explicitFullName || fallbackName || explicitShortName);
    const shortName = cleanCompanyName(explicitShortName || abbreviateCompanyName(fullName));
    const legalAddress = findValue(document, [
        'адрес юридического лица',
        'юридический адрес',
        'юр. адрес',
        'адрес регистрации',
    ]);
    const actualAddress = findValue(document, ['фактический адрес', 'факт. адрес', 'почтовый адрес']);
    const bankName = cleanBankName(findValue(document, ['наименование банка', 'банк получателя', 'банк организации', 'банк']));
    const email = findValue(document, ['электронная почта', 'e-mail', 'email', 'почта']) || findEmail(document.text);
    const phone = findValue(document, ['номер телефона', 'контактный телефон', 'телефон']) || findPhone(document.text);
    const clientKind = inferClientKind(fullName || shortName, inn);
    return {
        clientKind,
        shortName,
        fullName,
        name: shortName || fullName,
        legalName: fullName || shortName,
        inn,
        kpp,
        ogrn,
        legalAddress,
        actualAddress,
        phone,
        email,
        bankName,
        bankBik,
        bankAccount,
        correspondentAccount,
    };
}
async function readPdf(buffer) {
    const parser = new pdf_parse_1.PDFParse({ data: buffer });
    try {
        const result = await parser.getText();
        return documentFromLines((result.text ?? '').split(/\r?\n/));
    }
    catch {
        throw new common_1.BadRequestException('Не удалось прочитать PDF. Проверьте, что файл не защищен паролем и не поврежден.');
    }
    finally {
        await parser.destroy().catch(() => undefined);
    }
}
function readWorkbook(buffer) {
    let workbook;
    try {
        workbook = XLSX.read(buffer, { type: 'buffer', cellText: true, cellDates: false });
    }
    catch {
        throw new common_1.BadRequestException('Не удалось прочитать Excel. Поддерживаются файлы XLS и XLSX.');
    }
    if (!workbook.SheetNames.length) {
        throw new common_1.BadRequestException('В Excel нет листов.');
    }
    const lines = [];
    const entries = [];
    for (const sheetName of workbook.SheetNames) {
        const rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            header: 1,
            raw: false,
            defval: '',
            blankrows: false,
        });
        for (const row of rows) {
            const cells = row.map(cellText).filter(Boolean);
            if (!cells.length)
                continue;
            lines.push(cells.join(' | '));
            for (let index = 0; index < cells.length - 1; index += 1) {
                if (looksLikeLabel(cells[index]) && cells[index + 1]) {
                    entries.push({ label: cells[index], value: cells[index + 1] });
                }
            }
            if (cells.length === 1) {
                const pair = splitLabelValue(cells[0]);
                if (pair)
                    entries.push(pair);
            }
        }
    }
    const base = documentFromLines(lines);
    return { ...base, entries: [...entries, ...base.entries] };
}
function documentFromLines(rawLines) {
    const lines = rawLines.map(normalizeWhitespace).filter(Boolean);
    const entries = lines.flatMap((line) => {
        const pair = splitLabelValue(line);
        return pair ? [pair] : [];
    });
    return { text: lines.join('\n'), lines, entries };
}
function findValue(document, aliases) {
    const normalizedAliases = aliases.map(normalizeLabel).sort((left, right) => right.length - left.length);
    for (const alias of normalizedAliases) {
        for (const entry of document.entries) {
            const label = normalizeLabel(entry.label);
            if ((label === alias || label.startsWith(`${alias} `) || label.endsWith(` ${alias}`)) && entry.value.trim()) {
                return cleanValue(entry.value);
            }
        }
    }
    for (const alias of normalizedAliases) {
        const pattern = new RegExp(`(?:^|\\n)\\s*${wordsPattern(alias)}\\s*(?:[:№-]|\\|)\\s*([^\\n|]{2,250})`, 'iu');
        const match = document.text.match(pattern);
        if (match?.[1])
            return cleanValue(match[1]);
    }
    return '';
}
function labeledDigits(document, aliases, lengths) {
    for (const alias of aliases) {
        const direct = findValue(document, [alias]);
        const found = pickDigits(direct, lengths);
        if (found)
            return found;
    }
    for (const line of document.lines) {
        const normalized = normalizeLabel(line);
        for (const alias of aliases) {
            if (!normalized.includes(normalizeLabel(alias)))
                continue;
            const found = pickDigits(line, lengths);
            if (found)
                return found;
        }
    }
    return '';
}
function pickDigits(value, lengths) {
    const groups = value.match(/[\d][\d\s-]{4,30}[\d]/g) ?? [];
    for (const group of groups) {
        const digits = group.replace(/\D/g, '');
        if (lengths.includes(digits.length))
            return digits;
    }
    return '';
}
function findOrganizationName(lines) {
    const legalForm = /(?:общество\s+с\s+ограниченной\s+ответственностью|индивидуальный\s+предприниматель|публичное\s+акционерное\s+общество|акционерное\s+общество|(?:ооо|ип|пао|ао)\s+[«"“]?[^|\n]{2,100})/iu;
    for (const line of lines) {
        if (/банк|получател|директор|подпис/i.test(line))
            continue;
        const match = line.match(legalForm);
        if (match)
            return match[0];
    }
    return '';
}
function abbreviateCompanyName(value) {
    return value
        .replace(/^Общество с ограниченной ответственностью\s*/iu, 'ООО ')
        .replace(/^Индивидуальный предприниматель\s*/iu, 'ИП ')
        .replace(/^Публичное акционерное общество\s*/iu, 'ПАО ')
        .replace(/^Акционерное общество\s*/iu, 'АО ')
        .trim();
}
function inferClientKind(name, inn) {
    if (/индивидуальный предприниматель|^ип\b/iu.test(name))
        return 'INDIVIDUAL_ENTREPRENEUR';
    if (/самозанят/iu.test(name))
        return 'SELF_EMPLOYED';
    if (inn.length === 12)
        return 'INDIVIDUAL_ENTREPRENEUR';
    return 'LEGAL_ENTITY';
}
function findEmail(text) {
    return text.match(/[\w.+-]+@[\w.-]+\.[A-Za-zА-Яа-я]{2,}/u)?.[0] ?? '';
}
function findPhone(text) {
    const match = text.match(/(?:\+7|8)[\s(-]*\d{3}[\s)-]*\d{3}[\s-]*\d{2}[\s-]*\d{2}/u)?.[0] ?? '';
    return normalizeWhitespace(match);
}
function splitLabelValue(value) {
    const colon = value.match(/^\s*([^:|]{2,80})\s*(?::|\|)\s*(.+?)\s*$/u);
    if (colon && looksLikeLabel(colon[1]))
        return { label: colon[1], value: colon[2] };
    const spaced = value.match(/^\s*(.{2,80}?)\s{2,}(.+?)\s*$/u);
    if (spaced && looksLikeLabel(spaced[1]))
        return { label: spaced[1], value: spaced[2] };
    return null;
}
function looksLikeLabel(value) {
    return /[A-Za-zА-Яа-яЁё]/u.test(value) && value.length <= 100;
}
function cellText(value) {
    if (value === null || value === undefined)
        return '';
    return normalizeWhitespace(String(value));
}
function cleanCompanyName(value) {
    return cleanValue(value).replace(/^(?:полное|сокращенное|сокращённое)\s+наименование\s*/iu, '');
}
function cleanBankName(value) {
    const clean = cleanValue(value);
    return /^\d{9,}$/u.test(clean.replace(/\D/g, '')) ? '' : clean;
}
function cleanValue(value) {
    return normalizeWhitespace(value).replace(/^[-–—:]+\s*/u, '').replace(/[;,.]\s*$/u, '').trim();
}
function normalizeWhitespace(value) {
    return value.replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').trim();
}
function normalizeLabel(value) {
    return normalizeWhitespace(value)
        .toLocaleLowerCase('ru')
        .replace(/ё/g, 'е')
        .replace(/["'«»“”()№:;,.]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}
function wordsPattern(value) {
    return value.split(' ').map(escapeRegExp).join('\\s+');
}
function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function validateFile(file) {
    if (!file?.buffer?.length)
        throw new common_1.BadRequestException('Выберите PDF, XLS или XLSX с реквизитами.');
    if (file.buffer.length > MAX_FILE_SIZE)
        throw new common_1.BadRequestException('Файл реквизитов превышает 10 МБ.');
    const extension = file.originalname.toLocaleLowerCase('ru').split('.').pop() ?? '';
    if (!['pdf', 'xls', 'xlsx'].includes(extension)) {
        throw new common_1.BadRequestException('Поддерживаются только PDF, XLS и XLSX.');
    }
    if (extension === 'pdf' && file.buffer.subarray(0, 4).toString('ascii') !== '%PDF') {
        throw new common_1.BadRequestException('Выбранный файл не является корректным PDF.');
    }
}
