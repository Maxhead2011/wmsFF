"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.receiptDateFromBoxCode = receiptDateFromBoxCode;
exports.receiptBoxCodePrefixForDate = receiptBoxCodePrefixForDate;
const DEFAULT_RECEIPT_BOX_PREFIX = 'FFL_LKB';
function receiptDateFromBoxCode(boxCode, fallback, receiptPrefix = DEFAULT_RECEIPT_BOX_PREFIX) {
    const escapedPrefix = receiptPrefix
        .trim()
        .toLocaleUpperCase('ru-RU')
        .replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = boxCode
        .toLocaleUpperCase('ru-RU')
        .match(new RegExp(`^${escapedPrefix}(\\d{2})(\\d{2})(\\d{2})?(?:_|$)`));
    if (!match)
        return moscowDateKey(fallback);
    const fallbackYear = Number(moscowDateKey(fallback).slice(0, 4));
    const year = match[3] ? 2000 + Number(match[3]) : fallbackYear;
    const month = Number(match[2]);
    const day = Number(match[1]);
    const candidate = new Date(Date.UTC(year, month - 1, day));
    return candidate.getUTCFullYear() === year && candidate.getUTCMonth() === month - 1 && candidate.getUTCDate() === day
        ? candidate.toISOString().slice(0, 10)
        : moscowDateKey(fallback);
}
function receiptBoxCodePrefixForDate(value, receiptPrefix = DEFAULT_RECEIPT_BOX_PREFIX) {
    const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match)
        return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const candidate = new Date(Date.UTC(year, month - 1, day));
    if (candidate.getUTCFullYear() !== year ||
        candidate.getUTCMonth() !== month - 1 ||
        candidate.getUTCDate() !== day) {
        return null;
    }
    return `${receiptPrefix.trim().toLocaleUpperCase('ru-RU')}${match[3]}${match[2]}`;
}
function moscowDateKey(value) {
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Europe/Moscow',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
    }).format(value);
}
