"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configurePdfMake = configurePdfMake;
const pdfMake = require("pdfmake");
const node_path_1 = require("node:path");
let isPdfMakeConfigured = false;
function configurePdfMake() {
    if (isPdfMakeConfigured) {
        return;
    }
    const fontRoot = (0, node_path_1.join)((0, node_path_1.dirname)(require.resolve('dejavu-fonts-ttf/package.json')), 'ttf');
    // Русский комментарий: DejaVu Sans TTF содержит кириллицу и одинаково работает локально и на VPS.
    pdfMake.setFonts({
        DejaVuSans: {
            normal: (0, node_path_1.join)(fontRoot, 'DejaVuSans.ttf'),
            bold: (0, node_path_1.join)(fontRoot, 'DejaVuSans-Bold.ttf'),
            italics: (0, node_path_1.join)(fontRoot, 'DejaVuSans-Oblique.ttf'),
            bolditalics: (0, node_path_1.join)(fontRoot, 'DejaVuSans-BoldOblique.ttf'),
        },
    });
    pdfMake.setUrlAccessPolicy(() => false);
    pdfMake.setLocalAccessPolicy((filePath) => filePath.startsWith(fontRoot));
    isPdfMakeConfigured = true;
}
