"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelledWithoutSale = exports.cancelledKizReviewEnabled = void 0;
exports.releaseCancelledBindings = releaseCancelledBindings;
const common_1 = require("@nestjs/common");
const kiz_manual_writeoff_1 = require("./kiz-manual-writeoff");
// FIX: opt-in for our WMS. Unknown circulation permits human review, never automatic reuse.
const cancelledKizReviewEnabled = () => process.env.WMS_KIZ_CANCELLED_ADMIN_REUSE_ENABLED === 'true';
exports.cancelledKizReviewEnabled = cancelledKizReviewEnabled;
const cancelledWithoutSale = (status) => ['canceled', 'canceled_by_client', 'declined_by_client'].includes(status ?? '');
exports.cancelledWithoutSale = cancelledWithoutSale;
// FIX: preserve shipment records and the complete historical task before releasing its unique live slot.
// The caller must first check admin rights, current unit/box/balance and confirmation of physical presence.
async function releaseCancelledBindings(tx, clientId, kiz, evidence, userId, reviewId, excludedTaskId = '') {
    const conflict = () => new common_1.ConflictException('КИЗ занят другой сборкой или отмена прежнего заказа не подтверждена. Обновите проверку.');
    const age = Date.now() - Date.parse(evidence.checkedAt);
    if (!(0, exports.cancelledKizReviewEnabled)() || evidence.decision !== 'REVIEW' ||
        ['RETIRED', 'WRITTEN_OFF'].includes(evidence.circulation ?? '') || !Number.isFinite(age) || age < 0 || age > 60000 ||
        !evidence.orders.length || !evidence.orders.every(o => o.verified && o.supplierStatus === 'cancel' && (0, exports.cancelledWithoutSale)(o.wbStatus)))
        throw conflict();
    const identity = (0, kiz_manual_writeoff_1.manualKizIdentity)(kiz);
    if (!identity)
        throw conflict();
    await tx.$queryRaw `SELECT 1 FROM pg_advisory_xact_lock(hashtextextended(${identity},0))`;
    const links = (await tx.fbsTsdAssembly.findMany({ where: { clientId, id: { not: excludedTaskId },
            OR: (0, kiz_manual_writeoff_1.manualKizPrefixes)(identity).map(p => ({ kiz: { startsWith: p } })) } })).filter(t => (0, kiz_manual_writeoff_1.manualKizIdentity)(t.kiz ?? '') === identity);
    const requests = await tx.clientRequest.findMany({ where: { clientId, id: { in: links.map(t => t.requestId) }, status: { in: ['DONE', 'CANCELLED', 'REJECTED'] } } });
    if (links.some(t => t.status !== 'COMPLETED' || !t.completedAt || !requests.some(r => r.id === t.requestId) ||
        !evidence.orders.some(o => o.orderId === t.orderId)))
        throw conflict();
    for (const old of links) {
        const history = await tx.shippedKizHistory.findMany({ where: { clientId, orderId: old.orderId, requestId: old.requestId,
                OR: (0, kiz_manual_writeoff_1.manualKizPrefixes)(identity).map(p => ({ kiz: { startsWith: p } })) } });
        if (!history.some(h => (0, kiz_manual_writeoff_1.manualKizIdentity)(h.kiz) === identity))
            throw conflict();
        await tx.auditLog.create({ data: { userId, action: 'KIZ_CANCELLED_BINDING_ARCHIVED', entity: 'FbsTsdAssembly', entityId: old.id,
                payload: JSON.parse(JSON.stringify({ reviewId, kizIdentity: identity, evidence, before: old })) } });
        const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: old.id, clientId, status: 'COMPLETED', kiz: old.kiz, updatedAt: old.updatedAt }, data: { kiz: null } });
        if (changed.count !== 1)
            throw conflict();
    }
}
