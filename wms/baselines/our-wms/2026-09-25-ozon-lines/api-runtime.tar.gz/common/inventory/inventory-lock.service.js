"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryLockService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
let InventoryLockService = class InventoryLockService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async activeFullInventory() {
        return this.prisma.inventorySession.findFirst({
            where: {
                type: client_1.InventorySessionType.FULL,
                status: { in: [client_1.InventorySessionStatus.ACTIVE, client_1.InventorySessionStatus.REVIEW] },
            },
            orderBy: { startedAt: 'desc' },
            select: { id: true, title: true, status: true, startedAt: true, createdByName: true },
        });
    }
    async assertStockMovementsAllowed() {
        const active = await this.activeFullInventory();
        if (!active) {
            return;
        }
        throw new common_1.ConflictException({
            code: 'FULL_INVENTORY_LOCK',
            message: `Движения товара временно заблокированы: выполняется полная инвентаризация «${active.title}».`,
            inventory: active,
        });
    }
};
exports.InventoryLockService = InventoryLockService;
exports.InventoryLockService = InventoryLockService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], InventoryLockService);
