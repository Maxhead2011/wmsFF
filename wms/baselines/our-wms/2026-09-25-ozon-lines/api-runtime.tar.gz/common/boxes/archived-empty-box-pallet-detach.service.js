"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArchivedEmptyBoxPalletDetachService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const box_code_policy_service_1 = require("./box-code-policy.service");
const DETACH_AUDIT_MESSAGE = 'Пустой архивный короб автоматически удалён с паллетсорта';
let ArchivedEmptyBoxPalletDetachService = class ArchivedEmptyBoxPalletDetachService {
    prisma;
    boxCodes;
    constructor(prisma, boxCodes) {
        this.prisma = prisma;
        this.boxCodes = boxCodes;
    }
    async previewIfArchivedAndEmpty(input, db) {
        // FIX: reconciliation can perform the exact canonical check without mutating the placement.
        if (db)
            return this.evaluateInDatabase(input, db);
        return this.prisma.$transaction((tx) => this.evaluateInDatabase(input, tx), { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
    }
    async detachIfArchivedAndEmpty(input, db) {
        // FIX: callers already inside a stock transaction reuse it; standalone callers get one atomic transaction.
        if (db)
            return this.detachInTransaction(input, db);
        return this.prisma.$transaction((tx) => this.detachInTransaction(input, tx), { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable });
    }
    async detachInTransaction(input, db) {
        const candidate = await this.evaluateInDatabase(input, db);
        if (!candidate.eligible || !candidate.placementId) {
            return { detached: false, boxId: candidate.boxId, quantity: candidate.quantity };
        }
        const removed = await db.storagePalletBox.deleteMany({
            // FIX: re-check both predicates in the DELETE statement to close the check/delete race.
            where: {
                id: candidate.placementId,
                boxId: candidate.boxId,
                box: {
                    status: 'archived',
                    balances: { none: { quantity: { gt: 0 } } },
                },
            },
        });
        if (removed.count === 0) {
            return { detached: false, boxId: candidate.boxId, quantity: candidate.quantity };
        }
        // FIX: audit is written only for the transaction that actually removed the active relation.
        await db.auditLog.create({
            data: {
                userId: input.userId,
                action: 'EMPTY_ARCHIVED_BOX_AUTO_DETACHED',
                entity: 'Box',
                entityId: candidate.boxId,
                payload: {
                    message: DETACH_AUDIT_MESSAGE,
                    boxCode: candidate.boxCode,
                    clientId: candidate.clientId,
                    warehouseId: candidate.warehouseId,
                    palletId: candidate.palletId,
                    reason: input.reason ?? null,
                },
            },
        });
        return {
            detached: true,
            boxId: candidate.boxId,
            palletId: candidate.palletId,
            quantity: candidate.quantity,
        };
    }
    async evaluateInDatabase(input, db) {
        const box = await db.box.findUnique({
            where: { id: input.boxId },
            select: {
                id: true,
                code: true,
                clientId: true,
                warehouseId: true,
                status: true,
                storagePlacement: {
                    select: { id: true, palletId: true, boxCode: true },
                },
            },
        });
        if (!box || box.status !== 'archived') {
            return { eligible: false, boxId: input.boxId, quantity: null };
        }
        // FIX: old archived status is not authority to detach permanent storage in reconciliation.
        if (await (0, box_code_policy_service_1.preserveEmptyStorageBox)(box.code, this.boxCodes)) {
            return { eligible: false, boxId: box.id, quantity: null };
        }
        // FIX: NULL is zero only when the aggregate confirms that no balance rows exist.
        const balance = await db.stockBalance.aggregate({
            // FIX: canonical factual stock is the sum of positive balance rows across statuses.
            where: { boxId: box.id, quantity: { gt: 0 } },
            _count: { _all: true },
            _sum: { quantity: true },
        });
        const rowCount = balance._count._all;
        if (rowCount > 0 && balance._sum.quantity == null) {
            throw new Error(`Не удалось определить фактический остаток короба ${box.code}.`);
        }
        const quantity = rowCount === 0 ? 0 : balance._sum.quantity;
        if (quantity !== 0 || !box.storagePlacement) {
            return { eligible: false, boxId: box.id, quantity };
        }
        return {
            eligible: true,
            boxId: box.id,
            boxCode: box.code,
            clientId: box.clientId,
            warehouseId: box.warehouseId,
            palletId: box.storagePlacement.palletId,
            placementId: box.storagePlacement.id,
            quantity,
        };
    }
};
exports.ArchivedEmptyBoxPalletDetachService = ArchivedEmptyBoxPalletDetachService;
exports.ArchivedEmptyBoxPalletDetachService = ArchivedEmptyBoxPalletDetachService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, box_code_policy_service_1.BoxCodePolicyService])
], ArchivedEmptyBoxPalletDetachService);
