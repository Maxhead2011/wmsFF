"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BoxCodePolicyService = exports.DEFAULT_BOX_CODE_POLICY = exports.permanentStorageBoxesEnabled = exports.BOX_CODE_POLICY_SETTING = void 0;
exports.preserveEmptyStorageBox = preserveEmptyStorageBox;
exports.normalizeBoxCodePolicy = normalizeBoxCodePolicy;
const common_1 = require("@nestjs/common");
const system_settings_service_1 = require("../settings/system-settings.service");
exports.BOX_CODE_POLICY_SETTING = 'warehouse.boxCodePolicy';
// FIX: opt-in for WMSFF2207; sold installations retain their existing lifecycle.
const permanentStorageBoxesEnabled = () => process.env.WMS_PERMANENT_STORAGE_BOXES_ENABLED === 'true';
exports.permanentStorageBoxesEnabled = permanentStorageBoxesEnabled;
async function preserveEmptyStorageBox(code, boxCodes) {
    if (!(0, exports.permanentStorageBoxesEnabled)())
        return false;
    // FIX: a missing policy must fail closed, not archive an unidentified permanent location.
    if (!boxCodes)
        throw new Error('Политика постоянных боксов недоступна. Операция отменена.');
    const policy = await boxCodes.getPolicy();
    const normalized = await boxCodes.normalize(code);
    return [policy.storageBoxPrefix, ...policy.storageBoxAliases].some(prefix => normalized.startsWith(prefix) && normalized.length > prefix.length);
}
exports.DEFAULT_BOX_CODE_POLICY = {
    primaryPrefix: 'FFL_',
    allowedPrefixes: ['FFL_'],
    receiptPrefix: 'FFL_LKB',
    balancePrefix: 'FFL_BAL',
    whiteReceiptPrefixes: ['FFL_LKB'],
    grayReceiptPrefixes: ['FFL_G_'],
    palletPrefix: 'PAL_',
    storageCellPrefix: 'CELL_',
    rackSlotPrefix: 'SLOT_',
    rackPrefix: 'RACK_',
    storageBoxPrefix: 'SBOX_',
    storageBoxAliases: [],
    autoCorrections: {
        FL_: 'FFL_',
    },
};
let BoxCodePolicyService = class BoxCodePolicyService {
    settings;
    cached = null;
    constructor(settings) {
        this.settings = settings;
    }
    async getPolicy(force = false) {
        if (!force && this.cached && this.cached.expiresAt > Date.now()) {
            return this.cached.value;
        }
        const stored = await this.settings.get(exports.BOX_CODE_POLICY_SETTING, exports.DEFAULT_BOX_CODE_POLICY);
        const value = normalizeBoxCodePolicy(stored);
        this.cached = { expiresAt: Date.now() + 15_000, value };
        return value;
    }
    async normalize(value) {
        const policy = await this.getPolicy();
        let normalized = value.trim().toLocaleUpperCase('ru-RU');
        for (const [from, to] of Object.entries(policy.autoCorrections)) {
            if (normalized.startsWith(from)) {
                normalized = `${to}${normalized.slice(from.length)}`;
                break;
            }
        }
        return normalized;
    }
    async requireAllowed(value) {
        const policy = await this.getPolicy();
        const normalized = await this.normalize(value);
        if (!normalized || !policy.allowedPrefixes.some((prefix) => normalized.startsWith(prefix))) {
            throw new common_1.BadRequestException(`Номер короба должен начинаться с одного из разрешённых префиксов: ${policy.allowedPrefixes.join(', ')}.`);
        }
        return normalized;
    }
    async updatePolicy(value, userId) {
        // FIX: older settings screens omit aliases; preserve them unless explicitly replaced.
        const input = asRecord(value);
        const policy = normalizeBoxCodePolicy({
            ...input,
            storageBoxAliases: input.storageBoxAliases === undefined
                ? (await this.getPolicy(true)).storageBoxAliases
                : input.storageBoxAliases,
        });
        await this.settings.set(exports.BOX_CODE_POLICY_SETTING, policy, userId);
        this.cached = null;
        return policy;
    }
    // FIX: storage boxes have their own configured prefix; ordinary box rules stay unchanged.
    async requireStorageBox(value) {
        const { storageBoxPrefix, storageBoxAliases } = await this.getPolicy();
        // FIX: keep the primary generation prefix and accept only explicitly configured aliases.
        const prefixes = [storageBoxPrefix, ...storageBoxAliases];
        const normalized = await this.normalize(value);
        if (!prefixes.some(prefix => normalized.startsWith(prefix) && normalized.length > prefix.length)) {
            throw new common_1.BadRequestException(`Отсканируйте бокс хранения с префиксом ${prefixes.join(', ')} и номером.`);
        }
        return normalized;
    }
};
exports.BoxCodePolicyService = BoxCodePolicyService;
exports.BoxCodePolicyService = BoxCodePolicyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [system_settings_service_1.SystemSettingsService])
], BoxCodePolicyService);
function normalizeBoxCodePolicy(value) {
    const input = asRecord(value);
    const primaryPrefix = normalizePrefix(input.primaryPrefix, exports.DEFAULT_BOX_CODE_POLICY.primaryPrefix);
    const allowedPrefixes = uniquePrefixes(input.allowedPrefixes, primaryPrefix);
    const receiptPrefix = normalizePrefix(input.receiptPrefix, exports.DEFAULT_BOX_CODE_POLICY.receiptPrefix);
    const balancePrefix = normalizePrefix(input.balancePrefix, exports.DEFAULT_BOX_CODE_POLICY.balancePrefix);
    const whiteReceiptPrefixes = uniquePrefixes(input.whiteReceiptPrefixes, exports.DEFAULT_BOX_CODE_POLICY.whiteReceiptPrefixes[0]);
    const grayReceiptPrefixes = uniquePrefixes(input.grayReceiptPrefixes, exports.DEFAULT_BOX_CODE_POLICY.grayReceiptPrefixes[0]);
    const palletPrefix = normalizePrefix(input.palletPrefix, exports.DEFAULT_BOX_CODE_POLICY.palletPrefix);
    const storageCellPrefix = normalizePrefix(input.storageCellPrefix, exports.DEFAULT_BOX_CODE_POLICY.storageCellPrefix);
    const rackSlotPrefix = normalizePrefix(input.rackSlotPrefix, exports.DEFAULT_BOX_CODE_POLICY.rackSlotPrefix);
    const rackPrefix = normalizePrefix(input.rackPrefix, exports.DEFAULT_BOX_CODE_POLICY.rackPrefix);
    const storageBoxPrefix = normalizePrefix(input.storageBoxPrefix, exports.DEFAULT_BOX_CODE_POLICY.storageBoxPrefix);
    // FIX: no aliases by default, so other installations keep their previous behavior.
    const storageBoxAliases = Array.isArray(input.storageBoxAliases) && input.storageBoxAliases.length
        ? uniquePrefixes(input.storageBoxAliases, storageBoxPrefix)
        : [];
    const autoCorrections = normalizeCorrections(input.autoCorrections);
    if (!allowedPrefixes.some((prefix) => primaryPrefix.startsWith(prefix) || prefix.startsWith(primaryPrefix))) {
        allowedPrefixes.unshift(primaryPrefix);
    }
    return {
        primaryPrefix,
        allowedPrefixes,
        receiptPrefix,
        balancePrefix,
        whiteReceiptPrefixes,
        grayReceiptPrefixes,
        palletPrefix,
        storageCellPrefix,
        rackSlotPrefix,
        rackPrefix,
        storageBoxPrefix,
        storageBoxAliases,
        autoCorrections,
    };
}
function normalizePrefix(value, fallback) {
    const normalized = typeof value === 'string' ? value.trim().toLocaleUpperCase('ru-RU') : fallback;
    if (!/^[A-ZА-ЯЁ0-9][A-ZА-ЯЁ0-9_-]{0,31}$/.test(normalized)) {
        throw new common_1.BadRequestException('Префикс может содержать буквы, цифры, дефис и подчёркивание; длина — от 1 до 32 символов.');
    }
    return normalized;
}
function uniquePrefixes(value, fallback) {
    const items = Array.isArray(value) ? value : [fallback];
    const result = [
        ...new Set(items
            .filter((item) => typeof item === 'string')
            .map((item) => normalizePrefix(item, fallback))),
    ];
    if (result.length === 0)
        result.push(fallback);
    if (result.length > 20) {
        throw new common_1.BadRequestException('Можно указать не более 20 разрешённых префиксов.');
    }
    return result;
}
function normalizeCorrections(value) {
    const result = {};
    const source = asRecord(value);
    for (const [from, to] of Object.entries(source)) {
        if (Object.keys(result).length >= 20)
            break;
        if (typeof to !== 'string')
            continue;
        result[normalizePrefix(from, from)] = normalizePrefix(to, to);
    }
    return result;
}
function asRecord(value) {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? value
        : {};
}
