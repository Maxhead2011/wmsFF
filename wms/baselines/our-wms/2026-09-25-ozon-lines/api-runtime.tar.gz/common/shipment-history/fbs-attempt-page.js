"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsAttemptPageWindow = fbsAttemptPageWindow;
exports.mergeFbsAttemptPage = mergeFbsAttemptPage;
// FIX: fetch only a history-sized overlap, not every preceding live page.
function fbsAttemptPageWindow(page, pageSize, historyCount) {
    const target = (page - 1) * pageSize;
    const skip = Math.max(0, target - historyCount);
    return { skip, take: pageSize + historyCount, offset: target - skip };
}
function mergeFbsAttemptPage(current, history, offset, size) {
    return [...current, ...history].sort((a, b) => (b.completedAt?.getTime() ?? 0) - (a.completedAt?.getTime() ?? 0) ||
        b.updatedAt.getTime() - a.updatedAt.getTime() ||
        (a.id < b.id ? 1 : a.id > b.id ? -1 : 0)).slice(offset, offset + size);
}
