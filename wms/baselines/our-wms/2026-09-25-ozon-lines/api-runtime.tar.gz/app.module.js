"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const admin_notifications_module_1 = require("./modules/admin-notifications/admin-notifications.module");
const common_1 = require("@nestjs/common");
const kiz_search_module_1 = require("./modules/kiz-search/kiz-search.module");
const operations_statistics_module_1 = require("./modules/operations-statistics/operations-statistics.module");
const config_1 = require("@nestjs/config");
const core_1 = require("@nestjs/core");
const analytics_module_1 = require("./modules/analytics/analytics.module");
const administration_module_1 = require("./modules/administration/administration.module");
const common_module_1 = require("./common/common.module");
const auth_module_1 = require("./modules/auth/auth.module");
const billing_module_1 = require("./modules/billing/billing.module");
const branches_module_1 = require("./modules/branches/branches.module");
const client_notifications_module_1 = require("./modules/client-notifications/client-notifications.module");
const client_requests_module_1 = require("./modules/client-requests/client-requests.module");
const contracts_module_1 = require("./modules/contracts/contracts.module");
const expenses_module_1 = require("./modules/expenses/expenses.module");
const factory_shipments_module_1 = require("./modules/factory-shipments/factory-shipments.module");
const auth_guard_1 = require("./modules/auth/guards/auth.guard");
const permissions_guard_1 = require("./modules/auth/guards/permissions.guard");
const health_controller_1 = require("./modules/health/health.controller");
const clients_module_1 = require("./modules/clients/clients.module");
const imports_module_1 = require("./modules/imports/imports.module");
const inventory_module_1 = require("./modules/inventory/inventory.module");
const integration_api_module_1 = require("./modules/integration-api/integration-api.module");
const kiz_issues_module_1 = require("./modules/kiz-issues/kiz-issues.module");
const kiz_circulation_module_1 = require("./modules/kiz-circulation/kiz-circulation.module");
const logistics_module_1 = require("./modules/logistics/logistics.module");
const marketplace_connections_module_1 = require("./modules/marketplace-connections/marketplace-connections.module");
const mobile_module_1 = require("./modules/mobile/mobile.module");
const mobile_idempotency_interceptor_1 = require("./modules/mobile/mobile-idempotency.interceptor");
const own_companies_module_1 = require("./modules/own-companies/own-companies.module");
const ozon_fbo_module_1 = require("./modules/ozon-fbo/ozon-fbo.module");
const print_module_1 = require("./modules/print/print.module");
const service_center_module_1 = require("./modules/service/service-center.module");
const skus_module_1 = require("./modules/skus/skus.module");
const stock_module_1 = require("./modules/stock/stock.module");
const tsd_module_1 = require("./modules/tsd/tsd.module");
const turnover_module_1 = require("./modules/turnover/turnover.module");
const users_module_1 = require("./modules/users/users.module");
const warehouse_module_1 = require("./modules/warehouse/warehouse.module");
const wms_ai_module_1 = require("./modules/wms-ai/wms-ai.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true }),
            common_module_1.CommonModule,
            kiz_search_module_1.KizSearchModule,
            admin_notifications_module_1.AdminNotificationsModule,
            administration_module_1.AdministrationModule,
            analytics_module_1.AnalyticsModule,
            auth_module_1.AuthModule,
            billing_module_1.BillingModule,
            branches_module_1.BranchesModule,
            client_notifications_module_1.ClientNotificationsModule,
            client_requests_module_1.ClientRequestsModule,
            contracts_module_1.ContractsModule,
            expenses_module_1.ExpensesModule,
            factory_shipments_module_1.FactoryShipmentsModule,
            users_module_1.UsersModule,
            clients_module_1.ClientsModule,
            skus_module_1.SkusModule,
            warehouse_module_1.WarehouseModule,
            wms_ai_module_1.WmsAiModule,
            stock_module_1.StockModule,
            logistics_module_1.LogisticsModule,
            marketplace_connections_module_1.MarketplaceConnectionsModule,
            mobile_module_1.MobileModule,
            own_companies_module_1.OwnCompaniesModule,
            ozon_fbo_module_1.OzonFboModule,
            imports_module_1.ImportsModule,
            inventory_module_1.InventoryModule,
            // ADDED: isolated external API; it does not change existing user or TSD routes.
            integration_api_module_1.IntegrationApiModule,
            kiz_circulation_module_1.KizCirculationModule,
            kiz_issues_module_1.KizIssuesModule,
            print_module_1.PrintModule,
            service_center_module_1.ServiceCenterModule,
            tsd_module_1.TsdModule,
            turnover_module_1.TurnoverModule,
            operations_statistics_module_1.OperationsStatisticsModule,
        ],
        controllers: [health_controller_1.HealthController],
        providers: [
            {
                provide: core_1.APP_GUARD,
                useClass: auth_guard_1.AuthGuard,
            },
            {
                provide: core_1.APP_GUARD,
                useClass: permissions_guard_1.PermissionsGuard,
            },
            {
                provide: core_1.APP_INTERCEPTOR,
                useClass: mobile_idempotency_interceptor_1.MobileIdempotencyInterceptor,
            },
        ],
    })
], AppModule);
