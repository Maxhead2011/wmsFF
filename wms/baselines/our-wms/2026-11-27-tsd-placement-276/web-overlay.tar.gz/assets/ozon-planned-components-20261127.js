// <define:import.meta.env>
var define_import_meta_env_default = {};

// host:react
import { r as R } from "/assets/admin-tiles-20261019-0.js";
var react_default = R;
var { useState, useEffect, useRef, useMemo, useCallback, createElement, Fragment } = R;

// work/fulfillment-analytics/wms/apps/web/src/lib/shared-read.ts
function createSharedRead() {
  const pending = /* @__PURE__ */ new Map();
  return function sharedRead2(key, read) {
    const current = pending.get(key);
    if (current) return current;
    const promise = Promise.resolve().then(read);
    pending.set(key, promise);
    const clear = () => {
      if (pending.get(key) === promise) pending.delete(key);
    };
    void promise.then(clear, clear);
    return promise;
  };
}
var sharedRead = createSharedRead();

// work/fulfillment-analytics/wms/apps/web/src/lib/api.ts
var API_BASE_URL = define_import_meta_env_default.VITE_API_URL ?? "/api/v1";
async function fetchFboHistory(accessToken, id, offset) {
  return request(`/tsd/requests/${id}/fbo?view=history&offset=${offset}`, { accessToken });
}
function fetchLamodaRelabelStations(accessToken, id) {
  return request(`/tsd/requests/${id}/fbo/lamoda-relabel/stations`, { accessToken });
}
function printLamodaRelabel(accessToken, id, body) {
  return request(`/tsd/requests/${id}/fbo/lamoda-relabel/print`, { accessToken, method: "POST", body });
}
function resolvePlannedPacking(accessToken, id, body) {
  return request(`/tsd/requests/${id}/fbo/packing-plan/resolve`, { accessToken, method: "POST", body });
}
async function fetchFboPlan(accessToken, id) {
  const load = () => request(`/tsd/requests/${id}/fbo${define_import_meta_env_default.VITE_MENU_READS_ENABLED === "true" ? "?view=summary" : ""}`, { accessToken });
  return define_import_meta_env_default.VITE_MENU_READS_ENABLED === "true" ? sharedRead(JSON.stringify([accessToken, id, "fbo"]), load) : load();
}
async function actFbo(accessToken, id, body) {
  const response = await fetch(`${API_BASE_URL}/tsd/requests/${id}/fbo/actions`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` }, body: JSON.stringify(body) });
  if (!response.ok) throw Object.assign(new Error(await responseError(response)), { rejected: response.status >= 400 && response.status < 500 && response.status !== 408 });
  return await response.json();
}
function downloadFboWbFile(accessToken, id) {
  return requestBlob(`/tsd/requests/${id}/fbo/wb-packages.xlsx`, accessToken);
}
async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: options.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      ...options.accessToken ? { Authorization: `Bearer ${options.accessToken}` } : {}
    },
    body: options.body ? JSON.stringify(options.body) : void 0
  });
  if (!response.ok) {
    const detail = await response.json().catch(() => null);
    const error = new Error(await responseError(response, detail));
    if (detail?.code === "KIZ_DUPLICATE" && detail.duplicateInfo && typeof detail.duplicateInfo === "object") {
      Object.assign(error, { code: detail.code, duplicate: true, duplicateInfo: detail.duplicateInfo });
    }
    throw error;
  }
  return await response.json();
}
async function requestBlob(path, accessToken, init = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: init.method,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      ...init.body === void 0 ? {} : { "Content-Type": "application/json" }
    },
    body: init.body === void 0 ? void 0 : JSON.stringify(init.body)
  });
  if (!response.ok) {
    throw new Error(await responseError(response));
  }
  return response.blob();
}
async function responseError(response, parsed) {
  try {
    const payload = parsed === void 0 ? await response.json() : parsed;
    if (Array.isArray(payload?.message)) {
      return payload.message.join("\n");
    }
    return payload?.message || `HTTP ${response.status}`;
  } catch {
    return `HTTP ${response.status}`;
  }
}
function ozonAssemblySupply(accessToken, id, action, body = {}) {
  return request(`/ozon-fbo-import/requests/${encodeURIComponent(id)}/supply${action ? "/" + action : ""}`, { accessToken, ...action ? { method: "POST", body } : {} });
}
function downloadOzonCargoMapping(accessToken, id) {
  return requestBlob(`/ozon-fbo-import/requests/${encodeURIComponent(id)}/supply/cargo-mapping.xlsx`, accessToken);
}
var ozonSync = (accessToken, id, action, body = {}) => request(`/tsd/requests/${encodeURIComponent(id)}/fbo/ozon-adjustment/${action}`, { accessToken, method: "POST", body });
var ozonAdjustment = (accessToken, id, action, body = {}) => request(`/tsd/requests/${encodeURIComponent(id)}/fbo/ozon-adjustment${action ? "/" + action : ""}`, { accessToken, ...action ? { method: "POST", body } : {} });
function resolveLamodaRelabel(accessToken, id, body) {
  return request(`/tsd/requests/${id}/fbo/lamoda-relabel/resolve`, { accessToken, method: "POST", body });
}
async function recordOzonLabelDownload(accessToken, id, supplyId) {
  const data = await request(`/ozon-fbo-import/requests/${encodeURIComponent(id)}/supply/label-download`, { accessToken, method: "POST", body: { supplyId } });
  if (!("pdfBase64" in data)) return data;
  const bytes = Uint8Array.from(atob(data.pdfBase64), (c) => c.charCodeAt(0));
  const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
  window.setTimeout(() => URL.revokeObjectURL(url), 3e5);
  return { url };
}

// host:react/jsx-runtime
import { j as J } from "/assets/admin-tiles-20261019-0.js";
var { jsx, jsxs, Fragment: Fragment2 } = J;

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/OzonStockAdjustment.tsx
var names = { NEEDS_ATTENTION: "\u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u044F \u2014 \u0435\u0441\u0442\u044C \u043E\u0442\u043A\u0430\u0437 \u0438\u043B\u0438 \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 Ozon", PENDING: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438", SENDING: "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F", ACCEPTED: "\u041E\u0431\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0435\u0442\u0441\u044F Ozon", SUCCESS: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E Ozon", FAILED: "\u041E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E Ozon", UNKNOWN: "\u041E\u0442\u0432\u0435\u0442 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D", RUNNING: "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430", APPLIED: "\u041F\u043B\u0430\u043D WMS \u0438 Ozon \u0441\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D", CANCELLED: "\u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u043E\u0442\u043C\u0435\u043D\u0435\u043D\u0430" };
function OzonStockAdjustment({ requestId, accessToken, disabled, onLockChange, onChanged, autoPreview = false }) {
  const [preview, setPreview] = useState(null), [quantities, setQuantities] = useState([]), [state, setState] = useState({ operation: null }), [busy, setBusy] = useState(false), [error, setError] = useState(""), [confirm, setConfirm] = useState(false);
  const running = !!state.operation && !["APPLIED", "CANCELLED"].includes(state.operation.state);
  const [mode, setMode] = useState("AVAILABLE");
  const generation = useRef(0), inFlight = useRef(false);
  const [sync, setSync] = useState(null), [syncConfirmed, setSyncConfirmed] = useState(false), [notice, setNotice] = useState("");
  async function synchronize(apply = false) {
    if (inFlight.current || disabled || apply && (!sync || !syncConfirmed)) return;
    inFlight.current = true;
    const gen = generation.current;
    setBusy(true);
    setError("");
    setNotice("");
    setPreview(null);
    try {
      const result = await ozonSync(accessToken, requestId, apply ? "sync-apply" : "sync-preview", apply ? { token: sync?.token, confirm: true } : {});
      if (gen !== generation.current) return;
      setSyncConfirmed(false);
      if (apply) {
        setSync(null);
        setNotice("\u0421\u043E\u0441\u0442\u0430\u0432 \u0412\u041C\u0421 \u043E\u0431\u043D\u043E\u0432\u043B\u0451\u043D \u0438\u0437 Ozon.");
        onChanged();
      } else setSync(result);
    } catch (e) {
      if (gen === generation.current) {
        setError(e instanceof Error ? e.message : String(e));
        setSync(null);
        setSyncConfirmed(false);
      }
    } finally {
      if (gen === generation.current) {
        setBusy(false);
        inFlight.current = false;
      }
    }
  }
  useEffect(() => {
    onLockChange(running);
  }, [running, onLockChange]);
  useEffect(() => {
    const gen = ++generation.current;
    setPreview(null);
    setSync(null);
    setConfirm(false);
    setSyncConfirmed(false);
    setError("");
    setMode("AVAILABLE");
    setState({ operation: null });
    setBusy(true);
    inFlight.current = true;
    void (async () => {
      try {
        const s = await ozonAdjustment(accessToken, requestId, "");
        if (gen !== generation.current) return;
        setState(s);
        if (autoPreview && (!s.operation || ["APPLIED", "CANCELLED"].includes(s.operation.state))) {
          const p = await ozonAdjustment(accessToken, requestId, "preview", { mode: "AVAILABLE" });
          if (gen === generation.current) {
            setPreview(p);
            setQuantities(p.rows.map((r) => r.after));
          }
        }
      } catch (e) {
        if (gen === generation.current) setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (gen === generation.current) {
          setBusy(false);
          inFlight.current = false;
        }
      }
    })();
    return () => {
      generation.current++;
    };
  }, [requestId, accessToken, autoPreview]);
  async function run(action, nextMode = mode) {
    if (inFlight.current || disabled || action === "start" && (!preview || !confirm)) return;
    inFlight.current = true;
    const gen = generation.current;
    setBusy(true);
    setError("");
    setSync(null);
    setNotice("");
    if (action === "preview") {
      setPreview(null);
      setConfirm(false);
      setMode(nextMode);
    }
    try {
      const result = await ozonAdjustment(accessToken, requestId, action, action === "start" ? { token: preview?.token, quantities, confirm: true, mode } : action === "preview" ? { mode: nextMode } : {});
      if (gen !== generation.current) return;
      if (action === "preview") {
        setPreview(result);
        setQuantities(result.rows.map((r) => r.after));
        setConfirm(false);
      } else {
        setState(result);
        setPreview(null);
        if (result.operation?.state === "APPLIED") onChanged();
      }
    } catch (e) {
      if (gen !== generation.current) return;
      setError(e instanceof Error ? e.message : String(e));
      setPreview(null);
      setConfirm(false);
      try {
        const s = await ozonAdjustment(accessToken, requestId, "");
        if (gen === generation.current) setState(s);
      } catch {
      }
    } finally {
      if (gen === generation.current) {
        setBusy(false);
        inFlight.current = false;
      }
    }
  }
  return /* @__PURE__ */ jsxs("section", { className: "ozon-adjustment", "aria-label": "\u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u043E\u0441\u0442\u0430\u0442\u043A\u043E\u0432 Ozon", "aria-busy": busy, children: [
    !running && /* @__PURE__ */ jsxs("div", { className: "ozon-adjustment__toolbar", children: [
      /* @__PURE__ */ jsx("button", { className: "ozon-adjustment__primary", type: "button", disabled: busy || disabled, onClick: () => void run("preview", "AVAILABLE"), children: "\u0421\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C Ozon \u043F\u043E \u0444\u0430\u043A\u0442\u0443" }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || disabled, onClick: () => void synchronize(), children: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u043E\u0441\u0442\u0430\u0432 \u0438\u0437 Ozon" })
    ] }),
    busy && /* @__PURE__ */ jsx("p", { role: "status", children: "\u0421\u0432\u0435\u0440\u044F\u044E \u0441\u043E\u0441\u0442\u0430\u0432 \u0438 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\u2026" }),
    notice && /* @__PURE__ */ jsx("p", { role: "status", children: notice }),
    sync && !running && /* @__PURE__ */ jsxs("div", { className: "ozon-adjustment__preview", children: [
      /* @__PURE__ */ jsx("h3", { children: "Ozon \u2192 \u0412\u041C\u0421" }),
      /* @__PURE__ */ jsxs("p", { children: [
        "\u0421\u043E\u0441\u0442\u0430\u0432 \u0438\u0437 Ozon: \u0431\u044B\u043B\u043E ",
        sync.needed,
        " \u0448\u0442. \u2192 \u0431\u0443\u0434\u0435\u0442 ",
        sync.after,
        " \u0448\u0442. \u041E\u0442\u0431\u043E\u0440 \u0438 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F."
      ] }),
      /* @__PURE__ */ jsx("div", { className: "ozon-adjustment__table", children: /* @__PURE__ */ jsxs("table", { children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { children: "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 / \u0442\u043E\u0432\u0430\u0440 / \u0428\u041A" }),
          /* @__PURE__ */ jsx("th", { children: "\u0412 \u0437\u0430\u044F\u0432\u043A\u0435" }),
          /* @__PURE__ */ jsx("th", { children: "\u0412 Ozon" }),
          /* @__PURE__ */ jsx("th", { children: "\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: sync.rows.map((r) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsxs("td", { children: [
            r.direction,
            /* @__PURE__ */ jsx("br", {}),
            r.name,
            /* @__PURE__ */ jsx("br", {}),
            r.barcode
          ] }),
          /* @__PURE__ */ jsx("td", { children: r.before }),
          /* @__PURE__ */ jsx("td", { children: r.after }),
          /* @__PURE__ */ jsx("td", { children: r.packed })
        ] }, `${r.direction}:${r.skuId}`)) })
      ] }) }),
      /* @__PURE__ */ jsxs("label", { className: "ozon-adjustment__confirm", children: [
        /* @__PURE__ */ jsx("input", { type: "checkbox", checked: syncConfirmed, disabled: busy || disabled, onChange: (e) => setSyncConfirmed(e.target.checked) }),
        "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0437\u0430\u044F\u0432\u043A\u0438 \u043F\u043E \u0441\u043E\u0441\u0442\u0430\u0432\u0443 Ozon"
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || disabled || !syncConfirmed, onClick: () => void synchronize(true), children: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443 \u0438\u0437 Ozon" }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, onClick: () => setSync(null), children: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440" })
    ] }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", className: "ozon-adjustment__error", children: error }),
    state.operation && /* @__PURE__ */ jsxs("div", { role: "status", className: "ozon-adjustment__preview", children: [
      /* @__PURE__ */ jsx("strong", { children: names[state.operation.state] ?? state.operation.state }),
      state.operation.operations.map((o) => /* @__PURE__ */ jsxs("p", { children: [
        o.direction ? `${o.direction} \xB7 ` : "",
        "\u041F\u043E\u0441\u0442\u0430\u0432\u043A\u0430 ",
        o.supplyId,
        ": ",
        names[o.state] ?? o.state,
        o.error ? ` \xB7 ${o.error}` : ""
      ] }, o.supplyId)),
      running && /* @__PURE__ */ jsxs(Fragment2, { children: [
        /* @__PURE__ */ jsx("p", { children: "\u0421\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0430 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442 \u043F\u0440\u0438\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u044B \u0434\u043E \u0441\u0432\u0435\u0440\u043A\u0438. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F." }),
        /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || disabled, onClick: () => void run("resume"), children: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 / \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C" }),
        state.operation.operations.every((o) => ["FAILED", "PENDING"].includes(o.state)) && /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || disabled, onClick: () => void run("cancel"), children: "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0442\u043A\u043B\u043E\u043D\u0451\u043D\u043D\u0443\u044E \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0443" })
      ] })
    ] }),
    preview && !running && /* @__PURE__ */ jsxs("div", { className: "ozon-adjustment__preview", children: [
      /* @__PURE__ */ jsx("h3", { children: "\u0412\u041C\u0421 \u2192 Ozon" }),
      /* @__PURE__ */ jsx("div", { className: "ozon-adjustment__toolbar", "aria-label": "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0438", children: preview.physicalBasis === "PACKED" ? /* @__PURE__ */ jsx("strong", { children: "\u041F\u043E \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u043C\u0443 \u0441\u043E\u0441\u0442\u0430\u0432\u0443 \u043A\u043E\u0440\u043E\u0431\u043E\u0432" }) : /* @__PURE__ */ jsxs(Fragment2, { children: [
        /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": mode === "AVAILABLE", disabled: busy || disabled, onClick: () => void run("preview", "AVAILABLE"), children: "\u041F\u043E \u043D\u0430\u043B\u0438\u0447\u0438\u044E" }),
        /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": mode === "PICKED", disabled: busy || disabled, onClick: () => void run("preview", "PICKED"), children: "\u041F\u043E \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043D\u043E\u043C\u0443" })
      ] }) }),
      /* @__PURE__ */ jsxs("p", { children: [
        "\u0412 \u0437\u0430\u044F\u0432\u043A\u0435 ",
        preview.needed,
        " \u0448\u0442. \u2192 \u0431\u0443\u0434\u0435\u0442 ",
        preview.after,
        " \u0448\u0442. ",
        preview.physicalBasis === "AVAILABLE" ? "\u0423\u0447\u0442\u0435\u043D\u044B \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u0442\u043E\u0432\u0430\u0440\u044B \u0438 \u0441\u0432\u043E\u0431\u043E\u0434\u043D\u044B\u0439 \u043E\u0441\u0442\u0430\u0442\u043E\u043A \u0437\u0430 \u0432\u044B\u0447\u0435\u0442\u043E\u043C \u0447\u0443\u0436\u0438\u0445 \u0440\u0435\u0437\u0435\u0440\u0432\u043E\u0432." : preview.physicalBasis === "PACKED" ? "\u0423\u0447\u0442\u0451\u043D \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0432 \u0412\u041C\u0421 \u0441\u043E\u0441\u0442\u0430\u0432 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438." : "\u0423\u0447\u0442\u0435\u043D\u044B \u0442\u043E\u043B\u044C\u043A\u043E \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043D\u044B\u0435 \u0435\u0434\u0438\u043D\u0438\u0446\u044B.",
        " \u041A\u043E\u0440\u043E\u0431\u0430, \u0441\u043A\u0430\u043D\u044B \u0438 \u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F."
      ] }),
      /* @__PURE__ */ jsx("div", { className: "ozon-adjustment__table", children: /* @__PURE__ */ jsxs("table", { children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { children: "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 / \u0442\u043E\u0432\u0430\u0440 / \u0428\u041A" }),
          /* @__PURE__ */ jsx("th", { children: "\u0412 \u0412\u041C\u0421" }),
          /* @__PURE__ */ jsx("th", { children: "\u0412 Ozon" }),
          /* @__PURE__ */ jsx("th", { children: "\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E" }),
          /* @__PURE__ */ jsx("th", { children: "\u0411\u0443\u0434\u0435\u0442" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: (preview.comparison ?? preview.rows.map((r) => ({ ...r, remote: r.before }))).map((r) => {
          const i = preview.rows.findIndex((v) => v.direction === r.direction && v.barcode === r.barcode), row = preview.rows[i];
          return /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsxs("td", { children: [
              r.direction,
              /* @__PURE__ */ jsx("br", {}),
              preview.lines.find((l) => l.skuId === row?.skuId)?.name,
              /* @__PURE__ */ jsx("br", {}),
              r.barcode
            ] }),
            /* @__PURE__ */ jsx("td", { children: r.before }),
            /* @__PURE__ */ jsx("td", { children: r.remote }),
            /* @__PURE__ */ jsx("td", { children: row?.packed ?? 0 }),
            /* @__PURE__ */ jsx("td", { children: row ? /* @__PURE__ */ jsx("input", { "aria-label": `\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E ${r.direction} ${r.barcode}`, type: "number", min: row.packed, max: row.before, step: 1, value: quantities[i], disabled: busy || disabled || preview.physicalBasis === "PACKED", onChange: (e) => {
              const next = [...quantities];
              next[i] = Number(e.target.value);
              setQuantities(next);
              setConfirm(false);
            } }) : 0 })
          ] }, `${r.direction}:${r.barcode}`);
        }) })
      ] }) }),
      preview.changes ?? preview.after < preview.needed ? /* @__PURE__ */ jsxs(Fragment2, { children: [
        /* @__PURE__ */ jsx("p", { children: preview.physicalBasis === "PACKED" ? "\u0421\u043E\u0441\u0442\u0430\u0432 \u0431\u0443\u0434\u0435\u0442 \u043F\u0435\u0440\u0435\u0434\u0430\u043D \u0442\u043E\u0447\u043D\u043E \u043F\u043E \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u043C \u0435\u0434\u0438\u043D\u0438\u0446\u0430\u043C \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F." : "\u0420\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u0435 \u043C\u0435\u0436\u0434\u0443 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F\u043C\u0438 \u043C\u043E\u0436\u043D\u043E \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C, \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0432 \u0438\u0442\u043E\u0433 \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0442\u043E\u0432\u0430\u0440\u0430. \u0423\u0436\u0435 \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u043D\u0435 \u0443\u043C\u0435\u043D\u044C\u0448\u0430\u0435\u0442\u0441\u044F." }),
        /* @__PURE__ */ jsxs("label", { className: "ozon-adjustment__confirm", children: [
          /* @__PURE__ */ jsx("input", { type: "checkbox", checked: confirm, disabled: busy || disabled, onChange: (e) => setConfirm(e.target.checked) }),
          "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0439 \u0441\u043E\u0441\u0442\u0430\u0432 \u0432 \u0412\u041C\u0421 \u0438 Ozon"
        ] }),
        /* @__PURE__ */ jsx("button", { className: "ozon-adjustment__primary", type: "button", disabled: busy || disabled || !confirm, onClick: () => void run("start"), children: "\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0432 \u0412\u041C\u0421 \u0438 Ozon" })
      ] }) : /* @__PURE__ */ jsx("p", { children: "\u0421\u043E\u0441\u0442\u0430\u0432 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442. \u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F." }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, onClick: () => setPreview(null), children: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440" })
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/WbFboSupply.tsx
function WbSupplyWindow({ requestId, accessToken }) {
  const dialog = useRef(null);
  const [open, setOpen] = useState(false);
  return /* @__PURE__ */ jsxs(Fragment2, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        className: "primary-button wb-supply-trigger",
        title: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0443 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0438 Wildberries",
        "aria-haspopup": "dialog",
        onClick: () => {
          dialog.current?.showModal();
          setOpen(true);
        },
        children: "\u0417\u0430\u044F\u0432\u043A\u0430 \u0412\u0411"
      }
    ),
    /* @__PURE__ */ jsx(
      "dialog",
      {
        ref: dialog,
        "aria-label": "\u041F\u043E\u0441\u0442\u0430\u0432\u043A\u0430 \u0412\u0411",
        onClose: () => setOpen(false),
        onKeyDown: (event) => event.stopPropagation(),
        onClick: (event) => event.stopPropagation(),
        className: "wb-supply-dialog",
        children: open && /* @__PURE__ */ jsxs(Fragment2, { children: [
          /* @__PURE__ */ jsxs("header", { children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("small", { children: "\u0424\u0411\u041E WB \xB7 \u041F\u041E\u0421\u0422\u0410\u0412\u041A\u0410" }),
              /* @__PURE__ */ jsx("h2", { children: "\u041F\u0435\u0440\u0435\u0434\u0430\u0447\u0430 \u0438 \u043F\u0440\u0438\u0451\u043C\u043A\u0430" })
            ] }),
            /* @__PURE__ */ jsx("button", { type: "button", className: "wb-window-close", "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u043A\u043D\u043E", title: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u043A\u043D\u043E", autoFocus: true, onClick: () => dialog.current?.close(), children: "\xD7" })
          ] }),
          /* @__PURE__ */ jsx(WbFboSupply, { requestId, accessToken, onCancel: () => dialog.current?.close() }, requestId)
        ] })
      }
    )
  ] });
}
function WbFboSupply({ requestId, accessToken, disabled = false, onCancel }) {
  const [data, setData] = useState(null), [error, setError] = useState(""), [busy, setBusy] = useState(false), [input, setInput] = useState(""), [connection, setConnection] = useState("");
  const path = "/api/v1/client-requests/" + encodeURIComponent(requestId) + "/wb-fbo-supply";
  async function call(action2 = "", body, signal) {
    const r = await fetch(path + (action2 ? "/" + action2 : ""), { method: action2 ? "POST" : "GET", headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" }, ...body ? { body: JSON.stringify(body) } : {}, signal });
    let v;
    try {
      v = await r.json();
    } catch {
      throw new Error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442 WMS.");
    }
    if (!r.ok) throw new Error(typeof v.message === "string" ? v.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0443 WB.");
    return v;
  }
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    setData(null);
    setError("");
    setInput("");
    setConnection("");
    call("", void 0, controller.signal).then((v) => {
      if (active) {
        setData(v);
        if (v.connections.length === 1) setConnection(v.connections[0].id);
      }
    }).catch((e) => {
      if (active) setError(e.message);
    });
    return () => {
      active = false;
      controller.abort();
    };
  }, [requestId, accessToken]);
  useEffect(() => {
    if (!data?.binding || disabled || busy) return;
    let active = true, pending = false;
    const controller = new AbortController();
    const refresh = async () => {
      if (pending || document.visibilityState === "hidden") return;
      pending = true;
      try {
        const v = await call("refresh", void 0, controller.signal);
        if (active) {
          setData(v);
          setError("");
        }
      } catch (e) {
        if (active) setError(e instanceof Error ? e.message : "\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 WB");
      } finally {
        pending = false;
      }
    };
    const timer = window.setInterval(refresh, 6e4);
    window.addEventListener("focus", refresh);
    return () => {
      active = false;
      controller.abort();
      window.clearInterval(timer);
      window.removeEventListener("focus", refresh);
    };
  }, [requestId, accessToken, !!data?.binding, disabled, busy]);
  async function action(kind) {
    if (busy || disabled) return;
    if (kind === "gate" && !window.confirm("\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u0435\u0442\u0435, \u0447\u0442\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0435 \u043A\u043E\u0440\u043E\u0431\u0430 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u044B \u0432 \u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0438\u043B\u044C? \u042D\u0442\u043E \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u043F\u0440\u0438\u0451\u043C\u043A\u0438 WB.")) return;
    setBusy(true);
    setError("");
    try {
      setData(await call(kind, kind === "bind" ? { connectionId: connection, input } : void 0));
    } catch (e) {
      setError(e instanceof Error ? e.message : "\u041E\u0448\u0438\u0431\u043A\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438");
    } finally {
      setBusy(false);
    }
  }
  const b = data?.binding;
  const date = (s) => new Date(s).toLocaleString("ru-RU", { timeZone: "Europe/Moscow" });
  return /* @__PURE__ */ jsxs("section", { className: "wb-supply-content", "aria-label": "\u041F\u043E\u0441\u0442\u0430\u0432\u043A\u0430 \u0424\u0411\u041E WB", children: [
    !data && !error && /* @__PURE__ */ jsx("p", { children: "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u044E \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0443\u2026" }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
    data && !b && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "\u041F\u0440\u0438\u0432\u044F\u0436\u0438\u0442\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0443 WB \u0434\u043B\u044F \u043E\u0442\u0441\u043B\u0435\u0436\u0438\u0432\u0430\u043D\u0438\u044F \u043F\u0440\u0438\u0451\u043C\u043A\u0438. \u0412 \u0437\u0430\u044F\u0432\u043A\u0435 ",
        data.plannedQuantity,
        " \u0448\u0442."
      ] }),
      data.canWrite ? /* @__PURE__ */ jsxs("div", { className: "wb-supply-form", children: [
        /* @__PURE__ */ jsxs("label", { children: [
          "\u041A\u0430\u0431\u0438\u043D\u0435\u0442 WB",
          /* @__PURE__ */ jsxs("select", { value: connection, disabled: busy || disabled, onChange: (e) => setConnection(e.target.value), children: [
            /* @__PURE__ */ jsx("option", { value: "", children: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043A\u0430\u0431\u0438\u043D\u0435\u0442" }),
            data.connections.map((c) => /* @__PURE__ */ jsx("option", { value: c.id, children: c.accountName || c.sellerId || "\u041A\u0430\u0431\u0438\u043D\u0435\u0442 WB" }, c.id))
          ] })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "\u0421\u0441\u044B\u043B\u043A\u0430 \u0438\u043B\u0438 \u043D\u043E\u043C\u0435\u0440 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0438 WB",
          /* @__PURE__ */ jsx("input", { value: input, disabled: busy || disabled, onChange: (e) => setInput(e.target.value), placeholder: "41834673 \u0438\u043B\u0438 \u0441\u0441\u044B\u043B\u043A\u0430 \u0438\u0437 \u043A\u0430\u0431\u0438\u043D\u0435\u0442\u0430 WB" })
        ] }),
        /* @__PURE__ */ jsxs("footer", { children: [
          /* @__PURE__ */ jsx("button", { type: "button", onClick: onCancel, children: "\u041E\u0442\u043C\u0435\u043D\u0430" }),
          /* @__PURE__ */ jsx("button", { className: "wb-bind", type: "button", disabled: busy || disabled || !connection || !input.trim(), onClick: () => void action("bind"), children: "\u041F\u0440\u0438\u0432\u044F\u0437\u0430\u0442\u044C \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0443 WB" })
        ] })
      ] }) : /* @__PURE__ */ jsx("p", { children: "\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0443 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0437\u0430\u044F\u0432\u043A\u0438." })
    ] }),
    b && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        /* @__PURE__ */ jsxs("a", { href: "https://seller.wildberries.ru/supplies-management/all-supplies/supply-detail?supplyId=" + encodeURIComponent(b.supplyId), target: "_blank", rel: "noreferrer", children: [
          "WB \u2116",
          b.supplyId
        ] }),
        " \xB7 ",
        b.warehouse,
        " \xB7 ",
        b.quantity,
        " \u0448\u0442."
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        /* @__PURE__ */ jsx("strong", { children: "\u041F\u0435\u0440\u0435\u0434\u0430\u0447\u0430 \u0441\u043E \u0441\u043A\u043B\u0430\u0434\u0430:" }),
        " ",
        data?.dispatch ? `\u041E\u0442\u0433\u0440\u0443\u0436\u0435\u043D\u043E \xB7 ${date(data?.dispatch.at)} \u041C\u0421\u041A` : "\u041D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430"
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        /* @__PURE__ */ jsx("strong", { children: "\u0421\u0442\u0430\u0442\u0443\u0441 WB:" }),
        " ",
        [4, 5, 6].includes(b.statusId) ? "\u0421\u0434\u0430\u043D\u043E \xB7 " + b.status : b.status,
        " \xB7 \u043F\u0440\u0438\u043D\u044F\u0442\u043E ",
        b.acceptedQuantity,
        " \u0438\u0437 ",
        b.quantity,
        " \u0448\u0442."
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        "\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u0443\u0441\u043F\u0435\u0448\u043D\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430: ",
        date(b.checkedAt),
        " \u041C\u0421\u041A"
      ] }),
      b.lastError && /* @__PURE__ */ jsxs("p", { role: "alert", children: [
        b.lastError,
        " \u041F\u043E\u043A\u0430\u0437\u0430\u043D \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0441\u0442\u0430\u0442\u0443\u0441."
      ] }),
      b.quantity !== data?.plannedQuantity && /* @__PURE__ */ jsxs("p", { role: "alert", children: [
        "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E WB \u0438 WMS \u043E\u0442\u043B\u0438\u0447\u0430\u0435\u0442\u0441\u044F: ",
        b.quantity,
        " / ",
        data?.plannedQuantity,
        " \u0448\u0442."
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || disabled, onClick: () => void action("refresh"), children: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0443\u0441 WB" }),
      data?.canWrite && !data?.dispatch && /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || disabled || !data.canGate, onClick: () => void action("gate"), children: "\u041E\u0442\u0433\u0440\u0443\u0436\u0435\u043D\u043E" }),
      !data?.dispatch && !data?.canGate && /* @__PURE__ */ jsx("p", { children: "\u041F\u0435\u0440\u0435\u0434\u0430\u0447\u0443 \u043C\u043E\u0436\u043D\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043A\u043E\u0440\u043E\u0431\u043E\u0432." })
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/components/lamoda/LamodaBatchFields.tsx
var batchKeys = ["composition", "manufacturer", "origin", "manufacturedAt"];
var titles = { composition: "\u0421\u043E\u0441\u0442\u0430\u0432, %", manufacturer: "\u0418\u0437\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0435\u043B\u044C", origin: "\u0421\u0434\u0435\u043B\u0430\u043D\u043E \u0432 \u2014 \u0441\u0442\u0440\u0430\u043D\u0430 \u0438 \u0430\u0434\u0440\u0435\u0441", manufacturedAt: "\u0414\u0430\u0442\u0430 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u0430" };
function groupLamodaDrafts(drafts) {
  const groups = /* @__PURE__ */ new Map();
  for (const d of drafts) {
    const key = JSON.stringify([d.model, ...batchKeys.map((k) => d[k])]);
    groups.set(key, [...groups.get(key) || [], d]);
  }
  return [...groups.values()];
}
function LamodaBatchFields({ drafts, values, onChange, confirmed, onConfirm, disabled }) {
  return /* @__PURE__ */ jsxs("fieldset", { disabled, className: "lamoda-card", children: [
    /* @__PURE__ */ jsx("legend", { children: "\u0414\u0430\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0438 Lamoda \xB7 58 \xD7 40 \u043C\u043C" }),
    /* @__PURE__ */ jsx("p", { children: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043D\u0430 \u0441\u0442\u0438\u043A\u0435\u0440\u0430\u0445 \u044D\u0442\u0438\u0445 \u043A\u043E\u0441\u0442\u044E\u043C\u043E\u0432. \u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u043C \u0438\u0445 \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0438 \u044D\u0442\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0438; \u0434\u0440\u0443\u0433\u0438\u0435 \u0437\u0430\u044F\u0432\u043A\u0438 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u044F\u044E\u0442\u0441\u044F." }),
    groupLamodaDrafts(drafts).map((group) => /* @__PURE__ */ jsxs("section", { className: "lamoda-card", children: [
      /* @__PURE__ */ jsx("h4", { children: group[0].model }),
      /* @__PURE__ */ jsxs("p", { children: [
        "\u0420\u0430\u0437\u043C\u0435\u0440\u044B: ",
        group.map((d) => d.size).join(", ")
      ] }),
      batchKeys.map((key) => /* @__PURE__ */ jsxs("label", { style: { display: "grid", gap: 6, marginBottom: 12 }, children: [
        titles[key],
        /* @__PURE__ */ jsx("input", { maxLength: key === "manufacturedAt" ? 10 : 600, placeholder: key === "manufacturedAt" ? "\u0414\u0414.\u041C\u041C.\u0413\u0413\u0413\u0413" : titles[key], value: values[group[0].skuId]?.[key] ?? "", onChange: (e) => {
          const next = { ...values };
          for (const d of group) next[d.skuId] = { ...next[d.skuId], skuId: d.skuId, [key]: e.target.value };
          onChange(next);
          onConfirm(false);
        } })
      ] }, key))
    ] }, group[0].skuId)),
    /* @__PURE__ */ jsxs("label", { children: [
      /* @__PURE__ */ jsx("input", { type: "checkbox", checked: confirmed, onChange: (e) => onConfirm(e.target.checked) }),
      "\u0414\u0430\u043D\u043D\u044B\u0435 \u0441\u043E\u0441\u0442\u0430\u0432\u0430, \u0438\u0437\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u0435\u043B\u044F, \u0441\u0442\u0440\u0430\u043D\u044B \u0438 \u0434\u0430\u0442\u044B \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u044B \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u043F\u0430\u0440\u0442\u0438\u0438"
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/LamodaRelabelDataForm.tsx
function LamodaRelabelDataForm({ requestId, token, disabled, onReady, onSaved }) {
  const [view, setView] = useState(null), [values, setValues] = useState({}), [confirmed, setConfirmed] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState("");
  const url = "/api/v1/tsd/requests/" + encodeURIComponent(requestId) + "/fbo/lamoda-relabel/data";
  async function read(response) {
    const value = await response.json();
    if (!response.ok) throw new Error(Array.isArray(value.message) ? value.message.join("; ") : value.message || "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0438.");
    return value;
  }
  function accept(v) {
    setView(v);
    setValues(Object.fromEntries(v.drafts.map((d) => [d.skuId, { skuId: d.skuId, composition: d.composition, manufacturer: d.manufacturer, origin: d.origin, manufacturedAt: d.manufacturedAt }])));
    setConfirmed(v.saved);
    onReady(!v.enabled || v.saved);
  }
  useEffect(() => {
    let active = true;
    onReady(false);
    setView(null);
    setError("");
    fetch(url, { headers: { Authorization: `Bearer ${token}` } }).then(read).then((v) => {
      if (active) accept(v);
    }).catch((e) => {
      if (active) setError(e.message);
    });
    return () => {
      active = false;
    };
  }, [url, token]);
  async function save() {
    setBusy(true);
    setError("");
    try {
      const result = await read(await fetch(url, { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify({ confirmed, labelData: view.drafts.map((d) => values[d.skuId]) }) }));
      accept(result);
      await onSaved();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }
  if (view && !view.enabled) return null;
  return /* @__PURE__ */ jsxs("section", { "aria-label": "\u0414\u0430\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0438 Lamoda", children: [
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
    !view && !error && /* @__PURE__ */ jsx("p", { children: "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u044E \u0434\u0430\u043D\u043D\u044B\u0435 \u0441\u0442\u0438\u043A\u0435\u0440\u043E\u0432\u2026" }),
    view && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsx(LamodaBatchFields, { drafts: view.drafts, values, onChange: (v) => {
        setValues(v);
        onReady(false);
      }, confirmed, onConfirm: (v) => {
        setConfirmed(v);
        if (!v) onReady(false);
      }, disabled: disabled || busy || view.locked }),
      view.locked ? /* @__PURE__ */ jsx("p", { children: "\u0414\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u0435\u043D\u044B \u0437\u0430 \u043D\u0430\u043F\u0435\u0447\u0430\u0442\u0430\u043D\u043D\u044B\u043C\u0438 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0430\u043C\u0438 \u044D\u0442\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0438." }) : /* @__PURE__ */ jsx("button", { type: "button", className: "primary-button", disabled: disabled || busy || !confirmed || !view.drafts.every((d) => batchKeys.every((k) => values[d.skuId]?.[k]?.trim())), onClick: () => void save(), children: busy ? "\u0421\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u2026" : "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0434\u0430\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u043F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0438" }),
      view.saved && confirmed && /* @__PURE__ */ jsx("p", { children: "\u0414\u0430\u043D\u043D\u044B\u0435 \u043F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0438." })
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/LamodaFboRelabel.tsx
function LamodaFboRelabel({ plan, accessToken, disabled, command, refresh }) {
  const [source, setSource] = useState(""), [sourceKiz, setSourceKiz] = useState(""), [selected, setSelected] = useState(""), [stations, setStations] = useState([]), [station, setStation] = useState("");
  const [barcode, setBarcode] = useState(""), [kiz, setKiz] = useState(""), [busy, setBusy] = useState(false), [error, setError] = useState("");
  const [labelReady, setLabelReady] = useState(false);
  const units = plan.relabelUnits ?? [], unit = units.find((u) => u.id === selected);
  async function resolve() {
    setBusy(true);
    setError("");
    setSelected("");
    setBarcode("");
    setKiz("");
    try {
      const u = await resolveLamodaRelabel(accessToken, plan.requestId, { barcode: source, kiz: sourceKiz || void 0 });
      setSelected(u.id);
      await refresh();
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }
  async function load() {
    setBusy(true);
    setError("");
    try {
      setStations(await fetchLamodaRelabelStations(accessToken, plan.requestId));
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }
  async function print() {
    if (!unit || !station) return;
    setBusy(true);
    setError("");
    try {
      await printLamodaRelabel(accessToken, plan.requestId, { unitId: unit.id, stationId: station, printId: crypto.randomUUID() });
      await refresh();
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }
  if (!plan.relabelRequired) return null;
  return /* @__PURE__ */ jsxs("section", { "aria-label": "\u041F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0430 Lamoda", children: [
    /* @__PURE__ */ jsx("h3", { children: "\u041F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0430 Lamoda" }),
    /* @__PURE__ */ jsxs("p", { children: [
      "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438: ",
      units.length,
      " \u0448\u0442. \u0421\u043A\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u0441\u043A\u043B\u0430\u0434\u0441\u043A\u043E\u0439 \u0428\u041A, \u0447\u0442\u043E\u0431\u044B \u043D\u0430\u0439\u0442\u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 Lamoda. \u041D\u0430\u043F\u0435\u0447\u0430\u0442\u0430\u0439\u0442\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0443, \u043D\u0430\u043A\u043B\u0435\u0439\u0442\u0435 \u0435\u0451 \u043D\u0430 \u0442\u043E\u0432\u0430\u0440 \u0438 \u043E\u0442\u0441\u043A\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u043D\u043E\u0432\u044B\u0439 \u0428\u041A. \u0414\u043B\u044F \u043C\u0430\u0440\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u0442\u043E\u0432\u0430\u0440\u0430 \u0442\u0430\u043A\u0436\u0435 \u0441\u043A\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u041A\u0418\u0417."
    ] }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
    /* @__PURE__ */ jsx(LamodaRelabelDataForm, { requestId: plan.requestId, token: accessToken, disabled, onReady: setLabelReady, onSaved: refresh }),
    /* @__PURE__ */ jsxs("fieldset", { disabled: disabled || busy, children: [
      /* @__PURE__ */ jsxs("label", { children: [
        "\u0421\u043A\u043B\u0430\u0434\u0441\u043A\u043E\u0439 \u0428\u041A",
        /* @__PURE__ */ jsx("input", { value: source, onChange: (e) => {
          setSource(e.target.value);
          setSelected("");
        }, autoComplete: "off" })
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "\u041A\u0418\u0417 \u0442\u043E\u0432\u0430\u0440\u0430, \u0435\u0441\u043B\u0438 \u043C\u0430\u0440\u043A\u0438\u0440\u043E\u0432\u0430\u043D",
        /* @__PURE__ */ jsx("input", { value: sourceKiz, onChange: (e) => {
          setSourceKiz(e.target.value);
          setSelected("");
        }, autoComplete: "off" })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: !source.trim(), onClick: () => void resolve(), children: "\u041D\u0430\u0439\u0442\u0438 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 Lamoda" })
    ] }),
    unit && /* @__PURE__ */ jsxs("fieldset", { disabled: disabled || busy, children: [
      /* @__PURE__ */ jsxs("p", { children: [
        unit.label?.name,
        " \xB7 \u0440\u0430\u0437\u043C\u0435\u0440 ",
        unit.label?.size ?? "\u2014",
        " \xB7 \u0428\u041A Lamoda: ",
        unit.label?.barcode
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        "\u0410\u0440\u0442\u0438\u043A\u0443\u043B Lamoda: ",
        unit.label?.article,
        ". \u041F\u0435\u0447\u0430\u0442\u044C: ",
        unit.printStatus ?? "\u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0430",
        "."
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", onClick: () => void load(), children: "\u041D\u0430\u0439\u0442\u0438 \u0441\u0442\u0430\u043D\u0446\u0438\u0438 \u043F\u0435\u0447\u0430\u0442\u0438" }),
      /* @__PURE__ */ jsxs("select", { "aria-label": "\u0421\u0442\u0430\u043D\u0446\u0438\u044F \u043F\u0435\u0447\u0430\u0442\u0438", value: station, onChange: (e) => setStation(e.target.value), children: [
        /* @__PURE__ */ jsx("option", { value: "", children: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0442\u0430\u043D\u0446\u0438\u044E" }),
        stations.map((s) => /* @__PURE__ */ jsxs("option", { value: s.id, children: [
          s.name,
          " \xB7 ",
          s.printerName
        ] }, s.id))
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: !labelReady || !station || !!unit.printStatus && unit.printStatus !== "FAILED", onClick: () => void print(), children: "\u041D\u0430\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C 2 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438 58 \xD7 40" }),
      /* @__PURE__ */ jsx("button", { type: "button", onClick: () => void refresh(), children: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043F\u0435\u0447\u0430\u0442\u044C" }),
      /* @__PURE__ */ jsxs("label", { children: [
        "\u041D\u043E\u0432\u044B\u0439 \u0428\u041A Lamoda",
        /* @__PURE__ */ jsx("input", { value: barcode, onChange: (e) => setBarcode(e.target.value), autoComplete: "off" })
      ] }),
      unit.kiz && /* @__PURE__ */ jsxs("label", { children: [
        "\u041A\u0418\u0417 \u044D\u0442\u043E\u0439 \u0435\u0434\u0438\u043D\u0438\u0446\u044B",
        /* @__PURE__ */ jsx("input", { value: kiz, onChange: (e) => setKiz(e.target.value), autoComplete: "off" })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: unit.printStatus !== "PRINTED" || !barcode || !!unit.kiz && !kiz, onClick: () => {
        void command("RELABEL_UNIT", { relabelUnitId: unit.id, barcode, kiz: unit.kiz ? kiz : void 0 }).then(() => {
          setBarcode("");
          setKiz("");
          setSelected("");
          setSource("");
          setSourceKiz("");
        });
      }, children: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043F\u0435\u0440\u0435\u043A\u043B\u0435\u0439\u043A\u0443" })
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/lib/visiblePolling.ts
function startVisiblePolling(refresh, element, interval = 5e3) {
  const visible = () => {
    let node = element();
    if (document.visibilityState !== "visible" || !node?.isConnected) return false;
    for (; node; node = node.parentElement) if (node.hasAttribute("hidden") || node.classList.contains("panthera-window-minimized") || getComputedStyle(node).display === "none") return false;
    return true;
  };
  let wasVisible = visible();
  const check = () => {
    const now = visible();
    if (now && !wasVisible) refresh();
    wasVisible = now;
  };
  const observer = new MutationObserver(check);
  for (let node = element(); node; node = node.parentElement) observer.observe(node, { attributes: true, attributeFilter: ["hidden", "class", "style"] });
  document.addEventListener("visibilitychange", check);
  const timer = setInterval(() => {
    const now = visible();
    wasVisible = now;
    if (now) refresh();
  }, interval);
  return () => {
    clearInterval(timer);
    observer.disconnect();
    document.removeEventListener("visibilitychange", check);
  };
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/fboLivePolling.ts
function startFboPolling(refresh, visible) {
  const timer = setInterval(() => {
    if (visible()) refresh();
  }, 5e3);
  return () => clearInterval(timer);
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/FboHistory.tsx
var time = (value) => value ? new Date(value).toLocaleString("ru-RU", { timeZone: "Europe/Moscow" }) : "\u2014";
function FboHistory({ plan, accessToken }) {
  const lazy = define_import_meta_env_default.VITE_MENU_READS_ENABLED === "true";
  const [open, setOpen] = useState(false), [offset, setOffset] = useState(0), [retry, setRetry] = useState(0);
  const [history, setHistory] = useState([]), [loading, setLoading] = useState(false), [error, setError] = useState("");
  const [historyTotal, setHistoryTotal] = useState();
  const pageScope = useRef();
  useEffect(() => {
    if (!lazy || !open || !accessToken) return;
    const scope = JSON.stringify([accessToken, plan.requestId, offset]);
    if (pageScope.current !== scope) {
      setHistory([]);
      setHistoryTotal(void 0);
      pageScope.current = scope;
    }
    let cancelled = false;
    setLoading(true);
    setError("");
    fetchFboHistory(accessToken, plan.requestId, offset).then((data) => {
      if (!cancelled) {
        setHistory(data.pickedUnits);
        setHistoryTotal(data.total);
      }
    }).catch((e) => {
      if (!cancelled) setError(String(e));
    }).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [lazy, open, accessToken, plan.requestId, plan.observedAt, offset, retry]);
  const total = open ? historyTotal ?? plan.pickedUnitsCount ?? plan.pickedUnits?.length ?? 0 : plan.pickedUnitsCount ?? plan.pickedUnits?.length ?? 0;
  const historyRows = lazy ? open ? accessToken ? history : (plan.pickedUnits ?? []).slice(offset, offset + 100) : [] : plan.pickedUnits ?? [];
  return /* @__PURE__ */ jsxs("details", { className: "fbo-progress-history", onToggle: (e) => setOpen(e.currentTarget.open), children: [
    /* @__PURE__ */ jsxs("summary", { children: [
      "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043E\u0442\u0431\u043E\u0440\u0430 \xB7 ",
      total,
      " \u0435\u0434\u0438\u043D\u0438\u0446"
    ] }),
    loading && history.length === 0 && /* @__PURE__ */ jsx("p", { role: "status", children: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0438\u0441\u0442\u043E\u0440\u0438\u0438\u2026" }),
    error && /* @__PURE__ */ jsxs("p", { role: "alert", children: [
      error,
      " ",
      /* @__PURE__ */ jsx("button", { onClick: () => setRetry((n) => n + 1), children: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C" })
    ] }),
    (!lazy || open) && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsx("div", { className: "online-execution-table-wrap", children: /* @__PURE__ */ jsxs("table", { className: "online-execution-table", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { children: "\u0422\u043E\u0432\u0430\u0440 / \u0428\u041A" }),
          /* @__PURE__ */ jsx("th", { children: "\u041A\u0418\u0417" }),
          /* @__PURE__ */ jsx("th", { children: "\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u043A\u043E\u0440\u043E\u0431" }),
          /* @__PURE__ */ jsx("th", { children: "\u041E\u0442\u043E\u0431\u0440\u0430\u043B / \u0432\u0440\u0435\u043C\u044F \u041C\u0421\u041A" }),
          /* @__PURE__ */ jsx("th", { children: "\u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430 / \u0432\u0440\u0435\u043C\u044F \u041C\u0421\u041A" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: historyRows.map((u) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsxs("td", { children: [
            plan.lines.find((l) => l.id === u.requestItemId)?.name,
            /* @__PURE__ */ jsx("br", {}),
            u.barcode
          ] }),
          /* @__PURE__ */ jsx("td", { className: "fbo-kiz", children: u.kiz || "\u0411\u0435\u0437 \u041A\u0418\u0417" }),
          /* @__PURE__ */ jsxs("td", { children: [
            u.sourceBoxCode,
            u.wholeBox ? " \xB7 \u0446\u0435\u043B\u0438\u043A\u043E\u043C" : ""
          ] }),
          /* @__PURE__ */ jsxs("td", { children: [
            u.pickedBy || "\u2014",
            /* @__PURE__ */ jsx("br", {}),
            time(u.pickedAt)
          ] }),
          /* @__PURE__ */ jsxs("td", { children: [
            u.targetBoxCode || "\u041D\u0435 \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E",
            /* @__PURE__ */ jsx("br", {}),
            u.packedBy,
            " ",
            time(u.packedAt)
          ] })
        ] }, u.id)) })
      ] }) }),
      lazy && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("button", { disabled: offset === 0 || loading, onClick: () => setOffset((n) => Math.max(0, n - 100)), children: "\u041D\u0430\u0437\u0430\u0434" }),
        /* @__PURE__ */ jsxs("span", { children: [
          " ",
          total ? offset + 1 : 0,
          "\u2013",
          Math.min(offset + 100, total),
          " \u0438\u0437 ",
          total,
          " "
        ] }),
        /* @__PURE__ */ jsx("button", { disabled: offset + 100 >= total || loading, onClick: () => setOffset((n) => n + 100), children: "\u0414\u0430\u043B\u0435\u0435" })
      ] })
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/lib/assemblyProductDisplay.ts
function assemblyProductLabel(value, fallback) {
  const text = value.productDisplayText;
  return typeof text === "string" ? text : fallback;
}
function hasAssemblyProductDisplay(value) {
  return typeof value.productDisplayText === "string";
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/FboProgress.tsx
var time2 = (value) => value ? new Date(value).toLocaleString("ru-RU", { timeZone: "Europe/Moscow" }) : "\u2014";
function FboProgress({ plan, paused = false, accessToken }) {
  const [search, setSearch] = useState(""), [tab, setTab] = useState("all");
  const q = search.trim().toLocaleLowerCase("ru-RU");
  const lines = plan.lines.filter((l) => `${l.name} ${l.article ?? ""} ${l.size ?? ""} ${l.barcode}`.toLocaleLowerCase("ru-RU").includes(q)).filter((l) => tab === "remaining" ? l.remaining > 0 : tab === "picked" ? l.picked > 0 : tab === "packed" ? l.packed > 0 : true);
  const percentage = (value) => plan.needed ? Math.min(100, Math.round(value / plan.needed * 100)) : 0;
  const stats = plan.boxStatistics, remaining = Math.max(0, plan.needed - plan.picked);
  const hasPickingBreakdown = stats?.remainingPartialPickUnits !== void 0 && stats.remainingWholePickBoxes !== void 0 && stats.remainingWholePickUnits !== void 0;
  const unassigned = hasPickingBreakdown ? Math.max(0, remaining - stats.remainingPartialPickUnits - stats.remainingWholePickUnits) : 0;
  return /* @__PURE__ */ jsxs("section", { className: "fbo-progress", "aria-label": "\u041E\u043D\u043B\u0430\u0439\u043D-\u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 FBO", children: [
    /* @__PURE__ */ jsxs("p", { className: "inline-status", children: [
      "\u041E\u043D\u043B\u0430\u0439\u043D-\u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \xB7 ",
      paused ? "\u0410\u0432\u0442\u043E\u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0440\u0438\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E \u043D\u0430 \u0432\u0440\u0435\u043C\u044F \u0441\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0438\u043B\u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438" : "\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043A\u0430\u0436\u0434\u044B\u0435 5 \u0441\u0435\u043A\u0443\u043D\u0434",
      plan.observedAt ? ` \xB7 ${time2(plan.observedAt)} \u041C\u0421\u041A` : ""
    ] }),
    (plan.pendingPlacementQuantity ?? 0) > 0 && /* @__PURE__ */ jsxs("p", { role: "status", children: [
      "\u041F\u0440\u0438\u043D\u044F\u0442\u043E, \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u0438\u044F: ",
      plan.pendingPlacementQuantity,
      " \u0448\u0442."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "online-execution-metrics", children: [
      /* @__PURE__ */ jsxs("article", { children: [
        /* @__PURE__ */ jsx("span", { children: "\u041D\u0443\u0436\u043D\u043E" }),
        /* @__PURE__ */ jsx("strong", { children: plan.needed }),
        plan.boxStatistics && /* @__PURE__ */ jsxs("div", { className: "fbo-picking-breakdown", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            "\u0427\u0430\u0441\u0442\u0438\u0447\u043D\u044B\u0439 \u043E\u0442\u0431\u043E\u0440 \u2014 ",
            plan.boxStatistics.partialUnits,
            " \u0435\u0434."
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            "\u0426\u0435\u043B\u044B\u043C\u0438 \u043A\u043E\u0440\u043E\u0431\u0430\u043C\u0438 \u2014 ",
            plan.boxStatistics.wholeBoxes,
            " \u043A\u043E\u0440\u043E\u0431\u043E\u0432"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("article", { className: "is-done", children: [
        /* @__PURE__ */ jsx("span", { children: "\u041E\u0442\u043E\u0431\u0440\u0430\u043D\u043E" }),
        /* @__PURE__ */ jsx("strong", { children: plan.picked })
      ] }),
      /* @__PURE__ */ jsxs("article", { className: "is-done", children: [
        /* @__PURE__ */ jsx("span", { children: "\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E" }),
        /* @__PURE__ */ jsx("strong", { children: plan.packed })
      ] }),
      /* @__PURE__ */ jsxs("article", { className: "is-warning", children: [
        /* @__PURE__ */ jsx("span", { children: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043E\u0431\u0440\u0430\u0442\u044C" }),
        /* @__PURE__ */ jsx("strong", { children: remaining }),
        hasPickingBreakdown && /* @__PURE__ */ jsxs("div", { className: "fbo-picking-breakdown", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            "\u0427\u0430\u0441\u0442\u0438\u0447\u043D\u044B\u0439 \u043E\u0442\u0431\u043E\u0440 \u2014 ",
            stats.remainingPartialPickUnits,
            " \u0448\u0442."
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            "\u0426\u0435\u043B\u044B\u043C\u0438 \u043A\u043E\u0440\u043E\u0431\u0430\u043C\u0438 \u2014 ",
            stats.remainingWholePickBoxes,
            " \u043A\u043E\u0440. \xB7 ",
            stats.remainingWholePickUnits,
            " \u0448\u0442."
          ] }),
          unassigned > 0 && /* @__PURE__ */ jsxs("span", { children: [
            "\u0411\u0435\u0437 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0430 \u043E\u0442\u0431\u043E\u0440\u0430 \u2014 ",
            unassigned,
            " \u0448\u0442."
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "fbo-progress-bars", children: [["\u041E\u0442\u0431\u043E\u0440", plan.picked], ["\u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430", plan.packed]].map(([label, count]) => /* @__PURE__ */ jsxs("section", { className: "online-execution-progress", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("strong", { children: [
          percentage(Number(count)),
          "%"
        ] }),
        /* @__PURE__ */ jsxs("span", { children: [
          label,
          ": ",
          count,
          " \u0438\u0437 ",
          plan.needed
        ] })
      ] }),
      /* @__PURE__ */ jsx("meter", { "aria-label": String(label), min: 0, max: 100, value: percentage(Number(count)) }),
      plan.boxStatistics && /* @__PURE__ */ jsx("p", { className: "fbo-box-count", children: label === "\u041E\u0442\u0431\u043E\u0440" ? `\u041A\u043E\u0440\u043E\u0431\u043E\u0432-\u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u043E\u0432 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043E: ${plan.boxStatistics.pickedBoxes}` : `\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E \u043A\u043E\u0440\u043E\u0431\u043E\u0432: ${plan.boxStatistics.packedBoxes}` }),
      label === "\u041E\u0442\u0431\u043E\u0440" && stats?.pickedPartialUnits !== void 0 && stats.pickedWholeBoxes !== void 0 && stats.pickedWholeUnits !== void 0 && /* @__PURE__ */ jsxs("div", { className: "fbo-picking-breakdown", children: [
        /* @__PURE__ */ jsxs("span", { children: [
          "\u0427\u0430\u0441\u0442\u0438\u0447\u043D\u043E \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043E \u2014 ",
          stats.pickedPartialUnits,
          " \u0448\u0442."
        ] }),
        /* @__PURE__ */ jsxs("span", { children: [
          "\u0426\u0435\u043B\u044B\u043C\u0438 \u043A\u043E\u0440\u043E\u0431\u0430\u043C\u0438 \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043E \u2014 ",
          stats.pickedWholeBoxes,
          " \u043A\u043E\u0440. \xB7 ",
          stats.pickedWholeUnits,
          " \u0448\u0442."
        ] })
      ] }),
      label === "\u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430" && plan.boxStatistics?.remainingWholeBoxes !== void 0 && /* @__PURE__ */ jsxs("p", { className: "fbo-box-count", children: [
        "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u0442\u044C \u0446\u0435\u043B\u044B\u0445 \u043A\u043E\u0440\u043E\u0431\u043E\u0432: ",
        plan.boxStatistics.remainingWholeBoxes
      ] })
    ] }, label)) }),
    /* @__PURE__ */ jsxs("div", { className: "fbo-progress-filters", children: [
      /* @__PURE__ */ jsxs("label", { children: [
        "\u041F\u043E\u0438\u0441\u043A \u0442\u043E\u0432\u0430\u0440\u0430, \u0430\u0440\u0442\u0438\u043A\u0443\u043B\u0430 \u0438\u043B\u0438 \u0428\u041A",
        /* @__PURE__ */ jsx("input", { value: search, onChange: (e) => setSearch(e.target.value), placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435, \u0440\u0430\u0437\u043C\u0435\u0440, \u0448\u0442\u0440\u0438\u0445\u043A\u043E\u0434" })
      ] }),
      /* @__PURE__ */ jsx("div", { role: "group", "aria-label": "\u0424\u0438\u043B\u044C\u0442\u0440 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F", children: [["all", "\u0412\u0441\u0435 \u043F\u043E\u0437\u0438\u0446\u0438\u0438"], ["remaining", "\u041D\u0435 \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043E"], ["picked", "\u041E\u0442\u043E\u0431\u0440\u0430\u043D\u043E"], ["packed", "\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E"]].map(([value, label]) => /* @__PURE__ */ jsx("button", { className: "icon-text-button", "aria-pressed": tab === value, onClick: () => setTab(value), children: label }, value)) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "online-execution-table-wrap", children: /* @__PURE__ */ jsxs("table", { className: "online-execution-table", children: [
      /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { children: "\u0422\u043E\u0432\u0430\u0440" }),
        /* @__PURE__ */ jsx("th", { children: "\u0428\u041A" }),
        /* @__PURE__ */ jsx("th", { children: "\u041D\u0443\u0436\u043D\u043E" }),
        /* @__PURE__ */ jsx("th", { children: "\u041E\u0442\u043E\u0431\u0440\u0430\u043D\u043E" }),
        /* @__PURE__ */ jsx("th", { children: "\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E" }),
        /* @__PURE__ */ jsx("th", { children: "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C" }),
        /* @__PURE__ */ jsx("th", { children: "\u0413\u0434\u0435 \u043E\u0442\u0431\u0438\u0440\u0430\u0442\u044C" })
      ] }) }),
      /* @__PURE__ */ jsxs("tbody", { children: [
        lines.map((l) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsxs("td", { children: [
            /* @__PURE__ */ jsx("strong", { children: assemblyProductLabel(l, l.name) }),
            !hasAssemblyProductDisplay(l) && /* @__PURE__ */ jsxs(Fragment2, { children: [
              /* @__PURE__ */ jsx("br", {}),
              l.article,
              " \xB7 ",
              l.size
            ] })
          ] }),
          /* @__PURE__ */ jsx("td", { children: hasAssemblyProductDisplay(l) ? "\u2014" : l.barcode }),
          /* @__PURE__ */ jsx("td", { children: l.needed }),
          /* @__PURE__ */ jsx("td", { children: l.picked }),
          /* @__PURE__ */ jsx("td", { children: l.packed }),
          /* @__PURE__ */ jsx("td", { children: l.remaining }),
          /* @__PURE__ */ jsxs("td", { children: [
            l.remaining > 0 ? plan.route.filter((r) => r.tasks.some((t) => t.skuId === l.skuId)).map((r) => /* @__PURE__ */ jsxs("div", { children: [
              r.boxCode,
              " \xB7 ",
              r.pallet || "\u0411\u0435\u0437 \u043F\u0430\u043B\u043B\u0435\u0442\u0430",
              " \xB7 ",
              r.tasks.filter((t) => t.skuId === l.skuId).reduce((s, t) => s + t.quantity, 0),
              " \u0448\u0442."
            ] }, r.boxCode)) : "\u041E\u0442\u0431\u043E\u0440 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043D",
            (plan.pendingLocations ?? []).filter((r) => r.skuId === l.skuId).map((r) => /* @__PURE__ */ jsxs("div", { children: [
              "\u041A\u043E\u0440\u043E\u0431 ",
              r.boxCode,
              " \xB7 ",
              r.pallet || "\u041F\u0430\u043B\u043B\u0435\u0442-\u0441\u043E\u0440\u0442 \u043D\u0435 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D",
              r.zone ? ` \xB7 ${r.zone}` : "",
              " \xB7 ",
              r.quantity,
              " \u0448\u0442. \xB7 \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u0438\u044F"
            ] }, r.boxCode)),
            (l.pendingPlacementQuantity ?? 0) > 0 && /* @__PURE__ */ jsxs("div", { children: [
              "\u041F\u0440\u0438\u043D\u044F\u0442\u043E, \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u0438\u044F: ",
              l.pendingPlacementQuantity,
              " \u0448\u0442."
            ] }),
            l.remaining > 0 && !(l.pendingPlacementQuantity ?? 0) && !plan.route.some((r) => r.tasks.some((t) => t.skuId === l.skuId)) ? "\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0439 \u043A\u043E\u0440\u043E\u0431 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D" : null
          ] })
        ] }, l.id)),
        !lines.length && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 7, children: "\u041D\u0435\u0442 \u043F\u043E\u0437\u0438\u0446\u0438\u0439 \u043F\u043E \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C\u0443 \u0444\u0438\u043B\u044C\u0442\u0440\u0443." }) })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(FboHistory, { plan, accessToken })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/FboTwoStagePanel.tsx
function selectFboLocation(route, pallet, scan) {
  const same = (a, b) => a.trim().toUpperCase() === b.trim().toUpperCase();
  if (!pallet) {
    const match = route.find((r) => r.pallet && same(r.pallet, scan));
    if (match) return { pallet: match.pallet, source: "" };
  }
  const box = route.find((r) => same(r.boxCode, scan) && r.pallet === pallet);
  return box ? { pallet, source: box.boxCode } : null;
}
function FboTwoStagePanel({ initial, accessToken, userId, canWrite, onClose, embedded = false }) {
  const panel = useRef(null);
  const [plan, setPlan] = useState(initial), [code, setCode] = useState(""), [source, setSource] = useState(""), [target, setTarget] = useState(""), [barcode, setBarcode] = useState("");
  const [planned, setPlanned] = useState(null), [plannedKiz, setPlannedKiz] = useState("");
  const [pallet, setPallet] = useState("");
  const [direction, setDirection] = useState("");
  const [scanMode, setScanMode] = useState(false);
  const [adjusting, setAdjusting] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const storageKey = `fbo-pending:${userId}:${initial.requestId}`;
  const [busy, setBusy] = useState(false), [error, setError] = useState(""), [pending, setPending] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(storageKey) || "null");
    } catch {
      return null;
    }
  });
  const inFlight = useRef(false), field = useRef(null);
  const active = useRef(true), refreshRef = useRef(() => {
  });
  refreshRef.current = () => {
    if (!scanMode && !code && !barcode) void refresh();
  };
  useEffect(() => {
    active.current = true;
    const stop = define_import_meta_env_default.VITE_MENU_READS_ENABLED === "true" ? startVisiblePolling(() => refreshRef.current(), () => panel.current) : startFboPolling(() => refreshRef.current(), () => document.visibilityState === "visible");
    return () => {
      active.current = false;
      stop();
    };
  }, []);
  const sourceTask = plan.route.find((b) => b.boxCode === source);
  const title = plan.phase === "CONTROL" ? "\u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0432\u0441\u0435\u0445 \u043A\u043E\u0440\u043E\u0431\u043E\u0432 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0438" : plan.phase === "PACKING" ? "2. \u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0438" : "1. \u041E\u0442\u0431\u043E\u0440 \u0442\u043E\u0432\u0430\u0440\u0430";
  async function command(action, extra = {}) {
    if (inFlight.current || (!canWrite || adjusting)) return;
    const dto = pending ?? { action, operationId: crypto.randomUUID(), palletCode: pallet, direction: direction || void 0, ...extra };
    inFlight.current = true;
    setBusy(true);
    setError("");
    setPending(dto);
    try {
      localStorage.setItem(storageKey, JSON.stringify(dto));
      const next = await actFbo(accessToken, plan.requestId, dto);
      setPlan(next);
      localStorage.removeItem(storageKey);
      setPending(null);
      setBarcode("");
      setCode("");
      setPlanned(null);
      setPlannedKiz("");
      if (!next.route.some((r) => r.boxCode === source)) setSource("");
      if (!next.route.some((r) => r.pallet === pallet)) setPallet("");
      if (!next.boxes.some((b) => b.code === target && !b.closed) || next.phase !== "PACKING") setTarget("");
      if (dto.action === "OPEN_BOX") setTarget(dto.targetBoxCode ?? "");
      if (dto.action === "FINISH" && next.marketplace !== "OZON" && next.marketplace !== "LAMODA") void download();
    } catch (e) {
      setError(e instanceof Error ? e.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044E.");
      if (e.rejected) {
        localStorage.removeItem(storageKey);
        setPending(null);
      }
    } finally {
      inFlight.current = false;
      setBusy(false);
      setTimeout(() => field.current?.focus(), 0);
    }
  }
  async function scan(event) {
    event.preventDefault();
    const value = code.trim();
    if (!value || busy || pending) return;
    setCode("");
    if (plan.plannedPackingRequired && plan.phase === "PACKING") {
      if (planned) {
        if (value !== planned.targetBoxCode && value !== planned.cargoId) {
          setError(`\u0421\u043A\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u043A\u043E\u0440\u043E\u0431 ${planned.targetBoxCode}`);
          return;
        }
        await command("PACK_PRODUCT", { targetBoxCode: planned.targetBoxCode, direction: planned.direction, barcode, kiz: plannedKiz || void 0, packingUnitId: planned.packingUnitId });
        return;
      }
      const line2 = plan.lines.find((l) => (l.barcode === value || l.barcodes?.includes(value)) && l.picked > l.packed);
      if (!barcode) {
        if (!line2) {
          setError("\u0422\u043E\u0432\u0430\u0440 \u043D\u0435 \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438.");
          return;
        }
        setBarcode(value);
        if (line2.requiresKiz) {
          setError("");
          return;
        }
      }
      setBusy(true);
      setError("");
      try {
        const result = await resolvePlannedPacking(accessToken, plan.requestId, { barcode: barcode || value, ...barcode ? { kiz: value } : {} });
        setPlanned(result);
        setPlannedKiz(barcode ? value : "");
      } catch (e) {
        setError(String(e));
        setBarcode("");
      } finally {
        setBusy(false);
      }
      return;
    }
    if (plan.phase === "CONTROL") {
      await command("CONFIRM_BOX", { targetBoxCode: value });
      return;
    }
    if (plan.phase === "PICKING" && !source) {
      const selected = selectFboLocation(plan.route, pallet, value);
      if (!selected) {
        setError(pallet ? "\u041A\u043E\u0440\u043E\u0431 \u043D\u0435 \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0441\u043F\u0438\u0441\u043E\u043A \u043D\u0430 \u044D\u0442\u043E\u043C \u043F\u0430\u043B\u043B\u0435\u0442\u0435." : "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0442\u0441\u043A\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0430\u043B\u043B\u0435\u0442. \u041A\u043E\u0440\u043E\u0431 \u0431\u0435\u0437 \u043F\u0430\u043B\u043B\u0435\u0442\u0430 \u043C\u043E\u0436\u043D\u043E \u0441\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u0440\u0430\u0437\u0443.");
        return;
      }
      setPallet(selected.pallet);
      setSource(selected.source);
      setError("");
      return;
    }
    if (plan.phase === "PACKING" && !target) {
      if (plan.wholeBoxes.includes(value)) {
        await command("PACK_BOX", { sourceBoxCode: value });
        return;
      }
      await command("OPEN_BOX", { targetBoxCode: value });
      return;
    }
    if (barcode) {
      await command(plan.phase === "PICKING" ? "PICK_UNIT" : "PACK_UNIT", { sourceBoxCode: source, targetBoxCode: target, barcode, kiz: value });
      return;
    }
    const line = plan.lines.find((l) => (l.barcode === value || l.barcodes?.includes(value)) && (plan.phase === "PICKING" ? l.remaining > 0 : l.picked > l.packed));
    if (!line) {
      setError("\u042D\u0442\u043E\u0442 \u0428\u041A \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u043D\u0430 \u0442\u0435\u043A\u0443\u0449\u0435\u043C \u044D\u0442\u0430\u043F\u0435.");
      return;
    }
    if (line.requiresKiz) {
      setBarcode(value);
      setError("");
    } else await command(plan.phase === "PICKING" ? "PICK_UNIT" : "PACK_UNIT", { sourceBoxCode: source, targetBoxCode: target, barcode: value });
  }
  async function refresh() {
    if (inFlight.current) return;
    inFlight.current = true;
    setRefreshing(true);
    setBusy(true);
    try {
      const next = await fetchFboPlan(accessToken, plan.requestId);
      if (!active.current) return;
      setPlan(next);
      if (!next.route.some((r) => r.boxCode === source && r.pallet === pallet)) {
        setSource("");
        setBarcode("");
      }
      if (!next.route.some((r) => r.pallet === pallet)) setPallet("");
      if (!next.boxes.some((b) => b.code === target && !b.closed)) setTarget("");
      setError("");
    } catch (e) {
      if (active.current) setError(`\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0443: ${String(e)}`);
    } finally {
      inFlight.current = false;
      if (active.current) {
        setBusy(false);
        setRefreshing(false);
      }
    }
  }
  async function download() {
    try {
      const file = await downloadFboWbFile(accessToken, plan.requestId);
      const a = document.createElement("a");
      const url = URL.createObjectURL(file);
      a.href = url;
      a.download = "wb-packages.xlsx";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    } catch (e) {
      setError(String(e));
    }
  }
  const hint = plan.plannedPackingRequired && plan.phase === "PACKING" ? planned ? `\u0428\u041A \u043A\u043E\u0440\u043E\u0431\u0430 ${planned.targetBoxCode}` : barcode ? "\u041A\u0418\u0417 \u0442\u043E\u0432\u0430\u0440\u0430" : "\u0428\u041A \u0442\u043E\u0432\u0430\u0440\u0430" : plan.phase === "CONTROL" ? "\u0428\u041A \u043A\u043E\u0440\u043E\u0431\u0430 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0438" : plan.phase === "PICKING" && !source ? pallet ? "\u0428\u041A \u043A\u043E\u0440\u043E\u0431\u0430 \u043D\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C \u043F\u0430\u043B\u043B\u0435\u0442\u0435" : "\u0428\u041A \u043F\u0430\u043B\u043B\u0435\u0442\u0430 \u0438\u043B\u0438 \u043A\u043E\u0440\u043E\u0431\u0430 \u0431\u0435\u0437 \u043F\u0430\u043B\u043B\u0435\u0442\u0430" : plan.phase === "PACKING" && !target ? "\u0428\u041A \u043A\u043E\u0440\u043E\u0431\u0430 \u0434\u043B\u044F \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438 \u0438\u043B\u0438 \u0446\u0435\u043B\u043E\u0433\u043E \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u043A\u043E\u0440\u043E\u0431\u0430" : barcode ? "\u041A\u0418\u0417 \u0442\u043E\u0432\u0430\u0440\u0430" : "\u0428\u041A \u0442\u043E\u0432\u0430\u0440\u0430";
  return /* @__PURE__ */ jsx("div", { ref: panel, className: embedded ? "fbo-inline-execution" : "online-execution-modal", role: embedded ? "region" : "dialog", "aria-modal": embedded ? void 0 : true, "aria-label": "\u0414\u0432\u0443\u0445\u044D\u0442\u0430\u043F\u043D\u0430\u044F \u0441\u0431\u043E\u0440\u043A\u0430 \u0424\u0411\u041E", children: /* @__PURE__ */ jsxs("section", { className: embedded ? "fbo-inline-execution__panel" : "online-execution-modal__panel", style: embedded ? { display: "block", width: "100%", minWidth: 0 } : { display: "block", maxWidth: 1e3, width: "95vw", maxHeight: "92vh", overflow: "auto", padding: 24 }, children: [
    /* @__PURE__ */ jsxs("header", { className: embedded ? "fbo-inline-execution__header" : "online-execution-modal__header", style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }, children: [
      /* @__PURE__ */ jsxs("h2", { children: [
        "FBO ",
        plan.marketplace === "LAMODA" ? "Lamoda" : plan.marketplace === "OZON" ? "Ozon" : "WB",
        " ",
        plan.number ? `\xB7 \u2116${String(plan.number).padStart(6, "0")}` : "",
        " \xB7 ",
        plan.title
      ] }),
      /* @__PURE__ */ jsxs("div", { className: embedded ? "fbo-inline-execution__actions" : "online-execution-modal__actions", children: [
        define_import_meta_env_default.VITE_MARKETPLACE_WORKSPACES_ENABLED === "true" && (!plan.marketplace || plan.marketplace === "WILDBERRIES") && /* @__PURE__ */ jsx(WbSupplyWindow, { requestId: plan.requestId, accessToken }, plan.requestId),
        /* @__PURE__ */ jsx("button", { type: "button", className: "icon-button", "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C", title: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C", disabled: busy && !refreshing, onClick: onClose, children: "\xD7" })
      ] })
    ] }),
    plan.marketplace === "OZON" && canWrite && /* @__PURE__ */ jsx(OzonStockAdjustment, { requestId: plan.requestId, accessToken, disabled: busy || !!pending, onLockChange: setAdjusting, onChanged: () => void refresh() }),
    /* @__PURE__ */ jsx(FboProgress, { plan, accessToken, paused: scanMode || !!pending }),
    plan.marketplace === "LAMODA" && /* @__PURE__ */ jsx(LamodaFboRelabel, { plan, accessToken, disabled: !canWrite || busy || !!pending || adjusting, command, refresh }),
    !!plan.directions?.length && /* @__PURE__ */ jsxs("section", { "aria-label": "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0441\u0431\u043E\u0440\u043A\u0438", children: [
      /* @__PURE__ */ jsx("h3", { children: "\u0415\u0434\u0438\u043D\u0430\u044F \u0441\u0431\u043E\u0440\u043A\u0430 \xB7 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F" }),
      plan.directions.map((d) => /* @__PURE__ */ jsxs("details", { children: [
        /* @__PURE__ */ jsxs("summary", { children: [
          d.name,
          ": \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E ",
          d.packed,
          " \u0438\u0437 ",
          d.needed
        ] }),
        /* @__PURE__ */ jsx("ul", { children: d.items.map((i) => /* @__PURE__ */ jsxs("li", { children: [
          plan.lines.find((l) => l.skuId === i.skuId)?.name,
          " \xB7 ",
          i.barcode,
          ": ",
          i.packed,
          " \u0438\u0437 ",
          i.quantity
        ] }, i.skuId)) })
      ] }, d.name)),
      !plan.plannedPackingRequired && plan.phase === "PACKING" && /* @__PURE__ */ jsxs("label", { children: [
        "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043A\u043E\u0440\u043E\u0431\u0430",
        /* @__PURE__ */ jsxs("select", { disabled: busy || adjusting || !!pending || !!target, value: target ? plan.boxes.find((b) => b.code === target)?.direction ?? direction : direction, onChange: (e) => setDirection(e.target.value), children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435" }),
          plan.directions.map((d) => /* @__PURE__ */ jsxs("option", { value: d.name, children: [
            d.name,
            " \xB7 ",
            d.packed,
            "/",
            d.needed
          ] }, d.name))
        ] })
      ] })
    ] }),
    plan.compositionChanged && /* @__PURE__ */ jsx("p", { role: "alert", children: "\u0421\u043E\u0441\u0442\u0430\u0432 \u0437\u0430\u044F\u0432\u043A\u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F. \u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0441\u0432\u0435\u0440\u043A\u0430." }),
    plan.shortage > 0 && /* @__PURE__ */ jsxs("p", { role: "alert", children: [
      "\u041D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u0447\u043D\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u0433\u043E \u043E\u0441\u0442\u0430\u0442\u043A\u0430: ",
      plan.shortage,
      " \u0435\u0434."
    ] }),
    (plan.pendingPlacementQuantity ?? 0) > 0 && /* @__PURE__ */ jsxs("p", { role: "status", children: [
      "\u041F\u0440\u0438\u043D\u044F\u0442\u043E, \u043E\u0436\u0438\u0434\u0430\u0435\u0442 \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u0438\u044F: ",
      plan.pendingPlacementQuantity,
      " \u0448\u0442. \u0420\u0430\u0437\u043C\u0435\u0441\u0442\u0438\u0442\u0435 \u043A\u043E\u0440\u043E\u0431\u0430 \u043D\u0430 \u043F\u0430\u043B\u0435\u0442-\u0441\u043E\u0440\u0442\u0435 \u0438 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u043C\u0430\u0440\u0448\u0440\u0443\u0442."
    ] }),
    /* @__PURE__ */ jsx("h3", { children: plan.phase === "COMPLETED" ? "\u041F\u043E\u0441\u0442\u0430\u0432\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u0430" : title }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
    pending && !busy && /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, onClick: () => void command(pending.action), children: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441" }),
    plan.phase === "NOT_STARTED" && /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending || (!canWrite || adjusting), onClick: () => void command("START"), children: "\u041D\u0430\u0447\u0430\u0442\u044C \u043E\u0442\u0431\u043E\u0440" }),
    canWrite && ["PICKING", "PACKING", "CONTROL"].includes(plan.phase) && /* @__PURE__ */ jsxs("details", { onToggle: (e) => setScanMode(e.currentTarget.open), children: [
      /* @__PURE__ */ jsx("summary", { children: "\u0421\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u0412\u041C\u0421" }),
      /* @__PURE__ */ jsxs("form", { onSubmit: scan, style: { display: "flex", gap: 12, alignItems: "end", flexWrap: "wrap", margin: "20px 0" }, children: [
        /* @__PURE__ */ jsxs("label", { style: { display: "grid", gap: 8, flex: "1 1 240px" }, children: [
          hint,
          /* @__PURE__ */ jsx("input", { ref: field, value: code, onChange: (e) => setCode(e.target.value), disabled: busy || adjusting || !!pending, style: { minHeight: 44, padding: 10, border: "1px solid var(--line)", borderRadius: 6 } })
        ] }),
        /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending, children: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u0441\u043A\u0430\u043D" })
      ] })
    ] }),
    sourceTask && plan.phase === "PICKING" && /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        sourceTask.boxCode,
        " \xB7 ",
        sourceTask.pallet,
        " \xB7 ",
        sourceTask.zone
      ] }),
      sourceTask.tasks.map((t) => /* @__PURE__ */ jsxs("p", { children: [
        "\u041E\u0442\u0431\u0435\u0440\u0438\u0442\u0435 ",
        t.quantity,
        " \u0435\u0434. \xB7 ",
        assemblyProductLabel(t, `${t.name} \xB7 ${t.barcode}`)
      ] }, t.skuId)),
      sourceTask.recount && /* @__PURE__ */ jsx("p", { role: "alert", children: "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0438 \u041A\u0418\u0417 \u0440\u0430\u0441\u0445\u043E\u0434\u044F\u0442\u0441\u044F. \u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u043A\u043E\u0440\u043E\u0431\u0430." }),
      !plan.plannedPackingRequired && sourceTask.wholeBox && /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending || (!canWrite || adjusting), onClick: () => void command("PICK_BOX", { sourceBoxCode: source }), children: "\u041A\u043E\u0440\u043E\u0431 \u0437\u0430\u0431\u0440\u0430\u043D \u0446\u0435\u043B\u0438\u043A\u043E\u043C" }),
      /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending, onClick: () => {
        setSource("");
        setBarcode("");
      }, children: "\u0414\u0440\u0443\u0433\u043E\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0439 \u043A\u043E\u0440\u043E\u0431" })
    ] }),
    plan.phase === "PICKING" && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043E\u0431\u0440\u0430\u0442\u044C: ",
        plan.needed - plan.picked
      ] }),
      /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending || plan.picked !== plan.needed || (!canWrite || adjusting), onClick: () => void command("FINISH_PICK"), children: "\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0435" }),
      !!pallet && /* @__PURE__ */ jsxs("p", { children: [
        "\u041F\u0430\u043B\u043B\u0435\u0442 ",
        pallet,
        " ",
        /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending, onClick: () => {
          setPallet("");
          setSource("");
          setBarcode("");
        }, children: "\u0414\u0440\u0443\u0433\u043E\u0439 \u043F\u0430\u043B\u043B\u0435\u0442" })
      ] }),
      !pallet && /* @__PURE__ */ jsx("ul", { children: [...new Set(plan.route.map((r) => r.pallet).filter(Boolean))].map((p) => /* @__PURE__ */ jsxs("li", { children: [
        p,
        " \xB7 \u041D\u0443\u0436\u043D\u044B\u0445 \u043A\u043E\u0440\u043E\u0431\u043E\u0432: ",
        plan.route.filter((r) => r.pallet === p).length
      ] }, p)) }),
      /* @__PURE__ */ jsx("div", { className: "online-execution-table-wrap", children: /* @__PURE__ */ jsxs("table", { className: "online-execution-table", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { children: "\u041F\u0430\u043B\u043B\u0435\u0442 / \u0437\u043E\u043D\u0430" }),
          /* @__PURE__ */ jsx("th", { children: "\u041D\u0443\u0436\u043D\u044B\u0439 \u043A\u043E\u0440\u043E\u0431" }),
          /* @__PURE__ */ jsx("th", { children: "\u041E\u0442\u043E\u0431\u0440\u0430\u0442\u044C" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: plan.route.filter((r) => r.pallet === pallet).map((r) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsxs("td", { children: [
            r.pallet || "\u0411\u0435\u0437 \u043F\u0430\u043B\u043B\u0435\u0442\u0430",
            " \xB7 ",
            r.zone
          ] }),
          /* @__PURE__ */ jsx("td", { children: r.boxCode }),
          /* @__PURE__ */ jsx("td", { children: r.tasks.map((t) => `${assemblyProductLabel(t, t.name)}: ${t.quantity}`).join("; ") })
        ] }, r.boxCode)) })
      ] }) })
    ] }),
    plan.plannedPackingRequired && plan.phase === "PACKING" && /* @__PURE__ */ jsxs("section", { "aria-label": "\u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u043F\u043E \u043F\u043B\u0430\u043D\u0443", children: [
      /* @__PURE__ */ jsx("h3", { children: "\u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u043F\u043E \u043F\u043B\u0430\u043D\u0443 Ozon" }),
      /* @__PURE__ */ jsx("p", { children: "\u0421\u043A\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u0442\u043E\u0432\u0430\u0440, \u0437\u0430\u0442\u0435\u043C \u041A\u0418\u0417 \u0438 \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0439 \u043A\u043E\u0440\u043E\u0431. \u041A\u0430\u0436\u0434\u043E\u0435 \u0432\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u0442\u0441\u044F \u043F\u043E \u0441\u043E\u0441\u0442\u0430\u0432\u0443 Ozon." }),
      planned && /* @__PURE__ */ jsxs("p", { role: "status", children: [
        /* @__PURE__ */ jsxs("strong", { children: [
          planned.direction,
          " \xB7 ",
          planned.targetBoxCode
        ] }),
        " \xB7 Ozon ",
        planned.cargoId,
        " \xB7 \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ",
        planned.remaining,
        " \u0448\u0442."
      ] }),
      barcode && /* @__PURE__ */ jsx("button", { disabled: busy || !!pending, onClick: () => {
        setBarcode("");
        setPlanned(null);
        setPlannedKiz("");
      }, children: "\u041E\u0442\u043B\u043E\u0436\u0438\u0442\u044C \u0442\u043E\u0432\u0430\u0440" }),
      plan.boxes.filter((b) => !b.closed).map((b) => /* @__PURE__ */ jsxs("button", { disabled: busy || !!pending || !!barcode, onClick: () => void command("CLOSE_BOX", { targetBoxCode: b.code }), children: [
        "\u0417\u0430\u043A\u0440\u044B\u0442\u044C ",
        b.code
      ] }, b.code))
    ] }),
    plan.phase === "PACKING" && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        plan.plannedPackingRequired ? "\u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u043F\u043E \u043F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u043C\u0443 \u043F\u043B\u0430\u043D\u0443" : target ? `\u041E\u0442\u043A\u0440\u044B\u0442 \u043A\u043E\u0440\u043E\u0431 ${target}` : "\u041E\u0442\u0441\u043A\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u043A\u043E\u0440\u043E\u0431 \u0434\u043B\u044F \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438",
        " \xB7 \u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u0432\u043B\u043E\u0436\u0438\u0442\u044C ",
        plan.needed - plan.packed
      ] }),
      !!target && /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending || (!canWrite || adjusting), onClick: () => void command("CLOSE_BOX", { targetBoxCode: target }), children: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043A\u043E\u0440\u043E\u0431" }),
      !!target && plan.boxes.some((b) => b.code === target && !b.quantity && !b.closed) && /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending || (!canWrite || adjusting), onClick: () => void command("CANCEL_EMPTY_BOX", { targetBoxCode: target }), children: "\u041E\u0442\u043B\u043E\u0436\u0438\u0442\u044C \u043F\u0443\u0441\u0442\u043E\u0439 \u043A\u043E\u0440\u043E\u0431" }),
      plan.wholeBoxes.length > 0 && /* @__PURE__ */ jsxs("p", { children: [
        "\u0426\u0435\u043B\u044B\u0435 \u043A\u043E\u0440\u043E\u0431\u0430 \u043A \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0438\u044E: ",
        plan.wholeBoxes.join(", ")
      ] }),
      /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending || plan.packed !== plan.needed || plan.boxes.some((b) => !b.closed) || (!canWrite || adjusting), onClick: () => void command("SORTED"), children: "\u041A\u043E\u0440\u043E\u0431\u0430 \u0440\u0430\u0437\u043E\u0431\u0440\u0430\u043D\u044B" })
    ] }),
    ["PACKING", "CONTROL", "COMPLETED"].includes(plan.phase) && /* @__PURE__ */ jsx("ul", { children: plan.boxes.map((b) => /* @__PURE__ */ jsxs("li", { children: [
      b.code,
      " ",
      b.direction ? `\xB7 ${b.direction}` : "",
      " \xB7 ",
      b.quantity,
      " \u0435\u0434. \xB7 ",
      b.confirmed ? "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D" : b.closed ? "\u0417\u0430\u043A\u0440\u044B\u0442" : "\u041E\u0442\u043A\u0440\u044B\u0442"
    ] }, b.code)) }),
    plan.phase === "CONTROL" && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E \u043A\u043E\u0440\u043E\u0431\u043E\u0432 ",
        plan.boxes.filter((b) => b.confirmed).length,
        " \u0438\u0437 ",
        plan.boxes.length
      ] }),
      /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy || adjusting || !!pending || plan.boxes.some((b) => !b.confirmed) || (!canWrite || adjusting), onClick: () => void command("FINISH"), children: plan.marketplace === "OZON" || plan.marketplace === "LAMODA" ? "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0439" : "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u0438 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0444\u0430\u0439\u043B WB" })
    ] }),
    plan.phase === "COMPLETED" && plan.marketplace !== "OZON" && plan.marketplace !== "LAMODA" && /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, onClick: () => void download(), children: "\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0444\u0430\u0439\u043B WB" }),
    /* @__PURE__ */ jsxs("p", { children: [
      /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy, onClick: () => void refresh(), children: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C" }),
      " ",
      /* @__PURE__ */ jsx("button", { className: "icon-text-button", style: { minHeight: 42, margin: 4, padding: "8px 14px" }, disabled: busy && !refreshing, onClick: onClose, children: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C" })
    ] })
  ] }) });
}

// work/fulfillment-analytics/wms/apps/web/src/components/ozon-fbo/OzonPackingPlan.tsx
function OzonPackingPlan({ data, busy, action }) {
  const [rows, setRows] = useState(null), [confirmed, setConfirmed] = useState(false), [replaceEmpty, setReplaceEmpty] = useState(false), [error, setError] = useState("");
  const plan = data.link?.packingPlan;
  if (!data.plannedPackingSupported && !plan) return null;
  function edit() {
    const existing = plan?.boxes.flatMap((b) => b.items.map((i) => ({ ...i, direction: b.direction, boxCode: b.boxCode })));
    setRows(existing ?? data.directions.flatMap((d, index) => d.items.map((i) => ({ ...i, direction: d.name, zone: data.link?.supplies.find((s) => s.id === data.link?.mapping[d.name])?.items.find((v) => v.barcode === i.barcode)?.placementZone ?? "", boxCode: `FFL_OZ_${data.requestId.slice(0, 8)}_${String(index + 1).padStart(3, "0")}` }))));
  }
  async function save() {
    if (!rows) return;
    setError("");
    const boxes = [];
    for (const row of rows) {
      if (!row.boxCode.trim() || !Number.isSafeInteger(row.quantity) || row.quantity <= 0) {
        setError("\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0428\u041A \u043A\u043E\u0440\u043E\u0431\u0430 \u0438 \u0446\u0435\u043B\u043E\u0435 \u043F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u0432 \u043A\u0430\u0436\u0434\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0435.");
        return;
      }
      let box = boxes.find((b) => b.boxCode === row.boxCode.trim());
      if (box && box.direction !== row.direction) {
        setError("\u041E\u0434\u0438\u043D \u043A\u043E\u0440\u043E\u0431 \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u043F\u0440\u0438\u043D\u0430\u0434\u043B\u0435\u0436\u0430\u0442\u044C \u0440\u0430\u0437\u043D\u044B\u043C \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F\u043C.");
        return;
      }
      if (!box) {
        box = { key: crypto.randomUUID(), boxCode: row.boxCode.trim(), direction: row.direction, supplyId: data.link.mapping[row.direction], items: [] };
        boxes.push(box);
      }
      box.items.push({ skuId: row.skuId, barcode: row.barcode, quantity: row.quantity, zone: row.zone });
    }
    await action("packing-plan", { confirm: true, boxes });
  }
  return /* @__PURE__ */ jsxs("section", { "aria-label": "\u041F\u0440\u0435\u0434\u0432\u0430\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u043B\u0430\u043D \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442", children: [
    /* @__PURE__ */ jsx("h3", { children: "\u0423\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u043F\u043E \u043F\u043B\u0430\u043D\u0443 Ozon" }),
    /* @__PURE__ */ jsx("p", { children: "\u0420\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u0435 \u0442\u043E\u0432\u0430\u0440\u044B \u043F\u043E \u043A\u043E\u0440\u043E\u0431\u0430\u043C \u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0441\u043E\u0441\u0442\u0430\u0432 \u0437\u0430\u0440\u0430\u043D\u0435\u0435. \u041F\u0440\u0438 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0435 \u0422\u0421\u0414 \u0443\u043A\u0430\u0436\u0435\u0442 \u043D\u0443\u0436\u043D\u044B\u0439 \u043A\u043E\u0440\u043E\u0431 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442 \u043A\u0430\u0436\u0434\u043E\u0435 \u0432\u043B\u043E\u0436\u0435\u043D\u0438\u0435. \u041F\u043B\u0430\u043D \u043D\u0435 \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442, \u0447\u0442\u043E \u0442\u043E\u0432\u0430\u0440 \u0443\u0436\u0435 \u0441\u043E\u0431\u0440\u0430\u043D." }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
    plan && /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "\u0412\u0435\u0440\u0441\u0438\u044F ",
        plan.version,
        " \xB7 ",
        plan.state === "ACTIVE" ? "\u0421\u043E\u0441\u0442\u0430\u0432 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D Ozon" : plan.state === "DRAFT" ? "\u0427\u0435\u0440\u043D\u043E\u0432\u0438\u043A" : "\u041E\u0436\u0438\u0434\u0430\u0435\u0442\u0441\u044F \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 Ozon"
      ] }),
      /* @__PURE__ */ jsxs("table", { children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { children: "\u041A\u043E\u0440\u043E\u0431" }),
          /* @__PURE__ */ jsx("th", { children: "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435" }),
          /* @__PURE__ */ jsx("th", { children: "\u0413\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u043E Ozon" }),
          /* @__PURE__ */ jsx("th", { children: "\u0421\u043E\u0441\u0442\u0430\u0432" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: plan.boxes.map((b) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("td", { children: b.boxCode }),
          /* @__PURE__ */ jsx("td", { children: b.direction }),
          /* @__PURE__ */ jsx("td", { children: b.cargoId ?? "\u041E\u0436\u0438\u0434\u0430\u0435\u0442\u0441\u044F" }),
          /* @__PURE__ */ jsx("td", { children: b.items.map((i) => /* @__PURE__ */ jsxs("div", { children: [
            i.barcode,
            " \xB7 ",
            i.quantity,
            " \u0448\u0442. \xB7 ",
            i.zone
          ] }, i.skuId)) })
        ] }, b.key)) })
      ] })
    ] }),
    !data.link?.frozenHash && /* @__PURE__ */ jsx("button", { disabled: busy || data.differences.length > 0, onClick: edit, children: plan ? "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A" : "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u044C \u043F\u043B\u0430\u043D \u043A\u043E\u0440\u043E\u0431\u043E\u0432" }),
    rows && !data.link?.frozenHash && /* @__PURE__ */ jsxs("fieldset", { disabled: busy, children: [
      /* @__PURE__ */ jsx("legend", { children: "\u0421\u043E\u0441\u0442\u0430\u0432 \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u043A\u043E\u0440\u043E\u0431\u0430" }),
      /* @__PURE__ */ jsx("p", { children: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C \u043A\u043E\u0440\u043E\u0431\u043E\u0432. SORT \u0438 NON_SORT \u0440\u0430\u0437\u043C\u0435\u0449\u0430\u0439\u0442\u0435 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E. \u041F\u0440\u0438 \u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0438 SKU \u043D\u0430 \u0434\u0432\u0430 \u043A\u043E\u0440\u043E\u0431\u0430 \u0440\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u0435 \u0435\u0433\u043E \u043E\u0431\u0449\u0435\u0435 \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u043C\u0435\u0436\u0434\u0443 \u0441\u0442\u0440\u043E\u043A\u0430\u043C\u0438." }),
      /* @__PURE__ */ jsxs("table", { children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { children: "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 / \u0442\u043E\u0432\u0430\u0440" }),
          /* @__PURE__ */ jsx("th", { children: "\u0417\u043E\u043D\u0430" }),
          /* @__PURE__ */ jsx("th", { children: "\u0428\u041A \u043A\u043E\u0440\u043E\u0431\u0430 FFL" }),
          /* @__PURE__ */ jsx("th", { children: "\u0428\u0442\u0443\u043A" }),
          /* @__PURE__ */ jsx("th", { children: "\u0420\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0435" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: rows.map((r, index) => /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsxs("td", { children: [
            r.direction,
            /* @__PURE__ */ jsx("br", {}),
            r.barcode
          ] }),
          /* @__PURE__ */ jsx("td", { children: r.zone || "\u041D\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0445 Ozon" }),
          /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("input", { "aria-label": `\u041A\u043E\u0440\u043E\u0431 \u0434\u043B\u044F ${r.barcode}`, value: r.boxCode, onChange: (e) => setRows(rows.map((x, j) => j === index ? { ...x, boxCode: e.target.value } : x)) }) }),
          /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("input", { "aria-label": `\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E ${r.barcode}`, type: "number", min: "1", step: "1", value: r.quantity, onChange: (e) => setRows(rows.map((x, j) => j === index ? { ...x, quantity: Number(e.target.value) } : x)) }) }),
          /* @__PURE__ */ jsxs("td", { children: [
            /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setRows([...rows, { ...r, quantity: 1, boxCode: "" }]), children: "\u0415\u0449\u0451 \u043A\u043E\u0440\u043E\u0431" }),
            /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setRows(rows.filter((_, j) => j !== index)), children: "\u0423\u0431\u0440\u0430\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443" })
          ] })
        ] }, index)) })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", onClick: () => void save(), children: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A" })
    ] }),
    plan?.state === "DRAFT" && /* @__PURE__ */ jsxs("fieldset", { disabled: busy, children: [
      /* @__PURE__ */ jsx("legend", { children: "\u041F\u0435\u0440\u0435\u0434\u0430\u0447\u0430 \u0441\u043E\u0441\u0442\u0430\u0432\u0430" }),
      /* @__PURE__ */ jsxs("label", { children: [
        /* @__PURE__ */ jsx("input", { type: "checkbox", checked: confirmed, onChange: (e) => setConfirmed(e.target.checked) }),
        "\u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u044B \u0442\u043E\u0432\u0430\u0440\u044B, \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u0430 \u0438 \u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C \u043A\u043E\u0440\u043E\u0431\u043E\u0432"
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        /* @__PURE__ */ jsx("input", { type: "checkbox", checked: replaceEmpty, onChange: (e) => setReplaceEmpty(e.target.checked) }),
        "\u0420\u0430\u0437\u0440\u0435\u0448\u0430\u044E \u0437\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u043F\u0443\u0441\u0442\u044B\u0435 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u0430. \u041F\u043E\u0441\u043B\u0435 \u0437\u0430\u043C\u0435\u043D\u044B \u0440\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u0430\u044E \u043D\u043E\u0432\u044B\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438"
      ] }),
      /* @__PURE__ */ jsx("button", { disabled: !confirmed, onClick: () => void action("packing-plan/upload", { confirm: true, replaceEmpty }), children: "\u041F\u0435\u0440\u0435\u0434\u0430\u0442\u044C \u043F\u043B\u0430\u043D \u0432 Ozon" })
    ] }),
    plan && plan.state !== "DRAFT" && plan.state !== "ACTIVE" && /* @__PURE__ */ jsx("p", { role: "status", children: "\u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438\xBB. \u0414\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u043D\u043E\u0433\u043E \u0441\u043E\u0441\u0442\u0430\u0432\u0430 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430; \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F." })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/components/ozon-fbo/OzonEditCountdown.tsx
function deadlineDisplay(deadline, now) {
  const at = deadline ? Date.parse(deadline) : NaN;
  if (!Number.isFinite(at)) return { tone: "unknown", text: "\u0414\u0435\u0434\u043B\u0430\u0439\u043D \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043D \u2014 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u0432\u0435\u0440\u043A\u0443 \u0441 Ozon" };
  const remaining = at - now;
  if (remaining <= 0) return { tone: "expired", text: "\u0421\u0440\u043E\u043A \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0438\u0441\u0442\u0451\u043A" };
  const minutes = Math.ceil(remaining / 6e4), days = Math.floor(minutes / 1440), hours = Math.floor(minutes % 1440 / 60), mins = minutes % 60;
  return { tone: remaining <= 2 * 36e5 ? "urgent" : remaining <= 24 * 36e5 ? "warning" : "normal", text: `\u0414\u043E \u0434\u0435\u0434\u043B\u0430\u0439\u043D\u0430: ${days ? days + " \u0434. " : ""}${hours} \u0447. ${mins} \u043C\u0438\u043D.` };
}
function OzonEditCountdown({ orders, enabled }) {
  const [now, setNow] = useState(Date.now);
  const visible = enabled ?? (typeof window !== "undefined" && ["wms.logoff.pro", "localhost", "127.0.0.1"].includes(window.location.hostname));
  useEffect(() => {
    if (!visible) return;
    const tick = () => setNow(Date.now());
    const timer = setInterval(tick, 15e3);
    window.addEventListener("focus", tick);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", tick);
    };
  }, [visible]);
  if (!visible) return null;
  const list = orders?.length ? orders : [{ orderId: "unknown", orderNumber: "", editDeadlineAt: null }];
  return /* @__PURE__ */ jsx("span", { className: "ozfbo-edit-deadlines", "aria-label": "\u0414\u0435\u0434\u043B\u0430\u0439\u043D \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F Ozon", children: list.map((o) => {
    const d = deadlineDisplay(o.editDeadlineAt, now);
    const stale = o.checkedAt && now - Date.parse(o.checkedAt) > 15 * 6e4;
    return /* @__PURE__ */ jsxs("span", { className: "ozfbo-edit-deadline is-" + d.tone, children: [
      list.length > 1 && /* @__PURE__ */ jsxs("strong", { children: [
        "Ozon \u2116",
        o.orderNumber
      ] }),
      /* @__PURE__ */ jsx("strong", { children: d.text }),
      o.editDeadlineAt && Number.isFinite(Date.parse(o.editDeadlineAt)) && /* @__PURE__ */ jsxs("small", { children: [
        "\u0414\u043E ",
        new Date(o.editDeadlineAt).toLocaleString("ru-RU", { timeZone: "Europe/Moscow" }),
        " \u041C\u0421\u041A"
      ] }),
      stale && /* @__PURE__ */ jsx("small", { children: "\u0421\u0440\u043E\u043A \u043F\u043E\u043B\u0443\u0447\u0435\u043D \u0440\u0430\u043D\u0435\u0435. \u041F\u043E\u0441\u043B\u0435 \u043F\u0435\u0440\u0435\u043D\u043E\u0441\u0430 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u0432\u0435\u0440\u043A\u0443 \u0441 Ozon." })
    ] }, o.orderId);
  }) });
}

// work/fulfillment-analytics/wms/apps/web/src/lib/ozonAllLabels.ts
async function prepareOzonAllLabels(manifest, stationId, part, recheck, progress) {
  const pages = [];
  let widthMm = 0, heightMm = 0;
  for (const supply of manifest.supplies) {
    progress(`\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430: ${supply.name} \xB7 ${pages.length} \u0438\u0437 ${manifest.total}`);
    const next = await part(supply.id);
    if (next.fingerprint !== manifest.fingerprint || next.clientId !== manifest.clientId) throw new Error("\u0421\u043E\u0441\u0442\u0430\u0432 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u044C\u0442\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438 \u0437\u0430\u043D\u043E\u0432\u043E.");
    if (next.pages.length !== supply.cargoIds.length || new Set(next.pages.map((p) => p.value)).size !== supply.cargoIds.length || next.pages.some((p) => !supply.cargoIds.includes(p.value))) throw new Error("\u041A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043D\u0435\u043F\u043E\u043B\u043D\u044B\u0439. \u041F\u0435\u0447\u0430\u0442\u044C \u043D\u0435 \u043D\u0430\u0447\u0430\u0442\u0430.");
    if (widthMm && (widthMm !== next.widthMm || heightMm !== next.heightMm)) throw new Error("\u0412 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F\u0445 \u0440\u0430\u0437\u043D\u044B\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u044B \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A.");
    widthMm = next.widthMm;
    heightMm = next.heightMm;
    pages.push(...next.pages);
  }
  if (!pages.length || pages.length !== manifest.total || new Set(pages.map((p) => p.value)).size !== pages.length) throw new Error("\u041A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A \u043D\u0435\u043F\u043E\u043B\u043D\u044B\u0439. \u041F\u0435\u0447\u0430\u0442\u044C \u043D\u0435 \u043D\u0430\u0447\u0430\u0442\u0430.");
  if ((await recheck()).fingerprint !== manifest.fingerprint) throw new Error("\u0421\u043E\u0441\u0442\u0430\u0432 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F. \u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u044C\u0442\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438 \u0437\u0430\u043D\u043E\u0432\u043E.");
  const input = { stationId, clientId: manifest.clientId, widthMm, heightMm, pages };
  if (new TextEncoder().encode(JSON.stringify(input)).length > 8e6) throw new Error("\u041A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0439 \u0440\u0430\u0437\u043C\u0435\u0440 \u043E\u0447\u0435\u0440\u0435\u0434\u0438. \u041F\u0435\u0447\u0430\u0442\u044C \u043D\u0435 \u043D\u0430\u0447\u0430\u0442\u0430.");
  return input;
}

// work/fulfillment-analytics/wms/apps/web/src/lib/printSeries.ts
async function sendPrintSeries(accessToken, payload) {
  const response = await fetch("/api/v1/print/series/jobs", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` }, body: JSON.stringify(payload) });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.message === "string" ? data.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0441\u0435\u0440\u0438\u044E. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0443 \u044D\u0442\u043E\u0439 \u0436\u0435 \u0441\u0435\u0440\u0438\u0438.");
  return data;
}
async function submitPreparedSeries(accessToken, input) {
  const encoded = new TextEncoder().encode(JSON.stringify(input));
  if (encoded.byteLength > 8e6) throw new Error("\u0421\u0435\u0440\u0438\u044F \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0432\u0435\u043B\u0438\u043A\u0430. \u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u0435 \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A.");
  const hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", encoded))).map((n) => n.toString(16).padStart(2, "0")).join("");
  const key = "wms-print-series:" + hash;
  const requestId = sessionStorage.getItem(key) || crypto.randomUUID();
  sessionStorage.setItem(key, requestId);
  const result = await sendPrintSeries(accessToken, { ...input, requestId });
  sessionStorage.removeItem(key);
  if (result.status === "failed") throw new Error("\u0421\u0435\u0440\u0438\u044F \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0430\u0441\u044C \u0441 \u043E\u0448\u0438\u0431\u043A\u043E\u0439. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0443\u0436\u0435 \u0432\u044B\u0448\u0435\u0434\u0448\u0438\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0435 \u043D\u0430\u0436\u0430\u0442\u0438\u0435 \u0441\u043E\u0437\u0434\u0430\u0441\u0442 \u043D\u043E\u0432\u043E\u0435 \u0437\u0430\u0434\u0430\u043D\u0438\u0435.");
  return result;
}

// work/fulfillment-analytics/wms/apps/web/src/components/ozon-fbo/OzonPrintAllLabels.tsx
function OzonPrintAllLabels({ requestId, accessToken, ready }) {
  const [opened, setOpened] = useState(false), [busy, setBusy] = useState(false), [message, setMessage] = useState(""), [station, setStation] = useState("");
  const [stations, setStations] = useState([]), [manifest, setManifest] = useState(null), [sent, setSent] = useState(false);
  const lock = useRef(false);
  const request2 = async (path, body) => {
    const r = await fetch(`${define_import_meta_env_default.VITE_API_URL ?? "/api/v1"}${path}`, { method: body ? "POST" : "GET", headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" }, ...body ? { body: JSON.stringify(body) } : {} });
    const d = await r.json();
    if (!r.ok) throw new Error(Array.isArray(d.message) ? d.message.join(", ") : d.message || "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u0442\u044C \u043F\u0435\u0447\u0430\u0442\u044C.");
    return d;
  };
  const labels = (supplyId) => request2(`/ozon-fbo-import/requests/${encodeURIComponent(requestId)}/supply/print-labels`, supplyId ? { supplyId } : {});
  async function open() {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setMessage("");
    setOpened(true);
    try {
      const [m, s] = await Promise.all([labels(), request2("/print/series/stations")]);
      setManifest(m);
      setStations(s);
      setStation(s.find((v) => /озон|ozon/i.test(v.name))?.id ?? s[0]?.id ?? "");
      if (!s.length) setMessage("\u041D\u0435\u0442 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D\u043D\u044B\u0445 \u0430\u0433\u0435\u043D\u0442\u043E\u0432 \u043F\u0435\u0447\u0430\u0442\u0438. \u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u0435 \u0430\u0433\u0435\u043D\u0442 \u0438 \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435.");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : String(e));
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  async function print() {
    if (lock.current || sent || !manifest || !station) return;
    lock.current = true;
    setBusy(true);
    setMessage("");
    try {
      const input = await prepareOzonAllLabels(manifest, station, labels, () => labels(), setMessage);
      const job = await submitPreparedSeries(accessToken, input);
      setSent(true);
      setMessage(`\u0412 \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E ${job.pages} \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A. \u0417\u0430\u0434\u0430\u043D\u0438\u0435: ${job.id}. \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u0435\u0447\u0430\u0442\u0438 \u2014 \u0432 \u0440\u0430\u0437\u0434\u0435\u043B\u0435 \xAB\u041F\u0435\u0447\u0430\u0442\u044C \u2192 \u0417\u0430\u0434\u0430\u043D\u0438\u044F\xBB.`);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : String(e));
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "ozfbo-print-all", children: [
    /* @__PURE__ */ jsx("button", { type: "button", disabled: !ready || busy, onClick: () => void open(), children: "\u0420\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u0432\u0441\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438" }),
    opened && /* @__PURE__ */ jsxs("div", { role: "group", "aria-label": "\u041F\u0435\u0447\u0430\u0442\u044C \u0432\u0441\u0435\u0445 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A Ozon", children: [
      /* @__PURE__ */ jsx("p", { children: manifest ? `${manifest.total} \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A \xB7 ${manifest.supplies.length} \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0439 \xB7 \u043F\u043E \u043E\u0434\u043D\u043E\u0439 \u043D\u0430 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u043E` : "\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430\u2026" }),
      /* @__PURE__ */ jsxs("label", { children: [
        "\u041F\u0440\u0438\u043D\u0442\u0435\u0440 ",
        /* @__PURE__ */ jsx("select", { disabled: busy || sent, value: station, onChange: (e) => setStation(e.target.value), children: stations.map((s) => /* @__PURE__ */ jsxs("option", { value: s.id, children: [
          s.name,
          " \xB7 ",
          s.printerName
        ] }, s.id)) })
      ] }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || sent || !station || !manifest, onClick: () => void print(), children: busy ? "\u041F\u043E\u0434\u0433\u043E\u0442\u0430\u0432\u043B\u0438\u0432\u0430\u044E\u2026" : "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043F\u0435\u0447\u0430\u0442\u044C \u0432\u0441\u0435\u0445 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A" }),
      sent && /* @__PURE__ */ jsx("button", { type: "button", onClick: () => {
        if (window.confirm("\u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u043D\u0430\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u0432\u0435\u0441\u044C \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A?")) {
          setSent(false);
          setMessage("\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u0443\u044E \u043F\u0435\u0447\u0430\u0442\u044C.");
        }
      }, children: "\u041D\u0430\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E" }),
      /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, onClick: () => setOpened(false), children: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C" }),
      /* @__PURE__ */ jsx("p", { role: "status", children: message })
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/components/client-requests/OzonLinkImport.tsx
function ozonCabinetLabel(c, clientName) {
  return [...new Set([clientName?.trim(), c.accountName?.trim()].filter(Boolean)), c.sellerId].filter(Boolean).join(" \xB7 ") || "Ozon";
}

// work/fulfillment-analytics/wms/apps/web/src/components/ozon-fbo/OzonAssemblySupply.tsx
async function openRecordedOzonLabels(record) {
  const tab = window.open("about:blank", "_blank");
  if (!tab) throw new Error("\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u043D\u043E\u0432\u043E\u0439 \u0432\u043A\u043B\u0430\u0434\u043A\u0438 \u0434\u043B\u044F \u0441\u043A\u0430\u0447\u0438\u0432\u0430\u043D\u0438\u044F \u0441\u0442\u0438\u043A\u0435\u0440\u043E\u0432.");
  tab.opener = null;
  try {
    const result = await record();
    tab.location.replace(result.url);
  } catch (e) {
    tab.close();
    throw e;
  }
}
function cargoMappingReady(data) {
  return !!data?.directions.length && data.directions.every((d) => data.link?.operations[data.link.mapping[d.name]]?.state === "SUCCESS");
}
function OzonAssemblySupply({ requestId, accessToken, clientName, onBindingReady, bindingOnly = false }) {
  const [data, setData] = useState(null), [connection, setConnection] = useState(""), [order, setOrder] = useState(""), [mapping, setMapping] = useState({}), [busy, setBusy] = useState(false), [error, setError] = useState(""), [confirm, setConfirm] = useState(false), [notice, setNotice] = useState("");
  function accept(v) {
    setData(v);
    setMapping(v.link?.mapping ?? {});
    setConnection(v.link?.connectionId ?? v.connections[0]?.id ?? "");
    setOrder("");
    onBindingReady?.(!!v.link && !v.differences.length && v.directions.every((d) => !!v.link?.mapping[d.name]));
  }
  useEffect(() => {
    let live = true;
    void ozonAssemblySupply(accessToken, requestId).then((v) => {
      if (live) accept(v);
    }).catch((e) => {
      if (live) setError(e.message);
    });
    return () => {
      live = false;
    };
  }, [accessToken, requestId]);
  async function action(name, body = {}) {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      accept(await ozonAssemblySupply(accessToken, requestId, name, body));
      setNotice("\u0414\u0430\u043D\u043D\u044B\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u044B.");
      setConfirm(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }
  async function downloadLabels(supplyId) {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await openRecordedOzonLabels(() => recordOzonLabelDownload(accessToken, requestId, supplyId));
      setNotice("\u041D\u0430\u0436\u0430\u0442\u0438\u0435 \xAB\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0441\u0442\u0438\u043A\u0435\u0440\u044B Ozon\xBB \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u043E \u0432 \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0437\u0430\u044F\u0432\u043A\u0438.");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }
  const frozen = !!data?.link?.frozenHash;
  const mappingReady = cargoMappingReady(data);
  async function downloadMapping() {
    setBusy(true);
    setError("");
    try {
      const blob = await downloadOzonCargoMapping(accessToken, requestId), url = URL.createObjectURL(blob), a = document.createElement("a");
      a.href = url;
      a.download = `ozon-boxes-${requestId}.xlsx`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }
  const orders = data?.link ? data.link.orders ?? [data.link] : [];
  return /* @__PURE__ */ jsxs("section", { className: "ozfbo-card ozfbo-supply-panel", "aria-label": "\u0421\u0432\u044F\u0437\u044C \u0441\u0431\u043E\u0440\u043A\u0438 \u0441 Ozon", children: [
    /* @__PURE__ */ jsx("h2", { children: "\u041F\u043E\u0441\u0442\u0430\u0432\u043A\u0430 \u0438 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u0430 Ozon" }),
    /* @__PURE__ */ jsx("p", { children: "\u041F\u0440\u0438\u0432\u044F\u0436\u0438\u0442\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0443\u044E \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0443 \u0434\u043E \u0441\u0431\u043E\u0440\u043A\u0438. \u041F\u043E\u0441\u043B\u0435 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438 \u0438 \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u044F \u043A\u043E\u0440\u043E\u0431\u043E\u0432 \u043F\u0435\u0440\u0435\u0434\u0430\u0439\u0442\u0435 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u0430 \u0432 Ozon. \u0417\u0430\u0442\u0435\u043C \u0440\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u0430\u0439\u0442\u0435 \u0438 \u043D\u0430\u043A\u043B\u0435\u0439\u0442\u0435 \u0441\u0442\u0438\u043A\u0435\u0440\u044B. \u041D\u0430 \u0422\u0421\u0414 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043A\u0430\u0436\u0434\u044B\u0439 \u043A\u043E\u0440\u043E\u0431: \u043D\u0430\u0448 \u0428\u041A \u2192 \u0428\u041A \u0441\u0442\u0438\u043A\u0435\u0440\u0430 Ozon." }),
    error && /* @__PURE__ */ jsx("p", { role: "alert", children: error }),
    notice && /* @__PURE__ */ jsx("p", { role: "status", children: notice }),
    !data ? /* @__PURE__ */ jsx("p", { children: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026" }) : /* @__PURE__ */ jsxs(Fragment2, { children: [
      /* @__PURE__ */ jsxs("fieldset", { className: "ozfbo-supply-bind", disabled: busy || frozen, children: [
        /* @__PURE__ */ jsxs("label", { children: [
          "\u041A\u0430\u0431\u0438\u043D\u0435\u0442",
          /* @__PURE__ */ jsx("select", { disabled: !!data.link, value: connection, onChange: (e) => setConnection(e.target.value), children: data.connections.map((c) => /* @__PURE__ */ jsx("option", { value: c.id, children: ozonCabinetLabel({ ...c, sellerId: c.sellerId ?? "" }, clientName) }, c.id)) })
        ] }),
        /* @__PURE__ */ jsxs("label", { children: [
          "\u0421\u0441\u044B\u043B\u043A\u0430 \u0438\u043B\u0438 ID \u0437\u0430\u044F\u0432\u043A\u0438 Ozon \u0438\u0437 \u0430\u0434\u0440\u0435\u0441\u0430 \u043A\u0430\u0431\u0438\u043D\u0435\u0442\u0430",
          /* @__PURE__ */ jsx("input", { value: order, onChange: (e) => setOrder(e.target.value) })
        ] }),
        /* @__PURE__ */ jsx("button", { type: "button", disabled: !connection || !order, onClick: () => void action("bind", { connectionId: connection, orderId: order }), children: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443 Ozon" })
      ] }),
      data.link && /* @__PURE__ */ jsxs(Fragment2, { children: [
        /* @__PURE__ */ jsx(OzonEditCountdown, { orders }),
        /* @__PURE__ */ jsxs("h3", { children: [
          "\u0417\u0430\u044F\u0432\u043A\u0438 Ozon \u043E\u0431\u0449\u0435\u0439 \u0441\u0431\u043E\u0440\u043A\u0438 (",
          orders.length,
          ")"
        ] }),
        orders.map((o) => /* @__PURE__ */ jsxs("p", { className: "ozfbo-linked-order", children: [
          /* @__PURE__ */ jsxs("a", { href: "https://seller.ozon.ru/app/supply/orders/" + o.orderId, target: "_blank", rel: "noreferrer", children: [
            "Ozon \u2116",
            o.orderNumber
          ] }),
          " \xB7 ",
          o.place,
          " \xB7 ",
          o.date ? new Date(o.date).toLocaleString("ru-RU") : "",
          " \xB7 ",
          o.state,
          " \xB7 ",
          o.supplies.reduce((n, s) => n + s.items.reduce((n2, i) => n2 + i.quantity, 0), 0),
          " \u0448\u0442."
        ] }, o.orderId)),
        /* @__PURE__ */ jsxs("p", { children: [
          "\u0412\u0441\u0435\u0433\u043E \u043F\u043E \u0444\u0430\u0439\u043B\u0443: ",
          data.directions.reduce((n, d) => n + d.items.reduce((n2, i) => n2 + i.quantity, 0), 0),
          " \u0448\u0442. \xB7 \u0412 Ozon: ",
          data.link.supplies.reduce((n, s) => n + s.items.reduce((n2, i) => n2 + i.quantity, 0), 0),
          " \u0448\u0442."
        ] }),
        /* @__PURE__ */ jsxs("fieldset", { className: "ozfbo-direction-mapping", disabled: busy || frozen, children: [
          /* @__PURE__ */ jsx("legend", { children: "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0438\u0437 \u0444\u0430\u0439\u043B\u0430 \u2192 Ozon" }),
          data.directions.map((d) => /* @__PURE__ */ jsxs("label", { className: "ozfbo-direction-row", children: [
            d.name,
            " \xB7 ",
            d.items.reduce((n, i) => n + i.quantity, 0),
            " \u0448\u0442.",
            /* @__PURE__ */ jsxs("select", { value: mapping[d.name] ?? "", onChange: (e) => setMapping((m) => ({ ...m, [d.name]: e.target.value })), children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "\u041D\u0435 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E" }),
              data.link.supplies.map((s) => /* @__PURE__ */ jsxs("option", { value: s.id, children: [
                s.name,
                " \xB7 \u2116",
                orders.find((o) => o.supplies.some((v) => v.id === s.id))?.orderNumber,
                " \xB7 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0430 ",
                s.id,
                " \xB7 ",
                s.items.reduce((n, i) => n + i.quantity, 0),
                " \u0448\u0442."
              ] }, s.id))
            ] })
          ] }, d.name)),
          /* @__PURE__ */ jsx("button", { type: "button", onClick: () => void action("mapping", { mapping }), children: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F" })
        ] }),
        data.differences.length > 0 ? /* @__PURE__ */ jsxs("div", { role: "alert", children: [
          /* @__PURE__ */ jsx("strong", { children: "\u0415\u0441\u0442\u044C \u0440\u0430\u0441\u0445\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u2014 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u0430" }),
          /* @__PURE__ */ jsx("ul", { children: data.differences.map((v, i) => /* @__PURE__ */ jsx("li", { children: v }, i)) }),
          /* @__PURE__ */ jsx("p", { children: "\u0418\u0441\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0443 \u0432 \u043A\u0430\u0431\u0438\u043D\u0435\u0442\u0435 Ozon \u0438\u043B\u0438 \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435. \u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u0430 \u0444\u0430\u0439\u043B\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F." })
        ] }) : /* @__PURE__ */ jsx("p", { className: "ozfbo-composition-match", children: "\u0421\u043E\u0441\u0442\u0430\u0432 \u0444\u0430\u0439\u043B\u0430 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 Ozon." }),
        /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, onClick: () => void action("refresh"), children: "\u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u0441\u0432\u0435\u0440\u0438\u0442\u044C \u0441 Ozon" }),
        !bindingOnly && /* @__PURE__ */ jsx(OzonPackingPlan, { data, busy, action }),
        !bindingOnly && /* @__PURE__ */ jsxs(Fragment2, { children: [
          !data.link.packingPlan && data.packingError && /* @__PURE__ */ jsx("p", { children: data.packingError }),
          /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || !mappingReady, onClick: () => void downloadMapping(), children: "\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F \u043A\u043E\u0440\u043E\u0431\u043E\u0432 (Excel)" }),
          /* @__PURE__ */ jsx("p", { children: "\u041A\u043E\u0440\u043E\u0431 WMS \u2192 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u2192 \u043D\u043E\u043C\u0435\u0440 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u0430 Ozon. \u0424\u0430\u0439\u043B \u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u043F\u043E\u0441\u043B\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0432\u0441\u0435\u0445 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0439. \u041F\u043E\u0440\u044F\u0434\u043E\u043A \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u043B\u0438\u0447\u0430\u0442\u044C\u0441\u044F \u043E\u0442 \u043F\u043E\u0440\u044F\u0434\u043A\u0430 \u043A\u043E\u0440\u043E\u0431\u043E\u0432." }),
          !data.link.packingPlan && /* @__PURE__ */ jsxs(Fragment2, { children: [
            /* @__PURE__ */ jsxs("label", { className: "ozfbo-upload-confirm", children: [
              /* @__PURE__ */ jsx("input", { type: "checkbox", checked: confirm, disabled: busy, onChange: (e) => setConfirm(e.target.checked) }),
              "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0443 \u0441\u043E\u0441\u0442\u0430\u0432\u0430 \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0438 \u0437\u0430\u043A\u0440\u044B\u0442\u044B\u0445 \u043A\u043E\u0440\u043E\u0431\u043E\u0432"
            ] }),
            /* @__PURE__ */ jsx("button", { type: "button", disabled: busy || !confirm || !!data.packingError || data.differences.length > 0, onClick: () => void action("upload", { confirm: true }), children: "\u041F\u0435\u0440\u0435\u0434\u0430\u0442\u044C \u043A\u043E\u0440\u043E\u0431\u0430 \u0432 Ozon" })
          ] })
        ] }),
        !bindingOnly && /* @__PURE__ */ jsx(OzonPrintAllLabels, { requestId, accessToken, ready: mappingReady && !busy }, requestId),
        Object.keys(data.link.operations).length > 0 && /* @__PURE__ */ jsxs(Fragment2, { children: [
          /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, onClick: () => void action("status"), children: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438" }),
          /* @__PURE__ */ jsx("p", { children: "\u0421\u043E\u0441\u0442\u0430\u0432 \u0437\u0430\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u043D. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0443\u0436\u0435 \u043D\u0430\u0447\u0430\u0442\u044B\u0445 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0439 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F." }),
          Object.entries(data.link.operations).map(([id, op]) => /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("strong", { children: data.link.supplies.find((s) => s.id === id)?.name ?? id }),
            /* @__PURE__ */ jsx("p", { children: { QUEUED: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0435\u0433\u043E \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F", SENDING: "\u0417\u0430\u043F\u0440\u043E\u0441 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F; \u043F\u043E\u0432\u0442\u043E\u0440 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D", UNKNOWN: "\u041E\u0442\u0432\u0435\u0442 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u2014 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F \u0441\u0432\u0435\u0440\u043A\u0430 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442 \u0432 \u043A\u0430\u0431\u0438\u043D\u0435\u0442\u0435", ACCEPTED: "Ozon \u043E\u0431\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0435\u0442", SUCCESS: "\u0413\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B", FAILED: "Ozon \u043E\u0442\u043A\u043B\u043E\u043D\u0438\u043B \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u0430" }[op.state] ?? op.state }),
            op.error && /* @__PURE__ */ jsx("p", { role: "alert", children: op.error }),
            op.state === "SUCCESS" && /* @__PURE__ */ jsx("button", { disabled: busy, type: "button", onClick: () => void action("labels", { supplyId: id }), children: "\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438 Ozon" }),
            op.labelOperationId && !op.labelUrl && /* @__PURE__ */ jsx("p", { children: "\u042D\u0442\u0438\u043A\u0435\u0442\u043A\u0438 \u0433\u043E\u0442\u043E\u0432\u044F\u0442\u0441\u044F. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438 Ozon\xBB \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E." }),
            op.labelUrl && /* @__PURE__ */ jsx("button", { type: "button", disabled: busy, onClick: () => void downloadLabels(id), children: "\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0441\u0442\u0438\u043A\u0435\u0440\u044B Ozon" })
          ] }, id))
        ] })
      ] })
    ] })
  ] });
}

// work/fulfillment-analytics/wms/apps/web/src/planned-release.tsx
function PlannedSupplyGate(props) {
  const [data, setData] = useState(null), [busy, setBusy] = useState(false), [error, setError] = useState("");
  useEffect(() => {
    let live = true;
    ozonAssemblySupply(props.accessToken, props.requestId).then((d) => {
      if (live) setData(d);
    }).catch(() => {
    });
    return () => {
      live = false;
    };
  }, [props.accessToken, props.requestId]);
  if (data?.link?.packingPlan) return react_default.createElement(OzonAssemblySupply, props);
  const action = async (name, body) => {
    setBusy(true);
    setError("");
    try {
      setData(await ozonAssemblySupply(props.accessToken, props.requestId, name, body));
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  return react_default.createElement(react_default.Fragment, null, react_default.createElement(props.Legacy, props), error && react_default.createElement("p", { role: "alert" }, error), data?.plannedPackingSupported && !props.bindingOnly && react_default.createElement(OzonPackingPlan, { data, busy, action }));
}
export {
  FboTwoStagePanel,
  PlannedSupplyGate
};
