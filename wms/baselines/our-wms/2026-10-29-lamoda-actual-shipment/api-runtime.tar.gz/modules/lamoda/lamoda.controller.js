"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const lamoda_service_1 = require("./lamoda.service");
const lamoda_dto_1 = require("./lamoda.dto");
const lamoda_policy_1 = require("./lamoda-policy");
const lamoda_dto_2 = require("./lamoda.dto");
const lamoda_actual_shipment_1 = require("./lamoda-actual-shipment");
let LamodaController = class LamodaController {
    service;
    resetSubmission(id, requestId, user) { return this.service.submission(id, requestId, user, 'reset'); }
    submission(id, requestId, user) { return this.service.submission(id, requestId, user, 'view'); }
    previewSubmission(id, requestId, user, body) { return this.service.submission(id, requestId, user, 'preview', body); }
    sendSubmission(id, requestId, user, body) { return this.service.submission(id, requestId, user, 'send', body); }
    refreshSubmission(id, requestId, user) { return this.service.submission(id, requestId, user, 'refresh'); }
    async submissionFile(id, requestId, user, body) {
        const result = await this.service.submission(id, requestId, user, 'preview', body);
        if (!('payload' in result))
            throw new common_1.BadRequestException('Нет состава поставки.');
        return new common_1.StreamableFile((0, lamoda_actual_shipment_1.actualLamodaWorkbook)(result.payload), { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', disposition: 'attachment; filename="Lamoda-shipment.xlsx"' });
    }
    constructor(service) {
        this.service = service;
    }
    accounts(clientId, user) { return this.service.accounts(clientId, user); }
    create(body, user) { return this.service.create(body, user); }
    update(id, body, user) { return this.service.update(id, body, user); }
    overview(id, user) { return this.service.overview(id, user); }
    warehouses(id, user) { return this.service.warehouses(id, user); }
    check(id, user) { return this.service.check(id, user); }
    sync(id, body, user) { return this.service.sync(id, body.kind, user); }
    candidates(id, productId, user, q) { return this.service.candidates(id, productId, user, q); }
    link(id, productId, body, user) { return this.service.link(id, productId, body.skuId, user); }
    async template(id, user) {
        await this.service.overview(id, user);
        return new common_1.StreamableFile((0, lamoda_policy_1.templateWorkbook)(), { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', disposition: 'attachment; filename="Lamoda-FBO.xlsx"' });
    }
    importPlan(id, body, file, user) {
        if (!file?.buffer)
            throw new common_1.BadRequestException('Выберите Excel-файл.');
        return this.service.importPlan(id, body, file.buffer, user);
    }
    availability(id, planId, user) { return this.service.availability(id, planId, user); }
    fromShipment(id, body, user) { return this.service.importShipment(id, body, user); }
    assembly(id, planId, user, body) { return this.service.createAssembly(id, planId, user, body); }
};
exports.LamodaController = LamodaController;
__decorate([
    (0, common_1.Post)('accounts/:id/assemblies/:requestId/submission/reset'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('requestId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "resetSubmission", null);
__decorate([
    (0, common_1.Get)('accounts/:id/assemblies/:requestId/submission'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('requestId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "submission", null);
__decorate([
    (0, common_1.Post)('accounts/:id/assemblies/:requestId/submission/preview'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('requestId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, typeof (_b = typeof lamoda_dto_2.LamodaSubmissionDto !== "undefined" && lamoda_dto_2.LamodaSubmissionDto) === "function" ? _b : Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "previewSubmission", null);
__decorate([
    (0, common_1.Post)('accounts/:id/assemblies/:requestId/submission/send'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('requestId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, typeof (_c = typeof lamoda_dto_2.LamodaSubmissionDto !== "undefined" && lamoda_dto_2.LamodaSubmissionDto) === "function" ? _c : Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "sendSubmission", null);
__decorate([
    (0, common_1.Post)('accounts/:id/assemblies/:requestId/submission/refresh'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('requestId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "refreshSubmission", null);
__decorate([
    (0, common_1.Post)('accounts/:id/assemblies/:requestId/submission/file'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('requestId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, typeof (_d = typeof lamoda_dto_2.LamodaSubmissionDto !== "undefined" && lamoda_dto_2.LamodaSubmissionDto) === "function" ? _d : Object]),
    __metadata("design:returntype", Promise)
], LamodaController.prototype, "submissionFile", null);
__decorate([
    (0, common_1.Get)('accounts'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "accounts", null);
__decorate([
    (0, common_1.Post)('accounts'),
    (0, require_permissions_decorator_1.RequirePermissions)('marketplace-api:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_e = typeof lamoda_dto_1.LamodaCreateAccountDto !== "undefined" && lamoda_dto_1.LamodaCreateAccountDto) === "function" ? _e : Object, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)('accounts/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('marketplace-api:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_f = typeof lamoda_dto_1.LamodaUpdateAccountDto !== "undefined" && lamoda_dto_1.LamodaUpdateAccountDto) === "function" ? _f : Object, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "update", null);
__decorate([
    (0, common_1.Get)('accounts/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "overview", null);
__decorate([
    (0, common_1.Get)('accounts/:id/warehouses'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "warehouses", null);
__decorate([
    (0, common_1.Post)('accounts/:id/check'),
    (0, require_permissions_decorator_1.RequirePermissions)('marketplace-api:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "check", null);
__decorate([
    (0, common_1.Post)('accounts/:id/sync'),
    (0, require_permissions_decorator_1.RequirePermissions)('marketplace-api:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_g = typeof lamoda_dto_1.LamodaSyncDto !== "undefined" && lamoda_dto_1.LamodaSyncDto) === "function" ? _g : Object, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "sync", null);
__decorate([
    (0, common_1.Get)('accounts/:id/products/:productId/candidates'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('productId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Query)('q')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, String]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "candidates", null);
__decorate([
    (0, common_1.Post)('accounts/:id/products/:productId/link'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('productId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, typeof (_h = typeof lamoda_dto_1.LamodaLinkDto !== "undefined" && lamoda_dto_1.LamodaLinkDto) === "function" ? _h : Object, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "link", null);
__decorate([
    (0, common_1.Get)('accounts/:id/template'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], LamodaController.prototype, "template", null);
__decorate([
    (0, common_1.Post)('accounts/:id/plans/import'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 5 * 1024 * 1024 } })),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.UploadedFile)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_j = typeof lamoda_dto_1.LamodaImportDto !== "undefined" && lamoda_dto_1.LamodaImportDto) === "function" ? _j : Object, typeof (_l = typeof Express !== "undefined" && (_k = Express.Multer) !== void 0 && _k.File) === "function" ? _l : Object, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "importPlan", null);
__decorate([
    (0, common_1.Post)('accounts/:id/plans/:planId/availability'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('planId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "availability", null);
__decorate([
    (0, common_1.Post)('accounts/:id/plans/from-shipment'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_m = typeof lamoda_dto_1.LamodaImportShipmentDto !== "undefined" && lamoda_dto_1.LamodaImportShipmentDto) === "function" ? _m : Object, Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "fromShipment", null);
__decorate([
    (0, common_1.Post)('accounts/:id/plans/:planId/assembly'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:write', 'client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('planId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, typeof (_o = typeof lamoda_dto_1.LamodaAssemblyDto !== "undefined" && lamoda_dto_1.LamodaAssemblyDto) === "function" ? _o : Object]),
    __metadata("design:returntype", void 0)
], LamodaController.prototype, "assembly", null);
exports.LamodaController = LamodaController = __decorate([
    (0, common_1.Controller)('lamoda')
    // FIX: service still requires CLIENT role and scoped access for customer plan operations.
    ,
    (0, require_permissions_decorator_1.RequireAnyPermissions)('marketplace-api:read', 'marketplace-api:write', 'client-requests:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof lamoda_service_1.LamodaService !== "undefined" && lamoda_service_1.LamodaService) === "function" ? _a : Object])
], LamodaController);
