"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ReceiptChannelsController_1;
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceiptChannelsController = void 0;
const core_1 = require("@nestjs/core");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const client_scope_service_1 = require("../auth/client-scope.service");
const receipt_channel_policy_1 = require("./receipt-channel-policy");
let ReceiptChannelsController = ReceiptChannelsController_1 = class ReceiptChannelsController {
    prisma;
    scopes;
    modules;
    logger = new common_1.Logger(ReceiptChannelsController_1.name);
    constructor(prisma, scopes, modules) {
        this.prisma = prisma;
        this.scopes = scopes;
        this.modules = modules;
    }
    async list(user, clientId, from, to) {
        if (typeof clientId !== 'string' || !clientId.trim())
            throw new common_1.BadRequestException('Выберите клиента.');
        const warehouseId = (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        this.scopes.requireClientAccess(user, clientId, 'read');
        if (!(0, receipt_channel_policy_1.receiptChannelsEnabled)())
            return { enabled: false, rows: [] };
        const since = from && /^\d{4}-\d{2}-\d{2}$/.test(from) ? new Date(from + 'T00:00:00+03:00') : new Date(Date.now() - 30 * 86400000);
        const until = to && /^\d{4}-\d{2}-\d{2}$/.test(to) ? new Date(to + 'T23:59:59+03:00') : new Date();
        if (!Number.isFinite(since.getTime()) || !Number.isFinite(until.getTime()) || since > until)
            throw new common_1.BadRequestException('Проверьте период приёмок.');
        const [docs, saved] = await Promise.all([(0, receipt_channel_policy_1.receiptDocuments)(this.prisma, clientId, warehouseId, since), this.prisma.systemSetting.findMany({ where: { key: { startsWith: `receipt.channels.v1:${clientId}:` } }, select: { value: true } })]);
        const rules = new Map(saved.map(s => { const r = s.value; return [r.id, r]; }));
        return { enabled: true, rows: docs.filter(d => d.current || new Date(d.date) <= until).map(d => ({ ...d, fbs: rules.get(d.id)?.fbs ?? true, fbo: rules.get(d.id)?.fbo ?? true, revision: rules.get(d.id)?.revision ?? 0 })) };
    }
    async assign(user, body) {
        if (!body || typeof body.clientId !== 'string' || typeof body.id !== 'string' || typeof body.boxCode !== 'string' || !body.boxCode.trim() || typeof body.save !== 'boolean')
            throw new common_1.BadRequestException('Укажите приёмку и короб.');
        const warehouseId = (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        const result = await this.prisma.$transaction(tx => (0, receipt_channel_policy_1.assignReceiptBox)(tx, body.clientId, warehouseId, body.id, body.boxCode, user.id, body.save), { isolationLevel: 'Serializable', timeout: 30000 });
        if (body.save)
            this.refresh(body.clientId);
        return result;
    }
    preview(user, body) { return this.change(user, body, false); }
    save(user, body) { return this.change(user, body, true); }
    async change(user, body, save) {
        if (!body || typeof body.clientId !== 'string' || !body.clientId.trim() || typeof body.id !== 'string' || !/^[a-f0-9]{32}$/.test(body.id))
            throw new common_1.BadRequestException('Укажите клиента и приёмку.');
        const warehouseId = (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        const result = await this.prisma.$transaction(async (tx) => {
            // FIX: serialize policy changes with each other; serializable scans retry stale reads.
            if (save)
                await tx.$executeRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))', `receipt-channels:${body.clientId}:${warehouseId}`);
            return (0, receipt_channel_policy_1.receiptChannelChange)(tx, body.clientId, warehouseId, body.id, body.fbs, body.fbo, body.revision, save, user.id);
        }, { isolationLevel: save ? 'Serializable' : 'RepeatableRead', timeout: 30000 });
        if (save)
            this.refresh(body.clientId);
        return result;
    }
    refresh(clientId) {
        // FIX: schedule recalculation immediately; the existing periodic stock sync retries failures.
        // FIX: a failed background sync must not misreport a committed save as failed.
        void Promise.resolve().then(() => this.modules.get(marketplace_connections_service_1.MarketplaceConnectionsService, { strict: false }).refreshReceiptChannelStocks(clientId))
            .catch(() => this.logger.warn(`Receipt directions saved for ${clientId}; periodic WB stock synchronization will retry.`));
    }
};
exports.ReceiptChannelsController = ReceiptChannelsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('from')),
    __param(3, (0, common_1.Query)('to')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('assign-box'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "assign", null);
__decorate([
    (0, common_1.Post)('preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ReceiptChannelsController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ReceiptChannelsController.prototype, "save", null);
exports.ReceiptChannelsController = ReceiptChannelsController = ReceiptChannelsController_1 = __decorate([
    (0, common_1.Controller)('warehouse/receipt-channels'),
    (0, require_permissions_decorator_1.RequirePermissions)('warehouse:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof core_1.ModuleRef !== "undefined" && core_1.ModuleRef) === "function" ? _c : Object])
], ReceiptChannelsController);
