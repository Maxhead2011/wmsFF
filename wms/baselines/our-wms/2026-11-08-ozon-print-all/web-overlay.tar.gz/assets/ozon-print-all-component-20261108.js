export function createOzonPrintAll(React){const {useRef,useState}=React;
// FIX: prepare all pages before the single POST; preserve the request ID on explicit retry.
async function preparePrintSeries(values, options, render) {
    if (!values.length || values.length > 500)
        throw new Error('Серия — от 1 до 500 этикеток.');
    const pages = [];
    for (const value of values)
        pages.push({ value, imageBase64: (await render(value)).replace(/^data:image\/png;base64,/, '') });
    return { ...options, requestId: crypto.randomUUID(), pages };
}
async function sendPrintSeries(accessToken, payload) {
    const response = await fetch('/api/v1/print/series/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok)
        throw new Error(typeof data.message === 'string' ? data.message : 'Не удалось отправить серию. Повторите отправку этой же серии.');
    return data;
}
// FIX: after an ambiguous network response, an explicit retry reuses the original UUID.
async function submitPreparedSeries(accessToken, input) {
    const encoded = new TextEncoder().encode(JSON.stringify(input));
    if (encoded.byteLength > 8_000_000)
        throw new Error('Серия слишком велика. Уменьшите количество этикеток.');
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', encoded))).map(n => n.toString(16).padStart(2, '0')).join('');
    const key = 'wms-print-series:' + hash;
    const requestId = sessionStorage.getItem(key) || crypto.randomUUID();
    sessionStorage.setItem(key, requestId);
    const result = await sendPrintSeries(accessToken, { ...input, requestId });
    sessionStorage.removeItem(key);
    if (result.status === 'failed')
        throw new Error('Серия завершилась с ошибкой. Проверьте уже вышедшие этикетки. Повторное нажатие создаст новое задание.');
    return result;
}
// FIX: no queue write until every direction has been prepared and the manifest rechecked.
async function prepareOzonAllLabels(manifest, stationId, part, recheck, progress) {
    const pages = [];
    let widthMm = 0, heightMm = 0;
    for (const supply of manifest.supplies) {
        progress(`Подготовка: ${supply.name} · ${pages.length} из ${manifest.total}`);
        const next = await part(supply.id);
        if (next.fingerprint !== manifest.fingerprint || next.clientId !== manifest.clientId)
            throw new Error('Состав грузомест изменился. Подготовьте этикетки заново.');
        if (next.pages.length !== supply.cargoIds.length || new Set(next.pages.map(p => p.value)).size !== supply.cargoIds.length || next.pages.some(p => !supply.cargoIds.includes(p.value)))
            throw new Error('Комплект этикеток направления неполный. Печать не начата.');
        if (widthMm && (widthMm !== next.widthMm || heightMm !== next.heightMm))
            throw new Error('В направлениях разные форматы этикеток.');
        widthMm = next.widthMm;
        heightMm = next.heightMm;
        pages.push(...next.pages);
    }
    if (!pages.length || pages.length !== manifest.total || new Set(pages.map(p => p.value)).size !== pages.length)
        throw new Error('Комплект этикеток неполный. Печать не начата.');
    if ((await recheck()).fingerprint !== manifest.fingerprint)
        throw new Error('Состав грузомест изменился. Подготовьте этикетки заново.');
    const input = { stationId, clientId: manifest.clientId, widthMm, heightMm, pages };
    if (new TextEncoder().encode(JSON.stringify(input)).length > 8_000_000)
        throw new Error('Комплект превышает допустимый размер очереди. Печать не начата.');
    return input;
}
// FIX: the existing station queue owns media, retry UUID and physical agent acknowledgement.
function OzonPrintAllLabels({ requestId, accessToken, ready }) {
    const [opened, setOpened] = useState(false), [busy, setBusy] = useState(false), [message, setMessage] = useState(''), [station, setStation] = useState('');
    const [stations, setStations] = useState([]), [manifest, setManifest] = useState(null), [sent, setSent] = useState(false);
    const lock = useRef(false);
    const request = async (path, body) => { const r = await fetch(`${'/api/v1'}${path}`, { method: body ? 'POST' : 'GET', headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' }, ...(body ? { body: JSON.stringify(body) } : {}) }); const d = await r.json(); if (!r.ok)
        throw new Error(Array.isArray(d.message) ? d.message.join(', ') : d.message || 'Не удалось подготовить печать.'); return d; };
    const labels = (supplyId) => request(`/ozon-fbo-import/requests/${encodeURIComponent(requestId)}/supply/print-labels`, supplyId ? { supplyId } : {});
    async function open() { if (lock.current)
        return; lock.current = true; setBusy(true); setMessage(''); setOpened(true); try {
        const [m, s] = await Promise.all([labels(), request('/print/series/stations')]);
        setManifest(m);
        setStations(s);
        setStation(s.find((v) => /озон|ozon/i.test(v.name))?.id ?? s[0]?.id ?? '');
        if (!s.length)
            setMessage('Нет подключённых агентов печати. Запустите агент и повторите.');
    }
    catch (e) {
        setMessage(e instanceof Error ? e.message : String(e));
    }
    finally {
        lock.current = false;
        setBusy(false);
    } }
    async function print() { if (lock.current || sent || !manifest || !station)
        return; lock.current = true; setBusy(true); setMessage(''); try {
        const input = await prepareOzonAllLabels(manifest, station, labels, () => labels(), setMessage);
        const job = await submitPreparedSeries(accessToken, input);
        setSent(true);
        setMessage(`В очередь отправлено ${job.pages} этикеток. Задание: ${job.id}. Результат печати — в разделе «Печать → Задания».`);
    }
    catch (e) {
        setMessage(e instanceof Error ? e.message : String(e));
    }
    finally {
        lock.current = false;
        setBusy(false);
    } }
    return React.createElement("div", { className: "ozfbo-print-all" },
        React.createElement("button", { type: "button", disabled: !ready || busy, onClick: () => void open() }, "\u0420\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u0432\u0441\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438"),
        opened && React.createElement("div", { role: "group", "aria-label": "\u041F\u0435\u0447\u0430\u0442\u044C \u0432\u0441\u0435\u0445 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A Ozon" },
            React.createElement("p", null, manifest ? `${manifest.total} этикеток · ${manifest.supplies.length} направлений · по одной на грузоместо` : 'Подготовка…'),
            React.createElement("label", null,
                "\u041F\u0440\u0438\u043D\u0442\u0435\u0440 ",
                React.createElement("select", { disabled: busy || sent, value: station, onChange: e => setStation(e.target.value) }, stations.map(s => React.createElement("option", { key: s.id, value: s.id },
                    s.name,
                    " \u00B7 ",
                    s.printerName)))),
            React.createElement("button", { type: "button", disabled: busy || sent || !station || !manifest, onClick: () => void print() }, busy ? 'Подготавливаю…' : 'Подтвердить печать всех этикеток'),
            sent && React.createElement("button", { type: "button", onClick: () => { if (window.confirm('Повторно напечатать весь комплект этикеток?')) {
                    setSent(false);
                    setMessage('Подтвердите повторную печать.');
                } } }, "\u041D\u0430\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E"),
            React.createElement("button", { type: "button", disabled: busy, onClick: () => setOpened(false) }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044C"),
            React.createElement("p", { role: "status" }, message)));
}

return OzonPrintAllLabels;
}
