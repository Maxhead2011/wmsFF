import { j as ie, r as M } from "/assets/storage-volume-root-20261109.js";
function r(...n) {
  return ie.jsx(...n);
}
function t(...n) {
  return ie.jsxs(...n);
}
function L(n) {
  return n.children;
}
function s(...n) {
  return M.useState(...n);
}
function j(...n) {
  return M.useEffect(...n);
}
function te(...n) {
  return M.useRef(...n);
}
function Ce(...n) {
  return M.useMemo(...n);
}
function ye(...n) {
  return M.useCallback(...n);
}
const Ie = "/api/v1";
async function we(n, o = {}) {
  return T(
    Se("/clients", {
      includeArchived: o.includeArchived ? "true" : void 0,
      marketplaceDirectory: o.marketplaceDirectory ? "true" : void 0,
      allBranches: o.allBranches ? "1" : void 0,
      displayWarehouseId: o.displayWarehouseId || void 0
    }),
    {
      accessToken: n
    }
  );
}
async function T(n, o = {}) {
  const l = await fetch(`${Ie}${n}`, {
    method: o.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      ...o.accessToken ? { Authorization: `Bearer ${o.accessToken}` } : {}
    },
    body: o.body ? JSON.stringify(o.body) : void 0
  });
  if (!l.ok) {
    const i = await l.json().catch(() => null), m = new Error(await Ee(l, i));
    throw (i == null ? void 0 : i.code) === "KIZ_DUPLICATE" && i.duplicateInfo && typeof i.duplicateInfo == "object" && Object.assign(m, { code: i.code, duplicate: !0, duplicateInfo: i.duplicateInfo }), m;
  }
  return await l.json();
}
function Se(n, o) {
  const l = new URLSearchParams();
  Object.entries(o).forEach(([m, u]) => {
    u !== void 0 && u !== "" && u !== !1 && l.set(m, String(u));
  });
  const i = l.toString();
  return i ? `${n}?${i}` : n;
}
async function Ee(n, o) {
  try {
    const l = o === void 0 ? await n.json() : o;
    return Array.isArray(l == null ? void 0 : l.message) ? l.message.join(`
`) : (l == null ? void 0 : l.message) || `HTTP ${n.status}`;
  } catch {
    return `HTTP ${n.status}`;
  }
}
const Te = "logoff-wms:last-client", O = "logoff-wms:last-client-change";
function Re(n, o = {}) {
  var S, I;
  const l = Ce(() => `${Te}:${n}`, [n]), i = ((S = o.fixedClientId) == null ? void 0 : S.trim()) ?? "", m = ((I = o.initialClientId) == null ? void 0 : I.trim()) ?? "", [u, g] = s(
    () => i || (o.preferInitialClientId ? m : "") || Ue(l) || m
  );
  j(() => {
    i && g(i);
  }, [i]), j(() => {
    if (i || typeof window > "u") return;
    const C = (w) => {
      const b = Ae(w, l);
      b && g(b);
    };
    return window.addEventListener(O, C), () => {
      window.removeEventListener(O, C);
    };
  }, [i, l]);
  const f = ye((C) => {
    g((w) => {
      const b = typeof C == "function" ? C(w) : C;
      return !i && b && typeof window < "u" && (window.localStorage.setItem(l, b), window.dispatchEvent(new CustomEvent(O, {
        detail: { storageKey: l, clientId: b }
      }))), b;
    });
  }, [i, l]);
  return [u, f];
}
function ke(n, o, l = "") {
  var i;
  return o.some((m) => m.id === n) ? n : l || ((i = o[0]) == null ? void 0 : i.id) || "";
}
function Ae(n, o) {
  var i;
  const l = n.detail;
  return n.type !== O || (l == null ? void 0 : l.storageKey) !== o ? "" : ((i = l.clientId) == null ? void 0 : i.trim()) ?? "";
}
function Ue(n) {
  var o;
  return typeof window > "u" ? "" : ((o = window.localStorage.getItem(n)) == null ? void 0 : o.trim()) ?? "";
}
const re = { SATIN: "Атлас", GABARDINE: "Габардин" };
function Me({ session: n }) {
  var Z, Y, ee;
  const [o, l] = s([]), [i, m] = Re(n.user.id), [u, g] = s(null), [f, S] = s(null), [I, C] = s("SATIN"), [w, b] = s("black"), [x, $] = s(""), [R, ae] = s(1), [P, W] = s(""), [k, le] = s(5), [c, E] = s(!1), [J, p] = s(""), [K, B] = s(""), [A, oe] = s(""), [v, ce] = s("ADJUST"), [G, se] = s(0), [D, de] = s(""), [z, ue] = s(""), [H, he] = s(""), [q, me] = s(""), [Q, fe] = s(1), h = te(0), U = te(null), y = n.accessToken, F = "/warehouse/fabric-rolls/" + encodeURIComponent(i), be = !n.user.roleCodes.includes("CLIENT") && n.user.permissionCodes.some((e) => ["stock:write", "system:admin"].includes(e)), pe = !n.user.roleCodes.includes("CLIENT") && n.user.permissionCodes.some((e) => ["clients:write", "system:admin"].includes(e));
  j(() => {
    let e = !0;
    return we(y).then((a) => {
      e && (l(a), m((d) => ke(d, a)));
    }).catch((a) => {
      e && p(String(a.message));
    }), () => {
      e = !1;
    };
  }, [y]);
  async function _() {
    const e = ++h.current;
    p("");
    try {
      const [a, d] = await Promise.all([T(F, { accessToken: y }), T("/warehouse/fabric-catalog/" + encodeURIComponent(i), { accessToken: y })]);
      e === h.current && (g(a), S(d));
    } catch (a) {
      e === h.current && p(a instanceof Error ? a.message : String(a));
    }
  }
  j(() => (g(null), S(null), W(""), b("black"), B(""), U.current = null, i && _(), () => {
    h.current++;
  }), [i, y, n.user.activeWarehouseId]);
  async function V(e) {
    if (!f || c) return;
    E(!0), p("");
    const a = h.current;
    try {
      const d = await T("/warehouse/fabric-catalog/" + encodeURIComponent(i), { accessToken: y, method: "POST", body: { action: e, material: I, name: x, skuId: P, colorId: w, lengthMm: Math.round(k * 1e3), version: f.version } });
      if (a !== h.current) return;
      S(d.catalog), d.result.color && (b(d.result.color.id), $("")), B(d.result.reused ? "Такой цвет уже есть — он выбран." : e === "CREATE_COLOR" ? "Цвет добавлен и выбран для приёмки." : "Привязка товара сохранена."), await _();
    } catch (d) {
      a === h.current && p(d instanceof Error ? d.message : String(d));
    } finally {
      E(!1);
    }
  }
  async function X(e) {
    var ne;
    if (c || !u) return;
    E(!0), p("");
    const a = h.current, d = JSON.stringify({ clientId: i, body: e });
    ((ne = U.current) == null ? void 0 : ne.fingerprint) !== d && (U.current = { fingerprint: d, key: crypto.randomUUID() });
    try {
      const N = await T(F, { method: "POST", accessToken: y, body: { ...e, version: u.version, operationKey: U.current.key } });
      a === h.current && (g(N), U.current = null, B(e.action === "RECEIVE" ? "Рулоны приняты." : "Операция с рулоном сохранена."));
    } catch (N) {
      a === h.current && p(N instanceof Error ? N.message : String(N));
    } finally {
      E(!1);
    }
  }
  async function ve() {
    if (c) return;
    E(!0), p("");
    const e = h.current;
    try {
      const a = await T(F, { method: "PUT", accessToken: y, body: { enabled: !0 } });
      e === h.current && g(a);
    } catch (a) {
      e === h.current && p(a instanceof Error ? a.message : String(a));
    } finally {
      E(!1);
    }
  }
  const ge = [...Object.entries((f == null ? void 0 : f.baseColors) ?? {}).map(([e, a]) => ({ id: e, name: a })), ...(f == null ? void 0 : f.colors.filter((e) => e.material === I)) ?? []];
  return /* @__PURE__ */ t("section", { className: "warehouse-panel fabric-warehouse", "aria-label": "Ткани: хранение и учёт", children: [
    /* @__PURE__ */ r("h2", { children: "Ткани: хранение и учёт" }),
    /* @__PURE__ */ t("label", { children: [
      "Клиент",
      /* @__PURE__ */ t("select", { value: i, disabled: c, onChange: (e) => m(e.target.value), children: [
        /* @__PURE__ */ r("option", { value: "", children: "Выберите клиента" }),
        o.map((e) => /* @__PURE__ */ r("option", { value: e.id, children: e.name }, e.id))
      ] })
    ] }),
    J ? /* @__PURE__ */ r("p", { role: "alert", children: J }) : null,
    K ? /* @__PURE__ */ r("p", { role: "status", children: K }) : null,
    i ? /* @__PURE__ */ r("button", { type: "button", disabled: c, onClick: () => void _(), children: "Обновить" }) : null,
    u && !u.enabled ? /* @__PURE__ */ t("div", { children: [
      /* @__PURE__ */ r("p", { children: "Рулонный учёт у клиента выключен." }),
      pe ? /* @__PURE__ */ r("button", { disabled: c, onClick: () => void ve(), children: "Включить «Товар в рулонах»" }) : /* @__PURE__ */ r("p", { children: "Для включения обратитесь к администратору." })
    ] }) : null,
    u != null && u.enabled && f ? /* @__PURE__ */ t(L, { children: [
      /* @__PURE__ */ r("p", { children: "Рулон — 100 м. Остатки рулонов и готовые отрезы учитываются отдельно." }),
      /* @__PURE__ */ r("div", { className: "warehouse-topic-grid", children: (Z = u.groups) == null ? void 0 : Z.map((e) => /* @__PURE__ */ t("article", { className: "warehouse-panel", children: [
        /* @__PURE__ */ t("h3", { children: [
          re[e.material],
          " · ",
          e.colorName
        ] }),
        /* @__PURE__ */ t("p", { children: [
          "Целых: ",
          e.whole,
          " · открытых: ",
          e.open,
          " · в рулонах: ",
          e.rawMeters.toLocaleString("ru-RU"),
          " м"
        ] }),
        /* @__PURE__ */ t("p", { children: [
          "Объём хранения: ",
          e.rawLiters.toLocaleString("ru-RU"),
          " л"
        ] }),
        /* @__PURE__ */ t("p", { children: [
          "Готовые отрезы: ",
          e.ready.reduce((a, d) => a + d.pieces, 0),
          " шт."
        ] }),
        /* @__PURE__ */ t("p", { children: [
          "FBS: ",
          e.fbs.pieces,
          " отрезов / ",
          e.fbs.meters,
          " м · FBO: ",
          e.fbo.pieces,
          " отрезов / ",
          e.fbo.meters,
          " м"
        ] }),
        /* @__PURE__ */ t("details", { children: [
          /* @__PURE__ */ r("summary", { children: "Остаток каждого рулона" }),
          e.rolls.map((a) => /* @__PURE__ */ t("p", { children: [
            a.code,
            ": ",
            (a.remainingMm / 1e3).toLocaleString("ru-RU"),
            " м"
          ] }, a.id))
        ] })
      ] }, e.key)) }),
      be ? /* @__PURE__ */ t(L, { children: [
        /* @__PURE__ */ r("h3", { children: "Приёмка новых рулонов" }),
        /* @__PURE__ */ t("label", { children: [
          "Ткань",
          /* @__PURE__ */ r("select", { disabled: c, value: I, onChange: (e) => {
            C(e.target.value), b("black");
          }, children: Object.entries(re).map(([e, a]) => /* @__PURE__ */ r("option", { value: e, children: a }, e)) })
        ] }),
        /* @__PURE__ */ t("label", { children: [
          "Цвет",
          /* @__PURE__ */ r("select", { disabled: c, value: w, onChange: (e) => b(e.target.value), children: ge.map((e) => /* @__PURE__ */ r("option", { value: e.id, children: e.name }, e.id)) })
        ] }),
        /* @__PURE__ */ t("form", { onSubmit: (e) => {
          e.preventDefault(), V("CREATE_COLOR");
        }, children: [
          /* @__PURE__ */ t("label", { children: [
            "Новый цвет",
            /* @__PURE__ */ r("input", { value: x, maxLength: 80, disabled: c, onChange: (e) => $(e.target.value), placeholder: "Например, Пудровый" })
          ] }),
          /* @__PURE__ */ r("button", { disabled: c || !x.trim(), children: "Добавить цвет" })
        ] }),
        /* @__PURE__ */ t("form", { onSubmit: (e) => {
          e.preventDefault(), X({ action: "RECEIVE", material: I, color: w, count: R });
        }, children: [
          /* @__PURE__ */ t("label", { children: [
            "Количество рулонов",
            /* @__PURE__ */ r("input", { type: "number", min: 1, max: 500, step: 1, value: R, disabled: c, onChange: (e) => ae(Number(e.target.value)) })
          ] }),
          /* @__PURE__ */ r("button", { disabled: c || !Number.isInteger(R) || R < 1 || R > 500, children: "Принять рулоны" })
        ] }),
        /* @__PURE__ */ t("details", { children: [
          /* @__PURE__ */ r("summary", { children: "Операции с рулоном" }),
          /* @__PURE__ */ t("form", { onSubmit: (e) => {
            e.preventDefault(), X(v === "CUT" ? { action: v, rollId: A, barcode: z, boxCode: H, kiz: q, count: Q } : v === "ADJUST" ? { action: v, rollId: A, deltaMm: Math.round(G * 1e3), reason: D } : { action: v, rollId: A, reason: D });
          }, children: [
            /* @__PURE__ */ t("label", { children: [
              "Рулон",
              /* @__PURE__ */ t("select", { value: A, disabled: c, onChange: (e) => oe(e.target.value), children: [
                /* @__PURE__ */ r("option", { value: "", children: "Выберите рулон" }),
                (Y = u.groups) == null ? void 0 : Y.flatMap((e) => e.rolls).filter((e) => e.warehouseId === n.user.activeWarehouseId && e.remainingMm > 0).map((e) => /* @__PURE__ */ t("option", { value: e.id, children: [
                  e.code,
                  " · ",
                  e.remainingMm / 1e3,
                  " м"
                ] }, e.id))
              ] })
            ] }),
            /* @__PURE__ */ t("label", { children: [
              "Действие",
              /* @__PURE__ */ t("select", { value: v, disabled: c, onChange: (e) => ce(e.target.value), children: [
                /* @__PURE__ */ r("option", { value: "ADJUST", children: "Фактическая корректировка ±2 м" }),
                /* @__PURE__ */ r("option", { value: "CUT", children: "Нарезать готовые отрезы" }),
                /* @__PURE__ */ r("option", { value: "WRITE_OFF", children: "Списать остаток рулона" })
              ] })
            ] }),
            v === "CUT" ? /* @__PURE__ */ t(L, { children: [
              /* @__PURE__ */ t("label", { children: [
                "Штрихкод отреза",
                /* @__PURE__ */ r("input", { value: z, disabled: c, onChange: (e) => ue(e.target.value) })
              ] }),
              /* @__PURE__ */ t("label", { children: [
                "Короб готовых отрезов",
                /* @__PURE__ */ r("input", { value: H, disabled: c, onChange: (e) => he(e.target.value) })
              ] }),
              /* @__PURE__ */ t("label", { children: [
                "Количество отрезов",
                /* @__PURE__ */ r("input", { type: "number", min: 1, max: 500, step: 1, value: Q, disabled: c, onChange: (e) => fe(Number(e.target.value)) })
              ] }),
              /* @__PURE__ */ t("label", { children: [
                "КИЗ, по одному на строку",
                /* @__PURE__ */ r("textarea", { value: q, disabled: c, onChange: (e) => me(e.target.value) })
              ] })
            ] }) : /* @__PURE__ */ t(L, { children: [
              v === "ADJUST" ? /* @__PURE__ */ t("label", { children: [
                "Изменение, м",
                /* @__PURE__ */ r("input", { type: "number", min: -2, max: 2, step: 1e-3, value: G, disabled: c, onChange: (e) => se(Number(e.target.value)) })
              ] }) : /* @__PURE__ */ r("p", { children: "Будет списан весь остаток выбранного рулона." }),
              /* @__PURE__ */ t("label", { children: [
                "Причина",
                /* @__PURE__ */ r("input", { value: D, disabled: c, onChange: (e) => de(e.target.value) })
              ] })
            ] }),
            /* @__PURE__ */ r("button", { disabled: c || !A || v !== "CUT" && D.trim().length < 5, children: "Сохранить операцию с рулоном" })
          ] })
        ] }),
        /* @__PURE__ */ t("details", { children: [
          /* @__PURE__ */ r("summary", { children: "Привязка к товару маркетплейса" }),
          /* @__PURE__ */ r("p", { children: "Выберите ткань и цвет выше. Для каждой длины отреза привяжите соответствующую карточку товара WMS." }),
          /* @__PURE__ */ t("form", { onSubmit: (e) => {
            e.preventDefault(), V("BIND_SKU");
          }, children: [
            /* @__PURE__ */ t("label", { children: [
              "Товар",
              /* @__PURE__ */ t("select", { value: P, disabled: c, onChange: (e) => W(e.target.value), children: [
                /* @__PURE__ */ r("option", { value: "", children: "Выберите товар клиента" }),
                f.skus.map((e) => /* @__PURE__ */ t("option", { value: e.id, children: [
                  e.marketplace ?? "WMS",
                  " · ",
                  e.name,
                  " · ",
                  e.offerId ?? e.internalSku,
                  e.binding ? " · привязан" : ""
                ] }, e.id))
              ] })
            ] }),
            /* @__PURE__ */ t("label", { children: [
              "Длина отреза, м",
              /* @__PURE__ */ r("input", { type: "number", min: 1e-3, max: 100, step: 1e-3, value: k, disabled: c, onChange: (e) => le(Number(e.target.value)) })
            ] }),
            /* @__PURE__ */ r("button", { disabled: c || !P || !Number.isFinite(k) || k <= 0 || k > 100, children: "Сохранить привязку" })
          ] })
        ] })
      ] }) : null,
      /* @__PURE__ */ t("details", { children: [
        /* @__PURE__ */ r("summary", { children: "История рулонного учёта" }),
        (ee = u.history) == null ? void 0 : ee.map((e, a) => {
          var d;
          return /* @__PURE__ */ t("p", { children: [
            new Date(e.createdAt).toLocaleString("ru-RU"),
            " · ",
            e.action,
            " ",
            ((d = e.payload) == null ? void 0 : d.reason) ?? ""
          ] }, a);
        })
      ] })
    ] }) : null
  ] });
}
export {
  Me as FabricWarehousePanel
};
