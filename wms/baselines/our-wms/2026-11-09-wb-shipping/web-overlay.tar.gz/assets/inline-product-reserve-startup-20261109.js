// singleton:published-react
import { r as React } from "./admin-tiles-20261019-0.js";
var published_react_default = { createElement: (...args) => React.createElement(...args) };
var useEffect = (...args) => React.useEffect(...args);
var useRef = (...args) => React.useRef(...args);
var useState = (...args) => React.useState(...args);

// apps/web/src/lib/shared-read.ts
function createSharedRead() {
  const pending = /* @__PURE__ */ new Map();
  return function sharedRead2(key, read) {
    const current = pending.get(key);
    if (current) return current;
    const promise = Promise.resolve().then(read);
    pending.set(key, promise);
    const clear = () => {
      if (pending.get(key) === promise) pending.delete(key);
    };
    void promise.then(clear, clear);
    return promise;
  };
}
var sharedRead = createSharedRead();

// apps/web/src/lib/api.ts
var API_BASE_URL = "/api/v1";
async function fetchFbsStockAllocation(accessToken, clientId, connectionId) {
  return request(
    withQuery("/marketplace-connections/fbs/stocks/allocation", { clientId, connectionId }),
    { accessToken }
  );
}
async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: options.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      ...options.accessToken ? { Authorization: `Bearer ${options.accessToken}` } : {}
    },
    body: options.body ? JSON.stringify(options.body) : void 0
  });
  if (!response.ok) {
    const detail = await response.json().catch(() => null);
    const error = new Error(await responseError(response, detail));
    if (detail?.code === "KIZ_DUPLICATE" && detail.duplicateInfo && typeof detail.duplicateInfo === "object") {
      Object.assign(error, { code: detail.code, duplicate: true, duplicateInfo: detail.duplicateInfo });
    }
    throw error;
  }
  return await response.json();
}
function withQuery(path, params) {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== void 0 && value !== "" && value !== false) {
      search.set(key, String(value));
    }
  });
  const query = search.toString();
  return query ? `${path}?${query}` : path;
}
async function responseError(response, parsed) {
  try {
    const payload = parsed === void 0 ? await response.json() : parsed;
    if (Array.isArray(payload?.message)) {
      return payload.message.join("\n");
    }
    return payload?.message || `HTTP ${response.status}`;
  } catch {
    return `HTTP ${response.status}`;
  }
}
async function fetchFbsProductReserve(accessToken, clientId, connectionId, skuId) {
  const data = await fetchFbsStockAllocation(accessToken, clientId, connectionId);
  const row = data.analysis?.rows.find((item) => item.skuId === skuId);
  if (!row || typeof row.blocked !== "boolean" || row.ruleUpdatedAt !== null && typeof row.ruleUpdatedAt !== "string") throw new Error("\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u044D\u0442\u043E\u0433\u043E \u0442\u043E\u0432\u0430\u0440\u0430 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u043E\u0441\u0442\u0430\u0442\u043A\u0438.");
  return { row, inherited: data.reserve };
}
async function saveFbsProductReserve(accessToken, clientId, row, reserve) {
  return request("/administration/marketplace-stock-control/" + encodeURIComponent(clientId) + "/skus/" + encodeURIComponent(row.skuId), {
    accessToken,
    method: "PUT",
    body: { reserve, blocked: row.blocked, expectedUpdatedAt: row.ruleUpdatedAt }
  });
}

// apps/web/src/components/fbs/FbsProductReserve.tsx
function validProductReserve(mode, value, lowStock) {
  return Number.isSafeInteger(value) && value >= 0 && value <= (mode === "PERCENT" ? 100 : 1e6) && (!lowStock || Number.isSafeInteger(lowStock.threshold) && lowStock.threshold >= 1 && lowStock.threshold <= 1e6 && Number.isSafeInteger(lowStock.reserveUnits) && lowStock.reserveUnits >= 0 && lowStock.reserveUnits <= 1e6);
}
function FbsProductReserve({ session, clientId, connectionId, skuId, onSaved }) {
  const [row, setRow] = useState(null), [mode, setMode] = useState("INHERIT"), [value, setValue] = useState(0);
  const [low, setLow] = useState(), [busy, setBusy] = useState(false), [error, setError] = useState(""), [message, setMessage] = useState("");
  const alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);
  const u = session.user;
  const allowed = !u.isDemo && (u.roleCodes.includes("CLIENT") ? u.permissionCodes.includes("stock:read") && u.clientIds.includes(clientId) && u.writableClientIds.includes(clientId) : u.permissionCodes.includes("system:admin"));
  async function load() {
    setBusy(true);
    setError("");
    try {
      const result = await fetchFbsProductReserve(session.accessToken, clientId, connectionId, skuId);
      if (!alive.current) return;
      setRow(result.row);
      setMode(result.row.reserveOverride?.mode ?? "INHERIT");
      setValue(result.row.reserveOverride?.value ?? 0);
      setLow(result.row.reserveOverride?.lowStock);
    } catch (e) {
      if (alive.current) setError(e instanceof Error ? e.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0440\u0435\u0437\u0435\u0440\u0432.");
    } finally {
      if (alive.current) setBusy(false);
    }
  }
  async function save() {
    if (!row || busy) return;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      await saveFbsProductReserve(session.accessToken, clientId, row, mode === "INHERIT" ? null : { mode, value: mode === "NONE" ? 0 : value, ...mode !== "NONE" && low ? { lowStock: low } : {} });
      if (!alive.current) return;
      await onSaved();
      if (!alive.current) return;
      await load();
      if (alive.current) setMessage("\u0420\u0435\u0437\u0435\u0440\u0432 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u0414\u043B\u044F \u0443\u0432\u0435\u043B\u0438\u0447\u0435\u043D\u0438\u044F \u043E\u0441\u0442\u0430\u0442\u043A\u0430 WB \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043F\u0440\u043E\u0434\u0430\u0436\u0443\xBB.");
    } catch (e) {
      if (alive.current) setError(e instanceof Error ? e.message : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0440\u0435\u0437\u0435\u0440\u0432.");
    } finally {
      if (alive.current) setBusy(false);
    }
  }
  if (!allowed || !connectionId) return null;
  return /* @__PURE__ */ published_react_default.createElement("details", { className: "fbs-product-reserve", onToggle: (e) => {
    if (e.currentTarget.open && !row && !busy) void load();
  } }, /* @__PURE__ */ published_react_default.createElement("summary", { "aria-label": `\u0421\u0442\u0440\u0430\u0445\u043E\u0432\u043E\u0439 \u0440\u0435\u0437\u0435\u0440\u0432 \u0442\u043E\u0432\u0430\u0440\u0430 ${skuId}` }, "\u0421\u0442\u0440\u0430\u0445\u043E\u0432\u043E\u0439 \u0440\u0435\u0437\u0435\u0440\u0432 \u0442\u043E\u0432\u0430\u0440\u0430"), busy && !row ? /* @__PURE__ */ published_react_default.createElement("p", null, "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u044E \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0443\u2026") : row ? /* @__PURE__ */ published_react_default.createElement("div", null, /* @__PURE__ */ published_react_default.createElement("label", null, "\u0420\u0435\u0437\u0435\u0440\u0432 \u0442\u043E\u0432\u0430\u0440\u0430", /* @__PURE__ */ published_react_default.createElement("select", { "aria-label": "\u0420\u0435\u0437\u0435\u0440\u0432 \u0442\u043E\u0432\u0430\u0440\u0430", value: mode, disabled: busy, onChange: (e) => setMode(e.target.value) }, /* @__PURE__ */ published_react_default.createElement("option", { value: "INHERIT" }, "\u041A\u0430\u043A \u0443 \u043A\u043B\u0438\u0435\u043D\u0442\u0430"), /* @__PURE__ */ published_react_default.createElement("option", { value: "NONE" }, "\u0411\u0435\u0437 \u0440\u0435\u0437\u0435\u0440\u0432\u0430"), /* @__PURE__ */ published_react_default.createElement("option", { value: "UNITS" }, "\u0412 \u0448\u0442\u0443\u043A\u0430\u0445"), /* @__PURE__ */ published_react_default.createElement("option", { value: "PERCENT" }, "\u0412 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u0430\u0445"))), (mode === "UNITS" || mode === "PERCENT") && /* @__PURE__ */ published_react_default.createElement("label", null, "\u0412\u0435\u043B\u0438\u0447\u0438\u043D\u0430 \u0440\u0435\u0437\u0435\u0440\u0432\u0430", /* @__PURE__ */ published_react_default.createElement("input", { "aria-label": "\u0412\u0435\u043B\u0438\u0447\u0438\u043D\u0430 \u0440\u0435\u0437\u0435\u0440\u0432\u0430", type: "number", min: 0, max: mode === "PERCENT" ? 100 : 1e6, step: 1, value, disabled: busy, onChange: (e) => setValue(Number(e.target.value)) })), (mode === "UNITS" || mode === "PERCENT") && /* @__PURE__ */ published_react_default.createElement(published_react_default.Fragment, null, /* @__PURE__ */ published_react_default.createElement("label", null, /* @__PURE__ */ published_react_default.createElement("input", { type: "checkbox", checked: !!low, disabled: busy, onChange: (e) => setLow(e.target.checked ? { threshold: 5, reserveUnits: 1 } : void 0) }), "\u041E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u0440\u0435\u0437\u0435\u0440\u0432 \u043F\u0440\u0438 \u043C\u0430\u043B\u043E\u043C \u043E\u0441\u0442\u0430\u0442\u043A\u0435"), low && /* @__PURE__ */ published_react_default.createElement(published_react_default.Fragment, null, /* @__PURE__ */ published_react_default.createElement("label", null, "\u041F\u0440\u0438 \u043E\u0441\u0442\u0430\u0442\u043A\u0435 \u043C\u0435\u043D\u044C\u0448\u0435", /* @__PURE__ */ published_react_default.createElement("input", { type: "number", min: 1, step: 1, value: low.threshold, disabled: busy, onChange: (e) => setLow({ ...low, threshold: Number(e.target.value) }) })), /* @__PURE__ */ published_react_default.createElement("label", null, "\u041E\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C, \u0448\u0442.", /* @__PURE__ */ published_react_default.createElement("input", { type: "number", min: 0, step: 1, value: low.reserveUnits, disabled: busy, onChange: (e) => setLow({ ...low, reserveUnits: Number(e.target.value) }) })))), /* @__PURE__ */ published_react_default.createElement("button", { type: "button", disabled: busy || !validProductReserve(mode, mode === "NONE" || mode === "INHERIT" ? 0 : value, mode === "NONE" || mode === "INHERIT" ? void 0 : low), onClick: () => void save() }, "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0440\u0435\u0437\u0435\u0440\u0432 \u0442\u043E\u0432\u0430\u0440\u0430")) : null, error && /* @__PURE__ */ published_react_default.createElement("p", { role: "alert" }, error, " ", /* @__PURE__ */ published_react_default.createElement("button", { type: "button", disabled: busy, onClick: () => void load() }, "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0443")), message && /* @__PURE__ */ published_react_default.createElement("p", { role: "status" }, message));
}
export {
  FbsProductReserve,
  validProductReserve
};
