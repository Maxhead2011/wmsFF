"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prepareMissingOzonGtd = prepareMissingOzonGtd;
const common_1 = require("@nestjs/common");
// FIX: user-authorized own-WMS policy: blank required GTD means absent; never replace an existing number or other exemplar fields.
async function prepareMissingOzonGtd(posting, headers, json, pause = ms => new Promise(resolve => setTimeout(resolve, ms))) {
    const required = new Set((posting.requirements?.products_requiring_gtd ?? []).map(String));
    if (!required.size)
        return [];
    const signal = AbortSignal.timeout(30000), call = (path, body) => { signal.throwIfAborted(); return json('https://api-seller.ozon.ru' + path, { method: 'POST', headers, body: JSON.stringify(body), signal }); };
    const current = await call('/v6/fbs/posting/product/exemplar/create-or-get', { posting_number: posting.posting_number });
    if (current.posting_number !== posting.posting_number || !Array.isArray(current.products))
        throw new common_1.BadRequestException('Ozon вернул другой состав экземпляров.');
    const products = [], changed = [];
    for (const id of required) {
        const line = posting.products.filter((p) => String(p.sku) === id), matches = current.products.filter((p) => String(p.product_id) === id);
        if (line.length !== 1 || matches.length !== 1 || !Array.isArray(matches[0].exemplars) || matches[0].exemplars.length !== line[0].quantity)
            throw new common_1.BadRequestException('Изменился состав экземпляров Ozon. Обновите отправление и повторите подготовку.');
        const product = matches[0], seen = new Set();
        let dirty = false;
        const exemplars = product.exemplars.map((e) => {
            if (!Number.isSafeInteger(e.exemplar_id) || e.exemplar_id <= 0 || seen.has(e.exemplar_id))
                throw new common_1.BadRequestException('Ozon вернул некорректный состав экземпляров.');
            seen.add(e.exemplar_id);
            if (String(e.gtd ?? '').trim() || e.is_gtd_absent === true)
                return { ...e };
            dirty = true;
            changed.push({ productId: product.product_id, exemplarId: e.exemplar_id });
            return { ...e, gtd: e.gtd ?? '', is_gtd_absent: true };
        });
        if (dirty)
            products.push({ product_id: product.product_id, exemplars });
    }
    if (!changed.length)
        return [];
    await call('/v6/fbs/posting/product/exemplar/set', { posting_number: posting.posting_number, multi_box_qty: current.multi_box_qty, products });
    for (let attempt = 0; attempt < 8; attempt++) {
        if (attempt)
            await pause(500);
        const status = await call('/v5/fbs/posting/product/exemplar/status', { posting_number: posting.posting_number });
        const ready = changed.every(c => { const rows = (status.products ?? []).filter((p) => p.product_id === c.productId).flatMap((p) => p.exemplars ?? []).filter((e) => e.exemplar_id === c.exemplarId); if (rows.length !== 1)
            return false; const e = rows[0]; if (e.gtd_check_status === 'failed' || e.gtd_error_codes?.length)
            throw new common_1.BadRequestException(`Ozon отклонил признак отсутствия ГТД для отправления ${posting.posting_number}. Проверьте сведения об экземплярах.`); return e.is_gtd_absent === true && e.gtd_check_status === 'passed'; });
        if (ready)
            return changed.map(c => c.exemplarId);
    }
    throw new common_1.ConflictException(`Ozon ещё проверяет отсутствие ГТД для отправления ${posting.posting_number}. Повторите подготовку через несколько секунд.`);
}
