"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isOzonPrintPrepared = isOzonPrintPrepared;
exports.decorateOzonPrintPrepared = decorateOzonPrintPrepared;
exports.hasOzonPrintPreparation = hasOzonPrintPreparation;
exports.prepareOzonPrint = prepareOzonPrint;
const common_1 = require("@nestjs/common");
const ozon_gtd_absence_1 = require("./ozon-gtd-absence");
const enabled = () => process.env.WMS_FBS_UNMARKED_PAIRED_LABELS_ENABLED === 'true';
const key = (clientId, connectionId, orderId) => 'ozon.print-preparation.v1:' + JSON.stringify([clientId, connectionId, orderId]);
function composition(posting) {
    if (!Array.isArray(posting.products) || !posting.products.length)
        throw new common_1.BadRequestException('Ozon не вернул состав заказа.');
    const rows = posting.products.map((p) => ({ product_id: Number(p.sku), quantity: p.quantity }));
    if (rows.some((p) => !Number.isSafeInteger(p.product_id) || p.product_id < 1 || !Number.isSafeInteger(p.quantity) || p.quantity < 1) || new Set(rows.map((p) => p.product_id)).size !== rows.length)
        throw new common_1.BadRequestException('Некорректный состав заказа Ozon.');
    return rows.sort((a, b) => a.product_id - b.product_id);
}
// FIX: a preparation intent is separate from physical picking and survives a lost Ozon response.
async function isOzonPrintPrepared(db, clientId, connectionId, orderId, posting, requestId) {
    if (!enabled() || posting.status !== 'awaiting_deliver')
        return false;
    const saved = await db.systemSetting.findUnique({ where: { key: key(clientId, connectionId, orderId) } });
    try {
        return !!saved?.value?.requestId && (!requestId || saved.value.requestId === requestId) && JSON.stringify(saved.value.products) === JSON.stringify(composition(posting));
    }
    catch {
        return false;
    }
}
async function decorateOzonPrintPrepared(db, clientId, orders) {
    if (!enabled())
        return;
    const candidates = orders.filter(o => o.marketplace === 'OZON' && o.supplierStatus === 'awaiting_deliver');
    if (!candidates.length)
        return;
    const records = await db.systemSetting.findMany({ where: { key: { in: candidates.map(o => key(clientId, o.connectionId, o.id)) } } });
    const byKey = new Map(records.map((r) => [r.key, r.value]));
    for (const o of candidates) {
        const saved = byKey.get(key(clientId, o.connectionId, o.id));
        if (saved?.requestId && saved.requestId === o.request?.id)
            o.ozonPrintPrepared = true;
    }
}
async function hasOzonPrintPreparation(db, clientId, connectionId, orderId, requestId) {
    if (!enabled())
        return false;
    return (await db.systemSetting.findUnique({ where: { key: key(clientId, connectionId, orderId) } }))?.value?.requestId === requestId;
}
// FIX: only the explicit print action may prepare Ozon; no fabricated scans, stock or completed tasks.
async function prepareOzonPrint(db, clientId, selections, user, json) {
    if (!enabled())
        throw new common_1.BadRequestException('Подготовка этикеток до отбора не включена.');
    // Same advisory identities as the published manual/background assembly lock.
    return db.$transaction(async (tx) => {
        for (const id of [...new Set(selections.map(s => `${s.connectionId}:${s.id}`))].sort()) {
            const lockKey = `fbs-assembly:${clientId}:${id}`;
            const rows = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${lockKey})) AS locked`;
            if (!rows[0]?.locked)
                throw new common_1.ConflictException('Для выбранного заказа уже выполняется подготовка. Повторите печать позже.');
        }
        return prepareUnlocked(db, clientId, selections, user, json);
    }, { timeout: 600000, maxWait: 5000 });
}
async function prepareUnlocked(db, clientId, selections, user, json) {
    const selected = [...new Map(selections.map(s => [JSON.stringify([s.connectionId, s.id]), s])).values()];
    if (!selected.length || selected.length > 1000)
        throw new common_1.BadRequestException('Выберите заказы Ozon.');
    const connections = await db.clientMarketplaceConnection.findMany({ where: { clientId, isActive: true, id: { in: [...new Set(selected.map(s => s.connectionId))] } } });
    if (connections.length !== new Set(selected.map(s => s.connectionId)).size || connections.some((c) => c.marketplace !== 'OZON' || !c.sellerId))
        throw new common_1.BadRequestException('Кабинет Ozon не найден.');
    const links = await db.fbsOrderRequestLink.findMany({ where: { clientId, marketplace: 'OZON', OR: selected.map(s => ({ connectionId: s.connectionId, orderId: s.id })) }, include: { request: { select: { status: true, warehouseId: true } } } });
    const plans = [];
    // Preflight every selected order before the first remote mutation.
    for (const s of selected) {
        const c = connections.find((c) => c.id === s.connectionId);
        const l = links.find((l) => l.connectionId === s.connectionId && l.orderId === s.id);
        if (!l || l.syncStatus !== 'ACTIVE' || !['SUBMITTED', 'IN_REVIEW', 'APPROVED', 'IN_WORK', 'PACKED'].includes(l.request.status) || !user.activeWarehouseId || l.request.warehouseId !== user.activeWarehouseId)
            throw new common_1.BadRequestException(`Заказ ${s.id} недоступен в открытой заявке выбранного филиала.`);
        const headers = { 'Client-Id': c.sellerId, 'Api-Key': c.apiKey, 'Content-Type': 'application/json' };
        const response = await json('https://api-seller.ozon.ru/v3/posting/fbs/get', { method: 'POST', headers, body: JSON.stringify({ posting_number: s.id, with: { barcodes: true } }), signal: AbortSignal.timeout(20000) });
        const posting = response.result ?? response;
        if (posting.posting_number !== s.id)
            throw new common_1.BadRequestException('Ozon вернул другой номер заказа.');
        if (!['awaiting_packaging', 'awaiting_deliver'].includes(posting.status))
            throw new common_1.BadRequestException(`Заказ ${s.id} уже передан или недоступен для сборки.`);
        if (posting.is_multibox)
            throw new common_1.BadRequestException(`Заказ ${s.id} требует отдельной проверки мест.`);
        const products = composition(posting);
        plans.push({ s, headers, posting, products, requestId: l.requestId, requiresPhysicalSubmission: !!posting.requirements?.products_requiring_mandatory_mark?.length });
    }
    for (const plan of plans) {
        const { s, headers, posting, products, requestId } = plan;
        if (posting.status === 'awaiting_packaging' && !plan.requiresPhysicalSubmission) {
            const gtdExemplars = await (0, ozon_gtd_absence_1.prepareMissingOzonGtd)(posting, headers, json);
            if (gtdExemplars.length)
                await db.auditLog.create({ data: { userId: user.id, action: 'OZON_GTD_ABSENCE_CONFIRMED', entity: 'ClientRequest', entityId: requestId, payload: { orderId: s.id, connectionId: s.connectionId, exemplarIds: gtdExemplars, reason: 'User-configured empty GTD policy', otherExemplarFieldsPreserved: true } } });
            const value = { requestId, products, preparedBy: user.id, preparedAt: new Date().toISOString() };
            const settingKey = key(clientId, s.connectionId, s.id);
            await db.systemSetting.upsert({ where: { key: settingKey }, create: { key: settingKey, value }, update: { value } });
            await db.auditLog.create({ data: { userId: user.id, action: 'OZON_LABEL_PREPARATION_REQUESTED', entity: 'ClientRequest', entityId: requestId, payload: { orderId: s.id, connectionId: s.connectionId, products } } });
            try {
                await json('https://api-seller.ozon.ru/v4/posting/fbs/ship', { method: 'POST', headers, body: JSON.stringify({ posting_number: s.id, packages: [{ products }], with: { additional_data: true } }), signal: AbortSignal.timeout(30000) });
                // FIX: Ozon may acknowledge ship before its label status becomes available.
                const readySignal = AbortSignal.timeout(15000);
                let ready = false;
                for (let attempt = 0; attempt < 8; attempt++) {
                    if (attempt)
                        await new Promise(resolve => setTimeout(resolve, 750));
                    readySignal.throwIfAborted();
                    const current = await json('https://api-seller.ozon.ru/v3/posting/fbs/get', { method: 'POST', headers, body: JSON.stringify({ posting_number: s.id }), signal: readySignal });
                    const actual = current.result ?? current;
                    if (actual.posting_number !== s.id)
                        throw new common_1.BadRequestException('Ozon вернул другой номер заказа.');
                    if (actual.status === 'awaiting_deliver') {
                        ready = true;
                        break;
                    }
                    if (actual.status !== 'awaiting_packaging')
                        throw new common_1.ConflictException(`Статус отправления ${s.id} изменился в Ozon. Обновите заявку перед печатью.`);
                }
                if (!ready)
                    throw new common_1.ConflictException(`Ozon принял подготовку отправления ${s.id}, но ещё не разрешил стикеры. Повторите печать через несколько секунд.`);
            }
            catch (error) {
                // FIX: explain the rejected selected posting; requirements alone never block already completed exemplar data.
                if (error instanceof Error && error.message.includes('EXEMPLAR_INFO_NOT_FILLED_COMPLETELY')) {
                    const fields = { products_requiring_gtd: 'ГТД', products_requiring_rnpt: 'РНПТ', products_requiring_country: 'страна происхождения', products_requiring_mandatory_mark: 'КИЗ', products_requiring_imei: 'IMEI', products_requiring_weight: 'вес', products_requiring_jw_uin: 'УИН' };
                    const details = Object.entries(fields).flatMap(([field, label]) => (posting.requirements?.[field] ?? []).map((id) => { const product = posting.products.find((p) => String(p.sku) === String(id)); return `${product?.offer_id || id}: ${label}`; }));
                    throw new common_1.BadRequestException(`Отправление ${s.id}: Ozon не разрешил подготовить стикеры — не заполнены сведения об экземплярах товара.${details.length ? ' Требуются ' + details.join('; ') + '.' : ''} Заполните сведения в кабинете Ozon и повторите печать. Для отсутствующей ГТД нужен явный признак «ГТД отсутствует», а не пустое поле. Код: EXEMPLAR_INFO_NOT_FILLED_COMPLETELY.`);
                }
                throw error;
            }
        }
    }
    const requiresPhysicalSubmission = plans.filter(p => p.requiresPhysicalSubmission && p.posting.status === 'awaiting_packaging').map(p => p.s);
    return { prepared: plans.length - requiresPhysicalSubmission.length, orderIds: plans.filter(p => !requiresPhysicalSubmission.includes(p.s)).map(p => p.s.id), requiresPhysicalSubmission };
}
