"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonPostingLabelPages = ozonPostingLabelPages;
const common_1 = require("@nestjs/common");
const pdf_lib_1 = require("pdf-lib");
const pdf_parse_1 = require("pdf-parse");
const compact = (s) => String(s ?? '').replace(/\s+/g, '');
// FIX: Ozon's own PDF may contain product barcode pages; only proven shipment labels belong to cargo mode.
async function ozonPostingLabelPages(buffer, postings) {
    const parser = new pdf_parse_1.PDFParse({ data: buffer });
    let texts;
    try {
        texts = (await parser.getText()).pages.map(p => compact(p.text));
    }
    finally {
        await parser.destroy();
    }
    const matches = postings.map(p => { const keys = [p.posting_number, p.scanit, p.barcodes?.upper_barcode, p.barcodes?.lower_barcode].map(compact).filter(Boolean); return texts.flatMap((t, i) => keys.some(k => t.includes(k)) ? [i] : []); });
    if (!postings.length || matches.some(p => !p.length))
        throw new common_1.BadRequestException('В PDF Ozon не удалось подтвердить стикеры всех выбранных отправлений. Печать грузомест остановлена, чтобы не выдать неверный комплект.');
    const indices = [...new Set(matches.flat())].sort((a, b) => a - b), source = await pdf_lib_1.PDFDocument.load(buffer);
    if (texts.length !== source.getPageCount())
        throw new common_1.BadRequestException('Не удалось проверить страницы PDF Ozon.');
    const output = await pdf_lib_1.PDFDocument.create();
    (await output.copyPages(source, indices)).forEach(p => output.addPage(p));
    return Buffer.from(await output.save());
}
