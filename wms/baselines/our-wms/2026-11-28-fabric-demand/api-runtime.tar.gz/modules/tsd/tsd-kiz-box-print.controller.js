"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdKizBoxPrintController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const tsd_kiz_box_print_service_1 = require("./tsd-kiz-box-print.service");
class Lookup {
    kiz;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1024),
    __metadata("design:type", String)
], Lookup.prototype, "kiz", void 0);
class Print extends Lookup {
    stationId;
    printId;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(160),
    __metadata("design:type", String)
], Print.prototype, "stationId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], Print.prototype, "printId", void 0);
let TsdKizBoxPrintController = class TsdKizBoxPrintController {
    service;
    constructor(service) {
        this.service = service;
    }
    stations(u) { return this.service.stations(u); }
    lookup(b, u) { return this.service.lookup(b.kiz, u); }
    create(b, u) { return this.service.create(b, u); }
    status(id, u) { return this.service.status(id, u); }
};
exports.TsdKizBoxPrintController = TsdKizBoxPrintController;
__decorate([
    (0, common_1.Get)('stations'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], TsdKizBoxPrintController.prototype, "stations", null);
__decorate([
    (0, common_1.Post)('lookup'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Lookup, Object]),
    __metadata("design:returntype", void 0)
], TsdKizBoxPrintController.prototype, "lookup", null);
__decorate([
    (0, common_1.Post)('jobs'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Print, Object]),
    __metadata("design:returntype", void 0)
], TsdKizBoxPrintController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('jobs/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], TsdKizBoxPrintController.prototype, "status", null);
exports.TsdKizBoxPrintController = TsdKizBoxPrintController = __decorate([
    (0, common_1.Controller)('tsd/kiz-box-print'),
    __metadata("design:paramtypes", [typeof (_a = typeof tsd_kiz_box_print_service_1.TsdKizBoxPrintService !== "undefined" && tsd_kiz_box_print_service_1.TsdKizBoxPrintService) === "function" ? _a : Object])
], TsdKizBoxPrintController);
