"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdKizBoxPrintService = exports.KIZ_BOX_PRINT_SOURCE = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const stock_operations_service_1 = require("../stock/stock-operations.service");
const tsd_kiz_box_label_1 = require("./tsd-kiz-box-label");
exports.KIZ_BOX_PRINT_SOURCE = 'TSD_KIZ_BOX_LABELS';
// FIX: printing-only worker access; never elevate access to administrative KIZ decisions.
let TsdKizBoxPrintService = class TsdKizBoxPrintService {
    prisma;
    clients;
    constructor(prisma, clients) {
        this.prisma = prisma;
        this.clients = clients;
    }
    scope(user) {
        if (process.env.WMS_TSD_KIZ_BOX_PRINT_ENABLED !== 'true' || user.isDemo)
            throw new common_1.ForbiddenException('Печать по КИЗ недоступна.');
        const wh = user.activeWarehouseId;
        if (!wh)
            throw new common_1.BadRequestException('Сначала выберите филиал.');
        if (!user.permissionCodes.includes('system:admin') && !user.warehouseIds?.includes(wh))
            throw new common_1.ForbiddenException('Нет доступа к филиалу.');
        return wh;
    }
    identity(value) {
        const parsed = typeof value === 'string' && value.length <= 1024 ? (0, stock_operations_service_1.storageBoxTransferKizIdentity)(value.trim()) : null;
        if (!parsed)
            throw new common_1.BadRequestException('Отсканируйте КИЗ Data Matrix.');
        return { parsed, key: `01${parsed.gtin}21${parsed.serial}` };
    }
    async lookup(kiz, user, db = this.prisma) {
        const warehouseId = this.scope(user), { parsed, key } = this.identity(kiz), clientId = this.clients.resolveClientFilter(user);
        const prefixes = [key, ']d2' + key, ']D2' + key, `(01)${parsed.gtin}(21)${parsed.serial}`, `01${parsed.gtin}\u001d21${parsed.serial}`, `]d201${parsed.gtin}\u001d21${parsed.serial}`, `01${parsed.gtin}<GS>21${parsed.serial}`, `]d201${parsed.gtin}<GS>21${parsed.serial}`];
        const records = await db.productMark.findMany({ where: { clientId, AND: [{ OR: prefixes.map(value => ({ value: { startsWith: value } })) }, { OR: [{ box: { warehouseId } }, { boxId: null, stockMovement: { warehouseId } }] }] }, include: { box: { include: { pallet: true } } }, take: 51 });
        if (records.length > 50)
            throw new common_1.ConflictException('Найдено несколько привязок КИЗ. Обратитесь к администратору.');
        const marks = records.filter((m) => { const p = (0, stock_operations_service_1.storageBoxTransferKizIdentity)(m.value); return p?.gtin === parsed.gtin && p.serial === parsed.serial; });
        if (!marks.length)
            throw new common_1.NotFoundException('КИЗ не найден в системе.');
        if (marks.length !== 1)
            throw new common_1.ConflictException('Найдено несколько привязок КИЗ. Обратитесь к администратору.');
        const m = marks[0], b = m.box;
        if (!b || b.status !== 'active' || b.clientId !== m.clientId || b.warehouseId !== warehouseId)
            throw new common_1.ConflictException('КИЗ найден, но действующий короб не указан.');
        this.clients.requireClientAccess(user, m.clientId, 'read');
        const placements = await db.storagePalletBox.findMany({ where: { OR: [{ boxId: b.id }, { boxId: null, boxCode: b.code }], pallet: { clientId: m.clientId, warehouseId } }, include: { pallet: true } });
        const codes = [...new Set(placements.map((p) => p.pallet.code))];
        if (codes.length > 1)
            throw new common_1.ConflictException('Найдено несколько размещений короба. Обратитесь к администратору.');
        const legacy = b.pallet?.clientId === m.clientId && b.pallet?.warehouseId === warehouseId ? b.pallet.code : null;
        const palletCode = codes[0] || legacy;
        if (!palletCode)
            throw new common_1.ConflictException('Короб найден, но паллет-сорт не указан.');
        return { identity: key, markId: m.id, clientId: m.clientId, warehouseId, boxId: b.id, boxCode: b.code, palletCode: String(palletCode) };
    }
    async stations(user) { this.scope(user); return this.prisma.fbsPrintStation.findMany({ where: { enabled: true, labelWidthMm: 58, labelHeightMm: 40, lastSeenAt: { gt: new Date(Date.now() - 45000) } }, select: { id: true, name: true, printerName: true }, orderBy: { name: 'asc' } }); }
    owned(job, user, kiz, stationId) {
        if (!job || job.source !== exports.KIZ_BOX_PRINT_SOURCE || job.requestedById !== user.id || job.requestId !== this.scope(user))
            throw new common_1.NotFoundException('Задание печати не найдено.');
        this.clients.requireClientAccess(user, job.assemblyId, 'read');
        if (kiz && job.kiz !== this.identity(kiz).key || stationId && stationId !== job.stationId)
            throw new common_1.ConflictException('Идентификатор уже использован для другой печати.');
        return { printId: job.historyId, status: job.status, stationId: job.stationId, boxCode: job.stickerCode, palletCode: job.productName, error: job.errorMessage, printedAt: job.printedAt };
    }
    async create(body, user) {
        this.scope(user);
        this.identity(body.kiz);
        if (!/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(body.printId) || !body.stationId || body.stationId.length > 160)
            throw new common_1.BadRequestException('Некорректное задание печати.');
        const existing = await this.prisma.fbsPrintJob.findUnique({ where: { historyId: body.printId } });
        if (existing)
            return this.owned(existing, user, body.kiz, body.stationId);
        if (!(await this.stations(user)).some(s => s.id === body.stationId))
            throw new common_1.ConflictException('Выбранный принтер недоступен или не настроен на 58 × 40 мм.');
        const found = await this.lookup(body.kiz, user), image = await (0, tsd_kiz_box_label_1.buildKizBoxLabel)(found.boxCode, 'КОРОБ');
        try {
            return await this.prisma.$transaction(async (tx) => {
                // FIX: reject changed placement rather than print a stale location.
                const now = await this.lookup(body.kiz, user, tx);
                if (JSON.stringify(now) !== JSON.stringify(found))
                    throw new common_1.ConflictException('Размещение изменилось. Повторите сканирование.');
                const job = await tx.fbsPrintJob.create({ data: { stationId: body.stationId, historyId: body.printId, assemblyId: found.clientId, requestId: found.warehouseId,
                        orderId: `BOX:${found.boxCode}`, kiz: found.identity, warehouseName: found.warehouseId, productName: found.palletCode, stickerCode: found.boxCode,
                        stickerMime: 'image/png', stickerBase64: image, source: exports.KIZ_BOX_PRINT_SOURCE, requestedById: user.id, requestedBy: user.name, deviceCode: user.deviceCode ?? null } });
                await tx.auditLog.create({ data: { userId: user.id, action: 'TSD_KIZ_BOX_LABELS_QUEUED', entity: 'FbsPrintJob', entityId: job.id, payload: { ...found, stationId: body.stationId, labels: 2 } } });
                return this.owned(job, user, body.kiz, body.stationId);
            });
        }
        catch (e) {
            if (e.code !== 'P2002')
                throw e;
            return this.owned(await this.prisma.fbsPrintJob.findUnique({ where: { historyId: body.printId } }), user, body.kiz, body.stationId);
        }
    }
    async status(printId, user) { this.scope(user); return this.owned(await this.prisma.fbsPrintJob.findUnique({ where: { historyId: printId } }), user); }
};
exports.TsdKizBoxPrintService = TsdKizBoxPrintService;
exports.TsdKizBoxPrintService = TsdKizBoxPrintService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], TsdKizBoxPrintService);
