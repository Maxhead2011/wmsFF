"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdAssemblyService = void 0;
exports.boxSearchInstruction = boxSearchInstruction;
exports.validateStageAction = validateStageAction;
const fbs_packing_progress_1 = require("../service/fbs-packing-progress");
const fbs_wb_accounting_1 = require("../../common/fbs-wb-accounting");
const common_1 = require("@nestjs/common");
const fbs_attempt_history_1 = require("../../common/shipment-history/fbs-attempt-history");
const fbs_return_receipt_1 = require("../marketplace-connections/fbs-return-receipt");
const fbs_terminal_queue_1 = require("../../common/fbs-terminal-queue");
const fbs_manager_decision_1 = require("../marketplace-connections/fbs-manager-decision");
const box_code_policy_service_1 = require("../../common/boxes/box-code-policy.service");
const client_1 = require("@prisma/client");
const XLSX = __importStar(require("xlsx"));
const client_scope_service_1 = require("../auth/client-scope.service");
const pick_instruction_service_1 = require("../stock/pick-instruction.service");
const fbs_request_box_audit_service_1 = require("../stock/fbs-request-box-audit.service");
const stock_operations_service_1 = require("../stock/stock-operations.service");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const fbo_two_stage_service_1 = require("./fbo-two-stage.service");
const fbo_two_stage_policy_1 = require("./fbo-two-stage-policy");
const client_request_warehouse_scope_1 = require("../client-requests/client-request-warehouse-scope");
const activeAssemblyStatuses = [
    client_1.ClientRequestStatus.SUBMITTED,
    client_1.ClientRequestStatus.IN_REVIEW,
    client_1.ClientRequestStatus.APPROVED,
    client_1.ClientRequestStatus.IN_WORK,
];
const FBS_KIZ_DUPLICATE_SCAN_ACTION = 'FBS_KIZ_DUPLICATE_SCAN';
const FBS_KIZ_LOCAL_STATUS_CONFLICT_ACTION = 'FBS_KIZ_LOCAL_STATUS_CONFLICT';
let TsdAssemblyService = class TsdAssemblyService {
    prisma;
    clientScopes;
    pickInstructions;
    stockOperations;
    fbsRequestBoxAudits;
    fbo;
    instructionCache = new Map();
    // The web preview used to request the same expensive instruction every
    // 1.5 seconds. A short shared cache protects StockMovement aggregation from
    // duplicate browser tabs while all mutating TSD actions still invalidate it.
    instructionCacheTtlMs = 5000;
    constructor(prisma, clientScopes, pickInstructions, stockOperations, fbsRequestBoxAudits, fbo) {
        this.prisma = prisma;
        this.clientScopes = clientScopes;
        this.pickInstructions = pickInstructions;
        this.stockOperations = stockOperations;
        this.fbsRequestBoxAudits = fbsRequestBoxAudits;
        this.fbo = fbo;
    }
    async listActiveRequests(user, workflow) {
        // FIX: explicit FBO queues exclude FBS before pagination; legacy installations keep their queue.
        if (workflow && !['fbo-pick', 'fbo-pack'].includes(workflow))
            throw new common_1.BadRequestException('Неизвестный этап сборки.');
        if (workflow && !(0, fbo_two_stage_policy_1.fboTwoStageEnabled)())
            throw new common_1.BadRequestException('Сборка FBO недоступна в этой ВМС.');
        const fboFilter = !workflow ? {} : {
            fbsOrderLinks: { none: {} },
            ...(workflow === 'fbo-pack'
                ? { fboAssembly: { is: process.env.WMS_FBO_PARALLEL_PACKING_ENABLED === 'true'
                            // FIX: include actual picked units before the SQL limit, preserving access scope.
                            ? { OR: [{ phase: { in: ['PACKING', 'CONTROL'] } }, { phase: 'PICKING', units: { some: { state: { in: ['PICKED', 'PACKED'] } } } }] }
                            : { phase: { in: ['PACKING', 'CONTROL'] } } } }
                : { OR: [{ fboAssembly: { is: null } }, { fboAssembly: { is: { phase: 'PICKING' } } }] }),
        };
        const clientFilter = this.clientScopes.resolveClientFilter(user);
        const requests = await this.prisma.clientRequest.findMany({
            where: {
                clientId: clientFilter,
                ...(0, client_request_warehouse_scope_1.warehouseScopeWhere)(user),
                type: client_1.ClientRequestType.OUTBOUND,
                ...fboFilter,
                status: { in: activeAssemblyStatuses },
            },
            orderBy: [{ updatedAt: 'desc' }],
            take: 100,
            select: {
                id: true,
                title: true,
                status: true,
                destinationCity: true,
                desiredDate: true,
                createdAt: true,
                updatedAt: true,
                client: { select: { id: true, name: true, code: true } },
                assignedTo: { select: { id: true, name: true, email: true } },
                pickWaveRequests: {
                    where: { wave: { status: { in: [client_1.PickWaveStatus.BALANCE_REVIEW, client_1.PickWaveStatus.FROZEN, client_1.PickWaveStatus.PICKING] } } },
                    select: {
                        wave: { select: { id: true, waveNumber: true, status: true, balanceReviewStatus: true } },
                    },
                    take: 1,
                },
                _count: { select: { items: true } },
            },
        });
        const activeProcesses = await this.loadActiveTsdProcesses(requests.map((request) => request.id));
        return requests.map((request) => ({
            id: request.id,
            requestId: request.id,
            title: request.title,
            name: request.title,
            status: request.status,
            city: request.destinationCity,
            destinationCity: request.destinationCity,
            deliveryCity: request.destinationCity,
            cityName: request.destinationCity,
            destination: request.destinationCity,
            deliveryDestination: request.destinationCity,
            desiredDate: request.desiredDate?.toISOString() ?? null,
            createdAt: request.createdAt.toISOString(),
            updatedAt: request.updatedAt.toISOString(),
            client: request.client,
            rowsCount: request._count.items,
            itemsCount: request._count.items,
            itemCount: request._count.items,
            linesCount: request._count.items,
            inWorkBy: request.assignedTo
                ? {
                    id: request.assignedTo.id,
                    name: request.assignedTo.name,
                    email: request.assignedTo.email,
                }
                : null,
            activeTsdProcess: activeProcesses.get(request.id)?.[0] ?? null,
            activeTsdProcesses: activeProcesses.get(request.id) ?? [],
            pickWave: request.pickWaveRequests[0]?.wave ?? null,
            balanceReviewPending: request.pickWaveRequests[0]?.wave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.PENDING ||
                request.pickWaveRequests[0]?.wave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.SUBMITTED,
        }));
    }
    async getDeviceRequestPlan(requestId, user) {
        // FIX: the dedicated FBO terminal screen loads its own plan. Building the
        // legacy picking document first can exceed the terminal's network timeout.
        // Preserve the full response for web clients, FBS and other installations.
        if (user.deviceId && this.fbo && (0, fbo_two_stage_policy_1.fboTwoStageEnabled)() && await this.fbo.eligible(requestId, user)) {
            const fbo = await this.fbo.plan(requestId, user);
            return { id: fbo.requestId, title: fbo.title, assemblyMode: 'FBO_TWO_STAGE',
                storesWithoutBoxes: false, fbo };
        }
        return this.getRequestPlan(requestId, user);
    }
    async getRequestPlan(requestId, user) {
        const exists = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: {
                id: true,
                clientId: true,
                warehouseId: true,
                client: { select: { storesWithoutBoxes: true } },
                pickWaveRequests: {
                    where: { wave: { status: client_1.PickWaveStatus.BALANCE_REVIEW } },
                    select: { wave: { select: { waveNumber: true, balanceReviewStatus: true } } },
                    take: 1,
                },
            },
        });
        if (!exists) {
            throw new common_1.NotFoundException('Заявка для ТСД не найдена.');
        }
        this.clientScopes.requireClientAccess(user, exists.clientId, 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, exists, 'read', 'Заявка для ТСД не найдена в выбранном филиале.');
        const pendingWave = exists.pickWaveRequests[0]?.wave;
        if (pendingWave &&
            (pendingWave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.PENDING ||
                pendingWave.balanceReviewStatus === client_1.PickWaveBalanceReviewStatus.SUBMITTED)) {
            throw new common_1.BadRequestException(`Волна ${pendingWave.waveNumber} ожидает проверки балансов клиентом. Сборка еще не зафиксирована.`);
        }
        const document = await this.getCachedInstruction(requestId, user);
        const plan = await this.toTsdPlan(document);
        const fbo = this.fbo && (0, fbo_two_stage_policy_1.fboTwoStageEnabled)() && await this.fbo.eligible(requestId, user)
            ? await this.fbo.plan(requestId, user) : undefined;
        return {
            ...plan,
            fbo,
            storesWithoutBoxes: exists.client.storesWithoutBoxes,
            assemblyMode: fbo ? 'FBO_TWO_STAGE' : exists.client.storesWithoutBoxes ? 'BOXLESS_PACKING' : 'BOX_WORKFLOW',
        };
    }
    async assertRelabelProgressAvailable(requestId, payload, user) {
        await this.requireRequestAccess(requestId, user, 'write');
        // В этой инсталляции одна и та же физическая позиция может повторно
        // проходить переклейку. Не блокируем сканирование по рассчитанному
        // остатку очереди: фактический ШК/КИЗ и итог заявки проверяются дальше.
        const plan = await this.getRequestPlan(requestId, user);
        this.requireLegacyPlan(plan);
        void payload;
    }
    async assertMovementProgressAvailable(requestId, payload, user) {
        await this.requireRequestAccess(requestId, user, 'write');
        const plan = await this.getRequestPlan(requestId, user);
        this.requireLegacyPlan(plan);
        const sourceBox = normalizeBoxCode(textValue(payload, 'fromBoxCode'));
        const barcode = normalizeScanCode(textValue(payload, 'barcode'));
        const quantity = Math.max(1, Number(payload.quantity) || 1);
        const rows = plan.movementProgress?.rows ?? [];
        const remaining = rows
            .filter((row) => normalizeBoxCode(textValue(row, 'sourceBox')) === sourceBox && normalizeScanCode(textValue(row, 'barcode')) === barcode)
            .reduce((sum, row) => sum + Math.max(0, Number(row.remainingQuantity) || 0), 0);
        if (remaining < quantity) {
            throw new common_1.BadRequestException('Эта позиция перемещения уже выполнена другим сборщиком. Обновите заявку на ТСД.');
        }
    }
    async assertOutgoingBoxAvailable(requestId, payload, user) {
        await this.requireRequestAccess(requestId, user, 'write');
        const plan = await this.getRequestPlan(requestId, user);
        this.requireLegacyPlan(plan);
        const boxCode = normalizeBoxCode(textValue(payload, 'boxCode'));
        if (!(plan.outgoingBoxCodes ?? []).some((value) => normalizeBoxCode(value) === boxCode)) {
            throw new common_1.BadRequestException('Короб не входит в актуальный список коробов на отправку. Обновите заявку на ТСД.');
        }
        if ((plan.confirmedOutgoingBoxCodes ?? []).some((value) => normalizeBoxCode(value) === boxCode)) {
            throw new common_1.BadRequestException('Этот короб уже был пропикан и подтвержден к отгрузке. Повторный скан отклонен.');
        }
    }
    async getOutgoingBoxesXlsx(requestId, user) {
        const document = await this.loadInstructionWithAccess(requestId, user);
        const plan = await this.toTsdPlan(document);
        const outgoingBoxes = Array.isArray(plan.outgoingBoxes) ? plan.outgoingBoxes : [];
        const rows = [
            ['№', 'Короб', 'Тип', 'Из короба', 'Статус', 'Город', 'Паллет', 'Количество'],
            ...outgoingBoxes.map((box, index) => [
                index + 1,
                box.boxCode,
                box.typeLabel,
                box.sourceBox || '',
                box.status || '',
                box.city || document.destinationCity || '',
                box.pallet || '',
                box.quantity || '',
            ]),
        ];
        return {
            fileName: `outgoing-boxes-${safeFileName(document.requestTitle)}-${document.requestId.slice(0, 8)}.xlsx`,
            mimeType: xlsxMimeType(),
            content: buildWorkbook(rows, 'Короба на отправку', [8, 28, 20, 30, 24, 22, 18, 14]),
        };
    }
    async getOutgoingContentsXlsx(requestId, user) {
        const document = await this.loadInstructionWithAccess(requestId, user);
        const plan = await this.toTsdPlan(document);
        const actualRows = plan.movementProgress?.actualRows ?? [];
        const wholeBoxCodes = new Set(document.warehouseWholeBoxes.map((row) => normalizeBoxCode(row.box)).filter(Boolean));
        const rows = [
            ['№', 'Короб', 'Тип', 'Из короба', 'ШК', 'Наименование', 'Размер', 'Количество', 'Город', 'Паллет', 'Примечание'],
        ];
        for (const row of document.warehouseRows) {
            if (!wholeBoxCodes.has(normalizeBoxCode(row.sourceBox)) || row.quantity <= 0) {
                continue;
            }
            rows.push([
                rows.length,
                row.sourceBox,
                'Целый короб',
                row.sourceBox,
                row.barcodeOnBox,
                row.artOnBox,
                row.size,
                row.quantity,
                row.city || document.destinationCity || '',
                row.pallet,
                row.comment || row.note || '',
            ]);
        }
        for (const row of actualRows) {
            if (row.purpose !== 'SHIPMENT' || row.quantity <= 0) {
                continue;
            }
            rows.push([
                rows.length,
                row.targetBox,
                'Короб поставки',
                row.sourceBox,
                row.barcode,
                row.name ?? '',
                row.size ?? '',
                row.quantity,
                document.destinationCity ?? '',
                '',
                'Собран после перемещения',
            ]);
        }
        return {
            fileName: `outgoing-contents-${safeFileName(document.requestTitle)}-${document.requestId.slice(0, 8)}.xlsx`,
            mimeType: xlsxMimeType(),
            content: buildWorkbook(rows, 'Состав коробов', [8, 28, 20, 30, 22, 44, 16, 14, 22, 18, 28]),
        };
    }
    async getMovementsXlsx(requestId, user) {
        const document = await this.loadInstructionWithAccess(requestId, user);
        const plan = await this.toTsdPlan(document);
        const movementRows = plan.movementProgress?.rows ?? [];
        const rows = [
            [
                '№',
                'Из короба',
                'Куда',
                'ШК',
                'Наименование',
                'Размер',
                'Нужно переместить',
                'Уже перемещено',
                'Осталось',
                'Назначение',
                'Примечание',
            ],
            ...movementRows.map((row, index) => [
                index + 1,
                row.sourceBox,
                movementTargetsText(row),
                row.barcode ?? '',
                row.name ?? '',
                row.size ?? '',
                row.requiredQuantity ?? row.quantity,
                row.movedQuantity ?? 0,
                row.remainingQuantity ?? row.quantity,
                movementPurposeLabel(row.purpose, row.targetRole),
                row.note ?? '',
            ]),
        ];
        if (rows.length === 1) {
            rows.push(['', '', '', '', 'Перемещения по заявке не требуются', '', 0, 0, 0, '', '']);
        }
        return {
            fileName: `movements-${safeFileName(document.requestTitle)}-${document.requestId.slice(0, 8)}.xlsx`,
            mimeType: xlsxMimeType(),
            content: buildWorkbook(rows, 'Перемещения', [8, 28, 30, 22, 44, 16, 16, 16, 16, 22, 42]),
        };
    }
    async loadInstructionWithAccess(requestId, user) {
        const exists = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: { id: true, clientId: true, warehouseId: true },
        });
        if (!exists) {
            throw new common_1.NotFoundException('Заявка для ТСД не найдена.');
        }
        this.clientScopes.requireClientAccess(user, exists.clientId, 'read');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, exists, 'read', 'Заявка для ТСД не найдена в выбранном филиале.');
        return this.getCachedInstruction(requestId, user);
    }
    async getCachedInstruction(requestId, user) {
        const now = Date.now();
        const cached = this.instructionCache.get(requestId);
        if (cached && cached.expiresAt > now) {
            return cached.promise;
        }
        this.pruneInstructionCache(now);
        const promise = this.pickInstructions.getRequestInstruction(requestId, user);
        this.instructionCache.set(requestId, { expiresAt: now + this.instructionCacheTtlMs, promise });
        try {
            return await promise;
        }
        catch (error) {
            if (this.instructionCache.get(requestId)?.promise === promise) {
                this.instructionCache.delete(requestId);
            }
            throw error;
        }
    }
    pruneInstructionCache(now) {
        for (const [key, value] of this.instructionCache.entries()) {
            if (value.expiresAt <= now) {
                this.instructionCache.delete(key);
            }
        }
    }
    invalidateInstructionCache(requestId) {
        this.instructionCache.delete(requestId);
    }
    async getRequestStage(requestId, stage, user) {
        const plan = await this.getRequestPlan(requestId, user);
        const payload = stagePayload(plan, stage);
        return stage === 'boxless-packing'
            ? { ...payload, packingProgress: await this.loadBoxlessPackingProgress(requestId, plan) }
            : payload;
    }
    async handleStageAction(requestId, stage, action, body, user) {
        await this.requireRequestAccess(requestId, user, 'write');
        const plan = await this.getRequestPlan(requestId, user);
        this.requireLegacyPlan(plan);
        const scannedCode = stage === 'boxless-packing' && action === 'scan-item' && isRecord(body)
            ? textValue(body, 'barcode')
            : scannedValue(body);
        let result = validateStageAction(plan, stage, action, scannedCode);
        let actionBody = isRecord(body) ? { ...body } : {};
        if (stage === 'boxless-packing' && result.accepted) {
            if (!plan.storesWithoutBoxes) {
                throw new common_1.BadRequestException('Для этого клиента используется обычная сборка по складским коробам.');
            }
            const progress = await this.loadBoxlessPackingProgress(requestId, plan);
            if (action === 'scan-item') {
                const row = progress.rows.find((item) => sameCode(item.barcode, scannedCode ?? ''));
                if (!row || Number(row.remainingQuantity) <= 0) {
                    result = actionResult('REJECTED', false, 'Эта позиция уже полностью упакована или отсутствует в заявке.');
                }
                else {
                    actionBody = { ...actionBody, requestItemId: row.requestItemId, quantity: 1 };
                }
            }
            if (result.accepted && ['open-box', 'scan-item', 'close-box'].includes(action)) {
                await this.recordBoxlessPackingAction(requestId, action, scannedCode ?? '', actionBody, user);
            }
            if (result.accepted && action === 'finish') {
                const finalProgress = await this.loadBoxlessPackingProgress(requestId, plan);
                if (finalProgress.remainingQuantity > 0) {
                    throw new common_1.BadRequestException(`Не упаковано товаров: ${finalProgress.remainingQuantity}.`);
                }
                if (finalProgress.boxes.some((box) => !box.closed)) {
                    throw new common_1.BadRequestException('Перед завершением закройте все открытые короба.');
                }
                await this.stockOperations.packageClientRequest({
                    requestId,
                    boxes: finalProgress.boxes.length,
                    packedUnits: finalProgress.packedQuantity,
                    idempotencyKey: `tsd-boxless-pack:${requestId}`,
                    comment: 'Сборка по коробам завершена на ТСД.',
                    packages: finalProgress.boxes.map((box) => ({
                        packageCode: box.boxCode,
                        packageType: 'BOX',
                        items: box.items.map((item) => ({ requestItemId: item.requestItemId, quantity: item.quantity })),
                    })),
                }, user);
                this.invalidateInstructionCache(requestId);
            }
        }
        if (stage === 'box-search' && action === 'scan' && result.accepted && scannedCode) {
            await this.recordFoundBoxSearch(requestId, scannedCode, body, user);
            this.invalidateInstructionCache(requestId);
        }
        const nextPlan = stage === 'box-search' && action === 'scan' && result.accepted ? await this.getRequestPlan(requestId, user) : plan;
        const stageData = stagePayload(nextPlan, stage);
        const packingProgress = stage === 'boxless-packing' ? await this.loadBoxlessPackingProgress(requestId, nextPlan) : undefined;
        return {
            ...stageData,
            ...result,
            requestId,
            stage,
            action,
            scannedCode,
            deviceCode: isRecord(body) ? textValue(body, 'deviceCode') : undefined,
            serverTime: new Date().toISOString(),
            plan: stageData,
            ...(packingProgress ? { packingProgress } : {}),
        };
    }
    requireLegacyPlan(plan) {
        // FIX: old clients cannot move stock behind the two-stage unit ledger.
        if (plan.assemblyMode === 'FBO_TWO_STAGE')
            throw new common_1.BadRequestException('Откройте новую двухэтапную сборку ФБО. При необходимости обновите ТСД.');
    }
    async findSkuByBarcode(query, user) {
        const clientId = query.clientId?.trim();
        const barcode = query.barcode?.trim();
        if (!clientId) {
            throw new common_1.BadRequestException('Не указан клиент для поиска товара.');
        }
        if (!barcode) {
            throw new common_1.BadRequestException('Не указан штрихкод товара.');
        }
        this.clientScopes.requireClientAccess(user, clientId, 'read');
        const warehouseId = (0, client_request_warehouse_scope_1.effectiveWarehouseId)(user, 'read');
        const matches = await this.prisma.barcode.findMany({
            where: {
                value: barcode,
                sku: { clientId },
            },
            include: {
                sku: {
                    include: {
                        barcodes: true,
                        balances: {
                            where: {
                                quantity: { gt: 0 },
                                warehouseId: warehouseId ?? undefined,
                            },
                            select: { quantity: true, status: true },
                        },
                        client: { select: { id: true, code: true, name: true } },
                    },
                },
            },
            take: 20,
        });
        const found = matches.find((match) => !match.sku.isDraft && match.sku.balances.some((balance) => balance.quantity > 0)) ??
            matches.find((match) => !match.sku.isDraft) ??
            matches[0];
        if (!found) {
            throw new common_1.NotFoundException('Товар по штрихкоду не найден.');
        }
        const sku = found.sku;
        const marketplacePhotos = extractMarketplacePhotos(sku.marketplacePayload);
        return {
            id: sku.id,
            skuId: sku.id,
            clientId: sku.clientId,
            client: sku.client,
            internalSku: sku.internalSku,
            clientSku: sku.clientSku,
            article: sku.article,
            name: sku.name,
            brand: sku.brand,
            category: sku.category,
            color: sku.color,
            size: sku.size,
            weightGrams: sku.weightGrams,
            lengthCm: decimalToNumber(sku.lengthCm),
            widthCm: decimalToNumber(sku.widthCm),
            heightCm: decimalToNumber(sku.heightCm),
            volumeLiters: decimalToNumber(sku.volumeLiters),
            shelfLifeUntil: sku.shelfLifeUntil?.toISOString() ?? null,
            needsChestnyZnak: sku.needsChestnyZnak,
            isUnmarked: sku.isUnmarked,
            isDraft: sku.isDraft,
            draftSource: sku.draftSource,
            barcode: found.value,
            barcodes: sku.barcodes.map((item) => ({ value: item.value, isPrimary: item.isPrimary })),
            availableQuantity: sku.balances.reduce((sum, balance) => sum + balance.quantity, 0),
            marketplace: sku.marketplace,
            marketplaceProductId: sku.marketplaceProductId,
            marketplaceOfferId: sku.marketplaceOfferId,
            marketplacePhotos,
            imageUrl: marketplacePhotos[0] ?? null,
            photoUrl: marketplacePhotos[0] ?? null,
        };
    }
    async requireRequestAccess(requestId, user, mode) {
        const request = await this.prisma.clientRequest.findUnique({
            where: { id: requestId },
            select: { id: true, clientId: true, warehouseId: true },
        });
        if (!request) {
            throw new common_1.NotFoundException('Заявка для ТСД не найдена.');
        }
        this.clientScopes.requireClientAccess(user, request.clientId, mode);
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, request, mode, 'Заявка для ТСД не найдена в выбранном филиале.');
        return request;
    }
    async toTsdPlan(document) {
        const rawSearchBoxCodes = uniqueSorted([
            ...document.warehouseRows.map((row) => row.sourceBox),
            ...document.warehouseBalanceMoves.map((row) => row.sourceBox),
            ...document.warehouseWholeBoxes.map((row) => row.box),
        ]);
        const movementTargetBoxes = new Set(document.warehouseBalanceMoves.map((row) => normalizeBoxCode(row.newBox)).filter(Boolean));
        const shipmentBoxes = document.warehouseWholeBoxes.map((row) => boxEntry(row.box));
        const shipmentBoxCodes = shipmentBoxes.map((box) => box.boxCode);
        let searchBoxes = rawSearchBoxCodes
            .filter((boxCode) => shouldShowInTsdBoxSearch(boxCode, movementTargetBoxes))
            .map((boxCode) => boxEntry(boxCode));
        const [activeProcessesByRequest, fbsAssembly] = await Promise.all([
            this.loadActiveTsdProcesses([document.requestId]),
            this.loadFbsAssemblyFacts(document.requestId, document.rows),
        ]);
        const fbsBoxAudit = fbsAssembly
            ? await this.fbsRequestBoxAudits.auditDocument(document)
            : null;
        if (fbsBoxAudit) {
            const liveBoxCodes = new Set(fbsBoxAudit.rows
                .filter((row) => row.state === 'OK')
                .map((row) => normalizeBoxCode(row.code)));
            searchBoxes = searchBoxes.filter((box) => liveBoxCodes.has(normalizeBoxCode(box.boxCode)));
        }
        const activeTsdProcesses = activeProcessesByRequest.get(document.requestId) ?? [];
        let activeTsdProcess = activeTsdProcesses[0] ?? null;
        const foundSearchBoxCodes = await this.loadFoundBoxSearchCodes(document.requestId, searchBoxes.map((box) => box.boxCode));
        const foundSearchBoxMatchers = [...foundSearchBoxCodes, ...(activeTsdProcess?.foundBoxCodes ?? [])];
        searchBoxes = searchBoxes.map((box) => foundSearchBoxMatchers.some((boxCode) => sameCode(boxCode, box.boxCode)) ? { ...box, found: true, isFound: true } : box);
        const rawRelabelTasks = collapseRows(document.warehouseRows
            .filter((row) => row.sourceBox && row.quantity > 0 && row.rebrandNote)
            .map((row) => {
            const parsed = parseRelabelNote(row.rebrandNote);
            return {
                sourceBox: row.sourceBox,
                oldBarcode: parsed.oldBarcode || row.barcodeOnBox,
                newBarcode: parsed.newBarcode || row.barcodeOnBox,
                barcode: parsed.newBarcode || row.barcodeOnBox,
                name: row.artOnBox,
                size: row.size,
                quantity: row.quantity,
                note: row.rebrandNote,
            };
        }), (row) => `${row.sourceBox}|${row.oldBarcode}|${row.newBarcode}|${row.size}`);
        const sharedProgress = await this.loadSharedAssemblyProgress(document.requestId);
        const relabelTasks = rawRelabelTasks.map((task) => {
            const doneQuantity = Math.min(task.quantity, sharedProgress.relabelDone.get(relabelTaskProgressKey(task)) ?? 0);
            return {
                ...task,
                doneQuantity,
                remainingQuantity: Math.max(0, task.quantity - doneQuantity),
                done: doneQuantity >= task.quantity,
            };
        });
        const allMovementTasks = collapseRows(document.warehouseBalanceMoves
            .filter((row) => row.sourceBox && row.quantity > 0)
            .map((row) => ({
            sourceBox: row.sourceBox,
            targetBox: row.newBox,
            purpose: row.purpose ?? (row.newBox ? 'BALANCE' : 'SHIPMENT'),
            targetRole: row.targetRole ?? (row.newBox ? 'STOCK' : 'SHIPMENT'),
            barcode: row.barcodeOnBox,
            name: row.artOnBox,
            size: row.size,
            quantity: row.quantity,
            note: row.note,
        })), (row) => `${row.sourceBox}|${row.targetBox}|${row.purpose}|${row.targetRole}|${row.barcode}|${row.size}`);
        searchBoxes = searchBoxes.map((box) => {
            const requiresRelabel = relabelTasks.some((row) => sameCode(row.sourceBox, box.boxCode));
            const requiresMovement = allMovementTasks.some((row) => sameCode(row.sourceBox, box.boxCode));
            const shipsWhole = shipmentBoxCodes.some((boxCode) => sameCode(boxCode, box.boxCode));
            const servesMultipleCities = document.warehouseRows.some((row) => sameCode(row.sourceBox, box.boxCode) &&
                row.comment.toLocaleUpperCase('ru-RU').includes('НЕСКОЛЬКО ГОРОДОВ'));
            return {
                ...box,
                ...boxSearchInstruction({ requiresRelabel, requiresMovement, shipsWhole }),
                servesMultipleCities,
                multiCityLabel: servesMultipleCities ? 'ТОВАР УЕЗЖАЕТ В НЕСКОЛЬКО ГОРОДОВ' : '',
            };
        });
        const storagePlacementCodes = uniqueSorted(searchBoxes
            .map((box) => safeDecode(box.boxCode).trim())
            .filter(Boolean));
        const storagePlacements = storagePlacementCodes.length
            ? await this.prisma.storagePalletBox.findMany({
                where: {
                    OR: storagePlacementCodes.map((boxCode) => ({
                        boxCode: { equals: boxCode, mode: 'insensitive' },
                    })),
                },
                include: { pallet: { include: { zone: true } } },
            })
            : [];
        const storageLocationByBox = new Map(storagePlacements.map((placement) => [
            normalizeBoxCode(placement.boxCode),
            {
                palletId: placement.palletId,
                palletCode: placement.pallet.code,
                zoneId: placement.pallet.zoneId,
                zoneCode: placement.pallet.zone?.code ?? null,
                zoneName: placement.pallet.zone?.name ?? null,
            },
        ]));
        const currentPalletId = searchBoxes
            .filter((box) => box.found || box.isFound)
            .map((box) => storageLocationByBox.get(normalizeBoxCode(box.boxCode))?.palletId)
            .find(Boolean) ?? null;
        searchBoxes = searchBoxes
            .map((box) => ({
            ...box,
            storageLocation: storageLocationByBox.get(normalizeBoxCode(box.boxCode)) ?? null,
        }))
            .sort((left, right) => {
            const leftCurrent = currentPalletId && left.storageLocation?.palletId === currentPalletId;
            const rightCurrent = currentPalletId && right.storageLocation?.palletId === currentPalletId;
            return Number(rightCurrent) - Number(leftCurrent) ||
                (left.storageLocation?.palletCode ?? '\uffff').localeCompare(right.storageLocation?.palletCode ?? '\uffff', 'ru-RU') ||
                left.boxCode.localeCompare(right.boxCode, 'ru-RU');
        });
        const movementProgress = await this.loadMovementProgress(document, allMovementTasks);
        const completedMoveSourceBoxes = new Set(movementProgress.sourceBoxes.filter((box) => box.done).map((box) => normalizeBoxCode(box.sourceBox)));
        const movementTasks = allMovementTasks.filter((row) => !completedMoveSourceBoxes.has(normalizeBoxCode(row.sourceBox)));
        const outgoingBoxes = buildOutgoingBoxes(document, movementProgress.actualRows);
        const outgoingBoxCodes = outgoingBoxes.map((box) => box.boxCode);
        const totalRelabel = relabelTasks.reduce((sum, row) => sum + row.quantity, 0);
        const totalMove = movementTasks.reduce((sum, row) => sum + row.quantity, 0);
        const totalMoveRequired = allMovementTasks.reduce((sum, row) => sum + row.quantity, 0);
        const searchBoxCodes = searchBoxes.map((box) => box.boxCode);
        const foundBoxes = searchBoxes.filter((box) => box.found || box.isFound);
        const remainingBoxes = searchBoxes.filter((box) => !box.found && !box.isFound);
        const foundBoxCodes = foundBoxes.map((box) => box.boxCode);
        const remainingBoxCodes = remainingBoxes.map((box) => box.boxCode);
        if (activeTsdProcess && searchBoxes.length > 0) {
            const totalBoxCount = searchBoxes.length;
            const activeFoundCount = Math.max(activeTsdProcess.foundCount, foundBoxes.length);
            activeTsdProcess = {
                ...activeTsdProcess,
                foundCount: activeFoundCount,
                totalBoxCount,
                progressText: `найдено коробов: ${activeFoundCount} из ${totalBoxCount}`,
            };
        }
        const requestRows = document.rows.map((row) => ({
            id: row.itemId,
            itemId: row.itemId,
            skuId: row.skuId,
            internalSku: row.internalSku,
            name: row.name,
            barcode: row.barcode,
            quantity: row.requestedQuantity,
            requestedQuantity: row.requestedQuantity,
            allocatedQuantity: row.allocatedQuantity,
            shortageQuantity: row.shortageQuantity,
            status: row.status,
            statusLabel: row.statusLabel,
            comment: row.comment,
            allocations: row.allocations,
        }));
        return {
            id: document.requestId,
            requestId: document.requestId,
            title: document.requestTitle,
            name: document.requestTitle,
            status: document.requestStatus,
            statusLabel: document.requestStatusLabel,
            city: document.destinationCity,
            destinationCity: document.destinationCity,
            deliveryCity: document.destinationCity,
            cityName: document.destinationCity,
            destination: document.destinationCity,
            deliveryDestination: document.destinationCity,
            desiredDate: document.desiredDate,
            client: document.client,
            rowsCount: document.rowsCount,
            itemsCount: document.rowsCount,
            itemCount: document.rowsCount,
            linesCount: document.rowsCount,
            totalRequested: document.totalRequested,
            totalQuantity: document.totalRequested,
            requestedQuantity: document.totalRequested,
            boxesTotal: searchBoxes.length,
            boxesCount: searchBoxes.length,
            relabelTotal: totalRelabel,
            relabelCount: totalRelabel,
            movementTotal: totalMove,
            movementRequiredTotal: totalMoveRequired,
            movementCount: totalMove,
            rows: requestRows,
            items: requestRows,
            requestRows,
            searchBoxes,
            shipmentBoxes,
            outgoingBoxes,
            shipmentBoxCodes,
            outgoingBoxCodes,
            boxesToSearch: searchBoxes,
            boxesToFind: searchBoxes,
            searchTasks: searchBoxes,
            boxTasks: searchBoxes,
            boxCodes: searchBoxCodes,
            searchBoxCodes,
            boxesToSearchCodes: searchBoxCodes,
            boxesToFindCodes: searchBoxCodes,
            foundBoxCodes,
            foundBoxesCodes: foundBoxCodes,
            remainingBoxCodes,
            remainingBoxes,
            remainingBoxTasks: remainingBoxes,
            remainingCount: remainingBoxes.length,
            remaining: remainingBoxes.length,
            remainingBoxesCount: remainingBoxes.length,
            foundCount: foundBoxes.length,
            found: foundBoxes.length,
            foundBoxes,
            boxSearchProgress: {
                total: searchBoxes.length,
                found: foundBoxes.length,
                remaining: remainingBoxes.length,
                foundBoxCodes,
                remainingBoxCodes,
            },
            activeTsdProcess,
            activeTsdProcesses,
            confirmedOutgoingBoxCodes: [...sharedProgress.confirmedOutgoingBoxes],
            relabelProgress: {
                totalRequired: totalRelabel,
                totalDone: relabelTasks.reduce((sum, task) => sum + task.doneQuantity, 0),
                totalRemaining: relabelTasks.reduce((sum, task) => sum + task.remainingQuantity, 0),
            },
            relabelTasks,
            relabelBoxes: groupTasksByBox(relabelTasks),
            allMovementTasks,
            movementTasks,
            moveTasks: movementTasks,
            movementBoxes: groupTasksByBox(movementTasks),
            movementProgress,
            fbsAssembly,
            fbsBoxAudit: fbsBoxAudit
                ? {
                    checkedAt: fbsBoxAudit.checkedAt,
                    summary: fbsBoxAudit.summary,
                }
                : null,
        };
    }
    async loadFbsAssemblyFacts(requestId, requestRows) {
        const [savedLinks, rows, duplicateKizEvents, localKizConflictEvents] = await Promise.all([
            this.prisma.fbsOrderRequestLink.findMany({
                where: {
                    requestId,
                    syncStatus: { in: ['ACTIVE', 'RETURN_REQUIRED', fbs_wb_accounting_1.FBS_WB_ACCOUNTED, ...((0, box_code_policy_service_1.permanentStorageBoxesEnabled)() ? ['MANAGER_CONFIRMED_SHIPMENT', 'MANAGER_CONFIRMED_RETURN'] : [])] },
                    ...(!(0, fbs_terminal_queue_1.fbsTerminalQueueFilterEnabled)() ? ((0, box_code_policy_service_1.permanentStorageBoxesEnabled)()
                        ? { OR: [{ lastCategory: { not: 'cancelled' } }, { syncStatus: { in: ['MANAGER_CONFIRMED_SHIPMENT', 'MANAGER_CONFIRMED_RETURN'] } }] }
                        : { lastCategory: { not: 'cancelled' } }) : {}),
                },
                select: { orderId: true, connectionId: true, lastSkuId: true, lastItemCount: true,
                    marketplace: true, lastCategory: true, lastSupplierStatus: true, lastWbStatus: true, syncStatus: true },
                orderBy: { createdAt: 'asc' },
            }),
            this.prisma.fbsTsdAssembly.findMany({
                where: { requestId, status: { not: 'RELEASED' } },
                select: {
                    id: true,
                    orderId: true,
                    requestItemId: true,
                    skuId: true,
                    sourceSkuId: true, // FIX: source stock remains under its original SKU until relabeling.
                    relabelRequired: true,
                    sourceArticle: true,
                    sourceBarcodes: true,
                    storageBoxes: true,
                    reservedBoxCode: true,
                    connectionId: true,
                    productName: true,
                    article: true,
                    boxCode: true,
                    barcode: true,
                    kiz: true,
                    wbMetaStatus: true,
                    stickerPartB: true,
                    stickerBarcode: true,
                    status: true,
                    errorMessage: true,
                    itemCount: true,
                    requiresKiz: true,
                    sourceBoxPending: true,
                    boxId: true, sourceBarcode: true, stickerPartA: true, marketplaceSubmittedAt: true,
                    workerName: true,
                    deviceCode: true,
                    completedAt: true,
                    relabelConfirmedAt: true, // FIX: distinguish physical picks requiring return receipt.
                    updatedAt: true,
                    cargoPackingId: true,
                    cargoPackedAt: true,
                    cargoPackedByName: true,
                    cargoPacking: {
                        select: {
                            id: true,
                            cargoPlaceId: true,
                            status: true,
                            deviceCode: true,
                            openedByName: true,
                            openedAt: true,
                            closedByName: true,
                            closedAt: true,
                        },
                    },
                },
                orderBy: [{ completedAt: 'desc' }, { updatedAt: 'desc' }],
            }),
            this.prisma.auditLog.findMany({
                where: {
                    action: FBS_KIZ_DUPLICATE_SCAN_ACTION,
                    entity: 'ClientRequest',
                    entityId: requestId,
                },
                select: { id: true, payload: true, createdAt: true },
                orderBy: { createdAt: 'desc' },
                take: 100,
            }),
            this.prisma.auditLog.findMany({
                where: {
                    action: FBS_KIZ_LOCAL_STATUS_CONFLICT_ACTION,
                    entity: 'ClientRequest',
                    entityId: requestId,
                },
                select: { id: true, payload: true, createdAt: true },
                orderBy: { createdAt: 'desc' },
                take: 100,
            }),
        ]);
        // FIX: the original online request retains the factual collection history.
        for (const historical of await (0, fbs_attempt_history_1.readFbsAttemptHistory)(this.prisma, { requestId })) {
            if (!rows.some(row => row.id === historical.task.id))
                rows.push(historical.task);
            if (!savedLinks.some(link => link.orderId === historical.link.orderId && link.connectionId === historical.link.connectionId))
                savedLinks.push(historical.link);
        }
        // FIX: filter only the collection plan. All task rows/KIZ/return evidence remain below.
        const completedQueueKeys = new Set(rows.filter(row => row.status === 'COMPLETED')
            .map(row => `${row.connectionId}:${row.orderId}`));
        const links = savedLinks.filter(link => !(0, fbs_terminal_queue_1.isFbsTerminalQueueOrder)(link) ||
            completedQueueKeys.has(`${link.connectionId}:${link.orderId}`));
        if (links.length === 0 && !((0, fbs_terminal_queue_1.fbsTerminalQueueFilterEnabled)() && (rows.length > 0 || savedLinks.length > 0))) {
            return null;
        }
        // FIX: keep saved completion facts across local-search activation, matching TSD and online progress.
        // Full emergency reset explicitly changes task statuses and remains unaffected.
        const skuIds = uniqueSorted([
            ...rows.map((row) => row.skuId),
            ...requestRows.map((row) => row.skuId).filter((value) => Boolean(value)),
        ]);
        const skus = skuIds.length > 0
            ? await this.prisma.sku.findMany({
                where: { id: { in: skuIds } },
                select: {
                    id: true,
                    internalSku: true,
                    clientSku: true,
                    article: true,
                    color: true,
                    size: true,
                },
            })
            : [];
        const skuById = new Map(skus.map((sku) => [sku.id, sku]));
        // FIX: allocations in a saved instruction may not contain the pallet-sort that
        // was assigned later. The online request must show the current physical place.
        // FIX: isolate our installation's live relabel hints from the sold VM.
        const relabelCandidates = process.env.WMS_FBS_ONLINE_RELABEL_LOCATIONS_ENABLED === 'true'
            ? rows.filter(row => row.sourceSkuId && row.sourceSkuId !== row.skuId &&
                ['RESERVED', 'IN_PROGRESS', 'WAITING_STOCK'].includes(row.status) &&
                links.some(link => link.connectionId === row.connectionId && link.orderId === row.orderId))
                .flatMap(row => {
                // A scanned source remains the route during relabelling; never use target-SKU boxes.
                const selected = row.boxCode || row.reservedBoxCode;
                const codes = selected ? [selected] : (Array.isArray(row.storageBoxes) ? row.storageBoxes : [])
                    .flatMap(value => value && typeof value === 'object' && !Array.isArray(value) &&
                    typeof value.code === 'string' ? [value.code] : []);
                return uniqueSorted(codes).map(boxCode => ({ itemId: row.requestItemId, orderId: row.orderId,
                    targetSkuId: row.skuId, skuId: row.sourceSkuId, boxCode, quantity: Math.max(1, row.itemCount) }));
            })
            : [];
        const allocationBoxCodes = uniqueSorted([
            ...requestRows.flatMap((row) => row.allocations.map((allocation) => allocation.boxCode)),
            ...relabelCandidates.map(row => row.boxCode),
            ...rows.filter(row => row.relabelRequired && row.boxCode).map(row => row.boxCode),
        ]);
        const allocationPlacements = allocationBoxCodes.length > 0
            ? await this.prisma.storagePalletBox.findMany({
                where: {
                    OR: allocationBoxCodes.map((boxCode) => ({
                        boxCode: { equals: boxCode, mode: 'insensitive' },
                    })),
                },
                include: { pallet: { include: { zone: true } } },
            })
            : [];
        const allocationLocationByBox = new Map(allocationPlacements.map((placement) => [
            normalizeBoxCode(placement.boxCode),
            {
                palletId: placement.palletId,
                palletCode: placement.pallet.code,
                zoneId: placement.pallet.zoneId,
                zoneCode: placement.pallet.zone?.code ?? null,
                zoneName: placement.pallet.zone?.name ?? null,
            },
        ]));
        // FIX: historical pick allocations are not proof of current available stock.
        const currentAllocationQuantities = await this.loadCurrentFbsAllocationQuantities(requestId, requestRows, relabelCandidates);
        // FIX: shared SOS WB2 print evidence, isolated to our deployment.
        const packing = process.env.WMS_UNPRINTED_KIZ_SEARCH === 'true'
            ? await (0, fbs_packing_progress_1.readPackingProgress)(this.prisma, requestId, rows.filter(row => savedLinks.some(link => link.marketplace === 'WILDBERRIES' && link.connectionId === row.connectionId && link.orderId === row.orderId)).map(row => ({ ...row, requestId }))) : new Map();
        const facts = rows.map((row) => ({
            ...(packing.has(row.id) ? { packing: packing.get(row.id) } : {}),
            id: row.id,
            orderId: row.orderId,
            sourceBoxCode: row.boxCode,
            relabelRequired: row.relabelRequired,
            sourceArticle: row.sourceArticle,
            sourceProductBarcode: row.sourceBarcode ?? (Array.isArray(row.sourceBarcodes) ? row.sourceBarcodes[0] : null),
            sourceStorageLocation: row.relabelRequired && row.boxCode
                ? allocationLocationByBox.get(normalizeBoxCode(row.boxCode)) ?? null : null,
            productName: row.productName,
            article: row.article,
            productBarcode: row.barcode,
            kiz: row.kiz,
            wbMetaStatus: row.wbMetaStatus,
            size: skuById.get(row.skuId)?.size ?? null,
            wbStickerPartB: row.stickerPartB,
            wbStickerBarcode: row.stickerBarcode,
            status: row.status,
            statusLabel: fbsAssemblyStatusLabel(row.status),
            sourceBoxPending: row.sourceBoxPending,
            syncIssue: row.errorMessage,
            // FIX: web clients request fresh receipt scans only when our installation requires them.
            requiresReturnReceipt: (0, fbs_return_receipt_1.requiresFbsReturnReceipt)(row),
            // FIX: deferred receipt remains visible after the manager resolves the marketplace conflict.
            managerDisposition: (0, fbs_manager_decision_1.fbsManagerDisposition)(savedLinks.find(link => link.connectionId === row.connectionId && link.orderId === row.orderId)?.syncStatus),
            returnRequiresKiz: row.requiresKiz || Boolean(row.kiz),
            workerName: row.workerName,
            completionSource: row.deviceCode.startsWith('SOS-WB:') ? 'SOS_WB' : 'STANDARD',
            completedAt: row.completedAt?.toISOString() ?? null,
            updatedAt: row.updatedAt.toISOString(),
            cargoPackingId: row.cargoPackingId,
            cargoPackedAt: row.cargoPackedAt?.toISOString() ?? null,
            cargoPackedByName: row.cargoPackedByName,
            wmsBoxCode: row.cargoPacking?.cargoPlaceId ?? null,
        }));
        // FIX: terminal orders are read-only evidence, never a new collection/KIZ action.
        const terminalLinks = savedLinks.filter(fbs_terminal_queue_1.isFbsTerminalQueueOrder);
        const terminalKeys = new Set(terminalLinks.map(link => `${link.connectionId}:${link.orderId}`));
        const terminalTaskIds = new Set(rows.filter(row => terminalKeys.has(`${row.connectionId}:${row.orderId}`)).map(row => row.id));
        const notForAssembly = terminalLinks.filter(link => !(0, fbs_wb_accounting_1.isFbsWbAccounted)(link)).map(link => {
            const task = rows.find(row => row.connectionId === link.connectionId && row.orderId === link.orderId);
            const fact = task ? facts.find(row => row.id === task.id) : null;
            return {
                id: task?.id ?? `${link.connectionId}:${link.orderId}`,
                orderId: link.orderId,
                wbStatus: `${link.lastSupplierStatus ?? '—'}/${link.lastWbStatus ?? '—'}`,
                productName: fact?.productName ?? requestRows.find(row => row.skuId === link.lastSkuId)?.name ?? 'Товар',
                productBarcode: fact?.productBarcode ?? null,
                kiz: fact?.kiz ?? null,
                sourceBoxCode: fact?.sourceBoxCode ?? null,
                workerName: fact?.workerName ?? null,
                syncIssue: fact?.syncIssue ?? null,
            };
        });
        // FIX: separately record WB-based accounting, without incrementing physical collection facts.
        const accountingEvents = savedLinks.some(fbs_wb_accounting_1.isFbsWbAccounted) ? await this.prisma.auditLog.findMany({
            where: { action: fbs_wb_accounting_1.FBS_WB_ACCOUNTED_ACTION, entity: 'ClientRequest', entityId: requestId },
            select: { payload: true, createdAt: true }, orderBy: { createdAt: 'desc' },
        }) : [];
        const wbAccounting = {
            enabled: (0, fbs_wb_accounting_1.fbsWbAccountingEnabled)(),
            candidates: (0, fbs_wb_accounting_1.fbsWbAccountingEnabled)() ? rows.flatMap(task => {
                const link = savedLinks.find(link => link.connectionId === task.connectionId && link.orderId === task.orderId);
                if (!link || link.marketplace !== 'WILDBERRIES' || !['ACTIVE', 'RETURN_REQUIRED'].includes(link.syncStatus) || !((0, fbs_wb_accounting_1.isFbsWbAccountingUntouched)(task) || (0, fbs_wb_accounting_1.isFbsWbKizShipmentCandidate)(task)) ||
                    !(0, fbs_wb_accounting_1.isFbsWbAccountingStatus)({ supplierStatus: link.lastSupplierStatus, wbStatus: link.lastWbStatus }))
                    return [];
                return [{ id: task.id, orderId: task.orderId, productName: task.productName, kiz: task.kiz, barcode: task.barcode, wbStatus: `${link.lastSupplierStatus}/${link.lastWbStatus}` }];
            }) : [],
            accounted: savedLinks.filter(fbs_wb_accounting_1.isFbsWbAccounted).map(link => {
                const task = rows.find(row => row.connectionId === link.connectionId && row.orderId === link.orderId);
                const event = accountingEvents.find(event => {
                    const payload = event.payload;
                    return payload?.orderId === link.orderId && payload.connectionId === link.connectionId;
                });
                const payload = event?.payload;
                return { id: task?.id ?? `${link.connectionId}:${link.orderId}`, orderId: link.orderId,
                    productName: task?.productName ?? requestRows.find(row => row.skuId === link.lastSkuId)?.name ?? 'Товар',
                    wbStatus: `${payload?.supplierStatus ?? link.lastSupplierStatus}/${payload?.wbStatus ?? link.lastWbStatus}`,
                    confirmedAt: event?.createdAt.toISOString() ?? null,
                    confirmedByName: typeof payload?.confirmedByName === 'string' ? payload.confirmedByName : null,
                    comment: typeof payload?.comment === 'string' ? payload.comment : null,
                    shipped: payload?.shipped === true, kiz: task?.kiz ?? null, barcode: task?.barcode ?? null,
                    sourceBoxCode: typeof payload?.sourceBoxCode === 'string' ? payload.sourceBoxCode : null };
            }),
        };
        const completedRows = rows.filter((row) => row.status === 'COMPLETED');
        // FIX: terminal cancellation blocks collection, not receipt of an already picked return.
        const cancelledReceiptKeys = new Set(terminalLinks.filter(link => link.lastCategory === 'cancelled' &&
            link.lastWbStatus?.trim().toLowerCase() !== 'sold').map(link => `${link.connectionId}:${link.orderId}`));
        const returnRequiredRows = rows.filter((row) => row.status === 'RETURN_REQUIRED' &&
            (facts.find(fact => fact.id === row.id)?.managerDisposition === 'AWAIT_RETURN_RECEIPT' ||
                !terminalTaskIds.has(row.id) || ((0, fbs_return_receipt_1.requiresFbsReturnReceipt)(row) && cancelledReceiptKeys.has(`${row.connectionId}:${row.orderId}`))));
        const returnRequiredIds = new Set(returnRequiredRows.map(row => row.id));
        const handledRows = [...completedRows, ...returnRequiredRows];
        const handledOrderIds = new Set(handledRows.map((row) => row.orderId));
        const linkedOrderIds = new Set(links.map((link) => link.orderId));
        const linkByOrderId = new Map(links.map((link) => [link.orderId, link]));
        const rowByOrderId = new Map(rows.map((row) => [row.orderId, row]));
        const pendingOrderIds = links
            .map((link) => link.orderId)
            .filter((orderId) => !handledOrderIds.has(orderId));
        const pendingLinksBySku = new Map();
        links.forEach((link) => {
            if (!link.lastSkuId || handledOrderIds.has(link.orderId))
                return;
            pendingLinksBySku.set(link.lastSkuId, [...(pendingLinksBySku.get(link.lastSkuId) ?? []), link]);
        });
        const handledByRequestItem = new Map();
        handledRows.forEach((row) => {
            handledByRequestItem.set(row.requestItemId, (handledByRequestItem.get(row.requestItemId) ?? 0) + Math.max(1, row.itemCount));
        });
        const notCollectedRows = requestRows
            .map((row) => {
            const requiredQuantity = Math.max(0, row.requestedQuantity);
            const collectedQuantity = Math.min(requiredQuantity, handledByRequestItem.get(row.itemId) ?? 0);
            const savedRemainingQuantity = Math.max(0, requiredQuantity - collectedQuantity);
            const sku = row.skuId ? skuById.get(row.skuId) : null;
            const linkedSkuOrderIds = row.skuId
                ? (pendingLinksBySku.get(row.skuId) ?? []).map((link) => link.orderId)
                : [];
            const commentOrderIds = (row.comment?.match(/\d{6,}/g) ?? [])
                .filter((orderId) => linkedOrderIds.has(orderId) && !handledOrderIds.has(orderId));
            const orderIds = uniqueSorted([...linkedSkuOrderIds, ...commentOrderIds]);
            // FIX: an old requestedQuantity is not demand after WB ended an order.
            const eligibleOrderIds = (0, fbs_terminal_queue_1.fbsTerminalQueueFilterEnabled)() ? orderIds.filter(orderId => {
                const task = rowByOrderId.get(orderId);
                if (task?.requestItemId)
                    return task.requestItemId === row.itemId;
                return requestRows.find(candidate => candidate.skuId === row.skuId)?.itemId === row.itemId;
            }) : orderIds;
            const remainingQuantity = (0, fbs_terminal_queue_1.fbsTerminalQueueFilterEnabled)()
                ? eligibleOrderIds.reduce((sum, orderId) => sum + Math.max(1, linkByOrderId.get(orderId)?.lastItemCount ?? rowByOrderId.get(orderId)?.itemCount ?? 1), 0)
                : savedRemainingQuantity;
            const sourceAllocations = new Map();
            for (const candidate of relabelCandidates.filter(candidate => candidate.targetSkuId === row.skuId &&
                (!candidate.itemId || candidate.itemId === row.itemId) && eligibleOrderIds.includes(candidate.orderId))) {
                const key = `${candidate.skuId}:${normalizeBoxCode(candidate.boxCode)}`;
                const previous = sourceAllocations.get(key);
                sourceAllocations.set(key, { boxCode: candidate.boxCode, quantity: (previous?.quantity ?? 0) + candidate.quantity,
                    stockSkuId: candidate.skuId, palletId: null, palletCode: null });
            }
            return {
                requestItemId: row.itemId,
                skuId: row.skuId,
                name: row.name,
                article: sku?.article ?? sku?.clientSku ?? sku?.internalSku ?? row.internalSku,
                color: sku?.color ?? null,
                size: sku?.size ?? null,
                barcode: row.barcode,
                requiredQuantity,
                collectedQuantity,
                remainingQuantity,
                orderIds: eligibleOrderIds,
                orders: eligibleOrderIds
                    .map((orderId) => {
                    const link = linkByOrderId.get(orderId);
                    const task = rowByOrderId.get(orderId);
                    return link
                        ? {
                            id: orderId,
                            connectionId: link.connectionId,
                            assemblyId: task?.id ?? null,
                            requiresKiz: task?.requiresKiz ?? false,
                            kizAccepted: Boolean(task?.kiz && task.wbMetaStatus === 'ACCEPTED'),
                        }
                        : null;
                })
                    .filter((order) => Boolean(order)),
                availableBoxes: [
                    ...row.allocations.map(allocation => ({ ...allocation, stockSkuId: row.skuId })),
                    // FIX: only assignments belonging to this pending item/order can supply a source hint.
                    ...sourceAllocations.values(),
                ].flatMap((allocation) => {
                    if (remainingQuantity <= 0)
                        return [];
                    const balanceKey = `${allocation.stockSkuId}:${normalizeBoxCode(allocation.boxCode)}`;
                    const available = currentAllocationQuantities.get(balanceKey) ?? 0;
                    const quantity = Math.min(allocation.quantity, available);
                    if (quantity <= 0)
                        return [];
                    currentAllocationQuantities.set(balanceKey, available - quantity);
                    const storageLocation = allocationLocationByBox.get(normalizeBoxCode(allocation.boxCode)) ?? null;
                    return [{
                            boxCode: allocation.boxCode,
                            quantity,
                            relabelRequired: Boolean(allocation.stockSkuId && allocation.stockSkuId !== row.skuId),
                            // FIX: prefer the current placement over the stale instruction snapshot.
                            palletId: storageLocation?.palletId ?? allocation.palletId,
                            palletCode: storageLocation?.palletCode ?? allocation.palletCode,
                            storageLocation,
                        }];
                }),
            };
        })
            .filter((row) => row.remainingQuantity > 0);
        const requestRowBySkuId = new Map(requestRows
            .filter((row) => Boolean(row.skuId))
            .map((row) => [row.skuId, row]));
        const wmsPackingRows = rows.filter((row) => row.status === 'COMPLETED' && Boolean(row.cargoPackingId && row.cargoPacking));
        const wmsBoxMap = new Map();
        wmsPackingRows.forEach((row) => {
            const packing = row.cargoPacking;
            const current = wmsBoxMap.get(packing.id) ?? {
                id: packing.id,
                code: packing.cargoPlaceId,
                status: packing.status,
                deviceCode: packing.deviceCode,
                openedByName: packing.openedByName,
                openedAt: packing.openedAt.toISOString(),
                closedByName: packing.closedByName,
                closedAt: packing.closedAt?.toISOString() ?? null,
                items: [],
            };
            current.items.push({
                id: row.id,
                orderId: row.orderId,
                productName: row.productName,
                article: row.article,
                productBarcode: row.barcode,
                size: skuById.get(row.skuId)?.size ?? null,
                kiz: row.kiz,
                wbStickerPartB: row.stickerPartB,
                packedByName: row.cargoPackedByName,
                packedAt: row.cargoPackedAt?.toISOString() ?? null,
                quantity: Math.max(1, row.itemCount),
            });
            wmsBoxMap.set(packing.id, current);
        });
        const notPackedRows = links
            .filter(link => !(0, fbs_terminal_queue_1.isFbsTerminalQueueOrder)(link))
            .map((link) => {
            const task = rowByOrderId.get(link.orderId);
            if (task?.cargoPackingId)
                return null;
            const requestRow = link.lastSkuId ? requestRowBySkuId.get(link.lastSkuId) : null;
            const sku = link.lastSkuId ? skuById.get(link.lastSkuId) : null;
            return {
                orderId: link.orderId,
                productName: task?.productName ?? requestRow?.name ?? 'Товар не определён',
                article: task?.article ??
                    sku?.article ??
                    sku?.clientSku ??
                    sku?.internalSku ??
                    requestRow?.internalSku ??
                    null,
                productBarcode: task?.barcode ?? requestRow?.barcode ?? null,
                size: task ? skuById.get(task.skuId)?.size ?? null : sku?.size ?? null,
                wbStickerPartB: task?.stickerPartB ?? null,
                assemblyStatus: task?.status ?? 'NOT_STARTED',
                assemblyStatusLabel: task ? fbsAssemblyStatusLabel(task.status) : 'Ещё не собрано',
                readyForPacking: task?.status === 'COMPLETED',
            };
        })
            .filter((row) => Boolean(row));
        const factById = new Map(facts.map((row) => [row.id, row]));
        const seenLocalKizConflicts = new Set();
        const localKizConflicts = localKizConflictEvents
            .map((event) => localFbsKizConflictFromAudit(event))
            .filter((event) => Boolean(event))
            .filter((event) => {
            const row = factById.get(event.assemblyId);
            if (!row || terminalTaskIds.has(row.id) ||
                row.status !== 'IN_PROGRESS' ||
                (row.wbMetaStatus === 'ACCEPTED' && Boolean(row.kiz))) {
                return false;
            }
            const key = `${event.assemblyId}:${event.kiz}`;
            if (seenLocalKizConflicts.has(key))
                return false;
            seenLocalKizConflicts.add(key);
            return true;
        })
            .map((event) => ({
            id: event.id,
            orderId: event.orderId,
            productName: event.productName,
            article: event.article,
            sourceBoxCode: event.sourceBoxCode,
            kiz: event.kiz,
            message: event.message,
            updatedAt: event.updatedAt,
        }));
        return {
            totalOrders: links.length,
            startedOrders: facts.filter((row) => !['WAITING_STOCK', 'RELEASED', fbs_wb_accounting_1.FBS_WB_ACCOUNTED].includes(row.status)).length,
            completedOrders: facts.filter((row) => row.status === 'COMPLETED').length,
            duplicateKizScans: duplicateKizEvents
                .map((event) => duplicateFbsKizScanFromAudit(event))
                .filter((event) => Boolean(event)),
            kizConflicts: [
                ...facts
                    .filter((row) => !terminalTaskIds.has(row.id) && row.wbMetaStatus === 'REJECTED' &&
                    Boolean(row.kiz) &&
                    Boolean(row.syncIssue))
                    .map((row) => ({
                    id: row.id,
                    orderId: row.orderId,
                    productName: row.productName,
                    article: row.article,
                    sourceBoxCode: row.sourceBoxCode,
                    kiz: row.kiz,
                    message: row.syncIssue,
                    updatedAt: row.updatedAt,
                })),
                ...localKizConflicts,
            ],
            returnRequired: {
                orders: returnRequiredRows.length,
                units: returnRequiredRows.reduce((sum, row) => sum + Math.max(1, row.itemCount), 0),
                rows: facts.filter((row) => returnRequiredIds.has(row.id)),
            },
            notForAssembly,
            wbAccounting,
            rows: facts.filter(row => row.status !== fbs_wb_accounting_1.FBS_WB_ACCOUNTED),
            wmsBoxes: {
                totalBoxes: wmsBoxMap.size,
                closedBoxes: [...wmsBoxMap.values()].filter((box) => box.status === 'CLOSED').length,
                packedUnits: wmsPackingRows.reduce((sum, row) => sum + Math.max(1, row.itemCount), 0),
                remainingUnits: notPackedRows.length,
                boxes: [...wmsBoxMap.values()],
                notPacked: notPackedRows,
            },
            notCollected: {
                remainingOrders: pendingOrderIds.length,
                remainingPositions: notCollectedRows.length,
                remainingUnits: notCollectedRows.reduce((sum, row) => sum + row.remainingQuantity, 0),
                pendingOrderIds,
                rows: notCollectedRows,
            },
        };
    }
    async loadCurrentFbsAllocationQuantities(requestId, requestRows, sources = []) {
        const boxCodes = uniqueSorted([...requestRows.flatMap(row => row.allocations.map(allocation => allocation.boxCode)), ...sources.map(row => row.boxCode)]);
        const skuIds = uniqueSorted([...requestRows.map(row => row.skuId).filter((id) => Boolean(id)), ...sources.map(row => row.skuId)]);
        const quantities = new Map();
        if (boxCodes.length === 0 || skuIds.length === 0)
            return quantities;
        const balances = await this.prisma.stockBalance.findMany({
            where: {
                skuId: { in: skuIds },
                status: client_1.StockStatus.AVAILABLE,
                quantity: { gt: 0 },
                // FIX: use the request's owner and branch, never a global box-code match.
                sku: { client: { requests: { some: { id: requestId } } } },
                warehouse: { requests: { some: { id: requestId } } },
                box: {
                    status: { notIn: ['deleted', 'archived'] },
                    OR: boxCodes.map(code => ({ code: { equals: code, mode: 'insensitive' } })),
                },
            },
            select: { skuId: true, quantity: true, box: { select: { code: true } } },
        });
        for (const balance of balances) {
            if (!balance.box)
                continue;
            const key = `${balance.skuId}:${normalizeBoxCode(balance.box.code)}`;
            quantities.set(key, (quantities.get(key) ?? 0) + balance.quantity);
        }
        return quantities;
    }
    async loadMovementProgress(document, tasks) {
        const totalRequired = tasks.reduce((sum, task) => sum + task.quantity, 0);
        const empty = {
            totalRequired,
            totalMoved: 0,
            totalRemaining: totalRequired,
            doneSourceBoxes: [],
            sourceBoxes: [],
            rows: [],
            actualRows: [],
        };
        if (tasks.length === 0 || !document.requestTitle.trim()) {
            return empty;
        }
        const movements = await this.prisma.stockMovement.findMany({
            where: {
                clientId: document.client.id,
                type: client_1.MovementType.MOVE,
                comment: { contains: document.requestTitle },
            },
            orderBy: { createdAt: 'asc' },
            select: {
                idempotencyKey: true,
                quantity: true,
                createdAt: true,
                box: { select: { code: true } },
                sku: {
                    select: {
                        name: true,
                        size: true,
                        barcodes: { select: { value: true, isPrimary: true } },
                    },
                },
            },
        });
        const pairs = new Map();
        for (const movement of movements) {
            const key = movementPairKey(movement.idempotencyKey);
            const side = movementPairSide(movement.idempotencyKey, movement.quantity);
            if (!key || !side) {
                continue;
            }
            const pair = pairs.get(key) ?? { out: [], in: [] };
            pair[side].push(movement);
            pairs.set(key, pair);
        }
        const balanceTargetsBySourceBox = new Map();
        for (const task of tasks) {
            if (!isBalanceMovementTask(task)) {
                continue;
            }
            const sourceBox = normalizeBoxCode(task.sourceBox);
            const targetBox = normalizeBoxCode(task.targetBox);
            if (!sourceBox || !targetBox) {
                continue;
            }
            const targets = balanceTargetsBySourceBox.get(sourceBox) ?? new Set();
            targets.add(targetBox);
            balanceTargetsBySourceBox.set(sourceBox, targets);
        }
        const movedBySourceBox = new Map();
        for (const movement of movements) {
            if (movement.quantity >= 0) {
                continue;
            }
            const sourceBox = normalizeBoxCode(movement.box?.code);
            if (sourceBox) {
                movedBySourceBox.set(sourceBox, (movedBySourceBox.get(sourceBox) ?? 0) + Math.abs(movement.quantity));
            }
        }
        const actualRows = new Map();
        for (const pair of pairs.values()) {
            const rowsCount = Math.min(pair.out.length, pair.in.length);
            for (let index = 0; index < rowsCount; index += 1) {
                const outRow = pair.out[index];
                const inRow = pair.in[index];
                const sourceBox = outRow.box?.code?.trim() ?? '';
                const targetBox = inRow.box?.code?.trim() ?? '';
                const normalizedSourceBox = normalizeBoxCode(sourceBox);
                const normalizedTargetBox = normalizeBoxCode(targetBox);
                if (!sourceBox || !targetBox || !normalizedSourceBox || !normalizedTargetBox) {
                    continue;
                }
                const isBalanceTarget = balanceTargetsBySourceBox.get(normalizedSourceBox)?.has(normalizedTargetBox) ?? false;
                const purpose = isBalanceTarget ? 'BALANCE' : 'SHIPMENT';
                const targetRole = isBalanceTarget ? 'STOCK' : 'SHIPMENT';
                const barcode = primaryBarcode(outRow.sku.barcodes);
                const quantity = Math.min(Math.abs(outRow.quantity), Math.abs(inRow.quantity));
                const key = [
                    normalizedSourceBox,
                    normalizedTargetBox,
                    normalizeScanCode(barcode),
                    outRow.sku.size?.trim().toLocaleLowerCase('ru-RU') ?? '',
                    purpose,
                ].join('|');
                const current = actualRows.get(key) ??
                    {
                        sourceBox,
                        targetBox,
                        purpose,
                        targetRole,
                        barcode,
                        name: outRow.sku.name,
                        size: outRow.sku.size,
                        quantity: 0,
                        movedAt: null,
                    };
                current.quantity += quantity;
                current.movedAt = inRow.createdAt.toISOString();
                actualRows.set(key, current);
            }
        }
        const movedByTask = new Map();
        const actualTargetBoxesByTask = new Map();
        for (const actual of actualRows.values()) {
            let remaining = actual.quantity;
            for (const task of tasks) {
                if (remaining <= 0 || !matchesMovementTask(task, actual)) {
                    continue;
                }
                const key = movementTaskKey(task);
                const current = movedByTask.get(key) ?? 0;
                const capacity = Math.max(0, task.quantity - current);
                const accepted = Math.min(capacity, remaining);
                if (accepted <= 0) {
                    continue;
                }
                movedByTask.set(key, current + accepted);
                const targetBoxes = actualTargetBoxesByTask.get(key) ?? new Set();
                targetBoxes.add(actual.targetBox);
                actualTargetBoxesByTask.set(key, targetBoxes);
                remaining -= accepted;
            }
        }
        const assignedBySourceBox = new Map();
        for (const task of tasks) {
            const sourceBox = normalizeBoxCode(task.sourceBox);
            if (!sourceBox) {
                continue;
            }
            assignedBySourceBox.set(sourceBox, (assignedBySourceBox.get(sourceBox) ?? 0) + (movedByTask.get(movementTaskKey(task)) ?? 0));
        }
        for (const [sourceBox, movedQuantity] of movedBySourceBox) {
            let unassignedQuantity = Math.max(0, movedQuantity - (assignedBySourceBox.get(sourceBox) ?? 0));
            if (unassignedQuantity <= 0) {
                continue;
            }
            for (const task of tasks) {
                if (unassignedQuantity <= 0 || normalizeBoxCode(task.sourceBox) !== sourceBox) {
                    continue;
                }
                const key = movementTaskKey(task);
                const current = movedByTask.get(key) ?? 0;
                const capacity = Math.max(0, task.quantity - current);
                const accepted = Math.min(capacity, unassignedQuantity);
                if (accepted <= 0) {
                    continue;
                }
                movedByTask.set(key, current + accepted);
                if (task.targetBox) {
                    const targetBoxes = actualTargetBoxesByTask.get(key) ?? new Set();
                    targetBoxes.add(task.targetBox);
                    actualTargetBoxesByTask.set(key, targetBoxes);
                }
                unassignedQuantity -= accepted;
            }
        }
        const rows = tasks.map((task) => {
            const key = movementTaskKey(task);
            const movedQuantity = Math.min(task.quantity, movedByTask.get(key) ?? 0);
            const remainingQuantity = Math.max(0, task.quantity - movedQuantity);
            return {
                ...task,
                requiredQuantity: task.quantity,
                movedQuantity,
                remainingQuantity,
                done: remainingQuantity === 0,
                actualTargetBoxes: [...(actualTargetBoxesByTask.get(key) ?? new Set())],
            };
        });
        const actualRowsList = [...actualRows.values()].sort((left, right) => `${left.sourceBox}:${left.targetBox}:${left.barcode}`.localeCompare(`${right.sourceBox}:${right.targetBox}:${right.barcode}`, 'ru', {
            numeric: true,
        }));
        const actualMovedTotal = actualRowsList.reduce((sum, row) => sum + row.quantity, 0);
        const sourceBoxes = mergeActualMovementSourceBoxes(groupMovementProgressBySource(rows), actualRowsList);
        const plannedMovedTotal = rows.reduce((sum, row) => sum + row.movedQuantity, 0);
        const totalMoved = Math.max(plannedMovedTotal, actualMovedTotal);
        return {
            totalRequired,
            totalMoved,
            totalRemaining: Math.max(0, totalRequired - totalMoved),
            doneSourceBoxes: sourceBoxes.filter((box) => box.done).map((box) => box.sourceBox),
            sourceBoxes,
            rows,
            actualRows: actualRowsList,
        };
    }
    async loadSharedAssemblyProgress(requestId) {
        const operations = await this.prisma.tsdOperation.findMany({
            where: {
                operationType: 'assembly_stage',
                status: client_1.TsdOperationStatus.ACCEPTED,
                payload: { path: ['requestId'], equals: requestId },
            },
            orderBy: { createdAt: 'asc' },
            select: { payload: true },
        });
        const relabelDone = new Map();
        const confirmedOutgoingBoxes = new Set();
        for (const operation of operations) {
            const payload = operationPayload(operation.payload);
            const action = textValue(payload, 'action') ?? textValue(payload, 'progressKind') ?? '';
            if (action === 'relabel-complete') {
                const key = relabelPayloadProgressKey(payload);
                if (key)
                    relabelDone.set(key, (relabelDone.get(key) ?? 0) + 1);
            }
            if (action === 'outgoing-confirm') {
                const boxCode = normalizeBoxCode(textValue(payload, 'boxCode'));
                if (boxCode)
                    confirmedOutgoingBoxes.add(boxCode);
            }
        }
        return { relabelDone, confirmedOutgoingBoxes };
    }
    async loadActiveTsdProcesses(requestIds) {
        const ids = [...new Set(requestIds.filter(Boolean))];
        if (ids.length === 0) {
            return new Map();
        }
        const since = new Date(Date.now() - 30 * 60 * 1000);
        const operations = await this.prisma.tsdOperation.findMany({
            where: {
                status: client_1.TsdOperationStatus.ACCEPTED,
                operationType: { in: ['assembly_stage', 'box_search_scan', 'move_scan', 'administration_release'] },
                createdAt: { gte: since },
            },
            orderBy: { createdAt: 'desc' },
            take: 1200,
        });
        const allowedRequestIds = new Set(ids);
        const latestByWorker = new Map();
        const foundBoxesByRequest = new Map();
        const userIds = new Set();
        for (const operation of operations) {
            const payload = operationPayload(operation.payload);
            const requestId = operationRequestId(operation, payload);
            if (!requestId || !allowedRequestIds.has(requestId)) {
                continue;
            }
            const payloadDevice = textValue(payload, 'deviceCode') ?? operation.deviceId;
            const workerKey = `${requestId}|${payloadDevice}`;
            if (!latestByWorker.has(workerKey)) {
                latestByWorker.set(workerKey, operation);
            }
            const userId = textValue(payload, 'userId');
            if (userId) {
                userIds.add(userId);
            }
            if (operation.operationType === 'box_search_scan') {
                const boxCode = normalizeBoxCode(textValue(payload, 'normalizedBoxCode') ?? textValue(payload, 'boxCode') ?? operation.operationKey.split(':').pop());
                if (boxCode) {
                    const boxes = foundBoxesByRequest.get(requestId) ?? new Set();
                    boxes.add(boxCode);
                    foundBoxesByRequest.set(requestId, boxes);
                }
            }
        }
        const users = userIds.size
            ? await this.prisma.user.findMany({
                where: { id: { in: [...userIds] } },
                select: { id: true, name: true, email: true },
            })
            : [];
        const usersById = new Map(users.map((user) => [user.id, user]));
        const result = new Map();
        for (const operation of latestByWorker.values()) {
            if (operation.operationType === 'administration_release')
                continue;
            const payload = operationPayload(operation.payload);
            const requestId = operationRequestId(operation, payload);
            if (!requestId)
                continue;
            const user = usersById.get(textValue(payload, 'userId') ?? '');
            const stage = operationStage(operation, payload);
            const foundBoxCodes = [...(foundBoxesByRequest.get(requestId) ?? new Set())];
            const foundCount = foundBoxCodes.length;
            const processes = result.get(requestId) ?? [];
            processes.push({
                stage,
                stageLabel: stageLabel(stage),
                deviceCode: textValue(payload, 'deviceCode') ?? operation.deviceId,
                workerName: user?.name ?? textValue(payload, 'workerName') ?? textValue(payload, 'operatorName') ?? null,
                updatedAt: operation.updatedAt.toISOString(),
                foundCount,
                foundBoxCodes,
                progressText: foundCount > 0 ? `найдено коробов: ${foundCount}` : stageLabel(stage),
            });
            result.set(requestId, processes);
        }
        return result;
    }
    async loadFoundBoxSearchCodes(requestId, boxCodes) {
        const allowed = new Set(boxCodes.map((boxCode) => normalizeBoxCode(boxCode)).filter(Boolean));
        if (!requestId || allowed.size === 0) {
            return new Set();
        }
        const prefix = boxSearchOperationPrefix(requestId);
        const operations = await this.prisma.tsdOperation.findMany({
            where: {
                operationType: 'box_search_scan',
                status: client_1.TsdOperationStatus.ACCEPTED,
                OR: [{ operationKey: { startsWith: prefix } }, { payload: { path: ['requestId'], equals: requestId } }],
            },
            select: { operationKey: true, payload: true },
        });
        const found = new Set();
        for (const operation of operations) {
            const payload = operationPayload(operation.payload);
            const candidates = [
                operation.operationKey.startsWith(prefix) ? operation.operationKey.slice(prefix.length) : operation.operationKey.split(':').pop(),
                textValue(payload, 'normalizedBoxCode'),
                textValue(payload, 'boxCode'),
            ];
            for (const candidate of candidates) {
                const normalized = normalizeBoxCode(candidate);
                const allowedCode = [...allowed].find((boxCode) => sameCode(boxCode, normalized));
                if (allowedCode) {
                    found.add(allowedCode);
                    break;
                }
            }
        }
        return found;
    }
    async recordFoundBoxSearch(requestId, scannedCode, body, user) {
        const normalizedBoxCode = normalizeScanCode(scannedCode);
        if (!normalizedBoxCode) {
            return;
        }
        const operationKey = `${boxSearchOperationPrefix(requestId)}${normalizedBoxCode}`;
        const payload = {
            requestId,
            boxCode: scannedCode.trim(),
            normalizedBoxCode,
            deviceCode: isRecord(body) ? textValue(body, 'deviceCode') : user.deviceCode,
            userId: user.id,
        };
        try {
            await this.prisma.tsdOperation.create({
                data: {
                    deviceId: user.deviceId ?? user.id,
                    operationKey,
                    operationType: 'box_search_scan',
                    payload,
                    status: client_1.TsdOperationStatus.ACCEPTED,
                    serverMessage: 'Короб найден.',
                },
            });
        }
        catch (caught) {
            if (isPrismaUniqueConflict(caught)) {
                throw new common_1.BadRequestException('Этот короб уже был пропикан в данной заявке. Повторный скан отклонен.');
            }
            throw caught;
        }
    }
    async recordBoxlessPackingAction(requestId, action, scannedCode, body, user) {
        const boxCode = textValue(body, 'boxCode') || (action !== 'scan-item' ? scannedCode : '');
        if (!boxCode || !boxCode.toLocaleUpperCase('ru-RU').startsWith('FFL')) {
            throw new common_1.BadRequestException('Сначала отсканируйте номер нового короба, начинающийся с FFL.');
        }
        const operationKey = textValue(body, 'operationKey') ||
            `boxless-packing:${requestId}:${action}:${user.deviceId ?? user.id}:${Date.now()}:${Math.random().toString(36).slice(2)}`;
        const payload = {
            ...body,
            requestId,
            stage: 'boxless-packing',
            action,
            boxCode: boxCode.trim(),
            scannedCode,
            deviceCode: textValue(body, 'deviceCode') || user.deviceCode,
            userId: user.id,
        };
        await this.prisma.tsdOperation.upsert({
            where: { operationKey },
            update: { payload, status: client_1.TsdOperationStatus.ACCEPTED, serverMessage: 'Операция сборки по коробам принята.' },
            create: {
                deviceId: user.deviceId ?? user.id,
                operationKey,
                operationType: 'assembly_stage',
                payload,
                status: client_1.TsdOperationStatus.ACCEPTED,
                serverMessage: 'Операция сборки по коробам принята.',
            },
        });
    }
    async loadBoxlessPackingProgress(requestId, plan) {
        const operations = await this.prisma.tsdOperation.findMany({
            where: {
                operationType: 'assembly_stage',
                status: client_1.TsdOperationStatus.ACCEPTED,
                payload: { path: ['requestId'], equals: requestId },
            },
            orderBy: { createdAt: 'asc' },
            select: { operationKey: true, payload: true, deviceId: true, createdAt: true },
        });
        const requestRows = (plan.requestRows ?? plan.rows ?? []);
        const boxes = new Map();
        for (const operation of operations) {
            const payload = operationPayload(operation.payload);
            if (textValue(payload, 'stage') !== 'boxless-packing')
                continue;
            const action = textValue(payload, 'action');
            const rawBoxCode = textValue(payload, 'boxCode') ?? '';
            const normalized = normalizeBoxCode(rawBoxCode);
            if (!normalized)
                continue;
            const current = boxes.get(normalized) ?? {
                boxCode: rawBoxCode,
                closed: false,
                deviceCode: textValue(payload, 'deviceCode') || operation.deviceId,
                openedAt: operation.createdAt.toISOString(),
                closedAt: null,
                items: new Map(),
            };
            if (action === 'open-box') {
                current.closed = false;
                current.deviceCode = textValue(payload, 'deviceCode') || operation.deviceId;
            }
            if (action === 'scan-item') {
                const requestItemId = textValue(payload, 'requestItemId');
                const row = requestRows.find((item) => item.itemId === requestItemId || item.id === requestItemId);
                if (requestItemId && row) {
                    const existing = current.items.get(requestItemId);
                    current.items.set(requestItemId, {
                        requestItemId,
                        barcode: textValue(row, 'barcode') ?? '',
                        name: textValue(row, 'name') ?? '',
                        quantity: (existing?.quantity ?? 0) + Math.max(1, Number(payload.quantity) || 1),
                    });
                }
            }
            if (action === 'close-box') {
                current.closed = true;
                current.closedAt = operation.createdAt.toISOString();
            }
            boxes.set(normalized, current);
        }
        const packedByItem = new Map();
        const boxRows = [...boxes.values()].map((box) => {
            const items = [...box.items.values()];
            for (const item of items)
                packedByItem.set(item.requestItemId, (packedByItem.get(item.requestItemId) ?? 0) + item.quantity);
            return { ...box, items, quantity: items.reduce((sum, item) => sum + item.quantity, 0) };
        });
        const rows = requestRows.map((row) => {
            const requestItemId = textValue(row, 'itemId') || textValue(row, 'id') || '';
            const requiredQuantity = Number(row.requestedQuantity ?? row.quantity) || 0;
            const packedQuantity = Math.min(requiredQuantity, packedByItem.get(requestItemId) ?? 0);
            return {
                requestItemId,
                barcode: textValue(row, 'barcode') ?? '',
                name: textValue(row, 'name') ?? '',
                requiredQuantity,
                packedQuantity,
                remainingQuantity: Math.max(0, requiredQuantity - packedQuantity),
            };
        });
        return {
            boxes: boxRows,
            rows,
            packedQuantity: rows.reduce((sum, row) => sum + row.packedQuantity, 0),
            totalQuantity: rows.reduce((sum, row) => sum + row.requiredQuantity, 0),
            remainingQuantity: rows.reduce((sum, row) => sum + row.remainingQuantity, 0),
            closedBoxes: boxRows.filter((box) => box.closed).length,
            openBoxes: boxRows.filter((box) => !box.closed).length,
        };
    }
};
exports.TsdAssemblyService = TsdAssemblyService;
exports.TsdAssemblyService = TsdAssemblyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        client_scope_service_1.ClientScopeService,
        pick_instruction_service_1.PickInstructionService,
        stock_operations_service_1.StockOperationsService,
        fbs_request_box_audit_service_1.FbsRequestBoxAuditService,
        fbo_two_stage_service_1.FboTwoStageService])
], TsdAssemblyService);
function stagePayload(plan, stage) {
    const requestRows = plan.requestRows ?? plan.rows ?? [];
    const base = {
        ...plan,
        stage,
        requestId: plan.requestId ?? plan.id,
        destinationCity: plan.destinationCity ?? plan.city ?? null,
        deliveryCity: plan.deliveryCity ?? plan.destinationCity ?? plan.city ?? null,
        city: plan.city ?? plan.destinationCity ?? null,
        cityName: plan.cityName ?? plan.destinationCity ?? plan.city ?? null,
        destination: plan.destination ?? plan.destinationCity ?? plan.city ?? null,
        deliveryDestination: plan.deliveryDestination ?? plan.destinationCity ?? plan.city ?? null,
        rowsCount: plan.rowsCount ?? requestRows.length,
        itemsCount: plan.itemsCount ?? plan.rowsCount ?? requestRows.length,
        itemCount: plan.itemCount ?? plan.rowsCount ?? requestRows.length,
        linesCount: plan.linesCount ?? plan.rowsCount ?? requestRows.length,
        rows: requestRows,
        items: requestRows,
    };
    if (stage === 'box-search') {
        const tasks = normalizeBoxTasks(plan.searchBoxes ?? []);
        const boxCodes = tasks.map((box) => box.boxCode);
        const foundBoxes = tasks.filter((box) => box.found || box.isFound);
        const remainingBoxes = tasks.filter((box) => !box.found && !box.isFound);
        const foundBoxCodes = foundBoxes.map((box) => box.boxCode);
        const remainingBoxCodes = remainingBoxes.map((box) => box.boxCode);
        return {
            ...base,
            tasks,
            boxes: tasks,
            boxTasks: tasks,
            searchBoxes: tasks,
            boxesToSearch: tasks,
            boxesToFind: tasks,
            boxCodes,
            searchBoxCodes: boxCodes,
            boxesToSearchCodes: boxCodes,
            boxesToFindCodes: boxCodes,
            foundBoxCodes,
            foundBoxesCodes: foundBoxCodes,
            remainingBoxCodes,
            total: tasks.length,
            totalCount: tasks.length,
            foundCount: foundBoxes.length,
            found: foundBoxes.length,
            remainingCount: remainingBoxes.length,
            remaining: remainingBoxes.length,
            remainingBoxesCount: remainingBoxes.length,
            foundBoxes,
            remainingBoxes,
            remainingBoxTasks: remainingBoxes,
            boxSearchProgress: {
                total: tasks.length,
                found: foundBoxes.length,
                remaining: remainingBoxes.length,
                foundBoxCodes,
                remainingBoxCodes,
            },
        };
    }
    if (stage === 'relabel') {
        const tasks = plan.relabelTasks ?? [];
        return {
            ...base,
            tasks,
            relabelTasks: tasks,
            boxes: groupTasksByBox(tasks),
            relabelBoxes: groupTasksByBox(tasks),
            total: tasks.reduce((sum, row) => sum + (row.quantity ?? 0), 0),
            totalCount: tasks.length,
            doneCount: 0,
            remainingCount: tasks.length,
        };
    }
    if (stage === 'moves') {
        const tasks = plan.movementTasks ?? [];
        return {
            ...base,
            tasks,
            movementTasks: tasks,
            moveTasks: tasks,
            boxes: groupTasksByBox(tasks),
            movementBoxes: groupTasksByBox(tasks),
            total: tasks.reduce((sum, row) => sum + (row.quantity ?? 0), 0),
            totalCount: tasks.length,
            doneCount: 0,
            remainingCount: tasks.length,
        };
    }
    return {
        ...base,
        tasks: requestRows,
        total: plan.totalRequested ?? plan.totalQuantity ?? 0,
        totalCount: requestRows.length,
        packedCount: 0,
        closedBoxes: [],
    };
}
function normalizeBoxTasks(values) {
    return values
        .map((value) => typeof value === 'string' ? boxEntry(value) : boxEntry(value.boxCode ?? value.code ?? '', Boolean(value.found ?? value.isFound)))
        .filter((box) => box.boxCode);
}
function boxSearchOperationPrefix(requestId) {
    return `box-search:${requestId}:`;
}
function operationPayload(payload) {
    return payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
}
function duplicateFbsKizScanFromAudit(event) {
    const payload = operationPayload(event.payload ?? {});
    const attempt = isRecord(payload.attempt) ? payload.attempt : {};
    const existing = isRecord(payload.existing) ? payload.existing : {};
    const kiz = textValue(payload, 'kiz');
    const attemptOrderId = textValue(attempt, 'orderId');
    const existingOrderId = textValue(existing, 'orderId');
    if (!kiz || !attemptOrderId || !existingOrderId) {
        return null;
    }
    return {
        id: event.id,
        eventKey: textValue(payload, 'eventKey') ?? event.id,
        kiz,
        detectedAt: textValue(payload, 'detectedAt') ?? event.createdAt.toISOString(),
        attempt: duplicateFbsKizOccurrence(attempt, event.createdAt),
        existing: duplicateFbsKizOccurrence(existing, event.createdAt),
    };
}
function localFbsKizConflictFromAudit(event) {
    const payload = operationPayload(event.payload ?? {});
    const assemblyId = textValue(payload, 'assemblyId');
    const orderId = textValue(payload, 'orderId');
    const kiz = textValue(payload, 'kiz');
    if (!assemblyId || !orderId || !kiz)
        return null;
    return {
        id: event.id,
        assemblyId,
        orderId,
        productName: textValue(payload, 'productName') ?? 'Товар не определён',
        article: textValue(payload, 'article') ?? null,
        sourceBoxCode: textValue(payload, 'boxCode') ?? null,
        kiz,
        message: textValue(payload, 'message') ??
            'КИЗ требует сверки с данными WMS и Wildberries.',
        updatedAt: textValue(payload, 'detectedAt') ??
            event.createdAt.toISOString(),
    };
}
function duplicateFbsKizOccurrence(value, fallbackDate) {
    const requestNumberValue = value.requestNumber;
    const requestNumber = typeof requestNumberValue === 'number' && Number.isSafeInteger(requestNumberValue)
        ? requestNumberValue
        : typeof requestNumberValue === 'string' && /^\d+$/.test(requestNumberValue)
            ? Number(requestNumberValue)
            : null;
    return {
        requestId: textValue(value, 'requestId') ?? '',
        requestNumber,
        requestTitle: textValue(value, 'requestTitle') ?? null,
        assemblyId: textValue(value, 'assemblyId') ?? '',
        orderId: textValue(value, 'orderId') ?? '',
        boxCode: textValue(value, 'boxCode') ?? 'БЕЗ КОРОБА',
        deviceCode: textValue(value, 'deviceCode') ?? null,
        workerName: textValue(value, 'workerName') ?? null,
        status: textValue(value, 'status') ?? null,
        scannedAt: textValue(value, 'scannedAt') ?? fallbackDate.toISOString(),
    };
}
function operationRequestId(operation, payload) {
    const fromPayload = textValue(payload, 'requestId');
    if (fromPayload) {
        return fromPayload;
    }
    if (operation.operationType === 'box_search_scan') {
        const parts = operation.operationKey.split(':');
        return parts.length >= 3 ? parts[1] : '';
    }
    return '';
}
function operationStage(operation, payload) {
    if (operation.operationType === 'box_search_scan') {
        return 'box-search';
    }
    if (operation.operationType === 'move_scan') {
        return 'moves';
    }
    return textValue(payload, 'stage') ?? 'open';
}
function relabelTaskProgressKey(task) {
    return [
        normalizeBoxCode(task.sourceBox),
        normalizeScanCode(task.oldBarcode),
        normalizeScanCode(task.newBarcode),
        (task.size ?? '').trim().toLocaleLowerCase('ru-RU'),
    ].join('|');
}
function relabelPayloadProgressKey(payload) {
    return relabelTaskProgressKey({
        sourceBox: textValue(payload, 'sourceBox'),
        oldBarcode: textValue(payload, 'oldBarcode'),
        newBarcode: textValue(payload, 'newBarcode'),
        size: textValue(payload, 'size'),
    });
}
function stageLabel(stage) {
    const labels = {
        open: 'открыта заявка',
        'box-search': 'поиск коробов',
        relabel: 'перемаркировка',
        moves: 'перемещения',
        'boxless-packing': 'сборка по коробам',
        packed: 'упаковано',
    };
    return labels[stage] ?? stage;
}
function requireFflScanCode(code) {
    return code.toLocaleUpperCase('ru-RU').startsWith('FFL')
        ? null
        : actionResult('REJECTED', false, 'Номер короба должен начинаться с FFL. Отсканируйте корректный ШК короба.');
}
function normalizeBoxCode(value) {
    return safeDecode(value ?? '')
        .replace(/[\u0000-\u001f\u007f]/g, '')
        .trim()
        .toLocaleLowerCase('ru-RU');
}
function shouldShowInTsdBoxSearch(boxCode, movementTargetBoxes) {
    const normalized = normalizeBoxCode(boxCode);
    if (!normalized) {
        return false;
    }
    if (movementTargetBoxes.has(normalized)) {
        return false;
    }
    return true;
}
function boxEntry(boxCode, found = false) {
    const code = boxCode.trim();
    return {
        boxCode: code,
        code,
        number: code,
        name: code,
        title: code,
        label: code,
        value: code,
        found,
        isFound: found,
    };
}
function boxSearchInstruction(input) {
    if (input.requiresRelabel && input.requiresMovement) {
        return {
            instructionType: 'RELABEL_MOVEMENT',
            instructionLabel: 'МАРК+ПЕРЕМЕЩЕНИЕ',
            requiresRelabel: true,
            requiresMovement: true,
            shipsWhole: input.shipsWhole,
        };
    }
    if (input.requiresRelabel) {
        return {
            instructionType: 'RELABEL',
            instructionLabel: 'ПЕРЕМАРКИРОВКА',
            requiresRelabel: true,
            requiresMovement: false,
            shipsWhole: input.shipsWhole,
        };
    }
    if (input.requiresMovement) {
        return {
            instructionType: 'MOVEMENT',
            instructionLabel: 'ПЕРЕМЕЩЕНИЕ',
            requiresRelabel: false,
            requiresMovement: true,
            shipsWhole: input.shipsWhole,
        };
    }
    return {
        instructionType: 'WHOLE',
        instructionLabel: 'ЦЕЛИКОМ',
        requiresRelabel: false,
        requiresMovement: false,
        shipsWhole: input.shipsWhole,
    };
}
function validateStageAction(plan, stage, action, scannedCode) {
    const code = normalizeScanCode(scannedCode);
    if (stage === 'box-search' && action === 'scan') {
        if (!code) {
            return actionResult('REJECTED', false, 'Не прочитан номер короба.');
        }
        const boxGuard = requireFflScanCode(code);
        if (boxGuard) {
            return boxGuard;
        }
        const matched = (plan.searchBoxes ?? []).find((box) => sameCode(box.boxCode, code));
        if (matched?.found || matched?.isFound) {
            return actionResult('DUPLICATE', false, 'Этот короб уже был пропикан в данной заявке. Повторный скан отклонен.');
        }
        return actionResult(matched ? 'FOUND' : 'NOT_REQUIRED', Boolean(matched), matched ? 'Короб найден.' : 'Короб не участвует в этой заявке.');
    }
    if ((stage === 'moves' && action === 'target-box') || (stage === 'boxless-packing' && action === 'open-box')) {
        if (!code) {
            return actionResult('REJECTED', false, 'Не прочитан номер короба.');
        }
        const boxGuard = requireFflScanCode(code);
        if (boxGuard) {
            return boxGuard;
        }
    }
    if (stage === 'relabel' && action === 'scan-source') {
        const found = (plan.relabelTasks ?? []).some((task) => sameCode(task.oldBarcode ?? task.barcode, code));
        return actionResult(found ? 'ACCEPTED' : 'REJECTED', found, found ? 'Старый штрихкод принят.' : 'Неверный старый штрихкод для перемаркировки.');
    }
    if (stage === 'relabel' && action === 'scan-target') {
        const found = (plan.relabelTasks ?? []).some((task) => sameCode(task.newBarcode ?? task.barcode, code));
        return actionResult(found ? 'ACCEPTED' : 'REJECTED', found, found ? 'Новый штрихкод принят.' : 'Неверный новый штрихкод для перемаркировки.');
    }
    if (stage === 'moves' && action === 'scan-item') {
        const found = (plan.movementTasks ?? []).some((task) => sameCode(task.barcode, code));
        return actionResult(found ? 'ACCEPTED' : 'REJECTED', found, found ? 'Товар для перемещения принят.' : 'Товар не найден в списке перемещений.');
    }
    if (stage === 'boxless-packing' && action === 'scan-item') {
        const rows = plan.requestRows ?? plan.rows ?? [];
        const found = rows.some((row) => sameCode(row.barcode, code));
        return actionResult(found ? 'ACCEPTED' : 'REJECTED', found, found ? 'Товар принят в короб.' : 'Товар не найден в заявке.');
    }
    return actionResult('ACCEPTED', true, 'Операция принята.');
}
function actionResult(status, accepted, message) {
    return {
        status,
        result: status,
        accepted,
        ok: accepted,
        success: accepted,
        valid: accepted,
        isValid: accepted,
        matched: accepted,
        match: accepted,
        isMatched: accepted,
        found: accepted,
        isFound: accepted,
        needed: accepted,
        required: accepted,
        notRequired: !accepted,
        rejected: !accepted,
        error: !accepted,
        isError: !accepted,
        message,
    };
}
function groupTasksByBox(tasks) {
    const byBox = new Map();
    for (const task of tasks) {
        const sourceBox = task.sourceBox?.trim();
        if (!sourceBox) {
            continue;
        }
        const current = byBox.get(sourceBox) ?? { boxCode: sourceBox, sourceBox, remaining: 0, quantity: 0, tasks: [] };
        current.remaining += task.quantity ?? 0;
        current.quantity += task.quantity ?? 0;
        current.tasks.push(task);
        byBox.set(sourceBox, current);
    }
    return [...byBox.values()].sort((left, right) => left.sourceBox.localeCompare(right.sourceBox, 'ru', { numeric: true }));
}
function movementPairKey(value) {
    return value?.replace(/:(out|in)$/i, '') ?? '';
}
function movementPairSide(value, quantity) {
    if (value?.match(/:out$/i)) {
        return 'out';
    }
    if (value?.match(/:in$/i)) {
        return 'in';
    }
    if (quantity < 0) {
        return 'out';
    }
    if (quantity > 0) {
        return 'in';
    }
    return null;
}
function primaryBarcode(barcodes) {
    return barcodes.find((barcode) => barcode.isPrimary)?.value ?? barcodes[0]?.value ?? '';
}
function isBalanceMovementTask(task) {
    const purpose = task.purpose?.trim().toUpperCase();
    const targetRole = task.targetRole?.trim().toUpperCase();
    return purpose === 'BALANCE' || targetRole === 'STOCK' || Boolean(task.targetBox?.trim());
}
function isShipmentMovementTask(task) {
    const purpose = task.purpose?.trim().toUpperCase();
    const targetRole = task.targetRole?.trim().toUpperCase();
    if (purpose === 'SHIPMENT' || targetRole === 'SHIPMENT') {
        return true;
    }
    return !task.targetBox?.trim() || Boolean(task.note?.toLocaleLowerCase('ru-RU').includes('постав'));
}
function movementTaskKey(task) {
    return [
        normalizeBoxCode(task.sourceBox),
        normalizeBoxCode(task.targetBox),
        isShipmentMovementTask(task) ? 'SHIPMENT' : 'BALANCE',
        normalizeScanCode(task.barcode),
        task.size?.trim().toLocaleLowerCase('ru-RU') ?? '',
    ].join('|');
}
function matchesMovementTask(task, actual) {
    if (!sameCode(task.sourceBox, actual.sourceBox)) {
        return false;
    }
    if (isShipmentMovementTask(task) !== (actual.purpose === 'SHIPMENT')) {
        return false;
    }
    if (isBalanceMovementTask(task) && task.targetBox && !sameCode(task.targetBox, actual.targetBox)) {
        return false;
    }
    const barcodeMatches = task.barcode && actual.barcode ? sameCode(task.barcode, actual.barcode) : true;
    const sizeMatches = task.size && actual.size ? task.size.trim().toLocaleLowerCase('ru-RU') === actual.size.trim().toLocaleLowerCase('ru-RU') : true;
    const nameMatches = task.name && actual.name ? task.name.trim().toLocaleLowerCase('ru-RU') === actual.name.trim().toLocaleLowerCase('ru-RU') : true;
    return barcodeMatches && sizeMatches && nameMatches;
}
function groupMovementProgressBySource(rows) {
    const bySource = new Map();
    for (const row of rows) {
        const sourceBox = row.sourceBox.trim();
        if (!sourceBox) {
            continue;
        }
        const current = bySource.get(sourceBox) ??
            {
                sourceBox,
                requiredQuantity: 0,
                movedQuantity: 0,
                remainingQuantity: 0,
                done: false,
                targetBoxes: [],
            };
        current.requiredQuantity += row.requiredQuantity;
        current.movedQuantity += row.movedQuantity;
        current.remainingQuantity += row.remainingQuantity;
        for (const targetBox of row.actualTargetBoxes) {
            if (targetBox && !current.targetBoxes.some((value) => sameCode(value, targetBox))) {
                current.targetBoxes.push(targetBox);
            }
        }
        current.done = current.remainingQuantity <= 0;
        bySource.set(sourceBox, current);
    }
    return [...bySource.values()].sort((left, right) => left.sourceBox.localeCompare(right.sourceBox, 'ru', { numeric: true }));
}
function mergeActualMovementSourceBoxes(sourceBoxes, actualRows) {
    const bySource = new Map(sourceBoxes.map((box) => [
        normalizeBoxCode(box.sourceBox),
        {
            ...box,
            targetBoxes: [...box.targetBoxes],
        },
    ]));
    const actualBySource = new Map();
    for (const row of actualRows) {
        const sourceKey = normalizeBoxCode(row.sourceBox);
        if (!sourceKey) {
            continue;
        }
        const current = actualBySource.get(sourceKey) ?? {
            sourceBox: row.sourceBox,
            movedQuantity: 0,
            targetBoxes: [],
        };
        current.movedQuantity += row.quantity;
        if (row.targetBox && !current.targetBoxes.some((value) => sameCode(value, row.targetBox))) {
            current.targetBoxes.push(row.targetBox);
        }
        actualBySource.set(sourceKey, current);
    }
    for (const [sourceKey, actual] of actualBySource) {
        const current = bySource.get(sourceKey);
        if (!current) {
            bySource.set(sourceKey, {
                sourceBox: actual.sourceBox,
                requiredQuantity: actual.movedQuantity,
                movedQuantity: actual.movedQuantity,
                remainingQuantity: 0,
                done: true,
                targetBoxes: actual.targetBoxes,
            });
            continue;
        }
        current.movedQuantity = Math.max(current.movedQuantity, actual.movedQuantity);
        current.remainingQuantity = Math.max(0, current.requiredQuantity - current.movedQuantity);
        current.done = current.remainingQuantity <= 0;
        for (const targetBox of actual.targetBoxes) {
            if (!current.targetBoxes.some((value) => sameCode(value, targetBox))) {
                current.targetBoxes.push(targetBox);
            }
        }
        bySource.set(sourceKey, current);
    }
    return [...bySource.values()].sort((left, right) => left.sourceBox.localeCompare(right.sourceBox, 'ru', { numeric: true }));
}
function buildOutgoingBoxes(document, actualRows) {
    const boxes = new Map();
    const addBox = (boxCode, data) => {
        const normalized = normalizeBoxCode(boxCode);
        if (!normalized) {
            return;
        }
        const safeCode = boxCode.trim();
        const current = boxes.get(normalized) ??
            {
                boxCode: safeCode,
                code: safeCode,
                number: safeCode,
                label: safeCode,
                type: data.type,
                typeLabel: data.typeLabel,
                sourceBox: '',
                quantity: 0,
                status: '',
                city: null,
                pallet: null,
            };
        current.quantity += data.quantity ?? 0;
        current.status = current.status || data.status || '';
        current.city = current.city || data.city || null;
        current.pallet = current.pallet || data.pallet || null;
        if (data.sourceBox && !current.sourceBox.split(', ').some((value) => sameCode(value, data.sourceBox))) {
            current.sourceBox = current.sourceBox ? `${current.sourceBox}, ${data.sourceBox}` : data.sourceBox;
        }
        if (current.type !== 'WHOLE_BOX' && data.type === 'WHOLE_BOX') {
            current.type = data.type;
            current.typeLabel = data.typeLabel;
        }
        boxes.set(normalized, current);
    };
    for (const row of document.warehouseWholeBoxes) {
        addBox(row.box, {
            type: 'WHOLE_BOX',
            typeLabel: 'Целый короб',
            sourceBox: row.box,
            status: row.status,
            city: row.city || null,
            pallet: row.pallet || null,
        });
    }
    for (const row of actualRows) {
        if (row.purpose !== 'SHIPMENT') {
            continue;
        }
        addBox(row.targetBox, {
            type: 'SHIPMENT_MOVE',
            typeLabel: 'Короб поставки',
            sourceBox: row.sourceBox,
            quantity: row.quantity,
            status: 'Собран из перемещений',
        });
    }
    return [...boxes.values()].sort((left, right) => left.boxCode.localeCompare(right.boxCode, 'ru', { numeric: true }));
}
function buildWorkbook(rows, sheetName, columnWidths) {
    const workbook = XLSX.utils.book_new();
    const sheet = XLSX.utils.aoa_to_sheet(rows);
    sheet['!cols'] = columnWidths.map((wch) => ({ wch }));
    XLSX.utils.book_append_sheet(workbook, sheet, sheetName);
    return XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
}
function movementTargetsText(row) {
    if (row.actualTargetBoxes?.length) {
        return row.actualTargetBoxes.join(', ');
    }
    if (row.targetBox) {
        return row.targetBox;
    }
    return row.purpose === 'SHIPMENT' || row.targetRole === 'SHIPMENT' ? 'Новый короб поставки' : 'Новый короб баланса';
}
function movementPurposeLabel(purpose, targetRole) {
    if (purpose === 'SHIPMENT' || targetRole === 'SHIPMENT') {
        return 'В поставку';
    }
    if (purpose === 'BALANCE' || targetRole === 'STOCK') {
        return 'Остаток на склад';
    }
    return [purpose, targetRole].filter(Boolean).join(' / ');
}
function xlsxMimeType() {
    return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
}
function safeFileName(value) {
    return value.replace(/[^a-zA-Z0-9а-яА-ЯёЁ._-]+/g, '_').replace(/^_+|_+$/g, '') || 'request';
}
function scannedValue(body) {
    if (typeof body === 'string') {
        return body.trim() || undefined;
    }
    if (!body) {
        return undefined;
    }
    for (const key of [
        'boxCode',
        'box_code',
        'box-code',
        'box',
        'boxNo',
        'boxNum',
        'boxId',
        'boxNumber',
        'boxBarcode',
        'boxQr',
        'boxQrCode',
        'boxQRCode',
        'packageCode',
        'package',
        'targetBoxCode',
        'targetBox',
        'sourceBox',
        'barcode',
        'barCode',
        'barcodeText',
        'oldBarcode',
        'newBarcode',
        'sourceBarcode',
        'targetBarcode',
        'itemBarcode',
        'code',
        'value',
        'scan',
        'scanCode',
        'scanData',
        'scanText',
        'scanValue',
        'scanResult',
        'scannedCode',
        'scannedValue',
        'qr',
        'qrCode',
        'qrText',
        'raw',
        'rawValue',
        'rawText',
        'text',
        'serial',
    ]) {
        const value = textValue(body, key);
        if (value) {
            return value;
        }
    }
    const payload = body?.payload;
    if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        return scannedValue(payload);
    }
    for (const [key, value] of Object.entries(body)) {
        if (looksLikeScannedKey(key, value)) {
            return key.trim();
        }
    }
    return undefined;
}
function isRecord(value) {
    return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}
function textValue(body, key) {
    const value = body?.[key];
    if (typeof value === 'string') {
        return value.trim();
    }
    if (typeof value === 'number' || typeof value === 'bigint') {
        return String(value).trim();
    }
    return undefined;
}
function normalizeScanCode(value) {
    return safeDecode(value ?? '')
        .replace(/[\u0000-\u001f\u007f]/g, '')
        .trim()
        .toLocaleLowerCase('ru-RU');
}
function sameCode(left, right) {
    const leftCode = normalizeScanCode(left ?? undefined);
    const rightCode = normalizeScanCode(right);
    const leftCompact = compactScanCode(leftCode);
    const rightCompact = compactScanCode(rightCode);
    return Boolean(leftCode &&
        rightCode &&
        (leftCode === rightCode ||
            rightCode.includes(leftCode) ||
            leftCode.includes(rightCode) ||
            (leftCompact && rightCompact && (leftCompact === rightCompact || rightCompact.includes(leftCompact) || leftCompact.includes(rightCompact)))));
}
function isPrismaUniqueConflict(value) {
    return Boolean(value && typeof value === 'object' && 'code' in value && value.code === 'P2002');
}
function safeDecode(value) {
    try {
        return decodeURIComponent(value);
    }
    catch {
        return value;
    }
}
function compactScanCode(value) {
    return value.replace(/[^0-9a-zа-я]+/giu, '');
}
function looksLikeScannedKey(key, value) {
    const normalizedKey = key.trim();
    if (!normalizedKey || normalizedKey.length < 3) {
        return false;
    }
    if (['deviceCode', 'device', 'token', 'stage', 'action'].includes(normalizedKey)) {
        return false;
    }
    return value === '' || value == null || value === true || typeof value === 'number';
}
function collapseRows(rows, keyOf) {
    const byKey = new Map();
    for (const row of rows) {
        const key = keyOf(row);
        const current = byKey.get(key);
        if (current) {
            current.quantity += row.quantity;
        }
        else {
            byKey.set(key, { ...row });
        }
    }
    return [...byKey.values()].sort((left, right) => left.sourceBox.localeCompare(right.sourceBox, 'ru', { numeric: true }));
}
function uniqueSorted(values) {
    return [...new Set(values.map((value) => value.trim()).filter(Boolean))].sort((left, right) => left.localeCompare(right, 'ru', { numeric: true }));
}
function fbsAssemblyStatusLabel(status) {
    return {
        IN_PROGRESS: 'В работе',
        COMPLETED: 'Собрано',
        RELEASED: 'Отложено',
        RETURN_REQUIRED: 'Требуется решение',
    }[status] ?? status;
}
function decimalToNumber(value) {
    if (value == null) {
        return null;
    }
    if (typeof value === 'number') {
        return value;
    }
    if (typeof value === 'string') {
        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : null;
    }
    return typeof value.toNumber === 'function' ? value.toNumber() : null;
}
function extractMarketplacePhotos(payload) {
    const photos = [];
    visitMarketplacePayload(payload, (value, key) => {
        const normalizedKey = key.toLowerCase();
        if (typeof value === 'string' && looksLikeImageUrl(value)) {
            photos.push(value);
            return;
        }
        if (!['photo', 'photos', 'image', 'images', 'picture', 'pictures', 'media', 'primary_image'].some((name) => normalizedKey.includes(name))) {
            return;
        }
        if (typeof value === 'string' && looksLikeImageUrl(value)) {
            photos.push(value);
            return;
        }
        if (value && typeof value === 'object' && !Array.isArray(value)) {
            const record = value;
            for (const field of ['url', 'big', 'small', 'file_name', 'link', 'c246x328', 'c516x688', 'hq', 'tm']) {
                const candidate = record[field];
                if (typeof candidate === 'string' && looksLikeImageUrl(candidate)) {
                    photos.push(candidate);
                }
            }
        }
    });
    return [...new Set(photos)].slice(0, 20);
}
function visitMarketplacePayload(value, visit, key = '', depth = 0) {
    if (depth > 6 || value == null) {
        return;
    }
    visit(value, key);
    if (Array.isArray(value)) {
        value.forEach((item, index) => visitMarketplacePayload(item, visit, `${key}.${index}`, depth + 1));
        return;
    }
    if (typeof value === 'object') {
        for (const [nextKey, nextValue] of Object.entries(value)) {
            visitMarketplacePayload(nextValue, visit, nextKey, depth + 1);
        }
    }
}
function looksLikeImageUrl(value) {
    return /^https?:\/\//i.test(value) && /\.(?:jpg|jpeg|png|webp)(?:\?|#|$)/i.test(value);
}
function parseRelabelNote(note) {
    const match = note.match(/перемаркировать\s+(.+?)\s*->\s*(.+)$/i);
    return {
        oldBarcode: match?.[1]?.trim() ?? '',
        newBarcode: match?.[2]?.trim() ?? '',
    };
}
