"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tryAssignFabricTask = tryAssignFabricTask;
const common_1 = require("@nestjs/common");
const fabric_fbs_assignment_1 = require("../warehouse/fabric-fbs-assignment");
const fabric_fbs_task_state_1 = require("../warehouse/fabric-fbs-task-state");
const fabric_fbs_availability_1 = require("../warehouse/fabric-fbs-availability");
const marketplace_product_links_1 = require("./marketplace-product-links");
const ozon_fbs_pick_lines_1 = require("./ozon-fbs-pick-lines");
// FIX: resolve the entire posting before starting a DB transaction. Raw metres
// are never represented as AVAILABLE finished goods, even for queue previews.
async function tryAssignFabricTask(service, clientId, order, existing, user, deviceCode) {
    if (process.env.WMS_FBS_FABRIC_CUT_ENABLED !== 'true')
        return { handled: false };
    const enabled = await service.prisma.systemSetting.findUnique({ where: { key: `fabric.fbs.enabled.v1:${clientId}` } });
    if (enabled?.value?.enabled !== true)
        return { handled: false };
    const catalog = await service.prisma.sku.findMany({ where: { clientId }, include: { barcodes: true } });
    let rows;
    if (order.marketplace === 'OZON') {
        const posting = await service.readOzonFbsPickPosting({ clientId, connectionId: order.connectionId, orderId: order.id });
        const linked = await (0, marketplace_product_links_1.ozonLinkedSkus)(service.prisma, clientId, order.connectionId, catalog);
        const products = (0, ozon_fbs_pick_lines_1.ozonPostingProducts)(posting);
        // FIX: opting into fabric must not apply fabric restrictions to ordinary orders.
        const containsFabric = products.some(p => linked.some((sku) => (0, fabric_fbs_availability_1.identifyFabricSku)(sku) && (String(sku.marketplaceProductId ?? '').split(':').some(id => id === p.offerId || id === String(p.productId)) ||
            sku.marketplaceOfferId === p.offerId || (sku.barcodes ?? []).some((b) => p.barcodes.includes(b.value)))));
        if (!containsFabric)
            return { handled: false };
        if (!(0, ozon_fbs_pick_lines_1.ozonPickLinesEnabled)())
            throw new common_1.ConflictException('Для нарезки Ozon требуется поштучный учёт состава заказа.');
        rows = products.map(p => ({ ...p, sku: (0, ozon_fbs_pick_lines_1.resolveOzonLineSku)(p, linked) }));
        if (!rows.some(r => (0, fabric_fbs_availability_1.identifyFabricSku)(r.sku)))
            return { handled: false };
        if (posting.status !== 'awaiting_packaging' || posting.requirements?.products_requiring_mandatory_mark?.length)
            throw new common_1.ConflictException('Заказ Ozon изменился или требует маркировки. Проверьте состав перед нарезкой.');
    }
    else {
        const sku = catalog.find((s) => s.id === order.product?.id);
        if (!sku || !(0, fabric_fbs_availability_1.identifyFabricSku)(sku))
            return { handled: false };
        rows = [{ sku, quantity: order.itemCount, productId: 0, offerId: '' }];
    }
    if (user.tsdFabricCutConfirmation !== true)
        throw new common_1.ConflictException('Для сборки из рулонов обновите приложение ТСД.');
    if (rows.some(r => !Number.isSafeInteger(r.quantity) || r.quantity < 1 || !r.sku.barcodes?.length ||
        (r.sku.needsChestnyZnak && !r.sku.isUnmarked) || r.sku.needsRelabel) ||
        (order.requiredMeta ?? []).some((m) => m.toLowerCase() === 'sgtin'))
        throw new common_1.ConflictException('Для нарезки проверьте количество, ШК и требования маркировки всех позиций.');
    if (new Set(rows.map(r => r.sku.id)).size !== rows.length || rows[0].sku.id !== order.product.id ||
        rows.reduce((n, r) => n + r.quantity, 0) !== order.itemCount)
        throw new common_1.ConflictException('Состав заказа отличается от заявки. Обновите заявку перед нарезкой.');
    if (existing && !['RESERVED', 'RELEASED'].includes(existing.status))
        return { handled: true };
    // Existing physical evidence must not be erased by reassignment.
    if (existing && (existing.marketplaceSubmittedAt || (existing.sourceArticle !== fabric_fbs_task_state_1.FABRIC_TASK_MARKER &&
        (existing.barcode || existing.kiz || existing.sourceBarcode || existing.relabelConfirmedAt))))
        throw new common_1.ConflictException('В заказе уже есть физические действия. Требуется продолжение прежнего задания.');
    const task = await service.prisma.$transaction(async (tx) => {
        const requestId = order.request.id;
        await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${requestId} FOR UPDATE`;
        const request = await tx.clientRequest.findUnique({ where: { id: requestId } });
        if (!request || request.clientId !== clientId || !request.warehouseId || request.warehouseId !== user.activeWarehouseId ||
            ['DONE', 'CANCELLED', 'REJECTED'].includes(request.status))
            throw new common_1.ConflictException('Выберите филиал открытой заявки.');
        const saved = existing && order.marketplace === 'OZON' ? await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, existing.id) : null;
        if (saved && (saved.submission !== 'PICKING' || (existing.sourceArticle !== fabric_fbs_task_state_1.FABRIC_TASK_MARKER && saved.lines.some(l => l.picks.length)) || saved.lines.length !== rows.length ||
            saved.lines.some(l => !rows.some(r => r.sku.id === l.skuId && r.quantity === l.quantity && r.productId === l.productId && r.offerId === l.offerId))))
            throw new common_1.ConflictException('Состав или сканы ранее начатого заказа изменились. Нужна сверка.');
        const items = [];
        for (const [index, row] of rows.entries()) {
            const found = await tx.clientRequestItem.findFirst({ where: { requestId, skuId: row.sku.id } });
            // Match the existing Ozon initialization: replace this order's historical
            // contribution to the first SKU once, retaining other orders in the request.
            if (!saved && order.marketplace === 'OZON' && rows.length > 1) {
                if (index === 0) {
                    if (!found || found.quantity < order.itemCount)
                        throw new common_1.ConflictException('Количество первой позиции изменилось. Нужна сверка.');
                    items.push(await tx.clientRequestItem.update({ where: { id: found.id }, data: { quantity: { decrement: order.itemCount - row.quantity } } }));
                }
                else if (found)
                    items.push(await tx.clientRequestItem.update({ where: { id: found.id }, data: { quantity: { increment: row.quantity } } }));
                else
                    items.push(await tx.clientRequestItem.create({ data: { requestId, skuId: row.sku.id, name: row.sku.name, barcode: row.sku.barcodes[0].value, quantity: row.quantity } }));
            }
            else {
                if (!found || found.quantity < row.quantity)
                    throw new common_1.ConflictException('Позиция не соответствует заявке.');
                items.push(found);
            }
        }
        const owner = { marketplace: order.marketplace, connectionId: order.connectionId, orderId: order.id, requestId };
        const lines = rows.flatMap((row, index) => {
            const identity = (0, fabric_fbs_availability_1.identifyFabricSku)(row.sku);
            return identity ? [{ ...identity, lineId: items[index].id, warehouseId: request.warehouseId, units: row.quantity }] : [];
        });
        return (0, fabric_fbs_assignment_1.assignFabricOrder)(tx, { clientId, owner, lines, capability: true }, async () => {
            const first = rows[0].sku;
            const data = { clientId, ...owner, supplyId: order.supplyId, requestItemId: items[0].id, skuId: first.id,
                productName: first.name, article: first.article || first.clientSku || first.internalSku,
                barcodes: first.barcodes.map((b) => b.value), sourceBarcodes: [], storageBoxes: [], itemCount: order.itemCount,
                requiresKiz: false, relabelRequired: false, status: 'IN_PROGRESS', deviceCode, workerUserId: user.id, workerName: user.name,
                startedAt: new Date(), boxId: null, boxCode: order.marketplace === 'OZON' ? null : 'БЕЗ КОРОБА',
                // This marks a reserved production task as non-empty for legacy lease recovery.
                sourceBoxPending: order.marketplace === 'OZON', sourceArticle: fabric_fbs_task_state_1.FABRIC_TASK_MARKER, sourceSkuId: null, sourceBarcode: null, barcode: null, kiz: null,
                reservedBoxId: null, reservedBoxCode: null, reservedAt: null, wbMetaStatus: 'NOT_REQUIRED', errorMessage: null };
            let claimed;
            if (existing) {
                const assignmentData = existing.sourceArticle === fabric_fbs_task_state_1.FABRIC_TASK_MARKER
                    ? { status: 'IN_PROGRESS', deviceCode, workerUserId: user.id, workerName: user.name, errorMessage: null }
                    : data;
                const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: existing.id, status: existing.status, updatedAt: existing.updatedAt }, data: assignmentData });
                if (changed.count !== 1)
                    throw new common_1.ConflictException('Заказ уже взят другим сотрудником. Обновите очередь.');
                claimed = await tx.fbsTsdAssembly.findUnique({ where: { id: existing.id } });
            }
            else
                claimed = await tx.fbsTsdAssembly.create({ data });
            if (order.marketplace === 'OZON' && !saved) {
                const state = { version: 1, source: null, submission: 'PICKING', legacyScansDiscarded: false,
                    lines: rows.map((row, index) => ({ productId: row.productId, offerId: row.offerId, quantity: row.quantity, skuId: row.sku.id,
                        requestItemId: items[index].id, name: row.sku.name, article: row.sku.article || row.sku.internalSku,
                        barcodes: row.sku.barcodes.map((b) => b.value), picks: [] })) };
                await (0, ozon_fbs_pick_lines_1.writeOzonPickState)(tx, claimed.id, state);
            }
            await tx.clientRequestEvent.create({ data: { requestId, clientId, eventType: 'COMMENT', createdByUserId: user.id,
                    title: 'Зарезервирована ткань для ФБС', body: JSON.stringify({ taskId: claimed.id, ...owner, lines }) } });
            return claimed;
        });
    });
    return { handled: true, task };
}
