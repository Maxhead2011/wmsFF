// live-react:react
import { r as R } from "/assets/storage-volume-root-20261109.js";
var react_default = R;
var forwardRef = R.forwardRef;
var createElement = R.createElement;

// ../returns-processing/wms/node_modules/.pnpm/lucide-react@0.468.0_react@18.3.1/node_modules/lucide-react/dist/esm/shared/src/utils.js
var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
var mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();

// ../returns-processing/wms/node_modules/.pnpm/lucide-react@0.468.0_react@18.3.1/node_modules/lucide-react/dist/esm/defaultAttributes.js
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

// ../returns-processing/wms/node_modules/.pnpm/lucide-react@0.468.0_react@18.3.1/node_modules/lucide-react/dist/esm/Icon.js
var Icon = forwardRef(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => {
    return createElement(
      "svg",
      {
        ref,
        ...defaultAttributes,
        width: size,
        height: size,
        stroke: color,
        strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
        className: mergeClasses("lucide", className),
        ...rest
      },
      [
        ...iconNode.map(([tag, attrs]) => createElement(tag, attrs)),
        ...Array.isArray(children) ? children : [children]
      ]
    );
  }
);

// ../returns-processing/wms/node_modules/.pnpm/lucide-react@0.468.0_react@18.3.1/node_modules/lucide-react/dist/esm/createLucideIcon.js
var createLucideIcon = (iconName, iconNode) => {
  const Component = forwardRef(
    ({ className, ...props }, ref) => createElement(Icon, {
      ref,
      iconNode,
      className: mergeClasses(`lucide-${toKebabCase(iconName)}`, className),
      ...props
    })
  );
  Component.displayName = `${iconName}`;
  return Component;
};

// ../returns-processing/wms/node_modules/.pnpm/lucide-react@0.468.0_react@18.3.1/node_modules/lucide-react/dist/esm/icons/boxes.js
var Boxes = createLucideIcon("Boxes", [
  [
    "path",
    {
      d: "M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z",
      key: "lc1i9w"
    }
  ],
  ["path", { d: "m7 16.5-4.74-2.85", key: "1o9zyk" }],
  ["path", { d: "m7 16.5 5-3", key: "va8pkn" }],
  ["path", { d: "M7 16.5v5.17", key: "jnp8gn" }],
  [
    "path",
    {
      d: "M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z",
      key: "8zsnat"
    }
  ],
  ["path", { d: "m17 16.5-5-3", key: "8arw3v" }],
  ["path", { d: "m17 16.5 4.74-2.85", key: "8rfmw" }],
  ["path", { d: "M17 16.5v5.17", key: "k6z78m" }],
  [
    "path",
    {
      d: "M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z",
      key: "1xygjf"
    }
  ],
  ["path", { d: "M12 8 7.26 5.15", key: "1vbdud" }],
  ["path", { d: "m12 8 4.74-2.85", key: "3rx089" }],
  ["path", { d: "M12 13.5V8", key: "1io7kd" }]
]);

// ../returns-processing/wms/node_modules/.pnpm/lucide-react@0.468.0_react@18.3.1/node_modules/lucide-react/dist/esm/icons/download.js
var Download = createLucideIcon("Download", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
  ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }]
]);

// ../returns-processing/wms/node_modules/.pnpm/lucide-react@0.468.0_react@18.3.1/node_modules/lucide-react/dist/esm/icons/printer.js
var Printer = createLucideIcon("Printer", [
  [
    "path",
    {
      d: "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
      key: "143wyd"
    }
  ],
  ["path", { d: "M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6", key: "1itne7" }],
  ["rect", { x: "6", y: "14", width: "12", height: "8", rx: "1", key: "1ue0tg" }]
]);

// wms/apps/web/src/components/client-requests/FbsLabelActions.tsx
function FbsLabelActions({ onAction }) {
  return /* @__PURE__ */ react_default.createElement("div", { className: "fbs-label-actions" }, /* @__PURE__ */ react_default.createElement("style", null, `.fbs-label-actions{display:grid;gap:8px;width:100%;min-width:0}.fbs-label-actions .fbs-label-action{display:flex;align-items:center;gap:10px;width:100%;padding:12px 14px;border:1px solid #dce3ec;border-radius:12px;background:#fff;color:#334155;cursor:pointer;text-align:left;font:inherit;font-size:14px;font-weight:600;line-height:1.3;transition:background .15s,border-color .15s,box-shadow .15s}.fbs-label-actions .fbs-label-action svg{flex-shrink:0}.fbs-label-actions .fbs-label-action:hover{background:#f5f3ff;border-color:#c4b5fd;box-shadow:0 3px 10px #49338712}.fbs-label-actions .fbs-label-action:focus-visible{outline:3px solid #a78bfa;outline-offset:2px}.fbs-label-actions .fbs-label-action--primary{background:#6d4bc3;border-color:#6d4bc3;color:#fff}.fbs-label-actions .fbs-label-action--primary:hover{background:#5b3ba9;border-color:#5b3ba9}.fbs-label-actions .fbs-label-action--cargo{background:#f0fdfa;border-color:#bce5dc;color:#16665b}`), /* @__PURE__ */ react_default.createElement("style", null, `.fbs-label-actions .fbs-label-action span{color:inherit!important}`), /* @__PURE__ */ react_default.createElement("button", { type: "button", className: "fbs-label-action", onClick: () => onAction("download"), title: "\u041F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442: \u0442\u043E\u0432\u0430\u0440\u043D\u044B\u0435 \u044D\u0442\u0438\u043A\u0435\u0442\u043A\u0438 \u0438 \u0441\u0442\u0438\u043A\u0435\u0440\u044B \u043C\u0430\u0440\u043A\u0435\u0442\u043F\u043B\u0435\u0439\u0441\u0430" }, /* @__PURE__ */ react_default.createElement(Download, { size: 18, "aria-hidden": "true" }), /* @__PURE__ */ react_default.createElement("span", null, "\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0432\u0441\u0435 \u0428\u041A")), /* @__PURE__ */ react_default.createElement("button", { type: "button", className: "fbs-label-action fbs-label-action--primary", onClick: () => onAction("print"), title: "\u0420\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u043F\u043E\u043B\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0435\u043A\u0442 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A" }, /* @__PURE__ */ react_default.createElement(Printer, { size: 18, "aria-hidden": "true" }), /* @__PURE__ */ react_default.createElement("span", null, "\u0420\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u0430\u0442\u044C \u0432\u0441\u0435 \u0428\u041A")), /* @__PURE__ */ react_default.createElement("button", { type: "button", className: "fbs-label-action fbs-label-action--cargo", onClick: () => onAction("cargo"), title: "\u0414\u043B\u044F \u0441\u043E\u0431\u0440\u0430\u043D\u043D\u044B\u0445 \u0437\u0430\u043A\u0430\u0437\u043E\u0432: WB \u2014 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442\u0430 \u0438 \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0430; Ozon \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0442\u0438\u043A\u0435\u0440\u044B \u0437\u0430\u043A\u0430\u0437\u043E\u0432. \u0411\u0435\u0437 \u044D\u0442\u0438\u043A\u0435\u0442\u043E\u043A \u0442\u043E\u0432\u0430\u0440\u0430." }, /* @__PURE__ */ react_default.createElement(Boxes, { size: 18, "aria-hidden": "true" }), /* @__PURE__ */ react_default.createElement("span", null, "\u041F\u0435\u0447\u0430\u0442\u044C \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442")));
}
export {
  FbsLabelActions
};
/*! Bundled license information:

lucide-react/dist/esm/shared/src/utils.js:
lucide-react/dist/esm/defaultAttributes.js:
lucide-react/dist/esm/Icon.js:
lucide-react/dist/esm/createLucideIcon.js:
lucide-react/dist/esm/icons/boxes.js:
lucide-react/dist/esm/icons/download.js:
lucide-react/dist/esm/icons/printer.js:
lucide-react/dist/esm/lucide-react.js:
  (**
   * @license lucide-react v0.468.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
