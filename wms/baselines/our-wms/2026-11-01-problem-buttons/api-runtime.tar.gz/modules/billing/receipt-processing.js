"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.receiptPricingKey = exports.receiptProcessingKey = exports.receiptProcessingPrefix = exports.receiptProcessingEnabled = void 0;
exports.normalizeReceiptProfile = normalizeReceiptProfile;
exports.saveReceiptProcessing = saveReceiptProcessing;
exports.receiptProcessingByBoxes = receiptProcessingByBoxes;
exports.receiptProfileAmount = receiptProfileAmount;
exports.applyReceiptPrimary = applyReceiptPrimary;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
const fbs_primary_processing_1 = require("../marketplace-connections/fbs-primary-processing");
const receipt_channel_policy_1 = require("../warehouse/receipt-channel-policy");
const receiptProcessingEnabled = () => process.env.WMS_RECEIPT_PROCESSING_ENABLED === 'true';
exports.receiptProcessingEnabled = receiptProcessingEnabled;
const receiptProcessingPrefix = (clientId) => `receipt.processing.v1:${clientId}:`;
exports.receiptProcessingPrefix = receiptProcessingPrefix;
const receiptProcessingKey = (clientId, warehouseId, id) => `${(0, exports.receiptProcessingPrefix)(clientId)}${warehouseId}:${id}`;
exports.receiptProcessingKey = receiptProcessingKey;
const receiptPricingKey = (clientId) => `receipt.processing.pricing.v1:${clientId}`;
exports.receiptPricingKey = receiptPricingKey;
function normalizeReceiptProfile(raw, allowedIds) {
    if (!raw || !/^\d{1,8}([.,]\d{1,2})?$/.test(String(raw.unitPriceRub)) || !['INCLUDED', 'ADD_6_PERCENT'].includes(raw.taxMode) || !Array.isArray(raw.includedServiceIds))
        throw new common_1.BadRequestException('Проверьте цену, налог и состав обработки.');
    const ids = raw.includedServiceIds;
    if (ids.length > 100 || new Set(ids).size !== ids.length || ids.some((id) => typeof id !== 'string' || !allowedIds.includes(id)))
        throw new common_1.BadRequestException('Проверьте включённые услуги.');
    return { unitPriceRub: new client_1.Prisma.Decimal(String(raw.unitPriceRub).replace(',', '.')).toFixed(2), taxMode: raw.taxMode, includedServiceIds: ids };
}
// FIX: exact client/warehouse/receipt identity and optimistic revision; changing type never rewrites invoices.
async function saveReceiptProcessing(db, input, user) {
    if (!(0, exports.receiptProcessingEnabled)())
        throw new common_1.NotFoundException('Виды прихода не включены.');
    if (!['WHITE', 'GRAY'].includes(input.kind) || !Number.isSafeInteger(input.revision) || input.revision < 0)
        throw new common_1.BadRequestException('Выберите один вид прихода и актуальную версию.');
    const key = (0, exports.receiptProcessingKey)(input.clientId, input.warehouseId, input.id);
    await db.$queryRaw `SELECT pg_advisory_xact_lock(hashtextextended(${key},0))::text`;
    const doc = (await (0, receipt_channel_policy_1.receiptDocuments)(db, input.clientId, input.warehouseId, undefined, undefined, true)).find(r => r.id === input.id);
    if (!doc)
        throw new common_1.NotFoundException('Приёмка не найдена.');
    const saved = await db.systemSetting.findUnique({ where: { key } }), previous = saved?.value;
    if ((previous?.revision ?? 0) !== input.revision)
        throw new common_1.ConflictException('Вид обработки уже изменён. Обновите список.');
    if (previous?.kind === input.kind)
        return previous;
    const pricing = (await db.systemSetting.findUnique({ where: { key: (0, exports.receiptPricingKey)(input.clientId) } }))?.value;
    if (!pricing?.[input.kind])
        throw new common_1.BadRequestException('Сначала настройте тарифы серой и белой обработки в биллинге клиента.');
    const next = { kind: input.kind, revision: input.revision + 1, changedAt: new Date().toISOString(), changedByName: user.name, changedByUserId: user.id };
    await db.systemSetting.upsert({ where: { key }, create: { key, value: next, updatedByUserId: user.id }, update: { value: next, updatedByUserId: user.id } });
    await db.auditLog.create({ data: { userId: user.id, action: 'RECEIPT_PROCESSING_CHANGED', entity: 'Receipt', entityId: input.id, payload: { clientId: input.clientId, warehouseId: input.warehouseId, sourceDocument: doc.sourceDocument, previous: previous ?? null, next } } });
    return next;
}
// FIX: one batched index lookup; no scan through receipt movement history on billing paths.
async function receiptProcessingByBoxes(db, clientId, codes) {
    const result = new Map();
    if (!(0, exports.receiptProcessingEnabled)() || !codes.length)
        return result;
    const selections = await db.systemSetting.findMany({ where: { key: { startsWith: (0, exports.receiptProcessingPrefix)(clientId) } } });
    if (!selections.length)
        return result;
    const pricing = (await db.systemSetting.findUnique({ where: { key: (0, exports.receiptPricingKey)(clientId) } }))?.value;
    const boxes = await db.$queryRaw(client_1.Prisma.sql `
 SELECT b.id,b.code,b."warehouseId",i."receiptAt" FROM "Box" b
 LEFT JOIN "ReceiptStockIdentity" i ON i."boxId"=b.id
 WHERE b."clientId"=${clientId} AND b.code IN (${client_1.Prisma.join([...new Set(codes)])})`);
    const assignments = await db.systemSetting.findMany({ where: { key: { in: boxes.map(b => `receipt.membership.v1:${clientId}:${b.id}`) } } });
    for (const b of boxes) {
        if (!b.warehouseId || !b.receiptAt || (0, fbs_primary_processing_1.classifyFbsPrimaryProcessingType)(b.code) === 'RETURN')
            continue;
        const assignment = assignments.find(a => a.key === `receipt.membership.v1:${clientId}:${b.id}`)?.value;
        const document = assignment?.clientId === clientId && assignment?.warehouseId === b.warehouseId ? assignment.series : `SERIES:${b.receiptAt.getUTCFullYear()}:${b.code.replace(/_[0-9]+$/, '')}`;
        const id = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([clientId, b.warehouseId, document])).digest('hex').slice(0, 32);
        const selected = selections.find(s => s.key === (0, exports.receiptProcessingKey)(clientId, b.warehouseId, id))?.value;
        if (!selected)
            continue;
        const profile = pricing?.[selected.kind];
        if (!profile)
            throw new common_1.BadRequestException('Для выбранного вида прихода не настроен тариф клиента.');
        if (result.has(b.code))
            throw new common_1.ConflictException('Неоднозначный короб для расчёта вида прихода.');
        result.set(b.code, { receiptId: id, kind: selected.kind, revision: selected.revision, profile, pricingRevision: pricing.revision });
    }
    return result;
}
function receiptProfileAmount(profile) { return new client_1.Prisma.Decimal(profile.unitPriceRub).div(profile.taxMode === 'ADD_6_PERCENT' ? '0.94' : '1'); }
// FIX: base receipt price replaces legacy primary prices; included services are not added again.
function applyReceiptPrimary(lines, selection, quantity) {
    if (!selection || lines.some(l => l.key === 'RETURN' && l.quantity > 0))
        return lines;
    if (!Number.isSafeInteger(quantity) || quantity < 1)
        throw new common_1.BadRequestException('Некорректное количество для расчёта приёмки.');
    const base = { key: 'RECEIPT_' + selection.kind, description: (selection.kind === 'WHITE' ? 'Частичная обработка' : 'Полная обработка'), quantity, unitPriceRub: receiptProfileAmount(selection.profile).toDecimalPlaces(2).toNumber(), priceBeforeTaxRub: Number(selection.profile.unitPriceRub), taxMode: selection.profile.taxMode, serviceId: null, serviceCode: 'FBS_PRIMARY_' + selection.kind, billingPolicy: 'RECEIPT_PROCESSING_V1' };
    return [base, ...lines.filter(l => !['WHITE', 'GRAY'].includes(l.key) && !(l.serviceId && selection.profile.includedServiceIds.includes(l.serviceId))).map(l => ({ ...l, billingPolicy: 'RECEIPT_PROCESSING_V1' }))];
}
