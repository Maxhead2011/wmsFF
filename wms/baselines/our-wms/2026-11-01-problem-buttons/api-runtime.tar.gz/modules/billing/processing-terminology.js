"use strict";
// Display-only vocabulary. Stored WHITE/GRAY keys, prices and receipt identities stay unchanged.
function text(value) {
    if (typeof value !== 'string') return value;
    return value
        .replace(/(Первичная обработка\s*[—–-]\s*)в белую/gi, '$1Частичная')
        .replace(/(Первичная обработка\s*[—–-]\s*)в серую/gi, '$1Полная')
        .replace(/Белая обработка/g, 'Частичная обработка')
        .replace(/белая обработка/g, 'частичная обработка')
        .replace(/Серая обработка/g, 'Полная обработка')
        .replace(/серая обработка/g, 'полная обработка');
}
const displayFields = new Set(['description', 'message', 'label', 'title', 'text', 'comment', 'serviceName']);
function present(value, field = '') {
    if (typeof value === 'string') return displayFields.has(field) ? text(value) : value;
    if (Array.isArray(value)) return value.map(item => present(item, field));
    if (!value || typeof value !== 'object' || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) return value;
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, present(item, key)]));
}
module.exports = { text, present };
