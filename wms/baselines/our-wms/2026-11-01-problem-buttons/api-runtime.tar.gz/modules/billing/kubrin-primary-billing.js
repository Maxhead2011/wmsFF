"use strict";
const {Prisma}=require('@prisma/client');
const {ConflictException}=require('@nestjs/common');
const CLIENT='c401202c-be57-4310-9939-2ea36767da37';
const PPR=new Set(['PPR_BAGS','PPR_BOXES']);
const primary=charge=>charge?.metadata?.kind==='FBS_PRIMARY_PROCESSING';
const isPpr=charge=>PPR.has(charge?.service?.code??charge?.metadata?.serviceCode);
function title(value){
 const key=value.serviceCode??value.metadata?.serviceCode;
 if(key==='FBS_PRIMARY_WHITE')return 'Первичная обработка — Частичная';
 if(key==='FBS_PRIMARY_GRAY')return 'Первичная обработка — Полная';
 return value.description;
}
function lines(clientId,rows){return clientId===CLIENT?rows.filter(row=>!PPR.has(row.serviceCode)).map(row=>({...row,description:title(row)})):rows;}
function check(condition,message){if(!condition)throw new ConflictException(message);}
const row=charge=>({chargeId:charge.id,description:title(charge),unit:charge.unit,quantity:charge.quantity,unitPriceRub:charge.unitPriceRub,totalRub:charge.totalRub,serviceDate:charge.serviceDate});
async function collect(db,input){
 const empty={charges:[],sources:[],ppr:[],renames:[]};
 if(input.clientId!==CLIENT)return empty;
 const target=input.invoice?await db.billingInvoice.findUnique({where:{id:input.invoice.id},include:{payments:true,items:{include:{charge:{include:{service:true}}}}}}):null;
 if(target&&(target.clientId!==CLIENT||target.status!=='DRAFT'||Number(target.paidRub)!==0||target.payments.length))return empty;
 const key='fbs-primary-invoice:'+CLIENT+':'+input.shipmentKey;
 const sources=await db.billingInvoice.findMany({where:{clientId:CLIENT,sourceKey:key},include:{payments:true,items:{include:{charge:{include:{service:true,invoiceItems:{include:{invoice:{select:{id:true,status:true}}}}}}}}}});
 const source=sources[0];
 const editable=source&&source.status==='DRAFT'&&Number(source.paidRub)===0&&!source.payments.length;
 const transferred=source&&target&&source.status==='CANCELLED'&&source.comment==='Объединено в FBS-счёт '+target.number;
 if(source&&!editable&&!transferred)return empty;
 if(source){check((source.warehouseId??input.warehouseId)===input.warehouseId,'Первичная обработка относится к другому филиалу.');check(source.warehouseId,'Не определён филиал первичной обработки.');}
 const candidates=[...(editable?source.items:[]),...(target?.items??[]).filter(item=>primary(item.charge))];
 const charges=new Map(),ppr=new Map(),renames=new Map();
 for(const item of candidates){
  const charge=item.charge;
  check(charge&&charge.clientId===CLIENT&&primary(charge)&&charge.metadata.shipmentKey===input.shipmentKey,'Первичная обработка не совпадает с источником FBS.');
  check(charge.status!=='CANCELLED'&&Number(item.totalRub)===Number(charge.totalRub)&&Number(item.quantity)===Number(charge.quantity)&&Number(item.unitPriceRub)===Number(charge.unitPriceRub),'Снимок первичной обработки изменился.');
  if(charge.invoiceItems)check(charge.invoiceItems.every(link=>link.invoice.status==='CANCELLED'||link.invoice.id===source?.id||link.invoice.id===target?.id),'Начисление уже включено в другой счёт.');
  if(isPpr(charge)){ppr.set(charge.id,charge);continue;}
  charges.set(charge.id,{...charge,description:title(charge)});
  if(title(charge)!==charge.description)renames.set(charge.id,title(charge));
 }
 return {charges:[...charges.values()],sources:editable?[source]:[],ppr:[...ppr.values()],renames:[...renames]};
}
async function finish(db,input,bundle,invoice){
 if(input.clientId!==CLIENT||!invoice||(!bundle.sources.length&&!bundle.ppr.length&&!bundle.renames.length))return;
 const target=await db.billingInvoice.findUnique({where:{id:invoice.id},include:{payments:true,items:true}});
 check(target?.clientId===CLIENT&&target.status==='DRAFT'&&Number(target.paidRub)===0&&!target.payments.length,'FBS-счёт изменился или оплачен.');
 const targetIds=new Set(target.items.map(item=>item.chargeId));
 check(bundle.charges.every(charge=>targetIds.has(charge.id)),'Не все строки первичной обработки перенесены.');
 for(const source of bundle.sources){const result=await db.billingInvoice.updateMany({where:{id:source.id,status:'DRAFT',paidRub:0,payments:{none:{}}},data:{status:'CANCELLED',comment:'Объединено в FBS-счёт '+target.number}});check(result.count===1,'Исходный счёт первичной обработки изменился.');}
 for(const charge of bundle.ppr){check(!targetIds.has(charge.id),'ПРР нельзя включать в FBS-счёт.');const result=await db.billingCharge.updateMany({where:{id:charge.id,clientId:CLIENT,status:'DRAFT',invoiceItems:{none:{invoice:{status:{not:'CANCELLED'}}}}},data:{status:'CANCELLED',comment:'Исключено из автоматической первичной обработки FBS по поручению пользователя; ПРР оформляется отдельно.'}});check(result.count===1,'ПРР уже выставлены или изменились.');}
 for(const [id,description] of bundle.renames){await db.billingCharge.update({where:{id},data:{description}});await db.billingInvoiceItem.updateMany({where:{invoiceId:target.id,chargeId:id},data:{description}});}
 await db.auditLog.create({data:{action:'KUBRIN_FBS_PRIMARY_COMBINED',entity:'BillingInvoice',entityId:target.id,payload:{clientId:CLIENT,shipmentKey:input.shipmentKey,sourceInvoiceIds:bundle.sources.map(i=>i.id),primaryChargeIds:bundle.charges.map(c=>c.id),excludedPprChargeIds:bundle.ppr.map(c=>c.id),renamedChargeIds:bundle.renames.map(x=>x[0]),totalRub:target.totalRub.toString()}}});
}
async function combineExisting(db,invoice){
 const prefix='fbs-invoice:'+CLIENT+':';if(invoice.clientId!==CLIENT||!invoice.sourceKey?.startsWith(prefix))return null;
 const input={clientId:CLIENT,shipmentKey:invoice.sourceKey.slice(prefix.length),warehouseId:invoice.warehouseId,invoice};
 const bundle=await collect(db,input);if(!bundle.sources.length&&!bundle.renames.length&&!bundle.ppr.length)return null;
 const target=await db.billingInvoice.findUnique({where:{id:invoice.id},include:{items:true}});const ids=new Set(target.items.map(i=>i.chargeId));
 for(const charge of bundle.charges)if(!ids.has(charge.id))await db.billingInvoiceItem.create({data:{invoiceId:target.id,...row(charge)}});
 const items=await db.billingInvoiceItem.findMany({where:{invoiceId:target.id}});const total=items.reduce((s,i)=>s.plus(i.totalRub),new Prisma.Decimal(0));
 await db.billingInvoice.update({where:{id:target.id},data:{totalRub:total}});
 await finish(db,input,bundle,target);
 return {id:target.id,number:target.number,totalRub:total.toFixed(2),primaryInvoices:bundle.sources.length,primaryRows:bundle.charges.length,excludedPprRub:bundle.ppr.reduce((s,c)=>s.plus(c.totalRub),new Prisma.Decimal(0)).toFixed(2)};
}
module.exports={CLIENT,PPR,lines,collect,finish,combineExisting};
