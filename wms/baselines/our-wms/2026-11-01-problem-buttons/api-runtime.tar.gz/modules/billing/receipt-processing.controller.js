"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceiptProcessingController = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const client_scope_service_1 = require("../auth/client-scope.service");
const billing_mutation_1 = require("./billing-mutation");
const receipt_processing_1 = require("./receipt-processing");
const common_2 = require("@nestjs/common");
// FIX: pricing is separate per client and opt-in; existing tariff tables and invoices are never modified.
let ReceiptProcessingController = class ReceiptProcessingController {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    async get(user, clientId) {
        this.scopes.requireClientAccess(user, clientId, 'read');
        if (!(0, receipt_processing_1.receiptProcessingEnabled)())
            return { enabled: false };
        const pricing = (await this.prisma.systemSetting.findUnique({ where: { key: (0, receipt_processing_1.receiptPricingKey)(clientId) } }))?.value ?? { revision: 0 };
        const services = await this.prisma.billingService.findMany({ where: { isActive: true, unit: 'PIECE', code: { notIn: ['FBS_PROCESSING', 'BOX_60_40_40', 'BOX_ASSEMBLY', 'PALLET', 'PALLET_ASSEMBLY'] } }, select: { id: true, name: true, code: true } });
        return { enabled: true, pricing, services, canWrite: !user.isDemo && user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)) && user.permissionCodes.some(p => ['billing:write', 'system:admin'].includes(p)) };
    }
    async save(user, clientId, body) {
        if (!(0, receipt_processing_1.receiptProcessingEnabled)())
            throw new common_1.NotFoundException('Виды прихода не включены.');
        this.scopes.requireClientAccess(user, clientId, 'write');
        if (user.isDemo || !user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)))
            throw new common_1.ForbiddenException('Настройки меняет администратор.');
        if (!body || !Number.isSafeInteger(body.revision) || body.revision < 0)
            throw new common_1.BadRequestException('Укажите версию настроек.');
        return (0, billing_mutation_1.runBillingMutation)(this.prisma, async (tx) => {
            const key = (0, receipt_processing_1.receiptPricingKey)(clientId), saved = await tx.systemSetting.findUnique({ where: { key } }), previous = saved?.value;
            if ((previous?.revision ?? 0) !== body.revision)
                throw new common_2.ConflictException('Настройки уже изменены. Обновите страницу.');
            const services = await tx.billingService.findMany({ where: { isActive: true, unit: 'PIECE', code: { notIn: ['FBS_PROCESSING', 'BOX_60_40_40', 'BOX_ASSEMBLY', 'PALLET', 'PALLET_ASSEMBLY'] } }, select: { id: true } });
            const next = { revision: body.revision + 1, WHITE: (0, receipt_processing_1.normalizeReceiptProfile)(body.WHITE, services.map(s => s.id)), GRAY: (0, receipt_processing_1.normalizeReceiptProfile)(body.GRAY, services.map(s => s.id)), changedAt: new Date().toISOString(), changedByName: user.name };
            await tx.systemSetting.upsert({ where: { key }, create: { key, value: next, updatedByUserId: user.id }, update: { value: next, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'RECEIPT_PROCESSING_PRICING_CHANGED', entity: 'Client', entityId: clientId, payload: { previous: previous ?? null, next } } });
            return next;
        });
    }
};
exports.ReceiptProcessingController = ReceiptProcessingController;
__decorate([
    (0, common_1.Get)(':clientId'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], ReceiptProcessingController.prototype, "get", null);
__decorate([
    (0, common_1.Post)(':clientId'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('clientId')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object]),
    __metadata("design:returntype", Promise)
], ReceiptProcessingController.prototype, "save", null);
exports.ReceiptProcessingController = ReceiptProcessingController = __decorate([
    (0, common_1.Controller)('billing/receipt-processing'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], ReceiptProcessingController);
