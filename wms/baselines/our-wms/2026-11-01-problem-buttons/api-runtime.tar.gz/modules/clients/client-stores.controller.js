"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientStoresController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const client_stores_service_1 = require("./client-stores.service");
// FIX: store metadata is scoped to the existing payer client; no new client/balance is created.
let ClientStoresController = class ClientStoresController {
    stores;
    constructor(stores) {
        this.stores = stores;
    }
    get(clientId, user) { return this.stores.get(clientId, user); }
    save(clientId, stores, user) { return this.stores.save(clientId, stores, user); }
    getSku(clientId, skuId, user) { return this.stores.getSkuStores(clientId, skuId, user); }
    saveSku(clientId, skuId, ids, expected, user) { return this.stores.saveSkuStores(clientId, skuId, ids, expected, user); }
};
exports.ClientStoresController = ClientStoresController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientStoresController.prototype, "get", null);
__decorate([
    (0, common_1.Put)(),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)('stores')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientStoresController.prototype, "save", null);
__decorate([
    (0, common_1.Get)('skus/:skuId'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Param)('skuId')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", void 0)
], ClientStoresController.prototype, "getSku", null);
__decorate([
    (0, common_1.Put)('skus/:skuId'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Param)('skuId')),
    __param(2, (0, common_1.Body)('storeIds')),
    __param(3, (0, common_1.Body)('expectedStoreIds')),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientStoresController.prototype, "saveSku", null);
exports.ClientStoresController = ClientStoresController = __decorate([
    (0, common_1.Controller)('clients/:clientId/stores'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:read'),
    __metadata("design:paramtypes", [client_stores_service_1.ClientStoresService])
], ClientStoresController);
