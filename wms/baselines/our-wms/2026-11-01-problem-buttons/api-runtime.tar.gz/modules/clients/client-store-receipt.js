"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.skuStoresKey = exports.storeDirectoryKey = void 0;
exports.validateSkuStores = validateSkuStores;
exports.assertStoreReceipt = assertStoreReceipt;
const common_1 = require("@nestjs/common");
const client_stores_policy_1 = require("./client-stores.policy");
const storeDirectoryKey = (clientId) => `client.stores.v1:${clientId}`;
exports.storeDirectoryKey = storeDirectoryKey;
const skuStoresKey = (clientId, skuId) => `client.sku-stores.v1:${clientId}:${skuId}`;
exports.skuStoresKey = skuStoresKey;
// FIX: multiple permissions reference one physical SKU, never separate balances.
function validateSkuStores(value, allowedStoreIds) {
    if (!Array.isArray(value) || !value.length || value.length > 50 ||
        value.some(id => typeof id !== 'string' || !allowedStoreIds.includes(id)) || new Set(value).size !== value.length) {
        throw new common_1.BadRequestException('Укажите разрешённые магазины товара без повторов.');
    }
    return [...value].sort();
}
// FIX: invoked inside the stock transaction. Unknown old scans require review, not inferred ownership.
async function assertStoreReceipt(tx, input) {
    if (process.env.WMS_CLIENT_STORES_ENABLED !== 'true' || process.env.WMS_CLIENT_STORE_RECEIPTS_ENABLED !== 'true')
        return null;
    await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${(0, exports.storeDirectoryKey)(input.clientId)}))`;
    const directory = await tx.systemSetting.findUnique({ where: { key: (0, exports.storeDirectoryKey)(input.clientId) } });
    if (!directory) {
        if (input.storeId)
            throw new common_1.BadRequestException('Магазины клиента ещё не настроены.');
        return null;
    }
    const connections = await tx.clientMarketplaceConnection.findMany({ where: { clientId: input.clientId }, select: { id: true } });
    let stores;
    try {
        stores = (0, client_stores_policy_1.validateStoreDirectory)(directory.value, connections.map(c => c.id));
    }
    catch {
        throw new common_1.BadRequestException('Связи магазинов требуют проверки администратором.');
    }
    const store = stores.find(s => s.id === input.storeId);
    if (!store)
        throw new common_1.BadRequestException('Укажите магазин приёмки. Старый скан без магазина требует разбора.');
    const membership = await tx.systemSetting.findUnique({ where: { key: (0, exports.skuStoresKey)(input.clientId, input.skuId) } });
    const ids = validateSkuStores(membership?.value, stores.map(s => s.id));
    if (!ids.includes(store.id))
        throw new common_1.BadRequestException('Товар не разрешён для выбранного магазина. Проверьте ШК.');
    if (!input.sourceDocument?.trim())
        throw new common_1.BadRequestException('Для приёмки магазина нужен документ приёмки.');
    const key = `client.receipt-store.v1:${input.clientId}:${input.sourceDocument}`;
    const context = await tx.systemSetting.findUnique({ where: { key } });
    if (context && context.value !== store.id)
        throw new common_1.BadRequestException('Документ приёмки уже относится к другому магазину.');
    if (!context)
        await tx.systemSetting.create({ data: { key, value: store.id } });
    return { storeId: store.id, storeName: store.name };
}
