"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientStoresService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_stores_policy_1 = require("./client-stores.policy");
const client_store_receipt_1 = require("./client-store-receipt");
let ClientStoresService = class ClientStoresService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    key(clientId) { return `client.stores.v1:${clientId}`; }
    async check(clientId, user, mode) {
        if (process.env.WMS_CLIENT_STORES_ENABLED !== 'true')
            throw new common_1.NotFoundException('Магазины клиента не включены.');
        this.scopes.requireClientAccess(user, clientId, mode);
        const client = await this.prisma.client.findFirst({ where: { id: clientId, isDemo: Boolean(user.isDemo) }, select: { id: true } });
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
    }
    async get(clientId, user) {
        await this.check(clientId, user, 'read');
        const [setting, connections] = await Promise.all([
            this.prisma.systemSetting.findUnique({ where: { key: this.key(clientId) } }),
            this.prisma.clientMarketplaceConnection.findMany({ where: { clientId }, select: { id: true, marketplace: true, accountName: true, isActive: true } }),
        ]);
        let stores = [];
        if (setting) {
            try {
                stores = (0, client_stores_policy_1.validateStoreDirectory)(setting.value, connections.map((c) => c.id));
            }
            catch {
                throw new common_1.BadRequestException('Связи магазинов требуют проверки администратором.');
            }
        }
        return { clientId, stores, connections };
    }
    async save(clientId, value, user) {
        await this.check(clientId, user, 'write');
        if (!user.roleCodes.some((r) => r === 'ADMIN' || r === 'OWNER'))
            throw new common_1.ForbiddenException('Магазины настраивает администратор или собственник.');
        const connections = await this.prisma.clientMarketplaceConnection.findMany({ where: { clientId }, select: { id: true } });
        let stores;
        try {
            stores = (0, client_stores_policy_1.validateStoreDirectory)(value, connections.map(c => c.id));
        }
        catch (e) {
            throw new common_1.BadRequestException(e instanceof Error ? e.message : 'Неверные магазины.');
        }
        // FIX: identity changes need an explicit migration, not an unnoticed reassignment of history.
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${this.key(clientId)}))`;
            const previous = await tx.systemSetting.findUnique({ where: { key: this.key(clientId) } });
            if (previous) {
                const old = (0, client_stores_policy_1.validateStoreDirectory)(previous.value, connections.map(c => c.id));
                for (const store of old) {
                    const next = stores.find(s => s.id === store.id);
                    if (!next || store.connectionIds.some(id => !next.connectionIds.includes(id)))
                        throw new common_1.BadRequestException('Перенос подключения или удаление магазина требует отдельной сверки истории.');
                }
            }
            await tx.systemSetting.upsert({ where: { key: this.key(clientId) }, create: { key: this.key(clientId), value: stores, updatedByUserId: user.id }, update: { value: stores, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'CLIENT_STORES_SAVED', entity: 'Client', entityId: clientId,
                    payload: { before: previous?.value ?? null, after: stores } } });
            return { clientId, stores };
        });
    }
    // FIX: membership changes are explicit, audited and do not clone shared physical stock.
    async getSkuStores(clientId, skuId, user) {
        const { stores } = await this.get(clientId, user);
        const sku = await this.prisma.sku.findFirst({ where: { id: skuId, clientId }, select: { id: true } });
        if (!sku)
            throw new common_1.NotFoundException('Товар клиента не найден.');
        const setting = await this.prisma.systemSetting.findUnique({ where: { key: (0, client_store_receipt_1.skuStoresKey)(clientId, skuId) } });
        return { clientId, skuId, storeIds: setting ? (0, client_store_receipt_1.validateSkuStores)(setting.value, stores.map(s => s.id)) : [] };
    }
    async saveSkuStores(clientId, skuId, value, expected, user) {
        await this.check(clientId, user, 'write');
        if (!user.roleCodes.some(r => r === 'ADMIN' || r === 'OWNER'))
            throw new common_1.ForbiddenException('Связи товара настраивает администратор или собственник.');
        if (!Array.isArray(expected) || expected.some(id => typeof id !== 'string'))
            throw new common_1.BadRequestException('Нужна исходная версия связей товара.');
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${this.key(clientId)}))`;
            const sku = await tx.sku.findFirst({ where: { id: skuId, clientId }, select: { id: true } });
            if (!sku)
                throw new common_1.NotFoundException('Товар клиента не найден.');
            const directory = await tx.systemSetting.findUnique({ where: { key: this.key(clientId) } });
            const connections = await tx.clientMarketplaceConnection.findMany({ where: { clientId }, select: { id: true } });
            let stores;
            try {
                stores = (0, client_stores_policy_1.validateStoreDirectory)(directory?.value, connections.map(c => c.id));
            }
            catch {
                throw new common_1.BadRequestException('Сначала настройте магазины клиента.');
            }
            const storeIds = (0, client_store_receipt_1.validateSkuStores)(value, stores.map(s => s.id));
            const key = (0, client_store_receipt_1.skuStoresKey)(clientId, skuId);
            const previous = await tx.systemSetting.findUnique({ where: { key } });
            const before = previous ? (0, client_store_receipt_1.validateSkuStores)(previous.value, stores.map(s => s.id)) : [];
            if (JSON.stringify([...expected].sort()) !== JSON.stringify(before))
                throw new common_1.BadRequestException('Связи изменились. Обновите товар и повторите проверку.');
            if (before.some(id => !storeIds.includes(id)))
                throw new common_1.BadRequestException('Удаление магазина у товара требует сверки активных резервов и истории.');
            await tx.systemSetting.upsert({ where: { key }, create: { key, value: storeIds, updatedByUserId: user.id }, update: { value: storeIds, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'SKU_STORES_SAVED', entity: 'Sku', entityId: skuId, payload: { clientId, before, after: storeIds } } });
            return { clientId, skuId, storeIds };
        });
    }
    async decorateOrders(clientId, response, user) {
        // FIX: the sold WMS and clients without a configured directory retain the exact old payload.
        if (process.env.WMS_CLIENT_STORES_ENABLED !== 'true')
            return response;
        const { stores } = await this.get(clientId, user);
        if (!stores.length)
            return response;
        const visibleConnections = new Set(response.connections.map(c => c.id));
        const visibleStores = stores.map(s => ({ ...s, connectionIds: s.connectionIds.filter(id => visibleConnections.has(id)) })).filter(s => s.connectionIds.length);
        return { ...response, stores: visibleStores, orders: response.orders.map(order => {
                const store = (0, client_stores_policy_1.storeForConnection)(visibleStores, order.connectionId);
                return { ...order, storeId: store?.id ?? null, storeName: store?.name ?? null };
            }) };
    }
};
exports.ClientStoresService = ClientStoresService;
exports.ClientStoresService = ClientStoresService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, client_scope_service_1.ClientScopeService])
], ClientStoresService);
