"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g, _h;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonFboImportController = void 0;
const ozon_link_import_service_1 = require("./ozon-link-import.service");
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const ozon_fbo_import_dto_1 = require("./dto/ozon-fbo-import.dto");
const ozon_fbo_import_service_1 = require("./ozon-fbo-import.service");
let OzonFboImportController = class OzonFboImportController {
    service;
    links;
    constructor(service, links) {
        this.service = service;
        this.links = links;
    }
    linkConnections(id, user) { return this.links.connections(id, user); }
    previewLinks(body, user) { return this.links.preview(body, user); }
    commitLinks(body, user) { return this.links.commit(body, user); }
    capability() { return { enabled: process.env.WMS_OZON_FBO_IMPORT_ENABLED === 'true' }; }
    // FIX: client-specific choices are authorized by the same service as preview/commit.
    warehouses(clientId, user) { return this.service.warehouses(clientId, user); }
    list(clientId, user, warehouseId, view, allClients, beforeNumber) { return this.service.list(clientId, user, warehouseId, view, allClients, beforeNumber); }
    preview(file, dto, user) { return this.service.preview(file, dto, user); }
    commit(file, dto, user) { return this.service.commit(file, dto, user); }
};
exports.OzonFboImportController = OzonFboImportController;
__decorate([
    (0, common_1.Get)('link-connections'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "linkConnections", null);
__decorate([
    (0, common_1.Post)('links/preview'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "previewLinks", null);
__decorate([
    (0, common_1.Post)('links/commit'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "commitLinks", null);
__decorate([
    (0, common_1.Get)('capability'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "capability", null);
__decorate([
    (0, common_1.Get)('warehouses'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "warehouses", null);
__decorate([
    (0, common_1.Get)('requests'),
    __param(0, (0, common_1.Query)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __param(2, (0, common_1.Query)('warehouseId')),
    __param(3, (0, common_1.Query)('view')),
    __param(4, (0, common_1.Query)('allClients')),
    __param(5, (0, common_1.Query)('beforeNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String, String, String, String]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('preview'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_d = typeof Express !== "undefined" && (_c = Express.Multer) !== void 0 && _c.File) === "function" ? _d : Object, typeof (_e = typeof ozon_fbo_import_dto_1.OzonFboImportDto !== "undefined" && ozon_fbo_import_dto_1.OzonFboImportDto) === "function" ? _e : Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)('commit'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_g = typeof Express !== "undefined" && (_f = Express.Multer) !== void 0 && _f.File) === "function" ? _g : Object, typeof (_h = typeof ozon_fbo_import_dto_1.OzonFboImportDto !== "undefined" && ozon_fbo_import_dto_1.OzonFboImportDto) === "function" ? _h : Object, Object]),
    __metadata("design:returntype", void 0)
], OzonFboImportController.prototype, "commit", null);
exports.OzonFboImportController = OzonFboImportController = __decorate([
    (0, common_1.Controller)('ozon-fbo-import'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __metadata("design:paramtypes", [typeof (_a = typeof ozon_fbo_import_service_1.OzonFboImportService !== "undefined" && ozon_fbo_import_service_1.OzonFboImportService) === "function" ? _a : Object, typeof (_b = typeof ozon_link_import_service_1.OzonLinkImportService !== "undefined" && ozon_link_import_service_1.OzonLinkImportService) === "function" ? _b : Object])
], OzonFboImportController);
