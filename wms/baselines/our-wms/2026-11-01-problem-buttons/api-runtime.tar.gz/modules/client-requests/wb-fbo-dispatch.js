"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dispatchKey = void 0;
exports.wbDispatchContexts = wbDispatchContexts;
exports.assertFboProcessChange = assertFboProcessChange;
const common_1 = require("@nestjs/common");
const dispatchKey = (id) => 'wb-fbo-dispatch:v1:' + id;
exports.dispatchKey = dispatchKey;
// FIX: dispatch is separate from warehouse ledger completion and remains unfinished.
async function wbDispatchContexts(db, ids) {
    const result = {};
    if (process.env.WMS_MARKETPLACE_WORKSPACES_ENABLED !== 'true' || !ids.length)
        return result;
    for (const row of await db.systemSetting.findMany({ where: { key: { in: ids.map(exports.dispatchKey) } } })) {
        const v = row.value;
        if (typeof v?.at === 'string')
            result[row.key.slice('wb-fbo-dispatch:v1:'.length)] = v.at;
    }
    return result;
}
// FIX: loading cannot be silently undone through an ordinary status dropdown.
async function assertFboProcessChange(db, id, status) {
    if (process.env.WMS_MARKETPLACE_WORKSPACES_ENABLED !== 'true')
        return;
    const dispatch = await db.systemSetting.findUnique({ where: { key: (0, exports.dispatchKey)(id) } });
    if (dispatch && status !== 'DONE')
        throw new common_1.ConflictException('Товар загружен в автомобиль. Для возврата требуется складское исправление.');
    if (status === 'DONE') {
        const binding = await db.systemSetting.findUnique({ where: { key: 'wb-fbo-tracking:v1:' + id } });
        if (binding && ![4, 5, 6].includes(binding.value.statusId))
            throw new common_1.ConflictException('WB ещё не подтвердил сдачу. Обновите статус связанной поставки.');
    }
}
