"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WbFboSupplyController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const wb_fbo_supply_service_1 = require("./wb-fbo-supply.service");
class BindWbFboDto {
    connectionId;
    input;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], BindWbFboDto.prototype, "connectionId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(2000),
    __metadata("design:type", String)
], BindWbFboDto.prototype, "input", void 0);
let WbFboSupplyController = class WbFboSupplyController {
    service;
    constructor(service) {
        this.service = service;
    }
    view(id, user) { return this.service.view(id, user); }
    bind(id, body, user) { return this.service.bind(id, body.connectionId, body.input, user); }
    refresh(id, user) { return this.service.refresh(id, user); }
    gate(id, user) { return this.service.gate(id, user); }
};
exports.WbFboSupplyController = WbFboSupplyController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WbFboSupplyController.prototype, "view", null);
__decorate([
    (0, common_1.Post)('bind'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, BindWbFboDto, Object]),
    __metadata("design:returntype", void 0)
], WbFboSupplyController.prototype, "bind", null);
__decorate([
    (0, common_1.Post)('refresh'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WbFboSupplyController.prototype, "refresh", null);
__decorate([
    (0, common_1.Post)('gate'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], WbFboSupplyController.prototype, "gate", null);
exports.WbFboSupplyController = WbFboSupplyController = __decorate([
    (0, common_1.Controller)('client-requests/:id/wb-fbo-supply'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof wb_fbo_supply_service_1.WbFboSupplyService !== "undefined" && wb_fbo_supply_service_1.WbFboSupplyService) === "function" ? _a : Object])
], WbFboSupplyController);
