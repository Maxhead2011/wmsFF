"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonFboImportDto = void 0;
const class_validator_1 = require("class-validator");
const import_outbound_request_xlsx_dto_1 = require("./import-outbound-request-xlsx.dto");
// FIX: explicit branch selection belongs only to the Ozon import workflow.
class OzonFboImportDto extends import_outbound_request_xlsx_dto_1.ImportOutboundRequestXlsxDto {
    stockDecision;
    warehouseId;
}
exports.OzonFboImportDto = OzonFboImportDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], OzonFboImportDto.prototype, "stockDecision", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], OzonFboImportDto.prototype, "warehouseId", void 0);
