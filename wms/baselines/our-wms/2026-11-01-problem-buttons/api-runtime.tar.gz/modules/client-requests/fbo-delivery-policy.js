"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deliveryRetryMs = exports.deliveryVersion = exports.deliveryKey = exports.fboDeliveryEnabled = void 0;
exports.ozonDeliveryProof = ozonDeliveryProof;
exports.wbDeliveryAccepted = wbDeliveryAccepted;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const ozon_supply_policy_1 = require("./ozon-supply-policy");
const fboDeliveryEnabled = () => process.env.WMS_FBO_DELIVERY_SYNC_ENABLED === 'true';
exports.fboDeliveryEnabled = fboDeliveryEnabled;
const deliveryKey = (id) => 'fbo-delivery-sync:v1:' + id;
exports.deliveryKey = deliveryKey;
const deliveryVersion = (value) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(value)).digest('hex');
exports.deliveryVersion = deliveryVersion;
const accepted = new Set(['ACCEPTED_AT_SUPPLY_WAREHOUSE', 'IN_TRANSIT', 'ACCEPTANCE_AT_STORAGE_WAREHOUSE', 'REPORTS_CONFIRMATION_AWAITING', 'COMPLETED']);
const ids = (values, field) => values.map(v => String(v[field])).sort();
const exact = (a, b) => a.length > 0 && new Set(a).size === a.length && new Set(b).size === b.length && JSON.stringify(a) === JSON.stringify(b);
// FIX: exact complete response, all linked orders AND all their directions; never infer acceptance from a partial reply.
function ozonDeliveryProof(link, data) {
    const wanted = (0, ozon_supply_policy_1.supplyOrders)(link), orders = data?.orders;
    if (!Array.isArray(orders) || !exact(ids(wanted, 'orderId'), ids(orders, 'order_id')))
        throw new common_1.ConflictException('Ozon не подтвердил все заявки поставки.');
    for (const w of wanted) {
        const o = orders.find((v) => String(v.order_id) === w.orderId);
        if (!Array.isArray(o.supplies) || !exact(ids(w.supplies, 'id'), ids(o.supplies, 'supply_id')))
            throw new common_1.ConflictException('Направления Ozon изменились. Нужна сверка привязки.');
        if (!accepted.has(o.state) || o.supplies.some((s) => !accepted.has(s.state)))
            return null;
    }
    return orders.map((o) => ({ orderId: String(o.order_id), state: o.state, supplies: o.supplies.map((s) => ({ id: String(s.supply_id), state: s.state })) }));
}
function wbDeliveryAccepted(snapshot, quantity, dispatch) {
    return Boolean(dispatch?.at && [4, 5, 6].includes(snapshot?.statusId) && Number.isSafeInteger(quantity) && quantity > 0 && snapshot.quantity === quantity);
}
const deliveryRetryMs = (attempt) => Math.min(30 * 60_000, 60_000 * 2 ** Math.min(5, Math.max(0, attempt - 1)));
exports.deliveryRetryMs = deliveryRetryMs;
