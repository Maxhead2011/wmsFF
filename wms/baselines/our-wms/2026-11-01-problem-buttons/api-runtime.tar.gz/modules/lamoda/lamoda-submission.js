"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaSubmission = void 0;
const common_1 = require("@nestjs/common");
const client_request_warehouse_scope_1 = require("../client-requests/client-request-warehouse-scope");
const lamoda_actual_shipment_1 = require("./lamoda-actual-shipment");
const lamoda_client_1 = require("./lamoda-client");
const node_crypto_1 = require("node:crypto");
const node_util_1 = require("node:util");
// FIX: persisted sending state is never retried automatically, including after process failure.
class LamodaSubmission {
    db;
    remote;
    constructor(db, remote) {
        this.db = db;
        this.remote = remote;
    }
    async context(tx, accountId, requestId, user) {
        const b = await tx.lamodaFboAssembly.findFirst({ where: { requestId, plan: { accountId } }, include: { plan: true, request: { include: { items: { include: { sku: true } } } } } });
        if (!b)
            throw new common_1.NotFoundException('Сборка Lamoda не найдена.');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, b.plan, 'read');
        const rows = await tx.$queryRaw `SELECT "submission" FROM "LamodaFboAssembly" WHERE "requestId"=${requestId}`;
        return { b, receipt: rows[0]?.submission ?? null };
    }
    async save(tx, id, r) { await tx.$executeRaw `UPDATE "LamodaFboAssembly" SET "submission"=${JSON.stringify(r)}::jsonb WHERE "requestId"=${id}`; }
    async composition(tx, accountId, id, user, form) {
        const { b, receipt } = await this.context(tx, accountId, id, user);
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, b.plan, 'write');
        if (b.plan.remoteShipmentId)
            throw new common_1.ConflictException('Сборка уже связана с поставкой Lamoda. Новая поставка не создаётся.');
        if (['CANCELLED', 'REJECTED'].includes(b.request.status))
            throw new common_1.ConflictException('Заявка отменена.');
        const assembly = await tx.fboAssembly.findUnique({ where: { requestId: id }, include: { units: true, boxes: true } });
        if (assembly?.phase !== 'COMPLETED')
            throw new common_1.ConflictException('Завершите сборку и контроль коробов на ТСД.');
        const cards = await tx.lamodaProduct.findMany({ where: { accountId, isPresent: true, linkState: 'CONFIRMED' } });
        const lines = b.plan.items;
        const identities = b.request.items.map(item => {
            const matches = cards.filter(c => c.skuId === item.skuId && lines.some(l => l.barcode === c.barcode && (!l.remoteSku || l.remoteSku === c.remoteSku) && (!l.article || l.article === c.externalSku)));
            const prices = form?.prices.filter(p => p.skuId === item.skuId);
            if (matches.length !== 1 || (form && prices?.length !== 1) || !matches[0].externalSku)
                throw new common_1.BadRequestException('Подтвердите однозначное соответствие каждому товару; для отправки API укажите цены.');
            if (Array.isArray(b.relabelLabels)) {
                const labels = b.relabelLabels;
                const frozen = labels.filter(l => l.skuId === item.skuId);
                if (frozen.length !== 1 || frozen[0].barcode !== matches[0].barcode || frozen[0].article !== matches[0].remoteSku)
                    throw new common_1.ConflictException('Соответствие Lamoda изменилось после переклейки. Проверьте этикетки.');
            }
            if (assembly.units.filter(u => u.skuId === item.skuId && u.state === 'PACKED').length !== item.quantity)
                throw new common_1.ConflictException('Факт упаковки отличается от состава заявки.');
            return { skuId: item.skuId, externalSku: matches[0].externalSku, ean: matches[0].barcode ?? '', priceMinor: prices?.[0]?.priceMinor };
        });
        return { receipt, identities, boxes: assembly.boxes, units: assembly.units.map(u => ({ ...u, requiresKiz: !!u.markId || b.request.items.some(i => i.skuId === u.skuId && i.sku?.needsChestnyZnak && !i.sku.isUnmarked) })) };
    }
    async build(tx, accountId, id, user, form) {
        const { receipt, ...composition } = await this.composition(tx, accountId, id, user, form);
        const payload = (0, lamoda_actual_shipment_1.buildActualLamodaShipment)({ ...form, ...composition, identities: composition.identities.map(i => ({ ...i, priceMinor: i.priceMinor })) });
        if (receipt && !(0, node_util_1.isDeepStrictEqual)(receipt.payload, payload))
            throw new common_1.ConflictException('Состав уже зафиксирован для отправки. Сначала сверка с Lamoda.');
        return { payload, receipt };
    }
    async template(accountId, id, user) {
        return this.db.$transaction(async (tx) => {
            const { receipt, ...composition } = await this.composition(tx, accountId, id, user);
            if (receipt)
                throw new common_1.ConflictException('Отправка уже выполнялась. Сверьте её статус, прежде чем оформлять поставку вручную.');
            return (0, lamoda_actual_shipment_1.buildActualLamodaTemplate)(composition);
        }, { isolationLevel: 'RepeatableRead', timeout: 30000 });
    }
    async view(accountId, id, user) {
        return this.db.$transaction(async (tx) => {
            const { b, receipt } = await this.context(tx, accountId, id, user);
            const assembly = await tx.fboAssembly.findUnique({ where: { requestId: id }, select: { phase: true } });
            return { receipt, readyForTemplate: assembly?.phase === 'COMPLETED' && !receipt && !b.plan.remoteShipmentId, remoteShipmentId: b.plan.remoteShipmentId, items: b.request.items.map(i => ({ skuId: i.skuId, name: i.name || i.sku?.name, size: i.sku?.size, quantity: i.quantity })) };
        });
    }
    async preview(accountId, id, user, form) { return this.db.$transaction(tx => this.build(tx, accountId, id, user, form), { isolationLevel: 'RepeatableRead', timeout: 30000 }); }
    async send(accountId, id, user, form, c) {
        if (process.env.WMS_LAMODA_FBO_SUBMISSION_ENABLED !== 'true')
            throw new common_1.ConflictException('Отправка поставок Lamoda выключена.');
        const prepared = await this.db.$transaction(async (tx) => {
            await tx.$queryRaw `SELECT "id" FROM "ClientRequest" WHERE "id"=${id} FOR UPDATE`;
            const { payload, receipt } = await this.build(tx, accountId, id, user, form);
            if (receipt)
                return { payload, receipt, send: false };
            const r = { state: 'SENDING', payload, updatedAt: new Date().toISOString() };
            // Unique operation key protects a reused UPD number across WMS assemblies in one account.
            try {
                await tx.lamodaOperation.create({ data: { id: (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([accountId, payload.externalShipmentId])).digest('hex'), accountId, operationKey: `FBO:${payload.externalShipmentId}`, payloadHash: (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(payload)).digest('hex'), status: 'SENDING' } });
            }
            catch (e) {
                if (e?.code === 'P2002')
                    throw new common_1.ConflictException('Этот номер поставки уже использован. Проверьте другую сборку и кабинет Lamoda.');
                throw e;
            }
            await this.save(tx, id, r);
            await tx.auditLog.create({ data: { userId: user.id, action: 'LAMODA_FBO_SUBMISSION_STARTED', entity: 'ClientRequest', entityId: id, payload: { accountId, externalShipmentId: payload.externalShipmentId } } });
            return { payload, receipt: r, send: true };
        }, { timeout: 30000 });
        if (!prepared.send) {
            if (prepared.receipt.state === 'SUCCEEDED')
                return prepared.receipt;
            throw new common_1.ConflictException('Отправка уже выполнялась. Обновите статус; повтор заблокирован до сверки.');
        }
        let result;
        try {
            const response = await this.remote.execute(c, { kind: 'FBO_CREATE', body: prepared.payload });
            if (!response || typeof response.id !== 'string' || response.externalShipmentId !== prepared.payload.externalShipmentId || response.plannedDate !== prepared.payload.plannedDate)
                throw new lamoda_client_1.LamodaApiError('INVALID_WRITE_RESPONSE', undefined, 'UNKNOWN');
            result = { ...prepared.receipt, state: 'SUCCEEDED', remoteId: response.id, updatedAt: new Date().toISOString() };
        }
        catch (e) {
            result = { ...prepared.receipt, state: e instanceof lamoda_client_1.LamodaApiError && e.outcome === 'REJECTED' ? 'REJECTED' : 'UNKNOWN', error: e instanceof lamoda_client_1.LamodaApiError ? `${e.code}${e.status ? ` (${e.status})` : ''}` : 'UNKNOWN_RESULT', updatedAt: new Date().toISOString() };
        }
        await this.db.$transaction(async (tx) => {
            await tx.$queryRaw `SELECT "id" FROM "ClientRequest" WHERE "id"=${id} FOR UPDATE`;
            const current = await this.context(tx, accountId, id, user);
            if (current.receipt?.state === 'SUCCEEDED') {
                result = current.receipt;
                return;
            }
            await this.save(tx, id, result);
            await tx.lamodaOperation.updateMany({ where: { accountId, operationKey: `FBO:${result.payload.externalShipmentId}`, status: 'SENDING' }, data: { status: result.state, errorCode: result.error ?? null } });
        });
        return result;
    }
    async resetRejected(accountId, id, user) {
        return this.db.$transaction(async (tx) => {
            await tx.$queryRaw `SELECT "id" FROM "ClientRequest" WHERE "id"=${id} FOR UPDATE`;
            const { b, receipt } = await this.context(tx, accountId, id, user);
            (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, b.plan, 'write');
            if (receipt?.state !== 'REJECTED')
                throw new common_1.ConflictException('Сброс разрешён только после явного отказа API. Неопределённый ответ требует сверки.');
            await tx.auditLog.create({ data: { userId: user.id, action: 'LAMODA_FBO_REJECTION_RESET', entity: 'ClientRequest', entityId: id, payload: { externalShipmentId: receipt.payload.externalShipmentId, error: receipt.error } } });
            await tx.lamodaOperation.deleteMany({ where: { accountId, operationKey: `FBO:${receipt.payload.externalShipmentId}`, status: 'REJECTED' } });
            await tx.$executeRaw `UPDATE "LamodaFboAssembly" SET "submission"=NULL WHERE "requestId"=${id}`;
            return { reset: true };
        });
    }
    async refresh(accountId, id, user, c) {
        const { receipt } = await this.view(accountId, id, user);
        if (!receipt)
            throw new common_1.ConflictException('Поставка ещё не отправлялась.');
        let remoteId = receipt.remoteId;
        if (!remoteId) {
            const matches = (await this.remote.collection(c, 'FBO_SHIPMENTS', { from: receipt.payload.plannedDate, to: receipt.payload.plannedDate })).filter(s => s.externalShipmentId === receipt.payload.externalShipmentId);
            if (matches.length !== 1 || typeof matches[0].id !== 'string')
                throw new common_1.ConflictException('Не удалось однозначно найти поставку. Повторная отправка заблокирована; проверьте кабинет Lamoda.');
            remoteId = matches[0].id;
        }
        const data = await this.remote.fboShipment(c, remoteId);
        if (data.shipment.externalShipmentId !== receipt.payload.externalShipmentId)
            throw new common_1.ConflictException('Идентификатор поставки не совпадает.');
        if (!receipt.remoteId) {
            if (data.shipment.plannedDate !== receipt.payload.plannedDate || data.shipment.warehouseCode !== receipt.payload.warehouseCode)
                throw new common_1.ConflictException('Дата или склад найденной поставки отличаются.');
            const counts = (items) => {
                const m = new Map();
                for (const i of items) {
                    const q = i.quantity ?? i.quantityPlanned;
                    if (typeof i.ean !== 'string' || !Number.isSafeInteger(q) || Number(q) < 0)
                        throw new common_1.ConflictException('Не удалось сверить состав Lamoda.');
                    m.set(i.ean, (m.get(i.ean) ?? 0) + Number(q));
                }
                return JSON.stringify([...m].sort());
            };
            if (counts(data.items) !== counts(receipt.payload.items))
                throw new common_1.ConflictException('Состав найденной поставки отличается. Нужна ручная сверка.');
        }
        const next = { ...receipt, state: 'SUCCEEDED', remoteId, remoteStatus: String(data.shipment.status), updatedAt: new Date().toISOString() };
        await this.db.$transaction(async (tx) => {
            // FIX: an old read cannot overwrite a reset or a newer submission attempt.
            await tx.$queryRaw `SELECT "id" FROM "ClientRequest" WHERE "id"=${id} FOR UPDATE`;
            const current = await this.context(tx, accountId, id, user);
            if (!(0, node_util_1.isDeepStrictEqual)(current.receipt, receipt))
                throw new common_1.ConflictException('Состояние отправки изменилось. Обновите статус ещё раз.');
            await this.save(tx, id, next);
            await tx.lamodaOperation.updateMany({ where: { accountId, operationKey: `FBO:${receipt.payload.externalShipmentId}` }, data: { status: 'SUCCEEDED', errorCode: null } });
        });
        return next;
    }
}
exports.LamodaSubmission = LamodaSubmission;
