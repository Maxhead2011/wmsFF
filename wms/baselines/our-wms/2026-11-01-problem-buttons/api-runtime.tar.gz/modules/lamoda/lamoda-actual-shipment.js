"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildActualLamodaShipment = buildActualLamodaShipment;
exports.buildActualLamodaTemplate = buildActualLamodaTemplate;
exports.actualLamodaWorkbook = actualLamodaWorkbook;
const common_1 = require("@nestjs/common");
const XLSX = __importStar(require("xlsx"));
const kiz_physical_identity_1 = require("../../common/kiz-physical-identity");
const lamoda_commands_1 = require("./lamoda-commands");
const lamoda_policy_1 = require("./lamoda-policy");
// FIX: one deterministic payload for Excel and API, from verified actual units only.
function buildActualLamodaShipment(input) {
    const externalShipmentId = (0, lamoda_policy_1.text)(input.externalShipmentId, 'Номер поставки / УПД');
    if (!['BYKOVO', 'SOFINO'].includes(input.warehouseCode))
        throw new common_1.BadRequestException('Выберите склад Lamoda.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(input.plannedDate) || !Number.isFinite(Date.parse(input.plannedDate)) || new Date(input.plannedDate).toISOString().slice(0, 10) !== input.plannedDate)
        throw new common_1.BadRequestException('Некорректная дата поставки.');
    const body = { externalShipmentId, warehouseCode: input.warehouseCode, plannedDate: input.plannedDate, items: actualItems(input, true) };
    (0, lamoda_commands_1.prepareLamodaCommand)({ kind: 'FBO_CREATE', body }, 'validation');
    return body;
}
// FIX: only the downloadable draft omits commercial fields; actual-unit checks are shared.
function buildActualLamodaTemplate(input) {
    return actualLamodaWorkbook({ items: actualItems(input, false) });
}
function actualItems(input, priced) {
    if (!input.units.length || input.units.length > 10000)
        throw new common_1.BadRequestException('В поставке должно быть от 1 до 10000 упакованных единиц.');
    const ids = new Set(), marks = new Set(), grouped = new Map();
    for (const u of [...input.units].sort((a, b) => a.id.localeCompare(b.id))) {
        if (ids.has(u.id))
            throw new common_1.BadRequestException('Повторная единица в составе.');
        ids.add(u.id);
        const boxes = input.boxes.filter(b => b.boxId === u.targetBoxId);
        if (u.state !== 'PACKED' || boxes.length !== 1 || !boxes[0].closedAt || !boxes[0].confirmedAt)
            throw new common_1.BadRequestException('Завершите упаковку и проверку всех коробов.');
        const matches = input.identities.filter(i => i.skuId === u.skuId);
        if (matches.length !== 1)
            throw new common_1.BadRequestException('Нужно однозначное соответствие товара Lamoda.');
        const i = matches[0], externalSku = (0, lamoda_policy_1.text)(i.externalSku, 'Артикул продавца Lamoda');
        if (!/^\d{8,14}$/.test(i.ean) || (priced && (!Number.isSafeInteger(i.priceMinor) || Number(i.priceMinor) <= 0)))
            throw new common_1.BadRequestException('Проверьте ШК и цену товара по УПД.');
        if (u.requiresKiz && !u.kiz)
            throw new common_1.BadRequestException('У маркированной единицы отсутствует КИЗ.');
        if (u.kiz) {
            const identity = (0, kiz_physical_identity_1.physicalKizIdentity)(u.kiz);
            if (!identity || marks.has(identity))
                throw new common_1.BadRequestException('Некорректный или повторный КИЗ.');
            marks.add(identity);
        }
        const key = JSON.stringify([externalSku, i.ean, priced ? i.priceMinor : null, !!u.kiz]);
        const item = grouped.get(key) ?? { externalSku, quantity: 0, ...(priced ? { price: { amount: i.priceMinor, currency: 'RUB' } } : {}), ean: i.ean, ...(u.kiz ? { markingCodes: [] } : {}) };
        item.quantity++;
        if (u.kiz)
            item.markingCodes.push(u.kiz);
        grouped.set(key, item);
    }
    if (new Set([...grouped.values()].map(i => i.externalSku)).size > 5000)
        throw new common_1.BadRequestException('Превышен лимит 5000 SKU.');
    return [...grouped.values()].sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
}
// FIX: textual dates/barcodes and one row per marked physical unit; prices converted once.
function actualLamodaWorkbook(body) {
    const date = body.plannedDate?.split('-').reverse().join('.') ?? '';
    const rows = [['Дата поставки', date], ['Номер поставки', body.externalShipmentId ?? ''], ['Номер документа отгрузки', ''], ['Seller SKU', 'Количество', 'Стоимость', 'EAN', 'Вес ЮИ', 'Data Matrix']];
    for (const i of body.items) {
        for (const code of i.markingCodes ?? [''])
            rows.push([i.externalSku, i.markingCodes ? 1 : i.quantity, i.price ? i.price.amount / 100 : '', i.ean, '', code]);
    }
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, XLSX.utils.aoa_to_sheet(rows), 'Лист1');
    return XLSX.write(book, { type: 'buffer', bookType: 'xlsx' });
}
