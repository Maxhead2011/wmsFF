"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaOperationJournal = void 0;
const node_crypto_1 = require("node:crypto");
const lamoda_client_1 = require("./lamoda-client");
function canonical(value) {
    if (value === null || typeof value === 'boolean' || typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value)))
        return JSON.stringify(value);
    if (Array.isArray(value))
        return `[${value.map(canonical).join(',')}]`;
    if (value && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype)
        return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
    throw new Error('INVALID_PAYLOAD');
}
const hash = (value) => (0, node_crypto_1.createHash)('sha256').update(canonical(value)).digest('hex');
// FIX: a committed SENDING claim survives crashes; no lease expiry may replay an external write.
class LamodaOperationJournal {
    store;
    constructor(store) {
        this.store = store;
    }
    async run(accountId, operationKey, payload, send) {
        if (!accountId || !operationKey || operationKey.length > 255)
            throw new Error('INVALID_OPERATION_KEY');
        const id = hash([accountId, operationKey]), payloadHash = hash(payload);
        const row = await this.store.upsert({ where: { id }, create: { id, accountId, operationKey, payloadHash, status: 'PENDING' }, update: {} });
        if (row.payloadHash !== payloadHash)
            throw new Error('PAYLOAD_CHANGED');
        if (row.status === 'SUCCEEDED')
            return { id, status: 'SUCCEEDED', replayed: true };
        if (row.status !== 'PENDING')
            throw new Error('RECONCILIATION_REQUIRED');
        const claim = await this.store.updateMany({ where: { id, status: 'PENDING' }, data: { status: 'SENDING' } });
        if (claim.count !== 1)
            throw new Error('RECONCILIATION_REQUIRED');
        try {
            await send();
        }
        catch (error) {
            const rejected = error instanceof lamoda_client_1.LamodaApiError && error.outcome === 'REJECTED';
            await this.store.updateMany({ where: { id, status: 'SENDING' }, data: { status: rejected ? 'REJECTED' : 'UNKNOWN', errorCode: error instanceof lamoda_client_1.LamodaApiError ? error.code : 'UNKNOWN_RESULT' } });
            throw new Error(rejected ? 'OPERATION_REJECTED' : 'UNKNOWN_RESULT');
        }
        // Never catch persistence failure as a remote rejection: leave SENDING blocked for reconciliation.
        const saved = await this.store.updateMany({ where: { id, status: 'SENDING' }, data: { status: 'SUCCEEDED' } });
        if (saved.count !== 1)
            throw new Error('RECONCILIATION_REQUIRED');
        return { id, status: 'SUCCEEDED', replayed: false };
    }
}
exports.LamodaOperationJournal = LamodaOperationJournal;
