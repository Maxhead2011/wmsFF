"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adjustLamodaComposition = adjustLamodaComposition;
exports.lamodaStockAvailability = lamodaStockAvailability;
exports.assertLamodaStockAvailable = assertLamodaStockAvailable;
const common_1 = require("@nestjs/common");
const wb_order_stock_lifecycle_1 = require("../../common/stock/wb-order-stock-lifecycle");
const receipt_channel_policy_1 = require("../warehouse/receipt-channel-policy");
// FIX: corrections only reduce the selected warehouse demand; the imported plan remains immutable.
function adjustLamodaComposition(original, quantities) {
    if (quantities === undefined)
        return original;
    const limits = new Map(original.items.map(i => [i.skuId, i.quantity]));
    const selected = new Map();
    if (!Array.isArray(quantities) || quantities.length !== limits.size)
        throw new common_1.BadRequestException('Передайте количество каждого товара из проверенного плана.');
    for (const row of quantities) {
        if (!row || !limits.has(row.skuId) || selected.has(row.skuId) || !Number.isSafeInteger(row.quantity)
            || row.quantity < 0 || row.quantity > limits.get(row.skuId))
            throw new common_1.BadRequestException('Корректировка может только уменьшать количество товаров исходного плана. Повторите проверку.');
        selected.set(row.skuId, row.quantity);
    }
    if (![...selected.values()].some(n => n > 0))
        throw new common_1.BadRequestException('Нет доступного товара для сборки. Заявка не создана.');
    const remaining = new Map(selected);
    const directions = original.directions.map(d => ({ ...d, items: d.items.map(i => {
            const quantity = Math.min(i.quantity, remaining.get(i.skuId) ?? 0);
            remaining.set(i.skuId, (remaining.get(i.skuId) ?? 0) - quantity);
            return { ...i, quantity };
        }).filter(i => i.quantity > 0) })).filter(d => d.items.length);
    return { items: original.items.map(i => ({ ...i, quantity: selected.get(i.skuId) })).filter(i => i.quantity > 0), directions };
}
// FIX: run on the creation transaction's snapshot, never trust an earlier UI preview.
// AVAILABLE has already lost picked units; the canonical reader subtracts only remaining demand.
async function lamodaStockAvailability(tx, clientId, warehouseId, items, excludeRequestId) {
    const grouped = new Map();
    for (const item of items) {
        const previous = grouped.get(item.skuId);
        grouped.set(item.skuId, { ...item, quantity: (previous?.quantity ?? 0) + item.quantity });
    }
    if (!grouped.size)
        return [];
    const skuIds = [...grouped.keys()];
    const client = await tx.client.findUniqueOrThrow({ where: { id: clientId }, select: { storesWithoutBoxes: true } });
    const balances = await tx.stockBalance.findMany({ where: {
            clientId, warehouseId, skuId: { in: skuIds }, status: 'AVAILABLE', quantity: { gt: 0 },
            ...(client.storesWithoutBoxes ? { boxId: null, palletId: null } : {
                box: { clientId, warehouseId, status: 'active' },
            }),
        }, select: { skuId: true, boxId: true, quantity: true } });
    const boxIds = [...new Set(balances.flatMap(b => b.boxId ? [b.boxId] : []))];
    const rules = boxIds.length ? await (0, receipt_channel_policy_1.receiptRules)(tx, clientId, warehouseId, boxIds) : new Map();
    const reserved = await (0, wb_order_stock_lifecycle_1.wbReservationQuantities)(tx, clientId, skuIds, warehouseId, excludeRequestId);
    const stock = new Map();
    for (const balance of balances) {
        if (balance.boxId && !(0, receipt_channel_policy_1.receiptAllows)(rules.get(balance.boxId), 'fbo'))
            continue;
        stock.set(balance.skuId, (stock.get(balance.skuId) ?? 0) + balance.quantity);
    }
    return [...grouped.values()].map(item => {
        const stockQuantity = stock.get(item.skuId) ?? 0;
        const reservedQuantity = reserved.get(item.skuId) ?? 0;
        const availableQuantity = Math.max(0, stockQuantity - reservedQuantity);
        return { ...item, stockQuantity, reservedQuantity, availableQuantity,
            shortageQuantity: Math.max(0, item.quantity - availableQuantity) };
    });
}
async function assertLamodaStockAvailable(tx, clientId, warehouseId, items) {
    const shortages = (await lamodaStockAvailability(tx, clientId, warehouseId, items)).filter(r => r.shortageQuantity > 0);
    if (shortages.length)
        throw new common_1.ConflictException({
            message: 'Недостаточно свободного остатка для Lamoda. ' + shortages.map(r => `ШК ${r.barcode}: нужно ${r.quantity}, доступно ${r.availableQuantity}, дефицит ${r.shortageQuantity}.`).join(' '),
            shortages,
        });
}
