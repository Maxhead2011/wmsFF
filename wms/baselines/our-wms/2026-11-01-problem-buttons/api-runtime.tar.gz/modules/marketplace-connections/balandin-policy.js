'use strict';
const CLIENT='abb5fdde-18a9-48f4-8d6d-f01d0913e3a0',MINIMUM=10;
const applies=id=>id===CLIENT;
const day=value=>{const d=new Date(value);return Number.isFinite(d.getTime())?d.toISOString().slice(0,10):null;};
async function dailyItems(db,clientId,orders){
 if(!applies(clientId))return null;
 // Count physical handovers across cabinets once, including a refresh returning only a tail.
 const [links,facts]=await Promise.all([
  db.fbsOrderRequestLink.findMany({where:{clientId,handedOverAt:{not:null},request:{status:'DONE'}},select:{connectionId:true,orderId:true,lastItemCount:true,handedOverAt:true}}),
  db.wbOrderShipment.findMany({where:{clientId},select:{connectionId:true,orderId:true,quantity:true,shippedAt:true}})
 ]);
 const unique=new Map();
 const add=(connection,id,quantity,date)=>{const d=day(date);if(!connection||!id||!d)return;const key=connection+':'+id,old=unique.get(key);unique.set(key,{day:old?.day||d,quantity:Math.max(old?.quantity||0,Math.max(1,Math.trunc(Number(quantity))||1))});};
 for(const r of links)add(r.connectionId,r.orderId,r.lastItemCount,r.handedOverAt);
 for(const r of facts)add(r.connectionId,r.orderId,r.quantity,r.shippedAt);
 for(const o of orders)add(o.connectionId,o.id,o.itemCount,o.deliveryDate||o.sellerDate||o.createdAt);
 const result=new Map();for(const x of unique.values())result.set(x.day,(result.get(x.day)||0)+x.quantity);return result;
}
const eligible=(clientId,quantity)=>!applies(clientId)||quantity>=MINIMUM;
const lateOzon=(clientId,order)=>applies(clientId)&&order.marketplace==='OZON'&&Boolean(order.request?.id);
const lateIdentity=order=>order.processingAssemblyId||'order-'+order.id;
module.exports={CLIENT,MINIMUM,applies,dailyItems,eligible,lateOzon,lateIdentity};
