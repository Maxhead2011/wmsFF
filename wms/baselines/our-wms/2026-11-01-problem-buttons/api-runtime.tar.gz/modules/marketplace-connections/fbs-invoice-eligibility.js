'use strict';
const {BadRequestException}=require('@nestjs/common');
const supported=new Set(['WILDBERRIES','OZON','YANDEX_MARKET']);
const sourceKeys=new WeakMap();
function bindSourceIdentities(clientId,orders,charges){
 const index=new Map();for(const c of charges){const m=c.metadata;
  if(c.clientId!==clientId||c.status==='CANCELLED'||m?.kind!=='FBS'||!['OZON','YANDEX_MARKET'].includes(m.marketplace)||
      typeof m.shipmentKey!=='string'||c.sourceKey!=='fbs-calculator:'+clientId+':'+m.shipmentKey||m.billingAttemptId||!Array.isArray(m.orderIds))continue;
  for(const id of m.orderIds){const key=m.marketplace+':'+m.connectionId+':'+id,list=index.get(key)||[];list.push(m.shipmentKey);index.set(key,list);}
 }
 for(const o of orders){sourceKeys.delete(o);if(o.processingAttemptId)continue;const list=index.get(o.marketplace+':'+o.connectionId+':'+o.id);if(list?.length===1)sourceKeys.set(o,list[0]);}
}
const sourceKey=order=>sourceKeys.get(order);
function invoiceCandidate(order,billing){return supported.has(order.marketplace)&&order.category==='shipped'&&Boolean(billing?.chargeId)&&billing.status!=='CANCELLED';}
function lateOrder(order){return ['OZON','YANDEX_MARKET'].includes(order.marketplace)&&order.category==='shipped'&&Boolean(order.id&&order.connectionId);}
function needsInvoice(order,preserved,billing){return billing?.status!=='CANCELLED'&&(!preserved||Boolean(billing?.chargeId&&!billing.invoiceNumber));}
const lateIdentity=order=>order.processingAssemblyId||'order-'+order.id;
async function bindInvoiceBranches(db,clientId,orders,branches,legacyKey){
 const selected=orders.filter(o=>['OZON','YANDEX_MARKET'].includes(o.marketplace));
 const actual=o=>o.request?.warehouseId||o.reservation?.warehouseId;
 const saved=o=>branches?.get(legacyKey(o)+'\0'+o.id);
 const ids=[...new Set(selected.filter(o=>!actual(o)&&!saved(o)).map(o=>o.connectionId))];
 const connections=ids.length?await db.clientMarketplaceConnection.findMany({where:{clientId,id:{in:ids},isActive:true},select:{id:true,fbsExecutionWarehouseId:true}}):[];
 const configured=new Map(connections.map(c=>[c.id,c.fbsExecutionWarehouseId]));
 for(const o of selected){const recorded=saved(o);if(recorded&&actual(o)&&recorded!==actual(o))throw new BadRequestException('Филиал заказа отличается от сохранённого начисления FBS. Требуется проверка источника.');if(actual(o))continue;const warehouseId=recorded||configured.get(o.connectionId);if(warehouseId)o.billingWarehouseId=warehouseId;else delete o.billingWarehouseId;}
}
module.exports={invoiceCandidate,lateOrder,needsInvoice,lateIdentity,bindInvoiceBranches,bindSourceIdentities,sourceKey};
