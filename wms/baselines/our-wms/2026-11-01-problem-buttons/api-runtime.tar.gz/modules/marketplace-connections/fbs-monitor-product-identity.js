"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.monitorIdentityKey = void 0;
exports.monitorProductIdentities = monitorProductIdentities;
const marketplace_product_links_1 = require("./marketplace-product-links");
const monitorIdentityKey = (row) => JSON.stringify([row.clientId, row.connectionId, row.skuId]);
exports.monitorIdentityKey = monitorIdentityKey;
function parse(value) {
    const [nmId = '', size = ''] = (value ?? '').trim().split(':');
    const chrtId = Number(size);
    return nmId && Number.isSafeInteger(chrtId) && chrtId > 0 ? { nmId, chrtId } : null;
}
// FIX: a physical SKU's legacy marketplace id may belong to Ozon. Resolve WB
// through the exact opted-in client/account, with no fallback for ambiguous links.
async function monitorProductIdentities(db, rows) {
    const result = new Map();
    const linked = rows.filter(row => (0, marketplace_product_links_1.productLinksEnabled)(row.clientId));
    const links = linked.length ? await db.marketplaceProductLink.findMany({
        where: { marketplace: 'WILDBERRIES', status: 'LINKED', OR: linked.map(({ clientId, connectionId, skuId }) => ({ clientId, connectionId, skuId })) },
        select: { clientId: true, connectionId: true, skuId: true, productId: true },
    }) : [];
    for (const row of rows) {
        const matches = links.filter(link => link.clientId === row.clientId && link.connectionId === row.connectionId && link.skuId === row.skuId);
        result.set((0, exports.monitorIdentityKey)(row), (0, marketplace_product_links_1.productLinksEnabled)(row.clientId)
            ? matches.length === 1 ? parse(matches[0].productId) : null
            : parse(row.marketplaceProductId));
    }
    return result;
}
