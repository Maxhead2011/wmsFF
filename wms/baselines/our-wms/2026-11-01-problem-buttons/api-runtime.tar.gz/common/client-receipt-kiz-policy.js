"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientReceiptKizPolicyKey = void 0;
exports.clientRequiresReceiptKiz = clientRequiresReceiptKiz;
exports.clientReceiptMarking = clientReceiptMarking;
exports.assertClientReceiptKiz = assertClientReceiptKiz;
const common_1 = require("@nestjs/common");
const clientReceiptKizPolicyKey = (clientId) => 'client.receipt-kiz-required.v1:' + clientId;
exports.clientReceiptKizPolicyKey = clientReceiptKizPolicyKey;
async function clientRequiresReceiptKiz(db, clientId) {
    if (process.env.WMS_KIZ_CLIENT_GUARD_ENABLED !== 'true')
        return false;
    const setting = await db.systemSetting?.findUnique({ where: { key: (0, exports.clientReceiptKizPolicyKey)(clientId) } });
    return setting?.value?.required === true;
}
async function clientReceiptMarking(db, clientId) { return await clientRequiresReceiptKiz(db, clientId) ? { needsChestnyZnak: true, isUnmarked: false } : {}; }
async function assertClientReceiptKiz(db, clientId, kiz) { if (await clientRequiresReceiptKiz(db, clientId) && !kiz?.trim())
    throw new common_1.BadRequestException('Для этого клиента КИЗ обязателен для каждой единицы. Сканируйте КИЗ.'); }
