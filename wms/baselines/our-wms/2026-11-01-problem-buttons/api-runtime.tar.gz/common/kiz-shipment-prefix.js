"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prefixEnd = prefixEnd;
exports.shipmentPrefixIds = shipmentPrefixIds;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const kiz_client_registry_1 = require("./kiz-client-registry");
// FIX: exclusive UTF-8 prefix bound for PostgreSQL text_pattern_ops, without LIKE wildcards.
function prefixEnd(prefix) {
    const points = Array.from(prefix);
    while (points.length) {
        const last = points.pop().codePointAt(0);
        if (last < 0x10ffff)
            return points.join('') + String.fromCodePoint(last === 0xd7ff ? 0xe000 : last + 1);
    }
    throw new Error('Unbounded KIZ prefix');
}
async function shipmentPrefixIds(tx, request, keys, kind, take) {
    const prefixes = [...new Set(keys.flatMap(kiz_client_registry_1.clientKizPrefixes))];
    if (!prefixes.length)
        return [];
    // Table/column fragments are static; all client data remains parameterized.
    const table = client_1.Prisma.raw({ marks: '"ProductMark"', shipments: '"ShippedKizHistory"', history: '"FboAssemblyUnit"', tasks: '"FbsTsdAssembly"', bindings: '"FboAssemblyUnit"' }[kind]);
    const col = client_1.Prisma.raw(kind === 'marks' ? 'm."value"' : 'm."kiz"');
    const scope = kind === 'history' || kind === 'bindings'
        ? client_1.Prisma.sql `EXISTS (SELECT 1 FROM "ClientRequest" r WHERE r.id=m."requestId" AND r."clientId"=${request.clientId} ${kind === 'history' ? client_1.Prisma.sql `AND r.status='DONE'` : client_1.Prisma.empty})`
        : client_1.Prisma.sql `m."clientId"=${request.clientId}`;
    const extra = kind === 'history' ? client_1.Prisma.sql `AND m.state <> 'RETURNED'`
        : kind === 'bindings' ? client_1.Prisma.sql `AND m."requestId" <> ${request.id} AND m."activeMarkId" IS NOT NULL`
            : kind === 'tasks' ? client_1.Prisma.sql `AND m.status IN ('IN_PROGRESS','COMPLETED','RETURN_REQUIRED')` : client_1.Prisma.empty;
    // LATERAL keeps each prefix an indexed range rather than a hundreds-term OR filter.
    const rows = await tx.$queryRaw(client_1.Prisma.sql `
  SELECT DISTINCT hit.id FROM unnest(${prefixes}::text[],${prefixes.map(prefixEnd)}::text[]) p(lo,hi)
  CROSS JOIN LATERAL (SELECT m.id FROM ${table} m
   WHERE ${col} ~>=~ p.lo AND ${col} ~<~ p.hi AND ${scope} ${extra} LIMIT ${take}) hit
  LIMIT ${take}`);
    if (rows.length >= take)
        throw new common_1.ConflictException('Слишком много записей истории КИЗ. Требуется разбор администратором.');
    return rows.map(row => row.id);
}
