"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.missingStockComment = void 0;
exports.missingStockHolds = missingStockHolds;
const prefix = '[FBO_MISSING_STOCK]';
const missingStockComment = (boxId, skuId, quantity) => prefix + JSON.stringify({ boxId, skuId, quantity });
exports.missingStockComment = missingStockComment;
// FIX: a report only withholds the reported units until the same box has a verified recount.
async function missingStockHolds(db, clientId, warehouseId, skuIds) {
    const result = new Map();
    if (!warehouseId || !skuIds.length || process.env.WMS_FBO_EXCEL_PICK_CHECK_ENABLED !== 'true')
        return result;
    const reports = await db.auditLog.findMany({
        where: { entity: 'FboMissingStock', entityId: warehouseId, action: 'HOLD', payload: { path: ['clientId'], equals: clientId } },
        select: { createdAt: true, payload: true }
    });
    const relevant = reports.map(report => ({ at: report.createdAt, data: report.payload }))
        .filter(report => skuIds.includes(report.data.skuId));
    if (!relevant.length)
        return result;
    const counts = await db.inventoryAuditBox.findMany({ where: { clientId, boxId: { in: [...new Set(relevant.map(r => r.data.boxId))] },
            status: { in: ['MATCHED', 'RESOLVED'] }, session: { warehouseId } }, select: { boxId: true, startedAt: true } });
    for (const report of relevant) {
        const h = report.data;
        const verified = counts.some(count => count.boxId === h.boxId && count.startedAt >= report.at);
        if (verified)
            continue;
        const box = result.get(h.boxId) ?? new Map();
        box.set(h.skuId, Math.max(box.get(h.skuId) ?? 0, h.quantity));
        result.set(h.boxId, box);
    }
    return result;
}
