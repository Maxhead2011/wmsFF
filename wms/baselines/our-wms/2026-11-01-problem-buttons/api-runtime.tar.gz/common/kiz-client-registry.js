"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientKizDuplicateError = exports.clientKizFilter = exports.clientKizGuardEnabled = void 0;
exports.clientKizIdentity = clientKizIdentity;
exports.clientKizPrefixes = clientKizPrefixes;
exports.receiptKizDuplicateMessage = receiptKizDuplicateMessage;
exports.lookupClientKiz = lookupClientKiz;
exports.lockClientKiz = lockClientKiz;
exports.assertNewReceiptKiz = assertNewReceiptKiz;
exports.withReceiptErrorKizGuard = withReceiptErrorKizGuard;
exports.recordClientKizReceipt = recordClientKizReceipt;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
// FIX: additive own-WMS guard; a marking identity is case-sensitive and client-scoped.
const clientKizGuardEnabled = () => process.env.WMS_KIZ_CLIENT_GUARD_ENABLED === 'true';
exports.clientKizGuardEnabled = clientKizGuardEnabled;
function clientKizIdentity(value) {
    const normalized = String(value ?? '').trim().replace(/^\]d2/i, '').replace(/<GS>/gi, '\u001d')
        .replace(/^\(01\)(\d{14})\(21\)/, '01$121').replace(/^(01\d{14})\u001d21/, '$121');
    return /^(01\d{14}21(?:[^\u0000-\u001f]{13}|[^\u0000-\u001f]{6}))(?=$|\u001d|91[^\u0000-\u001f]{4}(?:\u001d)?92)/.exec(normalized)?.[1] ?? '';
}
function clientKizPrefixes(identity) {
    const separated = identity.slice(0, 16) + '\u001d' + identity.slice(16);
    // FIX: historical scanner prefixes may coexist with parenthesized or textual GS forms.
    const forms = [identity, separated, ...['<GS>', '<Gs>', '<gS>', '<gs>'].map(gs => separated.replace('\u001d', gs)),
        '(01)' + identity.slice(2, 16) + '(21)' + identity.slice(18)];
    return ['', ']d2', ']D2'].flatMap(prefix => forms.map(form => prefix + form));
}
const escapedPrefix = (value) => value.replace(/[\\%_]/g, '\\$&');
const clientKizFilter = (identity, field = 'value') => ({
    OR: clientKizPrefixes(identity).map(prefix => ({ [field]: { startsWith: escapedPrefix(prefix) } })),
});
exports.clientKizFilter = clientKizFilter;
const iso = (value) => value ? new Date(value).toISOString() : null;
const emptyInfo = (identity) => ({ identity, firstReceivedAt: null,
    firstBoxCode: null, firstWarehouseId: null, productName: null, barcode: null,
    currentStatus: null, currentBoxCode: null, currentWarehouseId: null, source: 'LEGACY_UNKNOWN' });
function receiptKizDuplicateMessage(info) {
    const lines = ['ОТЛОЖИТЕ ТОВАР. ДУБЛЬ КИЗ — ТОВАР НЕ ПРИНЯТ.'];
    if (info.firstReceivedAt)
        lines.push(`Ранее принят: ${new Date(info.firstReceivedAt).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' })} (МСК).`);
    else
        lines.push('КИЗ уже зарегистрирован. Первоначальная приёмка не установлена.');
    if (info.firstBoxCode)
        lines.push(`Короб при приёмке: ${info.firstBoxCode}.`);
    if (info.productName)
        lines.push(`Товар: ${info.productName}${info.barcode ? `; ШК ${info.barcode}` : ''}.`);
    const statuses = { AVAILABLE: 'на складе', RECEIVING: 'в приёмке', RESERVED: 'зарезервирован',
        PACKING: 'в сборке', SHIPPING: 'готов к отгрузке', SHIPPED: 'отгружен', BLOCKED: 'заблокирован', AMBIGUOUS: 'несколько записей' };
    if (info.currentStatus)
        lines.push(`Сейчас: ${statuses[info.currentStatus] ?? info.currentStatus}${info.currentBoxCode ? `, короб ${info.currentBoxCode}` : ''}.`);
    if (info.detailsRestricted)
        lines.push('Подробности другого филиала доступны уполномоченному администратору.');
    lines.push('Передайте товар на проверку КИЗ.');
    return lines.join('\n');
}
class ClientKizDuplicateError extends common_1.ConflictException {
    duplicateInfo;
    constructor(duplicateInfo) {
        super({ code: 'KIZ_DUPLICATE', duplicate: true, message: receiptKizDuplicateMessage(duplicateInfo), duplicateInfo });
        this.duplicateInfo = duplicateInfo;
    }
}
exports.ClientKizDuplicateError = ClientKizDuplicateError;
function visibleInfo(info, warehouseId) {
    if (!warehouseId)
        return info;
    const firstHidden = !!info.firstWarehouseId && info.firstWarehouseId !== warehouseId;
    const currentHidden = !!info.currentWarehouseId && info.currentWarehouseId !== warehouseId;
    return { ...info, ...(firstHidden ? { firstBoxCode: null, productName: null, barcode: null, firstWarehouseId: null } : {}),
        ...(currentHidden ? { currentBoxCode: null, currentWarehouseId: null } : {}), detailsRestricted: firstHidden || currentHidden };
}
// FIX: read-only lookup. Immutable registry survives deletion/relabel of a ProductMark.
async function lookupClientKiz(db, clientId, kiz, warehouseId) {
    const identity = clientKizIdentity(kiz);
    if (!identity)
        throw new common_1.BadRequestException('Не удалось распознать GTIN и серийный номер КИЗ. Отсканируйте Data Matrix полностью.');
    const saved = await db.$queryRaw(client_1.Prisma.sql `SELECT * FROM "KizClientRegistry" WHERE "clientId"=${clientId} AND identity=${identity}`);
    const candidates = await db.productMark.findMany({ where: { clientId, ...(0, exports.clientKizFilter)(identity) },
        include: { box: { select: { code: true, warehouseId: true } }, sku: { select: { name: true } } } });
    const marks = candidates.filter((m) => clientKizIdentity(m.value) === identity);
    const shipments = await db.shippedKizHistory.findMany({ where: { clientId, ...(0, exports.clientKizFilter)(identity, 'kiz') },
        select: { kiz: true, warehouseId: true, productName: true, barcode: true }, take: 25 });
    const shipped = shipments.find((row) => clientKizIdentity(row.kiz) === identity);
    // Historical FBS attempts may outlive a removed ProductMark. They establish prior registration,
    // never a fabricated original receipt date or proof of shipment.
    let oldTask = null;
    if (!saved.length && !marks.length && !shipped && db.fbsTsdAssembly?.findMany) {
        const tasks = await db.fbsTsdAssembly.findMany({ where: { clientId, ...(0, exports.clientKizFilter)(identity, 'kiz') },
            select: { kiz: true }, take: 25 });
        oldTask = tasks.find((row) => clientKizIdentity(row.kiz ?? '') === identity);
    }
    // FIX: indexed receipt evidence closes the backfill/deployment gap and survives deleted marks.
    let receipt = null;
    if (!saved.length) {
        const filters = clientKizPrefixes(identity).map(prefix => client_1.Prisma.sql `o.payload->>'kiz' LIKE ${escapedPrefix(prefix) + '%'}`);
        const rows = await db.$queryRaw(client_1.Prisma.sql `SELECT o.payload, m."createdAt" AS "receivedAt", m."clientId" AS "movementClientId",
      m.type, m.quantity, m."warehouseId", m."skuId", b.code AS "boxCode", s.name AS "productName"
      FROM "TsdOperation" o LEFT JOIN "StockMovement" m ON m."idempotencyKey"=o."operationKey"
      LEFT JOIN "Box" b ON b.id=m."boxId" LEFT JOIN "Sku" s ON s.id=m."skuId"
      WHERE o."operationType"='receipt_scan' AND o.status='ACCEPTED' AND o.payload->>'clientId'=${clientId}
      AND (${client_1.Prisma.join(filters, ' OR ')}) ORDER BY o."createdAt", o.id LIMIT 100`);
        receipt = rows.find((r) => clientKizIdentity(r.payload?.kiz ?? '') === identity);
    }
    if (!saved.length && !marks.length && !shipped && !oldTask && !receipt)
        return null;
    const row = saved[0];
    let info = row ? { ...emptyInfo(identity), firstReceivedAt: iso(row.firstReceivedAt),
        firstBoxCode: row.firstBoxCode, firstWarehouseId: row.firstWarehouseId, productName: row.productName,
        barcode: row.barcode, source: row.source } : emptyInfo(identity);
    if (!row && receipt && receipt.type === 'RECEIPT' && receipt.quantity === 1 && receipt.movementClientId === clientId &&
        (receipt.payload.boxCode ?? null) === (receipt.boxCode ?? null)) {
        info = { ...info, firstReceivedAt: iso(receipt.receivedAt), firstBoxCode: receipt.boxCode,
            firstWarehouseId: receipt.warehouseId, productName: receipt.payload.skuName ?? receipt.productName,
            barcode: receipt.payload.barcode ?? null, source: 'RECEIPT' };
    }
    if (marks.length === 1)
        info = { ...info, currentStatus: marks[0].status, currentBoxCode: marks[0].box?.code ?? null,
            currentWarehouseId: marks[0].box?.warehouseId ?? null };
    if (shipped && (!marks.length || marks[0].status === 'SHIPPING'))
        info.currentStatus = 'SHIPPED';
    if (marks.length > 1)
        info = { ...info, currentStatus: 'AMBIGUOUS', multipleRecords: true };
    return visibleInfo(info, warehouseId);
}
async function lockClientKiz(tx, clientId, identity) {
    await tx.$queryRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(${JSON.stringify(['kiz-client', clientId, identity])},0))::text`);
}
async function assertNewReceiptKiz(tx, input) {
    if (!(0, exports.clientKizGuardEnabled)())
        return true;
    const identity = clientKizIdentity(input.kiz);
    if (!identity)
        throw new common_1.BadRequestException('Не удалось распознать GTIN и серийный номер КИЗ. Отсканируйте Data Matrix полностью.');
    await lockClientKiz(tx, input.clientId, identity);
    // FIX: a concurrent retry may have waited while the identical operation committed.
    if (tx.stockMovement?.findUnique) {
        const committed = await tx.stockMovement.findUnique({ where: { idempotencyKey: input.operationKey } });
        if (committed)
            return false;
    }
    const prior = await lookupClientKiz(tx, input.clientId, input.kiz, input.warehouseId);
    if (prior)
        throw new ClientKizDuplicateError(prior);
    return true;
}
// FIX: the administrative error path writes an unmarked unit, but must retain the scanned identity.
// The stock service receives this same tx: never open a nested receipt transaction while holding the lock.
async function withReceiptErrorKizGuard(db, input, action) {
    return db.$transaction(async (tx) => {
        const fresh = await assertNewReceiptKiz(tx, input);
        const result = await action(tx);
        if (fresh)
            await recordClientKizReceipt(tx, { ...input, source: 'CORRECTION' });
        return result;
    });
}
// Must run in the same transaction as the actual receipt. Unknown legacy origins keep a null date.
async function recordClientKizReceipt(tx, input) {
    if (!(0, exports.clientKizGuardEnabled)())
        return;
    const identity = clientKizIdentity(input.kiz);
    if (!identity)
        throw new common_1.BadRequestException('Некорректный идентификатор КИЗ.');
    const source = input.source ?? 'RECEIPT';
    await tx.$executeRaw(client_1.Prisma.sql `INSERT INTO "KizClientRegistry"
    ("clientId",identity,"firstReceivedAt","firstBoxCode","firstWarehouseId","productName",barcode,"skuId","operationKey","sourceDocument","userId",source)
    VALUES (${input.clientId},${identity},${source === 'RECEIPT' ? input.receivedAt ?? new Date() : null},
      ${source === 'RECEIPT' ? input.boxCode ?? null : null},${input.warehouseId ?? null},${input.productName ?? null},${input.barcode ?? null},
      ${input.skuId ?? null},${input.operationKey},${input.sourceDocument ?? null},${input.userId ?? null},${source})`);
}
