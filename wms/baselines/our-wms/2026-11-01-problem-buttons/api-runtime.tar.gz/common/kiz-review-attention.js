"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.openKizReviewCount = openKizReviewCount;
const crypto_1 = require("crypto");
const client_scope_service_1 = require("../modules/auth/client-scope.service");
// FIX: count unresolved reviews independently of FBS orders and read markers.
async function openKizReviewCount(db, user, clientId) {
    if (process.env.WMS_KIZ_REVIEW_QUEUE_ENABLED !== 'true' || user.isDemo || !user.activeWarehouseId ||
        !user.roleCodes.some(r => ['ADMIN', 'OWNER', 'SUPER_ADMIN'].includes(r)))
        return undefined;
    if (!user.permissionCodes.includes('system:admin') && user.warehouseIds && !user.warehouseIds.includes(user.activeWarehouseId))
        return undefined;
    const rows = await db.kizReviewCase.findMany({ where: { status: 'OPEN', warehouseId: user.activeWarehouseId,
            clientId: new client_scope_service_1.ClientScopeService().resolveClientFilter(user, clientId || undefined),
            NOT: [{ taskId: { startsWith: 'UNIT:' } }, { taskId: { startsWith: 'FOUND:' } }] }, select: { taskId: true, context: true } });
    const legacy = rows.filter((r) => !r.taskId.startsWith('GUARD:'));
    const tasks = legacy.length ? await db.fbsTsdAssembly.findMany({ where: { id: { in: legacy.map((r) => r.taskId) } } }) : [];
    return rows.filter((r) => {
        if (r.taskId.startsWith('GUARD:'))
            return true;
        const t = tasks.find((t) => t.id === r.taskId);
        if (!t || t.status !== 'IN_PROGRESS' || t.kiz)
            return false;
        const context = (0, crypto_1.createHash)('sha256').update(JSON.stringify([t.id, t.clientId, t.connectionId, t.requestId, t.orderId, t.skuId, t.boxId, t.workerUserId, t.startedAt, t.createdAt])).digest('hex');
        return context === r.context;
    }).length;
}
