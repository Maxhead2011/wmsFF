"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PayrollController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const payroll_export_1 = require("./payroll-export");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const payroll_dto_1 = require("./payroll.dto");
const payroll_service_1 = require("./payroll.service");
let PayrollController = class PayrollController {
    payroll;
    constructor(payroll) {
        this.payroll = payroll;
    }
    capabilities(user) {
        return { enabled: process.env.WMS_PAYROLL_ATTENDANCE_ENABLED === 'true' && user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)) };
    }
    employees(user) { return this.payroll.employees(user); }
    users(user) { return this.payroll.pickingUsers(user); }
    create(dto, user) { return this.payroll.saveEmployee(undefined, dto, user); }
    update(id, dto, user) { return this.payroll.saveEmployee(id, dto, user); }
    condition(id, dto, user) { return this.payroll.addCondition(id, dto, user); }
    shift(id, dto, user) { return this.payroll.addShift(id, dto, user); }
    shifts(id, user) { return this.payroll.shifts(id, user); }
    updateShift(id, shiftId, dto, user) { return this.payroll.updateShift(id, shiftId, dto, user); }
    report(id, from, to, user) {
        return this.payroll.report(id, from, to, user);
    }
    updateHistory(id, key, dto, user) {
        return this.payroll.updateHistory(id, key, dto, user);
    }
    handling(dto, user) { return this.payroll.addHandling(dto, user); }
    confirm(id, user) { return this.payroll.confirmHandling(id, user); }
    status(dto, user) { return this.payroll.setStatus(dto, user); }
    async export(id, from, to, format, user, response) {
        const report = await this.payroll.report(id, from, to, user);
        const pdf = format === 'pdf';
        response.setHeader('Content-Type', pdf ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        response.setHeader('Content-Disposition', `attachment; filename="payroll.${pdf ? 'pdf' : 'xlsx'}"`);
        return new common_1.StreamableFile(pdf ? await (0, payroll_export_1.payrollPdf)(report) : (0, payroll_export_1.payrollXlsx)(report));
    }
    async import(file, mapping, user) {
        if (!file?.buffer)
            throw new common_1.BadRequestException('Выберите XLSX-файл.');
        if (!mapping)
            return this.payroll.previewImport(file.buffer, user);
        let parsed;
        try {
            parsed = JSON.parse(mapping);
            if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
                throw new Error();
        }
        catch {
            throw new common_1.BadRequestException('Некорректное соответствие сотрудников.');
        }
        return this.payroll.importHistory(file.buffer, parsed, user);
    }
};
exports.PayrollController = PayrollController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)('employees'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "employees", null);
__decorate([
    (0, common_1.Get)('picking-users'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "users", null);
__decorate([
    (0, common_1.Post)('employees'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_b = typeof payroll_dto_1.PayrollEmployeeDto !== "undefined" && payroll_dto_1.PayrollEmployeeDto) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "create", null);
__decorate([
    (0, common_1.Put)('employees/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_c = typeof payroll_dto_1.PayrollEmployeeDto !== "undefined" && payroll_dto_1.PayrollEmployeeDto) === "function" ? _c : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "update", null);
__decorate([
    (0, common_1.Post)('employees/:id/conditions'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_d = typeof payroll_dto_1.PayrollConditionDto !== "undefined" && payroll_dto_1.PayrollConditionDto) === "function" ? _d : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "condition", null);
__decorate([
    (0, common_1.Post)('employees/:id/shifts'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_e = typeof payroll_dto_1.PayrollShiftDto !== "undefined" && payroll_dto_1.PayrollShiftDto) === "function" ? _e : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "shift", null);
__decorate([
    (0, common_1.Get)('employees/:id/shifts'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "shifts", null);
__decorate([
    (0, common_1.Put)('employees/:id/shifts/:shiftId'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('shiftId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, typeof (_f = typeof payroll_dto_1.PayrollShiftDto !== "undefined" && payroll_dto_1.PayrollShiftDto) === "function" ? _f : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "updateShift", null);
__decorate([
    (0, common_1.Get)('employees/:id/report'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('from')),
    __param(2, (0, common_1.Query)('to')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "report", null);
__decorate([
    (0, common_1.Put)('employees/:id/history/:key'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Param)('key')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, typeof (_g = typeof payroll_dto_1.PayrollHistoryEditDto !== "undefined" && payroll_dto_1.PayrollHistoryEditDto) === "function" ? _g : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "updateHistory", null);
__decorate([
    (0, common_1.Post)('handling'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_h = typeof payroll_dto_1.PayrollHandlingDto !== "undefined" && payroll_dto_1.PayrollHandlingDto) === "function" ? _h : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "handling", null);
__decorate([
    (0, common_1.Post)('handling/:id/confirm'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "confirm", null);
__decorate([
    (0, common_1.Post)('statuses'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_j = typeof payroll_dto_1.PayrollStatusDto !== "undefined" && payroll_dto_1.PayrollStatusDto) === "function" ? _j : Object, Object]),
    __metadata("design:returntype", void 0)
], PayrollController.prototype, "status", null);
__decorate([
    (0, common_1.Get)('employees/:id/export'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('from')),
    __param(2, (0, common_1.Query)('to')),
    __param(3, (0, common_1.Query)('format')),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __param(5, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object, Object]),
    __metadata("design:returntype", Promise)
], PayrollController.prototype, "export", null);
__decorate([
    (0, common_1.Post)('import'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:write'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { limits: { fileSize: 10 * 1024 * 1024 } })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('mapping')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_l = typeof Express !== "undefined" && (_k = Express.Multer) !== void 0 && _k.File) === "function" ? _l : Object, String, Object]),
    __metadata("design:returntype", Promise)
], PayrollController.prototype, "import", null);
exports.PayrollController = PayrollController = __decorate([
    (0, common_1.Controller)('expenses/workforce'),
    (0, require_permissions_decorator_1.RequirePermissions)('expenses:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof payroll_service_1.PayrollService !== "undefined" && payroll_service_1.PayrollService) === "function" ? _a : Object])
], PayrollController);
