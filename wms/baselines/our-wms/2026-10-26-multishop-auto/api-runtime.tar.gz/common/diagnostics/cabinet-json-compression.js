'use strict';
const {gzip,constants}=require('node:zlib');
const ROUTES=new Set(['/api/v1/stock/balances','/api/v1/billing/invoices','/api/v1/client-requests','/api/v1/billing/charges','/api/v1/billing/service-history','/api/v1/billing/reconciliation']);
function cabinetJsonCompression(req,res,next){
 if(req.method!=='GET'||!ROUTES.has(req.path))return next();
 const send=res.send;
 res.send=function(body){
  const type=String(this.getHeader('content-type')||'');
  if(this.headersSent||this.statusCode<200||this.statusCode>=300||this.getHeader('content-encoding')||!type.toLowerCase().includes('application/json')||!(typeof body==='string'||Buffer.isBuffer(body)))return send.call(this,body);
  this.vary('Accept-Encoding');
  const bytes=Buffer.isBuffer(body)?body:Buffer.from(body);
  if(bytes.length<4096||!req.headers['accept-encoding']||req.acceptsEncodings('gzip')!=='gzip')return send.call(this,body);
  // Serialize once through Express, compress off the event loop, retain the JSON content type.
  gzip(bytes,{level:constants.Z_BEST_SPEED},(error,compressed)=>{
   if(this.destroyed||this.writableEnded)return;
   try{
    if(error)return send.call(this,body);
    this.setHeader('Content-Encoding','gzip');this.removeHeader('Content-Length');
    return send.call(this,compressed);
   }catch(e){next(e)}
  });
  return this;
 };
 return next();
}
module.exports={cabinetJsonCompression};
