"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.boundedTimingSink = boundedTimingSink;
exports.measureOperation = measureOperation;
exports.operationTiming = operationTiming;
exports.timingMiddleware = timingMiddleware;
const node_async_hooks_1 = require("node:async_hooks");
const node_crypto_1 = require("node:crypto");
const node_perf_hooks_1 = require("node:perf_hooks");
const operation_histogram_1 = require("./operation-histogram");
const context = new node_async_hooks_1.AsyncLocalStorage();
// FIX: bounded per-process diagnostics: slow/error requests plus 1/100 fast requests.
// Stage totals may overlap; they are not a decomposition of wall-clock latency.
function boundedTimingSink(log, now = Date.now) {
    let windowStart = now(), emitted = 0, suppressed = 0, fast = 0;
    return report => {
        const time = now();
        if (time - windowStart >= 60_000 || time < windowStart) {
            if (suppressed)
                log({ event: 'wms_operation_suppressed', count: suppressed });
            windowStart = time;
            emitted = 0;
            suppressed = 0;
        }
        if (!report.failed && report.durationMs < 1000) {
            fast = (fast + 1) % 100;
            if (fast !== 0)
                return;
        }
        if (emitted >= 60) {
            suppressed++;
            return;
        }
        emitted++;
        log({ event: 'wms_operation', ...report });
    };
}
const detailSink = boundedTimingSink(record => console.info(JSON.stringify(record)));
// FIX: own-WMS opt-in; one bounded summary per minute counts fast responses too.
const histogram = process.env.WMS_OPERATION_HISTOGRAM_ENABLED === 'true'
    ? (0, operation_histogram_1.createOperationHistogram)(record => console.info(JSON.stringify(record))) : null;
if (histogram)
    setInterval(() => histogram.flush(), 60_000).unref();
const defaultSink = report => { histogram?.record(report); detailSink(report); };
const rounded = (n) => Math.round(n * 100) / 100;
function publish(sink, report) {
    // FIX: diagnostics must never change an operation's result; no payload, SQL or credentials.
    try {
        sink(report);
    }
    catch { /* logging is best effort */ }
}
function snapshot(state) {
    return { traceId: state.traceId, stages: Object.fromEntries(Object.entries(state.stages).map(([key, value]) => [key, { ...value, totalMs: rounded(value.totalMs), maxMs: rounded(value.maxMs) }])) };
}
async function measureOperation(stage, operation) {
    const state = context.getStore();
    if (!state)
        return operation();
    const start = node_perf_hooks_1.performance.now();
    try {
        return await operation();
    }
    finally {
        const elapsed = node_perf_hooks_1.performance.now() - start;
        const timing = state.stages[stage] ??= { count: 0, totalMs: 0, maxMs: 0 };
        timing.count++;
        timing.totalMs += elapsed;
        timing.maxMs = Math.max(timing.maxMs, elapsed);
    }
}
async function operationTiming(operation, work, sink = defaultSink) {
    const state = { traceId: context.getStore()?.traceId ?? (0, node_crypto_1.randomUUID)(), stages: {} };
    const start = node_perf_hooks_1.performance.now();
    let failed = false;
    return context.run(state, async () => {
        try {
            return await work();
        }
        catch (error) {
            failed = true;
            throw error;
        }
        finally {
            publish(sink, { ...snapshot(state), operation, failed, durationMs: rounded(node_perf_hooks_1.performance.now() - start) });
        }
    });
}
function timingMiddleware(sink = defaultSink) {
    return (req, res, next) => {
        if (process.env.WMS_OPERATION_TIMING_ENABLED !== 'true')
            return next();
        const state = { traceId: (0, node_crypto_1.randomUUID)(), stages: {} };
        const start = node_perf_hooks_1.performance.now();
        let recorded = false;
        const finish = () => {
            if (recorded)
                return;
            recorded = true;
            res.removeListener('finish', finish);
            res.removeListener('close', finish);
            // Express resolves the route after middleware. Never fall back to raw URLs.
            const route = typeof req.route?.path === 'string' ? req.route.path : 'unmatched';
            publish(sink, { ...snapshot(state), operation: `${req.method} ${route}`, statusCode: res.statusCode,
                failed: res.statusCode >= 500 || !res.writableFinished, durationMs: rounded(node_perf_hooks_1.performance.now() - start) });
        };
        res.once('finish', finish);
        res.once('close', finish);
        return context.run(state, next);
    };
}
