"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.physicalReuseEnabled = void 0;
exports.physicalReuseEligible = physicalReuseEligible;
exports.physicalReusePermission = physicalReusePermission;
exports.approvePhysicalReuse = approvePhysicalReuse;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const kiz_physical_identity_1 = require("./kiz-physical-identity");
// FIX: an explicit manager decision for one physical unit; never an automatic sale override.
const physicalReuseEnabled = () => process.env.WMS_KIZ_SOLD_PHYSICAL_REUSE_ENABLED === 'true';
exports.physicalReuseEnabled = physicalReuseEnabled;
const identity = (v) => (0, kiz_physical_identity_1.physicalKizIdentity)(v.replace(/^\(01\)(\d{14})\(21\)/, (_, gtin) => `01${gtin}21`).replace(/^(01\d{14})\u001d21/, (_, gtin) => `${gtin}21`));
const digest = (v) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(v)).digest('hex');
const prefixes = (v) => [v, ']d2' + v, ']D2' + v, `(01)${v.slice(2, 16)}(21)${v.slice(18)}`];
function physicalReuseEligible(e) {
    return (0, exports.physicalReuseEnabled)() && e?.decision === 'RELABEL' &&
        (e.circulation == null || e.circulation === 'INTRODUCED') &&
        Array.isArray(e.orders) && e.orders.length > 0 && e.orders.length <= 5 &&
        e.orders.every((o) => o.verified === true && o.supplierStatus === 'complete' && o.wbStatus === 'sold' && o.containsKiz === true);
}
function evidenceKey(e) {
    return digest([e.circulation ?? null, e.orders.map((o) => [o.orderId, o.connectionId ?? null, o.supplierStatus, o.wbStatus, o.containsKiz, o.supplyAccepted ?? null]).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)))]);
}
function markKey(m) { return digest([m.id, m.clientId, m.skuId, m.boxId, m.status, m.updatedAt]); }
function physicalReusePermission(row, context, e, mark) {
    const p = row?.snapshot?.physicalReuse;
    return !!(physicalReuseEligible(e) && row?.context === context && row.status === 'APPROVED' && row.resolution === 'REUSE' &&
        row.decidedById && row.reason && p?.version === 1 && p.evidenceKey === evidenceKey(e) && mark &&
        mark.status === 'AVAILABLE' && mark.box && !['archived', 'deleted'].includes(mark.box.status) && p.markKey === markKey(mark));
}
async function approvePhysicalReuse(tx, task, mark, e, user, reviewId, reason) {
    const fail = () => new common_1.ConflictException('Единица или прежняя привязка изменилась. Повторите проверку КИЗа.');
    const age = Date.now() - Date.parse(e.checkedAt);
    if (!physicalReuseEligible(e) || !Number.isFinite(age) || age < 0 || age > 60000)
        throw fail();
    const key = identity(mark.value);
    if (!key)
        throw fail();
    await tx.$queryRaw `SELECT 1 FROM pg_advisory_xact_lock(hashtextextended(${key},0))`;
    await tx.$queryRaw `SELECT id FROM "ProductMark" WHERE id=${mark.id} FOR UPDATE`;
    const marks = (await tx.productMark.findMany({ where: { OR: prefixes(key).map(p => ({ value: { startsWith: p } })) } })).filter((m) => identity(m.value) === key);
    if (marks.length !== 1 || markKey(marks[0]) !== markKey(mark) || mark.clientId !== task.clientId ||
        mark.skuId !== task.skuId || mark.boxId !== task.boxId || mark.status !== 'AVAILABLE')
        throw fail();
    const approvals = await tx.kizReviewCase.findMany({ where: { id: { not: reviewId }, kizIdentity: key, status: 'APPROVED', resolution: 'REUSE', taskId: { not: task.id } } });
    if (approvals.length)
        throw fail();
    const fbo = await tx.fboAssemblyUnit.findMany({ where: { OR: [{ activeMarkId: mark.id }, { OR: prefixes(key).map(p => ({ kiz: { startsWith: p } })), state: { in: ['PICKED', 'PACKED'] }, assembly: { phase: { not: 'COMPLETED' }, request: { status: { notIn: ['DONE', 'CANCELLED', 'REJECTED'] } } } }] } });
    if (fbo.some((u) => u.activeMarkId === mark.id || identity(u.kiz ?? '') === key))
        throw fail();
    const links = (await tx.fbsTsdAssembly.findMany({ where: { id: { not: task.id }, OR: prefixes(key).map(p => ({ kiz: { startsWith: p } })) } })).filter((t) => identity(t.kiz ?? '') === key);
    const requests = await tx.clientRequest.findMany({ where: { clientId: task.clientId, id: { in: links.map((t) => t.requestId) }, status: { in: ['DONE', 'CANCELLED', 'REJECTED'] } } });
    if (links.some((t) => t.clientId !== task.clientId || !['COMPLETED', 'WB_ACCOUNTED', 'RELEASED'].includes(t.status) ||
        !requests.some((r) => r.id === t.requestId && r.warehouseId === user.activeWarehouseId) || !e.orders.some((o) => o.orderId === t.orderId)))
        throw fail();
    // Preserve the complete old task before freeing its unique current binding; shipment history is untouched.
    for (const old of links) {
        await tx.auditLog.create({ data: { userId: user.id, action: 'KIZ_PHYSICAL_SALE_BINDING_ARCHIVED', entity: 'FbsTsdAssembly', entityId: old.id,
                payload: JSON.parse(JSON.stringify({ reviewId, taskId: task.id, kizIdentity: key, reason, physicalConfirmation: true, evidence: e, before: old })) } });
        const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: old.id, clientId: old.clientId, status: old.status, kiz: old.kiz, updatedAt: old.updatedAt }, data: { kiz: null } });
        if (changed.count !== 1)
            throw fail();
    }
    return { version: 1, markKey: markKey(mark), evidenceKey: evidenceKey(e), markId: mark.id, previousTaskIds: links.map((t) => t.id) };
}
