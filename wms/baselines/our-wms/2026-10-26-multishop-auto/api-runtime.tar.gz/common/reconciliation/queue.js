"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.retryDelay = exports.jobKey = void 0;
exports.version = version;
exports.reasonCode = reasonCode;
exports.runReconciliationJobs = runReconciliationJobs;
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
function version(value) {
    const canonical = (v) => v instanceof Date ? v.toISOString() : Array.isArray(v) ? v.map(canonical) : v && typeof v === 'object'
        ? Object.fromEntries(Object.keys(v).sort().map(k => [k, canonical(v[k])])) : typeof v === 'bigint' ? v.toString() : v;
    return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(canonical(value))).digest('hex');
}
const jobKey = (j) => version([j.clientId, j.entityId, j.cause]);
exports.jobKey = jobKey;
function reasonCode(error) {
    const text = error instanceof Error ? error.message : '';
    if (text.includes('Не определена заявка или филиал'))
        return 'MISSING_WAREHOUSE';
    if (text.includes('физическое списание'))
        return 'MISSING_PHYSICAL_EVIDENCE';
    if (text.includes('Недостаточно') || text.includes('недостаточно'))
        return 'PACKING_SHORTAGE';
    return 'REVIEW_REQUIRED';
}
const retryDelay = (attempts) => Math.min(6 * 60 * 60_000, 5 * 60_000 * 2 ** Math.min(7, Math.max(0, attempts - 1)));
exports.retryDelay = retryDelay;
// FIX: durable scheduling only. The existing stock service still owns all physical checks.
async function runReconciliationJobs(db, jobs, limit = 50) {
    if (!jobs.length)
        return { attempted: 0, failed: 0 };
    const byKey = new Map(jobs.map(j => [(0, exports.jobKey)(j), j]));
    const rows = [...byKey].map(([key, j]) => ({ key, clientId: j.clientId, requestId: j.requestId, warehouseId: j.warehouseId, entityId: j.entityId, cause: j.cause, label: j.label, version: version(j.evidence) }));
    for (let offset = 0; offset < rows.length; offset += 500) {
        const json = JSON.stringify(rows.slice(offset, offset + 500));
        await db.$executeRaw(client_1.Prisma.sql `INSERT INTO "WmsReconciliationCase" ("key","clientId","requestId","warehouseId","entityId","cause","label","evidenceVersion")
      SELECT x.key,x."clientId",x."requestId",x."warehouseId",x."entityId",x.cause,x.label,x.version
      FROM jsonb_to_recordset(${json}::jsonb) AS x(key text,"clientId" text,"requestId" text,"warehouseId" text,"entityId" text,cause text,label text,version text)
      ON CONFLICT ("key") DO UPDATE SET "evidenceVersion"=EXCLUDED."evidenceVersion", "nextAttemptAt"=NOW(), "attempts"=0,
        "requestId"=EXCLUDED."requestId", "warehouseId"=EXCLUDED."warehouseId", "label"=EXCLUDED."label", "resolvedAt"=NULL, "updatedAt"=NOW()
      WHERE "WmsReconciliationCase"."evidenceVersion"<>EXCLUDED."evidenceVersion"
        AND ("WmsReconciliationCase"."leaseUntil" IS NULL OR "WmsReconciliationCase"."leaseUntil"<NOW())`);
    }
    const ids = [...byKey.keys()];
    const due = await db.$queryRaw(client_1.Prisma.sql `SELECT "key","evidenceVersion" FROM "WmsReconciliationCase"
    WHERE "key" IN (SELECT jsonb_array_elements_text(${JSON.stringify(ids)}::jsonb)) AND "nextAttemptAt"<=NOW() AND ("leaseUntil" IS NULL OR "leaseUntil"<NOW())
    ORDER BY "lastAttemptAt" ASC NULLS FIRST,"createdAt","key" LIMIT ${Math.min(100, Math.max(1, limit))}`);
    let attempted = 0, failed = 0;
    for (const row of due) {
        const job = byKey.get(row.key);
        if (version(job.evidence) !== row.evidenceVersion)
            continue;
        const token = (0, node_crypto_1.randomUUID)();
        const claim = await db.$queryRaw(client_1.Prisma.sql `UPDATE "WmsReconciliationCase" SET "leaseToken"=${token},"leaseUntil"=NOW()+INTERVAL '5 minutes',
      "attempts"="attempts"+1,"lastAttemptAt"=NOW(),"updatedAt"=NOW()
      WHERE "key"=${row.key} AND "evidenceVersion"=${row.evidenceVersion} AND "nextAttemptAt"<=NOW()
        AND ("leaseUntil" IS NULL OR "leaseUntil"<NOW()) RETURNING "attempts"`);
        if (!claim.length)
            continue;
        attempted++;
        let reason = null;
        try {
            await job.run();
        }
        catch (error) {
            reason = reasonCode(error);
            failed++;
        }
        const delay = reason ? (0, exports.retryDelay)(claim[0].attempts) : 6 * 60 * 60_000;
        await db.$executeRaw(client_1.Prisma.sql `UPDATE "WmsReconciliationCase" SET "leaseToken"=NULL,"leaseUntil"=NULL,"reasonCode"=${reason},
      "resolvedAt"=CASE WHEN ${reason}::text IS NULL THEN NOW() ELSE NULL END,"nextAttemptAt"=NOW()+${delay}*INTERVAL '1 millisecond',"updatedAt"=NOW()
      WHERE "key"=${row.key} AND "leaseToken"=${token}`);
    }
    return { attempted, failed };
}
