"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizReviewQueue = exports.reviewContext = exports.unitReviewContext = exports.kizReviewEnabled = void 0;
exports.permittedReviewAction = permittedReviewAction;
exports.requireReviewAdmin = requireReviewAdmin;
exports.queueKizReview = queueKizReview;
exports.finishKizReview = finishKizReview;
exports.reusePermissionForProposal = reusePermissionForProposal;
exports.approvedUnitRelabel = approvedUnitRelabel;
exports.assertUnusedReplacement = assertUnusedReplacement;
const physical_reuse = require("./kiz-physical-reuse");
const kiz_cancelled_reuse_1 = require("./kiz-cancelled-reuse");
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
const kiz_physical_identity_1 = require("./kiz-physical-identity");
const kiz_wb_reuse_1 = require("./kiz-wb-reuse");
const kiz_manual_writeoff_1 = require("./kiz-manual-writeoff");
const kizReviewEnabled = () => (0, kiz_wb_reuse_1.kizReuseEnabled)() && process.env.WMS_KIZ_REVIEW_QUEUE_ENABLED === 'true';
exports.kizReviewEnabled = kizReviewEnabled;
const closed = ['DONE', 'CANCELLED', 'REJECTED'];
const json = (value) => JSON.parse(JSON.stringify(value));
const identityOf = (value) => (0, kiz_physical_identity_1.physicalKizIdentity)(value.replace(/^\(01\)(\d{14})\(21\)/, (_, gtin) => `01${gtin}21`).replace(/^(01\d{14})\u001d21/, (_, gtin) => `${gtin}21`));
const prefixesOf = (identity) => [identity, ']d2' + identity, ']D2' + identity, `(01)${identity.slice(2, 16)}(21)${identity.slice(18)}`];
// FIX: UNIT records deliberately have no request; the namespace separates them from assembly cases.
const unitKey = (markId) => `UNIT:${markId}`;
const unitReviewContext = (m) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([m.id, m.clientId, m.skuId, m.boxId, m.status, m.updatedAt])).digest('hex');
exports.unitReviewContext = unitReviewContext;
async function unitMark(tx, clientId, identity) {
    const marks = await tx.productMark.findMany({ where: { clientId, OR: prefixesOf(identity).map(p => ({ value: { startsWith: p } })) }, include: { box: true, sku: true } });
    const exact = marks.filter(m => identityOf(m.value) === identity);
    return exact.length === 1 ? exact[0] : null;
}
const reviewContext = (t) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([
    t.id, t.clientId, t.connectionId, t.requestId, t.orderId, t.skuId, t.boxId, t.workerUserId, t.startedAt, t.createdAt,
])).digest('hex');
exports.reviewContext = reviewContext;
// FIX: approvals never transfer to another unit, task attempt or relabel route.
function permittedReviewAction(row, context, decision) {
    if (!row || row.context !== context || row.status !== 'APPROVED')
        return null;
    if (row.resolution === 'REUSE' && decision !== 'RELABEL')
        return 'ALLOW';
    if (row.resolution === 'RELABEL' && decision === 'RELABEL')
        return 'RELABEL';
    return null;
}
function requireReviewAdmin(user) {
    if (!(0, exports.kizReviewEnabled)() || user.isDemo || !user.roleCodes.some(r => ['ADMIN', 'OWNER', 'SUPER_ADMIN'].includes(r)))
        throw new common_1.ForbiddenException('Разбор КИЗов доступен администратору и собственнику.');
    if (!user.activeWarehouseId)
        throw new common_1.BadRequestException('Сначала выберите филиал.');
    if (!user.permissionCodes.includes('system:admin') && user.warehouseIds && !user.warehouseIds.includes(user.activeWarehouseId))
        throw new common_1.ForbiddenException('Нет доступа к выбранному филиалу.');
}
async function lock(tx, taskId) {
    await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "FbsTsdAssembly" WHERE "id"=${taskId} FOR UPDATE`);
}
// FIX: persist the case outside the subsequently rejected scanner action. Repeated scans update one row.
async function queueKizReview(db, clientId, kiz, taskId, evidence) {
    if (!(0, exports.kizReviewEnabled)())
        return evidence.decision;
    const identity = identityOf(kiz);
    if (!identity)
        throw new common_1.BadRequestException('Не удалось определить КИЗ для проверки.');
    return db.$transaction(async (tx) => {
        await lock(tx, taskId);
        const task = await tx.fbsTsdAssembly.findUnique({ where: { id: taskId } });
        if (!task || task.clientId !== clientId || task.marketplace !== 'WILDBERRIES')
            throw new common_1.ConflictException('Задание изменилось.');
        const request = await tx.clientRequest.findUnique({ where: { id: task.requestId }, select: { clientId: true, warehouseId: true, number: true, status: true } });
        if (!request?.warehouseId || request.clientId !== clientId || closed.includes(request.status) || task.status !== 'IN_PROGRESS')
            throw new common_1.ConflictException('Заявка больше не доступна для отбора.');
        const key = { taskId_kizIdentity: { taskId, kizIdentity: identity } };
        if (evidence.decision === 'ALLOW' && evidence.manualWriteoffRecovery) {
            await (0, kiz_manual_writeoff_1.releaseWrittenOffBindings)(tx, task, kiz, evidence.manualWriteoffRecovery);
            const context = (0, exports.reviewContext)(task);
            const old = await tx.kizReviewCase.findUnique({ where: key });
            const data = { clientId, warehouseId: request.warehouseId, requestId: task.requestId, kiz, context, decision: 'ALLOW', status: 'APPROVED', resolution: 'REUSE',
                reason: 'Автоматически: ручное списание и подтверждённое физическое восстановление', decidedById: null, decidedByName: 'Система', decidedAt: new Date(), usedAt: null, evidence: json(evidence),
                snapshot: json({ requestNumber: request.number, orderId: task.orderId, productName: task.productName, article: task.article, boxCode: task.boxCode, workerName: task.workerName }) };
            const row = await tx.kizReviewCase.upsert({ where: key, create: { ...data, taskId, kizIdentity: identity }, update: { ...data, attempts: { increment: 1 } } });
            if (old?.status !== 'APPROVED' || old.context !== context || old.reason !== data.reason)
                await tx.auditLog.create({ data: { userId: task.workerUserId, action: 'KIZ_MANUAL_WRITEOFF_REUSE_ALLOWED', entity: 'KizReviewCase', entityId: row.id,
                        payload: json({ taskId, clientId, kizIdentity: identity, reason: data.reason, proof: evidence.manualWriteoffRecovery }) } });
            return 'ALLOW';
        }
        // FIX: claim a standalone permission once, atomically, for the next actual picking attempt.
        const mark = await unitMark(tx, clientId, identity);
        if (mark && mark.status === 'AVAILABLE' && mark.skuId === task.skuId && mark.boxId === task.boxId && mark.box?.warehouseId === request.warehouseId) {
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "KizReviewCase" WHERE "taskId"=${unitKey(mark.id)} FOR UPDATE`);
            const independent = await tx.kizReviewCase.findUnique({ where: { taskId_kizIdentity: { taskId: unitKey(mark.id), kizIdentity: identity } } });
            if (independent?.context === (0, exports.unitReviewContext)(mark) && ['APPROVED', 'CLAIMED'].includes(independent.status)) {
                const snapshot = independent.snapshot;
                const claimed = typeof snapshot.claimedTaskId === 'string' ? snapshot.claimedTaskId : null;
                const owner = claimed && claimed !== taskId ? await tx.fbsTsdAssembly.findUnique({ where: { id: claimed } }) : null;
                if (owner && (owner.status === 'IN_PROGRESS' || owner.kiz))
                    throw new common_1.ConflictException('Разрешение по КИЗу уже используется в другой сборке.');
                const allowed = independent.resolution === 'RELABEL' ? 'RELABEL' : permittedReviewAction({ ...independent, status: 'APPROVED' }, (0, exports.unitReviewContext)(mark), evidence.decision);
                if (allowed) {
                    const data = { clientId, warehouseId: request.warehouseId, requestId: task.requestId, kiz, context: (0, exports.reviewContext)(task), decision: evidence.decision,
                        status: 'APPROVED', resolution: independent.resolution, reason: independent.reason, decidedById: independent.decidedById,
                        decidedByName: independent.decidedByName, decidedAt: independent.decidedAt, evidence: json(evidence), usedAt: null,
                        snapshot: json({ requestNumber: request.number, orderId: task.orderId, productName: task.productName, boxCode: task.boxCode, workerName: task.workerName, unitApprovalId: independent.id }) };
                    await tx.kizReviewCase.upsert({ where: key, create: { ...data, taskId, kizIdentity: identity }, update: data });
                    if (independent.status !== 'CLAIMED' || claimed !== taskId) {
                        await tx.kizReviewCase.update({ where: { id: independent.id }, data: { status: 'CLAIMED', snapshot: json({ ...snapshot, claimedTaskId: taskId }) } });
                        await tx.auditLog.create({ data: { userId: task.workerUserId, action: 'KIZ_UNIT_PERMISSION_CLAIMED', entity: 'KizReviewCase', entityId: independent.id, payload: json({ taskId, kizIdentity: identity }) } });
                    }
                    return allowed;
                }
            }
        }
        const previous = await tx.kizReviewCase.findUnique({ where: key });
        if (evidence.decision === 'ALLOW' && !previous)
            return 'ALLOW';
        const context = (0, exports.reviewContext)(task);
        const staleUnitPermission = Boolean(previous?.snapshot?.unitApprovalId);
        const physicalPermission = physical_reuse.physicalReusePermission(previous, context, evidence, mark);
        const permission = staleUnitPermission ? null : physicalPermission ? "ALLOW" : previous?.snapshot?.physicalReuse ? null : permittedReviewAction(previous, context, evidence.decision);
        const reset = staleUnitPermission || previous?.context !== context || (previous?.resolution === 'REUSE' && evidence.decision === 'RELABEL' && !physicalPermission) || (previous?.snapshot?.physicalReuse && !physicalPermission) ||
            (previous?.resolution === 'RELABEL' && evidence.decision !== 'RELABEL');
        const status = permission ? 'APPROVED' : evidence.decision === 'ALLOW' ? 'RESOLVED' : 'OPEN';
        const common = { clientId, warehouseId: request.warehouseId, requestId: task.requestId, kiz, context, decision: evidence.decision, status,
            snapshot: json({ requestNumber: request.number, orderId: task.orderId, productName: task.productName, article: task.article,
                barcode: task.barcode, boxCode: task.boxCode, workerName: task.workerName, workerUserId: task.workerUserId, ...(physicalPermission ? {physicalReuse:previous.snapshot.physicalReuse} : {}) }), evidence: json(evidence) };
        const row = await tx.kizReviewCase.upsert({ where: key, create: { ...common, taskId, kizIdentity: identity },
            update: { ...common, attempts: { increment: 1 }, ...(reset ? { resolution: null, reason: null, decidedById: null, decidedByName: null, decidedAt: null, usedAt: null } : {}) } });
        if (!previous || reset)
            await tx.auditLog.create({ data: { userId: task.workerUserId, action: 'KIZ_REVIEW_OPENED', entity: 'KizReviewCase', entityId: row.id,
                    payload: json({ taskId, clientId, kizIdentity: identity, context, evidence }) } });
        return permission ?? (evidence.decision === 'ALLOW' ? 'ALLOW' : 'REVIEW');
    });
}
class KizReviewQueue {
    db;
    clients;
    constructor(db, clients) {
        this.db = db;
        this.clients = clients;
    }
    async forKiz(identity, user) { return (await this.list(user, undefined, identity)).items; }
    async unitChoices(identity, user) {
        requireReviewAdmin(user);
        const marks = await this.db.productMark.findMany({ where: { clientId: this.clients.resolveClientFilter(user), box: { warehouseId: user.activeWarehouseId },
                OR: prefixesOf(identity).map(p => ({ value: { startsWith: p } })) }, include: { box: true, sku: true } });
        const exact = marks.filter(m => identityOf(m.value) === identity);
        if (exact.length !== 1)
            return [];
        const mark = exact[0];
        const evidence = await (0, kiz_wb_reuse_1.inspectKizReuse)(this.db, mark.clientId, mark.value);
        const saved = await this.db.kizReviewCase.findUnique({ where: { taskId_kizIdentity: { taskId: unitKey(mark.id), kizIdentity: identity } } });
        const current = saved?.context === (0, exports.unitReviewContext)(mark) && ['APPROVED', 'CLAIMED'].includes(saved.status) &&
            !(saved.resolution === 'REUSE' && evidence.decision === 'RELABEL') ? saved : null;
        return [{ id: `unit:${mark.id}`, kizIdentity: identity, status: current?.status ?? 'OPEN', decision: evidence.decision,
                resolution: current?.resolution, decidedByName: current?.decidedByName, active: mark.status === 'AVAILABLE' && !['archived', 'deleted'].includes(mark.box?.status ?? 'deleted'),
                snapshot: { scope: 'UNIT', productName: mark.sku.name, boxCode: mark.box?.code }, scope: 'UNIT' }];
    }
    async list(user, cursor, identity) {
        requireReviewAdmin(user);
        const items = await this.db.kizReviewCase.findMany({ where: { warehouseId: user.activeWarehouseId, clientId: this.clients.resolveClientFilter(user),
                NOT: [{ taskId: { startsWith: 'UNIT:' } }, { taskId: { startsWith: 'FOUND:' } }],
                status: { in: ['OPEN', 'APPROVED'] }, ...(identity ? { kizIdentity: identity } : {}) }, orderBy: [{ createdAt: 'desc' }, { id: 'desc' }], take: 51, ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}) });
        const tasks = await this.db.fbsTsdAssembly.findMany({ where: { id: { in: items.map(r => r.taskId) } } });
        const rows = items.slice(0, 50).map(({ kiz, ...r }) => {
            const task = tasks.find(t => t.id === r.taskId);
            const evidence = r.evidence;
            const history = evidence.history.filter(h => h.request?.warehouseId === user.activeWarehouseId);
            return { ...r, physicalReuseAllowed: physical_reuse.physicalReuseEligible(evidence), evidence: { ...evidence, history, orders: evidence.orders.filter(o => history.some(h => h.orderId === o.orderId)) },
                active: Boolean(task && task.status === 'IN_PROGRESS' && !task.kiz && (0, exports.reviewContext)(task) === r.context) };
        });
        return { items: rows, nextCursor: items.length > 50 ? rows[rows.length - 1].id : null };
    }
    async decide(id, resolution, reason, confirmed, user) {
        requireReviewAdmin(user);
        if (!user.permissionCodes.includes('system:admin') && user.writableWarehouseIds && !user.writableWarehouseIds.includes(user.activeWarehouseId))
            throw new common_1.ForbiddenException('Нет права изменять данные выбранного филиала.');
        if (!['REUSE', 'RELABEL'].includes(resolution) || !confirmed || reason.trim().length < 5 || reason.length > 1000)
            throw new common_1.BadRequestException('Подтвердите проверку единицы и укажите основание решения (от 5 до 1000 символов).');
        if (id.startsWith('unit:'))
            return this.decideUnit(id.slice(5), resolution, reason, user);
        const row = await this.db.kizReviewCase.findFirst({ where: { id, warehouseId: user.activeWarehouseId, clientId: this.clients.resolveClientFilter(user) } });
        if (!row)
            throw new common_1.NotFoundException('Обращение не найдено в выбранном филиале.');
        this.clients.requireClientAccess(user, row.clientId, 'write');
        const evidence = await (0, kiz_wb_reuse_1.inspectKizReuse)(this.db, row.clientId, row.kiz, row.taskId);
        const physicalOverride = resolution === 'REUSE' && physical_reuse.physicalReuseEligible(evidence);
        if (resolution === 'REUSE' && evidence.decision === 'RELABEL' && !physicalOverride)
            throw new common_1.BadRequestException('Подтверждена продажа или погашение. Можно разрешить только переклейку.');
        if (resolution === 'RELABEL' && evidence.decision !== 'RELABEL')
            throw new common_1.BadRequestException('Необходимость переклейки не подтверждена. Обновите проверку.');
        return this.db.$transaction(async (tx) => {
            await lock(tx, row.taskId);
            const task = await tx.fbsTsdAssembly.findUnique({ where: { id: row.taskId } });
            const fresh = await tx.kizReviewCase.findUnique({ where: { id } });
            if (!task || !fresh || task.kiz || task.status !== 'IN_PROGRESS' || task.clientId !== row.clientId ||
                (0, exports.reviewContext)(task) !== row.context || fresh.context !== row.context || !['OPEN', 'APPROVED'].includes(fresh.status))
                throw new common_1.ConflictException('Задание или обращение изменилось. Обновите очередь.');
            const request = await tx.clientRequest.findUnique({ where: { id: task.requestId } });
            const box = task.boxId ? await tx.box.findUnique({ where: { id: task.boxId } }) : null;
            const marks = await tx.productMark.findMany({ where: { clientId: row.clientId, OR: prefixesOf(row.kizIdentity).map(prefix => ({ value: { startsWith: prefix } })) } });
            const exact = marks.filter(m => identityOf(m.value) === row.kizIdentity);
            if (exact.length > 1)
                throw new common_1.ConflictException('Найден дубль КИЗа. Сначала разберите дубли.');
            const mark = exact[0];
            if (!request || closed.includes(request.status) || request.clientId !== row.clientId || request.warehouseId !== row.warehouseId ||
                !box || box.clientId !== row.clientId || box.warehouseId !== row.warehouseId || ['archived', 'deleted'].includes(box.status) ||
                !mark || mark.status !== 'AVAILABLE' || mark.skuId !== task.skuId || mark.boxId !== task.boxId)
                throw new common_1.ConflictException('Единица не подтверждена в доступном остатке выбранного короба.');
            const balance = await tx.stockBalance.aggregate({ where: { clientId: row.clientId, warehouseId: row.warehouseId, skuId: task.skuId, boxId: task.boxId, status: 'AVAILABLE' }, _sum: { quantity: true } });
            if ((balance._sum.quantity ?? 0) < 1)
                throw new common_1.ConflictException('Доступного остатка для единицы нет.');
            const links = await tx.fbsTsdAssembly.findMany({ where: { id: { not: task.id }, clientId: row.clientId,
                    OR: prefixesOf(row.kizIdentity).map(prefix => ({ kiz: { startsWith: prefix } })) } });
            // Reuse cannot steal any stored binding; relabel keeps history and retains its normal source checks.
            let physicalProof = null;
            if (physicalOverride) physicalProof = await physical_reuse.approvePhysicalReuse(tx,task,mark,evidence,user,id,reason.trim());
            if (!physicalOverride && resolution === 'REUSE' && links.some(t => identityOf(t.kiz ?? '') === row.kizIdentity))
                await (0, kiz_cancelled_reuse_1.releaseCancelledBindings)(tx, row.clientId, row.kiz, evidence, user.id, id, task.id, true);
            if (resolution === 'RELABEL') {
                const exactLinks = links.filter(t => identityOf(t.kiz ?? '') === row.kizIdentity);
                const requestIds = [...new Set(exactLinks.map(t => t.requestId))];
                const closedCount = requestIds.length ? await tx.clientRequest.count({ where: { id: { in: requestIds }, clientId: row.clientId, status: { in: closed } } }) : 0;
                if (closedCount !== requestIds.length || exactLinks.some(t => !['COMPLETED', 'RETURN_REQUIRED'].includes(t.status)))
                    throw new common_1.ConflictException('КИЗ занят другой незавершённой сборкой. Сначала разберите прежнюю заявку.');
            }
            if (fresh.status === 'APPROVED') {
                if (fresh.resolution !== resolution)
                    throw new common_1.ConflictException('По обращению уже принято другое решение.');
                return { id, status: fresh.status, resolution: fresh.resolution };
            }
            await tx.kizReviewCase.update({ where: { id }, data: { status: 'APPROVED', resolution, reason: reason.trim(), decidedById: user.id,
                    decidedByName: user.name, decidedAt: new Date(), decision: evidence.decision, evidence: json(evidence), ...(physicalProof ? {snapshot:json({...fresh.snapshot,physicalReuse:physicalProof})} : {}) } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'KIZ_REVIEW_APPROVED', entity: 'KizReviewCase', entityId: id,
                    payload: json({ resolution, reason: reason.trim(), confirmed, taskId: task.id, context: row.context, kizIdentity: row.kizIdentity, evidence, physicalProof }) } });
            return { id, status: 'APPROVED', resolution };
        });
    }
    async decideUnit(markId, resolution, reason, user) {
        const initial = await this.db.productMark.findFirst({ where: { id: markId, clientId: this.clients.resolveClientFilter(user), box: { warehouseId: user.activeWarehouseId } } });
        if (!initial)
            throw new common_1.NotFoundException('КИЗ не найден в выбранном филиале.');
        this.clients.requireClientAccess(user, initial.clientId, 'write');
        const identity = identityOf(initial.value);
        if (!identity)
            throw new common_1.BadRequestException('КИЗ не распознан.');
        const evidence = await (0, kiz_wb_reuse_1.inspectKizReuse)(this.db, initial.clientId, initial.value);
        if (resolution === 'REUSE' && evidence.decision === 'RELABEL')
            throw new common_1.BadRequestException('Подтверждена продажа или погашение. Можно разрешить только переклейку.');
        if (resolution === 'RELABEL' && evidence.decision !== 'RELABEL')
            throw new common_1.BadRequestException('Необходимость переклейки не подтверждена.');
        return this.db.$transaction(async (tx) => {
            await tx.$queryRaw(client_1.Prisma.sql `SELECT "id" FROM "ProductMark" WHERE "id"=${markId} FOR UPDATE`);
            const mark = await unitMark(tx, initial.clientId, identity);
            if (!mark || mark.id !== markId || (0, exports.unitReviewContext)(mark) !== (0, exports.unitReviewContext)(initial) || mark.status !== 'AVAILABLE' ||
                !mark.box || mark.box.clientId !== mark.clientId || mark.box.warehouseId !== user.activeWarehouseId || ['archived', 'deleted'].includes(mark.box.status))
                throw new common_1.ConflictException('Единица изменилась или недоступна. Повторите проверку КИЗа.');
            const balance = await tx.stockBalance.aggregate({ where: { clientId: mark.clientId, warehouseId: user.activeWarehouseId, skuId: mark.skuId, boxId: mark.boxId, status: 'AVAILABLE' }, _sum: { quantity: true } });
            if ((balance._sum.quantity ?? 0) < 1)
                throw new common_1.ConflictException('Нет доступного остатка этой единицы.');
            const links = (await tx.fbsTsdAssembly.findMany({ where: { clientId: mark.clientId, OR: prefixesOf(identity).map(p => ({ kiz: { startsWith: p } })) } })).filter(t => identityOf(t.kiz ?? '') === identity);
            // FIX: admin-only reuse of an audited cancelled return, also from independent TSD lookup.
            if (resolution === 'REUSE' && links.length)
                await (0, kiz_cancelled_reuse_1.releaseCancelledBindings)(tx, mark.clientId, mark.value, evidence, user.id, 'unit:' + markId, '', true);
            if (resolution === 'RELABEL' && links.length) {
                const ids = [...new Set(links.map(t => t.requestId))];
                if (links.some(t => !['COMPLETED', 'RETURN_REQUIRED'].includes(t.status)) || await tx.clientRequest.count({ where: { id: { in: ids }, clientId: mark.clientId, status: { in: closed } } }) !== ids.length)
                    throw new common_1.ConflictException('КИЗ занят незавершённой сборкой.');
            }
            const key = { taskId_kizIdentity: { taskId: unitKey(markId), kizIdentity: identity } };
            const old = await tx.kizReviewCase.findUnique({ where: key });
            if (old?.context === (0, exports.unitReviewContext)(mark) && ['APPROVED', 'CLAIMED'].includes(old.status) &&
                !(old.resolution === 'REUSE' && resolution === 'RELABEL' && evidence.decision === 'RELABEL')) {
                if (old.resolution !== resolution)
                    throw new common_1.ConflictException('По этому КИЗу уже принято другое решение.');
                return { id: `unit:${markId}`, status: old.status, resolution };
            }
            const data = { clientId: mark.clientId, warehouseId: user.activeWarehouseId, requestId: '', kiz: mark.value, context: (0, exports.unitReviewContext)(mark), status: 'APPROVED',
                decision: evidence.decision, resolution, reason: reason.trim(), decidedById: user.id, decidedByName: user.name, decidedAt: new Date(), usedAt: null, evidence: json(evidence),
                snapshot: json({ scope: 'UNIT', markId, skuId: mark.skuId, boxId: mark.boxId, boxCode: mark.box.code, productName: mark.sku.name }) };
            const row = await tx.kizReviewCase.upsert({ where: key, create: { ...data, taskId: unitKey(markId), kizIdentity: identity }, update: data });
            await tx.auditLog.create({ data: { userId: user.id, action: 'KIZ_UNIT_PERMISSION_APPROVED', entity: 'KizReviewCase', entityId: row.id, payload: json({ resolution, reason: reason.trim(), markId, kizIdentity: identity, evidence }) } });
            return { id: `unit:${markId}`, status: 'APPROVED', resolution };
        });
    }
}
exports.KizReviewQueue = KizReviewQueue;
// FIX: acceptance consumes only this task's approval; uncertain network retries remain possible beforehand.
async function finishKizReview(tx, task, kiz, resolution) {
    if (!(0, exports.kizReviewEnabled)())
        return;
    await tx.kizReviewCase.updateMany({ where: { taskId: task.id, kizIdentity: identityOf(kiz), context: (0, exports.reviewContext)(task),
            status: 'APPROVED', resolution }, data: { status: 'USED', usedAt: new Date() } });
    await tx.kizReviewCase.updateMany({ where: { clientId: task.clientId, kizIdentity: identityOf(kiz), taskId: { startsWith: 'UNIT:' }, status: 'CLAIMED', resolution,
            snapshot: { path: ['claimedTaskId'], equals: task.id } }, data: { status: 'USED', usedAt: new Date() } });
}
async function reusePermissionForProposal(tx, task, kiz) {
    if (!(0, exports.kizReviewEnabled)())
        return false;
    const identity = identityOf(kiz);
    if (!identity)
        return false;
    if (await tx.kizReviewCase.findFirst({ where: { taskId: task.id, kizIdentity: identity, context: (0, exports.reviewContext)(task), status: 'APPROVED', resolution: 'REUSE' } }))
        return true;
    const mark = await unitMark(tx, task.clientId, identity);
    if (!mark || mark.skuId !== task.skuId || mark.boxId !== task.boxId || mark.status !== 'AVAILABLE')
        return false;
    return Boolean(await tx.kizReviewCase.findFirst({ where: { taskId: unitKey(mark.id), kizIdentity: identity, context: (0, exports.unitReviewContext)(mark), status: { in: ['APPROVED', 'CLAIMED'] }, resolution: 'REUSE' } }));
}
async function approvedUnitRelabel(tx, task, kiz) {
    if (!(0, exports.kizReviewEnabled)())
        return false;
    return Boolean(await tx.kizReviewCase.findFirst({ where: { taskId: task.id, kizIdentity: identityOf(kiz),
            context: (0, exports.reviewContext)(task), status: 'APPROVED', resolution: 'RELABEL' } }));
}
// FIX: a different crypto suffix does not make an already registered serial into a new KIZ.
async function assertUnusedReplacement(tx, value) {
    const identity = identityOf(value);
    if (!identity)
        throw new common_1.BadRequestException('Отсканируйте полный новый КИЗ.');
    await tx.$queryRaw(client_1.Prisma.sql `SELECT 1 FROM pg_advisory_xact_lock(hashtextextended(${identity},0))`);
    const prefixes = prefixesOf(identity);
    const [marks, tasks, history] = await Promise.all([
        tx.productMark.findMany({ where: { OR: prefixes.map(p => ({ value: { startsWith: p } })) }, select: { value: true } }),
        tx.fbsTsdAssembly.findMany({ where: { OR: prefixes.map(p => ({ kiz: { startsWith: p } })) }, select: { kiz: true } }),
        tx.shippedKizHistory.findMany({ where: { OR: prefixes.map(p => ({ kiz: { startsWith: p } })) }, select: { kiz: true } }),
    ]);
    if (marks.some(m => identityOf(m.value) === identity) || [...tasks, ...history].some(m => identityOf(m.kiz ?? '') === identity))
        throw new common_1.BadRequestException('Новый КИЗ уже зарегистрирован или использован. Возьмите свободный новый КИЗ.');
}
