"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hiddenFbsClientIds = hiddenFbsClientIds;
exports.assertFbsClientVisible = assertFbsClientVisible;
const common_1 = require("@nestjs/common");
// FIX: this is a single-client display exception for our company, not a change to show-all semantics.
const GUSHCHA = 'd7b835c1-6273-4b2c-be39-c96476fa7b5d';
const OUR_COMPANY = '0f31c965-66c3-4882-af0a-a390feb15a98';
async function hiddenFbsClientIds(db, user) {
    if (process.env.WMS_FBS_GUSHCHA_VISIBILITY_ENABLED !== 'true' || user.isDemo || user.roleCodes.includes('CLIENT'))
        return [];
    if (!user.activeWarehouseId)
        return [GUSHCHA];
    const warehouse = await db.warehouse.findUnique({ where: { id: user.activeWarehouseId }, select: { ownCompanyId: true } });
    return !warehouse?.ownCompanyId || warehouse.ownCompanyId === OUR_COMPANY ? [GUSHCHA] : [];
}
async function assertFbsClientVisible(db, user, clientId) {
    if (clientId?.trim() !== GUSHCHA)
        return;
    if ((await hiddenFbsClientIds(db, user)).includes(GUSHCHA))
        throw new common_1.NotFoundException('Клиент недоступен в FBS нашей компании.');
}
