"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const swagger_1 = require("@nestjs/swagger");
const app_module_1 = require("./app.module");
const operation_timing_1 = require("./common/diagnostics/operation-timing");
async function bootstrap() {
    const requestBodyLimit = process.env.API_REQUEST_BODY_LIMIT?.trim() || '10mb';
    const app = await core_1.NestFactory.create(app_module_1.AppModule, {
        bodyParser: false,
    });
    // FIX: own-WMS opt-in timing, with request-local correlation and no business payloads.
    app.use((0, operation_timing_1.timingMiddleware)());
    app.use(require('./common/diagnostics/cabinet-json-compression').cabinetJsonCompression);
    app.useBodyParser('json', { limit: requestBodyLimit });
    app.useBodyParser('urlencoded', {
        limit: requestBodyLimit,
        extended: true,
    });
    // Русский комментарий: единая валидация защищает API от "грязных" данных из web, ТСД и интеграций.
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        transform: true,
        forbidNonWhitelisted: true,
    }));
    app.setGlobalPrefix('api/v1');
    app.enableCors({
        origin: [/^https?:\/\/localhost:\d+$/, 'https://wms.logoff.pro'],
        credentials: true,
    });
    const swaggerConfig = new swagger_1.DocumentBuilder()
        .setTitle('LOGOFF WMS API')
        .setDescription('Документация внутреннего API и изолированного Integration API v1. ' +
        'Для внешних систем используйте X-WMS-API-Key; пользовательский Bearer-токен во внешнюю систему не передаётся.')
        .setVersion('1.0.0')
        .addBearerAuth()
        // ADDED: Swagger can authorize external integrations without exposing a WMS user session.
        .addApiKey({ type: 'apiKey', in: 'header', name: 'X-WMS-API-Key' }, 'WmsApiKey')
        .addServer('https://wms.logoff.pro', 'Production')
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, swaggerConfig);
    swagger_1.SwaggerModule.setup('api/docs', app, document, {
        customSiteTitle: 'LOGOFF WMS API',
        jsonDocumentUrl: 'api/docs/openapi.json',
    });
    const port = Number(process.env.API_PORT ?? 3000);
    await app.listen(port, '0.0.0.0');
}
void bootstrap();
