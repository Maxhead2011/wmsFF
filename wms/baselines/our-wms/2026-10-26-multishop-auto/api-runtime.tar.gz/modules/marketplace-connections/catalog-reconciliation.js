"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.catalogReconciliationKey = void 0;
exports.catalogReconciliationEnabled = catalogReconciliationEnabled;
exports.enableCatalogReconciliation = enableCatalogReconciliation;
exports.savedCatalogCards = savedCatalogCards;
const common_1 = require("@nestjs/common");
// FIX: enabling a catalogue audit must not switch operational stock/order identity readers.
const catalogReconciliationKey = (clientId) => `catalog.reconciliation.enabled.v1:${clientId}`;
exports.catalogReconciliationKey = catalogReconciliationKey;
async function catalogReconciliationEnabled(db, clientId) {
    return (await db.systemSetting.findUnique({ where: { key: (0, exports.catalogReconciliationKey)(clientId) } }))?.value === true;
}
async function enableCatalogReconciliation(db, clientId, user) {
    if (!user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)))
        throw new common_1.ForbiddenException('Включить сверку может администратор или собственник.');
    return db.$transaction(async (tx) => {
        await tx.$queryRaw `SELECT id FROM "Client" WHERE id=${clientId} FOR UPDATE`;
        if (await catalogReconciliationEnabled(tx, clientId))
            return { enabled: true, changed: false };
        await tx.systemSetting.upsert({ where: { key: (0, exports.catalogReconciliationKey)(clientId) }, create: { key: (0, exports.catalogReconciliationKey)(clientId), value: true, updatedByUserId: user.id }, update: { value: true, updatedByUserId: user.id } });
        await tx.auditLog.create({ data: { userId: user.id, action: 'CATALOG_RECONCILIATION_ENABLED', entity: 'Client', entityId: clientId, payload: { enabled: true, mode: 'READ_ONLY', operationalLinksChanged: false } } });
        return { enabled: true, changed: true };
    });
}
// FIX: legacy cards are evidence for an audit, never silently promoted to confirmed links.
async function savedCatalogCards(db, connection) {
    const accounts = await db.clientMarketplaceConnection.count({ where: { clientId: connection.clientId, marketplace: connection.marketplace } });
    if (accounts !== 1)
        return [];
    const skus = await db.sku.findMany({ where: { clientId: connection.clientId, marketplace: connection.marketplace, marketplaceProductId: { not: null } }, include: { barcodes: true } });
    return skus.map((s) => ({ id: `saved:${connection.id}:${s.id}`, clientId: connection.clientId, connectionId: connection.id, skuId: s.id, marketplace: connection.marketplace, productId: s.marketplaceProductId, offerId: s.marketplaceOfferId ?? '', barcodes: s.barcodes.map((b) => b.value), size: s.size, color: s.color, status: 'SAVED_CARD', reason: 'Сохранённая карточка: межмаркетплейсная связь не подтверждена', updatedAt: s.updatedAt }));
}
