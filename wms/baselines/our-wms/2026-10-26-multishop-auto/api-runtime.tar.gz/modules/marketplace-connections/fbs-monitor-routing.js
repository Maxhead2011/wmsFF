"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fbsMonitorRoutingEnabled = void 0;
exports.fbsMonitorRoute = fbsMonitorRoute;
exports.fbsMonitorReservation = fbsMonitorReservation;
exports.fbsMonitorScopeWhere = fbsMonitorScopeWhere;
// FIX: opt-in for our WMS; other installations retain their monitoring policy.
const fbsMonitorRoutingEnabled = () => process.env.WMS_FBS_MONITOR_ROUTING_ENABLED === 'true';
exports.fbsMonitorRoutingEnabled = fbsMonitorRoutingEnabled;
function fbsMonitorRoute(connection, warehouseId, routes) {
    const id = warehouseId || connection.fbsWarehouseId;
    const route = routes.find(row => row.connectionId === connection.id && row.marketplaceWarehouseId === id);
    if (!id || route?.mode === 'EXCLUDED')
        return null;
    if (route?.mode === 'BRANCH')
        return route.executionWarehouseId || null;
    if (route?.mode === 'CENTRAL' || (!route && connection.fbsAutoRouteNewWarehouses)) {
        return connection.fbsExecutionWarehouseId || null;
    }
    return null;
}
// FIX: a task for another warehouse, or unreserved demand, cannot prove this sale.
function fbsMonitorReservation(task, skuId, quantity, warehouseId) {
    return Boolean(task && task.skuId === skuId && warehouseId && task.stockWarehouseId === warehouseId &&
        task.reservedAt && ['RESERVED', 'IN_PROGRESS', 'COMPLETED'].includes(task.status) && task.itemCount >= quantity);
}
// FIX: filter before SQL pagination and summaries, including historical excluded events.
async function fbsMonitorScopeWhere(db, clientFilter) {
    if (!(0, exports.fbsMonitorRoutingEnabled)())
        return {};
    const connections = await db.clientMarketplaceConnection.findMany({
        where: { clientId: clientFilter, marketplace: 'WILDBERRIES', isActive: true },
        select: { id: true, fbsWarehouseId: true, fbsExecutionWarehouseId: true, fbsAutoRouteNewWarehouses: true },
    });
    const routes = await db.fbsWarehouseRoutingRule.findMany({ where: { connectionId: { in: connections.map(c => c.id) } } });
    return { OR: connections.map(c => {
            const own = routes.filter(r => r.connectionId === c.id);
            const allowed = own.filter(r => fbsMonitorRoute(c, r.marketplaceWarehouseId, routes)).map(r => r.marketplaceWarehouseId);
            const forbidden = own.filter(r => !fbsMonitorRoute(c, r.marketplaceWarehouseId, routes)).map(r => r.marketplaceWarehouseId);
            return { connectionId: c.id, marketplaceWarehouseId: c.fbsAutoRouteNewWarehouses && c.fbsExecutionWarehouseId
                    ? { notIn: forbidden } : { in: allowed } };
        }) };
}
