"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MultishopStockGroupsService = void 0;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const multishop_stock_plan_1 = require("./multishop-stock-plan");
const keyFor = (clientId) => `marketplace.multishop.draft.v1:${clientId}`;
// FIX: settings alone never activate external writes; drafts are versioned and audited.
let MultishopStockGroupsService = class MultishopStockGroupsService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    capabilities() { return { enabled: process.env.WMS_MULTISHOP_STOCK_ENABLED === 'true', publicationEnabled: process.env.WMS_MULTISHOP_PUBLICATION_ENABLED === 'true' }; }
    authorize(clientId, user, write = false) {
        if (!this.capabilities().enabled || user.isDemo)
            throw new common_1.ForbiddenException('Группы магазинов недоступны.');
        if (typeof clientId !== 'string' || !clientId.trim())
            throw new common_1.BadRequestException('Выберите клиента.');
        this.scopes.requireClientAccess(user, clientId, write ? 'write' : 'read');
        // A client-wide configuration may cover multiple branches; branch-local staff cannot replace it.
        if (write && !user.permissionCodes.includes('system:admin') && !user.roleCodes.includes('CLIENT') && (user.warehouseIds?.length ?? 0) > 0) {
            throw new common_1.ForbiddenException('Общие группы магазинов настраивает администратор сети или клиент с правом изменения.');
        }
    }
    connections(db, clientId) {
        return db.clientMarketplaceConnection.findMany({ where: { clientId, isActive: true, marketplace: { in: ['WILDBERRIES', 'OZON'] } },
            select: { id: true, accountName: true, marketplace: true, fbsExecutionWarehouseId: true }, orderBy: [{ marketplace: 'asc' }, { id: 'asc' }] });
    }
    async read(clientId, user) {
        this.authorize(clientId, user);
        const [saved, connections] = await Promise.all([
            this.prisma.systemSetting.findUnique({ where: { key: keyFor(clientId) } }), this.connections(this.prisma, clientId),
        ]);
        const state = saved?.value;
        let invalidReason = null;
        if (state) {
            try {
                (0, multishop_stock_plan_1.validateShopGroups)(state.config.groups, state.config.assignments, connections.map(c => ({ id: c.id, warehouseId: c.fbsExecutionWarehouseId })));
            }
            catch (error) {
                invalidReason = error instanceof Error ? error.message : 'Проверьте настройки групп.';
            }
        }
        return { ...this.capabilities(), revision: state?.revision ?? null, config: state?.config ?? { groups: [], assignments: [] },
            connections, invalidReason, changedAt: saved?.updatedAt.toISOString() ?? null };
    }
    async save(clientId, body, user) {
        this.authorize(clientId, user, true);
        if (!body || (body.revision !== null && typeof body.revision !== 'string'))
            throw new common_1.BadRequestException('Передайте версию настроек.');
        const key = keyFor(clientId);
        return this.prisma.$transaction(async (tx) => {
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${key}))`;
            const previous = await tx.systemSetting.findUnique({ where: { key } });
            const before = previous?.value;
            if ((before?.revision ?? null) !== body.revision)
                throw new common_1.ConflictException('Настройки изменены другим пользователем. Обновите раздел.');
            const connections = await this.connections(tx, clientId);
            try {
                (0, multishop_stock_plan_1.validateShopGroups)(body.config?.groups, body.config?.assignments, connections.map(c => ({ id: c.id, warehouseId: c.fbsExecutionWarehouseId })));
            }
            catch (error) {
                throw new common_1.BadRequestException(error instanceof Error ? error.message : 'Неверные настройки групп.');
            }
            const ids = body.config.assignments.map(a => a.skuId);
            if (ids.length) {
                const count = await tx.sku.count({ where: { clientId, id: { in: ids }, isDraft: false } });
                if (count !== ids.length)
                    throw new common_1.BadRequestException('Часть товаров недоступна или относится к другому клиенту.');
            }
            // Copy only supported fields; no caller-supplied activation or published state can persist here.
            const config = {
                groups: body.config.groups.map(g => ({ id: g.id, name: g.name, warehouseId: g.warehouseId, lowStockThreshold: g.lowStockThreshold,
                    mode: g.mode ?? 'ALLOCATED', safetyReserve: g.safetyReserve ?? 0,
                    members: g.members.map(m => ({ connectionId: m.connectionId, percent: m.percent, priority: m.priority, ...(m.marketplaceWarehouseId ? { marketplaceWarehouseId: m.marketplaceWarehouseId } : {}) })) })),
                assignments: body.config.assignments.map(a => ({ skuId: a.skuId, groupId: a.groupId })),
            };
            const value = { revision: (0, node_crypto_1.randomUUID)(), config };
            await tx.systemSetting.upsert({ where: { key }, create: { key, value: value, updatedByUserId: user.id },
                update: { value: value, updatedByUserId: user.id } });
            await tx.auditLog.create({ data: { userId: user.id, action: 'MULTISHOP_GROUPS_SAVED', entity: 'Client', entityId: clientId,
                    payload: { before: previous?.value ?? null, after: value } } });
            return { ...value, publicationEnabled: this.capabilities().publicationEnabled };
        });
    }
    async products(clientId, query, page, user) {
        this.authorize(clientId, user);
        const term = typeof query === 'string' ? query.trim().slice(0, 150) : '';
        const current = Number.isSafeInteger(page) && page > 0 ? Math.min(page, 100_000) : 1;
        const where = { clientId, isDraft: false, ...(term ? { OR: [
                    { name: { contains: term, mode: 'insensitive' } }, { article: { contains: term, mode: 'insensitive' } },
                    { barcodes: { some: { value: { contains: term } } } },
                ] } : {}) };
        const [items, total] = await Promise.all([
            this.prisma.sku.findMany({ where, select: { id: true, name: true, article: true, size: true, color: true, barcodes: { select: { value: true } } }, orderBy: { id: 'asc' }, skip: (current - 1) * 50, take: 50 }),
            this.prisma.sku.count({ where }),
        ]);
        return { items, total, page: current, pageSize: 50 };
    }
};
exports.MultishopStockGroupsService = MultishopStockGroupsService;
exports.MultishopStockGroupsService = MultishopStockGroupsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], MultishopStockGroupsService);
