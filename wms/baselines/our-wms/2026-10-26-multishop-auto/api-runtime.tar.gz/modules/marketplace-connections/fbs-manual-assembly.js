"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.manualHash = exports.manualAssemblyAllowed = exports.manualAssemblyEnabled = void 0;
exports.requireManualAssembly = requireManualAssembly;
exports.manualOrderIds = manualOrderIds;
exports.untouchedManualTask = untouchedManualTask;
exports.manualOrderPage = manualOrderPage;
exports.validateManualChoices = validateManualChoices;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const manualAssemblyEnabled = () => process.env.WMS_FBS_MANUAL_ASSEMBLY_ENABLED === 'true';
exports.manualAssemblyEnabled = manualAssemblyEnabled;
const manualAssemblyAllowed = (user) => !user.isDemo && user.roleCodes.some(r => r === 'ADMIN' || r === 'OWNER');
exports.manualAssemblyAllowed = manualAssemblyAllowed;
function requireManualAssembly(user) {
    if (!(0, exports.manualAssemblyEnabled)() || !(0, exports.manualAssemblyAllowed)(user))
        throw new common_1.ForbiddenException('Сборка ФБС по номерам доступна администраторам и собственнику только при включённой функции.');
}
function manualOrderIds(value) {
    if (!Array.isArray(value) || !value.length || value.length > 100 || value.some(id => typeof id !== 'string' || !/^[1-9]\d{0,15}$/.test(id) || !Number.isSafeInteger(Number(id)))) {
        throw new common_1.BadRequestException('Введите от 1 до 100 номеров заказов WB, только цифры.');
    }
    if (new Set(value).size !== value.length)
        throw new common_1.BadRequestException('Номера заказов повторяются.');
    return [...value].sort();
}
function untouchedManualTask(task) {
    return !task || (String(task.requestId).startsWith('AUTO:') &&
        ['WAITING_STOCK', 'RESERVED', 'RELEASED'].includes(String(task.status)) && task.itemCount === 1 &&
        !['boxId', 'boxCode', 'barcode', 'sourceBarcode', 'kiz', 'workerUserId', 'startedAt', 'completedAt',
            'sourceSkuId', 'relabelRequired', 'relabelConfirmedAt', 'cargoPackingId', 'marketplaceSubmittedAt'].some(k => task[k]) &&
        !Number(task.scannedItemCount || 0));
}
const manualHash = (value) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(value)).digest('hex');
exports.manualHash = manualHash;
// FIX: WB's nanosecond paging cursor exceeds Number.MAX_SAFE_INTEGER. Keep its JSON source digits.
function manualOrderPage(raw) {
    try {
        return JSON.parse(raw, ((key, value, context) => {
            if (key !== 'next' || typeof value !== 'number')
                return value;
            if (context?.source)
                return context.source;
            if (Number.isSafeInteger(value))
                return String(value);
            throw new Error('JSON parser cannot preserve this WB cursor');
        }));
    }
    catch {
        throw new common_1.BadRequestException('Не удалось точно прочитать страницу WB. Повторите проверку.');
    }
}
// FIX: a box shared by multiple orders is a single stock pool, not one pool per row.
function validateManualChoices(rows, choices) {
    if (!Array.isArray(choices) || choices.length !== rows.length || new Set(choices.map(c => c.orderId)).size !== rows.length)
        throw new common_1.BadRequestException('Выберите ровно один короб для каждого заказа.');
    const byBox = new Map(), bySku = new Map();
    for (const choice of choices) {
        const row = rows.find(r => r.orderId === choice.orderId);
        const box = row?.boxes.find(b => b.boxId === choice.boxId);
        if (!row || row.blockers.length || !row.skuId || !box)
            throw new common_1.ConflictException('Выбранный заказ или короб недоступен. Повторите проверку.');
        const key = `${row.skuId}:${box.boxId}`;
        byBox.set(key, (byBox.get(key) || 0) + 1);
        bySku.set(row.skuId, (bySku.get(row.skuId) || 0) + 1);
        if (byBox.get(key) > box.free || bySku.get(row.skuId) > row.free)
            throw new common_1.ConflictException('На все выбранные заказы не хватает свободного товара. Выберите другой короб или повторите проверку.');
    }
}
