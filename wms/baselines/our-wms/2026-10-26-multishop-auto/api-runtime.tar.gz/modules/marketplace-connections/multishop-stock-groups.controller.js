"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MultishopStockGroupsController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const multishop_stock_groups_service_1 = require("./multishop-stock-groups.service");
const multishop_stock_sync_service_1 = require("./multishop-stock-sync.service");
// FIX: all group and product access remains scoped to the authenticated client.
let MultishopStockGroupsController = class MultishopStockGroupsController {
    groups;
    sync;
    constructor(groups, sync) {
        this.groups = groups;
        this.sync = sync;
    }
    capabilities() { return this.groups.capabilities(); }
    read(clientId, user) { return this.groups.read(clientId, user); }
    save(clientId, body, user) {
        return this.groups.save(clientId, body, user);
    }
    products(clientId, query, page, user) {
        return this.groups.products(clientId, query, Number(page), user);
    }
    status(clientId, user) { return this.sync.status(clientId, user); }
    preview(clientId, user) { return this.sync.preview(clientId, user); }
    activate(clientId, body, user) { return this.sync.activate(clientId, body, user); }
    stop(clientId, user) { return this.sync.stop(clientId, user); }
};
exports.MultishopStockGroupsController = MultishopStockGroupsController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)(':clientId'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "read", null);
__decorate([
    (0, common_1.Put)(':clientId'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "save", null);
__decorate([
    (0, common_1.Get)(':clientId/products'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Query)('q')),
    __param(2, (0, common_1.Query)('page')),
    __param(3, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "products", null);
__decorate([
    (0, common_1.Get)(':clientId/sync'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "status", null);
__decorate([
    (0, common_1.Get)(':clientId/preview'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "preview", null);
__decorate([
    (0, common_1.Put)(':clientId/activate'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "activate", null);
__decorate([
    (0, common_1.Put)(':clientId/stop'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], MultishopStockGroupsController.prototype, "stop", null);
exports.MultishopStockGroupsController = MultishopStockGroupsController = __decorate([
    (0, common_1.Controller)('marketplace-connections/multishop'),
    (0, require_permissions_decorator_1.RequirePermissions)('clients:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof multishop_stock_groups_service_1.MultishopStockGroupsService !== "undefined" && multishop_stock_groups_service_1.MultishopStockGroupsService) === "function" ? _a : Object, typeof (_b = typeof multishop_stock_sync_service_1.MultishopStockSyncService !== "undefined" && multishop_stock_sync_service_1.MultishopStockSyncService) === "function" ? _b : Object])
], MultishopStockGroupsController);
