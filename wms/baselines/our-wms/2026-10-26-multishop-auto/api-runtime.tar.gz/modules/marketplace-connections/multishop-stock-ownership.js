"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MULTISHOP_ACTIVE_PREFIX = void 0;
exports.assertNotMultishopOwned = assertNotMultishopOwned;
const common_1 = require("@nestjs/common");
exports.MULTISHOP_ACTIVE_PREFIX = 'marketplace.multishop.active.v1:';
// FIX: legacy writers are fenced at the common network boundary, including retries.
// Stopping does not silently hand ownership back to the legacy automatic writer.
// Previously managed destinations remain fenced after their zero is confirmed.
async function assertNotMultishopOwned(db, clientId, apiKey, chrtIds) {
    if (process.env.WMS_MULTISHOP_PUBLICATION_ENABLED !== 'true')
        return;
    const setting = await db.systemSetting.findUnique({ where: { key: exports.MULTISHOP_ACTIVE_PREFIX + clientId } });
    const active = setting?.value;
    if (!active)
        return;
    const connection = await db.clientMarketplaceConnection.findFirst({ where: { clientId, marketplace: 'WILDBERRIES', apiKey, isActive: true }, select: { id: true } });
    if (!connection)
        throw new common_1.ConflictException('Кабинет WB не найден.');
    if (Object.values(active.destinations).some(d => d.connectionId === connection.id && d.marketplace === 'WILDBERRIES' && chrtIds.includes(Number(d.productId.split(':').at(-1))))) {
        throw new common_1.ConflictException('Остатками этих товаров управляет группа магазинов. Измените настройки в разделе «Между магазинами».');
    }
}
