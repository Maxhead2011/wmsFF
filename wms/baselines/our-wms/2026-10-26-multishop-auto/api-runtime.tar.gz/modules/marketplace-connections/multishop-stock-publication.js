"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.advanceShopPublication = advanceShopPublication;
const multishop_stock_plan_1 = require("./multishop-stock-plan");
// FIX: record intent before I/O; a crash or timeout always resumes with an observation.
// No transport retries happen here: the next durable run verifies actual stock first.
async function advanceShopPublication(job, ports) {
    await ports.assertLease();
    const current = await ports.current();
    if (current.revision !== job.revision || (current.mode ?? 'ALLOCATED') !== (job.mode ?? 'ALLOCATED')) {
        const next = { ...job, status: 'STALE' };
        await ports.persist(next);
        return next;
    }
    if (job.status === 'STALE')
        throw new Error('Создайте новый план распределения.');
    const required = [...new Set([...job.destinations, ...Object.keys(job.desired)])];
    const observed = await ports.observe(required);
    // Missing observations are unknown, never an implicit zero for an old cabinet.
    const complete = Object.fromEntries(required.map(id => [id, observed[id] ?? null]));
    const transition = (0, multishop_stock_plan_1.planShopTransition)(current.budget, complete, job.desired, current.mode ?? 'ALLOCATED');
    const next = { ...job, destinations: required, status: transition.phase, attempts: job.attempts + 1 };
    await ports.persist(next);
    for (const item of transition.writes) {
        await ports.assertLease();
        const fresh = await ports.current();
        if (fresh.revision !== job.revision || fresh.budget !== current.budget || (fresh.mode ?? 'ALLOCATED') !== (job.mode ?? 'ALLOCATED')) {
            const stale = { ...next, status: 'STALE' };
            await ports.persist(stale);
            return stale;
        }
        // Never mark ACK as success; even a successful write needs a later read-back.
        await ports.write(item.destination, item.amount);
    }
    return next;
}
