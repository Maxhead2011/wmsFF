"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OzonLinkImportService = void 0;
exports.ozonLinkIds = ozonLinkIds;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const XLSX = require("xlsx");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const ozon_fbo_import_service_1 = require("./ozon-fbo-import.service");
const ozon_assembly_supply_service_1 = require("./ozon-assembly-supply.service");
const ozon_supply_policy_1 = require("./ozon-supply-policy");
// FIX: only exact seller order URLs are accepted; input never becomes a fetch URL.
function ozonLinkIds(links) {
    if (typeof links !== 'string' || links.length > 5000)
        throw new common_1.BadRequestException('Вставьте ссылки Ozon.');
    const values = links.trim().split(/\s+/).filter(Boolean);
    if (!values.length || values.length > 10)
        throw new common_1.BadRequestException('Укажите от 1 до 10 ссылок.');
    const ids = values.map(v => { const id = v.match(/^https:\/\/seller\.ozon\.ru\/app\/supply\/orders\/(\d+)(?:[?#].*)?$/)?.[1]; if (!id || !Number.isSafeInteger(Number(id)))
        throw new common_1.BadRequestException('Нужна ссылка вида https://seller.ozon.ru/app/supply/orders/123.'); return id; });
    return [...new Set(ids)].sort();
}
let OzonLinkImportService = class OzonLinkImportService {
    db;
    scopes;
    importer;
    supply;
    constructor(db, scopes, importer, supply) {
        this.db = db;
        this.scopes = scopes;
        this.importer = importer;
        this.supply = supply;
    }
    // FIX: cabinet users need no internal active branch; use the file-import resolver.
    async access(clientId, user, warehouseId) {
        return this.importer.resolveWarehouse(clientId, user, 'write', warehouseId);
    }
    async connections(clientId, user) {
        const choices = await this.importer.warehouses(clientId, user);
        if (!choices.length)
            throw new common_1.BadRequestException('У клиента нет активного филиала.');
        return this.db.clientMarketplaceConnection.findMany({ where: { clientId, marketplace: 'OZON', isActive: true }, select: { id: true, accountName: true, sellerId: true } });
    }
    async existing(tx, keys, clientId, warehouseId) {
        const bindings = await tx.ozonFboOrderBinding.findMany({ where: { externalOrderKey: { in: keys } } });
        const legacy = await tx.ozonFboShipment.findMany({ where: { externalOrderKey: { in: keys } }, select: { requestId: true } });
        const owners = new Set([...bindings, ...legacy].map((v) => v.requestId));
        if (!owners.size)
            return null;
        if (owners.size !== 1)
            throw new common_1.ConflictException('Ссылки уже используются в разных сборках.');
        const request = await tx.clientRequest.findUniqueOrThrow({ where: { id: [...owners][0] } }), shipment = await tx.ozonFboShipment.findUnique({ where: { requestId: request.id } });
        if (request.clientId !== clientId || request.warehouseId !== warehouseId)
            throw new common_1.ConflictException('Поставка уже используется в другой сборке или филиале.');
        if (!shipment?.integration)
            throw new common_1.ConflictException('Существующая привязка требует сверки.');
        const actual = (0, ozon_supply_policy_1.supplyOrders)(shipment.integration).map((o) => o.orderId).sort(), wanted = keys.map(k => k.split(':').pop()).sort();
        if (JSON.stringify(actual) !== JSON.stringify(wanted))
            throw new common_1.ConflictException('Часть ссылок уже привязана. Откройте существующую сборку.');
        return { id: request.id, number: request.number };
    }
    async prepare(body, user) {
        const warehouseId = await this.access(body?.clientId, user, body?.warehouseId), ids = ozonLinkIds(body.links);
        if (typeof body.connectionId !== 'string')
            throw new common_1.BadRequestException('Выберите кабинет Ozon.');
        const c = await this.db.clientMarketplaceConnection.findFirst({ where: { id: body.connectionId, clientId: body.clientId, marketplace: 'OZON', isActive: true } });
        if (!c?.apiKey || !c.sellerId)
            throw new common_1.BadRequestException('Кабинет Ozon не настроен для клиента.');
        if (await this.db.ozonFboPlan.findFirst({ where: { connectionId: c.id, ozonOrderId: { in: ids } } }))
            throw new common_1.ConflictException('Поставка уже используется в прежнем плане Ozon.');
        const snapshots = [];
        for (const id of ids)
            snapshots.push(await this.supply.snapshot(c, id));
        if (snapshots.some(s => !['DATA_FILLING', 'READY_TO_SUPPLY'].includes(s.state)))
            throw new common_1.ConflictException('Для сборки нужна действующая поставка в статусе заполнения данных или готовности к отгрузке.');
        if (new Set(snapshots.map(s => s.place)).size !== 1 || new Set(snapshots.map(s => s.date)).size !== 1 || !snapshots[0].place || !Number.isFinite(Date.parse(snapshots[0].date)))
            throw new common_1.ConflictException('В одной сборке должны совпадать точка сдачи и время отгрузки.');
        const integration = (0, ozon_supply_policy_1.mergeSupplyOrders)(snapshots[0], snapshots.flatMap(ozon_supply_policy_1.supplyOrders)), rows = [['Направление / склад назначения Ozon', 'ШК', 'Поставка, шт', 'Артикул']];
        integration.mapping = {};
        for (const order of (0, ozon_supply_policy_1.supplyOrders)(integration))
            for (const s of order.supplies) {
                const duplicates = integration.supplies.filter(x => x.name === s.name).length > 1, name = duplicates ? `${s.name} · ${order.orderNumber} / ${s.id}` : s.name;
                integration.mapping[name] = s.id;
                if (!s.items.length)
                    throw new common_1.BadRequestException('Ozon вернул пустое направление.');
                for (const i of s.items)
                    rows.push([name, i.barcode, i.quantity, i.offerId]);
            }
        const book = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(book, XLSX.utils.aoa_to_sheet(rows), 'Поставка');
        const file = { buffer: XLSX.write(book, { type: 'buffer', bookType: 'xlsx' }), originalname: `Ozon-${ids.join('-')}.xlsx`, mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
        const dto = { clientId: body.clientId, warehouseId, destinationCity: integration.place, desiredDate: integration.date, title: `ФБО Ozon · ${snapshots.map(s => s.orderNumber).join(', ')}` };
        const p = await this.importer.preview(file, dto, user);
        if ((0, ozon_supply_policy_1.supplyDifferences)(p.directions, integration).length)
            throw new common_1.ConflictException('Не удалось однозначно сопоставить товары Ozon.');
        const keys = ids.map(id => `${c.sellerId}:${id}`).sort();
        const previewHash = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([body.clientId, warehouseId, c.id, (0, ozon_supply_policy_1.supplyOrders)(integration).map(({ checkedAt, ...o }) => o), p.directions])).digest('hex');
        p.importKey = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(['ozon-links', body.clientId, warehouseId, keys])).digest('hex');
        return { p, file, dto, integration, keys, previewHash, warehouseId };
    }
    async preview(body, user) { const x = await this.prepare(body, user); return { previewHash: x.previewHash, totalQuantity: x.p.totalQuantity, directions: x.p.directions, items: x.p.items, place: x.integration.place, date: x.integration.date, orders: (0, ozon_supply_policy_1.supplyOrders)(x.integration).map(o => ({ orderId: o.orderId, orderNumber: o.orderNumber, state: o.state })), existingRequest: await this.existing(this.db, x.keys, body.clientId, x.warehouseId) }; }
    async commit(body, user) {
        const x = await this.prepare(body, user);
        if (!body.previewHash || body.previewHash !== x.previewHash)
            throw new common_1.ConflictException('Состав Ozon изменился. Получите состав заново и проверьте его.');
        for (let attempt = 0;; attempt++) {
            try {
                return await this.db.$transaction(async (tx) => {
                    for (const key of x.keys)
                        await tx.$queryRaw `SELECT pg_advisory_xact_lock(hashtextextended(${key},0))::text`;
                    const existing = await this.existing(tx, x.keys, body.clientId, x.warehouseId);
                    if (existing)
                        return { request: existing, existing: true };
                    const made = await this.importer.createPrepared(tx, x.p, x.file, x.dto, user);
                    if (made.existing)
                        throw new common_1.ConflictException('Сборка уже существует. Требуется сверка привязки.');
                    await tx.ozonFboShipment.update({ where: { requestId: made.request.id }, data: { integration: x.integration, externalOrderKey: x.keys[0] } });
                    await tx.ozonFboOrderBinding.createMany({ data: x.keys.map(externalOrderKey => ({ externalOrderKey, requestId: made.request.id, orderId: externalOrderKey.split(':').pop() })) });
                    await tx.clientRequest.update({ where: { id: made.request.id }, data: { comment: `Состав получен из Ozon: ${(0, ozon_supply_policy_1.supplyOrders)(x.integration).map(o => o.orderNumber).join(', ')}. ${x.p.totalQuantity} шт.` } });
                    await tx.auditLog.create({ data: { userId: user.id, action: 'OZON_ASSEMBLY_CREATED_FROM_LINKS', entity: 'ClientRequest', entityId: made.request.id, payload: { orderIds: (0, ozon_supply_policy_1.supplyOrders)(x.integration).map(o => o.orderId), previewHash: x.previewHash, quantity: x.p.totalQuantity } } });
                    return { request: made.request, existing: false };
                }, { isolationLevel: 'Serializable', timeout: 30000 });
            }
            catch (e) {
                if (attempt >= 2 || !['P2034', 'P2002'].includes(e?.code))
                    throw e;
            }
        }
    }
};
exports.OzonLinkImportService = OzonLinkImportService;
exports.OzonLinkImportService = OzonLinkImportService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof ozon_fbo_import_service_1.OzonFboImportService !== "undefined" && ozon_fbo_import_service_1.OzonFboImportService) === "function" ? _c : Object, typeof (_d = typeof ozon_assembly_supply_service_1.OzonAssemblySupplyService !== "undefined" && ozon_assembly_supply_service_1.OzonAssemblySupplyService) === "function" ? _d : Object])
], OzonLinkImportService);
