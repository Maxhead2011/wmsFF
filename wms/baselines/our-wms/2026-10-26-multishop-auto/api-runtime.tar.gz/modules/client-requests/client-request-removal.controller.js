"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestRemovalController = exports.RemoveClientRequestDto = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const client_request_removal_service_1 = require("./client-request-removal.service");
class RemoveClientRequestDto {
    reason;
    number;
    revision;
    confirmed;
}
exports.RemoveClientRequestDto = RemoveClientRequestDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(5, 2000),
    __metadata("design:type", String)
], RemoveClientRequestDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], RemoveClientRequestDto.prototype, "number", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(64, 64),
    __metadata("design:type", String)
], RemoveClientRequestDto.prototype, "revision", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], RemoveClientRequestDto.prototype, "confirmed", void 0);
let ClientRequestRemovalController = class ClientRequestRemovalController {
    service;
    constructor(service) {
        this.service = service;
    }
    capability(user) { return this.service.capability(user); }
    preview(id, user) { return this.service.preview(id, user); }
    remove(id, body, user) { return this.service.remove(id, body, user); }
};
exports.ClientRequestRemovalController = ClientRequestRemovalController;
__decorate([
    (0, common_1.Get)('capability'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ClientRequestRemovalController.prototype, "capability", null);
__decorate([
    (0, common_1.Get)(':id/preview'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestRemovalController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, RemoveClientRequestDto, Object]),
    __metadata("design:returntype", void 0)
], ClientRequestRemovalController.prototype, "remove", null);
exports.ClientRequestRemovalController = ClientRequestRemovalController = __decorate([
    (0, common_1.Controller)('client-request-removal'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write'),
    __metadata("design:paramtypes", [typeof (_a = typeof client_request_removal_service_1.ClientRequestRemovalService !== "undefined" && client_request_removal_service_1.ClientRequestRemovalService) === "function" ? _a : Object])
], ClientRequestRemovalController);
