"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestRemovalEnabled = exports.REMOVAL_ACTION = exports.ADMIN_REMOVED = void 0;
exports.canRemoveRequests = canRemoveRequests;
exports.removalBlockers = removalBlockers;
exports.assertRequestNotRemoved = assertRequestNotRemoved;
exports.lockRequestNotRemoved = lockRequestNotRemoved;
exports.lockOrderLinks = lockOrderLinks;
exports.assertOrdersNotRemoved = assertOrdersNotRemoved;
exports.withoutRemovedOrders = withoutRemovedOrders;
const common_1 = require("@nestjs/common");
exports.ADMIN_REMOVED = 'ADMIN_REMOVED';
exports.REMOVAL_ACTION = 'CLIENT_REQUEST_ADMIN_REMOVED';
const requestRemovalEnabled = () => process.env.WMS_REQUEST_REMOVAL_ENABLED === 'true';
exports.requestRemovalEnabled = requestRemovalEnabled;
// FIX: role checks are independent from broad client-request write permissions.
function canRemoveRequests(user, enabled = (0, exports.requestRemovalEnabled)()) {
    return enabled && !user.isDemo && !!user.roleCodes?.some(r => r === 'ADMIN' || r === 'OWNER');
}
function removalBlockers(r) {
    const reasons = [];
    if (r.type !== 'OUTBOUND')
        reasons.push('Удаление доступно только для отгрузочных заявок ФБО/ФБС.');
    if (!['SUBMITTED', 'IN_REVIEW', 'APPROVED', 'IN_WORK'].includes(r.status))
        reasons.push('Заявка уже закрыта или упакована.');
    if (r.physical)
        reasons.push('Есть фактический отбор, упаковка или печать. Сначала выполните возврат товара через исправление этапов.');
    if (r.activeWaves)
        reasons.push('Заявка входит в активную волну отбора. Сначала отмените волну.');
    if (r.deliveries)
        reasons.push('Есть связанная заявка на доставку. Сначала завершите её разбор.');
    return reasons;
}
async function assertRequestNotRemoved(db, id) {
    if (!(0, exports.requestRemovalEnabled)())
        return;
    if (await db.auditLog.findFirst({ where: { action: exports.REMOVAL_ACTION, entity: 'ClientRequest', entityId: id }, select: { id: true } }))
        throw new common_1.ConflictException('Заявка удалена администратором. История доступна в архиве.');
}
async function lockRequestNotRemoved(db, id) {
    if (!(0, exports.requestRemovalEnabled)())
        return;
    await db.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${id} FOR UPDATE`;
    await assertRequestNotRemoved(db, id);
}
async function lockOrderLinks(db, clientId, orders) {
    if (!(0, exports.requestRemovalEnabled)())
        return;
    for (const o of [...orders].sort((a, b) => `${a.connectionId}:${a.id}`.localeCompare(`${b.connectionId}:${b.id}`)))
        await db.$queryRaw `SELECT id FROM "FbsOrderRequestLink" WHERE "clientId"=${clientId} AND "connectionId"=${o.connectionId} AND "orderId"=${o.id} FOR UPDATE`;
}
// FIX: cancellation must survive scheduler runs and incoming marketplace snapshots.
async function assertOrdersNotRemoved(db, clientId, orders) {
    if (!(0, exports.requestRemovalEnabled)() || !orders.length)
        return;
    const blocked = await db.fbsOrderRequestLink.findMany({ where: { clientId, syncStatus: exports.ADMIN_REMOVED, OR: orders.map(o => ({ connectionId: o.connectionId, orderId: o.id })) }, select: { orderId: true } });
    if (blocked.length)
        throw new common_1.ConflictException(`Сборка этих заказов удалена администратором: ${blocked.map(o => o.orderId).join(', ')}. Заказы на маркетплейсе не отменены; требуется отдельное решение.`);
}
async function withoutRemovedOrders(db, clientId, orders) {
    if (!(0, exports.requestRemovalEnabled)() || !orders.length)
        return orders;
    const blocked = await db.fbsOrderRequestLink.findMany({ where: { clientId, syncStatus: exports.ADMIN_REMOVED, connectionId: { in: [...new Set(orders.map(o => o.connectionId))] } }, select: { connectionId: true, orderId: true } });
    const keys = new Set(blocked.map(o => `${o.connectionId}:${o.orderId}`));
    return orders.filter(o => !keys.has(`${o.connectionId}:${o.id}`));
}
