"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientRequestRemovalService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const request_removal_policy_1 = require("./request-removal-policy");
let ClientRequestRemovalService = class ClientRequestRemovalService {
    db;
    scopes;
    constructor(db, scopes) {
        this.db = db;
        this.scopes = scopes;
    }
    capability(user) { return { enabled: (0, request_removal_policy_1.canRemoveRequests)(user) }; }
    authorize(user) { if (!(0, request_removal_policy_1.canRemoveRequests)(user))
        throw new common_1.ForbiddenException('Удаление доступно администратору и собственнику.'); }
    async inspect(tx, id, user) {
        const r = await tx.clientRequest.findUnique({ where: { id }, include: { items: true, fbsOrderLinks: true, ozonShipment: true, _count: { select: { deliveryRequests: true } } } });
        if (!r)
            throw new common_1.NotFoundException('Заявка не найдена.');
        this.scopes.requireClientAccess(user, r.clientId, 'write');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, r, 'write');
        const tasks = await tx.fbsTsdAssembly.findMany({ where: { requestId: id } });
        const units = await tx.fboAssemblyUnit.count({ where: { requestId: id, state: { not: 'RETURNED' } } });
        const packages = await tx.clientRequestPackage.count({ where: { requestId: id, items: { some: { quantity: { gt: 0 } } } } });
        const movements = await tx.stockMovement.count({ where: { sourceDocument: id, type: { in: ['PICK', 'PACK', 'SHIP'] } } });
        let scans = await tx.tsdOperation.count({ where: { status: 'ACCEPTED', payload: { path: ['requestId'], equals: id }, operationType: { in: ['move_scan', 'assembly_stage', 'box_search_scan'] } } });
        if(scans&&!units&&!packages&&!movements&&!r.fbsOrderLinks.length&&await require("./request-removal-return-proof").hasVerifiedFboReturn(tx,r))scans=0;
        const printed = await tx.fbsPrintJob.count({ where: { requestId: id } });
        const activeWaves = await tx.pickWaveRequest.count({ where: { requestId: id, wave: { status: { notIn: ['CANCELLED', 'DONE'] } } } });
        const physical = units + packages + movements + scans + printed + tasks.filter(t => t.boxId || t.barcode || t.sourceBarcode || t.kiz || t.relabelConfirmedAt || t.completedAt || t.cargoPackedAt || t.marketplaceSubmittedAt || t.workerUserId || t.startedAt || t.sourceBoxPending || !['WAITING_STOCK', 'RESERVED', 'RELEASED', 'CANCELLED'].includes(t.status)).length;
        const blockers = (0, request_removal_policy_1.removalBlockers)({ ...r, physical, activeWaves, deliveries: r._count.deliveryRequests });
        const externalOrders = r.fbsOrderLinks.map(l => ({ marketplace: l.marketplace, orderId: l.orderId, supplyId: l.lastSupplyId }));
        const snapshot = { id: r.id, number: r.number, title: r.title, status: r.status, clientId: r.clientId, warehouseId: r.warehouseId, updatedAt: r.updatedAt.toISOString(), quantity: r.items.reduce((n, i) => n + i.quantity, 0), externalOrders, ozonLinked: !!r.ozonShipment, blockers };
        const revision = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify({ snapshot, items: r.items, tasks, links: r.fbsOrderLinks })).digest('hex');
        return { r, tasks, preview: { ...snapshot, revision, allowed: !blockers.length } };
    }
    async preview(id, user) { this.authorize(user); return this.db.$transaction(async (tx) => (await this.inspect(tx, id, user)).preview, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.RepeatableRead, timeout: 15000 }); }
    // FIX: all guards are repeated under the request row lock and one serializable transaction.
    async remove(id, input, user) {
        this.authorize(user);
        const reason = typeof input.reason === 'string' ? input.reason.trim() : '';
        if (reason.length < 5 || reason.length > 2000 || input.confirmed !== true || !Number.isInteger(input.number) || !input.revision)
            throw new common_1.BadRequestException('Укажите причину (5–2000 символов), номер заявки и подтвердите действие.');
        try {
            return await this.db.$transaction(async (tx) => {
                await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${id} FOR UPDATE`;
                const { r, tasks, preview } = await this.inspect(tx, id, user);
                const previous = await tx.auditLog.findFirst({ where: { action: request_removal_policy_1.REMOVAL_ACTION, entity: 'ClientRequest', entityId: id }, select: { id: true } });
                if (previous && r.status === 'CANCELLED')
                    return { id, number: r.number, removed: true, alreadyRemoved: true };
                if (input.number !== r.number)
                    throw new common_1.BadRequestException('Номер подтверждения не совпадает с заявкой.');
                if (!preview.allowed)
                    throw new common_1.ConflictException(preview.blockers.join(' '));
                if (preview.revision !== input.revision)
                    throw new common_1.ConflictException('Заявка изменилась. Повторите предпросмотр удаления.');
                // Same per-order locks as manual and scheduled FBS creation, without waiting on another transaction.
                for (const key of [...new Set(r.fbsOrderLinks.map(l => `fbs-assembly:${r.clientId}:${l.connectionId}:${l.orderId}`))].sort()) {
                    const rows = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${key})) AS locked`;
                    if (!rows[0]?.locked)
                        throw new common_1.ConflictException('Заказы обрабатываются другой операцией. Повторите позже.');
                }
                await tx.clientRequest.update({ where: { id }, data: { status: 'CANCELLED', assignedToUserId: null, managerComment: [r.managerComment, `Удалена администратором: ${reason}`].filter(Boolean).join('\n') } });
                await tx.fbsOrderRequestLink.updateMany({ where: { requestId: id }, data: { syncStatus: request_removal_policy_1.ADMIN_REMOVED, syncIssue: reason } });
                // Preserve task ownership as a tombstone: no stock/KIZ writes and no new AUTO task for this order.
                await tx.fbsTsdAssembly.updateMany({ where: { requestId: id }, data: { status: 'CANCELLED', reservedBoxId: null, reservedBoxCode: null, reservedAt: null } });
                await tx.clientRequestEvent.create({ data: { requestId: id, clientId: r.clientId, eventType: 'STATUS_CHANGED', title: 'Заявка удалена администратором', body: reason, statusFrom: r.status, statusTo: 'CANCELLED', createdByUserId: user.id } });
                await tx.auditLog.create({ data: { userId: user.id, action: request_removal_policy_1.REMOVAL_ACTION, entity: 'ClientRequest', entityId: id, payload: { reason, before: JSON.parse(JSON.stringify({ request: r, tasks })), preview, externalCancellation: false } } });
                return { id, number: r.number, removed: true, alreadyRemoved: false };
            }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.Serializable, timeout: 20000 });
        }
        catch (e) {
            if (e instanceof client_1.Prisma.PrismaClientKnownRequestError && e.code === 'P2034')
                throw new common_1.ConflictException('Заявка изменилась во время удаления. Обновите предпросмотр.');
            throw e;
        }
    }
};
exports.ClientRequestRemovalService = ClientRequestRemovalService;
exports.ClientRequestRemovalService = ClientRequestRemovalService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], ClientRequestRemovalService);
