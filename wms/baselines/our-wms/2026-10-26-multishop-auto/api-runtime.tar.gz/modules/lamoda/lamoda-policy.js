"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.text = text;
exports.productSnapshot = productSnapshot;
exports.documentSnapshot = documentSnapshot;
exports.parseLamodaPlan = parseLamodaPlan;
exports.planHash = planHash;
exports.templateWorkbook = templateWorkbook;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const XLSX = __importStar(require("xlsx"));
const lamoda_client_1 = require("./lamoda-client");
function text(value, label, max = 200) {
    if (typeof value !== 'string' || !value.trim() || value.trim().length > max || /[\u0000-\u001f]/.test(value)) {
        throw new common_1.BadRequestException(`Заполните поле «${label}» (до ${max} символов).`);
    }
    return value.trim();
}
function optional(value) {
    return typeof value === 'string' && value.length <= 2000 ? value : null;
}
function productSnapshot(row) {
    if (typeof row.sku !== 'string' || !row.sku.trim())
        throw new lamoda_client_1.LamodaApiError('CATALOG_SKU_MISSING');
    return {
        remoteSku: row.sku, externalSku: optional(row.externalSku), barcode: optional(row.barcode),
        size: optional(row.externalSize), name: optional(row.name) ?? row.sku,
    };
}
// FIX: explicit allowlist keeps recipient data and arbitrary API payloads out of storage.
function documentSnapshot(kind, row) {
    const id = kind === 'FBS_SHIPMENTS' ? row.shipmentId : row.id;
    if (typeof id !== 'string' || !id)
        throw new lamoda_client_1.LamodaApiError('DOCUMENT_ID_MISSING');
    const payload = {};
    for (const key of ['createdAt', 'updatedAt', 'plannedDate', 'returnDate', 'sku', 'externalSku', 'itemId', 'boxId', 'baseWarehouse']) {
        payload[key] = optional(row[key]);
    }
    const delivery = row.deliveryMethod;
    if (delivery && typeof delivery === 'object' && !Array.isArray(delivery))
        payload.cutOff = optional(delivery.cutOff);
    for (const key of ['palletsQuantity', 'packQuantity', 'itemsQuantity']) {
        if (Number.isSafeInteger(row[key]) && Number(row[key]) >= 0)
            payload[key] = Number(row[key]);
    }
    const stats = row.statistics;
    if (stats && typeof stats === 'object' && !Array.isArray(stats)) {
        for (const key of ['plannedItems', 'acceptedItems', 'receivedItems', 'missingItems', 'surplusItems', 'damagedItems']) {
            const value = stats[key];
            if (Number.isSafeInteger(value) && Number(value) >= 0)
                payload[key] = Number(value);
        }
    }
    return { remoteId: id, number: optional(row.orderId) ?? optional(row.externalShipmentId) ?? id, status: optional(row.status) ?? 'UNKNOWN', payload };
}
function parseLamodaPlan(buffer) {
    let book;
    try {
        book = XLSX.read(buffer, { type: 'buffer', cellFormula: true, sheetRows: 1002 });
    }
    catch {
        throw new common_1.BadRequestException('Не удалось прочитать Excel. Используйте шаблон Lamoda.');
    }
    const sheet = book.Sheets['Поставка'] ?? book.Sheets[book.SheetNames[0]];
    if (!sheet)
        throw new common_1.BadRequestException('В файле нет листа поставки.');
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: true });
    const headers = (rows[0] ?? []).map(value => String(value).trim());
    const bi = headers.indexOf('ШК'), qi = headers.indexOf('Количество'), ai = headers.indexOf('Артикул'), di = headers.indexOf('Направление');
    if (bi < 0 || qi < 0 || headers.filter(h => h === 'ШК').length !== 1 || headers.filter(h => h === 'Количество').length !== 1) {
        throw new common_1.BadRequestException('Нужны колонки «ШК» и «Количество».');
    }
    const lines = [];
    for (let index = 1; index < rows.length; index++) {
        const row = rows[index];
        if (row.every(v => v === '' || v == null))
            continue;
        for (const col of [bi, qi, ai, di].filter(v => v >= 0)) {
            if (sheet[XLSX.utils.encode_cell({ r: index, c: col })]?.f)
                throw new common_1.BadRequestException(`Строка ${index + 1}: замените формулы значениями.`);
        }
        const rawBarcode = row[bi];
        // Numeric Excel cells cannot preserve leading zeroes: reject instead of guessing.
        if (typeof rawBarcode !== 'string' || !/^\d{8,14}$/.test(rawBarcode.trim()))
            throw new common_1.BadRequestException(`Строка ${index + 1}: ШК должен быть текстом из 8–14 цифр.`);
        const quantity = Number(row[qi]);
        if (!Number.isSafeInteger(quantity) || quantity <= 0 || quantity > 100_000)
            throw new common_1.BadRequestException(`Строка ${index + 1}: количество должно быть целым числом от 1 до 100000.`);
        lines.push({ barcode: rawBarcode.trim(), quantity, article: ai < 0 ? '' : String(row[ai]).trim().slice(0, 200), destination: di < 0 ? '' : String(row[di]).trim().slice(0, 200) });
    }
    if (!lines.length || lines.length > 1000 || rows.length >= 1002)
        throw new common_1.BadRequestException('В файле должно быть от 1 до 1000 строк.');
    return lines;
}
function planHash(lines, title, remoteShipmentId) {
    return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([title, remoteShipmentId, lines])).digest('hex');
}
function templateWorkbook() {
    const sheet = XLSX.utils.aoa_to_sheet([['ШК', 'Количество', 'Артикул', 'Направление']]);
    for (let r = 1; r <= 1000; r++)
        sheet[XLSX.utils.encode_cell({ r, c: 0 })] = { t: 's', v: '', z: '@' };
    sheet['!ref'] = 'A1:D1001';
    sheet['!cols'] = [{ wch: 22 }, { wch: 16 }, { wch: 25 }, { wch: 35 }];
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, 'Поставка');
    XLSX.utils.book_append_sheet(book, XLSX.utils.aoa_to_sheet([
        ['Как заполнить'], ['ШК — текст из 8–14 цифр. Сохраните начальные нули.'],
        ['Количество — целое положительное число.'], ['Артикул необязателен. Направление — склад назначения Lamoda.'],
        ['Одна строка — один товар для одного направления.'], ['Импорт создаёт черновик и не резервирует товар.'],
    ]), 'Инструкция');
    return XLSX.write(book, { type: 'buffer', bookType: 'xlsx' });
}
