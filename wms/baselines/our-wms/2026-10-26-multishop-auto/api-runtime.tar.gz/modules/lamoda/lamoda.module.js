"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const client_requests_module_1 = require("../client-requests/client-requests.module");
const lamoda_controller_1 = require("./lamoda.controller");
const lamoda_service_1 = require("./lamoda.service");
let LamodaModule = class LamodaModule {
};
exports.LamodaModule = LamodaModule;
exports.LamodaModule = LamodaModule = __decorate([
    (0, common_1.Module)({ imports: [auth_module_1.AuthModule, client_requests_module_1.ClientRequestsModule], controllers: [lamoda_controller_1.LamodaController], providers: [lamoda_service_1.LamodaService] })
], LamodaModule);
