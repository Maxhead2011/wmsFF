"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaClient = exports.lamodaResources = exports.LamodaApiError = void 0;
exports.sealSecret = sealSecret;
exports.openSecret = openSecret;
exports.record = record;
const node_crypto_1 = require("node:crypto");
class LamodaApiError extends Error {
    code;
    status;
    constructor(code, status) {
        // FIX: never propagate remote bodies (which can contain credentials/customer data).
        super(`Lamoda: ${code}${status ? ` (${status})` : ''}`);
        this.code = code;
        this.status = status;
    }
}
exports.LamodaApiError = LamodaApiError;
function encryptionKey() {
    const value = process.env.WMS_LAMODA_SECRET_KEY ?? '';
    if (!/^[A-Za-z0-9+/]{43}=$/.test(value))
        throw new LamodaApiError('SECRET_KEY_NOT_CONFIGURED');
    const key = Buffer.from(value, 'base64');
    if (key.length !== 32)
        throw new LamodaApiError('SECRET_KEY_NOT_CONFIGURED');
    return key;
}
function sealSecret(secret, identity) {
    const iv = (0, node_crypto_1.randomBytes)(12);
    const cipher = (0, node_crypto_1.createCipheriv)('aes-256-gcm', encryptionKey(), iv);
    cipher.setAAD(Buffer.from(identity));
    const body = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()]);
    return ['v1', iv.toString('base64'), cipher.getAuthTag().toString('base64'), body.toString('base64')].join('.');
}
function openSecret(encrypted, identity) {
    const key = encryptionKey();
    try {
        const [version, iv, tag, body, extra] = encrypted.split('.');
        if (version !== 'v1' || extra || !iv || !tag || !body)
            throw new Error();
        const decipher = (0, node_crypto_1.createDecipheriv)('aes-256-gcm', key, Buffer.from(iv, 'base64'));
        decipher.setAAD(Buffer.from(identity));
        decipher.setAuthTag(Buffer.from(tag, 'base64'));
        return Buffer.concat([decipher.update(Buffer.from(body, 'base64')), decipher.final()]).toString('utf8');
    }
    catch {
        throw new LamodaApiError('SECRET_DECRYPTION_FAILED');
    }
}
const resources = {
    CATALOG: { path: '/nomenclatures', key: 'nomenclatures' },
    ORDERS: { path: '/orders', key: 'orders' },
    FBO_SHIPMENTS: { path: '/fbo/shipments', key: 'shipments' },
    FBS_SHIPMENTS: { path: '/fbs/shipments', key: 'items' },
    RETURNS: { path: '/fbs/return-items', key: 'data' },
};
exports.lamodaResources = Object.keys(resources);
const base = 'https://public-api-seller.lamoda.ru/api/v2';
// FIX: this adapter only reads business data. No generic method/body proxy or write switch.
class LamodaClient {
    http;
    now;
    tokens = new Map();
    pending = new Map();
    constructor(http = fetch, now = Date.now) {
        this.http = http;
        this.now = now;
    }
    key(c) {
        return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([c.oauthClientId, c.secret, c.sellerId])).digest('hex');
    }
    async json(url, init) {
        let response;
        try {
            response = await this.http(url, { ...init, redirect: 'error', signal: AbortSignal.timeout(20_000) });
        }
        catch {
            throw new LamodaApiError('TRANSPORT_ERROR');
        }
        if (!response.ok)
            throw new LamodaApiError('HTTP_ERROR', response.status);
        const raw = await response.text().catch(() => { throw new LamodaApiError('TRANSPORT_ERROR'); });
        if (raw.length > 10_000_000)
            throw new LamodaApiError('RESPONSE_TOO_LARGE');
        try {
            return JSON.parse(raw);
        }
        catch {
            throw new LamodaApiError('INVALID_JSON');
        }
    }
    async token(c) {
        const key = this.key(c), cached = this.tokens.get(key);
        if (cached && cached.until > this.now())
            return cached;
        const pending = this.pending.get(key);
        if (pending)
            return pending;
        const task = (async () => {
            const raw = record(await this.json(`${base}/auth-token`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ grant_type: 'client_credentials', client_id: c.oauthClientId, client_secret: c.secret }),
            }));
            if (typeof raw.access_token !== 'string' || !raw.access_token || raw.token_type?.toString().toLowerCase() !== 'bearer' ||
                !Number.isSafeInteger(raw.expires_in) || Number(raw.expires_in) <= 0)
                throw new LamodaApiError('INVALID_TOKEN_RESPONSE');
            const lifetime = Number(raw.expires_in) * 1000;
            const token = { value: raw.access_token, until: this.now() + lifetime - Math.min(30_000, lifetime / 10) };
            // Bound process-local memory. Tokens are never stored in DB/logs or returned to the UI.
            if (this.tokens.size >= 100)
                this.tokens.delete(this.tokens.keys().next().value);
            this.tokens.set(key, token);
            return token;
        })();
        this.pending.set(key, task);
        try {
            return await task;
        }
        finally {
            this.pending.delete(key);
        }
    }
    async get(c, path, params) {
        const url = new URL(`${base}${path}`);
        Object.entries({ ...params, sellerId: c.sellerId }).forEach(([key, value]) => url.searchParams.set(key, value));
        for (let attempt = 0;; attempt++) {
            const token = await this.token(c);
            try {
                return record(await this.json(url.toString(), { headers: { Authorization: `Bearer ${token.value}` } }));
            }
            catch (error) {
                if (attempt === 0 && error instanceof LamodaApiError && error.status === 401) {
                    if (this.tokens.get(this.key(c)) === token)
                        this.tokens.delete(this.key(c));
                    continue;
                }
                throw error;
            }
        }
    }
    async check(c) {
        // Verify seller access too, rather than treating OAuth success as a working connection.
        const data = await this.get(c, '/nomenclatures', { page: '1', limit: '1' });
        if (!Array.isArray(data.nomenclatures) || record(data.meta).page !== 1)
            throw new LamodaApiError('INVALID_PAGE');
        return data;
    }
    async collection(c, kind, params = {}) {
        const resource = resources[kind];
        if (!resource)
            throw new LamodaApiError('UNKNOWN_RESOURCE');
        const result = [], started = this.now();
        for (let page = 1; page <= 100; page++) {
            if (this.now() - started > 120_000)
                throw new LamodaApiError('SYNC_TIME_LIMIT');
            const data = await this.get(c, resource.path, { ...params, page: String(page), limit: '100' });
            const items = data[resource.key], meta = record(data.meta);
            if (!Array.isArray(items) || items.length > 100 || meta.page !== page || !Number.isSafeInteger(meta.totalPages) ||
                Number(meta.totalPages) < 0 || (Number(meta.totalPages) === 0 && items.length !== 0) ||
                (Number(meta.totalPages) > page && !items.length))
                throw new LamodaApiError('INVALID_PAGE');
            result.push(...items.map(record));
            if (page >= Number(meta.totalPages))
                return result;
        }
        throw new LamodaApiError('SYNC_PAGE_LIMIT');
    }
}
exports.LamodaClient = LamodaClient;
function record(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new LamodaApiError('INVALID_OBJECT');
    return value;
}
