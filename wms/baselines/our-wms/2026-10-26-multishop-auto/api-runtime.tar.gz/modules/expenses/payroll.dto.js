"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PayrollStatusBatchDto = exports.PayrollBatchEntryDto = exports.PayrollIdentityDto = exports.PayrollStatusDto = exports.PayrollHandlingCancelDto = exports.PayrollHandlingConfirmDto = exports.PayrollHandlingDto = exports.PayrollHistoryEditDto = exports.PayrollShiftDto = exports.PayrollConditionDto = exports.PayrollEmployeeDto = exports.PayrollInitialConditionDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
// FIX: initial rates are validated and committed with the new employee.
class PayrollInitialConditionDto {
    kind;
    rateKopecks;
    startsAt;
}
exports.PayrollInitialConditionDto = PayrollInitialConditionDto;
__decorate([
    (0, class_validator_1.IsIn)(['HOURLY', 'PIECE', 'PALLET']),
    __metadata("design:type", String)
], PayrollInitialConditionDto.prototype, "kind", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollInitialConditionDto.prototype, "rateKopecks", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollInitialConditionDto.prototype, "startsAt", void 0);
class PayrollEmployeeDto {
    name;
    warehouseId;
    userId;
    picker;
    loader;
    isActive;
    // FIX: incomplete historical requisites must not imply a cash payment agreement.
    paymentMethod;
    paymentPhone;
    paymentBank;
    initialConditions;
}
exports.PayrollEmployeeDto = PayrollEmployeeDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "userId", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollEmployeeDto.prototype, "picker", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollEmployeeDto.prototype, "loader", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollEmployeeDto.prototype, "isActive", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['CASH', 'TRANSFER', 'UNSPECIFIED']),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "paymentMethod", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(32),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "paymentPhone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "paymentBank", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(2),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => PayrollInitialConditionDto),
    __metadata("design:type", Array)
], PayrollEmployeeDto.prototype, "initialConditions", void 0);
class PayrollConditionDto {
    kind;
    rateKopecks;
    startsAt;
    endsAt;
    temporary;
    reason;
}
exports.PayrollConditionDto = PayrollConditionDto;
__decorate([
    (0, class_validator_1.IsIn)(['HOURLY', 'PIECE', 'PALLET']),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "kind", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollConditionDto.prototype, "rateKopecks", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "startsAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "endsAt", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollConditionDto.prototype, "temporary", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "reason", void 0);
class PayrollShiftDto {
    // FIX: only the correction path may move a closed shift to another employee.
    employeeId;
    expectedVersion;
    startsAt;
    endsAt;
    reason;
    // FIX: one override per day; omitted preserves it, null restores automatic lunch.
    lunchMinutes;
}
exports.PayrollShiftDto = PayrollShiftDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollShiftDto.prototype, "employeeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PayrollShiftDto.prototype, "expectedVersion", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollShiftDto.prototype, "startsAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollShiftDto.prototype, "endsAt", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollShiftDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollShiftDto.prototype, "lunchMinutes", void 0);
class PayrollHistoryEditDto {
    startTime;
    endTime;
    lunchMinutes;
    rateKopecks;
    reason;
}
exports.PayrollHistoryEditDto = PayrollHistoryEditDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollHistoryEditDto.prototype, "startTime", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollHistoryEditDto.prototype, "endTime", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollHistoryEditDto.prototype, "lunchMinutes", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollHistoryEditDto.prototype, "rateKopecks", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollHistoryEditDto.prototype, "reason", void 0);
class PayrollHandlingDto {
    expectedState;
    warehouseId;
    startsAt;
    operation;
    palletCount;
    boxCount;
    bagCount;
    rollCount;
    employeeIds;
    reason;
}
exports.PayrollHandlingDto = PayrollHandlingDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(64),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "expectedState", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "startsAt", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['LOAD', 'UNLOAD']),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "operation", void 0);
__decorate([
    (0, class_validator_1.IsNumber)({ maxDecimalPlaces: 4 }),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollHandlingDto.prototype, "palletCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollHandlingDto.prototype, "boxCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollHandlingDto.prototype, "bagCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollHandlingDto.prototype, "rollCount", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], PayrollHandlingDto.prototype, "employeeIds", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "reason", void 0);
// FIX: an explicit operation tariff is separate from the employee's permanent conditions.
class PayrollHandlingConfirmDto {
    rateKopecks;
}
exports.PayrollHandlingConfirmDto = PayrollHandlingConfirmDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollHandlingConfirmDto.prototype, "rateKopecks", void 0);
class PayrollHandlingCancelDto {
    reason;
}
exports.PayrollHandlingCancelDto = PayrollHandlingCancelDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollHandlingCancelDto.prototype, "reason", void 0);
class PayrollStatusDto {
    employeeId;
    dateFrom;
    dateTo;
    keys;
    status;
    comment;
}
exports.PayrollStatusDto = PayrollStatusDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "employeeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "dateFrom", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "dateTo", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], PayrollStatusDto.prototype, "keys", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['UNPAID', 'REVIEW', 'PAID']),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "comment", void 0);
// FIX: bounded explicit selections; the server rechecks amounts before paying.
class PayrollIdentityDto {
    memberIds;
}
exports.PayrollIdentityDto = PayrollIdentityDto;
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMaxSize)(100),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], PayrollIdentityDto.prototype, "memberIds", void 0);
class PayrollBatchEntryDto {
    employeeId;
    keys;
}
exports.PayrollBatchEntryDto = PayrollBatchEntryDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollBatchEntryDto.prototype, "employeeId", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(2000),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], PayrollBatchEntryDto.prototype, "keys", void 0);
class PayrollStatusBatchDto {
    dateFrom;
    dateTo;
    status;
    comment;
    expectedAmountKopecks;
    entries;
}
exports.PayrollStatusBatchDto = PayrollStatusBatchDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusBatchDto.prototype, "dateFrom", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusBatchDto.prototype, "dateTo", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['UNPAID', 'REVIEW', 'PAID']),
    __metadata("design:type", String)
], PayrollStatusBatchDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollStatusBatchDto.prototype, "comment", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollStatusBatchDto.prototype, "expectedAmountKopecks", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayMaxSize)(100),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => PayrollBatchEntryDto),
    __metadata("design:type", Array)
], PayrollStatusBatchDto.prototype, "entries", void 0);
