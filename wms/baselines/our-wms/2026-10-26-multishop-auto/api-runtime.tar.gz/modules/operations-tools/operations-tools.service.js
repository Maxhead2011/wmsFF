"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsToolsService = void 0;
exports.exactRequestNumber = exactRequestNumber;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("../client-requests/client-request-warehouse-scope");
const kiz_physical_identity_1 = require("../../common/kiz-physical-identity");
const receipt_channel_policy_1 = require("../warehouse/receipt-channel-policy");
function exactRequestNumber(q) {
    if (!/^№?0*\d{1,10}$/.test(q))
        return undefined;
    const n = Number(q.replace(/^№/, ''));
    return Number.isSafeInteger(n) && n > 0 && n <= 2147483647 ? n : undefined;
}
let OperationsToolsService = class OperationsToolsService {
    db;
    scopes;
    constructor(db, scopes) {
        this.db = db;
        this.scopes = scopes;
    }
    enabled() { if (process.env.WMS_OPERATIONS_TOOLS_ENABLED !== 'true')
        throw new common_1.NotFoundException(); }
    scope(user, write = false) {
        this.enabled();
        return { clientId: this.scopes.resolveClientFilter(user), ...(0, client_request_warehouse_scope_1.warehouseScopeWhere)(user, write ? 'write' : 'read') };
    }
    async requests(value, user) {
        const q = (value ?? '').trim();
        if (!q || q.length > 128)
            throw new common_1.BadRequestException('Введите номер заявки.');
        const number = exactRequestNumber(q);
        const rows = await this.db.clientRequest.findMany({ where: { ...this.scope(user), OR: [{ id: q }, ...(number === undefined ? [] : [{ number }])] }, take: 21, select: { id: true, number: true, title: true, status: true } });
        return { rows: rows.slice(0, 20).map(r => ({ kind: 'request', id: r.id, label: `№${r.number} · ${r.title}`, detail: r.status })), truncated: rows.length > 20 };
    }
    async readiness(id, user) {
        const r = await this.db.clientRequest.findFirst({ where: { id, ...this.scope(user) }, select: { id: true, number: true, title: true, status: true, clientId: true, warehouseId: true,
                items: { select: { quantity: true } }, fboAssembly: { select: { phase: true } }, ozonShipment: { select: { integration: true } }, _count: { select: { files: true } } } });
        if (!r)
            throw new common_1.NotFoundException('Заявка не найдена.');
        const [units, boxes, charges] = await Promise.all([
            this.db.fboAssemblyUnit.groupBy({ by: ['state'], where: { requestId: id }, _count: true }),
            this.db.fboAssemblyBox.findMany({ where: { requestId: id }, select: { confirmedAt: true, closedAt: true } }),
            user.permissionCodes.includes('billing:read') || user.permissionCodes.includes('system:admin') ? this.db.billingCharge.count({ where: { requestId: id, status: { not: 'CANCELLED' } } }) : Promise.resolve(null),
        ]);
        const needed = r.items.reduce((s, i) => s + i.quantity, 0), picked = units.filter(u => u.state !== 'RETURNED').reduce((s, u) => s + u._count, 0), packed = units.find(u => u.state === 'PACKED')?._count ?? 0;
        const integration = r.ozonShipment?.integration;
        const supplyIds = Array.isArray(integration?.supplies) ? integration.supplies.map((s) => String(s.id)) : [];
        const accepted = supplyIds.length > 0 && supplyIds.every((id) => integration.operations?.[id]?.state === 'SUCCESS');
        const confirmed = boxes.length > 0 && boxes.every(b => b.closedAt && b.confirmedAt);
        const step = (key, label, state, detail) => ({ key, label, state, detail });
        return { id: r.id, number: r.number, title: r.title, status: r.status, observedAt: new Date().toISOString(), steps: [
                step('pick', 'Отбор', r.fboAssembly ? (needed > 0 && picked >= needed ? 'complete' : 'pending') : 'unknown', r.fboAssembly ? `${picked} из ${needed} шт.` : 'Смотрите фактическое выполнение заданий ФБС.'),
                step('pack', 'Упаковка', r.fboAssembly ? (needed > 0 && packed >= needed ? 'complete' : 'pending') : 'unknown', r.fboAssembly ? `${packed} из ${needed} шт.` : 'Проверяется в онлайн-выполнении.'),
                step('confirm', 'Подтверждение коробов', confirmed ? 'complete' : r.fboAssembly ? 'pending' : 'unknown', `${boxes.filter(b => b.confirmedAt && b.closedAt).length} из ${boxes.length} коробов`),
                step('marketplace', 'Грузоместа маркетплейса', r.ozonShipment ? (accepted ? 'complete' : 'pending') : 'unknown', r.ozonShipment ? (accepted ? 'Ozon подтвердил все грузоместа.' : 'Проверьте передачу грузомест Ozon.') : 'Проверьте статус передачи в разделе маркетплейса.'),
                step('documents', 'Документы', 'unknown', confirmed ? 'Можно сформировать файлы по подтверждённым коробам.' : `В заявке ${r._count.files} файлов; готовность отгрузочных документов не подтверждена.`),
                step('billing', 'Начисления', charges === null ? 'unknown' : charges > 0 ? 'complete' : 'pending', charges === null ? 'Нет доступа к начислениям.' : charges > 0 ? `Есть ${charges} начислений; это не подтверждение оплаты.` : 'Начисления ещё не найдены.'),
            ] };
    }
    async search(value, user) {
        const q = (value ?? '').trim();
        if (!q || q.length > 512)
            throw new common_1.BadRequestException('Введите точный номер, ШК или КИЗ (до 512 символов).');
        const scope = this.scope(user), number = exactRequestNumber(q), identity = (0, kiz_physical_identity_1.physicalKizIdentity)(q);
        // FIX: authorization filters precede limits and exact matching. IDs remain strings.
        const [requests, boxes, pallets, balances, marks] = await Promise.all([
            this.db.clientRequest.findMany({ where: { ...scope, OR: [{ id: q }, ...(number === undefined ? [] : [{ number }])] }, take: 21, select: { id: true, number: true, title: true, status: true } }),
            this.db.box.findMany({ where: { ...scope, code: q }, take: 21, select: { id: true, code: true, status: true } }),
            this.db.storagePallet.findMany({ where: { ...scope, code: q }, take: 21, select: { id: true, code: true, status: true } }),
            this.db.stockBalance.findMany({ where: { ...scope, quantity: { gt: 0 }, sku: { barcodes: { some: { value: q } } } }, take: 21, orderBy: { id: 'asc' }, select: { id: true, quantity: true, status: true, sku: { select: { name: true, size: true } }, box: { select: { code: true } }, warehouse: { select: { name: true } } } }),
            this.db.productMark.findMany({ where: { clientId: scope.clientId, ...(scope.warehouseId ? { OR: [{ box: { warehouseId: scope.warehouseId } }, { boxId: null, stockMovement: { warehouseId: scope.warehouseId } }] } : {}),
                    AND: [identity ? { OR: [identity, ']d2' + identity, ']D2' + identity].map(prefix => ({ value: { startsWith: prefix } })) } : { value: q }] }, take: 21, select: { id: true, value: true, status: true, sku: { select: { name: true } }, box: { select: { code: true } } } }),
        ]);
        const rows = [...requests.slice(0, 20).map(r => ({ kind: 'request', id: r.id, label: `№${r.number} · ${r.title}`, detail: r.status })),
            ...boxes.slice(0, 20).map(b => ({ kind: 'box', id: b.id, label: b.code, detail: b.status })), ...pallets.slice(0, 20).map(p => ({ kind: 'pallet', id: p.id, label: p.code, detail: p.status })),
            ...balances.slice(0, 20).map(b => ({ kind: 'balance', id: b.id, label: `${b.sku.name} · ${b.sku.size ?? ''}`, detail: `${b.quantity} шт. · ${b.status} · ${b.box?.code ?? 'Без короба'} · ${b.warehouse?.name ?? 'Филиал не указан'}` })),
            ...marks.filter(m => !identity || (0, kiz_physical_identity_1.physicalKizIdentity)(m.value) === identity).slice(0, 20).map(m => ({ kind: 'mark', id: m.id, label: m.sku.name, detail: `${m.status} · ${m.box?.code ?? 'Без короба'}` }))];
        return { rows, truncated: [requests, boxes, pallets, balances, marks].some(a => a.length > 20) };
    }
    async box(id, user) {
        const scope = this.scope(user);
        const box = await this.db.box.findFirst({ where: { id, ...scope }, select: { id: true, clientId: true, warehouseId: true, code: true, zone: { select: { name: true } }, storagePlacement: { select: { pallet: { select: { code: true } } } } } });
        if (!box)
            throw new common_1.NotFoundException('Короб не найден.');
        const rules = await (0, receipt_channel_policy_1.receiptRules)(this.db, box.clientId, box.warehouseId, [id]), rule = rules.get(id);
        const [tasks, history] = await Promise.all([
            this.db.fbsTsdAssembly.findMany({ where: { clientId: box.clientId, ...(scope.warehouseId ? { stockWarehouseId: scope.warehouseId } : {}), OR: [{ boxId: id }, { reservedBoxId: id }], status: { in: ['RESERVED', 'IN_PROGRESS', 'WAITING_STOCK', 'RESCAN_REQUIRED'] } }, take: 30, select: { requestId: true, orderId: true, itemCount: true, status: true } }),
            this.db.stockMovement.findMany({ where: { boxId: id, ...scope }, orderBy: { createdAt: 'desc' }, take: 30, select: { type: true, status: true, quantity: true, createdAt: true, sourceDocument: true } }),
        ]);
        return { code: box.code, zone: box.zone?.name, pallet: box.storagePlacement?.pallet.code, receiptApproved: rule?.stockAvailable !== false, fbsAllowed: (0, receipt_channel_policy_1.receiptAllows)(rule, 'fbs'), fboAllowed: (0, receipt_channel_policy_1.receiptAllows)(rule, 'fbo'), tasks, history };
    }
    sqlScope(user) {
        const scope = this.scope(user), f = scope.clientId;
        const client = typeof f === 'string' ? client_1.Prisma.sql `r."clientId"=${f}` : f && 'in' in f ? (f.in.length ? client_1.Prisma.sql `r."clientId" IN (${client_1.Prisma.join(f.in)})` : client_1.Prisma.sql `FALSE`) : f && 'notIn' in f && f.notIn.length ? client_1.Prisma.sql `r."clientId" NOT IN (${client_1.Prisma.join(f.notIn)})` : client_1.Prisma.sql `TRUE`;
        return client_1.Prisma.sql `${client} AND ${scope.warehouseId ? client_1.Prisma.sql `r."warehouseId"=${scope.warehouseId}` : client_1.Prisma.sql `TRUE`}`;
    }
    async attention(user) {
        return this.db.$queryRaw(client_1.Prisma.sql `SELECT q."key",q."requestId",r.number,r.title,q.cause,q.label,q."reasonCode",q.attempts,q."lastAttemptAt",q."nextAttemptAt",q."updatedAt",q."assignedToId",u.name AS "assignedToName"
      FROM "WmsReconciliationCase" q JOIN "ClientRequest" r ON r.id=q."requestId" AND r."clientId"=q."clientId"
      LEFT JOIN "User" u ON u.id=q."assignedToId" WHERE q."resolvedAt" IS NULL AND ${this.sqlScope(user)}
      ORDER BY q."createdAt",q."key" LIMIT 100`);
    }
    async take(key, user) {
        const rows = await this.db.$queryRaw(client_1.Prisma.sql `SELECT q."requestId",q."clientId" FROM "WmsReconciliationCase" q JOIN "ClientRequest" r ON r.id=q."requestId" AND r."clientId"=q."clientId" WHERE q."key"=${key} AND ${this.sqlScope(user)}`);
        if (!rows.length)
            throw new common_1.NotFoundException();
        this.scopes.requireClientAccess(user, rows[0].clientId, 'write');
        const r = await this.db.clientRequest.findFirst({ where: { id: rows[0].requestId, ...this.scope(user, true) }, select: { id: true } });
        if (!r)
            throw new common_1.NotFoundException();
        await this.db.$transaction(async (tx) => {
            const n = await tx.$executeRaw(client_1.Prisma.sql `UPDATE "WmsReconciliationCase" SET "assignedToId"=${user.id},"updatedAt"=NOW() WHERE "key"=${key} AND "resolvedAt" IS NULL AND ("assignedToId" IS NULL OR "assignedToId"=${user.id})`);
            if (!n)
                throw new common_1.BadRequestException('Случай уже взят другим сотрудником или закрыт.');
            await tx.auditLog.create({ data: { userId: user.id, action: 'RECONCILIATION_ASSIGNED', entity: 'WmsReconciliationCase', entityId: key, payload: { requestId: r.id } } });
        });
        return { ok: true };
    }
};
exports.OperationsToolsService = OperationsToolsService;
exports.OperationsToolsService = OperationsToolsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], OperationsToolsService);
