"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsToolsModule = exports.OperationsToolsController = void 0;
const common_1 = require("@nestjs/common");
const operations_tools_service_1 = require("./operations-tools.service");
const auth_module_1 = require("../auth/auth.module");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
let OperationsToolsController = class OperationsToolsController {
    tools;
    constructor(tools) {
        this.tools = tools;
    }
    capabilities() { this.tools.enabled(); return { enabled: true }; }
    requests(q, u) { return this.tools.requests(q, u); }
    readiness(id, u) { return this.tools.readiness(id, u); }
    search(q, u) { return this.tools.search(q, u); }
    box(id, u) { return this.tools.box(id, u); }
    attention(u) { return this.tools.attention(u); }
    take(key, u) { return this.tools.take(key, u); }
};
exports.OperationsToolsController = OperationsToolsController;
__decorate([
    (0, common_1.Get)('capabilities'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], OperationsToolsController.prototype, "capabilities", null);
__decorate([
    (0, common_1.Get)('requests'),
    __param(0, (0, common_1.Query)('q')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OperationsToolsController.prototype, "requests", null);
__decorate([
    (0, common_1.Get)('readiness/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OperationsToolsController.prototype, "readiness", null);
__decorate([
    (0, common_1.Get)('search'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:read', 'stock:read'),
    __param(0, (0, common_1.Query)('q')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OperationsToolsController.prototype, "search", null);
__decorate([
    (0, common_1.Get)('boxes/:id'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:read', 'stock:read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OperationsToolsController.prototype, "box", null);
__decorate([
    (0, common_1.Get)('attention'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], OperationsToolsController.prototype, "attention", null);
__decorate([
    (0, common_1.Post)('attention/:key/take'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:read', 'client-requests:write'),
    __param(0, (0, common_1.Param)('key')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OperationsToolsController.prototype, "take", null);
exports.OperationsToolsController = OperationsToolsController = __decorate([
    (0, common_1.Controller)('operations-tools'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof operations_tools_service_1.OperationsToolsService !== "undefined" && operations_tools_service_1.OperationsToolsService) === "function" ? _a : Object])
], OperationsToolsController);
let OperationsToolsModule = class OperationsToolsModule {
};
exports.OperationsToolsModule = OperationsToolsModule;
exports.OperationsToolsModule = OperationsToolsModule = __decorate([
    (0, common_1.Module)({ imports: [auth_module_1.AuthModule], controllers: [OperationsToolsController], providers: [operations_tools_service_1.OperationsToolsService] })
], OperationsToolsModule);
