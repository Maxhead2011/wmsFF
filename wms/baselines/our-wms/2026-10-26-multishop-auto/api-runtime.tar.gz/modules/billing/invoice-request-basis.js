"use strict";
exports.invoiceRequestBasis = invoiceRequestBasis;
async function invoiceRequestBasis(db, invoices) {
    const idsFor = invoice => [...new Set([invoice.requestId, ...(invoice.items || []).flatMap(item => [
        item.charge?.requestId, item.charge?.metadata?.requestId,
        ...(Array.isArray(item.charge?.metadata?.requestIds) ? item.charge.metadata.requestIds : [])
    ])].filter(id => typeof id === 'string' && id))];
    const ids = [...new Set(invoices.flatMap(idsFor))];
    const requests = ids.length ? await db.clientRequest.findMany({where:{id:{in:ids}},select:{id:true,clientId:true,number:true}}) : [];
    const map = new Map(requests.map(r=>[r.id,r]));
    return new Map(invoices.map(invoice=>{
        // Invoice snapshots can aggregate charge rows; retain provenance copied by merge.
        const saved = /Счёт сформирован из заяв(?:ки|ок) ВМС №[\d, ]+/.exec(invoice.comment || '')?.[0];
        const savedNumbers = saved ? saved.split('№')[1].split(',').map(n=>Number(n.trim())).filter(n=>Number.isSafeInteger(n)&&n>0) : [];
        const numbers = [...new Set([...savedNumbers,...idsFor(invoice).map(id=>map.get(id)).filter(r=>r && r.clientId===invoice.clientId).map(r=>r.number)])].sort((a,b)=>a-b);
        const basis = saved || (numbers.length ? `Счёт сформирован из ${numbers.length===1?'заявки':'заявок'} ВМС №${numbers.join(', ')}` : null);
        return [invoice.id,{requestNumbers:numbers,basis}];
    }));
}
