"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BILLING_CATEGORIES = void 0;
exports.classifyBillingCharge = classifyBillingCharge;
exports.classifyBillingInvoice = classifyBillingInvoice;
exports.classifyBillingRegistryInvoice = classifyBillingRegistryInvoice;
exports.parseBillingPeriod = parseBillingPeriod;
exports.record = record;
exports.buildPeriodPlan = buildPeriodPlan;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const completed_fbs_billing_1 = require("./completed-fbs-billing");
const fbs_billing_branch_evidence_1 = require("./fbs-billing-branch-evidence");
// ADDED: shared registry/generation policy. No tariff calculation or stock writes.
exports.BILLING_CATEGORIES = ['FBS', 'PROCESSING', 'PRR', 'STORAGE', 'OTHER'];
function classifyBillingCharge(charge) {
    if (!charge)
        return 'OTHER';
    const kind = record(charge.metadata).kind;
    if (charge.source === 'STORAGE' || charge.service?.code === 'STORAGE_LITER_DAY')
        return 'STORAGE';
    if (kind === 'FBS_PRIMARY_PROCESSING')
        return 'PROCESSING';
    if (['PPR_BOXES', 'PPR_BAGS'].includes(charge.service?.code ?? ''))
        return 'PRR';
    if (kind === 'FBS' || kind === 'FBS_DAILY_LOGISTICS' || charge.service?.code === 'FBS_PROCESSING')
        return 'FBS';
    return 'OTHER';
}
function classifyBillingInvoice(invoice) {
    const categories = new Set(invoice.items.map(item => classifyBillingCharge(item.charge)));
    return categories.size === 1 ? [...categories][0] : 'OTHER';
}
// FIX: recovery invoices may contain FBS processing and its primary/additional services.
// The period planner applies all financial/date/duplicate guards after this classification.
function classifyBillingRegistryInvoice(invoice) {
    const category = classifyBillingInvoice(invoice);
    if (category !== 'OTHER' || invoice.clientId !== 'c76b78f9-1b83-4e9b-bee3-bc28336ee1c9')
        return category;
    // FIX: preserve classification after consolidation, so a repeated preview reuses the result.
    const recoveredInvoice = invoice.sourceKey?.startsWith(`fbs-invoice:${invoice.clientId}:completed-work:`);
    const generatedPeriod = new RegExp(`^billing-period:[a-f0-9]{64}:FBS:${invoice.clientId}$`).test(invoice.sourceKey ?? '');
    if (!recoveredInvoice && !generatedPeriod)
        return category;
    const charges = invoice.items.map(item => ({ category: classifyBillingCharge(item.charge), metadata: record(item.charge?.metadata) }));
    const onlyFbsServices = charges.every(charge => ((charge.metadata.kind === 'FBS' || generatedPeriod) && charge.category === 'FBS') ||
        (charge.metadata.kind === 'FBS_PRIMARY_PROCESSING' && charge.category === 'PROCESSING'));
    // Persisted provenance, not today's rollout flag: disabling creation must not hide existing invoices.
    const recoveredWork = charges.some(charge => charge.metadata.billingPolicy === completed_fbs_billing_1.COMPLETED_WORK_POLICY && charge.metadata.processingOnly === true);
    return onlyFbsServices && recoveredWork && charges.some(charge => charge.category === 'FBS') ? 'FBS' : category;
}
function parseBillingPeriod(start, end) {
    const date = (value, endOfDay) => {
        const calendarDate = new Date(`${value}T12:00:00Z`);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(calendarDate.getTime()) || calendarDate.toISOString().slice(0, 10) !== value) {
            throw new common_1.BadRequestException('Укажите существующие календарные даты в формате ГГГГ-ММ-ДД.');
        }
        // FIX: billing service dates are historical calendar values encoded in UTC.
        // Existing writers and the invoice editor preserve these date components.
        return new Date(`${value}T${endOfDay ? '23:59:59.999' : '00:00:00.000'}Z`);
    };
    const from = date(start, false), to = date(end, true);
    if (from > to || to.getTime() - from.getTime() > 366 * 86400000)
        throw new common_1.BadRequestException('Выберите период от одного дня до года.');
    return { from, to };
}
function record(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function buildPeriodPlan(input, charges, invoices, warehouseId) {
    const { from, to } = parseBillingPeriod(input.periodFrom, input.periodTo);
    const groups = new Map();
    const issues = [];
    let alreadyBilledCount = 0, zeroCount = 0;
    const eligibleClient = (c) => (!input.clientId || input.clientId === c.id) &&
        !(input.excludeLukin && /лукин/i.test(`${c.name} ${c.legalName ?? ''}`));
    const issue = (id, c, message) => issues.push({ id, clientName: c.name, message });
    const add = (c, category, total, count, id, invoice, lines) => {
        const key = `${c.id}:${warehouseId}:${category}`;
        const group = groups.get(key) ?? { key, clientId: c.id, clientName: c.name, warehouseId, category, chargeIds: [], invoiceIds: [], totalRub: 0, itemCount: 0, action: 'CREATE', lines: [] };
        group[invoice ? 'invoiceIds' : 'chargeIds'].push(id);
        group.totalRub = Math.round((group.totalRub + total) * 100) / 100;
        group.itemCount += count;
        group.lines.push(...lines);
        groups.set(key, group);
    };
    const sourceCounts = new Map();
    for (const invoice of invoices.filter(i => i.status !== 'CANCELLED')) {
        for (const item of invoice.items)
            if (item.chargeId)
                sourceCounts.set(item.chargeId, (sourceCounts.get(item.chargeId) ?? 0) + 1);
    }
    for (const c of charges) {
        if (!eligibleClient(c.client) || c.serviceDate < from || c.serviceDate > to || c.status === 'CANCELLED')
            continue;
        if (c.invoiceItems.some(i => i.invoice.status !== 'CANCELLED'))
            continue;
        let branch = c.request?.warehouseId ?? record(c.metadata).warehouseId;
        if (!branch) {
            const evidence = (0, fbs_billing_branch_evidence_1.readFbsBranchEvidence)(c);
            if (evidence) {
                // Confirmed outside this branch, including explicitly excluded routes.
                // Do not reassign, approve, cancel or reprice these source charges.
                if (!evidence.warehouseIds.includes(warehouseId))
                    continue;
                if (evidence.warehouseIds.length !== 1 || evidence.excludedOrders > 0) {
                    issue(c.id, c.client, 'Начисление объединяет разные филиалы или исключённые склады. Требуется отдельная проверка источников.');
                    continue;
                }
                branch = evidence.warehouseIds[0];
            }
        }
        if (branch && branch !== warehouseId)
            continue;
        const category = classifyBillingCharge(c);
        if (category !== 'OTHER' && !input.categories.includes(category))
            continue;
        if (!branch) {
            issue(c.id, c.client, 'Не определён филиал начисления. Уточните источник; текущий филиал не подставляется автоматически.');
            continue;
        }
        if (category === 'OTHER') {
            issue(c.id, c.client, `Не определён вид услуги: ${c.description}.`);
            continue;
        }
        if (c.status !== 'APPROVED') {
            issue(c.id, c.client, `Не утверждено начисление: ${c.description}.`);
            continue;
        }
        const total = Number(c.totalRub);
        if (!Number.isFinite(total) || total < 0 || (total === 0 && Number(c.quantity) > 0)) {
            issue(c.id, c.client, `Требуется проверка суммы/нулевого тарифа: ${c.description}.`);
            continue;
        }
        if (total === 0) {
            zeroCount++;
            continue;
        }
        const meta = record(c.metadata);
        if (category === 'STORAGE' && (typeof meta.periodFrom !== 'string' || typeof meta.periodTo !== 'string' ||
            meta.periodFrom < input.periodFrom || meta.periodTo > input.periodTo)) {
            issue(c.id, c.client, 'Проверьте период начисления хранения: нельзя включить целый период в его часть.');
            continue;
        }
        add(c.client, category, total, 1, c.id, false, [{ sourceType: 'CHARGE', sourceId: c.id, chargeId: c.id,
                description: c.description, serviceDate: c.serviceDate.toISOString().slice(0, 10), unit: c.unit,
                quantity: c.quantity.toString(), unitPriceRub: c.unitPriceRub.toString(), totalRub: c.totalRub.toString() }]);
    }
    for (const inv of invoices) {
        if (!eligibleClient(inv.client) || inv.status === 'CANCELLED')
            continue;
        const branch = inv.warehouseId ?? inv.request?.warehouseId;
        if (branch && branch !== warehouseId)
            continue;
        // FIX: include proven recovered FBS bundles without recalculation or new charge creation.
        const category = classifyBillingRegistryInvoice(inv);
        if (category !== 'OTHER' && !input.categories.includes(category))
            continue;
        if (inv.status !== 'DRAFT' || Number(inv.paidRub) !== 0 || inv.payments.length) {
            alreadyBilledCount++;
            continue;
        }
        if (!branch || category === 'OTHER' || !inv.items.length) {
            issue(inv.id, inv.client, `Счёт ${inv.number}: не определён филиал или смешанные/неопределённые услуги.`);
            continue;
        }
        if (inv.periodFrom < from || inv.periodTo > to || inv.items.some(i => i.serviceDate < from || i.serviceDate > to)) {
            issue(inv.id, inv.client, `Счёт ${inv.number} выходит за выбранный период. Автоматическое разделение запрещено.`);
            continue;
        }
        if (inv.items.some(i => i.chargeId && (sourceCounts.get(i.chargeId) ?? 0) > 1)) {
            issue(inv.id, inv.client, `Счёт ${inv.number}: источник начисления повторяется в нескольких строках/счетах.`);
            continue;
        }
        // FIX: the invoice total cannot establish a tariff for each performed service.
        // No explicit free-service evidence exists in this snapshot contract; flag for review.
        const unresolvedTariffs = inv.items.filter(item => Number(item.quantity) > 0 &&
            (Number(item.unitPriceRub) <= 0 || Number(item.totalRub) <= 0));
        if (unresolvedTariffs.length) {
            for (const item of unresolvedTariffs)
                issue(inv.id, inv.client, `Счёт ${inv.number}: требуется проверка суммы/нулевого тарифа: ${item.description}.`);
            continue;
        }
        const total = Number(inv.totalRub);
        const rowTotal = Math.round(inv.items.reduce((n, i) => n + Number(i.totalRub), 0) * 100) / 100;
        if (!Number.isFinite(total) || total < 0 || Math.abs(total - rowTotal) > 0.005) {
            issue(inv.id, inv.client, `Счёт ${inv.number}: сумма не совпадает со строками.`);
            continue;
        }
        if (total === 0) {
            zeroCount++;
            continue;
        }
        add(inv.client, category, total, inv.items.length, inv.id, true, inv.items.map(item => ({
            sourceType: 'INVOICE', sourceId: inv.id, sourceNumber: inv.number, invoiceItemId: item.id,
            chargeId: item.chargeId ?? undefined, description: item.description, serviceDate: item.serviceDate.toISOString().slice(0, 10),
            unit: item.unit, quantity: item.quantity.toString(), unitPriceRub: item.unitPriceRub.toString(), totalRub: item.totalRub.toString(),
        })));
    }
    const result = [...groups.values()].sort((a, b) => a.key.localeCompare(b.key));
    for (const g of result) {
        g.chargeIds.sort();
        g.invoiceIds.sort();
        g.lines.sort((a, b) => `${a.sourceId}:${a.invoiceItemId ?? ''}`.localeCompare(`${b.sourceId}:${b.invoiceItemId ?? ''}`));
        const onlyInvoice = g.invoiceIds.length === 1 && !g.chargeIds.length ? invoices.find(invoice => invoice.id === g.invoiceIds[0]) : undefined;
        if (onlyInvoice && onlyInvoice.periodFrom.toISOString().slice(0, 10) === input.periodFrom && onlyInvoice.periodTo.toISOString().slice(0, 10) === input.periodTo) {
            g.action = 'EXISTING';
            g.existingInvoiceId = onlyInvoice.id;
        }
    }
    // FIX: bind confirmation to source snapshots as well as visible totals.
    const fingerprint = { input: { ...input, categories: [...input.categories].sort() }, warehouseId,
        charges: [...charges].sort((a, b) => a.id.localeCompare(b.id)).map(charge => ({ ...charge, invoiceItems: [...charge.invoiceItems].sort((a, b) => a.invoice.id.localeCompare(b.invoice.id)) })),
        invoices: [...invoices].sort((a, b) => a.id.localeCompare(b.id)).map(invoice => ({ ...invoice, items: [...invoice.items].sort((a, b) => a.id.localeCompare(b.id)) })), groups: result };
    return { periodFrom: input.periodFrom, periodTo: input.periodTo, groups: result, issues, alreadyBilledCount, zeroCount,
        previewHash: (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(fingerprint)).digest('hex') };
}
