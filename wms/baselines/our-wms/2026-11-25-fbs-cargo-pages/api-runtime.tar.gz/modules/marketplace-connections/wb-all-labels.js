"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wbAllLabels = wbAllLabels;
const common_1 = require("@nestjs/common");
const pdf_lib_1 = require("pdf-lib");
// FIX: read-only ribbon; a missing section must not discard the available labels.
async function wbAllLabels(input, readers, ozonEnabled = false, cargoLabelsOnly = false) {
    // FIX: isolated own-WMS mode; never fall back to product pairs.
    if (cargoLabelsOnly && !ozonEnabled)
        throw new common_1.BadRequestException('Печать грузомест не включена.');
    const orders = [...new Map(input.map(o => [JSON.stringify([o.connectionId, o.id]), o])).values()];
    if (!orders.length || orders.some(o => o.marketplace !== 'WILDBERRIES' && !(ozonEnabled && o.marketplace === 'OZON')))
        throw new common_1.BadRequestException('Выберите заказы Wildberries.');
    const warnings = [];
    const output = await pdf_lib_1.PDFDocument.create();
    async function append(read, label, split) {
        try {
            const file = await read();
            const pdf = await pdf_lib_1.PDFDocument.load(file.buffer);
            if (!pdf.getPageCount())
                throw new Error('Получен пустой PDF.');
            const pages = await output.copyPages(pdf, pdf.getPageIndices());
            pages.forEach(page => output.addPage(page));
        }
        catch (error) {
            const status = error?.getStatus?.();
            // Access failures are not missing labels. Never return another client's data.
            if (status === 401 || status === 403)
                throw error;
            if (split && (status === 400 || status === 404)) {
                await split();
                return;
            }
            warnings.push(`${label}: ${error instanceof common_1.BadRequestException ? error.message : 'не удалось получить этикетку, повторите скачивание позже.'}`);
        }
    }
    // FIX: SC/PVZ documents belong only to WB, never to an Ozon posting.
    const wbOrders = orders.filter(o => o.marketplace === 'WILDBERRIES');
    const supplies = [...new Map(wbOrders.filter(o => o.supplyId)
            .map(o => [JSON.stringify([o.connectionId, o.supplyId]), o])).values()];
    if (wbOrders.some(o => !o.supplyId))
        warnings.push('СЦ / ПВЗ: у части заказов ещё не привязана поставка.');
    for (const kind of ['sc', 'pvz']) {
        for (const order of supplies) {
            await append(() => readers[kind]([order]), `${kind === 'sc' ? 'СЦ' : 'ПВЗ'} · ${order.supplyId}`);
        }
    }
    async function pairs(batch) {
        await append(() => cargoLabelsOnly ? readers.official(batch) : readers.pairs(batch), `${cargoLabelsOnly ? 'Стикеры заказов Ozon' : 'ШК товара / заказа'} · ${batch.map(o => o.id).join(', ')}`, batch.length > 1 ? async () => {
            const mid = Math.ceil(batch.length / 2);
            await pairs(batch.slice(0, mid));
            await pairs(batch.slice(mid));
        } : undefined);
    }
    const labelOrders = cargoLabelsOnly ? orders.filter(o => o.marketplace === 'OZON') : orders;
    if (labelOrders.length)
        await pairs(labelOrders);
    if (!output.getPageCount())
        throw new common_1.BadRequestException(`Нет доступных этикеток. ${warnings.join(' ')}`);
    return { fileBase64: Buffer.from(await output.save()).toString('base64'),
        fileName: `FBS_${orders.every(o => o.marketplace === 'OZON') ? 'OZON' : 'WB'}_${cargoLabelsOnly ? 'cargo_labels' : 'all_labels'}.pdf`, pageCount: output.getPageCount(), warnings };
}
