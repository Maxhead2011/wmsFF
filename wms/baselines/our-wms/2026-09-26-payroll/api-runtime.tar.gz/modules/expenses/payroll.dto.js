"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PayrollStatusDto = exports.PayrollHandlingDto = exports.PayrollShiftDto = exports.PayrollConditionDto = exports.PayrollEmployeeDto = void 0;
const class_validator_1 = require("class-validator");
class PayrollEmployeeDto {
    name;
    warehouseId;
    userId;
    picker;
    loader;
    isActive;
    // FIX: incomplete historical requisites must not imply a cash payment agreement.
    paymentMethod;
    paymentPhone;
    paymentBank;
}
exports.PayrollEmployeeDto = PayrollEmployeeDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "userId", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollEmployeeDto.prototype, "picker", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollEmployeeDto.prototype, "loader", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollEmployeeDto.prototype, "isActive", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['CASH', 'TRANSFER', 'UNSPECIFIED']),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "paymentMethod", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(32),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "paymentPhone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], PayrollEmployeeDto.prototype, "paymentBank", void 0);
class PayrollConditionDto {
    kind;
    rateKopecks;
    startsAt;
    endsAt;
    temporary;
    reason;
}
exports.PayrollConditionDto = PayrollConditionDto;
__decorate([
    (0, class_validator_1.IsIn)(['HOURLY', 'PIECE', 'PALLET']),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "kind", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PayrollConditionDto.prototype, "rateKopecks", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "startsAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "endsAt", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PayrollConditionDto.prototype, "temporary", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollConditionDto.prototype, "reason", void 0);
class PayrollShiftDto {
    startsAt;
    endsAt;
    reason;
}
exports.PayrollShiftDto = PayrollShiftDto;
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollShiftDto.prototype, "startsAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollShiftDto.prototype, "endsAt", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollShiftDto.prototype, "reason", void 0);
class PayrollHandlingDto {
    warehouseId;
    startsAt;
    operation;
    palletCount;
    employeeIds;
    reason;
}
exports.PayrollHandlingDto = PayrollHandlingDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "startsAt", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['LOAD', 'UNLOAD']),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "operation", void 0);
__decorate([
    (0, class_validator_1.IsNumber)({ maxDecimalPlaces: 4 }),
    (0, class_validator_1.Min)(0.0001),
    __metadata("design:type", Number)
], PayrollHandlingDto.prototype, "palletCount", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], PayrollHandlingDto.prototype, "employeeIds", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollHandlingDto.prototype, "reason", void 0);
class PayrollStatusDto {
    employeeId;
    dateFrom;
    dateTo;
    keys;
    status;
    comment;
}
exports.PayrollStatusDto = PayrollStatusDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "employeeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "dateFrom", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "dateTo", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], PayrollStatusDto.prototype, "keys", void 0);
__decorate([
    (0, class_validator_1.IsIn)(['UNPAID', 'REVIEW', 'PAID']),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], PayrollStatusDto.prototype, "comment", void 0);
