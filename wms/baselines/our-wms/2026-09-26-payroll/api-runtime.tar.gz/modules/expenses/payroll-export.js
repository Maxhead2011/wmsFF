"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.payrollXlsx = payrollXlsx;
exports.payrollPdf = payrollPdf;
const XLSX = __importStar(require("xlsx"));
const pdfMake = require("pdfmake");
const pdfmake_1 = require("../../common/pdf/pdfmake");
const status = { PAID: 'Оплачено', REVIEW: 'На проверке', UNPAID: 'Не оплачено' };
function rows(report) {
    return report.rows.map(r => [r.date, report.employee.name, r.kind === 'HOURLY' ? 'Повременная' : r.kind === 'PIECE' ? 'Сдельная' : r.kind === 'HISTORY' ? 'История табеля' : 'Погрузка / разгрузка',
        (r.workedMs ?? 0) / 3600000, (r.lunchMs ?? 0) / 3600000, r.units ?? '', r.amountKopecks / 100, status[r.status] ?? r.status, r.comment ?? '']);
}
const headers = ['Дата', 'Сотрудник', 'Начисление', 'Часы', 'Обед, ч', 'Единицы', 'Сумма, ₽', 'Статус', 'Комментарий'];
function payrollXlsx(report) {
    const book = XLSX.utils.book_new();
    const table = [['Дата', 'ФИО', 'Начало', 'Конец', 'Обед', 'Время Итого', 'Цена в час', 'Сумма', 'Телефон', 'Банк', 'Статус']];
    const localTime = (value) => new Date(value).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
    for (const r of report.rows.filter(row => ['HOURLY', 'HISTORY'].includes(row.kind))) {
        if (r.kind === 'HISTORY') {
            const d = r.detail;
            table.push([r.date, report.employee.name, d.start, d.end, d.lunch, d.paidTime, d.rate, r.amountKopecks / 100, d.phone, d.bank, status[r.status]]);
        }
        else {
            const segments = r.detail.segments;
            let allocated = 0;
            segments.forEach((s, i) => {
                const amount = i === segments.length - 1 ? r.amountKopecks - allocated : Math.round(s.paidMs * s.rateKopecks / 3600000);
                allocated += amount;
                table.push([r.date, report.employee.name, localTime(s.start), localTime(s.end), (s.workedMs - s.paidMs) / 86400000, s.paidMs / 86400000, s.rateKopecks / 100, amount / 100,
                    report.employee.paymentPhone ?? '', report.employee.paymentMethod === 'CASH' ? 'Наличные' : report.employee.paymentBank ?? '', status[r.status]]);
            });
        }
    }
    const sheet = XLSX.utils.aoa_to_sheet(table);
    sheet['!cols'] = [14, 28, 23, 23, 12, 14, 16, 16, 20, 22, 18].map(wch => ({ wch }));
    for (let r = 1; r < table.length; r++)
        for (const c of [2, 3, 4, 5]) {
            const cell = sheet[XLSX.utils.encode_cell({ r, c })];
            if (cell?.t === 'n')
                cell.z = c < 4 ? 'hh:mm' : '[h]:mm';
        }
    XLSX.utils.book_append_sheet(book, sheet, 'Табель');
    XLSX.utils.book_append_sheet(book, XLSX.utils.aoa_to_sheet([headers, ...rows(report)]), 'Начисления');
    const details = [['Дата', 'Начало', 'Конец', 'Оплачиваемые часы', 'Ставка, ₽/ч']];
    for (const r of report.rows) {
        const segments = r.detail.segments;
        for (const s of segments ?? [])
            details.push([r.date, s.start, s.end, s.paidMs / 3600000, s.rateKopecks / 100]);
    }
    XLSX.utils.book_append_sheet(book, XLSX.utils.aoa_to_sheet(details), 'Расчёт по ставкам');
    XLSX.utils.book_append_sheet(book, XLSX.utils.aoa_to_sheet([['Период', `${report.from} — ${report.to}`], ['Начислено, ₽', report.totals.amountKopecks / 100], ['Оплачено, ₽', report.totals.paidKopecks / 100], ...report.issues.map(v => ['Требует проверки', v])]), 'Итоги');
    return XLSX.write(book, { type: 'buffer', bookType: 'xlsx' });
}
async function payrollPdf(report) {
    (0, pdfmake_1.configurePdfMake)();
    const doc = { pageOrientation: 'landscape', defaultStyle: { font: 'DejaVuSans', fontSize: 8 }, content: [
            { text: `Табель: ${report.employee.name}`, fontSize: 15, bold: true }, { text: `${report.from} — ${report.to}`, margin: [0, 8, 0, 12] },
            { table: { headerRows: 1, body: [headers, ...rows(report).map(row => row.map(v => typeof v === 'number' ? v.toFixed(2) : v))] }, layout: 'lightHorizontalLines' },
            { text: `Начислено: ${(report.totals.amountKopecks / 100).toFixed(2)} ₽. Оплачено: ${(report.totals.paidKopecks / 100).toFixed(2)} ₽.`, margin: [0, 12, 0, 0] }, ...report.issues.map(text => ({ text }))
        ] };
    return Buffer.from(await pdfMake.createPdf(doc).getBuffer());
}
