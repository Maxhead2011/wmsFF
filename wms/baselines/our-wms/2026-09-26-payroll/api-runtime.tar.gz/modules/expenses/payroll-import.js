"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.previewPayrollWorkbook = previewPayrollWorkbook;
const XLSX = __importStar(require("xlsx"));
const node_crypto_1 = require("node:crypto");
const hash = (s) => (0, node_crypto_1.createHash)('sha256').update(s).digest('hex');
const text = (v) => String(v ?? '').trim();
// FIX: import historical results verbatim; never apply the new lunch rule retroactively.
function previewPayrollWorkbook(buffer) {
    const book = XLSX.read(buffer, { type: 'buffer', cellDates: false });
    const rows = [], issues = [], counts = new Map();
    for (const sheet of book.SheetNames) {
        const cells = XLSX.utils.sheet_to_json(book.Sheets[sheet], { header: 1, raw: true, defval: null });
        const header = cells.findIndex(r => text(r[0]) === 'Дата' && text(r[1]) === 'ФИО');
        if (header < 0)
            continue;
        for (let i = header + 1; i < cells.length; i++) {
            const r = cells[i];
            if (!text(r[0]) && !text(r[1]))
                continue;
            const stamp = typeof r[0] === 'number' ? XLSX.SSF.parse_date_code(r[0]) : null;
            if (!stamp || !text(r[1])) {
                issues.push(`${sheet}, строка ${i + 1}: проверьте дату и имя`);
                continue;
            }
            const date = `${stamp.y}-${String(stamp.m).padStart(2, '0')}-${String(stamp.d).padStart(2, '0')}`;
            if (![r[2], r[3], r[4], r[5], r[6], r[7]].every(v => typeof v === 'number' && Number.isFinite(v) && v >= 0)) {
                issues.push(`${sheet}, строка ${i + 1}: отсутствует числовое значение времени, ставки или суммы; пересохраните рассчитанный файл`);
                continue;
            }
            const statusText = text(r[10]).toLowerCase();
            const status = statusText === 'оплачен' || statusText === 'оплачено' ? 'PAID' : ['не оплачен', 'не оплачено', 'ожидает'].includes(statusText) ? 'UNPAID' : 'REVIEW';
            const data = { sheet, row: i + 1, name: text(r[1]), date, start: r[2], end: r[3], lunch: r[4],
                paidTime: r[5], rate: r[6], amountKopecks: Math.round(Number(r[7]) * 100), phone: text(r[8]), bank: text(r[9]), status };
            const identity = hash(JSON.stringify([data.name.toLowerCase(), date, data.start, data.end]));
            const occurrence = (counts.get(identity) ?? 0) + 1;
            counts.set(identity, occurrence);
            rows.push({ key: `${identity}:${occurrence}`, ...data });
        }
    }
    return { sourceHash: hash(buffer), rows, issues, employees: [...new Set(rows.map(r => r.name))].sort(), totalKopecks: rows.reduce((s, r) => s + r.amountKopecks, 0) };
}
