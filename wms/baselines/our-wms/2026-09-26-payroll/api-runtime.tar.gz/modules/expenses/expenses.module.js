const {PayrollService}=require("./payroll.service");
const {PayrollController}=require("./payroll.controller");
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpensesModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const billing_module_1 = require("../billing/billing.module");
const expense_automation_service_1 = require("./expense-automation.service");
const expenses_controller_1 = require("./expenses.controller");
const expenses_service_1 = require("./expenses.service");
let ExpensesModule = class ExpensesModule {
};
exports.ExpensesModule = ExpensesModule;
exports.ExpensesModule = ExpensesModule = __decorate([
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule, billing_module_1.BillingModule],
        controllers: [expenses_controller_1.ExpensesController, PayrollController],
        providers: [expenses_service_1.ExpensesService, expense_automation_service_1.ExpenseAutomationService, PayrollService],
        exports: [expenses_service_1.ExpensesService, expense_automation_service_1.ExpenseAutomationService],
    })
], ExpensesModule);
