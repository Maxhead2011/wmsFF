"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdministrationInternalApiService = exports.INTERNAL_API_DEFINITIONS = exports.INTERNAL_API_RESTART_CONFIRMATION = void 0;
const common_1 = require("@nestjs/common");
const audit_log_service_1 = require("../../common/audit/audit-log.service");
const prisma_service_1 = require("../../common/prisma/prisma.service");
exports.INTERNAL_API_RESTART_CONFIRMATION = 'ПЕРЕЗАПУСТИТЬ API';
// ADDED: Explicit registry documents every controller group loaded by AppModule.
// Keeping it declarative avoids a global interceptor and therefore does not touch normal API traffic.
exports.INTERNAL_API_DEFINITIONS = Object.freeze([
    // FIX: expose the read-only cycle monitor in the internal API registry.
    { id: 'wb-sync-health', name: 'Контроль синхронизации WB', prefixes: ['/wb-sync-health'], routeCount: 1,
        description: 'Сохранённые циклы WB, свежие подтверждения остатков и отдельные ошибки биллинга.',
        logic: ['Читает последние 20 циклов с учётом прав клиента и филиала.', 'Обновление экрана не запускает отправку остатков.'],
        dependencies: ['Основная БД', 'WMS_WB_SYNC_HEALTH_ENABLED'] },
    // FIX: register the read-only warehouse processing-time report.
    {
        id: 'operations-statistics',
        name: 'Статистика обработки заказов',
        prefixes: ['/operations-statistics'],
        routeCount: 3,
        description: 'Срок до скана поставки и отдельное подтверждение приёмки заказов WB; обновление изолированного кеша отчёта.',
        logic: ['Группирует заказы по филиалам и складам продавца.', 'Применяет область доступа пользователя, фильтры клиента и периода.', 'Показывает неизвестные даты отдельно, не изменяет заказы и остатки.'],
        dependencies: ['Основная БД', 'Права stock:read'],
    },
    {
        id: 'health',
        name: 'Состояние сервиса',
        prefixes: ['/health'],
        routeCount: 1,
        description: 'Публичная проверка, что процесс API запущен и принимает HTTP-запросы.',
        logic: ['Возвращает время сервера и базовый статус процесса.', 'Используется балансировщиком и при проверке восстановления после перезапуска.'],
        dependencies: ['Nest API'],
        requiresDatabase: false,
    },
    {
        // FIX: document the isolated scanner search alongside existing internal APIs.
        id: 'kiz-search',
        name: 'Поиск КИЗ',
        prefixes: ['/tsd/kiz-search'],
        routeCount: 3,
        description: 'Назначенные сотруднику заявки поиска физических единиц по скану КИЗ.',
        logic: ['Проверяет назначение, клиента и филиал.', 'Подтверждает находки без изменения остатков и заказов.', 'Доступен только при WMS_TSD_KIZ_SEARCH=true.'],
        dependencies: ['Основная БД', 'Права stock:read и stock:write'],
    },
    {
        id: 'auth',
        name: 'Авторизация',
        prefixes: ['/auth'],
        routeCount: 4,
        description: 'Вход пользователей, выдача токенов и загрузка текущего профиля.',
        logic: ['Проверяет логин и пароль.', 'Формирует права, филиалы и клиентскую область доступа.', 'Возвращает текущую сессию пользователя или ТСД.'],
        dependencies: ['Основная БД', 'JWT'],
    },
    {
        id: 'administration',
        name: 'Администрирование',
        prefixes: ['/administration', '/administration/marketplace-stock-control', '/administration/auto-assembly', '/administration/fbo-problems'],
        // FIX: include the client stock-control list and update handlers.
        routeCount: 54, // FIX: client reserve, SKU exclusions and recommendation limits.
        description: 'Диагностика WMS, технические работы, настройки, аудит, контроль внутренних API и включение/отключение отправки остатков на МП по клиентам.',
        logic: ['Собирает административные показатели и журнал действий.', 'Диагностирует заявки, паллет-сорты, короба, КИЗ и задания ТСД.', 'Разрешает только серверные, повторно проверяемые исправления.', 'Проблемы FBO: исправления по предпросмотру только ADMIN своего филиала и OWNER; отчёт об отборе и Excel.'],
        dependencies: ['Основная БД', 'Права system:admin'],
    },
    {
        id: 'analytics',
        name: 'Аналитика',
        prefixes: ['/analytics'],
        routeCount: 4,
        description: 'Отчёты по продажам, регионам, товарам и синхронизации аналитических данных.',
        logic: ['Читает подготовленные аналитические срезы.', 'Запускает и контролирует синхронизацию источников.', 'Формирует показатели для аналитических экранов.'],
        dependencies: ['Основная БД', 'Аналитическая БД', 'API маркетплейсов'],
    },
    {
        id: 'billing',
        name: 'Биллинг и счета',
        prefixes: ['/billing'],
        routeCount: 42, // FIX: JSON POST preview for large FBS invoice selections; legacy GET retained.
        description: 'Расчёт услуг, начислений, счетов, оплат и закрывающих документов.',
        logic: ['Считает услуги по тарифам и операциям WMS.', 'Формирует счета, акты и печатные документы.', 'Готовит предварительный расчёт отдельных счетов по услугам за выбранный период.', 'Предпросмотр объединения FBS принимает большой список счетов через POST JSON без изменения данных; GET сохранён для совместимости.', 'Учитывает оплаты, долги и ручные корректировки с аудитом.'],
        dependencies: ['Основная БД', 'PDF-генератор'],
    },
    {
        id: 'branches',
        name: 'Филиалы',
        prefixes: ['/branches'],
        routeCount: 10,
        description: 'Справочник филиалов и доступ пользователя к складам.',
        logic: ['Создаёт и обновляет филиалы.', 'Назначает активный склад пользователя.', 'Ограничивает операции разрешёнными филиалами.'],
        dependencies: ['Основная БД'],
    },
    // FIX: register the operational notification API alongside its role and scope rules.
    {
        id: 'admin-notifications',
        name: 'Сигналы администраторам',
        prefixes: ['/admin-notifications'],
        routeCount: 3,
        description: 'Отсутствующие короба, проблемы с товаром и открытие проверок содержимого.',
        logic: ['Выдаёт события только роли ADMIN в доступных клиентах и филиалах.', 'Хранит прочтение и подтверждение показа отдельно для каждого администратора.', 'Запись и доставка включаются настройкой ADMIN_OPERATIONAL_NOTIFICATIONS_ENABLED.'],
        dependencies: ['Основная БД', 'Роль ADMIN'],
    },
    {
        id: 'client-notifications',
        name: 'Уведомления клиентов',
        prefixes: ['/client-notifications'],
        routeCount: 7,
        description: 'Системные уведомления, отметки прочтения и пользовательские настройки доставки.',
        logic: ['Выдаёт ленту уведомлений.', 'Хранит статус прочтения.', 'Управляет каналами и предпочтениями клиента.'],
        dependencies: ['Основная БД', 'Telegram при настройке'],
    },
    {
        id: 'client-requests',
        name: 'Заявки клиентов',
        prefixes: ['/client-requests'],
        routeCount: 38,
        description: 'Онлайн-заявки, документы, маршруты сборки и управление заказами FBS.',
        logic: ['Создаёт и изменяет заявки.', 'Связывает заказы, короба, файлы и события.', 'Перестраивает маршруты и управляет проблемными заказами.'],
        dependencies: ['Основная БД', 'Склад', 'Подключения маркетплейсов'],
    },
    {
        id: 'clients',
        name: 'Клиенты',
        prefixes: ['/clients'],
        routeCount: 8,
        description: 'Карточки клиентов, реквизиты и правила складского обслуживания.',
        logic: ['Хранит юридические и контактные данные.', 'Настраивает режимы остатков и хранения.', 'Связывает клиента с менеджером и собственной компанией.'],
        dependencies: ['Основная БД'],
    },
    {
        id: 'contracts',
        name: 'Договоры',
        prefixes: ['/contracts'],
        routeCount: 12,
        description: 'Создание, проверка, загрузка и архивирование договорных документов.',
        logic: ['Формирует договор по реквизитам.', 'Сверяет изменения реквизитов.', 'Хранит подписанные файлы и дополнительные соглашения.'],
        dependencies: ['Основная БД', 'Файловое хранилище', 'DOCX/PDF'],
    },
    {
        id: 'expenses',
        name: 'Расходы',
        prefixes: ['/expenses', '/expenses/workforce'],
        routeCount: 31,
        description: 'Учёт расходов, категорий, статей и подтверждающих документов.',
        logic: ['Регистрирует расходы филиала.', 'Фильтрует операции по периоду и ответственным.', 'Формирует отчётность и вложения.'],
        dependencies: ['Основная БД', 'Файловое хранилище'],
    },
    {
        id: 'factory-shipments',
        name: 'Поставки фабрики',
        prefixes: ['/factory-shipments'],
        routeCount: 7,
        description: 'Планирование и контроль поставок от фабрики до склада.',
        logic: ['Создаёт поставку и её состав.', 'Отслеживает статусы движения.', 'Передаёт данные в складскую приёмку.'],
        dependencies: ['Основная БД', 'Склад'],
    },
    {
        id: 'imports',
        name: 'Импорт данных',
        prefixes: ['/imports'],
        routeCount: 6,
        description: 'Проверка и загрузка файлов с товарами и операционными данными.',
        logic: ['Разбирает входной файл без записи на этапе предпросмотра.', 'Показывает ошибки строк.', 'Сохраняет подтверждённый импорт идемпотентно.'],
        dependencies: ['Основная БД', 'XLSX/CSV'],
    },
    {
        id: 'integration-api',
        name: 'Интеграционный API WMS',
        prefixes: ['/integration-access', '/integration/v1'],
        routeCount: 12,
        description: 'Ключи доступа и защищённые методы для внешних систем клиентов.',
        logic: ['Выпускает и отзывает API-ключи.', 'Отдаёт остатки и справочники.', 'Принимает корректировки остатков с идемпотентностью и аудитом.'],
        dependencies: ['Основная БД', 'X-WMS-API-Key'],
    },
    {
        id: 'inventory',
        name: 'Инвентаризация и сортировка',
        prefixes: ['/inventory', '/pallet-sorting', '/inventory/kiz-location'],
        routeCount: 29, // FIX: include SKU collection capabilities and the administrator KIZ location check.
        description: 'Пересчёты, актуализация, сортировка и очередь проверки КИЗов с разрешением использования или переклейки отдельной единицы.',
        logic: ['Фиксирует снимок ожидаемых остатков.', 'Сравнивает факт со снимком.', 'Применяет подтверждённые расхождения через движения склада.', 'Сортировка переносит товар и КИЗ в новые короба без приёмки; списывает недостачу только по свежему подтверждению и перестраивает затронутые FBS-маршруты.', 'Снятие сборки по SKU сохраняет историю и выполненные перемещения; доступно при включённом флаге снятия задач в пределах разрешённых клиента и склада.'],
        dependencies: ['Основная БД', 'Складские движения'],
    },
    {
        id: 'kiz-circulation',
        name: 'Погашение КИЗ',
        prefixes: ['/kiz-circulation'],
        routeCount: 10,
        description: 'Подготовка КИЗ к погашению, проверка Честного знака и возврат в оборот.',
        logic: ['Собирает КИЗ по отгрузкам маркетплейсов.', 'Хранит настройки OMS и подключения ЧЗ.', 'Записывает результат каждой операции и внешнего ответа.'],
        dependencies: ['Основная БД', 'Честный знак', 'Маркетплейсы'],
    },
    {
        id: 'kiz-issues',
        name: 'Проблемы КИЗ',
        prefixes: ['/kiz'],
        routeCount: 6,
        description: 'Поиск конфликтов КИЗ в приёмке, сборке и истории отгрузок.',
        logic: ['Находит дубли и незавершённые привязки.', 'Показывает доказательства конфликта.', 'Применяет только подтверждённое освобождение или перенос статуса.'],
        dependencies: ['Основная БД', 'Складские движения'],
    },
    {
        id: 'logistics',
        name: 'Логистика',
        prefixes: ['/logistics'],
        routeCount: 15,
        description: 'Маршруты, тарифы, заявки и расчёты логистических услуг.',
        logic: ['Хранит направления и тарифные сетки.', 'Рассчитывает стоимость маршрута.', 'Связывает перевозку с клиентом и филиалом.'],
        dependencies: ['Основная БД'],
    },
    {
        id: 'marketplace-connections',
        name: 'Маркетплейсы и FBS',
        prefixes: ['/marketplace-connections', '/marketplace-connection', '/external/v1/fbs',
            '/marketplace-connections/fbs/size-substitution', '/marketplace-connections/fbs/repeat-assembly', '/marketplace-connection/fbs/repeat-assembly',
            '/marketplace-connections/fbs/reshipment', '/marketplace-connection/fbs/reshipment', '/marketplace-connections/allocation', '/marketplace-connections/duplicate-groups', '/marketplace-connections/stock-confirmation'],
        // FIX: preserve delivery-options plus six reshipment handlers; aliases count once.
        routeCount: 127, // FIX: includes read-only WB stock verification.
        description: 'Подключения WB/Ozon, заказы FBS, поставки, статусы, финансовые отчёты и распределение остатков.',
        logic: ['Перенос из доставки через расширение: после подтверждения выдаёт одну команду кабинету WB, затем независимо проверяет поставки и новый стикер; токены кабинета остаются в браузере.', 'Учёт по статусу WB: решение менеджера после проверки WB; точная пара КИЗ–ШК списывается и сохраняется в истории отгрузок, неизвестный источник — без короба.', 'Замена размера WB: ADMIN/OWNER подтверждает переклейку, создаётся локальная заявка без списания до отбора.', 'Синхронизирует кабинеты, склады и заказы.', 'Сверяет активные поставки WB с заявками WMS и показывает отсутствующие привязки без записи в WB.', 'Резервирует товар WMS и передаёт статусы сборки.', 'Проверяет поставки филиала и создаёт локальные заявки FBS ДОВОЗ без повторной отправки статуса в WB.', 'Повторная отгрузка / довоз: проверяет доступность функции и заказы без изменений; после подтверждения администратора создаёт поставку WB и связанную заявку WMS, продолжает сохранённую операцию без дублирования.', 'Получает финансовые штрафы FBS без передачи токена WB в браузер.', 'Рассчитывает и выгружает распределённые остатки по складам.'],
        dependencies: ['Основная БД', 'WB API', 'Ozon API'],
    },
    {
        id: 'mobile',
        name: 'Мобильное приложение',
        prefixes: ['/mobile'],
        routeCount: 17,
        description: 'Сессии мобильных устройств, команды, синхронизация и автономные операции.',
        logic: ['Регистрирует устройство и сессию.', 'Передаёт команды и получает результаты.', 'Защищает повторные запросы идемпотентностью.'],
        dependencies: ['Основная БД', 'JWT устройства'],
    },
    {
        id: 'own-companies',
        name: 'Собственные компании',
        prefixes: ['/own-companies'],
        routeCount: 6,
        description: 'Реквизиты юридических лиц исполнителя для договоров и счетов.',
        logic: ['Хранит компании и банковские реквизиты.', 'Назначает компанию по умолчанию.', 'Использует реквизиты в документах клиентов.'],
        dependencies: ['Основная БД'],
    },
    {
        id: 'ozon-fbo',
        name: 'Ozon FBO',
        prefixes: ['/ozon-fbo'],
        routeCount: 19,
        description: 'Заявки и операции поставок Ozon по схеме FBO.',
        logic: ['Получает и хранит поставки Ozon.', 'Собирает состав и упаковочные данные.', 'Контролирует статусы подготовки и отгрузки.'],
        dependencies: ['Основная БД', 'Ozon API', 'Склад'],
    },
    {
        id: 'print',
        name: 'Печать',
        prefixes: ['/print', '/print/kiz-duplicates'],
        routeCount: 31, // FIX: preserve duplicate KIZ routes and add five print-agent routes.
        description: 'Очереди печати, шаблоны, принтеры и повторная печать этикеток.',
        logic: ['Формирует задания печати.', 'Маршрутизирует задание в группу принтеров.', 'Хранит статус, ошибки и историю повторов.', 'Передаёт товарные и серийные этикетки действующим агентам печати.', 'Дубль КИЗ: исходный код, подпись товара и проверка повторным сканом; без изменения остатков и WB. Включается отдельно.'],
        dependencies: ['Основная БД', 'Принтеры/агент печати'],
    },
    {
        id: 'service',
        name: 'Сервисный центр',
        prefixes: ['/service', '/service/unprinted-kiz'],
        routeCount: 21, // FIX: preserve WB print inspection and add three KIZ search routes.
        description: 'Сервисные обращения, диагностика и история ремонтных работ.',
        logic: ['Регистрирует обращение и устройство.', 'Ведёт этапы диагностики и ремонта.', 'Формирует read-only рекомендации по оптимизации хранения.', 'Хранит исполнителей, комментарии и результат.'],
        dependencies: ['Основная БД'],
    },
    {
        id: 'skus',
        name: 'Товары и SKU',
        prefixes: ['/skus'],
        routeCount: 16,
        description: 'Карточки товаров, штрихкоды, характеристики и связи маркетплейсов.',
        logic: ['Создаёт и обновляет SKU.', 'Управляет штрихкодами и заменой ошибочного ШК.', 'Связывает товар с артикулом и идентификатором маркетплейса.'],
        dependencies: ['Основная БД'],
    },
    {
        id: 'stock',
        name: 'Остатки',
        prefixes: ['/stock'],
        routeCount: 23,
        description: 'Доступные, резервные и физические остатки WMS и их движения.',
        logic: ['Считает остаток по коробу, SKU, клиенту и филиалу.', 'Создаёт движения при приёмке, резерве и отгрузке.', 'Формирует отчёты и сверки остатков.'],
        dependencies: ['Основная БД', 'Складские движения'],
    },
    {
        id: 'tsd',
        name: 'ТСД',
        prefixes: ['/tsd', '/tsd/requests/:id/fbo'],
        routeCount: 94, // FIX: compact FBO acknowledgement and read-only operation-status handlers.
        description: 'Приёмка, размещение, сборка FBS/ФБО, перемещения и синхронизация ТСД.',
        logic: ['Выдаёт следующее действие сборщику.', 'Проверяет паллет-сорт, короб, товар и КИЗ.', 'Фиксирует сканы, операции и восстановление сессий устройства.', 'При включённом WMS_FBO_TWO_STAGE_ENABLED ведёт отбор ФБО, упаковку и финальные сканы всех коробов перед двумя файлами WB: общий состав и распределение по коробам.', 'При WMS_FBO_FAST_ACK_ENABLED подтверждает сохранённую операцию отдельно от маршрута и проверяет её результат без повторного списания.'],
        dependencies: ['Основная БД', 'Склад', 'JWT устройства'],
    },
    {
        id: 'turnover',
        name: 'Товарооборот',
        prefixes: ['/turnover'],
        routeCount: 15,
        description: 'История движения товара и отчёты по операциям, КИЗ и отгрузкам.',
        logic: ['Объединяет приёмку, перемещения, резерв и отгрузку.', 'Фильтрует историю по товару, клиенту и периоду.', 'Формирует выгружаемые отчёты.'],
        dependencies: ['Основная БД', 'Складские движения'],
    },
    {
        id: 'users',
        name: 'Пользователи и права',
        prefixes: ['/users'],
        routeCount: 10,
        description: 'Учетные записи, роли, права и доступ к филиалам.',
        logic: ['Создаёт и блокирует пользователей.', 'Удаление архивирует учётную запись и закрывает доступ с сохранением истории. Администратор удаляет сотрудников закреплённого филиала, кроме администраторов и owner; owner — любого пользователя.', 'Назначает роли и разрешения.', 'Ограничивает клиентские и складские области доступа.'],
        dependencies: ['Основная БД'],
    },
    {
        id: 'warehouse',
        name: 'Склад и размещение',
        prefixes: ['/warehouse', '/warehouse/storage-locations'],
        // FIX: 30 warehouse handlers plus 12 storage-location handlers.
        routeCount: 42,
        description: 'Короба, паллет-сорты, зоны, ячейки и физическое размещение товара.',
        logic: ['Создаёт и изменяет складские места.', 'Размещает и перемещает короба.', 'Показывает содержимое и актуальную иерархию хранения.'],
        dependencies: ['Основная БД', 'Складские движения'],
    },
    {
        id: 'wms-ai',
        name: 'WMS AI',
        prefixes: ['/wms-ai'],
        routeCount: 3,
        description: 'Внутренний помощник для анализа WMS на основании разрешённых данных.',
        logic: ['Принимает диагностический запрос.', 'Собирает безопасный контекст WMS.', 'Возвращает объяснение без прямого изменения склада.'],
        dependencies: ['Основная БД', 'Настроенная AI-модель'],
    },
]);
let AdministrationInternalApiService = class AdministrationInternalApiService {
    prisma;
    auditLog;
    restartScheduled = false;
    constructor(prisma, auditLog) {
        this.prisma = prisma;
        this.auditLog = auditLog;
    }
    // ADDED: This is a bounded readiness check, not request instrumentation.
    async overview(user) {
        const databaseStartedAt = Date.now();
        let databaseStatus = 'WORKING';
        let databaseMessage = 'Основная БД отвечает.';
        try {
            await this.prisma.$queryRaw `SELECT 1`;
        }
        catch {
            databaseStatus = 'ERROR';
            // FIX: Do not expose a connection string or database host through a raw driver error.
            databaseMessage = 'Основная БД не ответила. Проверьте журнал API на сервере.';
        }
        const databaseLatencyMs = Date.now() - databaseStartedAt;
        const modules = exports.INTERNAL_API_DEFINITIONS.map((definition) => {
            const requiresDatabase = definition.requiresDatabase !== false;
            const status = requiresDatabase && databaseStatus === 'ERROR' ? 'DEGRADED' : 'WORKING';
            return {
                ...definition,
                status,
                statusText: status === 'WORKING'
                    ? 'Маршруты загружены, базовая проверка пройдена.'
                    : 'Маршруты загружены, но основная БД недоступна.',
            };
        });
        const canRestart = this.canRestart(user);
        return {
            checkedAt: new Date().toISOString(),
            scopeNote: 'Статус подтверждает загрузку маршрутов и доступность основной БД. Внешние WB, Ozon, ЧЗ, принтеры и AI проверяются в профильных разделах.',
            summary: {
                modules: modules.length,
                routes: modules.reduce((sum, module) => sum + module.routeCount, 0),
                working: modules.filter((module) => module.status === 'WORKING').length,
                degraded: modules.filter((module) => module.status === 'DEGRADED').length,
            },
            runtime: {
                status: 'WORKING',
                uptimeSeconds: Math.floor(process.uptime()),
                startedAt: new Date(Date.now() - process.uptime() * 1000).toISOString(),
                memoryMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
                nodeVersion: process.version,
                environment: process.env.NODE_ENV ?? 'development',
            },
            dependencies: {
                database: {
                    status: databaseStatus,
                    latencyMs: databaseLatencyMs,
                    message: databaseMessage,
                },
            },
            restart: {
                enabled: this.restartEnabled(),
                scheduled: this.restartScheduled,
                canRestart,
                confirmation: exports.INTERNAL_API_RESTART_CONFIRMATION,
                disabledReason: this.restartDisabledReason(user),
            },
            modules,
        };
    }
    // ADDED: The API exits only after audit persistence and the HTTP response has time to leave.
    async restart(body, user) {
        if (!user.permissionCodes.includes('system:admin')) {
            throw new common_1.ForbiddenException('Перезапуск API доступен только системному администратору.');
        }
        if (!this.restartEnabled()) {
            throw new common_1.ServiceUnavailableException('Самоперезапуск API отключён настройкой API_SELF_RESTART_ENABLED.');
        }
        if (body.confirmation !== exports.INTERNAL_API_RESTART_CONFIRMATION) {
            throw new common_1.BadRequestException(`Введите точную фразу: ${exports.INTERNAL_API_RESTART_CONFIRMATION}`);
        }
        if (process.uptime() < 30) {
            throw new common_1.ConflictException('API был запущен менее 30 секунд назад. Дождитесь завершения запуска.');
        }
        if (this.restartScheduled) {
            throw new common_1.ConflictException('Перезапуск API уже запланирован.');
        }
        this.restartScheduled = true;
        try {
            await this.auditLog.write({
                userId: user.id,
                action: 'administration.internal-api.restart',
                entity: 'SystemApi',
                entityId: 'api',
                payload: {
                    requestedAt: new Date().toISOString(),
                    userEmail: user.email,
                    uptimeSeconds: Math.floor(process.uptime()),
                },
            });
        }
        catch (error) {
            this.restartScheduled = false;
            throw error;
        }
        const acceptedAt = new Date().toISOString();
        setTimeout(() => process.exit(0), 1_500).unref();
        return {
            accepted: true,
            acceptedAt,
            message: 'Команда принята. API-контейнер завершит процесс и будет поднят политикой Docker restart: unless-stopped.',
        };
    }
    restartEnabled() {
        return process.env.API_SELF_RESTART_ENABLED?.trim().toLowerCase() === 'true';
    }
    canRestart(user) {
        return user.permissionCodes.includes('system:admin')
            && this.restartEnabled()
            && process.uptime() >= 30
            && !this.restartScheduled;
    }
    restartDisabledReason(user) {
        if (!user.permissionCodes.includes('system:admin'))
            return 'Недостаточно прав system:admin.';
        if (!this.restartEnabled())
            return 'Включите API_SELF_RESTART_ENABLED=true на сервере.';
        if (process.uptime() < 30)
            return 'API ещё завершает запуск.';
        if (this.restartScheduled)
            return 'Перезапуск уже выполняется.';
        return null;
    }
};
exports.AdministrationInternalApiService = AdministrationInternalApiService;
exports.AdministrationInternalApiService = AdministrationInternalApiService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        audit_log_service_1.AuditLogService])
], AdministrationInternalApiService);
