"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FulfillmentAnalyticsService = exports.fulfillmentAnalyticsEnabled = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const fulfillment_math_1 = require("./fulfillment-math");
const fulfillment_groups_1 = require("./fulfillment-groups");
const fulfillmentAnalyticsEnabled = () => process.env.WMS_FULFILLMENT_ANALYTICS_ENABLED === 'true';
exports.fulfillmentAnalyticsEnabled = fulfillmentAnalyticsEnabled;
let FulfillmentAnalyticsService = class FulfillmentAnalyticsService {
    prisma;
    scopes;
    constructor(prisma, scopes) {
        this.prisma = prisma;
        this.scopes = scopes;
    }
    enabled() { if (!(0, exports.fulfillmentAnalyticsEnabled)())
        throw new common_1.NotFoundException('Аналитика отгрузок не включена.'); }
    warehouseScope(user) { const clientOnly = user.roleCodes.includes('CLIENT') && !user.roleCodes.some(r => ['ADMIN', 'OWNER', 'MANAGER', 'OPERATOR'].includes(r)); return clientOnly || user.permissionCodes.includes('system:admin') || user.roleCodes.includes('OWNER') ? undefined : { in: user.warehouseIds ?? [] }; }
    async clients(user) {
        this.enabled();
        const filter = this.scopes.resolveClientFilter(user);
        const clients = await this.prisma.client.findMany({ where: { id: filter, isDemo: !!user.isDemo, status: { not: 'ARCHIVED' } }, select: { id: true, name: true, code: true }, orderBy: { name: 'asc' } });
        const links = await this.prisma.warehouseClient.findMany({ where: { clientId: { in: clients.map(c => c.id) }, warehouseId: this.warehouseScope(user) }, select: { clientId: true, warehouse: { select: { id: true, name: true } } } });
        return clients.map(c => ({ ...c, warehouses: links.filter(l => l.clientId === c.id).map(l => l.warehouse) }));
    }
    async dashboard(q, user) {
        this.enabled();
        if (!q.clientId || !q.warehouseId)
            throw new common_1.BadRequestException('Выберите клиента и склад ФФ.');
        this.scopes.requireClientAccess(user, q.clientId, 'read');
        const allowed = this.warehouseScope(user);
        if (allowed && !allowed.in.includes(q.warehouseId))
            throw new common_1.ForbiddenException('Нет доступа к складу.');
        const o = { dateFrom: q.dateFrom, dateTo: q.dateTo, channel: q.channel, leadDays: q.leadDays ?? 7, reviewDays: q.reviewDays ?? 7, safetyDays: q.safetyDays ?? 3, asOf: new Date().toISOString() };
        try {
            (0, fulfillment_math_1.validateFulfillmentOptions)(o);
        }
        catch (e) {
            throw new common_1.BadRequestException(e.message);
        }
        const client = await this.prisma.client.findFirst({ where: { id: q.clientId, isDemo: !!user.isDemo }, select: { id: true, name: true, code: true } });
        if (!client)
            throw new common_1.NotFoundException('Клиент не найден.');
        const link = await this.prisma.warehouseClient.findFirst({ where: { clientId: q.clientId, warehouseId: q.warehouseId }, select: { warehouse: { select: { id: true, name: true } } } });
        if (!link)
            throw new common_1.ForbiddenException('Склад не подключён к клиенту.');
        const from = new Date(q.dateFrom + 'T00:00:00+03:00'), until = new Date(new Date(q.dateTo + 'T00:00:00+03:00').getTime() + 86400000), asOf = new Date(o.asOf);
        // FIX: classify only explicit FBS/FBO relations. Do not label B2B shipments as FBO.
        const completed = client_1.Prisma.sql `WITH completed AS (
   SELECT r.id, MIN(e."createdAt") AS at,
    CASE WHEN EXISTS(SELECT 1 FROM "FbsOrderRequestLink" l WHERE l."requestId"=r.id AND l."clientId"=r."clientId") THEN 'FBS'
     WHEN EXISTS(SELECT 1 FROM "FboAssembly" a WHERE a."requestId"=r.id) OR EXISTS(SELECT 1 FROM "OzonFboShipment" a WHERE a."requestId"=r.id)
      OR EXISTS(SELECT 1 FROM "YandexFbyShipment" a WHERE a."requestId"=r.id) OR EXISTS(SELECT 1 FROM "LamodaFboAssembly" a WHERE a."requestId"=r.id) THEN 'FBO' ELSE 'OTHER' END AS channel
   FROM "ClientRequest" r JOIN "ClientRequestEvent" e ON e."requestId"=r.id AND e."clientId"=r."clientId" AND e."statusTo"='DONE'
   WHERE r."clientId"=${q.clientId} AND r."warehouseId"=${q.warehouseId} AND r.type='OUTBOUND' AND r.status='DONE'
   GROUP BY r.id HAVING MIN(e."createdAt")>=${from} AND MIN(e."createdAt")<${until}
  )`;
        const data = await this.prisma.$transaction(async (tx) => {
            await tx.$executeRawUnsafe('SET TRANSACTION READ ONLY');
            const products = await tx.$queryRaw(client_1.Prisma.sql `
    WITH movements AS (
     SELECT "skuId",MIN("createdAt") FILTER(WHERE type='RECEIPT' AND quantity>0) AS first_receipt,
      COALESCE(SUM(quantity) FILTER(WHERE type='RECEIPT' AND quantity>0 AND "createdAt">=${from} AND "createdAt"<${until}),0)::float AS received,
      COALESCE(SUM(quantity) FILTER(WHERE type='RETURN' AND quantity>0 AND "createdAt">=${from} AND "createdAt"<${until}),0)::float AS returned,
      COALESCE(SUM(quantity) FILTER(WHERE status<>'IN_TRANSIT'),0)::float AS ledger
     FROM "StockMovement" WHERE "clientId"=${q.clientId} AND "warehouseId"=${q.warehouseId} GROUP BY "skuId"
    ), receipts AS (
     SELECT "boxId",MIN("createdAt") AS at FROM "StockMovement" WHERE "clientId"=${q.clientId} AND "warehouseId"=${q.warehouseId} AND type='RECEIPT' AND quantity>0 AND "boxId" IS NOT NULL GROUP BY "boxId"
    ), balances AS (
     SELECT b."skuId",SUM(b.quantity)::float AS total,
      COALESCE(SUM(b.quantity) FILTER(WHERE b.status='AVAILABLE'),0)::float AS available,
      COALESCE(SUM(b.quantity) FILTER(WHERE b.status IN ('RESERVED','PACKING','SHIPPING')),0)::float AS allocated,
      COALESCE(SUM(b.quantity) FILTER(WHERE COALESCE(i."receiptAt",r.at)<=${asOf} AND b.quantity>0),0)::float AS known,
      COALESCE(SUM(b.quantity*EXTRACT(EPOCH FROM (${asOf}::timestamp-COALESCE(i."receiptAt",r.at)))/86400) FILTER(WHERE COALESCE(i."receiptAt",r.at)<=${asOf} AND b.quantity>0),0)::float AS age
     FROM "StockBalance" b LEFT JOIN "ReceiptStockIdentity" i ON i."boxId"=b."boxId" LEFT JOIN receipts r ON r."boxId"=b."boxId"
     WHERE b."clientId"=${q.clientId} AND b."warehouseId"=${q.warehouseId} AND b.status<>'IN_TRANSIT' GROUP BY b."skuId"
    ), pending AS (
     SELECT i."skuId",SUM(GREATEST(i.quantity,0))::float AS units FROM "ClientRequestItem" i JOIN "ClientRequest" r ON r.id=i."requestId"
     WHERE r."clientId"=${q.clientId} AND r."warehouseId"=${q.warehouseId} AND r.type='OUTBOUND' AND r.status NOT IN ('DONE','CANCELLED','REJECTED') GROUP BY i."skuId"
    ) SELECT s.id AS "skuId",s.name,s.article,s.size,s.color,s.category,s.brand,
     jsonb_build_object('fabricRollBinding',s."marketplacePayload"->'fabricRollBinding') AS "marketplacePayload",
     COALESCE(m.received,0) AS "receivedUnits",COALESCE(m.returned,0) AS "returnedUnits",
     COALESCE(b.total,0) AS "currentUnits",COALESCE(b.available,0) AS "availableUnits",COALESCE(b.allocated,0) AS "allocatedUnits",COALESCE(p.units,0) AS "openDemandUnits",
     m.first_receipt AS "firstReceiptAt",COALESCE(b.age,0) AS "ageUnitDays",COALESCE(b.known,0) AS "ageKnownUnits",0::float AS "shippedAgeUnitDays",0::float AS "shippedAgeKnownUnits",COALESCE(m.ledger,0) AS "ledgerUnits"
    FROM "Sku" s LEFT JOIN movements m ON m."skuId"=s.id LEFT JOIN balances b ON b."skuId"=s.id LEFT JOIN pending p ON p."skuId"=s.id WHERE s."clientId"=${q.clientId}
    ORDER BY s.id LIMIT 20001`);
            if (products.length > 20000)
                throw new common_1.BadRequestException('Слишком большой каталог для этого отчёта: требуется отдельная выгрузка.');
            const shipments = await tx.$queryRaw(client_1.Prisma.sql `${completed}, quantities AS (
    SELECT c.id,c.at,i."skuId",SUM(GREATEST(i.quantity,0))::float AS units FROM completed c JOIN "ClientRequestItem" i ON i."requestId"=c.id
    JOIN "Sku" s ON s.id=i."skuId" AND s."clientId"=${q.clientId} WHERE c.channel=${q.channel} GROUP BY c.id,c.at,i."skuId"
   ), receipts AS (
    SELECT "boxId",MIN("createdAt") AS at FROM "StockMovement" WHERE "clientId"=${q.clientId} AND "warehouseId"=${q.warehouseId} AND type='RECEIPT' AND quantity>0 AND "boxId" IS NOT NULL GROUP BY "boxId"
   ), trace AS (
    SELECT m."sourceDocument" AS id,m."skuId",SUM(-m.quantity)::float AS units,
     COALESCE(SUM(-m.quantity) FILTER(WHERE COALESCE(i."receiptAt",r.at)<=m."createdAt"),0)::float AS known,
     COALESCE(SUM(-m.quantity*EXTRACT(EPOCH FROM (m."createdAt"-COALESCE(i."receiptAt",r.at)))/86400) FILTER(WHERE COALESCE(i."receiptAt",r.at)<=m."createdAt"),0)::float AS age
    FROM "StockMovement" m JOIN completed c ON c.id=m."sourceDocument" LEFT JOIN "ReceiptStockIdentity" i ON i."boxId"=m."boxId" LEFT JOIN receipts r ON r."boxId"=m."boxId"
    WHERE m."clientId"=${q.clientId} AND m."warehouseId"=${q.warehouseId} AND m.type='SHIP' AND m.quantity<0 GROUP BY m."sourceDocument",m."skuId"
   ) SELECT q."skuId",to_char(q.at+interval '3 hours','YYYY-MM-DD') AS date,SUM(q.units)::float AS units,COUNT(*)::int AS requests,array_agg(DISTINCT q.id) AS "requestIds",
    COALESCE(SUM(t.known) FILTER(WHERE t.units<=q.units),0)::float AS known,COALESCE(SUM(t.age) FILTER(WHERE t.units<=q.units),0)::float AS age
   FROM quantities q LEFT JOIN trace t ON t.id=q.id AND t."skuId"=q."skuId" GROUP BY q."skuId",date ORDER BY date,q."skuId"`);
            const deltas = await tx.$queryRaw(client_1.Prisma.sql `SELECT "skuId",to_char("createdAt"+interval '3 hours','YYYY-MM-DD') AS date,SUM(quantity)::float AS quantity FROM "StockMovement"
    WHERE "clientId"=${q.clientId} AND "warehouseId"=${q.warehouseId} AND status<>'IN_TRANSIT' AND "createdAt">=${from} GROUP BY "skuId",date`);
            const quality = await tx.$queryRaw(client_1.Prisma.sql `${completed} SELECT
    (SELECT COUNT(*)::int FROM completed WHERE channel='OTHER') AS "unclassifiedRequests",
    (SELECT COALESCE(SUM(GREATEST(i.quantity,0)),0)::float FROM completed c JOIN "ClientRequestItem" i ON i."requestId"=c.id LEFT JOIN "Sku" s ON s.id=i."skuId" AND s."clientId"=${q.clientId} WHERE c.channel=${q.channel} AND s.id IS NULL) AS "missingSkuUnits",
    (SELECT COUNT(*)::int FROM completed WHERE channel=${q.channel}) AS "completedRequests"`);
            return { products, shipments, deltas, quality: quality[0] };
        }, { isolationLevel: client_1.Prisma.TransactionIsolationLevel.RepeatableRead, timeout: 60000 });
        const ages = new Map();
        for (const s of data.shipments) {
            const a = ages.get(s.skuId) ?? { age: 0, known: 0 };
            a.age += s.age;
            a.known += s.known;
            ages.set(s.skuId, a);
        }
        const products = data.products.filter(p => p.currentUnits !== 0 || p.receivedUnits || p.returnedUnits || ages.has(p.skuId)).map(p => ({ ...p, firstReceiptAt: p.firstReceiptAt ? new Date(p.firstReceiptAt).toISOString() : null, shippedAgeUnitDays: ages.get(p.skuId)?.age ?? 0, shippedAgeKnownUnits: ages.get(p.skuId)?.known ?? 0 }));
        // FIX: retain private catalog evidence server-side; only derived grouping labels reach the report.
        const facts = products.map(({ category, brand, marketplacePayload, ...fact }) => fact);
        const result = (0, fulfillment_math_1.analyzeFulfillment)(facts, data.shipments, data.deltas, o);
        return { ...result, groups: (0, fulfillment_groups_1.groupFulfillment)(products, data.shipments, data.deltas, o, result.items), client, warehouse: link.warehouse, quality: data.quality };
    }
};
exports.FulfillmentAnalyticsService = FulfillmentAnalyticsService;
exports.FulfillmentAnalyticsService = FulfillmentAnalyticsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], FulfillmentAnalyticsService);
