"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientKizReviewRequired = exports.clientUseContext = exports.clientUseTaskKey = void 0;
exports.clientPhysicalMark = clientPhysicalMark;
exports.assertClientKizUse = assertClientKizUse;
exports.queueClientKizReview = queueClientKizReview;
exports.withClientKizReview = withClientKizReview;
exports.queueFboKizError = queueFboKizError;
exports.queueReceiptKizReview = queueReceiptKizReview;
exports.clientReviewPresentation = clientReviewPresentation;
exports.decideClientKizReview = decideClientKizReview;
exports.finishClientKizUse = finishClientKizUse;
exports.assertClientRequestKizShipment = assertClientRequestKizShipment;
exports.finishClientRequestKizShipment = finishClientRequestKizShipment;
exports.refreshClientKizClaim = refreshClientKizClaim;
exports.assertFbsClientKiz = assertFbsClientKiz;
exports.strictLegacyQueueDecision = strictLegacyQueueDecision;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const client_1 = require("@prisma/client");
const kiz_client_registry_1 = require("./kiz-client-registry");
const kiz_shipment_reads_1 = require("./kiz-shipment-reads");
const ozon_unit_marks_1 = require("./ozon-unit-marks");
const ozon_fbs_pick_lines_1 = require("../modules/marketplace-connections/ozon-fbs-pick-lines");
const json = (v) => JSON.parse(JSON.stringify(v));
const digest = (v) => (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(v)).digest('hex');
const terminal = ['DONE', 'CANCELLED', 'REJECTED'];
const clientUseTaskKey = (i) => `GUARD:${i.scope}:${i.clientId}:${i.taskId || i.requestId || i.operationKey || digest([i.sourceDocument, i.boxId, i.kiz])}`;
exports.clientUseTaskKey = clientUseTaskKey;
const clientUseContext = (i) => digest([i.scope, i.clientId, i.warehouseId, i.requestId, i.taskId || '', i.skuId || '', i.boxId || '']);
exports.clientUseContext = clientUseContext;
const markVersion = (m) => m ? digest([m.id, m.clientId, m.skuId, m.boxId, m.status, m.updatedAt]) : null;
const filter = (key, field = 'kiz') => (0, kiz_client_registry_1.clientKizFilter)(key, field);
async function identityLock(tx, clientId, key) {
    await (0, kiz_client_registry_1.lockClientKiz)(tx, clientId, key);
}
async function clientPhysicalMark(db, clientId, kiz, read) {
    const key = (0, kiz_client_registry_1.clientKizIdentity)(kiz);
    if (!key)
        throw new common_1.BadRequestException('Не удалось определить GTIN и серийный номер КИЗ.');
    const matches = (read?.marks ?? await db.productMark.findMany({ where: { clientId, ...filter(key, 'value') }, include: { box: true, sku: true } }))
        .filter((m) => (0, kiz_client_registry_1.clientKizIdentity)(m.value) === key);
    if (matches.length > 1) {
        const error = new common_1.ConflictException('ДУБЛЬ КИЗ. Найдено несколько записей у клиента. ОТЛОЖИТЕ ТОВАР и передайте администратору.');
        error.clientKizAmbiguity = { clientId, kiz };
        throw error;
    }
    return matches[0] ?? null;
}
async function history(db, i, read) {
    const key = (0, kiz_client_registry_1.clientKizIdentity)(i.kiz);
    const [shipments, units, consumed] = read ? [read.shipments, read.historyUnits, read.consumed] : await Promise.all([
        db.shippedKizHistory.findMany({ where: { clientId: i.clientId, ...filter(key) }, orderBy: { shippedAt: 'desc' }, take: 501 }),
        db.fboAssemblyUnit.findMany({ where: { state: { not: 'RETURNED' }, ...filter(key),
                assembly: { request: { clientId: i.clientId, status: 'DONE' } } }, include: { assembly: { include: { request: true } } }, take: 501 }),
        db.kizReviewCase.findMany({ where: { clientId: i.clientId, kizIdentity: key, status: 'USED', taskId: { startsWith: 'GUARD:' } }, take: 501 }),
    ]);
    const own = (v) => (0, kiz_client_registry_1.clientKizIdentity)(v.kiz ?? '') === key;
    const events = [...shipments.filter(own).map((s) => ({ id: `SHIP:${s.id}`, at: s.shippedAt, requestId: s.requestId,
            request: { number: s.requestNumber, warehouseId: s.warehouseId }, orderId: s.orderId, boxCode: s.sourceBoxCode, event: 'Подтверждённая отгрузка WMS' })),
        ...units.filter(own).map((u) => ({ id: `FBO:${u.id}`, at: u.assembly?.request?.updatedAt, requestId: u.requestId,
            request: { number: u.assembly?.request?.number, warehouseId: u.assembly?.request?.warehouseId }, boxCode: u.sourceBoxCode, event: 'Отгрузка FBO, заявка сдана' })),
        ...consumed.map((c) => ({ id: `CONSUMED:${c.id}`, at: c.usedAt, requestId: c.requestId, request: { warehouseId: c.warehouseId }, event: 'Разрешение погашено при отгрузке' }))];
    const remote = (i.externalEvidence?.orders ?? []).filter((o) => o.verified && o.containsKiz && (o.wbStatus === 'sold' || o.supplierStatus === 'complete'));
    for (const o of remote)
        events.push({ id: `WB:${o.orderId}`, at: null, requestId: '', request: null, orderId: o.orderId, boxCode: null, event: 'Подтверждённое использование в WB' });
    const truncated = shipments.length > 500 || units.length > 500 || consumed.length > 500;
    return { history: events, orders: i.externalEvidence?.orders ?? [], circulation: i.externalEvidence?.circulation ?? null,
        checkedAt: new Date().toISOString(), decision: events.length || truncated ? 'REVIEW' : 'ALLOW', truncated,
        fingerprint: digest(events.map((e) => e.id).sort()) };
}
function required(i) {
    if (!i.clientId || !i.warehouseId || !(0, kiz_client_registry_1.clientKizIdentity)(i.kiz))
        throw new common_1.BadRequestException('Не определены клиент, филиал или КИЗ.');
    if (i.scope !== 'RECEIPT' && !i.requestId)
        throw new common_1.BadRequestException('Не определена заявка для проверки КИЗ.');
}
async function currentContext(db, i, allowPendingReview = false) {
    if (i.scope === 'RECEIPT')
        return null;
    const request = await db.clientRequest.findUnique({ where: { id: i.requestId } });
    if (!request || request.clientId !== i.clientId || request.warehouseId !== i.warehouseId || ['CANCELLED', 'REJECTED'].includes(request.status))
        throw new common_1.ConflictException('Заявка или клиент изменились. Повторите проверку КИЗ.');
    if (i.scope === 'FBS') {
        const task = await db.fbsTsdAssembly.findUnique({ where: { id: i.taskId } });
        // FIX: a multi-product posting owns each recorded unit, not only the scalar first SKU.
        const state = (0, ozon_unit_marks_1.ozonUnitMarksEnabled)() && task?.marketplace === 'OZON' && !task.kiz ? await (0, ozon_fbs_pick_lines_1.readOzonPickState)(db, task.id) : null;
        let unit = state?.unitMarksVersion === 1
            ? (0, ozon_unit_marks_1.ozonMarkedUnits)(task, state).find(u => (0, kiz_client_registry_1.clientKizIdentity)(u.kiz) === (0, kiz_client_registry_1.clientKizIdentity)(i.kiz)) : task;
        // FIX: a refused scan rolls back its candidate pick; review alone can use the pending line.
        // Claiming and shipment still require a recorded unit, never this fallback.
        if (!unit && allowPendingReview && process.env.WMS_OZON_TSD_UNIT_MARKS_ENABLED === 'true' &&
            state?.unitMarksVersion === 1 && state.submission === 'PICKING' && !state.recovery && state.pendingBarcode && state.source) {
            const line = (0, ozon_fbs_pick_lines_1.ozonActiveLine)(state);
            if (line?.requiresKiz && line.barcodes.includes(state.pendingBarcode))
                unit = { skuId: line.skuId, boxId: state.source.boxId };
        }
        if (!task || !unit || task.clientId !== i.clientId || task.requestId !== i.requestId || unit.skuId !== i.skuId || unit.boxId !== (i.boxId ?? null))
            throw new common_1.ConflictException('Задание или исходный короб изменились. Повторите проверку КИЗ.');
    }
    return request;
}
class ClientKizReviewRequired extends common_1.ConflictException {
    reviewInput;
    constructor(reviewInput, evidence) {
        // FIX: an altered claim is not evidence of shipment; show actual provenance only.
        const events = (evidence?.history ?? []).filter((h) => h.id?.startsWith('SHIP:') || h.id?.startsWith('FBO:') || h.id?.startsWith('WB:'));
        const details = events.slice(0, 3).map((h) => {
            if (h.request?.warehouseId && h.request.warehouseId !== reviewInput.warehouseId)
                return 'Отгрузка в другом филиале; подробности доступны администратору.';
            const date = h.at ? new Date(h.at).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' }) : 'дата не установлена';
            return `${date} (МСК) · ${h.orderId ? `заказ ${h.orderId}` : `заявка №${h.request?.number ?? 'не установлена'}`}.`;
        }).join(' ');
        super({ code: 'KIZ_REVIEW_REQUIRED', message: `ОТЛОЖИТЕ ТОВАР. ${events.length ? 'КИЗ ранее отгружался. ' + details : 'КИЗ требует проверки привязки или истории; предыдущая отгрузка не подтверждена.'} Продолжение — только после решения администратора в «КИЗ → Проверки КИЗ».` });
        this.reviewInput = reviewInput;
    }
}
exports.ClientKizReviewRequired = ClientKizReviewRequired;
async function assertNoCompetingClaim(tx, i, key, currentId, read) {
    const claims = read ? read.claims.filter(c => c.id !== currentId) : await tx.kizReviewCase.findMany({ where: { clientId: i.clientId, kizIdentity: key, ...(currentId ? { id: { not: currentId } } : {}), status: 'CLAIMED', taskId: { startsWith: 'GUARD:' } } });
    for (const claim of claims) {
        const request = await tx.clientRequest.findUnique({ where: { id: claim.requestId } });
        // A cancelled never-shipped attempt may release its claim; completed shipment never does.
        if (request && ['CANCELLED', 'REJECTED'].includes(request.status) && claim.resolution === 'FIRST_USE') {
            const prior = claim.snapshot?.clientGuard?.input;
            const oldHistory = prior ? await history(tx, { ...prior, requestId: '' }) : null;
            const mark = await clientPhysicalMark(tx, i.clientId, i.kiz, read);
            // FIX: scalar-null Ozon tasks can still hold several physical KIZs.
            const rawTasks = await tx.fbsTsdAssembly.findMany({ where: { clientId: i.clientId, requestId: claim.requestId, ...((0, ozon_unit_marks_1.ozonUnitMarksEnabled)() ? { OR: [{ kiz: { not: null } }, { marketplace: 'OZON' }] } : { kiz: { not: null } }), status: { in: ['IN_PROGRESS', 'COMPLETED', 'RETURN_REQUIRED'] } } });
            const tasks = await (0, ozon_unit_marks_1.expandOzonMarkedTasks)(tx, rawTasks);
            const units = await tx.fboAssemblyUnit.findMany({ where: { requestId: claim.requestId, activeMarkId: { not: null }, state: { not: 'RETURNED' } } });
            if (oldHistory?.decision === 'ALLOW' && mark?.status === 'AVAILABLE' && !tasks.length && !units.length) {
                await tx.kizReviewCase.update({ where: { id: claim.id }, data: { status: 'RESOLVED' } });
                continue;
            }
        }
        throw new common_1.ConflictException('Этот КИЗ уже закреплён за другой сборкой. ОТЛОЖИТЕ ТОВАР.');
    }
}
async function ownExpectedMovement(tx, i, mark, proof, read) {
    if (!mark)
        return !proof.markId;
    if (proof.markId && proof.markId !== mark.id || mark.clientId !== i.clientId || i.skuId && mark.skuId !== i.skuId)
        return false;
    if (proof.markVersion === markVersion(mark))
        return true;
    if (i.scope === 'FBS') {
        const task = await tx.fbsTsdAssembly.findUnique({ where: { id: i.taskId } });
        const state = (0, ozon_unit_marks_1.ozonUnitMarksEnabled)() && task?.marketplace === 'OZON' && !task.kiz ? await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, task.id) : null;
        const unit = state?.unitMarksVersion === 1 ? (0, ozon_unit_marks_1.ozonMarkedUnits)(task, state).find(u => (0, kiz_client_registry_1.clientKizIdentity)(u.kiz) === (0, kiz_client_registry_1.clientKizIdentity)(i.kiz)) : task;
        if (!unit || (0, kiz_client_registry_1.clientKizIdentity)(unit.kiz ?? '') !== (0, kiz_client_registry_1.clientKizIdentity)(i.kiz))
            return false;
        if (!proof.markId && mark.status === 'AVAILABLE' && mark.boxId === (i.boxId ?? null) &&
            mark.sourceDocument?.startsWith(`FBS TSD, заказ ${task.orderId}:`))
            return true;
        // FIX: permanent boxes keep the source on the task, while the picked mark has no box.
        if (mark.status === 'PACKING' && task.wbMetaStatus === 'ACCEPTED' && task.stockWarehouseId === i.warehouseId &&
            (mark.boxId === null || mark.boxId === i.boxId)) {
            const movements = await tx.stockMovement.findMany({ where: { clientId: i.clientId, warehouseId: i.warehouseId,
                    sourceDocument: i.requestId, skuId: i.skuId, boxId: mark.boxId, status: 'PACKING',
                    idempotencyKey: { startsWith: `fbs-sticker-pick:${i.taskId}:` } }, select: { quantity: true } });
            if (movements.reduce((sum, m) => sum + m.quantity, 0) >= Math.max(1, task.itemCount))
                return true;
        }
        const movement = mark.stockMovementId ? await tx.stockMovement.findUnique({ where: { id: mark.stockMovementId } }) : null;
        return movement?.clientId === i.clientId && movement?.sourceDocument === i.requestId && movement?.skuId === i.skuId && movement?.boxId === mark.boxId &&
            ['PACKING', 'SHIPPING'].includes(mark.status) && movement.status === mark.status;
    }
    if (i.scope === 'FBO') {
        const units = read ? read.units.filter(u => u.markId === mark.id && ['PICKED', 'PACKED'].includes(u.state)) : await tx.fboAssemblyUnit.findMany({ where: { requestId: i.requestId, markId: mark.id, state: { in: ['PICKED', 'PACKED'] } } });
        return units.some((u) => u.skuId === mark.skuId && (0, kiz_client_registry_1.clientKizIdentity)(u.kiz ?? '') === (0, kiz_client_registry_1.clientKizIdentity)(i.kiz) &&
            (u.sourceBoxId || null) === (i.boxId || null) && ((u.state === 'PACKED' && u.targetBoxId === mark.boxId) ||
            (u.state === 'PICKED' && (u.wholeBox ? u.sourceBoxId === mark.boxId : mark.box?.code === `FBO-PICK-${i.requestId}`))));
    }
    return false;
}
async function assertNoActiveBinding(tx, i, key, read) {
    // FIX: search per-unit bindings as well as legacy scalar codes.
    const rawTasks = read?.tasks ?? await tx.fbsTsdAssembly.findMany({ where: { clientId: i.clientId, id: { not: i.taskId || '' }, ...((0, ozon_unit_marks_1.ozonUnitMarksEnabled)() ? { OR: [filter(key), { marketplace: 'OZON' }] } : filter(key)), status: { in: ['IN_PROGRESS', 'COMPLETED', 'RETURN_REQUIRED'] } } });
    const tasks = (await (0, ozon_unit_marks_1.expandOzonMarkedTasks)(tx, rawTasks)).filter((t) => (0, kiz_client_registry_1.clientKizIdentity)(t.kiz ?? '') === key);
    for (const task of tasks) {
        const request = await tx.clientRequest.findUnique({ where: { id: task.requestId } });
        if (!request || !terminal.includes(request.status))
            throw new common_1.ConflictException('КИЗ занят другой сборкой FBS. ОТЛОЖИТЕ ТОВАР.');
    }
    const units = (read?.bindings ?? await tx.fboAssemblyUnit.findMany({ where: { requestId: { not: i.requestId }, activeMarkId: { not: null }, ...filter(key), assembly: { request: { clientId: i.clientId } } }, include: { assembly: { include: { request: true } } } })).filter((u) => (0, kiz_client_registry_1.clientKizIdentity)(u.kiz ?? '') === key);
    if (units.some((u) => !terminal.includes(u.assembly?.request?.status)))
        throw new common_1.ConflictException('КИЗ занят другой сборкой FBO. ОТЛОЖИТЕ ТОВАР.');
}
// Caller owns the transaction. A refused transaction is persisted by withClientKizReview afterwards.
async function assertClientKizUse(tx, i, user, read) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return 'ALLOW';
    required(i);
    const key = (0, kiz_client_registry_1.clientKizIdentity)(i.kiz);
    if (read && (i.scope !== 'FBO' || read.identity !== key || read.request.id !== i.requestId || read.request.clientId !== i.clientId || read.request.warehouseId !== i.warehouseId))
        throw new common_1.ConflictException('Контекст пакетной проверки КИЗ изменился.');
    if (!read) {
        await identityLock(tx, i.clientId, key);
        await currentContext(tx, i);
    }
    const row = read ? read.rows.find(r => r.taskId === (0, exports.clientUseTaskKey)(i)) : await tx.kizReviewCase.findUnique({ where: { taskId_kizIdentity: { taskId: (0, exports.clientUseTaskKey)(i), kizIdentity: key } } });
    const e = await history(tx, { ...i, externalEvidence: i.externalEvidence ?? row?.snapshot?.clientGuard?.input?.externalEvidence }, read);
    let mark;
    try {
        mark = await clientPhysicalMark(tx, i.clientId, i.kiz, read);
    }
    catch (error) {
        if (error instanceof common_1.ConflictException)
            throw new ClientKizReviewRequired(i);
        throw error;
    }
    const proof = row?.snapshot?.clientGuard;
    await assertNoCompetingClaim(tx, i, key, row?.id, read);
    await assertNoActiveBinding(tx, i, key, read);
    if (e.decision === 'ALLOW') {
        if (row?.status === 'CLAIMED' && row.resolution === 'FIRST_USE' && row.context === (0, exports.clientUseContext)(i) && await ownExpectedMovement(tx, i, mark, proof, read))
            return 'ALLOW';
        if (['OPEN', 'CLAIMED', 'USED', 'REJECTED', 'CLOSED'].includes(row?.status))
            throw new ClientKizReviewRequired(i, row?.evidence ?? e);
        // FIX: receipt and picking serialize on the same identity, including an as-yet unregistered physical mark.
        // Unknown origin stays unknown; an existing genuine receipt is immutable and is never overwritten.
        await tx.$executeRaw(client_1.Prisma.sql `INSERT INTO "KizClientRegistry"
   ("clientId",identity,"firstWarehouseId","skuId","operationKey","sourceDocument","userId",source)
   VALUES (${i.clientId},${key},${i.warehouseId},${i.skuId ?? null},${(0, exports.clientUseTaskKey)(i)},${i.requestId},${user.id ?? null},'LEGACY_UNKNOWN')
   ON CONFLICT ("clientId",identity) DO NOTHING`);
        await tx.kizReviewCase.upsert({ where: { taskId_kizIdentity: { taskId: (0, exports.clientUseTaskKey)(i), kizIdentity: key } },
            create: { clientId: i.clientId, warehouseId: i.warehouseId, requestId: i.requestId, taskId: (0, exports.clientUseTaskKey)(i), kiz: i.kiz, kizIdentity: key, context: (0, exports.clientUseContext)(i),
                status: 'CLAIMED', decision: 'ALLOW', resolution: 'FIRST_USE', snapshot: json({ scope: i.scope, clientGuard: { version: 1, input: i, markId: mark?.id ?? null, markVersion: markVersion(mark), history: e.fingerprint } }), evidence: json(e) },
            update: { status: 'CLAIMED', decision: 'ALLOW', resolution: 'FIRST_USE', context: (0, exports.clientUseContext)(i), decidedById: null, decidedByName: null, decidedAt: null, usedAt: null,
                snapshot: json({ scope: i.scope, clientGuard: { version: 1, input: i, markId: mark?.id ?? null, markVersion: markVersion(mark), history: e.fingerprint } }), evidence: json(e) } });
        return 'ALLOW';
    }
    const valid = row && row.clientId === i.clientId && row.context === (0, exports.clientUseContext)(i) && row.decidedById && row.reason &&
        proof?.version === 1 && proof.history === e.fingerprint && !e.truncated && proof.markId === mark?.id &&
        (!i.skuId || mark?.skuId === i.skuId) && ['APPROVED', 'CLAIMED'].includes(row.status);
    if (!valid)
        throw new ClientKizReviewRequired(i, e);
    if (row.resolution === 'RELABEL' && i.allowRelabel)
        return 'RELABEL';
    if (row.resolution !== 'REUSE' || i.scope === 'RECEIPT')
        throw new ClientKizReviewRequired(i);
    if (row.status === 'APPROVED' && proof.markVersion !== markVersion(mark))
        throw new ClientKizReviewRequired(i);
    if (row.status === 'CLAIMED' && !await ownExpectedMovement(tx, i, mark, proof, read))
        throw new ClientKizReviewRequired(i);
    if (row.status === 'APPROVED') {
        await tx.kizReviewCase.update({ where: { id: row.id }, data: { status: 'CLAIMED' } });
        await tx.auditLog.create({ data: { userId: user.id, entity: 'KizReviewCase', entityId: row.id, action: 'KIZ_CLIENT_PERMISSION_CLAIMED', payload: json({ context: row.context, identity: key, requestId: i.requestId }) } });
    }
    return 'ALLOW';
}
async function queueClientKizReview(db, i, user) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        throw new common_1.ForbiddenException('Проверка КИЗ выключена.');
    required(i);
    return db.$transaction(async (tx) => {
        const key = (0, kiz_client_registry_1.clientKizIdentity)(i.kiz);
        await identityLock(tx, i.clientId, key);
        const request = await currentContext(tx, i, true), e = await history(tx, i);
        let mark = null;
        try {
            mark = await clientPhysicalMark(tx, i.clientId, i.kiz);
        }
        catch (error) {
            if (!(error instanceof common_1.ConflictException))
                throw error;
        }
        const old = await tx.kizReviewCase.findUnique({ where: { taskId_kizIdentity: { taskId: (0, exports.clientUseTaskKey)(i), kizIdentity: key } } });
        // FIX: a retry cannot erase already recorded shipment evidence from an open review.
        if (old?.status === 'CLOSED' && i.operationKey)
            return { id: old.id, status: 'CLOSED', message: 'Это обращение уже закрыто.' };
        if (old?.status === 'OPEN' && e.history.length === 0 && old.evidence?.history?.length) {
            e.history = old.evidence.history;
            e.decision = 'REVIEW';
            e.fingerprint = old.evidence.fingerprint;
        }
        const context = (0, exports.clientUseContext)(i), unchanged = old?.context === context && old?.snapshot?.clientGuard?.history === e.fingerprint;
        const task = i.scope === 'FBS' ? await tx.fbsTsdAssembly.findUnique({ where: { id: i.taskId } }) : null;
        const snapshot = { scope: i.scope, requestNumber: request?.number ?? null, orderId: task?.orderId ?? null, productName: mark?.sku?.name ?? i.receiptInfo?.productName ?? 'КИЗ',
            barcode: i.receiptInfo?.barcode ?? null, boxCode: mark?.box?.code ?? i.receiptInfo?.firstBoxCode ?? i.receiptInfo?.currentBoxCode ?? null, workerName: user.name, receiptInfo: i.receiptInfo,
            receiptDuplicateUnconfirmed: i.scope === 'RECEIPT' && i.receiptInfo?.serverConfirmed === false,
            clientGuard: { version: 1, input: json(i), markId: mark?.id ?? null, markVersion: markVersion(mark), history: e.fingerprint } };
        const reset = !unchanged || old?.resolution === 'FIRST_USE' || old?.status === 'APPROVED' && old?.snapshot?.clientGuard?.markVersion !== markVersion(mark);
        const row = await tx.kizReviewCase.upsert({ where: { taskId_kizIdentity: { taskId: (0, exports.clientUseTaskKey)(i), kizIdentity: key } },
            create: { clientId: i.clientId, warehouseId: i.warehouseId, requestId: i.requestId || '', taskId: (0, exports.clientUseTaskKey)(i), kiz: i.kiz, kizIdentity: key, context,
                status: 'OPEN', decision: 'REVIEW', snapshot: json(snapshot), evidence: json(e) },
            update: { attempts: { increment: 1 }, ...(reset ? { context, status: 'OPEN', resolution: null, reason: null, decidedById: null, decidedByName: null, decidedAt: null, usedAt: null, snapshot: json(snapshot), evidence: json(e) } : {}) } });
        if (!old || reset)
            await tx.auditLog.create({ data: { userId: user.id, entity: 'KizReviewCase', entityId: row.id, action: 'KIZ_CLIENT_REVIEW_OPENED', payload: json({ context, identity: key, previous: old ?? null }) } });
        return { id: row.id, status: row.status, message: 'Обращение находится в «КИЗ → Проверки КИЗ». Товар отложите.' };
    });
}
async function withClientKizReview(db, user, action, fboRequestId) {
    try {
        return await action();
    }
    catch (e) {
        if (fboRequestId)
            await queueFboKizError(db, fboRequestId, e, user);
        else if (e instanceof ClientKizReviewRequired) {
            await queueClientKizReview(db, e.reviewInput, user);
        }
        throw e;
    }
}
async function queueFboKizError(db, requestId, error, user) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return;
    if (error instanceof ClientKizReviewRequired) {
        await queueClientKizReview(db, error.reviewInput, user);
        return;
    }
    if (!error?.clientKizAmbiguity)
        return;
    const request = await db.clientRequest.findUnique({ where: { id: requestId } });
    if (request?.clientId !== error.clientKizAmbiguity.clientId)
        return;
    await queueClientKizReview(db, { scope: 'FBO', clientId: request.clientId, warehouseId: request.warehouseId, requestId, kiz: error.clientKizAmbiguity.kiz }, user);
}
async function queueReceiptKizReview(db, clients, body, user) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        throw new common_1.ForbiddenException('Проверка КИЗ выключена.');
    clients.requireClientAccess(user, body.clientId, 'write');
    if (!user.activeWarehouseId)
        throw new common_1.BadRequestException('Выберите филиал.');
    let duplicate = await (0, kiz_client_registry_1.lookupClientKiz)(db, body.clientId, body.kiz, user.activeWarehouseId);
    const box = body.boxCode ? await db.box.findUnique({ where: { code: body.boxCode } }) : null;
    if (box && (box.clientId !== body.clientId || box.warehouseId !== user.activeWarehouseId))
        throw new common_1.ForbiddenException('Нет доступа к коробу.');
    // FIX: a local repeated scan can precede the first receipt upload. Persist a report, never stock.
    if (!duplicate) {
        if (body.localDuplicate !== 'true' || !box || typeof body.sourceDocument !== 'string' || !body.sourceDocument.trim() ||
            typeof body.operationKey !== 'string' || !body.operationKey.trim() || !(0, kiz_client_registry_1.clientKizIdentity)(body.kiz))
            throw new common_1.ConflictException('КИЗ не найден среди ранее зарегистрированных.');
        duplicate = { identity: (0, kiz_client_registry_1.clientKizIdentity)(body.kiz), localDuplicate: true, serverConfirmed: false, currentBoxCode: box.code ?? body.boxCode,
            productName: 'Повторный скан КИЗ на ТСД', currentStatus: 'PENDING_RECEIPT' };
    }
    const scanTime = (value) => {
        if (typeof value !== 'string' || !/^\d{13}$/.test(value))
            return null;
        return new Date(Number(value)).toISOString();
    };
    duplicate = { ...duplicate, firstScanAt: scanTime(body.firstScanAt), repeatScanAt: scanTime(body.repeatScanAt),
        firstScanBox: typeof body.firstScanBox === 'string' ? body.firstScanBox.slice(0, 200) : null,
        repeatScanWorker: typeof body.repeatScanWorker === 'string' ? body.repeatScanWorker.slice(0, 200) : null,
        firstScanWorker: typeof body.firstScanWorker === 'string' ? body.firstScanWorker.slice(0, 200) : null, repeatScanBox: box?.code ?? null };
    return queueClientKizReview(db, { scope: 'RECEIPT', clientId: body.clientId, warehouseId: user.activeWarehouseId, requestId: '', kiz: body.kiz,
        boxId: box?.id ?? null, operationKey: body.operationKey, sourceDocument: body.sourceDocument, receiptInfo: duplicate }, user);
}
function clientReviewPresentation(row, warehouseId) {
    const { clientGuard, ...snapshot } = row.snapshot ?? {};
    const evidence = row.evidence ?? {}, history = (evidence.history ?? []).filter((h) => !warehouseId || h.request?.warehouseId === warehouseId);
    return { scope: row.snapshot?.scope, active: ['OPEN', 'APPROVED'].includes(row.status), physicalReuseAllowed: row.snapshot?.scope !== 'RECEIPT',
        decision: 'REVIEW', snapshot, evidence: { ...evidence, history, orders: (evidence.orders ?? []).filter((o) => history.some((h) => h.orderId === o.orderId)) } };
}
async function decideClientKizReview(db, clients, row, resolution, reason, confirmed, user) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)() || user.isDemo || !user.roleCodes?.some((r) => ['ADMIN', 'OWNER', 'SUPER_ADMIN'].includes(r)))
        throw new common_1.ForbiddenException('Решение принимает только администратор.');
    if (!user.activeWarehouseId || row.warehouseId !== user.activeWarehouseId || (!user.permissionCodes?.includes('system:admin') && user.writableWarehouseIds && !user.writableWarehouseIds.includes(row.warehouseId)))
        throw new common_1.ForbiddenException('Нет права изменять данные филиала.');
    clients.requireClientAccess(user, row.clientId, 'write');
    if (!confirmed || !['REUSE', 'RELABEL', 'REJECT', 'CLOSE'].includes(resolution) || typeof reason !== 'string' || reason.trim().length < 5 || reason.length > 1000)
        throw new common_1.BadRequestException('Подтвердите физическую проверку и укажите основание решения.');
    if (resolution === 'CLOSE') {
        if (row.snapshot?.scope !== 'RECEIPT')
            throw new common_1.BadRequestException('Закрытие ошибки скана доступно для приёмки.');
        return db.$transaction(async (tx) => {
            await identityLock(tx, row.clientId, row.kizIdentity);
            const current = await tx.kizReviewCase.findUnique({ where: { id: row.id } });
            if (current?.status === 'CLOSED' && current.resolution === 'CLOSE')
                return { id: row.id, status: 'CLOSED', resolution };
            if (current?.status !== 'OPEN' || current.context !== row.context)
                throw new common_1.ConflictException('Обращение изменилось.');
            // FIX: keep the operation key to distinguish an offline retry from a genuinely new scan.
            await tx.kizReviewCase.update({ where: { id: row.id }, data: { status: 'CLOSED', resolution, reason: reason.trim(), decidedById: user.id, decidedByName: user.name, decidedAt: new Date() } });
            await tx.auditLog.create({ data: { userId: user.id, entity: 'KizReviewCase', entityId: row.id, action: 'KIZ_RECEIPT_SCAN_ERROR_CLOSED', payload: { reason: reason.trim(), taskId: current.taskId } } });
            return { id: row.id, status: 'CLOSED', resolution };
        });
    }
    const input = row.snapshot?.clientGuard?.input;
    // Recheck marketplace evidence when the decision depends on it; never trust a stale screen.
    const external = input?.externalEvidence && resolution !== 'REJECT'
        ? await require('./kiz-wb-reuse').inspectKizReuse(db, row.clientId, row.kiz, input.taskId || '') : input?.externalEvidence;
    return db.$transaction(async (tx) => {
        const i = { ...input, externalEvidence: external };
        if (!i.clientId || i.clientId !== row.clientId)
            throw new common_1.ConflictException('Обращение требует обновления.');
        const key = (0, kiz_client_registry_1.clientKizIdentity)(i.kiz);
        await identityLock(tx, i.clientId, key);
        const request = await currentContext(tx, i, true);
        if (request && terminal.includes(request.status) && resolution !== 'REJECT')
            throw new common_1.ConflictException('Заявка уже закрыта. Разрешение больше не применимо.');
        const fresh = await tx.kizReviewCase.findUnique({ where: { id: row.id } });
        if (!fresh || fresh.context !== row.context || !['OPEN', 'APPROVED'].includes(fresh.status))
            throw new common_1.ConflictException('Обращение изменилось.');
        let mark = null;
        try {
            mark = await clientPhysicalMark(tx, i.clientId, i.kiz);
        }
        catch (error) {
            if (resolution !== 'REJECT' || !(error instanceof common_1.ConflictException))
                throw error;
        }
        const e = await history(tx, i);
        if (resolution !== 'REJECT') {
            if (i.boxId) {
                const box = await tx.box.findUnique({ where: { id: i.boxId } });
                if (!box || box.clientId !== i.clientId || box.warehouseId !== i.warehouseId)
                    throw new common_1.ConflictException('Исходный короб недоступен в филиале.');
            }
            if (e.truncated || !mark || ['DEFECT', 'QUARANTINE', 'BLOCKED'].includes(mark.status) || i.skuId && mark.skuId !== i.skuId)
                throw new common_1.ConflictException('Физическая единица не определена однозначно. Сначала завершите сверку.');
            if (resolution === 'REUSE' && i.scope === 'RECEIPT')
                throw new common_1.ConflictException('Обычная повторная приёмка запрещена. Оформите возврат отдельно; здесь можно отказать или назначить переклейку.');
            if (resolution === 'REUSE' && ['RETIRED', 'WRITTEN_OFF'].includes(e.circulation))
                throw new common_1.ConflictException('КИЗ погашен. Требуется переклейка.');
            const tasks = (await (0, ozon_unit_marks_1.expandOzonMarkedTasks)(tx, await tx.fbsTsdAssembly.findMany({ where: { clientId: i.clientId, ...((0, ozon_unit_marks_1.ozonUnitMarksEnabled)() ? { OR: [filter(key), { marketplace: 'OZON', kiz: null }] } : filter(key)), id: { not: i.taskId || '' } } }))).filter((t) => (0, kiz_client_registry_1.clientKizIdentity)(t.kiz ?? '') === key);
            for (const task of tasks) {
                const req = await tx.clientRequest.findUnique({ where: { id: task.requestId } });
                if (!req || !terminal.includes(req.status) || !['COMPLETED', 'RELEASED', 'WB_ACCOUNTED', 'CANCELLED'].includes(task.status))
                    throw new common_1.ConflictException('КИЗ занят другой сборкой FBS.');
            }
            const units = (await tx.fboAssemblyUnit.findMany({ where: { ...filter(key), requestId: { not: i.requestId }, activeMarkId: { not: null }, assembly: { request: { clientId: i.clientId } } }, include: { assembly: { include: { request: true } } } })).filter((u) => (0, kiz_client_registry_1.clientKizIdentity)(u.kiz ?? '') === key);
            if (units.some((u) => !terminal.includes(u.assembly?.request?.status)))
                throw new common_1.ConflictException('КИЗ занят другой сборкой FBO.');
            if ((await tx.kizReviewCase.findMany({ where: { clientId: i.clientId, kizIdentity: key, id: { not: row.id }, status: { in: ['APPROVED', 'CLAIMED'] }, taskId: { startsWith: 'GUARD:' } } })).length)
                throw new common_1.ConflictException('Для КИЗ уже есть действующее разрешение в другой заявке.');
            // FIX: per-unit history is immutable; only legacy scalar bindings are cleared.
            if (resolution === 'REUSE')
                for (const old of tasks.filter((t) => !t.taskId)) {
                    await tx.auditLog.create({ data: { userId: user.id, entity: 'FbsTsdAssembly', entityId: old.id, action: 'KIZ_CLIENT_BINDING_ARCHIVED', payload: json({ reviewId: row.id, reason, before: old }) } });
                    const changed = await tx.fbsTsdAssembly.updateMany({ where: { id: old.id, kiz: old.kiz, updatedAt: old.updatedAt }, data: { kiz: null } });
                    if (changed.count !== 1)
                        throw new common_1.ConflictException('Прежняя привязка изменилась.');
                }
        }
        if (resolution === 'REUSE') {
            const closedUnits = (await tx.fboAssemblyUnit.findMany({ where: { ...filter(key), requestId: { not: i.requestId }, activeMarkId: { not: null }, assembly: { request: { clientId: i.clientId, status: { in: terminal } } } }, include: { assembly: { include: { request: true } } } })).filter((u) => (0, kiz_client_registry_1.clientKizIdentity)(u.kiz ?? '') === key);
            for (const old of closedUnits) {
                await tx.auditLog.create({ data: { userId: user.id, entity: 'FboAssemblyUnit', entityId: old.id, action: 'KIZ_CLIENT_BINDING_ARCHIVED', payload: json({ reviewId: row.id, reason, before: old }) } });
                const changed = await tx.fboAssemblyUnit.updateMany({ where: { id: old.id, activeMarkId: old.activeMarkId, state: old.state }, data: { activeMarkId: null } });
                if (changed.count !== 1)
                    throw new common_1.ConflictException('Прежняя привязка FBO изменилась.');
            }
        }
        const status = resolution === 'REJECT' ? 'REJECTED' : 'APPROVED';
        await tx.kizReviewCase.update({ where: { id: row.id }, data: { status, resolution, reason: reason.trim(), decidedById: user.id, decidedByName: user.name, decidedAt: new Date(), usedAt: null,
                snapshot: json({ ...fresh.snapshot, clientGuard: { ...fresh.snapshot.clientGuard, input: i, markId: mark?.id ?? null, markVersion: markVersion(mark), history: e.fingerprint } }), evidence: json(e) } });
        await tx.auditLog.create({ data: { userId: user.id, entity: 'KizReviewCase', entityId: row.id, action: 'KIZ_CLIENT_REVIEW_DECIDED', payload: json({ resolution, reason, confirmed, context: row.context, identity: key }) } });
        return { id: row.id, status, resolution };
    });
}
async function finishClientKizUse(tx, i) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return;
    await tx.kizReviewCase.updateMany({ where: { clientId: i.clientId, taskId: (0, exports.clientUseTaskKey)(i), kizIdentity: (0, kiz_client_registry_1.clientKizIdentity)(i.kiz), context: (0, exports.clientUseContext)(i), status: 'CLAIMED', resolution: { in: ['REUSE', 'FIRST_USE'] } }, data: { status: 'USED', usedAt: new Date() } });
}
async function assertClientRequestKizShipment(tx, request, user) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return;
    const units = await tx.fboAssemblyUnit.findMany({ where: { requestId: request.id, state: { not: 'RETURNED' }, kiz: { not: null } } });
    // FIX: one transaction-scoped preload; retain the existing per-KIZ decision and durable claims.
    const identities = new Set();
    for (const unit of units) {
        const key = (0, kiz_client_registry_1.clientKizIdentity)(unit.kiz);
        if (identities.has(key))
            throw new ClientKizReviewRequired({ scope: 'FBO', clientId: request.clientId, warehouseId: request.warehouseId, requestId: request.id, kiz: unit.kiz, skuId: unit.skuId, boxId: unit.sourceBoxId || null });
        identities.add(key);
    }
    const reads = await (0, kiz_shipment_reads_1.loadShipmentKizReads)(tx, request, units);
    for (const unit of units)
        await assertClientKizUse(tx, { scope: 'FBO', clientId: request.clientId, warehouseId: request.warehouseId, requestId: request.id, kiz: unit.kiz, skuId: unit.skuId, boxId: unit.sourceBoxId || null }, user, reads.get((0, kiz_client_registry_1.clientKizIdentity)(unit.kiz)));
    const rawTasks = await tx.fbsTsdAssembly.findMany({ where: { requestId: request.id, clientId: request.clientId, ...((0, ozon_unit_marks_1.ozonUnitMarksEnabled)() ? { OR: [{ kiz: { not: null } }, { marketplace: 'OZON' }] } : { kiz: { not: null } }), status: { notIn: ['RELEASED', 'CANCELLED'] } } });
    const tasks = await (0, ozon_unit_marks_1.expandOzonMarkedTasks)(tx, rawTasks, { requireComplete: true }); // FIX: partial picks cannot authorize shipment.
    const shipped = tasks.length ? await tx.shippedKizHistory.findMany({ where: { clientId: request.clientId, assemblyId: { in: tasks.map((t) => t.id) } } }) : [];
    for (const task of tasks) {
        if (shipped.some((s) => s.assemblyId === task.id && s.requestId === request.id && (0, kiz_client_registry_1.clientKizIdentity)(s.kiz) === (0, kiz_client_registry_1.clientKizIdentity)(task.kiz)))
            continue;
        await assertClientKizUse(tx, { scope: 'FBS', clientId: request.clientId, warehouseId: request.warehouseId, requestId: request.id, taskId: task.taskId || task.id, kiz: task.kiz, skuId: task.skuId, boxId: task.boxId }, user);
    }
}
async function finishClientRequestKizShipment(tx, request) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return;
    await tx.kizReviewCase.updateMany({ where: { clientId: request.clientId, requestId: request.id, taskId: { startsWith: 'GUARD:' }, status: 'CLAIMED', resolution: { in: ['REUSE', 'FIRST_USE'] } }, data: { status: 'USED', usedAt: new Date() } });
}
// Only the authorized bind transaction may update its own pre-pick mark version.
async function refreshClientKizClaim(tx, i, mark) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return;
    const key = (0, kiz_client_registry_1.clientKizIdentity)(i.kiz), row = await tx.kizReviewCase.findUnique({ where: { taskId_kizIdentity: { taskId: (0, exports.clientUseTaskKey)(i), kizIdentity: key } } });
    if (!row || row.status !== 'CLAIMED' || row.context !== (0, exports.clientUseContext)(i))
        throw new common_1.ConflictException('Привязка КИЗ не подтверждена.');
    await tx.kizReviewCase.update({ where: { id: row.id }, data: { snapshot: json({ ...row.snapshot, clientGuard: { ...row.snapshot.clientGuard, markId: mark.id, markVersion: markVersion(mark) } }) } });
}
async function assertFbsClientKiz(db, task, kiz, user) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return 'ALLOW';
    const request = await db.clientRequest.findUnique({ where: { id: task.requestId } });
    const i = { scope: 'FBS', clientId: task.clientId, warehouseId: request?.warehouseId, requestId: task.requestId, taskId: task.id, kiz, skuId: task.skuId, boxId: task.boxId, allowRelabel: true };
    return withClientKizReview(db, user, () => db.$transaction((tx) => assertClientKizUse(tx, i, user)));
}
// Old WB review logic must not auto-approve manual-writeoff histories under the new rule.
async function strictLegacyQueueDecision(db, clientId, kiz, taskId, evidence) {
    if (!(0, kiz_client_registry_1.clientKizGuardEnabled)())
        return null;
    const task = await db.fbsTsdAssembly.findUnique({ where: { id: taskId } });
    if (!task || task.clientId !== clientId)
        return null;
    const request = await db.clientRequest.findUnique({ where: { id: task.requestId } });
    const i = { scope: 'FBS', clientId, warehouseId: request?.warehouseId, requestId: task.requestId, taskId, kiz, skuId: task.skuId, boxId: task.boxId, externalEvidence: evidence, allowRelabel: true };
    if ((await history(db, i)).decision === 'ALLOW')
        return null;
    const user = { id: task.workerUserId, name: task.workerName };
    try {
        return await db.$transaction((tx) => assertClientKizUse(tx, i, user));
    }
    catch (e) {
        if (e instanceof ClientKizReviewRequired) {
            await queueClientKizReview(db, i, user);
            return 'REVIEW';
        }
        throw e;
    }
}
