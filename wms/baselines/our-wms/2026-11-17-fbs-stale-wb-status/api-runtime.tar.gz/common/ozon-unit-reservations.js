"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonUnitReservationsEnabled = void 0;
exports.ozonUnitReservationRows = ozonUnitReservationRows;
exports.loadOzonUnitReservations = loadOzonUnitReservations;
const common_1 = require("@nestjs/common");
const ozon_fbs_pick_lines_1 = require("../modules/marketplace-connections/ozon-fbs-pick-lines");
const ozon_unit_marks_1 = require("./ozon-unit-marks");
const ozonUnitReservationsEnabled = () => (0, ozon_unit_marks_1.ozonUnitMarksEnabled)() && process.env.WMS_OZON_TSD_UNIT_MARKS_ENABLED === 'true';
exports.ozonUnitReservationsEnabled = ozonUnitReservationsEnabled;
// FIX: replace the scalar header, never add its quantity to the per-product demand.
function ozonUnitReservationRows(task, state) {
    if (task.marketplace !== 'OZON' || state?.unitMarksVersion !== 1)
        return null;
    const fail = () => { throw new common_1.ConflictException('Повреждён поштучный резерв Ozon. Нужна проверка администратора.'); };
    if (!Array.isArray(state.lines) || !state.lines.length)
        return fail();
    let total = 0;
    const result = [];
    for (const line of state.lines) {
        if (!line.skuId || !Number.isSafeInteger(line.quantity) || line.quantity < 1 || !Array.isArray(line.picks) || line.picks.length > line.quantity)
            return fail();
        total += line.quantity;
        const boxes = new Map();
        for (const pick of line.picks)
            boxes.set(pick.boxId ?? null, (boxes.get(pick.boxId ?? null) ?? 0) + 1);
        if (line.quantity > line.picks.length)
            boxes.set(null, (boxes.get(null) ?? 0) + line.quantity - line.picks.length);
        for (const [boxId, itemCount] of boxes)
            result.push({ ...task, skuId: line.skuId, sourceSkuId: null, relabelConfirmedAt: null, boxId, reservedBoxId: null, itemCount });
    }
    if (total !== task.itemCount)
        return fail();
    return result;
}
async function loadOzonUnitReservations(db, tasks) {
    const result = new Map();
    if (!(0, exports.ozonUnitReservationsEnabled)())
        return result;
    for (const task of tasks) {
        if (task.marketplace !== 'OZON')
            continue;
        const rows = ozonUnitReservationRows(task, await (0, ozon_fbs_pick_lines_1.readOzonPickState)(db, task.id));
        if (rows)
            result.set(task.id, rows);
    }
    return result;
}
