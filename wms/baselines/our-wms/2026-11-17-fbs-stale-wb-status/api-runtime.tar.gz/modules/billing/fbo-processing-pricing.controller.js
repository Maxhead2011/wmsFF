"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FboProcessingPricingController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const fbo_processing_pricing_service_1 = require("./fbo-processing-pricing.service");
const fbo_processing_pricing_dto_1 = require("./dto/fbo-processing-pricing.dto");
// FIX: no update/delete route can overwrite an existing client's conditions.
let FboProcessingPricingController = class FboProcessingPricingController {
    pricing;
    constructor(pricing) {
        this.pricing = pricing;
    }
    list(user) { return this.pricing.list(user); }
    products(clientId, search = '', user) { return this.pricing.products(clientId, search, user); }
    create(clientId, dto, user) { return this.pricing.create(clientId, dto, user); }
};
exports.FboProcessingPricingController = FboProcessingPricingController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FboProcessingPricingController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(':clientId/products'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Query)('search')),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], FboProcessingPricingController.prototype, "products", null);
__decorate([
    (0, common_1.Post)(':clientId'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, fbo_processing_pricing_dto_1.CreateFboProcessingTariffDto, Object]),
    __metadata("design:returntype", void 0)
], FboProcessingPricingController.prototype, "create", null);
FboProcessingPricingController.prototype.previewProductRules = function(clientId,dto,user) { return this.pricing.previewProductRules(clientId,dto,user); };
__decorate([
    (0, common_1.Post)(':clientId/rules/preview'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata('design:type', Function),
    __metadata('design:paramtypes', [String,Object,Object]),
    __metadata('design:returntype', void 0)
], FboProcessingPricingController.prototype, 'previewProductRules', null);
FboProcessingPricingController.prototype.saveProductRules = function(clientId,dto,user) { return this.pricing.saveProductRules(clientId,dto,user); };
__decorate([
    (0, common_1.Patch)(':clientId/rules'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:write'),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata('design:type', Function),
    __metadata('design:paramtypes', [String,Object,Object]),
    __metadata('design:returntype', void 0)
], FboProcessingPricingController.prototype, 'saveProductRules', null);
exports.FboProcessingPricingController = FboProcessingPricingController = __decorate([
    (0, common_1.Controller)('billing/fbo-processing'),
    (0, require_permissions_decorator_1.RequirePermissions)('billing:read'),
    __metadata("design:paramtypes", [fbo_processing_pricing_service_1.FboProcessingPricingService])
], FboProcessingPricingController);
