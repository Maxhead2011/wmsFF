'use strict';
const { BadRequestException } = require('@nestjs/common');
const PREFIX = 'storage.receipt-groups.v1:';
const fail = message => { throw new BadRequestException(message); };
const dateKey = s => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && Number.isFinite(Date.parse(s)) && new Date(s).toISOString().slice(0, 10) === s;
const relevant = m => !['PICK', 'PACK', 'MOVE'].includes(m.type) && (m.type !== 'SHIP' || m.quantity < 0) && m.quantity !== 0;

// A confirmed opening reconciliation replaces the historical arrival journal,
// while preserving every physical stock movement and previously issued invoice.
function reconcile(config, clientId, movements, arrivalRows, from, to) {
  if (!config) return { movements, arrivalRows, metadata: null };
  if (config.version !== 1 || config.clientId !== clientId || !config.warehouseId || !dateKey(config.effectiveFrom) || !Array.isArray(config.groups) || !Array.isArray(config.retiredArrivalIds)) fail('Повреждена сверка хранения по приходам.');
  if (to.toISOString().slice(0, 10) < config.effectiveFrom) return { movements, arrivalRows, metadata: null };
  if (from.toISOString().slice(0, 10) < config.effectiveFrom) fail('Разделите период хранения по дате сверки ' + config.effectiveFrom + '.');
  const rowById = new Map(arrivalRows.map(r => [r.id, r]));
  const managed = new Set(), prefixes = new Set(), claimed = new Set(), extra = [];
  const summaries = [];
  for (const group of config.groups) {
    if (!group.id || !Array.isArray(group.arrivalIds) || !group.arrivalIds.length || !Array.isArray(group.receiptPrefixes) || !group.receiptPrefixes.length) fail('Не заполнена связь мешков с приёмкой.');
    for (const id of group.arrivalIds) { if (managed.has(id)) fail('Приход повторяется в сверке хранения.'); managed.add(id); }
    for (const prefix of group.receiptPrefixes) { if (typeof prefix !== 'string' || prefix.length < 8 || [...prefixes].some(p => p.startsWith(prefix) || prefix.startsWith(p))) fail('Пересекаются партии приёмки для хранения.'); prefixes.add(prefix); }
    const arrivals = group.arrivalIds.map(id => rowById.get(id));
    if (arrivals.some(r => !r || r.payload.clientId !== clientId || r.payload.warehouseId !== config.warehouseId || r.payload.status === 'CANCELLED' || !dateKey(r.payload.arrivalDate))) fail('Приход сверки не найден в нужном клиенте и филиале.');
    const dates = new Set(arrivals.map(r => r.payload.storageReconciledAt || null));
    if (dates.size !== 1) fail('Для связанных мешков укажите одну дату перехода на хранение принятого товара.');
    const releasedOn = [...dates][0];
    if (releasedOn && (!dateKey(releasedOn) || arrivals.some(r => releasedOn < r.payload.arrivalDate))) fail('Некорректная дата перехода на хранение товара.');
    const cutoff = releasedOn ? new Date(new Date(releasedOn + 'T00:00:00Z').getTime() - 1) : null;
    const bagSkuId = 'receipt-group-bags:' + group.id;
    const sku = { id: bagSkuId, internalSku: group.id, name: 'Неразобранные мешки · ' + group.name, volumeLiters: 480 };
    let bagCount = 0;
    for (const row of arrivals) {
      const p = row.payload, count = Number(p.bagCount);
      if (!Number.isSafeInteger(count) || count < 1 || Number(p.boxCount || 0) !== 0 || p.storageVolumeLiters != null) fail('Изменился объём связанных мешков — требуется сверка.');
      bagCount += count;
      const createdAt = new Date(new Date(p.arrivalDate + 'T00:00:00Z').getTime() - 1);
      if (createdAt <= to) extra.push({ skuId: bagSkuId, warehouseId: config.warehouseId, type: 'INVENTORY_ADJUSTMENT', status: 'AVAILABLE', quantity: count, createdAt, sku });
    }
    if (bagCount !== group.bagCount) fail('Количество мешков не совпало со сверкой.');
    const linked = movements.filter(m => group.receiptPrefixes.some(prefix => m.box?.code?.startsWith(prefix)));
    if (linked.some(m => m.warehouseId !== config.warehouseId)) fail('В связанной приёмке обнаружен другой филиал.');
    if (cutoff && linked.some(m => m.type === 'RECEIPT' && m.createdAt > cutoff)) fail('После завершения партии появились новые сканы. Проверьте дату завершения приёмки ' + group.name + '.');
    const externalIds = new Set(group.additionalMovementIds || []);
    const external = movements.filter(m => externalIds.has(m.id));
    if (external.some(m => m.warehouseId !== config.warehouseId || m.type !== 'SHIP' || m.quantity >= 0)) fail('Изменилась связанная отгрузка приёмки.');
    // Transfers do not affect storage; external shipments need exact provenance.
    for (const picked of linked.filter(m => m.type === 'PICK' && m.quantity < 0 && (!cutoff || m.createdAt <= cutoff))) {
      const shipments = movements.filter(m => m.type === 'SHIP' && m.quantity < 0 && m.skuId === picked.skuId && m.sourceDocument === picked.sourceDocument && (!cutoff || m.createdAt <= cutoff));
      if (shipments.some(m => !externalIds.has(m.id) && !linked.some(l => l.id === m.id))) fail('Нужна сверка отгрузки из незавершённой приёмки ' + group.name + '.');
    }
    if (linked.some(m => m.type === 'MOVE' && (!cutoff || m.createdAt <= cutoff))) fail('Нужна сверка перемещения из незавершённой приёмки ' + group.name + '.');
    const deferred = new Map();
    const rows = [...new Map([...linked, ...external].map(m => [m.id, m])).values()].filter(m => relevant(m) && (!cutoff || m.createdAt <= cutoff));
    for (const m of rows) {
      if (claimed.has(m.id)) fail('Движение попало в две партии хранения.'); claimed.add(m.id);
      extra.push({ ...m, type: 'INVENTORY_ADJUSTMENT', quantity: -m.quantity });
      const previous = deferred.get(m.skuId);
      deferred.set(m.skuId, { ...m, quantity: (previous?.quantity || 0) + m.quantity });
    }
    if ([...deferred.values()].some(m => m.quantity < 0)) fail('Отгрузка связанной партии превышает приёмку.');
    if (cutoff && cutoff <= to) {
      extra.push({ skuId: bagSkuId, warehouseId: config.warehouseId, type: 'INVENTORY_ADJUSTMENT', status: 'AVAILABLE', quantity: -bagCount, createdAt: cutoff, sku });
      for (const m of deferred.values()) if (m.quantity) extra.push({ ...m, type: 'INVENTORY_ADJUSTMENT', createdAt: cutoff });
    }
    summaries.push({ id: group.id, name: group.name, arrivalIds: group.arrivalIds, bagCount, releasedOn, receiptPrefixes: group.receiptPrefixes, deferredUnits: [...deferred.values()].reduce((s, m) => s + m.quantity, 0) });
  }
  const retired = new Set(config.retiredArrivalIds);
  if ([...managed].some(id => retired.has(id))) fail('Активный приход ошибочно исключён из хранения.');
  return {
    movements: movements.filter(m => !managed.has(String(m.skuId).replace(/^unpacked-bags:/, ''))).concat(extra),
    arrivalRows: arrivalRows.filter(r => !managed.has(r.id) && !retired.has(r.id)),
    metadata: { effectiveFrom: config.effectiveFrom, warehouseId: config.warehouseId, groups: summaries, retiredArrivalIds: config.retiredArrivalIds, reason: config.reason }
  };
}
async function sources(db, clientId, movements, arrivalRows, from, to) {
  const setting = await db.systemSetting.findUnique({ where: { key: PREFIX + clientId }, select: { value: true } });
  return reconcile(setting?.value, clientId, movements, arrivalRows, from, to);
}
module.exports = { PREFIX, reconcile, sources };
