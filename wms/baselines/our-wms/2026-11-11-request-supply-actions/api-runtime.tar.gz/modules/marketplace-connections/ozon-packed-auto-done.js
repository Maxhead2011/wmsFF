"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonPackedAutoDoneEnabled = void 0;
exports.closeOzonPackedRequest = closeOzonPackedRequest;
// FIX: opt-in for our installation; remote acceptance changes no warehouse ledger.
const ozonPackedAutoDoneEnabled = () => process.env.WMS_OZON_PACKED_AUTO_DONE_ENABLED === 'true';
exports.ozonPackedAutoDoneEnabled = ozonPackedAutoDoneEnabled;
async function closeOzonPackedRequest(tx, request, orders, explicitBatch) {
    if (!(0, exports.ozonPackedAutoDoneEnabled)() || explicitBatch || request.fbsEmergencyAssemblyAt ||
        request.type !== 'OUTBOUND' || !(process.env.WMS_FBS_ACTION_STATUS_ENABLED === 'true'
        ? ['SUBMITTED', 'IN_REVIEW', 'APPROVED', 'IN_WORK', 'PACKED'].includes(request.status)
        : request.status === 'PACKED'))
        return false;
    if (request.fbsOrderLinks.some(link => link.syncStatus === 'MOVING'))
        return false;
    const links = request.fbsOrderLinks.filter(link => !['REMOVED', 'ADMIN_REMOVED'].includes(link.syncStatus));
    if (!links.length)
        return false;
    const accepted = [];
    for (const link of links) {
        const matches = orders.filter(order => order.connectionId === link.connectionId && order.id === link.orderId);
        if (link.marketplace !== 'OZON' || matches.length !== 1)
            return false;
        const order = matches[0];
        if (order.marketplace !== 'OZON' || !['delivering', 'delivered'].includes(order.supplierStatus) ||
            order.wbStatus !== order.supplierStatus)
            return false;
        accepted.push(order);
    }
    const client = await tx.client.findUnique({ where: { id: request.clientId }, select: { isDemo: true } });
    if (!client || client.isDemo)
        return false;
    // FIX: caller holds the request lock; CAS also protects a stale snapshot/retry.
    // FIX: compare and record the actual pre-handover stage; never touch inventory.
    const previousStatus = request.status;
    const changed = await tx.clientRequest.updateMany({ where: { id: request.id, clientId: request.clientId,
            status: previousStatus, updatedAt: request.updatedAt, fbsEmergencyAssemblyAt: null }, data: { status: 'DONE' } });
    if (changed.count !== 1)
        return false;
    await tx.clientRequestEvent.create({ data: { requestId: request.id, clientId: request.clientId,
            eventType: 'STATUS_CHANGED', statusFrom: previousStatus, statusTo: 'DONE',
            title: 'Сдано: Ozon принял заказы в доставку',
            body: `Автоматическая сверка ФБС Ozon: ${accepted.map(o => `${o.id}: ${o.supplierStatus}/${o.wbStatus}`).join('; ')}. Изменён только статус заявки; списания, возвраты и остатки не изменялись.` } });
    return true;
}
