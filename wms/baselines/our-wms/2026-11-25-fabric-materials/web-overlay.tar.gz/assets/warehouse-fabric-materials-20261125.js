import { r as t } from "/assets/storage-volume-root-20261109.js";
const s = (...n) => t.useState(...n), U = (...n) => t.useEffect(...n), le = (...n) => t.useRef(...n), he = (...n) => t.useMemo(...n), Ce = (...n) => t.useCallback(...n), ye = "/api/v1";
async function Ie(n, l = {}) {
  return S(
    we("/clients", {
      includeArchived: l.includeArchived ? "true" : void 0,
      marketplaceDirectory: l.marketplaceDirectory ? "true" : void 0,
      allBranches: l.allBranches ? "1" : void 0,
      displayWarehouseId: l.displayWarehouseId || void 0
    }),
    {
      accessToken: n
    }
  );
}
async function S(n, l = {}) {
  const c = await fetch(`${ye}${n}`, {
    method: l.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      ...l.accessToken ? { Authorization: `Bearer ${l.accessToken}` } : {}
    },
    body: l.body ? JSON.stringify(l.body) : void 0
  });
  if (!c.ok) {
    const a = await c.json().catch(() => null), f = new Error(await Se(c, a));
    throw (a == null ? void 0 : a.code) === "KIZ_DUPLICATE" && a.duplicateInfo && typeof a.duplicateInfo == "object" && Object.assign(f, { code: a.code, duplicate: !0, duplicateInfo: a.duplicateInfo }), f;
  }
  return await c.json();
}
function we(n, l) {
  const c = new URLSearchParams();
  Object.entries(l).forEach(([f, m]) => {
    m !== void 0 && m !== "" && m !== !1 && c.set(f, String(m));
  });
  const a = c.toString();
  return a ? `${n}?${a}` : n;
}
async function Se(n, l) {
  try {
    const c = l === void 0 ? await n.json() : l;
    return Array.isArray(c == null ? void 0 : c.message) ? c.message.join(`
`) : (c == null ? void 0 : c.message) || `HTTP ${n.status}`;
  } catch {
    return `HTTP ${n.status}`;
  }
}
const Te = "logoff-wms:last-client", M = "logoff-wms:last-client-change";
function ke(n, l = {}) {
  var I, y;
  const c = he(() => `${Te}:${n}`, [n]), a = ((I = l.fixedClientId) == null ? void 0 : I.trim()) ?? "", f = ((y = l.initialClientId) == null ? void 0 : y.trim()) ?? "", [m, h] = s(
    () => a || (l.preferInitialClientId ? f : "") || Ne(c) || f
  );
  U(() => {
    a && h(a);
  }, [a]), U(() => {
    if (a || typeof window > "u") return;
    const b = (p) => {
      const d = Ae(p, c);
      d && h(d);
    };
    return window.addEventListener(M, b), () => {
      window.removeEventListener(M, b);
    };
  }, [a, c]);
  const u = Ce((b) => {
    h((p) => {
      const d = typeof b == "function" ? b(p) : b;
      return !a && d && typeof window < "u" && (window.localStorage.setItem(c, d), window.dispatchEvent(new CustomEvent(M, {
        detail: { storageKey: c, clientId: d }
      }))), d;
    });
  }, [a, c]);
  return [m, u];
}
function Re(n, l, c = "") {
  var a;
  return l.some((f) => f.id === n) ? n : c || ((a = l[0]) == null ? void 0 : a.id) || "";
}
function Ae(n, l) {
  var a;
  const c = n.detail;
  return n.type !== M || (c == null ? void 0 : c.storageKey) !== l ? "" : ((a = c.clientId) == null ? void 0 : a.trim()) ?? "";
}
function Ne(n) {
  var l;
  return typeof window > "u" ? "" : ((l = window.localStorage.getItem(n)) == null ? void 0 : l.trim()) ?? "";
}
const Le = { синий: "#2563eb", красный: "#dc3545", черный: "#202733", белый: "#ffffff", "айвори / шампань": "#eee0bc", зеленый: "#27845b", айвори: "#eee0bc", шампань: "#eee0bc", пудровый: "#e7bdc6", розовый: "#e7a9bd", серый: "#929aa6", бежевый: "#d5bea0", желтый: "#edc64a", голубой: "#83bce4", коричневый: "#80563e", фиолетовый: "#8757aa" };
function Me(n) {
  return Le[n.trim().toLocaleLowerCase("ru-RU").replace(/ё/g, "е")] ?? null;
}
function re({ name: n }) {
  const l = Me(n);
  return /* @__PURE__ */ t.createElement("span", { className: "fabric-color-label" }, /* @__PURE__ */ t.createElement("span", { "aria-hidden": "true", title: l ? `Условный образец: ${n}` : "Оттенок не задан", className: `fabric-color-swatch${l ? "" : " fabric-color-swatch--unknown"}`, style: l ? { backgroundColor: l } : void 0 }), n);
}
const Ue = { SATIN: "Атлас / сатин", GABARDINE: "Габардин" };
function Oe({ session: n }) {
  var Y, ee, te, ne;
  const [l, c] = s([]), [a, f] = ke(n.user.id), [m, h] = s(null), [u, I] = s(null), [y, b] = s("SATIN"), [p, d] = s("black"), [D, O] = s(""), [F, _] = s(""), J = { ...(u == null ? void 0 : u.baseMaterials) ?? Ue, ...Object.fromEntries(((u == null ? void 0 : u.materials) ?? []).map((e) => [e.id, e.name])) }, [T, ce] = s(1), [x, K] = s(""), [k, ie] = s(5), [i, w] = s(!1), [$, v] = s(""), [G, B] = s(""), [R, oe] = s(""), [g, se] = s("ADJUST"), [H, ue] = s(0), [L, me] = s(""), [z, de] = s(""), [q, Ee] = s(""), [V, fe] = s(""), [Q, be] = s(1), E = le(0), A = le(null), C = n.accessToken, P = "/warehouse/fabric-rolls/" + encodeURIComponent(a), pe = !n.user.roleCodes.includes("CLIENT") && n.user.permissionCodes.some((e) => ["stock:write", "system:admin"].includes(e)), ve = !n.user.roleCodes.includes("CLIENT") && n.user.permissionCodes.some((e) => ["clients:write", "system:admin"].includes(e));
  U(() => {
    let e = !0;
    return Ie(C).then((r) => {
      e && (c(r), f((o) => Re(o, r)));
    }).catch((r) => {
      e && v(String(r.message));
    }), () => {
      e = !1;
    };
  }, [C]);
  async function j() {
    const e = ++E.current;
    v("");
    try {
      const [r, o] = await Promise.all([S(P, { accessToken: C }), S("/warehouse/fabric-catalog/" + encodeURIComponent(a), { accessToken: C })]);
      e === E.current && (h(r), I(o));
    } catch (r) {
      e === E.current && v(r instanceof Error ? r.message : String(r));
    }
  }
  U(() => (h(null), I(null), K(""), b("SATIN"), _(""), O(""), d("black"), B(""), A.current = null, a && j(), () => {
    E.current++;
  }), [a, C, n.user.activeWarehouseId]);
  async function W(e) {
    if (!u || i) return;
    w(!0), v("");
    const r = E.current;
    try {
      const o = await S("/warehouse/fabric-catalog/" + encodeURIComponent(a), { accessToken: C, method: "POST", body: { action: e, material: y, name: e === "CREATE_MATERIAL" ? F : D, skuId: x, colorId: p, lengthMm: Math.round(k * 1e3), version: u.version } });
      if (r !== E.current) return;
      I(o.catalog), o.result.color && (d(o.result.color.id), O("")), o.result.material && (b(o.result.material.id), d("black"), _("")), B(e === "CREATE_MATERIAL" ? o.result.reused ? "Такая ткань уже есть — она выбрана." : "Ткань добавлена и выбрана для приёмки." : o.result.reused ? "Такой цвет уже есть — он выбран." : e === "CREATE_COLOR" ? "Цвет добавлен и выбран для приёмки." : "Привязка товара сохранена."), await j();
    } catch (o) {
      r === E.current && v(o instanceof Error ? o.message : String(o));
    } finally {
      w(!1);
    }
  }
  async function X(e) {
    var ae;
    if (i || !m) return;
    w(!0), v("");
    const r = E.current, o = JSON.stringify({ clientId: a, body: e });
    ((ae = A.current) == null ? void 0 : ae.fingerprint) !== o && (A.current = { fingerprint: o, key: crypto.randomUUID() });
    try {
      const N = await S(P, { method: "POST", accessToken: C, body: { ...e, version: m.version, operationKey: A.current.key } });
      r === E.current && (h(N), A.current = null, B(e.action === "RECEIVE" ? "Рулоны приняты." : "Операция с рулоном сохранена."));
    } catch (N) {
      r === E.current && v(N instanceof Error ? N.message : String(N));
    } finally {
      w(!1);
    }
  }
  async function ge() {
    if (i) return;
    w(!0), v("");
    const e = E.current;
    try {
      const r = await S(P, { method: "PUT", accessToken: C, body: { enabled: !0 } });
      e === E.current && h(r);
    } catch (r) {
      e === E.current && v(r instanceof Error ? r.message : String(r));
    } finally {
      w(!1);
    }
  }
  const Z = [...Object.entries((u == null ? void 0 : u.baseColors) ?? {}).map(([e, r]) => ({ id: e, name: r })), ...(u == null ? void 0 : u.colors.filter((e) => e.material === y)) ?? []];
  return /* @__PURE__ */ t.createElement("section", { className: "warehouse-panel fabric-warehouse", "aria-label": "Ткани: хранение и учёт" }, /* @__PURE__ */ t.createElement("header", { className: "fabric-heading" }, /* @__PURE__ */ t.createElement("div", null, /* @__PURE__ */ t.createElement("span", { className: "fabric-eyebrow" }, "Склад · ткани"), /* @__PURE__ */ t.createElement("h2", null, "Ткани: хранение и учёт"), /* @__PURE__ */ t.createElement("p", null, "Рулоны, готовые отрезы и движение ткани"))), /* @__PURE__ */ t.createElement("div", { className: "fabric-toolbar" }, /* @__PURE__ */ t.createElement("label", null, "Клиент", /* @__PURE__ */ t.createElement("select", { value: a, disabled: i, onChange: (e) => f(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "" }, "Выберите клиента"), l.map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.name)))), a ? /* @__PURE__ */ t.createElement("button", { type: "button", disabled: i, onClick: () => void j() }, "Обновить") : null), $ ? /* @__PURE__ */ t.createElement("p", { role: "alert" }, $) : null, G ? /* @__PURE__ */ t.createElement("p", { role: "status" }, G) : null, m && !m.enabled ? /* @__PURE__ */ t.createElement("div", null, /* @__PURE__ */ t.createElement("p", null, "Рулонный учёт у клиента выключен."), ve ? /* @__PURE__ */ t.createElement("button", { disabled: i, onClick: () => void ge() }, "Включить «Товар в рулонах»") : /* @__PURE__ */ t.createElement("p", null, "Для включения обратитесь к администратору.")) : null, m != null && m.enabled && u ? /* @__PURE__ */ t.createElement(t.Fragment, null, /* @__PURE__ */ t.createElement("p", null, "Рулон — 100 м. Остатки рулонов и готовые отрезы учитываются отдельно."), /* @__PURE__ */ t.createElement("div", { className: "warehouse-topic-grid" }, (Y = m.groups) == null ? void 0 : Y.map((e) => /* @__PURE__ */ t.createElement("article", { className: "warehouse-panel", key: e.key }, /* @__PURE__ */ t.createElement("h3", { className: "fabric-card-title" }, /* @__PURE__ */ t.createElement("span", { className: "fabric-material" }, J[e.material]), /* @__PURE__ */ t.createElement(re, { name: e.colorName })), /* @__PURE__ */ t.createElement("p", null, "Целых: ", e.whole, " · открытых: ", e.open, " · в рулонах: ", e.rawMeters.toLocaleString("ru-RU"), " м"), /* @__PURE__ */ t.createElement("p", null, "Объём хранения: ", e.rawLiters.toLocaleString("ru-RU"), " л"), /* @__PURE__ */ t.createElement("p", null, "Готовые отрезы: ", e.ready.reduce((r, o) => r + o.pieces, 0), " шт."), /* @__PURE__ */ t.createElement("p", null, "FBS: ", e.fbs.pieces, " отрезов / ", e.fbs.meters, " м · FBO: ", e.fbo.pieces, " отрезов / ", e.fbo.meters, " м"), /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "Остаток каждого рулона"), e.rolls.map((r) => /* @__PURE__ */ t.createElement("p", { key: r.id }, r.code, ": ", (r.remainingMm / 1e3).toLocaleString("ru-RU"), " м")))))), pe ? /* @__PURE__ */ t.createElement(t.Fragment, null, /* @__PURE__ */ t.createElement("section", { className: "fabric-intake" }, /* @__PURE__ */ t.createElement("div", { className: "fabric-section-heading" }, /* @__PURE__ */ t.createElement("h3", null, "Приёмка новых рулонов"), /* @__PURE__ */ t.createElement("span", null, "1 рулон = 100 м")), /* @__PURE__ */ t.createElement("div", { className: "fabric-intake-selects" }, /* @__PURE__ */ t.createElement("label", null, "Ткань", /* @__PURE__ */ t.createElement("select", { disabled: i, value: y, onChange: (e) => {
    b(e.target.value), d("black");
  } }, Object.entries(J).map(([e, r]) => /* @__PURE__ */ t.createElement("option", { key: e, value: e }, r)))), /* @__PURE__ */ t.createElement("label", null, "Цвет", /* @__PURE__ */ t.createElement("select", { disabled: i, value: p, onChange: (e) => d(e.target.value) }, Z.map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.name)))), /* @__PURE__ */ t.createElement("span", { className: "fabric-selected-color" }, /* @__PURE__ */ t.createElement(re, { name: ((ee = Z.find((e) => e.id === p)) == null ? void 0 : ee.name) ?? p }))), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), W("CREATE_MATERIAL");
  } }, /* @__PURE__ */ t.createElement("label", null, "Новый вид ткани", /* @__PURE__ */ t.createElement("input", { value: F, maxLength: 80, disabled: i, onChange: (e) => _(e.target.value), placeholder: "Например, Фатин" })), /* @__PURE__ */ t.createElement("button", { disabled: i || !F.trim() }, "Добавить вид ткани")), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), W("CREATE_COLOR");
  } }, /* @__PURE__ */ t.createElement("label", null, "Новый цвет", /* @__PURE__ */ t.createElement("input", { value: D, maxLength: 80, disabled: i, onChange: (e) => O(e.target.value), placeholder: "Например, Пудровый" })), /* @__PURE__ */ t.createElement("button", { disabled: i || !D.trim() }, "Добавить цвет")), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), X({ action: "RECEIVE", material: y, color: p, count: T });
  } }, /* @__PURE__ */ t.createElement("label", null, "Количество рулонов", /* @__PURE__ */ t.createElement("input", { type: "number", min: 1, max: 500, step: 1, value: T, disabled: i, onChange: (e) => ce(Number(e.target.value)) })), /* @__PURE__ */ t.createElement("button", { disabled: i || !Number.isInteger(T) || T < 1 || T > 500 }, "Принять рулоны"))), /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "Операции с рулоном"), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), X(g === "CUT" ? { action: g, rollId: R, barcode: z, boxCode: q, kiz: V, count: Q } : g === "ADJUST" ? { action: g, rollId: R, deltaMm: Math.round(H * 1e3), reason: L } : { action: g, rollId: R, reason: L });
  } }, /* @__PURE__ */ t.createElement("label", null, "Рулон", /* @__PURE__ */ t.createElement("select", { value: R, disabled: i, onChange: (e) => oe(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "" }, "Выберите рулон"), (te = m.groups) == null ? void 0 : te.flatMap((e) => e.rolls).filter((e) => e.warehouseId === n.user.activeWarehouseId && e.remainingMm > 0).map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.code, " · ", e.remainingMm / 1e3, " м")))), /* @__PURE__ */ t.createElement("label", null, "Действие", /* @__PURE__ */ t.createElement("select", { value: g, disabled: i, onChange: (e) => se(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "ADJUST" }, "Фактическая корректировка ±2 м"), /* @__PURE__ */ t.createElement("option", { value: "CUT" }, "Нарезать готовые отрезы"), /* @__PURE__ */ t.createElement("option", { value: "WRITE_OFF" }, "Списать остаток рулона"))), g === "CUT" ? /* @__PURE__ */ t.createElement(t.Fragment, null, /* @__PURE__ */ t.createElement("label", null, "Штрихкод отреза", /* @__PURE__ */ t.createElement("input", { value: z, disabled: i, onChange: (e) => de(e.target.value) })), /* @__PURE__ */ t.createElement("label", null, "Короб готовых отрезов", /* @__PURE__ */ t.createElement("input", { value: q, disabled: i, onChange: (e) => Ee(e.target.value) })), /* @__PURE__ */ t.createElement("label", null, "Количество отрезов", /* @__PURE__ */ t.createElement("input", { type: "number", min: 1, max: 500, step: 1, value: Q, disabled: i, onChange: (e) => be(Number(e.target.value)) })), /* @__PURE__ */ t.createElement("label", null, "КИЗ, по одному на строку", /* @__PURE__ */ t.createElement("textarea", { value: V, disabled: i, onChange: (e) => fe(e.target.value) }))) : /* @__PURE__ */ t.createElement(t.Fragment, null, g === "ADJUST" ? /* @__PURE__ */ t.createElement("label", null, "Изменение, м", /* @__PURE__ */ t.createElement("input", { type: "number", min: -2, max: 2, step: 1e-3, value: H, disabled: i, onChange: (e) => ue(Number(e.target.value)) })) : /* @__PURE__ */ t.createElement("p", null, "Будет списан весь остаток выбранного рулона."), /* @__PURE__ */ t.createElement("label", null, "Причина", /* @__PURE__ */ t.createElement("input", { value: L, disabled: i, onChange: (e) => me(e.target.value) }))), /* @__PURE__ */ t.createElement("button", { disabled: i || !R || g !== "CUT" && L.trim().length < 5 }, "Сохранить операцию с рулоном"))), /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "Привязка к товару маркетплейса"), /* @__PURE__ */ t.createElement("p", null, "Выберите ткань и цвет выше. Для каждой длины отреза привяжите соответствующую карточку товара WMS."), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), W("BIND_SKU");
  } }, /* @__PURE__ */ t.createElement("label", null, "Товар", /* @__PURE__ */ t.createElement("select", { value: x, disabled: i, onChange: (e) => K(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "" }, "Выберите товар клиента"), u.skus.map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.marketplace ?? "WMS", " · ", e.name, " · ", e.offerId ?? e.internalSku, e.binding ? " · привязан" : "")))), /* @__PURE__ */ t.createElement("label", null, "Длина отреза, м", /* @__PURE__ */ t.createElement("input", { type: "number", min: 1e-3, max: 100, step: 1e-3, value: k, disabled: i, onChange: (e) => ie(Number(e.target.value)) })), /* @__PURE__ */ t.createElement("button", { disabled: i || !x || !Number.isFinite(k) || k <= 0 || k > 100 }, "Сохранить привязку")))) : null, /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "История рулонного учёта"), (ne = m.history) == null ? void 0 : ne.map((e, r) => {
    var o;
    return /* @__PURE__ */ t.createElement("p", { key: r }, new Date(e.createdAt).toLocaleString("ru-RU"), " · ", e.action, " ", ((o = e.payload) == null ? void 0 : o.reason) ?? "");
  }))) : null);
}
export {
  Oe as FabricWarehousePanel
};
