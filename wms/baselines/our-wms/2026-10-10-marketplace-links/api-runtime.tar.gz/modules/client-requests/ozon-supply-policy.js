"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supplyOrders = supplyOrders;
exports.mergeSupplyOrders = mergeSupplyOrders;
exports.bindingIdentity = bindingIdentity;
exports.supplyDifferences = supplyDifferences;
exports.packedCargoes = packedCargoes;
exports.cargoHash = cargoHash;
exports.assertSupplyMutable = assertSupplyMutable;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
// FIX: legacy single-order bindings remain readable, while every supply keeps its order owner.
function supplyOrders(link) {
    return link.orders ?? [{ orderId: link.orderId, orderNumber: link.orderNumber, place: link.place, date: link.date, state: link.state, supplies: link.supplies, checkedAt: link.checkedAt }];
}
function mergeSupplyOrders(base, orders) {
    if (!orders.length)
        throw new common_1.ConflictException('Нужна хотя бы одна заявка Ozon.');
    const supplies = orders.flatMap(o => o.supplies);
    if (new Set(orders.map(o => o.orderId)).size !== orders.length || new Set(supplies.map(s => s.id)).size !== supplies.length)
        throw new common_1.ConflictException('Повтор заявки или поставки Ozon.');
    const first = orders[0];
    return { ...base, orderId: first.orderId, orderNumber: first.orderNumber, place: first.place, date: first.date, state: first.state, orders, supplies, checkedAt: new Date().toISOString() };
}
function bindingIdentity(link) {
    return JSON.stringify([link.connectionId, supplyOrders(link).map(o => o.orderId).sort()]);
}
// FIX: explicit mappings only; never silently change customer-file quantities.
function supplyDifferences(directions, link) {
    const errors = [];
    const used = new Set();
    for (const d of directions) {
        const s = link.supplies.find(s => s.id === link.mapping[d.name]);
        if (!s) {
            errors.push(`«${d.name}»: выберите направление Ozon.`);
            continue;
        }
        if (used.has(s.id))
            errors.push(`«${s.name}»: назначено нескольким направлениям файла.`);
        used.add(s.id);
        const expected = new Map();
        for (const i of d.items)
            expected.set(i.barcode, (expected.get(i.barcode) ?? 0) + i.quantity);
        const actual = new Map();
        for (const i of s.items)
            actual.set(i.barcode, (actual.get(i.barcode) ?? 0) + i.quantity);
        for (const barcode of new Set([...expected.keys(), ...actual.keys()])) {
            if (expected.get(barcode) !== actual.get(barcode))
                errors.push(`«${d.name}», ШК ${barcode}: файл ${expected.get(barcode) ?? 0}, Ozon ${actual.get(barcode) ?? 0}.`);
        }
    }
    for (const s of link.supplies)
        if (!used.has(s.id))
            errors.push(`«${s.name}»: отсутствует соответствие в файле.`);
    return errors;
}
function packedCargoes(directions, link, assembly) {
    const errors = supplyDifferences(directions, link);
    if (errors.length)
        throw new common_1.ConflictException('Устраните расхождения с Ozon перед передачей коробов.');
    if (!assembly || !['CONTROL', 'COMPLETED'].includes(assembly.phase) || !assembly.boxes.length || assembly.boxes.some((b) => !b.closedAt || !b.confirmedAt))
        throw new common_1.ConflictException('Сначала упакуйте, закройте и проверьте все короба.');
    const units = assembly.units.filter((u) => u.state !== 'RETURNED');
    if (units.some((u) => u.state !== 'PACKED' || !assembly.boxes.some((b) => b.boxId === u.targetBoxId)))
        throw new common_1.ConflictException('Есть неупакованные единицы.');
    const result = {};
    for (const d of directions) {
        const supply = link.supplies.find(s => s.id === link.mapping[d.name]);
        const boxes = assembly.boxes.filter((b) => b.direction === d.name);
        for (const i of d.items)
            if (units.filter((u) => u.skuId === i.skuId && boxes.some((b) => b.boxId === u.targetBoxId)).length !== i.quantity)
                throw new common_1.ConflictException(`Количество в коробах «${d.name}» не совпадает с файлом.`);
        result[supply.id] = boxes.map((b) => {
            const items = new Map();
            for (const u of units.filter((u) => u.targetBoxId === b.boxId)) {
                const item = d.items.find(i => i.skuId === u.skuId), matches = supply.items.filter(i => i.barcode === item?.barcode);
                if (matches.length !== 1 || !matches[0].offerId)
                    throw new common_1.ConflictException('Товар не сопоставлен однозначно с Ozon.');
                const p = matches[0], old = items.get(p.barcode);
                items.set(p.barcode, { barcode: p.barcode, offer_id: p.offerId, quantity: (old?.quantity ?? 0) + 1, quant: p.quant || 1 });
            }
            if (!items.size)
                throw new common_1.ConflictException('Пустой короб нельзя отправить.');
            return { key: b.id, value: { type: 'BOX', items: [...items.values()].sort((a, b) => a.barcode.localeCompare(b.barcode)) } };
        }).sort((a, b) => a.key.localeCompare(b.key));
    }
    if (assembly.boxes.some((b) => !directions.some(d => d.name === b.direction)))
        throw new common_1.ConflictException('Короб без направления.');
    return result;
}
function cargoHash(cargoes) { return (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(Object.entries(cargoes).sort(([a], [b]) => a.localeCompare(b)))).digest('hex'); }
function assertSupplyMutable(integration, action) {
    if (integration?.frozenHash && action !== 'FINISH')
        throw new common_1.ConflictException('Состав зафиксирован для Ozon. Изменение требует отдельной сверки грузомест.');
}
