"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productLinksEnabled = productLinksEnabled;
exports.productLinkCandidate = productLinkCandidate;
exports.linkedOrderSku = linkedOrderSku;
exports.ozonLinkedSkus = ozonLinkedSkus;
exports.readProductLinks = readProductLinks;
exports.wbLinkedSkus = wbLinkedSkus;
exports.wbSkuScope = wbSkuScope;
exports.preserveLegacyProductLinks = preserveLegacyProductLinks;
exports.syncProductLink = syncProductLink;
exports.confirmProductLink = confirmProductLink;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
// FIX: opt-in by deployment AND client; legacy clients do not query the new table.
function productLinksEnabled(clientId) {
    return process.env.WMS_MARKETPLACE_PRODUCT_LINKS_ENABLED === 'true' &&
        (process.env.WMS_MARKETPLACE_PRODUCT_LINK_CLIENTS ?? '').split(',').map(s => s.trim()).includes(clientId);
}
const norm = (s) => (s ?? '').trim().toLocaleLowerCase('ru-RU');
function productLinkCandidate(p, candidates) {
    const matches = candidates.filter(s => s.barcodes.some(b => p.barcodes.includes(b.value)));
    if (matches.length !== 1)
        return { skuId: null, reason: matches.length ? 'Несколько товаров с этим штрихкодом' : 'Нет товара с этим штрихкодом' };
    const s = matches[0];
    if (['size', 'color'].some(k => norm(p[k]) && norm(s[k]) && norm(p[k]) !== norm(s[k])))
        return { skuId: null, reason: 'Не совпадает размер или цвет' };
    return { skuId: s.id, reason: null };
}
// FIX: incoming orders resolve through the same account-specific physical identity as publication.
function linkedOrderSku(links, connectionId, barcodes, wbIdentity, offerId) {
    const candidates = links.filter(l => l.connectionId === connectionId && l.status === 'LINKED' &&
        (wbIdentity ? l.productId === wbIdentity : offerId ? l.offerId === offerId : l.barcodes.some(b => barcodes.includes(b))));
    return candidates.length === 1 ? candidates[0].skuId : null;
}
// FIX: Ozon consumers use the chosen account's identity even for a WB-origin warehouse SKU.
async function ozonLinkedSkus(db, clientId, connectionId, rows) {
    if (!productLinksEnabled(clientId))
        return rows;
    const links = (await readProductLinks(db, clientId, connectionId)).filter(l => l.marketplace === 'OZON' && l.status === 'LINKED');
    const bySku = new Map(links.map(l => [l.skuId, l]));
    return rows.flatMap(s => { const link = bySku.get(s.id); return link ? [{ ...s, marketplaceProductId: link.productId, marketplaceOfferId: link.offerId }] : []; });
}
async function readProductLinks(db, clientId, connectionId, productId, skuId) {
    if (!productLinksEnabled(clientId))
        return [];
    return db.$queryRaw `SELECT l.id,l."clientId",l."connectionId",l."skuId",l.marketplace,l."productId",l."offerId",l.barcodes,l.size,l.color,l.status,l.reason,l."updatedAt" FROM "MarketplaceProductLink" l
    JOIN "ClientMarketplaceConnection" c ON c.id=l."connectionId" AND c."clientId"=l."clientId"
    WHERE l."clientId"=${clientId} ${connectionId ? client_1.Prisma.sql `AND l."connectionId"=${connectionId}` : client_1.Prisma.empty}
    ${productId ? client_1.Prisma.sql `AND l."productId"=${productId}` : client_1.Prisma.empty}
    ${skuId ? client_1.Prisma.sql `AND l."skuId"=${skuId}` : client_1.Prisma.empty}
    ORDER BY l."productId"`;
}
// FIX: one WB identity per physical SKU per account, with fail-closed publication before reconciliation.
async function wbLinkedSkus(db, clientId, connectionId, rows) {
    if (!productLinksEnabled(clientId))
        return rows;
    if (!connectionId)
        throw new common_1.ConflictException('Для связанных карточек выберите кабинет WB.');
    const links = (await readProductLinks(db, clientId, connectionId)).filter(l => l.marketplace === 'WILDBERRIES' && l.status === 'LINKED' && l.skuId);
    const bySku = new Map(links.map(l => [l.skuId, l.productId]));
    return rows.flatMap(s => bySku.has(s.id) ? [{ ...s, marketplaceProductId: bySku.get(s.id) }] : []);
}
function wbSkuScope(clientId, legacy) {
    return productLinksEnabled(clientId) ? {} : legacy;
}
// FIX: preserve existing identities only when their owning account is unambiguous.
async function preserveLegacyProductLinks(db, clientId) {
    if (!productLinksEnabled(clientId))
        return;
    await db.$transaction(async (tx) => {
        await tx.$queryRaw `SELECT id FROM "Client" WHERE id=${clientId} FOR UPDATE`;
        const connections = await tx.clientMarketplaceConnection.findMany({ where: { clientId, isActive: true, marketplace: { in: ['WILDBERRIES', 'OZON'] } }, select: { id: true, marketplace: true } });
        const skus = await tx.sku.findMany({ where: { clientId, marketplaceProductId: { not: null }, isDraft: false }, include: { barcodes: true } });
        for (const s of skus) {
            const accounts = connections.filter(c => c.marketplace === s.marketplace);
            if (accounts.length !== 1)
                continue;
            await tx.$executeRaw `INSERT INTO "MarketplaceProductLink" (id,"clientId","connectionId","skuId",marketplace,"productId","offerId",barcodes,size,color,status,payload,"updatedAt")
        VALUES (${(0, node_crypto_1.randomUUID)()},${clientId},${accounts[0].id},${s.id},${s.marketplace},${s.marketplaceProductId},${s.marketplaceOfferId ?? ''},${s.barcodes.map(b => b.value)},${s.size},${s.color},'LINKED',${JSON.stringify(s.marketplacePayload ?? {})}::jsonb,NOW()) ON CONFLICT DO NOTHING`;
        }
    }, { timeout: 60000 });
}
async function syncProductLink(db, connection, p, createData) {
    return db.$transaction(async (tx) => {
        // Same-client imports and manual confirmations serialize without locking warehouse movements.
        await tx.$queryRaw `SELECT id FROM "Client" WHERE id=${connection.clientId} FOR UPDATE`;
        const prior = (await readProductLinks(tx, connection.clientId, connection.id, p.productId))[0];
        const candidates = await tx.sku.findMany({ where: { clientId: connection.clientId, barcodes: { some: { value: { in: p.barcodes } } } }, include: { barcodes: true } });
        let decision = productLinkCandidate(p, candidates);
        let created = false;
        if (prior?.status === 'LINKED') {
            // An established identity never silently switches to a new physical product.
            const linked = await tx.sku.findFirst({ where: { id: prior.skuId, clientId: connection.clientId }, include: { barcodes: true } });
            const checked = linked ? productLinkCandidate(p, [linked]) : { skuId: null, reason: 'Связанный товар не найден' };
            decision = checked.skuId === prior.skuId ? checked : { skuId: null, reason: 'Изменились реквизиты связанной карточки; требуется сверка' };
        }
        else if (!candidates.length && !prior && p.barcodes.length) {
            const existing = await tx.sku.findFirst({ where: { clientId: connection.clientId, internalSku: createData.internalSku } });
            if (!existing) {
                const s = await tx.sku.create({ data: createData });
                for (const value of [...new Set(p.barcodes)])
                    await tx.barcode.create({ data: { skuId: s.id, value, isPrimary: value === p.barcodes[0] } });
                decision = { skuId: s.id, reason: null };
                created = true;
            }
            else
                decision = { skuId: null, reason: 'Артикул уже существует с другим штрихкодом' };
        }
        if (decision.skuId) {
            const other = (await readProductLinks(tx, connection.clientId, connection.id, undefined, decision.skuId)).find(l => l.productId !== p.productId && l.status === 'LINKED');
            if (other)
                decision = { skuId: null, reason: 'Другой размер карточки этого кабинета уже связан с товаром' };
        }
        const status = decision.skuId ? 'LINKED' : 'REVIEW', id = prior?.id ?? (0, node_crypto_1.randomUUID)();
        await tx.$executeRaw `INSERT INTO "MarketplaceProductLink" (id,"clientId","connectionId","skuId",marketplace,"productId","offerId",barcodes,size,color,status,reason,payload,"updatedAt")
      VALUES (${id},${connection.clientId},${connection.id},${decision.skuId},${connection.marketplace},${p.productId},${p.offerId},${p.barcodes},${p.size ?? null},${p.color ?? null},${status},${decision.reason},${JSON.stringify(p.payload ?? {})}::jsonb,NOW())
      ON CONFLICT ("connectionId","productId") DO UPDATE SET "skuId"=EXCLUDED."skuId", "offerId"=EXCLUDED."offerId",barcodes=EXCLUDED.barcodes,size=EXCLUDED.size,color=EXCLUDED.color,status=EXCLUDED.status,reason=EXCLUDED.reason,payload=EXCLUDED.payload,"updatedAt"=NOW()`;
        return { created, mergedDrafts: 0, barcodesTouched: created ? p.barcodes.length : 0, review: !decision.skuId };
    });
}
async function confirmProductLink(db, clientId, connectionId, linkId, skuId, expectedUpdatedAt, reason, actorId) {
    if (!productLinksEnabled(clientId))
        throw new common_1.NotFoundException();
    return db.$transaction(async (tx) => {
        await tx.$queryRaw `SELECT id FROM "Client" WHERE id=${clientId} FOR UPDATE`;
        const link = (await readProductLinks(tx, clientId, connectionId)).find(l => l.id === linkId);
        if (!link || link.status === 'LINKED')
            throw new common_1.ConflictException('Карточка уже обработана или не найдена. Обновите сверку.');
        if (new Date(link.updatedAt).toISOString() !== expectedUpdatedAt)
            throw new common_1.ConflictException('Карточка изменилась. Обновите сверку.');
        const sku = await tx.sku.findFirst({ where: { id: skuId, clientId }, include: { barcodes: true } });
        if (!sku || !reason.trim() || productLinkCandidate(link, [sku]).skuId !== sku.id)
            throw new common_1.ConflictException('Нужны совпадающие штрихкод, размер и цвет и причина решения.');
        if ((await readProductLinks(tx, clientId, connectionId)).some(l => l.id !== link.id && l.skuId === skuId && l.status === 'LINKED'))
            throw new common_1.ConflictException('Этот товар уже связан с другой карточкой кабинета. Обновите сверку.');
        await tx.$executeRaw `UPDATE "MarketplaceProductLink" SET "skuId"=${skuId},status='LINKED',reason=NULL,"updatedAt"=NOW() WHERE id=${linkId}`;
        await tx.auditLog.create({ data: { userId: actorId, action: 'marketplace_product_link.confirmed', entity: 'MarketplaceProductLink', entityId: linkId, payload: { clientId, connectionId, skuId, reason, previous: JSON.parse(JSON.stringify(link)) } } });
        return { linked: true };
    });
}
