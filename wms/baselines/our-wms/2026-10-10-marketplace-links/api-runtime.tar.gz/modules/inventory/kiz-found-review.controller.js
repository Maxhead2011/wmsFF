"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.KizFoundReviewController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const kiz_found_review_1 = require("./kiz-found-review");
class FoundDto {
    action;
    id;
    markId;
    reason;
    confirmed;
    boxCode;
    releaseBindings;
}
__decorate([
    (0, class_validator_1.IsIn)(['OPEN', 'REUSE', 'RELABEL', 'RETURN', 'REJECT']),
    __metadata("design:type", String)
], FoundDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], FoundDto.prototype, "id", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], FoundDto.prototype, "markId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(5),
    (0, class_validator_1.MaxLength)(1000),
    __metadata("design:type", String)
], FoundDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], FoundDto.prototype, "confirmed", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], FoundDto.prototype, "boxCode", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], FoundDto.prototype, "releaseBindings", void 0);
// FIX: separate opt-in controller; the published evidence provider is loaded only for an authorized action.
let KizFoundReviewController = class KizFoundReviewController {
    prisma;
    clients;
    constructor(prisma, clients) {
        this.prisma = prisma;
        this.clients = clients;
    }
    service() { return new kiz_found_review_1.KizFoundReview(this.prisma, this.clients, (db, client, kiz) => require('../../common/kiz-wb-reuse').inspectKizReuse(db, client, kiz)); }
    list(user) { return this.service().list(user); }
    async act(dto, user) { const s = this.service(); return s.view(await s.act(dto, user), user); }
};
exports.KizFoundReviewController = KizFoundReviewController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], KizFoundReviewController.prototype, "list", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [FoundDto, Object]),
    __metadata("design:returntype", Promise)
], KizFoundReviewController.prototype, "act", null);
exports.KizFoundReviewController = KizFoundReviewController = __decorate([
    (0, common_1.Controller)('inventory/kiz-found'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object])
], KizFoundReviewController);
