"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withVerifiedBarcodeUpdate = withVerifiedBarcodeUpdate;
exports.isVerifiedBarcodeUpdate = isVerifiedBarcodeUpdate;
exports.barcodeIdentityMatches = barcodeIdentityMatches;
exports.barcodeCatalogReview = barcodeCatalogReview;
const node_async_hooks_1 = require("node:async_hooks");
const verifiedUpdate = new node_async_hooks_1.AsyncLocalStorage();
// FIX: only the complete, account-scoped catalog review can authorize a description update.
function withVerifiedBarcodeUpdate(skuId, product, action) {
    return verifiedUpdate.run({ skuId, product }, action);
}
function isVerifiedBarcodeUpdate(sku, product) {
    const proof = verifiedUpdate.getStore();
    return proof?.skuId === sku.id && proof.product === product;
}
const codes = (sku) => [...new Set([sku.marketplaceOfferId, ...(sku.barcodes ?? []).map(x => x.value)].filter((s) => Boolean(s)))];
const descriptionMatches = (sku, product) => (sku.article ?? '').trim().toLowerCase() === (product.article ?? '').trim().toLowerCase() &&
    (sku.size ?? '').trim().toLowerCase() === (product.size ?? '').trim().toLowerCase();
function identityIndex(owners, products) {
    const skuByCode = new Map(), productByCode = new Map();
    const add = (map, code, id) => {
        if (!code)
            return;
        if (!map.has(code))
            map.set(code, new Set());
        map.get(code).add(id);
    };
    for (const sku of owners)
        for (const code of codes(sku))
            add(skuByCode, code, sku.id);
    for (const product of products)
        for (const code of product.barcodes ?? [])
            add(productByCode, code, product.productId);
    return (sku, product) => {
        if (sku.marketplaceProductId !== product.productId)
            return false;
        const shared = codes(sku).filter(code => product.barcodes?.includes(code));
        const candidateOwners = new Set((product.barcodes ?? []).flatMap(code => [...(skuByCode.get(code) ?? [])]));
        return candidateOwners.size === 1 && candidateOwners.has(sku.id) && shared.length > 0 && shared.every(code => skuByCode.get(code)?.size === 1 && productByCode.get(code)?.size === 1);
    };
}
// FIX: descriptions do not identify physical goods. A barcode must be unique in
// both this client's WMS catalog and this connection's complete WB catalog.
function barcodeIdentityMatches(sku, product, owners, products) {
    return identityIndex(owners, products)(sku, product);
}
// FIX: classify changed descriptions as warnings only with unambiguous barcode proof.
// The caller may update descriptions only through the verified upsert context.
function barcodeCatalogReview(skus, products, owners, legacy) {
    if (!products.length || new Set(products.map(p => p.productId)).size !== products.length)
        throw new Error('Каталог WB пуст или содержит повторные размеры.');
    const excluded = [];
    const warnings = [];
    const matchesBarcode = identityIndex(owners, products);
    const productsById = new Map(products.map(product => [product.productId, product]));
    for (const sku of skus) {
        const chrtId = Number(sku.marketplaceProductId?.split(':')[1]);
        if (!Number.isSafeInteger(chrtId) || chrtId <= 0)
            continue;
        const product = productsById.get(sku.marketplaceProductId);
        const proof = product && matchesBarcode(sku, product);
        const hasCodes = codes(sku).length > 0 && Boolean(product?.barcodes?.length);
        if (product && (proof || (!hasCodes && legacy(sku, product)))) {
            if (proof && !descriptionMatches(sku, product))
                warnings.push({ skuId: sku.id, chrtId, reason: 'BARCODE_MATCH_DESCRIPTION_CHANGED', article: sku.article, size: sku.size, wbArticle: product.article ?? null, wbSize: product.size ?? null });
            continue;
        }
        excluded.push({ skuId: sku.id, chrtId, reason: product ? 'IDENTITY_CHANGED' : 'MISSING', article: sku.article, size: sku.size, wbArticle: product?.article ?? null, wbSize: product?.size ?? null });
    }
    return { excluded, warnings };
}
