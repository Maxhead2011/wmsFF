"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.proofKey = exports.closedSupplyEnabled = void 0;
exports.closedSupplyMatches = closedSupplyMatches;
exports.closedSupplyBillingKeys = closedSupplyBillingKeys;
// FIX: own-installation policy; preserve actual WB statuses and require exact supply membership.
const closedSupplyEnabled = () => process.env.WMS_WB_CLOSED_SUPPLY_COMPLETION_ENABLED === 'true';
exports.closedSupplyEnabled = closedSupplyEnabled;
const proofKey = (id) => 'wb-closed-supply-proof:v1:' + id;
exports.proofKey = proofKey;
function closedSupplyMatches(expected, supply) {
    return supply.done === true && expected.length > 0 && new Set(expected).size === expected.length &&
        new Set(supply.orderIds).size === supply.orderIds.length && expected.length === supply.orderIds.length && expected.every(id => supply.orderIds.includes(id));
}
async function closedSupplyBillingKeys(db, clientId) {
    if (!(0, exports.closedSupplyEnabled)())
        return new Set();
    const rows = await db.systemSetting.findMany({ where: { key: { startsWith: 'wb-closed-supply-proof:v1:' } }, select: { value: true } });
    return new Set(rows.flatMap((r) => r.value?.clientId === clientId ? (r.value.orders ?? []).map((o) => o.connectionId + ':' + o.id) : []));
}
