import {r as React,A as request} from './fulfillment-groups-host-20261125.js';
import {AnalyticsPanel as WildberriesAnalyticsPanel} from './admin-tiles-20261019-26.js';
const {useEffect,useMemo,useState}=React;
const detailLabels = { kind: 'По видам товаров', model: 'По моделям', color: 'Модель + цвет', size: 'Модель + цвет + размер', sku: 'Без группировки (SKU)' };
const fmt = (n) => n === null ? '—' : n.toLocaleString('ru-RU', { maximumFractionDigits: 2 });
const day = (offset) => new Date(Date.now() + 3 * 3600000 + offset * 86400000).toISOString().slice(0, 10);
const warningLabels = { GROUP_COLOR_CONFLICT: 'Цвет в названии отличается от поля карточки: проверьте исходные данные', GROUP_MODEL_UNKNOWN: 'Модель не определена: карточка оставлена отдельно', GROUP_SIZE_INFERRED: 'Размер взят из структуры артикула', GROUP_PARTIAL_RECOMMENDATION: 'Рекомендация известна только для части SKU', INVALID_STOCK: 'Остатки противоречивы: рекомендация не рассчитана', SHORT_HISTORY: 'Мало истории для прогноза', STOCK_HISTORY_UNRELIABLE: 'Историю остатков нельзя подтвердить', STOCKOUT_DEMAND_UNDERESTIMATED: 'Были дни без товара: спрос может быть выше', NO_SHIPMENTS: 'Нет отгрузок за период' };
// FIX: results belong to an explicit client + warehouse + submitted filter; stale responses are discarded.
function FulfillmentPanel({ session, channel }) {
    const [detail, setDetail] = useState('model'), [expanded, setExpanded] = useState(() => new Set());
    const [clients, setClients] = useState([]), [clientId, setClient] = useState(''), [warehouseId, setWarehouse] = useState('');
    const [dateFrom, setFrom] = useState(() => day(-90)), [dateTo, setTo] = useState(() => day(-1));
    const [lead, setLead] = useState(7), [review, setReview] = useState(7), [safety, setSafety] = useState(3);
    const [query, setQuery] = useState(''), [data, setData] = useState(null), [loading, setLoading] = useState(true), [error, setError] = useState('');
    const [search, setSearch] = useState(''), [group, setGroup] = useState(''), [sort, setSort] = useState('shippedUnits'), [page, setPage] = useState(0), [selected, setSelected] = useState(null);
    useEffect(() => { let active = true; setLoading(true); request('/analytics/fulfillment/clients', { accessToken: session.accessToken }).then(rows => { if (!active)
        return; setClients(rows); setClient(rows[0]?.id ?? ''); setWarehouse(rows[0]?.warehouses[0]?.id ?? ''); }).catch(e => { if (active)
        setError(e.message); }).finally(() => { if (active)
        setLoading(false); }); return () => { active = false; }; }, [session.accessToken]);
    useEffect(() => { if (!query)
        return; let active = true; setLoading(true); setError(''); setData(null); setSelected(null); const params = new URLSearchParams(query); params.delete('refresh'); request('/analytics/fulfillment/dashboard?' + params.toString(), { accessToken: session.accessToken }).then(result => { if (active) {
        setData(result);
        setExpanded(new Set());
    } }).catch(e => { if (active)
        setError(e.message); }).finally(() => { if (active)
        setLoading(false); }); return () => { active = false; }; }, [query, session.accessToken]);
    const warehouses = clients.find(c => c.id === clientId)?.warehouses ?? [];
    // FIX: classify the whole selected level before search/pagination; expanded rows never inflate totals.
    const population = detail === 'sku' ? (data?.items ?? []) : (data?.groups?.[detail] ?? data?.items ?? []);
    const matches = (p) => [p.name, p.article, p.size, p.color, p.searchText].join(' ').toLocaleLowerCase('ru').includes(search.toLocaleLowerCase('ru'));
    const compare = (a, b) => (sort === 'slowest' ? a.shippedUnits - b.shippedUnits : (b[sort] ?? -1) - (a[sort] ?? -1)) || a.skuId.localeCompare(b.skuId);
    const rows = [...population].filter(p => (!group || p.abc + (p.xyz ?? '?') === group) && matches(p)).sort(compare);
    const byId = useMemo(() => new Map([...(data?.items ?? []), ...Object.values(data?.groups ?? {}).flat()].map(p => [p.skuId, p])), [data]);
    const visible = [];
    const visit = (item, depth) => { visible.push({ item, depth }); if (expanded.has(item.skuId))
        item.children?.map(id => byId.get(id)).filter((p) => !!p && matches(p)).sort(compare).forEach(p => visit(p, depth + 1)); };
    rows.slice(page * 25, page * 25 + 25).forEach(p => visit(p, 0));
    const reset = () => { setQuery(''); setData(null); setSelected(null); setPage(0); setLoading(false); setError(''); setExpanded(new Set()); };
    return React.createElement("div", { className: "ff-report" },
        React.createElement("header", null,
            React.createElement("h2", null,
                "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A ",
                channel === 'FBS' ? 'ФБС' : 'ФБО'),
            React.createElement("p", null, "\u0422\u043E\u0432\u0430\u0440\u043E\u043E\u0431\u043E\u0440\u043E\u0442 \u0438 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u043D\u0430 \u0441\u043A\u043B\u0430\u0434\u0435 \u0444\u0443\u043B\u0444\u0438\u043B\u043C\u0435\u043D\u0442\u0430. \u0414\u0430\u0442\u044B \u2014 \u043F\u043E \u041C\u043E\u0441\u043A\u0432\u0435; \u043E\u0442\u0433\u0440\u0443\u0437\u043A\u0438 \u2014 \u043F\u043E \u043F\u0435\u0440\u0432\u043E\u043C\u0443 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044E \u0437\u0430\u044F\u0432\u043A\u0438 \u0432 \u0412\u041C\u0421.")),
        React.createElement("form", { className: "ff-filters", onSubmit: e => { e.preventDefault(); setPage(0); setQuery(new URLSearchParams({ clientId, warehouseId, dateFrom, dateTo, channel, leadDays: String(lead), reviewDays: String(review), safetyDays: String(safety), refresh: String(Date.now()) }).toString()); } },
            React.createElement("label", null,
                "\u041A\u043B\u0438\u0435\u043D\u0442",
                React.createElement("select", { "aria-label": "\u041A\u043B\u0438\u0435\u043D\u0442", value: clientId, onChange: e => { reset(); setClient(e.target.value); setWarehouse(clients.find(c => c.id === e.target.value)?.warehouses[0]?.id ?? ''); } }, clients.map(c => React.createElement("option", { key: c.id, value: c.id },
                    c.code,
                    " \u00B7 ",
                    c.name)))),
            React.createElement("label", null,
                "\u0421\u043A\u043B\u0430\u0434 \u0424\u0424",
                React.createElement("select", { "aria-label": "\u0421\u043A\u043B\u0430\u0434 \u0424\u0424", value: warehouseId, onChange: e => { reset(); setWarehouse(e.target.value); } }, warehouses.map(w => React.createElement("option", { key: w.id, value: w.id }, w.name)))),
            React.createElement("label", null,
                "\u0421 \u0434\u0430\u0442\u044B",
                React.createElement("input", { type: "date", required: true, value: dateFrom, max: dateTo, onChange: e => { reset(); setFrom(e.target.value); } })),
            React.createElement("label", null,
                "\u041F\u043E \u0434\u0430\u0442\u0443",
                React.createElement("input", { type: "date", required: true, value: dateTo, min: dateFrom, max: day(-1), onChange: e => { reset(); setTo(e.target.value); } })),
            channel === 'FBS' && React.createElement(React.Fragment, null,
                React.createElement("label", null,
                    "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430 \u043D\u0430 \u0424\u0424, \u0434\u043D\u0435\u0439",
                    React.createElement("input", { type: "number", min: "0", max: "90", required: true, value: lead, onChange: e => { reset(); setLead(Number(e.target.value)); } })),
                React.createElement("label", null,
                    "\u041C\u0435\u0436\u0434\u0443 \u043F\u043E\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F\u043C\u0438, \u0434\u043D\u0435\u0439",
                    React.createElement("input", { type: "number", min: "0", max: "90", required: true, value: review, onChange: e => { reset(); setReview(Number(e.target.value)); } })),
                React.createElement("label", null,
                    "\u0421\u0442\u0440\u0430\u0445\u043E\u0432\u043E\u0439 \u0437\u0430\u043F\u0430\u0441, \u0434\u043D\u0435\u0439",
                    React.createElement("input", { type: "number", min: "0", max: "90", required: true, value: safety, onChange: e => { reset(); setSafety(Number(e.target.value)); } }))),
            React.createElement("button", { type: "submit", disabled: loading || !warehouseId || !clientId }, "\u0420\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044C")),
        loading && React.createElement("p", { role: "status" }, "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u043C \u0434\u0430\u043D\u043D\u044B\u0435\u2026"),
        error && React.createElement("p", { role: "alert", className: "ff-warning" }, error),
        !loading && !clients.length && !error && React.createElement("p", null, "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432."),
        clientId && !warehouses.length && React.createElement("p", null, "\u041A \u044D\u0442\u043E\u043C\u0443 \u043A\u043B\u0438\u0435\u043D\u0442\u0443 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0451\u043D \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0439 \u0441\u043A\u043B\u0430\u0434 \u0424\u0424."),
        data && React.createElement(React.Fragment, null,
            React.createElement("p", { className: "ff-note" },
                "\u041F\u0435\u0440\u0438\u043E\u0434: ",
                data.period.from,
                " \u2014 ",
                data.period.to,
                ". \u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u043D\u0430 ",
                new Date(data.generatedAt).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' }),
                " \u041C\u0421\u041A."),
            React.createElement("div", { className: "ff-kpis" }, [['Карточек SKU', data.summary.products], ['Принято, шт.', data.summary.receivedUnits], ['Отгружено, шт.', data.summary.shippedUnits], ['Завершено заявок', data.quality.completedRequests], ['На складе сейчас, шт.', data.summary.currentUnits], ['Расчётно свободно, шт.', data.summary.freeUnits]].map(([label, value]) => React.createElement("div", { key: label },
                React.createElement("span", null, label),
                React.createElement("strong", null, fmt(Number(value)))))),
            (data.quality.unclassifiedRequests > 0 || data.quality.missingSkuUnits > 0) && React.createElement("p", { className: "ff-warning" },
                "\u041D\u0435 \u0432\u043A\u043B\u044E\u0447\u0435\u043D\u044B \u0432 \u0442\u043E\u0432\u0430\u0440\u043D\u044B\u0439 \u0430\u043D\u0430\u043B\u0438\u0437: ",
                fmt(data.quality.unclassifiedRequests),
                " \u0437\u0430\u044F\u0432\u043E\u043A \u0431\u0435\u0437 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0430 \u0424\u0411\u0421/\u0424\u0411\u041E; ",
                fmt(data.quality.missingSkuUnits),
                " \u0435\u0434\u0438\u043D\u0438\u0446 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u043A\u0430\u043D\u0430\u043B\u0430 \u0431\u0435\u0437 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u043A SKU."),
            React.createElement("details", { className: "ff-method" },
                React.createElement("summary", null, "\u041A\u0430\u043A \u0447\u0438\u0442\u0430\u0442\u044C ABC/XYZ, \u0441\u0440\u043E\u043A\u0438 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0438 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u043E\u0441\u0442\u0430\u0442\u043E\u043A"),
                React.createElement("p", null, "ABC \u2014 \u0432\u043A\u043B\u0430\u0434 \u0432 \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u043E\u0442\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u044B\u0445 \u0435\u0434\u0438\u043D\u0438\u0446: A \u0434\u043E 80%, B \u0434\u043E 95%, C \u2014 \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435. \u0422\u043E\u0432\u0430\u0440\u044B \u0441 \u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u043C \u043E\u0431\u044A\u0451\u043C\u043E\u043C \u043E\u0441\u0442\u0430\u044E\u0442\u0441\u044F \u0432 \u043E\u0434\u043D\u043E\u043C \u043A\u043B\u0430\u0441\u0441\u0435. N \u2014 \u0431\u0435\u0437 \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A. XYZ \u2014 \u0441\u0442\u0430\u0431\u0438\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043F\u043E \u043F\u043E\u043B\u043D\u044B\u043C \u043D\u0435\u0434\u0435\u043B\u044F\u043C: X \u0434\u043E 10% \u0432\u0430\u0440\u0438\u0430\u0446\u0438\u0438, Y \u0434\u043E 25%, Z \u2014 \u0432\u044B\u0448\u0435; \u043D\u0443\u0436\u043D\u044B \u043C\u0438\u043D\u0438\u043C\u0443\u043C 8 \u043D\u0435\u0434\u0435\u043B\u044C. \u041D\u0443\u043B\u0435\u0432\u044B\u0435 \u043D\u0435\u0434\u0435\u043B\u0438 \u0443\u0447\u0438\u0442\u044B\u0432\u0430\u044E\u0442\u0441\u044F."),
                React.createElement("p", null, "\u0421\u0440\u043E\u043A \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u2014 \u0441\u0440\u0435\u0434\u043D\u0438\u0439 \u0432\u043E\u0437\u0440\u0430\u0441\u0442 \u043F\u043E \u0434\u0430\u0442\u0435 \u043F\u0440\u0438\u0451\u043C\u043A\u0438 \u043A\u043E\u0440\u043E\u0431\u0430, \u0430 \u043D\u0435 \u0438\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u043E\u0435 \u043F\u0440\u043E\u0441\u043B\u0435\u0436\u0438\u0432\u0430\u043D\u0438\u0435 \u043A\u0430\u0436\u0434\u043E\u0439 \u0435\u0434\u0438\u043D\u0438\u0446\u044B. \u041F\u043E\u043A\u0440\u044B\u0442\u0438\u0435 \u0440\u044F\u0434\u043E\u043C \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0434\u043E\u043B\u044E \u0442\u043E\u0432\u0430\u0440\u0430 \u0441 \u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0439 \u0434\u0430\u0442\u043E\u0439. \u041F\u0440\u0438\u0445\u043E\u0434 \u0438 \u0442\u0435\u043A\u0443\u0449\u0438\u0435 \u043E\u0441\u0442\u0430\u0442\u043A\u0438 \u043E\u0431\u0449\u0438\u0435 \u0434\u043B\u044F \u0424\u0411\u0421 \u0438 \u0424\u0411\u041E: \u0438\u0445 \u043D\u0435\u043B\u044C\u0437\u044F \u0441\u043A\u043B\u0430\u0434\u044B\u0432\u0430\u0442\u044C \u043C\u0435\u0436\u0434\u0443 \u0432\u043A\u043B\u0430\u0434\u043A\u0430\u043C\u0438. \u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A \u2014 \u0437\u0430\u044F\u0432\u043A\u0438 \u0412\u041C\u0421, \u043D\u0435 \u0437\u0430\u043A\u0430\u0437\u044B \u043F\u043E\u043A\u0443\u043F\u0430\u0442\u0435\u043B\u0435\u0439."),
                React.createElement("p", null, "\u0420\u0430\u0441\u0447\u0451\u0442\u043D\u043E \u0441\u0432\u043E\u0431\u043E\u0434\u043D\u043E = \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0439 \u043E\u0441\u0442\u0430\u0442\u043E\u043A \u043C\u0438\u043D\u0443\u0441 \u043D\u0435\u0437\u0430\u043A\u0440\u044B\u0442\u044B\u0435 \u0437\u0430\u044F\u0432\u043A\u0438 \u0441 \u0443\u0447\u0451\u0442\u043E\u043C \u0443\u0436\u0435 \u0432\u044B\u0434\u0435\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0442\u043E\u0432\u0430\u0440\u0430. \u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u044F \u0424\u0411\u0421 = \u0441\u0440\u0435\u0434\u043D\u0438\u0435 \u043E\u0442\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 \u0434\u0435\u043D\u044C \u00D7 (\u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0430 + \u0438\u043D\u0442\u0435\u0440\u0432\u0430\u043B \u043F\u043E\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F) + \u0441\u0442\u0440\u0430\u0445\u043E\u0432\u043E\u0439 \u0437\u0430\u043F\u0430\u0441. \u0417\u0430\u043F\u0430\u0441 \u2014 \u0431\u043E\u043B\u044C\u0448\u0438\u0439 \u0438\u0437 \u0437\u0430\u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u043D\u0435\u0439 \u0441\u043F\u0440\u043E\u0441\u0430 \u0438 1,65 \u00D7 \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u043E\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435 \u0434\u043D\u0435\u0432\u043D\u044B\u0445 \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A \u00D7 \u221A\u0433\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u0430. \u041D\u0443\u0436\u043D\u043E \u043C\u0438\u043D\u0438\u043C\u0443\u043C 28 \u0434\u043D\u0435\u0439 \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0441 \u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0439 \u043F\u0435\u0440\u0432\u043E\u0439 \u043F\u0440\u0438\u0451\u043C\u043A\u043E\u0439. \u0414\u043E\u0432\u0435\u0437\u0442\u0438 = \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u044F \u043C\u0438\u043D\u0443\u0441 \u0440\u0430\u0441\u0447\u0451\u0442\u043D\u043E \u0441\u0432\u043E\u0431\u043E\u0434\u043D\u044B\u0439 \u043E\u0441\u0442\u0430\u0442\u043E\u043A, \u043D\u0435 \u043C\u0435\u043D\u044C\u0448\u0435 \u043D\u0443\u043B\u044F."),
                React.createElement("p", null, "\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435 \u0442\u043E\u0432\u0430\u0440\u0430 \u043C\u043E\u0433\u043B\u043E \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u0442\u044C \u043E\u0442\u0433\u0440\u0443\u0437\u043A\u0438; \u0443\u043F\u0443\u0449\u0435\u043D\u043D\u044B\u0439 \u0441\u043F\u0440\u043E\u0441 \u043D\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D. \u041D\u043E\u043B\u044C \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A \u043D\u0435 \u0434\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435 \u0431\u0443\u0434\u0443\u0449\u0435\u0433\u043E \u0441\u043F\u0440\u043E\u0441\u0430. \u0414\u043B\u044F \u0424\u0411\u041E \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u044F \u043D\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u044B\u0432\u0430\u0435\u0442\u0441\u044F: \u043F\u0430\u0440\u0442\u0438\u0438 \u043F\u043E\u0441\u0442\u0430\u0432\u043E\u043A \u0442\u0440\u0435\u0431\u0443\u044E\u0442 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u043D\u0430.")),
            React.createElement("div", { className: "ff-filters" },
                React.createElement("label", null,
                    "\u0414\u0435\u0442\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F",
                    React.createElement("select", { "aria-label": "\u0414\u0435\u0442\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F", value: detail, onChange: e => { setDetail(e.target.value); setExpanded(new Set()); setPage(0); setGroup(''); setSelected(null); } }, Object.entries(detailLabels).map(([key, label]) => React.createElement("option", { key: key, value: key }, label))))),
            React.createElement("p", { className: "ff-note" }, "ABC/XYZ \u043F\u0435\u0440\u0435\u0441\u0447\u0438\u0442\u044B\u0432\u0430\u0435\u0442\u0441\u044F \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F; \u0434\u043E\u043B\u044F \u2014 \u043E\u0442 \u0432\u0441\u0435\u0445 \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u043A\u043B\u0438\u0435\u043D\u0442\u0430 \u0438 \u0441\u043A\u043B\u0430\u0434\u0430. \u0420\u0430\u0441\u043A\u0440\u044B\u0442\u044B\u0435 \u0441\u0442\u0440\u043E\u043A\u0438 \u0432\u0445\u043E\u0434\u044F\u0442 \u0432 \u0438\u0442\u043E\u0433\u0438 \u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044F. \u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0438 \u0441\u0443\u043C\u043C\u0438\u0440\u0443\u044E\u0442\u0441\u044F \u043F\u043E SKU: \u0438\u0437\u0431\u044B\u0442\u043E\u043A \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0446\u0432\u0435\u0442\u0430 \u0438\u043B\u0438 \u0440\u0430\u0437\u043C\u0435\u0440\u0430 \u043D\u0435 \u043F\u043E\u043A\u0440\u044B\u0432\u0430\u0435\u0442 \u0434\u0435\u0444\u0438\u0446\u0438\u0442. \u0414\u043B\u044F \u0433\u0440\u0443\u043F\u043F\u044B \u0434\u043D\u0438 \u043F\u043E\u043A\u0440\u044B\u0442\u0438\u044F \u0438 \u0434\u043D\u0438 \u0431\u0435\u0437 \u0442\u043E\u0432\u0430\u0440\u0430 \u043D\u0435 \u043E\u0431\u044A\u0435\u0434\u0438\u043D\u044F\u044E\u0442\u0441\u044F."),
            React.createElement("div", { className: "ff-matrix", "aria-label": "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 ABC XYZ" }, ['A', 'B', 'C', 'N'].flatMap(a => ['X', 'Y', 'Z', 'N', '?'].map(x => { const key = a + x, count = population.filter(p => p.abc + (p.xyz ?? '?') === key).length; return React.createElement("button", { type: "button", key: key, "aria-pressed": group === key, onClick: () => { setGroup(group === key ? '' : key); setPage(0); } },
                key,
                " ",
                React.createElement("strong", null, count)); }))),
            React.createElement("div", { className: "ff-filters" },
                React.createElement("label", null,
                    "\u041D\u0430\u0439\u0442\u0438 \u0442\u043E\u0432\u0430\u0440",
                    React.createElement("input", { type: "search", value: search, placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435, \u0430\u0440\u0442\u0438\u043A\u0443\u043B, \u0440\u0430\u0437\u043C\u0435\u0440", onChange: e => { setSearch(e.target.value); setPage(0); } })),
                React.createElement("label", null,
                    "\u0421\u043D\u0430\u0447\u0430\u043B\u0430",
                    React.createElement("select", { value: sort, onChange: e => { setSort(e.target.value); setPage(0); } },
                        React.createElement("option", { value: "shippedUnits" }, "\u0411\u043E\u043B\u044C\u0448\u0435 \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A"),
                        React.createElement("option", { value: "slowest" }, "\u041C\u0435\u043D\u044C\u0448\u0435 \u043E\u0442\u0433\u0440\u0443\u0437\u043E\u043A"),
                        React.createElement("option", { value: "currentStorageDays" }, "\u0414\u043E\u043B\u044C\u0448\u0435 \u0445\u0440\u0430\u043D\u0438\u0442\u0441\u044F"),
                        channel === 'FBS' && React.createElement(React.Fragment, null,
                            React.createElement("option", { value: "toReplenish" }, "\u0411\u043E\u043B\u044C\u0448\u0435 \u0434\u043E\u0432\u0435\u0437\u0442\u0438"),
                            React.createElement("option", { value: "surplusUnits" }, "\u0411\u043E\u043B\u044C\u0448\u0435 \u0438\u0437\u0431\u044B\u0442\u043E\u043A")))),
                group && React.createElement("button", { type: "button", onClick: () => { setGroup(''); setPage(0); } },
                    "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C ",
                    group),
                React.createElement("span", null,
                    "\u041D\u0430\u0439\u0434\u0435\u043D\u043E ",
                    rows.length,
                    " ",
                    detail === 'sku' ? 'карточек' : 'групп')),
            React.createElement("div", { className: "ff-table-scroll" },
                React.createElement("table", null,
                    React.createElement("thead", null,
                        React.createElement("tr", null, ['Товар / артикул', 'ABC/XYZ', 'Принято, шт.', 'Отгружено, шт. / доля', 'Заявки / дни отгрузок', 'В день, шт.', 'Хранение до отгрузки, дни / покрытие', 'Остаток / свободно, шт.', 'Возраст остатка, дни / покрытие', ...(channel === 'FBS' ? ['Хватит, дней', 'Рекомендовано, шт.', 'Довезти, шт.', 'Избыток, шт.'] : [])].map(h => React.createElement("th", { key: h }, h)))),
                    React.createElement("tbody", null, visible.map(({ item: p, depth }) => React.createElement("tr", { key: p.skuId, className: p.level ? 'ff-group-row' : undefined },
                        React.createElement("td", { style: { paddingLeft: 12 + depth * 20 } },
                            !!p.children?.length && React.createElement("button", { type: "button", className: "ff-expand", "aria-expanded": expanded.has(p.skuId), "aria-label": (expanded.has(p.skuId) ? 'Свернуть ' : 'Раскрыть ') + [p.name, p.color, p.size].filter(Boolean).join(' · '), onClick: () => setExpanded(prev => { const next = new Set(prev); if (next.has(p.skuId))
                                    next.delete(p.skuId);
                                else
                                    next.add(p.skuId); return next; }) }, expanded.has(p.skuId) ? '−' : '+'),
                            React.createElement("button", { type: "button", className: "ff-product", onClick: () => setSelected(p) }, p.name),
                            p.skuCount !== undefined && React.createElement("small", null,
                                p.skuCount,
                                " SKU"),
                            React.createElement("small", null, [p.article, p.size, p.color].filter(Boolean).join(' · ')),
                            p.warnings.length > 0 && React.createElement("small", { className: "ff-caution", title: p.warnings.map(w => warningLabels[w]).join('; ') }, "\u0415\u0441\u0442\u044C \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u0440\u0430\u0441\u0447\u0451\u0442\u0430")),
                        React.createElement("td", null,
                            p.abc,
                            p.xyz ?? '?'),
                        React.createElement("td", null, fmt(p.receivedUnits)),
                        React.createElement("td", null,
                            fmt(p.shippedUnits),
                            " / ",
                            fmt(p.sharePercent),
                            "%",
                            p.shippedMetres != null && React.createElement("small", null,
                                fmt(p.shippedMetres),
                                " \u043C")),
                        React.createElement("td", null,
                            fmt(p.shipmentRequests),
                            " / ",
                            fmt(p.shippingDays)),
                        React.createElement("td", null, fmt(p.averageDaily)),
                        React.createElement("td", null,
                            fmt(p.shippedStorageDays),
                            " / ",
                            fmt(p.shippedAgeCoveragePercent),
                            "%"),
                        React.createElement("td", null,
                            fmt(p.currentUnits),
                            " / ",
                            fmt(p.freeUnits),
                            p.currentMetres != null && React.createElement("small", null,
                                fmt(p.currentMetres),
                                " \u043C \u0432 \u043E\u0442\u0440\u0435\u0437\u0430\u0445")),
                        React.createElement("td", null,
                            fmt(p.currentStorageDays),
                            " / ",
                            fmt(p.currentAgeCoveragePercent),
                            "%"),
                        channel === 'FBS' && React.createElement(React.Fragment, null,
                            React.createElement("td", null, fmt(p.daysOfStock)),
                            React.createElement("td", null,
                                fmt(p.recommendedUnits),
                                p.skuCount !== undefined && React.createElement("small", null,
                                    "\u0420\u0430\u0441\u0447\u0451\u0442 \u0434\u043B\u044F ",
                                    p.recommendationKnownSkus,
                                    " \u0438\u0437 ",
                                    p.skuCount,
                                    " SKU")),
                            React.createElement("td", { className: p.toReplenish ? 'ff-caution' : '' }, fmt(p.toReplenish)),
                            React.createElement("td", null, fmt(p.surplusUnits)))))))),
            !rows.length && React.createElement("p", null, "\u0417\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0439 \u043F\u0435\u0440\u0438\u043E\u0434 \u0442\u043E\u0432\u0430\u0440\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B."),
            React.createElement("div", { className: "ff-pagination" },
                React.createElement("button", { type: "button", disabled: page === 0, onClick: () => setPage(page - 1) }, "\u041D\u0430\u0437\u0430\u0434"),
                React.createElement("span", null,
                    page + 1,
                    " / ",
                    Math.max(1, Math.ceil(rows.length / 25))),
                React.createElement("button", { type: "button", disabled: (page + 1) * 25 >= rows.length, onClick: () => setPage(page + 1) }, "\u0414\u0430\u043B\u0435\u0435")),
            selected && React.createElement("section", { className: "ff-detail", "aria-label": "\u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0442\u043E\u0432\u0430\u0440\u0430" },
                React.createElement("button", { type: "button", onClick: () => setSelected(null) }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438"),
                React.createElement("h3", null, selected.name),
                selected.groupingSources && React.createElement("p", null,
                    "\u0413\u0440\u0443\u043F\u043F\u0438\u0440\u043E\u0432\u043A\u0430: ",
                    selected.groupingSources.join('; '),
                    "."),
                React.createElement("p", null, selected.warnings.map(w => warningLabels[w]).join('. ') || 'Расчёт без дополнительных ограничений.'),
                React.createElement("p", null,
                    "\u0414\u043D\u0435\u0439 \u0441 \u043D\u0443\u043B\u0435\u0432\u044B\u043C \u043E\u0441\u0442\u0430\u0442\u043A\u043E\u043C \u043D\u0430 \u043A\u043E\u043D\u0435\u0446 \u0434\u043D\u044F: ",
                    fmt(selected.stockoutDays),
                    ". \u0412\u043E\u0437\u0432\u0440\u0430\u0442\u043E\u0432 \u0437\u0430 \u043F\u0435\u0440\u0438\u043E\u0434: ",
                    fmt(selected.returnedUnits),
                    " \u0448\u0442."),
                React.createElement("p", null,
                    "\u041E\u0442\u0433\u0440\u0443\u0437\u043A\u0438 \u043F\u043E \u043F\u043E\u043B\u043D\u044B\u043C \u043D\u0435\u0434\u0435\u043B\u044F\u043C, \u0448\u0442. (\u043E\u0442 \u0440\u0430\u043D\u043D\u0435\u0439 \u043A \u043F\u043E\u0437\u0434\u043D\u0435\u0439): ",
                    selected.weeklyUnits.map(fmt).join(' → ') || 'Нет полных недель',
                    "."))));
}
function AnalyticsPanel({ session }) {
    const [tab, setTab] = useState('FBS');
    if (!session.user.fulfillmentAnalyticsEnabled)
        return React.createElement(WildberriesAnalyticsPanel, { session: session });
    return React.createElement("section", { className: "ff-analytics" },
        React.createElement("nav", { "aria-label": "\u0420\u0430\u0437\u0434\u0435\u043B\u044B \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0438", className: "ff-tabs" }, [['FBS', 'Отгрузки ФБС'], ['FBO', 'Отгрузки ФБО'], ['WB', 'Wildberries']].map(([id, label]) => React.createElement("button", { key: id, type: "button", "aria-current": tab === id ? 'page' : undefined, onClick: () => setTab(id) }, label))),
        tab === 'WB' ? session.user.analyticsEnabled ? React.createElement(WildberriesAnalyticsPanel, { session: session }) : React.createElement("p", { role: "status" }, "\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 Wildberries \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0430 \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u0443\u0447\u0451\u0442\u043D\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u0438.") : React.createElement(FulfillmentPanel, { key: tab + session.user.id, session: session, channel: tab }));
}

export {AnalyticsPanel};
