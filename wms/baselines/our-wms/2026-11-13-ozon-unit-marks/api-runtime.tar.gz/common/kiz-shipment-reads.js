"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadShipmentKizReads = loadShipmentKizReads;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const kiz_client_registry_1 = require("./kiz-client-registry");
const kiz_shipment_prefix_1 = require("./kiz-shipment-prefix");
const ozon_unit_marks_1 = require("./ozon-unit-marks");
async function loadShipmentKizReads(tx, request, units) {
    const keys = [...new Set(units.map(u => (0, kiz_client_registry_1.clientKizIdentity)(u.kiz)))].sort();
    if (keys.some(k => !k))
        throw new common_1.ConflictException('Не удалось определить КИЗ поставки. Нужна проверка.');
    const result = new Map();
    if (!keys.length)
        return result;
    // Same keys/hash as lockClientKiz; deterministic lock order prevents competing shipments interleaving.
    const locks = keys.map(k => JSON.stringify(['kiz-client', request.clientId, k])).sort();
    await tx.$queryRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(k,0))::text FROM unnest(${locks}::text[]) AS k ORDER BY k`);
    const current = await tx.clientRequest.findUnique({ where: { id: request.id } });
    if (!current || current.clientId !== request.clientId || current.warehouseId !== request.warehouseId || ['CANCELLED', 'REJECTED'].includes(current.status))
        throw new common_1.ConflictException('Заявка или клиент изменились. Повторите проверку КИЗ.');
    for (let start = 0; start < keys.length; start += 20) {
        const part = keys.slice(start, start + 20), where = (field = 'kiz') => ({ OR: part.map(k => (0, kiz_client_registry_1.clientKizFilter)(k, field)) });
        // Bound memory; a saturated batch fails closed instead of treating omitted rows as absent.
        const take = 10021;
        // FIX: own-WMS indexed range lookup; policy and transaction lifetime remain unchanged.
        const indexed = process.env.WMS_KIZ_SHIPMENT_PREFIX_ENABLED === 'true';
        const ids = async (kind, legacy) => indexed
            ? { id: { in: await (0, kiz_shipment_prefix_1.shipmentPrefixIds)(tx, request, part, kind, take) } } : legacy;
        const marksWhere = await ids('marks', { clientId: request.clientId, ...where('value') });
        const shipmentsWhere = await ids('shipments', { clientId: request.clientId, ...where() });
        const historyWhere = await ids('history', { state: { not: 'RETURNED' }, ...where(), assembly: { request: { clientId: request.clientId, status: 'DONE' } } });
        const tasksWhere = await ids('tasks', { clientId: request.clientId, ...where(), status: { in: ['IN_PROGRESS', 'COMPLETED', 'RETURN_REQUIRED'] } });
        const bindingsWhere = await ids('bindings', { requestId: { not: request.id }, activeMarkId: { not: null }, ...where(), assembly: { request: { clientId: request.clientId } } });
        const [marks, shipments, historyUnits, rows, tasks, bindings] = await Promise.all([
            tx.productMark.findMany({ where: marksWhere, include: { box: true, sku: true }, take }),
            tx.shippedKizHistory.findMany({ where: shipmentsWhere, orderBy: { shippedAt: 'desc' }, take }),
            tx.fboAssemblyUnit.findMany({ where: historyWhere, include: { assembly: { include: { request: true } } }, take }),
            tx.kizReviewCase.findMany({ where: { clientId: request.clientId, kizIdentity: { in: part } }, take }),
            tx.fbsTsdAssembly.findMany({ where: (0, ozon_unit_marks_1.ozonUnitMarksEnabled)() ? { OR: [tasksWhere, { clientId: request.clientId, marketplace: 'OZON', kiz: null, status: { in: ['IN_PROGRESS', 'COMPLETED', 'RETURN_REQUIRED'] } }] } : tasksWhere, take }),
            tx.fboAssemblyUnit.findMany({ where: bindingsWhere, include: { assembly: { include: { request: true } } }, take }),
        ]);
        if ([marks, shipments, historyUnits, rows, tasks, bindings].some(a => a.length >= take))
            throw new common_1.ConflictException('Слишком много записей истории КИЗ. Требуется разбор администратором.');
        const markedTasks = await (0, ozon_unit_marks_1.expandOzonMarkedTasks)(tx, tasks);
        for (const key of part) {
            const prefixes = (0, kiz_client_registry_1.clientKizPrefixes)(key), matches = (row, field = 'kiz') => prefixes.some(prefix => String(row[field] ?? '').startsWith(prefix));
            const ownRows = rows.filter((r) => r.kizIdentity === key);
            result.set(key, { identity: key, request: current, units, rows: ownRows, marks: marks.filter((m) => matches(m, 'value')),
                shipments: shipments.filter((s) => matches(s)).slice(0, 501), historyUnits: historyUnits.filter((u) => matches(u)).slice(0, 501),
                consumed: ownRows.filter((r) => r.status === 'USED' && r.taskId.startsWith('GUARD:')).slice(0, 501),
                claims: ownRows.filter((r) => r.status === 'CLAIMED' && r.taskId.startsWith('GUARD:')),
                tasks: markedTasks.filter((t) => matches(t)), bindings: bindings.filter((u) => matches(u)) });
        }
    }
    return result;
}
