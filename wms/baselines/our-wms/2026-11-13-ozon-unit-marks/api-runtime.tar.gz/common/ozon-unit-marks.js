"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonUnitMarksEnabled = void 0;
exports.ozonMarkedUnits = ozonMarkedUnits;
exports.expandOzonMarkedTasks = expandOzonMarkedTasks;
const common_1 = require("@nestjs/common");
const kiz_client_registry_1 = require("./kiz-client-registry");
const ozon_fbs_pick_lines_1 = require("../modules/marketplace-connections/ozon-fbs-pick-lines");
// FIX: enabled only on our installation; legacy/sold readers keep their previous path.
const ozonUnitMarksEnabled = () => process.env.WMS_OZON_UNIT_MARKS_ENABLED === 'true';
exports.ozonUnitMarksEnabled = ozonUnitMarksEnabled;
// FIX: materialize every marked unit, never substitute the first product for the whole posting.
function ozonMarkedUnits(task, state) {
    if (state?.unitMarksVersion !== 1)
        return task.kiz ? [{ ...task, kiz: task.kiz }] : [];
    const fail = () => { throw new common_1.ConflictException('Поштучный состав КИЗ Ozon неполон или повреждён. Нужна проверка администратора.'); };
    if (task.marketplace !== 'OZON' || !Array.isArray(state.lines) || !state.lines.length)
        return fail();
    const identities = new Set(), products = new Set();
    const result = state.lines.flatMap((line) => {
        if (!Number.isSafeInteger(line.productId) || products.has(line.productId) || !line.skuId || !line.requestItemId ||
            !Number.isSafeInteger(line.quantity) || line.quantity < 1 || !Array.isArray(line.picks) || line.picks.length !== line.quantity)
            return fail();
        products.add(line.productId);
        return line.picks.map((pick, index) => {
            const identity = (0, kiz_client_registry_1.clientKizIdentity)(pick.kiz);
            if (!identity || identities.has(identity))
                return fail();
            identities.add(identity);
            return { ...task, id: `${task.id}:ozon:${line.productId}:${index}`, taskId: task.id,
                skuId: line.skuId, requestItemId: line.requestItemId, kiz: pick.kiz,
                boxId: pick.boxId ?? null, boxCode: pick.boxCode ?? null };
        });
    });
    if (result.length !== task.itemCount)
        return fail();
    return result;
}
async function expandOzonMarkedTasks(db, tasks) {
    const rows = [];
    for (const task of tasks) {
        // Existing scalar tasks incur no extra reads. Per-unit tasks deliberately have no scalar KIZ.
        const state = (0, exports.ozonUnitMarksEnabled)() && task.marketplace === 'OZON' && !task.kiz ? await (0, ozon_fbs_pick_lines_1.readOzonPickState)(db, task.id) : null;
        rows.push(...ozonMarkedUnits(task, state));
    }
    return rows;
}
