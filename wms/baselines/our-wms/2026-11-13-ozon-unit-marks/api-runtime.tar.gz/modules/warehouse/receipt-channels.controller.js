const receipt_processing_1 = require("../billing/receipt-processing");
const receipt_direction_access_1 = require("./receipt-direction-access");
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var ReceiptChannelsController_1;
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceiptChannelsController = void 0;
const core_1 = require("@nestjs/core");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const common_1 = require("@nestjs/common");
const exceljs_1 = __importDefault(require("exceljs"));
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_2 = require("../auth/decorators/require-permissions.decorator");
const client_scope_service_1 = require("../auth/client-scope.service");
const receipt_channel_policy_1 = require("./receipt-channel-policy");
let ReceiptChannelsController = ReceiptChannelsController_1 = class ReceiptChannelsController {
    prisma;
    scopes;
    modules;
    logger = new common_1.Logger(ReceiptChannelsController_1.name);
    constructor(prisma, scopes, modules) {
        this.prisma = prisma;
        this.scopes = scopes;
        this.modules = modules;
    }
    async list(user, clientId, from, to, summary, receiptId) {
        if (typeof clientId !== 'string' || !clientId.trim())
            throw new common_1.BadRequestException('Выберите клиента.');
        this.scopes.requireClientAccess(user, clientId, 'read');
        const warehouseIds = await this.readWarehouses(user, clientId);
        if (!(0, receipt_channel_policy_1.receiptChannelsEnabled)())
            return { enabled: false, rows: [] };
        const since = from && /^\d{4}-\d{2}-\d{2}$/.test(from) ? new Date(from + 'T00:00:00+03:00') : new Date(Date.now() - 30 * 86400000);
        const until = to && /^\d{4}-\d{2}-\d{2}$/.test(to) ? new Date(to + 'T23:59:59+03:00') : new Date();
        if (!Number.isFinite(since.getTime()) || !Number.isFinite(until.getTime()) || since > until)
            throw new common_1.BadRequestException('Проверьте период приёмок.');
        const [groups, saved] = await Promise.all([Promise.all(warehouseIds.map(w => (0, receipt_channel_policy_1.receiptDocuments)(this.prisma, clientId, w, since, undefined, true))), this.prisma.systemSetting.findMany({ where: { key: { startsWith: `receipt.channels.v1:${clientId}:` } }, select: { value: true } })]);
        const docs = groups.flat(), approvals = (await Promise.all(warehouseIds.map(w => (0, receipt_channel_policy_1.receiptApprovalEntries)(this.prisma, clientId, w, docs)))).flat();
        const approvalById = new Map(approvals.map(a => [a.doc.id, a.approval]));
        const processing = (0, receipt_processing_1.receiptProcessingEnabled)() ? await this.prisma.systemSetting.findMany({ where: { key: { startsWith: (0, receipt_processing_1.receiptProcessingPrefix)(clientId) } } }) : [];
        const rules = new Map(saved.map(s => { const r = s.value; return [r.id, r]; }));
        return { enabled: true, processingEnabled: (0, receipt_processing_1.receiptProcessingEnabled)(), canManageProcessing: (0, receipt_processing_1.receiptProcessingEnabled)() && !user.isDemo && user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)) && user.permissionCodes.some(p => ['warehouse:write', 'system:admin'].includes(p)), canEnableManagement: process.env.WMS_RECEIPT_PROCESSING_ENABLED === 'true' && !user.isDemo && user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)) && user.permissionCodes.some(p => ['warehouse:write', 'system:admin'].includes(p)), canManageDirections: await (0, receipt_direction_access_1.canManageReceiptDirections)(this.prisma, user, clientId), rows: docs.filter(d => (!receiptId || d.id === receiptId) && (d.current || new Date(d.date) <= until)).map(d => ({ ...d, processing: processing.find(s => s.key === (0, receipt_processing_1.receiptProcessingKey)(clientId, d.warehouseId, d.id))?.value ?? null, ...(summary === '1' && process.env.WMS_MENU_READS_ENABLED === 'true' ? { boxCount: d.boxes.length, boxes: [] } : {}), approvalEnabled: approvalById.has(d.id), approval: approvalById.get(d.id) ?? { available: true, revision: 0 }, fbs: rules.get(d.id)?.fbs ?? true, fbo: rules.get(d.id)?.fbo ?? true, revision: rules.get(d.id)?.revision ?? 0 })) };
    }
    // FIX: the client can confirm only its own receipt; disabling remains an administrator action.
    async processing(user, body) {
        if (user.isDemo)
            throw new common_1.ForbiddenException('Read-only demo');
        if (!body || typeof body.clientId !== 'string' || typeof body.warehouseId !== 'string' || typeof body.id !== 'string' || !/^[a-f0-9]{32}$/.test(body.id))
            throw new common_1.BadRequestException('Укажите приёмку.');
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        if (!(await this.readWarehouses(user, body.clientId)).includes(body.warehouseId))
            throw new common_1.ForbiddenException('Нет доступа к филиалу.');
        return this.prisma.$transaction(tx => (0, receipt_processing_1.saveReceiptProcessing)(tx, body, user), { timeout: 60000 });
    }
    async enableManagement(user, body) {
        if (user.isDemo)
            throw new common_1.ForbiddenException('Read-only demo');
        if (!body || typeof body.clientId !== 'string' || typeof body.warehouseId !== 'string')
            throw new common_1.BadRequestException('Укажите клиента и филиал.');
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        if (!(await this.readWarehouses(user, body.clientId)).includes(body.warehouseId))
            throw new common_1.ForbiddenException('Нет доступа к филиалу.');
        await this.prisma.$transaction(tx => (0, receipt_channel_policy_1.enableReceiptManagement)(tx, body.clientId, body.warehouseId, user));
        return { enabled: true };
    }
    async approval(user, body) {
        if (!body || typeof body.clientId !== 'string' || typeof body.warehouseId !== 'string' || typeof body.id !== 'string' || !/^[a-f0-9]{32}$/.test(body.id) || typeof body.save !== 'boolean')
            throw new common_1.BadRequestException('Укажите клиента, филиал и приёмку.');
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        if (!(await this.readWarehouses(user, body.clientId)).includes(body.warehouseId))
            throw new common_1.ForbiddenException('Нет доступа к приёмке этого филиала.');
        if (user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)))
            (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        const result = await this.prisma.$transaction(tx => (0, receipt_channel_policy_1.changeReceiptApproval)(tx, body, user, body.save), { isolationLevel: body.save ? 'ReadCommitted' : 'RepeatableRead', timeout: 60000 });
        if (body.save)
            this.refresh(body.clientId);
        return result;
    }
    async history(user, clientId, warehouseId, id) {
        await this.readReceipt(user, clientId, warehouseId, id);
        return this.prisma.auditLog.findMany({ where: { entity: 'Receipt', entityId: id, action: { in: ['RECEIPT_STOCK_ACCESS_CHANGED', 'RECEIPT_PROCESSING_CHANGED'] }, AND: [{ payload: { path: ['clientId'], equals: clientId } }, { payload: { path: ['warehouseId'], equals: warehouseId } }] }, select: { createdAt: true, payload: true, action: true }, orderBy: { createdAt: 'desc' }, take: 100 });
    }
    async file(user, clientId, warehouseId, id, response) {
        const doc = await this.readReceipt(user, clientId, warehouseId, id);
        const boxes = new Map(doc.boxes.map(b => [b.id, b.code]));
        const recoveredRows = await require('./receipt-file-recovery').fileRows(this.prisma, clientId, warehouseId, doc);
        const rows = recoveredRows ?? await this.prisma.stockMovement.findMany({ where: { clientId, warehouseId, OR:[{type:'RECEIPT',quantity:{gt:0},OR:doc.boxes.map(b=>({boxId:b.id,sourceDocument:b.receiptDocument?.startsWith('BOX:')?null:b.receiptDocument}))},{id:{in:doc.boxes.flatMap(b=>[...(b.recoveredMovementIds??[]),...(b.linkedAdjustmentIds??[])])}}], createdAt: { gte: new Date(doc.date.slice(0, 4) + '-01-01T00:00:00Z'), lt: new Date((Number(doc.date.slice(0, 4)) + 1) + '-01-01T00:00:00Z') } }, include: { sku: { include: { barcodes: true } }, ...(require('./receipt-kiz-export').receiptKizExportEnabled()?{productMarks:true}:{}) }, orderBy: { createdAt: 'asc' } });
        const receiptBarcodes = recoveredRows ? new Map(rows.map(r => [r.id, r.barcode])) : await require('./receipt-export-barcode').receiptExportBarcodes(this.prisma, rows, boxes);
        const workbook = new exceljs_1.default.Workbook(), sheet = workbook.addWorksheet('Приёмка');
        sheet.columns = [{ header: 'Дата приёмки (МСК)', key: 'date', width: 23 }, { header: 'Короб', key: 'box', width: 24 }, { header: 'Товар', key: 'name', width: 45 }, { header: 'Артикул', key: 'article', width: 28 }, { header: 'Размер', key: 'size', width: 16 }, { header: 'Штрихкод', key: 'barcode', width: 20 }, { header: 'Принято, шт.', key: 'quantity', width: 16 }];
        const finalRows = !recoveredRows && process.env.WMS_RECEIPT_LINKED_ADJUSTMENTS_ENABLED === "true" && doc.boxes.some(b=>b.linkedAdjustmentIds?.length) ? require("./receipt-final-quantities").receiptFinalQuantities(rows) : rows;
        for (const r of finalRows)
            sheet.addRow({ date: r.createdAt ? r.createdAt.toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' }) : '', box: boxes.get(r.boxId), name: r.sku.name, article: r.sku.article, size: r.sku.size, barcode: receiptBarcodes.get(r.id) ?? '', quantity: r.quantity });
        if (recoveredRows) {
            sheet.columns = [...sheet.columns.map(c => ({header:c.header,key:c.key,width:c.width})), {header:'КИЗ',key:'kiz',width:44}, {header:'Строка исходного файла',key:'sourceRow',width:24}, {header:'Основание',key:'evidence',width:55}];
            rows.forEach((r,index)=>{sheet.getRow(index+2).getCell(8).value=r.kiz;sheet.getRow(index+2).getCell(9).value=r.sourceRow;sheet.getRow(index+2).getCell(10).value=r.evidence;});
        }
        sheet.getRow(1).font = { bold: true };
        sheet.views = [{ state: 'frozen', ySplit: 1 }];
        response.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        response.setHeader('Content-Disposition', `attachment; filename="receipt-${id}.xlsx"`);
        const content=Buffer.from(await workbook.xlsx.writeBuffer());
        const kizExport=require('./receipt-kiz-export');
        response.send(!recoveredRows && kizExport.receiptKizExportEnabled()?kizExport.appendReceiptKizSheet(content,await kizExport.receiptKizRows(this.prisma,rows,boxes)):content);
    }
    async readWarehouses(user, clientId) {
        if (user.activeWarehouseId)
            return [user.activeWarehouseId];
        if (user.roleCodes.some(r => ['ADMIN', 'OWNER'].includes(r)))
            throw new common_1.BadRequestException('Выберите филиал.');
        // Viewing/exporting own receipts must not depend on stock-approval configuration.
        // Keep client visibility and tenant checks; never create approval scopes or change stock.
        if (user.roleCodes.includes('CLIENT')) {
            this.scopes.requireClientAccess(user, clientId, 'read');
            const client = await this.prisma.client.findUnique({ where: { id: clientId }, select: { onlineReceiptVisibleToClient: true } });
            if (!client?.onlineReceiptVisibleToClient)
                return [];
            const receipts = await this.prisma.stockMovement.findMany({
                where: { clientId, type: 'RECEIPT', quantity: { gt: 0 } },
                distinct: ['warehouseId'], select: { warehouseId: true },
            });
            const configured = (0, receipt_channel_policy_1.receiptApprovalEnabled)()
                ? await this.prisma.systemSetting.findMany({ where: { key: { startsWith: `receipt.approval.scope.v1:${clientId}:` } }, select: { value: true } })
                : [];
            return [...new Set([...receipts.map(r => r.warehouseId), ...configured.map(s => s.value.warehouseId)].filter(w => typeof w === 'string' && w.length > 0))];
        }
        if (!(0, receipt_channel_policy_1.receiptApprovalEnabled)())
            return [];
        const scopes = await this.prisma.systemSetting.findMany({ where: { key: { startsWith: `receipt.approval.scope.v1:${clientId}:` } }, select: { value: true } });
        return scopes.map(s => String(s.value.warehouseId));
    }
    async readReceipt(user, clientId, warehouseId, id) {
        if (!clientId || !warehouseId || !id)
            throw new common_1.BadRequestException('Укажите приёмку.');
        this.scopes.requireClientAccess(user, clientId, 'read');
        if (!(await this.readWarehouses(user, clientId)).includes(warehouseId))
            throw new common_1.ForbiddenException('Нет доступа к филиалу.');
        const doc = (await (0, receipt_channel_policy_1.receiptDocuments)(this.prisma, clientId, warehouseId, undefined, undefined, true)).find(d => d.id === id);
        if (!doc)
            throw new common_1.NotFoundException('Приёмка не найдена.');
        return doc;
    }
    async assign(user, body) {
        if (!body || typeof body.clientId !== 'string' || typeof body.id !== 'string' || typeof body.boxCode !== 'string' || !body.boxCode.trim() || typeof body.save !== 'boolean')
            throw new common_1.BadRequestException('Укажите приёмку и короб.');
        const warehouseId = (0, receipt_channel_policy_1.requireReceiptChannelAdmin)(user);
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        const result = await this.prisma.$transaction(tx => (0, receipt_channel_policy_1.assignReceiptBox)(tx, body.clientId, warehouseId, body.id, body.boxCode, user.id, body.save), { isolationLevel: 'Serializable', timeout: 30000 });
        if (body.save)
            this.refresh(body.clientId);
        return result;
    }
    preview(user, body) { return this.change(user, body, false); }
    save(user, body) { return this.change(user, body, true); }
    async change(user, body, save) {
        if (!body || typeof body.clientId !== 'string' || !body.clientId.trim() || typeof body.id !== 'string' || !/^[a-f0-9]{32}$/.test(body.id))
            throw new common_1.BadRequestException('Укажите клиента и приёмку.');
        this.scopes.requireClientAccess(user, body.clientId, 'write');
        if (!await receipt_direction_access_1.canManageReceiptDirections(this.prisma,user,body.clientId)) throw new common_1.ForbiddenException('Нет права изменять направления приёмки этого клиента.');
        const admin=user.roleCodes.some(r=>r==='ADMIN'||r==='OWNER');
        const warehouseId=admin?(0,receipt_channel_policy_1.requireReceiptChannelAdmin)(user):body.warehouseId;
        if(typeof warehouseId!=='string'||!(await this.readWarehouses(user,body.clientId)).includes(warehouseId)) throw new common_1.ForbiddenException('Нет доступа к приёмке этого филиала.');
        const result = await this.prisma.$transaction(async (tx) => {
            // FIX: serialize policy changes with each other; serializable scans retry stale reads.
            if (save)
                await tx.$executeRawUnsafe('SELECT pg_advisory_xact_lock(hashtext($1))', `receipt-channels:${body.clientId}:${warehouseId}`);
            return (0, receipt_channel_policy_1.receiptChannelChange)(tx, body.clientId, warehouseId, body.id, body.fbs, body.fbo, body.revision, save, user.id);
        }, { isolationLevel: save ? 'Serializable' : 'RepeatableRead', timeout: 30000 });
        if (save)
            this.refresh(body.clientId);
        return result;
    }
    refresh(clientId) {
        // FIX: schedule recalculation immediately; the existing periodic stock sync retries failures.
        // FIX: a failed background sync must not misreport a committed save as failed.
        void Promise.resolve().then(() => this.modules.get(marketplace_connections_service_1.MarketplaceConnectionsService, { strict: false }).refreshReceiptChannelStocks(clientId))
            .catch(() => this.logger.warn(`Receipt directions saved for ${clientId}; periodic WB stock synchronization will retry.`));
    }
};
exports.ReceiptChannelsController = ReceiptChannelsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('from')),
    __param(3, (0, common_1.Query)("to")),
    __param(4, (0, common_1.Query)("summary")),
    __param(5, (0, common_1.Query)("receiptId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "list", null);
__decorate([
    (0, common_1.Post)('processing'),
    (0, require_permissions_decorator_2.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "processing", null);
__decorate([
    (0, common_1.Post)('enable-management'),
    (0, require_permissions_decorator_2.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "enableManagement", null);
__decorate([
    (0, common_1.Post)('approval'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "approval", null);
__decorate([
    (0, common_1.Get)('history'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('warehouseId')),
    __param(3, (0, common_1.Query)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "history", null);
__decorate([
    (0, common_1.Get)('file.xlsx'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)('clientId')),
    __param(2, (0, common_1.Query)('warehouseId')),
    __param(3, (0, common_1.Query)('id')),
    __param(4, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "file", null);
__decorate([
    (0, common_1.Post)('assign-box'),
    (0, require_permissions_decorator_2.RequirePermissions)('warehouse:write'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ReceiptChannelsController.prototype, "assign", null);
__decorate([
    (0, common_1.Post)('preview'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ReceiptChannelsController.prototype, "preview", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ReceiptChannelsController.prototype, "save", null);
exports.ReceiptChannelsController = ReceiptChannelsController = ReceiptChannelsController_1 = __decorate([
    (0, common_1.Controller)('warehouse/receipt-channels'),
    (0, require_permissions_decorator_1.RequireAnyPermissions)('warehouse:read', 'stock:read', 'client-requests:read'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof core_1.ModuleRef !== "undefined" && core_1.ModuleRef) === "function" ? _c : Object])
], ReceiptChannelsController);
