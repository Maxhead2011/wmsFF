"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FboFbsAvailability = void 0;
exports.loadFboFbsAvailability = loadFboFbsAvailability;
const receipt_channel_policy_1 = require("../warehouse/receipt-channel-policy");
const common_1 = require("@nestjs/common");
const key = (box, sku) => `${box}:${sku}`;
// FIX: keep both a box limit and a warehouse limit for orders awaiting a box route.
class FboFbsAvailability {
    boxes = new Map();
    warehouse = new Map();
    constructor(balances, tasks, rules = new Map()) {
        for (const b of balances) {
            if (!b.boxId || b.quantity <= 0)
                continue;
            const k = key(b.boxId, b.skuId);
            this.boxes.set(k, (this.boxes.get(k) ?? 0) + b.quantity);
            this.warehouse.set(b.skuId, (this.warehouse.get(b.skuId) ?? 0) + b.quantity);
        }
        // FIX: allocate each old/new FBS demand only to receipts that can supply it.
        if (rules.size) {
            for (const t of [...tasks].sort((a, b) => Number(!!(b.boxId || b.reservedBoxId)) - Number(!!(a.boxId || a.reservedBoxId)))) {
                const sku = t.sourceSkuId && !t.relabelConfirmedAt ? t.sourceSkuId : t.skuId;
                let remaining = Math.max(1, t.itemCount);
                const bound = t.boxId || t.reservedBoxId;
                const identity = t.connectionId && t.orderId ? { marketplace: t.marketplace, connectionId: t.connectionId, orderId: t.orderId } : undefined;
                const candidates = [...this.boxes.keys()].filter(k => k.endsWith(`:${sku}`));
                candidates.sort((a, b) => Number(b === key(bound || '', sku)) - Number(a === key(bound || '', sku)) || Number(rules.get(b.slice(0, -sku.length - 1))?.fbs === false) - Number(rules.get(a.slice(0, -sku.length - 1))?.fbs === false) || a.localeCompare(b));
                for (const k of candidates) {
                    const box = k.slice(0, -sku.length - 1);
                    if (!(0, receipt_channel_policy_1.receiptAllows)(rules.get(box), 'fbs', identity))
                        continue;
                    const n = Math.min(Math.max(0, this.boxes.get(k) || 0), remaining);
                    this.boxes.set(k, (this.boxes.get(k) || 0) - n);
                    remaining -= n;
                    if (!remaining)
                        break;
                }
            }
            this.warehouse.clear();
            for (const [k, n] of this.boxes) {
                const balance = balances.find(b => b.boxId && key(b.boxId, b.skuId) === k);
                if (!(0, receipt_channel_policy_1.receiptAllows)(rules.get(balance.boxId), 'fbo'))
                    this.boxes.set(k, 0);
                else
                    this.warehouse.set(balance.skuId, (this.warehouse.get(balance.skuId) || 0) + Math.max(0, n));
            }
            return;
        }
        for (const t of tasks) {
            const sku = t.sourceSkuId && !t.relabelConfirmedAt ? t.sourceSkuId : t.skuId;
            const qty = Math.max(1, t.itemCount), box = t.boxId ?? t.reservedBoxId;
            this.warehouse.set(sku, (this.warehouse.get(sku) ?? 0) - qty);
            if (box)
                this.boxes.set(key(box, sku), (this.boxes.get(key(box, sku)) ?? 0) - qty);
        }
    }
    free(box, sku) {
        return Math.max(0, Math.min(this.boxes.get(key(box, sku)) ?? 0, this.warehouse.get(sku) ?? 0));
    }
    take(box, sku, quantity) {
        if (quantity > this.free(box, sku))
            throw new common_1.ConflictException('Товар зарезервирован для FBS. Обновите маршрут ФБО и отберите только свободное количество.');
        this.boxes.set(key(box, sku), (this.boxes.get(key(box, sku)) ?? 0) - quantity);
        this.warehouse.set(sku, (this.warehouse.get(sku) ?? 0) - quantity);
    }
}
exports.FboFbsAvailability = FboFbsAvailability;
// FIX: run inside the existing serializable pick transaction, before any stock/KIZ writes.
async function loadFboFbsAvailability(tx, request, skuIds) {
    const balances = await tx.stockBalance.findMany({ where: { clientId: request.clientId,
            warehouseId: request.warehouseId, skuId: { in: skuIds }, status: 'AVAILABLE', quantity: { gt: 0 },
            box: { status: 'active', clientId: request.clientId, warehouseId: request.warehouseId } },
        select: { boxId: true, skuId: true, quantity: true } });
    const requestIds = await tx.clientRequest.findMany({ where: { clientId: request.clientId,
            warehouseId: request.warehouseId, status: { notIn: ['DONE', 'CANCELLED', 'REJECTED'] } }, select: { id: true } });
    const tasks = await tx.fbsTsdAssembly.findMany({ where: { clientId: request.clientId,
            status: { in: ['WAITING_STOCK', 'RESERVED', 'IN_PROGRESS', 'RESCAN_REQUIRED', 'RETURN_REQUIRED', 'COMPLETED'] },
            AND: [{ OR: [{ skuId: { in: skuIds } }, { sourceSkuId: { in: skuIds } }] },
                { OR: [{ stockWarehouseId: request.warehouseId },
                        { stockWarehouseId: null, requestId: { in: requestIds.map(r => r.id) } },
                        { boxId: { in: balances.flatMap(b => b.boxId ? [b.boxId] : []) } },
                        { reservedBoxId: { in: balances.flatMap(b => b.boxId ? [b.boxId] : []) } }] }] },
        select: { id: true, marketplace: true, requestId: true, connectionId: true, orderId: true, status: true,
            sourceBarcode: true, barcode: true, kiz: true,
            skuId: true, sourceSkuId: true, relabelConfirmedAt: true, itemCount: true, boxId: true, reservedBoxId: true } });
    // FIX: physical picking already reduced AVAILABLE; do not subtract that stock twice.
    const taskRequestIds = [...new Set(tasks.map(t => t.requestId))];
    const movements = tasks.length ? await tx.stockMovement.findMany({ where: { clientId: request.clientId,
            sourceDocument: { in: taskRequestIds }, skuId: { in: skuIds }, status: 'PACKING',
            idempotencyKey: { startsWith: 'fbs-sticker-pick:' } }, select: { idempotencyKey: true, quantity: true } }) : [];
    const picked = new Map();
    for (const movement of movements) {
        const id = movement.idempotencyKey.slice('fbs-sticker-pick:'.length).split(':', 1)[0];
        picked.set(id, (picked.get(id) ?? 0) + movement.quantity);
    }
    const openRequests = tasks.length ? await tx.clientRequest.findMany({ where: { id: { in: taskRequestIds },
            status: { notIn: ['DONE', 'CANCELLED', 'REJECTED'] } }, select: { id: true } }) : [];
    const open = new Set(openRequests.map(r => r.id));
    const shipped = tasks.length ? await tx.fbsOrderRequestLink.findMany({ where: { requestId: { in: taskRequestIds },
            lastCategory: { in: ['shipped', 'archive'] }, lastSupplierStatus: 'complete', request: { fbsEmergencyAssemblyAt: null } },
        select: { connectionId: true, orderId: true } }) : [];
    const shippedOrders = new Set(shipped.map(l => `${l.connectionId}:${l.orderId}`));
    const pending = tasks.filter(t => t.status === 'RETURN_REQUIRED' ||
        (t.status === 'IN_PROGRESS' && !!(t.sourceBarcode || t.barcode || t.kiz || t.relabelConfirmedAt)) ||
        (open.has(t.requestId) && !shippedOrders.has(`${t.connectionId}:${t.orderId}`)))
        .map(t => ({ ...t, itemCount: Math.max(1, t.itemCount) - Math.max(0, picked.get(t.id) ?? 0) }))
        .filter(t => t.itemCount > 0);
    const rules = await (0, receipt_channel_policy_1.receiptRules)(tx, request.clientId, request.warehouseId);
    const missing = rules.size ? await (0, receipt_channel_policy_1.receiptUnassignedOrders)(tx, request.clientId, request.warehouseId, new Set(tasks.map(receipt_channel_policy_1.receiptOrderKey))) : [];
    return new FboFbsAvailability(balances, [...pending, ...missing], rules);
}
