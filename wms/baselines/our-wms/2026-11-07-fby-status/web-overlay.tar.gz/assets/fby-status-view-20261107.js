import {r as React} from "./admin-tiles-20261019-0.js";
// FIX: distinguish the marketplace status from the WMS assembly stage and retain check time.
export function FbySupplyStatus({ status, checkedAt }) {
    const date = checkedAt ? new Date(checkedAt) : null;
    return React.createElement("p", null,
        "\u0421\u0442\u0430\u0442\u0443\u0441 \u042F\u043D\u0434\u0435\u043A\u0441\u0430: ",
        React.createElement("strong", null, status || 'Ещё не проверен'),
        date && Number.isFinite(date.getTime()) && React.createElement(React.Fragment, null,
            " \u00B7 \u041F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E ",
            date.toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' }),
            " \u041C\u0421\u041A"),
        React.createElement("small", null, "\u041E\u0431\u043D\u043E\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043F\u043E \u043A\u043D\u043E\u043F\u043A\u0435 \u00AB\u0421\u0432\u0435\u0440\u0438\u0442\u044C \u0441 \u042F\u043D\u0434\u0435\u043A\u0441\u043E\u043C\u00BB."));
}
