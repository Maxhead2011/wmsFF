"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ozonPrintManifest = ozonPrintManifest;
exports.renderOzonPrintPages = renderOzonPrintPages;
exports.annotateOzonLabels = annotateOzonLabels;
const common_1 = require("@nestjs/common");
const pdf_lib_1 = require("pdf-lib");
const node_crypto_1 = require("node:crypto");
const pdf_parse_1 = require("pdf-parse");
// FIX: only a complete, unique set of confirmed cargoes can enter one print job.
function ozonPrintManifest(directions, link) {
    if (!link || !directions.length)
        throw new common_1.BadRequestException('Сначала передайте все грузоместа в Ozon.');
    const supplies = directions.map(d => {
        const id = link.mapping[d.name], op = link.operations[id];
        if (!id || op?.state !== 'SUCCESS' || !op.cargoes?.length)
            throw new common_1.BadRequestException(`Грузоместа направления «${d.name}» ещё не подтверждены.`);
        return { id, name: d.name, cargoIds: op.cargoes.map(c => c.cargoId) };
    });
    const ids = supplies.flatMap(s => s.cargoIds);
    if (new Set(supplies.map(s => s.id)).size !== supplies.length || new Set(ids).size !== ids.length || ids.some(id => !/^\d+$/.test(id)))
        throw new common_1.BadRequestException('Неоднозначное соответствие грузомест. Проверьте результат отправки.');
    if (ids.length > 500)
        throw new common_1.BadRequestException('В одной серии допускается не более 500 грузомест.');
    return { supplies, total: ids.length, fingerprint: (0, node_crypto_1.createHash)('sha256').update(JSON.stringify(supplies)).digest('hex') };
}
// FIX: check identity, not only page count; preserve official artwork and aspect ratio.
async function renderOzonPrintPages(buffer, cargoIds) {
    const parser = new pdf_parse_1.PDFParse({ data: new Uint8Array(buffer) });
    try {
        const text = await parser.getText();
        if (text.pages.length !== cargoIds.length)
            throw new common_1.BadRequestException('Количество этикеток Ozon не совпадает с грузоместами. Печать не начата.');
        const values = text.pages.map(page => {
            const compact = page.text.replace(/\s/g, '');
            const matches = cargoIds.filter(id => compact.includes(id));
            if (matches.length !== 1)
                throw new common_1.BadRequestException('Не удалось однозначно проверить номер грузоместа на этикетке.');
            return matches[0];
        });
        if (new Set(values).size !== cargoIds.length)
            throw new common_1.BadRequestException('Ozon вернул повторные этикетки. Печать не начата.');
        const rendered = await parser.getScreenshot({ scale: 203 / 72, imageDataUrl: false, imageBuffer: true });
        let ratio = 0;
        const pages = rendered.pages.map((page, index) => {
            const b = Buffer.from(page.data), w = b.readUInt32BE(16), h = b.readUInt32BE(20);
            if (index === 0)
                ratio = w / h;
            if (w < 100 || w > 2000 || h < 100 || h > 3000 || Math.abs(w / h - ratio) > .01)
                throw new common_1.BadRequestException('Разные форматы этикеток Ozon в одной серии.');
            return { value: values[index], imageBase64: b.toString('base64') };
        });
        if (pages.length !== cargoIds.length)
            throw new common_1.BadRequestException('Подготовлены не все страницы этикеток.');
        return { widthMm: 120, heightMm: Math.round(120 / ratio), pages };
    }
    finally {
        await parser.destroy();
    }
}
// FIX: match each official page by cargo ID before adding a separate bottom line.
async function annotateOzonLabels(buffer, cargoes, boxes) {
    if (process.env.WMS_OZON_BOX_LABEL_ENABLED !== 'true')
        return buffer;
    if (buffer.length > 20_000_000)
        throw new common_1.BadRequestException('Файл этикеток слишком велик.');
    const parser = new pdf_parse_1.PDFParse({ data: new Uint8Array(buffer) });
    try {
        const { pages } = await parser.getText(), pdf = await pdf_lib_1.PDFDocument.load(buffer);
        const seen = new Set(), font = await pdf.embedFont(pdf_lib_1.StandardFonts.HelveticaBold);
        if (!cargoes.length || pages.length !== cargoes.length || pdf.getPageCount() !== pages.length)
            throw new common_1.BadRequestException('Количество стикеров не совпадает с коробами.');
        for (const [index, page] of pages.entries()) {
            const matches = cargoes.filter(c => page.text.replace(/\s/g, '').includes(c.cargoId));
            const code = matches.length === 1 && boxes.find(b => b.id === matches[0].key)?.boxCode;
            if (!code || seen.has(code))
                throw new common_1.BadRequestException('Не удалось сопоставить стикер с коробом WMS.');
            seen.add(code);
            const sheet = pdf.getPage(index), { width, height } = sheet.getSize(), line = 'WMS: ' + code;
            const size = Math.min(11, (width - 14) / font.widthOfTextAtSize(line, 1));
            sheet.setSize(width, height + 16);
            sheet.translateContent(0, 16);
            sheet.drawText(line, { x: 7, y: 4, size, font });
        }
        return Buffer.from(await pdf.save());
    }
    finally {
        await parser.destroy();
    }
}
