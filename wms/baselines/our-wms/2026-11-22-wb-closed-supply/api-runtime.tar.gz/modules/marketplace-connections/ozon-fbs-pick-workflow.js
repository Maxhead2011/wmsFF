const ozon_unit_marks_1 = require("../../common/ozon-unit-marks");
const ozon_unit_stock_1 = require("./ozon-unit-stock");
const fbs_box_claim_retry_1 = require("./fbs-box-claim-retry");
const kiz_client_registry_1 = require("../../common/kiz-client-registry");
const client_receipt_kiz_policy_1 = require("../../common/client-receipt-kiz-policy");
const kiz_client_review_1 = require("../../common/kiz-client-review");
const fabric_fbs_scan_1 = require("../warehouse/fabric-fbs-scan");
const fabric_fbs_task_state_1 = require("../warehouse/fabric-fbs-task-state");
const marketplace_product_links_1 = require("./marketplace-product-links");
const receipt_channel_policy_1 = require("../warehouse/receipt-channel-policy");
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleOzonPickLines = handleOzonPickLines;
const common_1 = require("@nestjs/common");
const fbs_request_auto_status_1 = require("../../common/stock/fbs-request-auto-status");
const ozon_fbs_pick_lines_1 = require("./ozon-fbs-pick-lines");
const NO_BOX = 'БЕЗ КОРОБА';
const closed = ['DONE', 'CANCELLED', 'REJECTED'];
const singleProductUntil = new WeakMap();
// FIX: only this exact order's manufactured line may bypass source-box selection.
async function producedLine(db, task, state) {
    if (task.sourceArticle !== fabric_fbs_task_state_1.FABRIC_TASK_MARKER)
        return null;
    const active = (0, ozon_fbs_pick_lines_1.ozonActiveLine)(state);
    if (!active)
        return null;
    const lines = await (0, fabric_fbs_task_state_1.readFabricTaskLines)(db, task);
    const line = lines?.find(l => l.lineId === active.requestItemId && l.skuId === active.skuId);
    if (line && line.quantity !== active.quantity)
        throw new common_1.ConflictException('Состав нарезки изменился.');
    return line ?? null;
}
// FIX: normal unit scanning is a separate rollout from administrative recovery.
const unitScanningEnabled = () => process.env.WMS_OZON_TSD_UNIT_MARKS_ENABLED === 'true' && (0, ozon_unit_marks_1.ozonUnitMarksEnabled)() && (0, kiz_client_registry_1.clientKizGuardEnabled)();
async function requireRequestCapacity(tx, task, state) {
    const others = await tx.fbsTsdAssembly.findMany({ where: { requestId: task.requestId, status: 'COMPLETED', id: { not: task.id } } });
    const used = new Map();
    for (const other of others) {
        const lines = other.marketplace === 'OZON' ? await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, other.id) : null;
        if (lines)
            for (const line of lines.lines)
                used.set(line.requestItemId, (used.get(line.requestItemId) ?? 0) + line.picks.length);
        else
            used.set(other.requestItemId, (used.get(other.requestItemId) ?? 0) + other.itemCount);
    }
    for (const line of state.lines) {
        const item = await tx.clientRequestItem.findUnique({ where: { id: line.requestItemId } });
        if (!item || item.requestId !== task.requestId || item.skuId !== line.skuId ||
            (used.get(line.requestItemId) ?? 0) + line.quantity > item.quantity) {
            throw new common_1.ConflictException('Количество по позиции уже собрано или состав заявки изменился. Нужна сверка WMS.');
        }
    }
}
// FIX: serialize request/assembly changes in the same order as the existing completion path.
async function locked(service, task, user, operation) {
    const operationWithLock = () => service.prisma.$transaction(async (tx) => {
        await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${task.requestId} FOR UPDATE`;
        if (task.sourceArticle === fabric_fbs_task_state_1.FABRIC_TASK_MARKER) {
            const key = `fabric.rolls.v1:${task.clientId}`;
            const locks = await tx.$queryRaw `SELECT pg_try_advisory_xact_lock(hashtext(${key})) AS locked`;
            if (locks[0]?.locked !== true)
                throw new common_1.ConflictException('Ткань обрабатывается другим сотрудником. Повторите скан.');
        }
        await tx.$queryRaw `SELECT id FROM "FbsTsdAssembly" WHERE id=${task.id} FOR UPDATE`;
        const fresh = await tx.fbsTsdAssembly.findUnique({ where: { id: task.id } });
        if (fresh?.status === 'COMPLETED') {
            if (fresh.workerUserId !== user.id || fresh.deviceCode !== service.fbsTsdDeviceCode(undefined, user))
                throw new common_1.ConflictException('Задание принадлежит другому сотруднику.');
        }
        else
            service.requireCurrentFbsTsdLease(fresh, user);
        const request = await tx.clientRequest.findUnique({ where: { id: task.requestId } });
        if (!request || request.clientId !== task.clientId || closed.includes(request.status)) {
            throw new common_1.ConflictException('Заявка закрыта или изменена. Обновите очередь.');
        }
        if (!['IN_PROGRESS', 'COMPLETED'].includes(fresh.status))
            throw new common_1.ConflictException('Задание отложено или требует решения менеджера.');
        if (fresh.requestId !== task.requestId || fresh.connectionId !== task.connectionId || fresh.clientId !== task.clientId || fresh.orderId !== task.orderId) {
            throw new common_1.ConflictException('Задание изменилось. Обновите очередь.');
        }
        return operation(tx, fresh);
    }, unitScanningEnabled() ? { isolationLevel: 'Serializable', maxWait: 10000, timeout: 15000 } : undefined);
    return unitScanningEnabled() ? (0, fbs_box_claim_retry_1.runFbsBoxClaimTransaction)(operationWithLock) : operationWithLock();
}
async function initialize(service, task, user) {
    const saved = await (0, ozon_fbs_pick_lines_1.readOzonPickState)(service.prisma, task.id);
    if (saved)
        return saved;
    const cache = singleProductUntil.get(service) ?? new Map();
    singleProductUntil.set(service, cache);
    if (task.itemCount < 2 || (cache.get(task.id) ?? 0) > Date.now())
        return null;
    if (task.status === 'COMPLETED')
        return null; // Historical owner confirmations must not be reinterpreted as new scans.
    const posting = await service.readOzonFbsPickPosting(task);
    const products = (0, ozon_fbs_pick_lines_1.ozonPostingProducts)(posting);
    if (products.length < 2) {
        if (cache.size >= 1000)
            cache.clear();
        cache.set(task.id, Date.now() + 60_000);
        return null;
    }
    const unitScanning = unitScanningEnabled();
    if (posting.status !== 'awaiting_packaging' || task.marketplaceSubmittedAt || task.kiz || task.relabelRequired || (task.requiresKiz && !unitScanning)) {
        throw new common_1.BadRequestException('Многотоварный заказ уже передан или требует маркировки/переклейки. Нужна проверка администратора.');
    }
    if (!unitScanning && posting.requirements?.products_requiring_mandatory_mark?.length)
        throw new common_1.BadRequestException('Ozon требует КИЗ: нужна отдельная проверка многотоварного заказа.');
    const catalog = await (0, marketplace_product_links_1.ozonLinkedSkus)(service.prisma, task.clientId, task.connectionId, await service.prisma.sku.findMany({ where: { clientId: task.clientId }, include: { barcodes: true } }));
    const resolved = products.map(product => ({ product, sku: (0, ozon_fbs_pick_lines_1.resolveOzonLineSku)(product, catalog, unitScanning) }));
    if (resolved[0].sku.id !== task.skuId || products.reduce((n, p) => n + p.quantity, 0) !== task.itemCount) {
        throw new common_1.ConflictException('Состав заказа отличается от заявки WMS. Сначала обновите заявку.');
    }
    if (new Set(resolved.map(row => row.sku.id)).size !== resolved.length)
        throw new common_1.ConflictException('Разные строки Ozon сопоставлены одному товару WMS. Проверьте соответствия.');
    const clientMarked = unitScanning && await (0, client_receipt_kiz_policy_1.clientRequiresReceiptKiz)(service.prisma, task.clientId);
    const mandatory = new Set((posting.requirements?.products_requiring_mandatory_mark ?? []).map(String));
    return locked(service, task, user, async (tx, fresh) => {
        const existing = await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, task.id);
        if (existing)
            return existing;
        if (fresh.status !== 'IN_PROGRESS' || fresh.marketplaceSubmittedAt || fresh.kiz || fresh.relabelRequired || fresh.completedAt)
            throw new common_1.ConflictException('Задание изменилось. Обновите очередь.');
        const firstItem = await tx.clientRequestItem.findUnique({ where: { id: fresh.requestItemId } });
        const delta = fresh.itemCount - products[0].quantity;
        if (!firstItem || firstItem.requestId !== fresh.requestId || firstItem.skuId !== resolved[0].sku.id || firstItem.quantity < fresh.itemCount) {
            throw new common_1.ConflictException('Количество первой позиции уже изменено. Нужна сверка заявки.');
        }
        // Replace this order's old first-product contribution, preserving other orders sharing the item.
        await tx.clientRequestItem.update({ where: { id: firstItem.id }, data: { quantity: { decrement: delta } } });
        const state = {
            version: 1, lines: [], source: null, submission: 'PICKING',
            ...(unitScanning ? { unitMarksVersion: 1 } : {}),
            legacyScansDiscarded: Boolean(fresh.barcode || fresh.scannedItemCount),
        };
        for (const [index, { product, sku }] of resolved.entries()) {
            const existingItem = index === 0 ? firstItem : await tx.clientRequestItem.findFirst({ where: { requestId: fresh.requestId, skuId: sku.id } });
            const item = index === 0 ? firstItem : existingItem ? await tx.clientRequestItem.update({ where: { id: existingItem.id }, data: { quantity: { increment: product.quantity } } }) : await tx.clientRequestItem.create({ data: {
                    requestId: fresh.requestId, skuId: sku.id, barcode: sku.barcodes[0].value,
                    name: sku.name, quantity: product.quantity, comment: `Ozon ${fresh.orderId}; строка ${product.productId}`,
                } });
            state.lines.push({ ...product, ...(unitScanning ? { requiresKiz: Boolean(clientMarked || (sku.needsChestnyZnak && !sku.isUnmarked) || mandatory.has(String(product.productId))) } : {}), skuId: sku.id, requestItemId: item.id, name: sku.name,
                article: sku.article || sku.clientSku || sku.internalSku, barcodes: sku.barcodes.map((b) => b.value), picks: [] });
        }
        await (0, ozon_fbs_pick_lines_1.writeOzonPickState)(tx, task.id, state);
        await tx.clientRequestEvent.create({ data: {
                requestId: fresh.requestId, clientId: fresh.clientId, eventType: 'COMMENT', createdByUserId: user.id,
                title: 'Ozon: включён отбор по товарным строкам',
                body: JSON.stringify({ orderId: task.orderId, previousBarcode: fresh.barcode, previousScannedCount: fresh.scannedItemCount ?? null,
                    reason: 'Общий старый счётчик не подтверждает состав. Необходимо повторить сканы каждого артикула.',
                    lines: state.lines.map(l => ({ skuId: l.skuId, quantity: l.quantity, requestItemId: l.requestItemId })) }),
            } });
        await tx.fbsTsdAssembly.update({ where: { id: task.id }, data: {
                barcode: null, boxId: null, boxCode: null, sourceBoxPending: true, errorMessage: null,
            } });
        // Preserve the old header as order identity; only the per-line ledger proves physical picks.
        return state;
    });
}
async function locations(service, task, state) {
    const line = (0, ozon_fbs_pick_lines_1.ozonActiveLine)(state);
    if (!line)
        return [];
    if (await producedLine(service.prisma, task, state))
        return [];
    const warehouseId = await service.resolveFbsTsdExpectedWarehouseId(task);
    if (!warehouseId)
        throw new common_1.ConflictException('Не определён склад исполнения заявки.');
    const excludedReceiptBoxes = await (0, receipt_channel_policy_1.receiptBlockedBoxes)(service.prisma, task.clientId, 'fbs', task.id);
    const rows = await service.prisma.stockBalance.findMany({ where: {
            clientId: task.clientId, warehouseId, skuId: line.skuId, status: 'AVAILABLE', quantity: { gt: 0 },
            boxId: { not: null, ...(excludedReceiptBoxes.length ? { notIn: excludedReceiptBoxes } : {}) }, box: { status: { notIn: ['archived', 'deleted'] } },
        }, select: { boxId: true, quantity: true, box: { select: { code: true, storagePlacement: { include: { pallet: { include: { zone: true } } } } } } } });
    const boxes = new Map();
    for (const row of rows) {
        const previous = boxes.get(row.boxId);
        boxes.set(row.boxId, { id: row.boxId, code: row.box.code, quantity: (previous?.quantity ?? 0) + row.quantity,
            placement: row.box.storagePlacement });
    }
    const reservations = await service.fbsTsdReservationRowsBySku({ clientId: task.clientId, skuIds: [line.skuId], excludeTaskId: task.id });
    for (const box of boxes.values()) {
        box.quantity -= line.picks.filter(p => p.boxId === box.id).length;
        box.quantity -= (reservations.get(line.skuId) ?? []).filter((r) => (r.boxId ?? r.reservedBoxId) === box.id).reduce((n, r) => n + r.itemCount, 0);
    }
    return [...boxes.values()].filter(box => box.quantity > 0).sort((a, b) => a.code.localeCompare(b.code));
}
async function render(service, task, state, message) {
    const manufactured = await producedLine(service.prisma, task, state);
    if (manufactured)
        state = { ...state, source: { boxId: null, boxCode: NO_BOX } };
    const active = (0, ozon_fbs_pick_lines_1.ozonActiveLine)(state), line = active ?? state.lines[state.lines.length - 1];
    const [client, request, totals, completed, boxes] = await Promise.all([
        service.prisma.client.findUnique({ where: { id: task.clientId }, select: { id: true, code: true, name: true } }),
        service.prisma.clientRequest.findUnique({ where: { id: task.requestId }, select: { number: true } }),
        service.prisma.clientRequestItem.aggregate({ where: { requestId: task.requestId }, _sum: { quantity: true } }),
        service.prisma.fbsTsdAssembly.aggregate({ where: { requestId: task.requestId, status: 'COMPLETED' }, _sum: { itemCount: true } }),
        locations(service, task, state),
    ]);
    const placement = boxes[0]?.placement;
    return {
        state: task.status === 'COMPLETED' ? 'COMPLETED' : !active ? 'READY_TO_COMPLETE' : state.pendingBarcode ? 'SCAN_KIZ' : state.source ? 'SCAN_BARCODE' : 'SCAN_BOX',
        message: message || (state.legacyScansDiscarded && !(0, ozon_fbs_pick_lines_1.ozonPickCount)(state) ? 'Повторите сканы: прежний общий счётчик не подтверждает разные товары заказа.' : ''),
        task: {
            id: task.id, marketplace: 'OZON', orderId: task.orderId, supplyId: task.supplyId, requestId: task.requestId, client,
            product: { id: line.skuId, name: line.name, article: line.article, barcodes: line.barcodes },
            itemCount: (0, ozon_fbs_pick_lines_1.ozonPickTotal)(state), scannedItemCount: (0, ozon_fbs_pick_lines_1.ozonPickCount)(state), perUnitScanning: true,
            ozonLines: state.lines.map(l => ({ article: l.article, quantity: l.quantity, scanned: l.picks.length })),
            activeLineNumber: active ? state.lines.indexOf(active) + 1 : state.lines.length,
            physicalPickConfirmation: true, requiresKiz: Boolean(active?.requiresKiz), relabeling: null, orderSticker: null,
            scannedBoxCode: state.source?.boxCode ?? null, sourceWithoutBox: Boolean(manufactured), sourceBoxPending: !manufactured && state.source?.boxCode === NO_BOX,
            scannedBarcode: state.pendingBarcode ?? (!active ? line.picks[line.picks.length - 1]?.barcode : null),
            recommendedBoxCode: boxes[0]?.code ?? null,
            recommendedLocation: placement ? { palletId: placement.palletId, palletCode: placement.pallet.code,
                zoneId: placement.pallet.zoneId, zoneCode: placement.pallet.zone?.code, zoneName: placement.pallet.zone?.name, source: placement.source } : null,
            storageBoxes: boxes.map(b => ({ code: b.code, quantity: b.quantity, status: 'AVAILABLE' })),
            samePalletBoxCodes: [], samePalletRemainingBoxes: 0,
            status: task.status, marketplaceSubmittedAt: task.marketplaceSubmittedAt?.toISOString() ?? null,
            errorMessage: ['UNKNOWN', 'SUBMITTING'].includes(state.submission) ? 'Результат передачи Ozon проверяется. Повторного списания не будет.' : null,
        },
        progress: { requestNumber: request?.number, requestTotalItems: totals._sum.quantity ?? 0,
            requestCompletedItems: completed._sum.itemCount ?? 0,
            requestRemainingItems: Math.max(0, (totals._sum.quantity ?? 0) - (completed._sum.itemCount ?? 0)), recentStickers: [] },
    };
}
async function complete(service, task, user) {
    const prepared = await locked(service, task, user, async (tx, fresh) => {
        const state = (await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, task.id));
        if (fresh.status === 'COMPLETED')
            return { state, alreadyCompleted: true, maySubmit: false };
        if ((0, ozon_fbs_pick_lines_1.ozonActiveLine)(state))
            throw new common_1.BadRequestException('Отсканируйте все товарные строки Ozon.');
        await requireRequestCapacity(tx, fresh, state);
        const maySubmit = state.submission === 'PICKING';
        if (maySubmit) {
            state.submission = 'SUBMITTING';
            await (0, ozon_fbs_pick_lines_1.writeOzonPickState)(tx, task.id, state);
        }
        return { state, alreadyCompleted: false, maySubmit };
    });
    if (prepared.alreadyCompleted)
        return prepared.state;
    try {
        const posting = await service.readOzonFbsPickPosting(task);
        (0, ozon_fbs_pick_lines_1.requireOzonLineComposition)(prepared.state, posting);
        if (posting.status === 'awaiting_packaging' && !prepared.maySubmit) {
            throw new common_1.ConflictException('Предыдущая отправка Ozon ещё не подтверждена. Обновите позже; повторная отправка остановлена до сверки.');
        }
        if (!['awaiting_packaging', 'awaiting_deliver', 'delivering', 'delivered'].includes(posting.status)) {
            throw new common_1.ConflictException(`Заказ Ozon изменил статус: ${posting.status}. Нужна сверка уже взятого товара.`);
        }
        // Existing posting/ship transport reads the posting again and validates the durable line ledger.
        if (prepared.maySubmit)
            await service.submitOzonFbsTask(task);
        else
            await locked(service, task, user, async (tx, fresh) => {
                await tx.fbsTsdAssembly.update({ where: { id: task.id }, data: { marketplaceSubmittedAt: fresh.marketplaceSubmittedAt ?? new Date(), marketplaceSubmitError: null } });
            });
    }
    catch (error) {
        // Unknown external result is not a licence to submit again after a timeout/restart.
        await locked(service, task, user, async (tx) => {
            const state = (await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, task.id));
            if (state.submission === 'SUBMITTING') {
                state.submission = 'UNKNOWN';
                await (0, ozon_fbs_pick_lines_1.writeOzonPickState)(tx, task.id, state);
            }
        });
        throw error;
    }
    const changes = [];
    const result = await locked(service, task, user, async (tx, fresh) => {
        const state = (await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, task.id));
        if (fresh.status === 'COMPLETED')
            return state;
        await requireRequestCapacity(tx, fresh, state);
        for (const line of state.lines) {
            const item = await tx.clientRequestItem.findUnique({ where: { id: line.requestItemId } });
            if (!item || item.requestId !== fresh.requestId || item.skuId !== line.skuId || item.quantity < line.quantity) {
                throw new common_1.ConflictException('Состав заявки изменился. Передача Ozon сохранена; нужна сверка WMS.');
            }
            const boxes = new Map();
            for (const pick of line.picks)
                if (pick.boxId)
                    boxes.set(pick.boxId, (boxes.get(pick.boxId) ?? 0) + 1);
            for (const [boxId, quantity] of boxes)
                await tx.clientRequestBoxSelection.upsert({
                    where: { requestItemId_boxId: { requestItemId: line.requestItemId, boxId } },
                    create: { requestItemId: line.requestItemId, skuId: line.skuId, boxId, quantity }, update: { quantity: { increment: quantity } },
                });
        }
        const completedAt = new Date();
        const fabricLines = fresh.sourceArticle === fabric_fbs_task_state_1.FABRIC_TASK_MARKER ? await (0, fabric_fbs_task_state_1.readFabricTaskLines)(tx, fresh) : null;
        await tx.fbsTsdAssembly.update({ where: { id: task.id }, data: { status: 'COMPLETED', completedAt, errorMessage: null,
                barcode: state.lines[0].picks[0].barcode, sourceBoxPending: state.lines.some(l => l.picks.some(p => !p.boxId) &&
                    !fabricLines?.some(f => f.lineId === l.requestItemId && f.skuId === l.skuId && f.remainingUnits === 0 && f.quantity === l.quantity)) } });
        state.submission = 'COMPLETED';
        await (0, ozon_fbs_pick_lines_1.writeOzonPickState)(tx, task.id, state);
        await tx.clientRequestEvent.create({ data: {
                requestId: task.requestId, clientId: task.clientId, eventType: 'COMMENT', createdByUserId: user.id,
                title: 'FBS Ozon: все товарные строки отобраны', body: JSON.stringify({ orderId: task.orderId, lines: state.lines }),
            } });
        // Ozon retains its existing accounting boundary: source selections, no new WB stock-debit path.
        await (0, fbs_request_auto_status_1.reconcileFbsRequestStatus)(tx, task.requestId, { stage: 'PICK', occurredAt: completedAt, actorId: user.id }, changes);
        return state;
    });
    service.fbsOrdersCache.delete(task.clientId);
    await service.notifyFbsAutoStatusChanges(changes);
    return result;
}
// FIX: called after normal client/device authorization; WB and single-product orders fall through unchanged.
async function handleOzonPickLines(service, task, user, action, payload = {}, message = '') {
    if (!(0, ozon_fbs_pick_lines_1.ozonPickLinesEnabled)() || task.marketplace !== 'OZON')
        return null;
    let state = await initialize(service, task, user);
    if (!state)
        return null;
    if (action === 'complete')
        state = await complete(service, task, user);
    else if (action !== 'view') {
        if (task.sourceArticle === fabric_fbs_task_state_1.FABRIC_TASK_MARKER || state.unitMarksVersion === 1)
            await service.inventoryLock?.assertStockMovementsAllowed();
        state = await (0, kiz_client_review_1.withClientKizReview)(service.prisma, user, () => locked(service, task, user, async (tx, fresh) => {
            let current = (await (0, ozon_fbs_pick_lines_1.readOzonPickState)(tx, task.id));
            if (fresh.status === 'COMPLETED')
                return current;
            const code = String(payload.barcode ?? payload.boxCode ?? payload.code ?? '').trim();
            const line = (0, ozon_fbs_pick_lines_1.ozonActiveLine)(current);
            const manufactured = await producedLine(tx, fresh, current);
            if (manufactured)
                current = { ...current, source: { boxId: null, boxCode: NO_BOX } };
            if (action === 'kiz') {
                if (!unitScanningEnabled())
                    throw new common_1.ConflictException('Поштучная маркировка Ozon не включена.');
                const previousCount = (0, ozon_fbs_pick_lines_1.ozonPickCount)(current);
                const next = (0, ozon_fbs_pick_lines_1.recordOzonUnitKiz)(current, String(payload.kiz ?? '').trim(), payload.scannedItemCount, user.id);
                if ((0, ozon_fbs_pick_lines_1.ozonPickCount)(next) === previousCount)
                    return current;
                if (!line)
                    throw new common_1.ConflictException('Активная позиция не найдена.');
                await (0, ozon_unit_stock_1.assertOzonUnitStock)(service, tx, fresh, current);
                await (0, receipt_channel_policy_1.assertReceiptFbsBox)(tx, fresh, current.source?.boxId);
                const pick = next.lines.find(l => l.requestItemId === line.requestItemId).picks.at(-1);
                const mark = await (0, kiz_client_review_1.clientPhysicalMark)(tx, fresh.clientId, pick.kiz) ?? (await require('../../common/client-fulfillment-policy').activeRule(tx,fresh.clientId,'pickKiz') ? await require('../../common/palitra-pick-kiz').bindNewPickMark(tx,{clientId:fresh.clientId,skuId:line.skuId,boxId:pick.boxId,warehouseId:await service.resolveFbsTsdExpectedWarehouseId(fresh),kiz:pick.kiz},fresh.requestId) : null);
                if (!mark || mark.skuId !== line.skuId || (mark.boxId ?? null) !== pick.boxId || mark.status !== 'AVAILABLE')
                    throw new common_1.ConflictException('КИЗ не относится к доступной единице выбранного товара и источника.');
                const warehouseId = await service.resolveFbsTsdExpectedWarehouseId(fresh);
                if (!warehouseId)
                    throw new common_1.ConflictException('Не определён склад исполнения заявки.');
                await (0, ozon_unit_stock_1.assertOzonMarkWarehouse)(tx, mark, warehouseId);
                // FIX: persist the candidate inside the transaction so the guard resolves this exact line.
                await (0, ozon_fbs_pick_lines_1.writeOzonPickState)(tx, fresh.id, next);
                const use = { scope: 'FBS', clientId: fresh.clientId, warehouseId, requestId: fresh.requestId,
                    taskId: fresh.id, skuId: line.skuId, boxId: pick.boxId, kiz: pick.kiz };
                if (await (0, kiz_client_review_1.assertClientKizUse)(tx, use, user) !== 'ALLOW')
                    throw new common_1.ConflictException('КИЗ требует разбора администратора.');
                pick.markId = mark.id;
                await (0, kiz_client_review_1.refreshClientKizClaim)(tx, use, mark);
                current = next;
            }
            else if (action === 'barcode' || (action === 'code' && /^\d{8,13}$/.test(code))) {
                await (0, receipt_channel_policy_1.assertReceiptFbsBox)(tx, fresh, current.source?.boxId);
                const previousCount = (0, ozon_fbs_pick_lines_1.ozonPickCount)(current);
                const next = (0, ozon_fbs_pick_lines_1.recordOzonLineScan)(current, code, payload.scannedItemCount, user.id);
                if (current.unitMarksVersion === 1 && !manufactured && (0, ozon_fbs_pick_lines_1.ozonPickCount)(next) > previousCount)
                    await (0, ozon_unit_stock_1.assertOzonUnitStock)(service, tx, fresh, current);
                current = next;
                if (manufactured && line && (0, ozon_fbs_pick_lines_1.ozonPickCount)(current) > previousCount) {
                    const accepted = current.lines.find(l => l.requestItemId === line.requestItemId);
                    await (0, fabric_fbs_scan_1.recordFabricScan)(tx, fresh, line.requestItemId, accepted.picks.length, user, service.fbsTsdDeviceCode(undefined, user));
                }
            }
            else {
                if (current.pendingBarcode)
                    throw new common_1.ConflictException('Сначала подтвердите КИЗ выбранного товара.');
                if (manufactured)
                    throw new common_1.BadRequestException('Для отреза из рулона отсканируйте ШК товара.');
                if (!Number.isSafeInteger(payload.scannedItemCount) || Number(payload.scannedItemCount) > (0, ozon_fbs_pick_lines_1.ozonPickCount)(current))
                    throw new common_1.ConflictException('Обновите задание перед выбором короба.');
                if (Number(payload.scannedItemCount) < (0, ozon_fbs_pick_lines_1.ozonPickCount)(current))
                    return current;
                if (!line || current.submission !== 'PICKING')
                    throw new common_1.ConflictException('Все товары отобраны или заказ передаётся.');
                if (code.toUpperCase() === NO_BOX)
                    current.source = { boxId: null, boxCode: NO_BOX };
                else {
                    const boxes = await locations(service, fresh, current);
                    const box = boxes.find(b => b.code.toUpperCase() === code.toUpperCase());
                    if (!box)
                        throw new common_1.BadRequestException(`В этом коробе нет доступного товара ${line.article}. Отсканируйте короб из маршрута.`);
                    current.source = { boxId: box.id, boxCode: box.code };
                }
            }
            await (0, ozon_fbs_pick_lines_1.writeOzonPickState)(tx, task.id, current);
            // Mark physical activity for the existing stale-lease/offline safeguards.
            await tx.fbsTsdAssembly.update({ where: { id: task.id }, data: { sourceBoxPending: true, errorMessage: null } });
            return current;
        }));
    }
    const fresh = await service.prisma.fbsTsdAssembly.findUnique({ where: { id: task.id } });
    return render(service, fresh, state, message);
}
