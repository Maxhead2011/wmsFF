'use strict';
const VOLUME=24.740;
function virtualSku(clientId,warehouseId,material,color,volume=VOLUME){
 const id='fabric-roll-storage:'+clientId+':'+warehouseId+':'+material+':'+color;
 return {id,internalSku:'ROLL-'+material+'-'+color,name:'Рулоны · '+({SATIN:'Атлас',GABARDINE:'Габардин'}[material]||material)+' · '+({black:'чёрный',white:'белый',green:'зелёный',red:'красный',ivory:'айвори'}[color]||color),volumeLiters:volume,lengthCm:140,widthCm:15,heightCm:15,size:'эквивалент рулона 100 м',barcodes:[],article:null,clientSku:null,marketplaceProductId:null,marketplaceOfferId:null};
}
async function fabricRollStorageSources(db,clientId,to){
 const state=await db.systemSetting.findUnique({where:{key:'fabric.rolls.v1:'+clientId}});
 if(!state?.value?.rolls?.length)return {movements:[],balances:[],skus:[]};
 const events=await db.auditLog.findMany({where:{entity:'FabricRolls',entityId:clientId,action:{in:['FABRIC_ROLL_RECEIVE','FABRIC_ROLL_CUT','FABRIC_ROLL_ADJUST','FABRIC_ROLL_SHIP','FABRIC_ROLL_WRITE_OFF','FABRIC_FBS_CUT']},createdAt:{lte:to}},select:{id:true,createdAt:true,payload:true},orderBy:[{createdAt:'asc'},{id:'asc'}]});
 const movements=[],skus=new Map();
 for(const e of events){const m=e.payload;if(!m||!m.warehouseId||!Number.isFinite(m.storageRollEquivalentDelta)||!Number.isFinite(m.volumeLiters)||m.volumeLiters<=0)throw Error('Не хватает истории объёма рулонов. Нужна проверка.');
  const sku=virtualSku(clientId,m.warehouseId,m.material,m.color,m.volumeLiters);skus.set(sku.id,sku);movements.push({id:e.id,skuId:sku.id,warehouseId:m.warehouseId,type:'INVENTORY_ADJUSTMENT',status:'AVAILABLE',quantity:m.storageRollEquivalentDelta,createdAt:e.createdAt,sku});
 }
 const current=new Map();for(const r of state.value.rolls){const sku=virtualSku(clientId,r.warehouseId,r.material,r.color,r.volumeLiters||VOLUME);skus.set(sku.id,sku);current.set(sku.id,(current.get(sku.id)||0)+r.remainingMm/100000);}
 return {movements,skus:[...skus.values()],balances:[...current].map(([skuId,quantity])=>({skuId,quantity,box:null,pallet:null}))};
}
module.exports={fabricRollStorageSources,virtualSku,VOLUME};
