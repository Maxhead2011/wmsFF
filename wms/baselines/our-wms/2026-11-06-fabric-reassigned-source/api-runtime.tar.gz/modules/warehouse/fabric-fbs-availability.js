"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.identifyFabricSku = identifyFabricSku;
exports.fabricMaterialAvailability = fabricMaterialAvailability;
const fabric_fbs_ledger_1 = require("./fabric-fbs-ledger");
// FIX: use the same exact SKU grammar as existing roll receipt; never infer metres from a title.
function identifyFabricSku(sku) {
    if (!/ткань/i.test(sku.name))
        return null;
    const match = /^(gab_)?(black|white|green|red|ivory)_(1|3|5|10|20|30|50)(?:-0)?$/.exec(sku.internalSku ?? '');
    return match ? { skuId: sku.id, material: match[1] ? 'GABARDINE' : 'SATIN', color: match[2], lengthMm: Number(match[3]) * 1000 } : null;
}
function fabricMaterialAvailability(ledger, sku, warehouseId, units) {
    const identity = identifyFabricSku(sku);
    if (!identity)
        return { available: false, reason: 'NOT_FABRIC' };
    // FIX: unresolved historic consumption must not silently count as freely sellable raw material.
    if (ledger.shipmentPending?.some(p => p.warehouseId === warehouseId && p.material === identity.material && p.color === identity.color && p.meters > 0)) {
        return { available: false, reason: 'RECONCILIATION_REQUIRED' };
    }
    try {
        (0, fabric_fbs_ledger_1.reserveFabric)(ledger, { ...identity, warehouseId, units, key: '__preview__:' + JSON.stringify([sku.id, warehouseId]) });
        return { available: true, reason: 'READY_TO_CUT', ...identity, units, totalMm: identity.lengthMm * units };
    }
    catch (error) {
        if (error instanceof Error && error.message === 'Insufficient continuous fabric')
            return { available: false, reason: 'INSUFFICIENT_MATERIAL' };
        throw error;
    }
}
