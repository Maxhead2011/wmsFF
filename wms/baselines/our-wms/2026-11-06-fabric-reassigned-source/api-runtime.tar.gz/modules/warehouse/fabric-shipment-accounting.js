'use strict';
const {createHash}=require('crypto');
const {ConflictException}=require('@nestjs/common');
const VOLUME=24.740;
const {freeFabricMm,fabricCreditMatches}=require('./fabric-fbs-protection');
const AUTO_CLIENTS=new Set(['1757a389-c0d4-49b5-9347-2bde0c549260']);
async function takeLock(tx,key){
 const rows=await tx.$queryRawUnsafe('SELECT pg_try_advisory_xact_lock(hashtext($1)) AS locked',key);
 if(rows[0]?.locked!==true)throw new ConflictException('Рулонный учёт изменяется другой операцией. Повторите подтверждение отгрузки.');
}
async function lockFabricClient(tx,clientId){
 if(!AUTO_CLIENTS.has(clientId))return;
 const enabled=await tx.systemSetting.findUnique({where:{key:'fabric.rolls.enabled.v1:'+clientId}});
 if(enabled?.value?.enabled===true)await takeLock(tx,'fabric.rolls.v1:'+clientId);
}
function identify(s){
 const m=/^(gab_)?(black|white|green|red|ivory)_(1|3|5|10|20|30|50)(?:-0)?$/.exec(s.internalSku||'');
 if(!m||!/ткань/i.test(s.name))return null;
 return {material:m[1]?'GABARDINE':'SATIN',color:m[2],mm:Number(m[3])*1000};
}
function planShipments(input,events,credits){
 const state=structuredClone(input);state.shipmentAccounting??={version:1,events:{},creditsUsed:{}};
 const ledger=state.shipmentAccounting;if(ledger.version!==1)throw new ConflictException('Неизвестная версия учёта списания рулонов.');
 const changes=[],pending=[];
 const ordered=[...events].sort((a,b)=>new Date(a.at)-new Date(b.at)||a.key.localeCompare(b.key));
 for(const e of ordered){
  if(!Number.isSafeInteger(e.mm)||e.mm<=0||!Number.isFinite(new Date(e.at).getTime()))throw new ConflictException('Некорректный метраж отгрузки.');
  const rolls=state.rolls.filter(r=>r.warehouseId===e.warehouseId&&r.material===e.material&&r.color===e.color&&new Date(r.createdAt)<=new Date(e.at)).sort((a,b)=>new Date(a.createdAt)-new Date(b.createdAt)||a.id.localeCompare(b.id));
  if(!rolls.length)continue; // Never debit a newly registered roll for shipments before its receipt.
  const old=ledger.events[e.key]||{rawMm:0,coveredMm:0,mm:e.mm};
  if(old.mm!==e.mm)throw new ConflictException('Изменился состав учтённой отгрузки. Нужна сверка рулонов.');
  let needed=e.mm-old.rawMm-old.coveredMm;if(needed===0)continue;
  const next={...old},usedCredits=[],allocations=[];
  // FIX: bound production belongs to this task, never an earlier order of the same SKU.
  for(const c of [...credits].sort((a,b)=>Number(!!b.taskId)-Number(!!a.taskId))){
   if(c.taskId&&!fabricCreditMatches(c,e))continue;
   if(c.skuId!==e.skuId||c.warehouseId!==e.warehouseId||new Date(c.at)>new Date(e.at))continue;
   const used=ledger.creditsUsed[c.key]||0,amount=Math.min(needed,c.mm-used);
   if(amount>0){ledger.creditsUsed[c.key]=used+amount;next.coveredMm+=amount;needed-=amount;usedCredits.push({key:c.key,mm:amount});}
   if(!needed)break;
  }
  for(const r of rolls){
   if(r.writtenOffAt||!needed)continue;
   const amount=Math.min(needed,state.fbsReservations?.length?freeFabricMm(state,r.id):r.remainingMm);
   if(amount>0){r.remainingMm-=amount;r.shippedMm=(r.shippedMm||0)+amount;next.rawMm+=amount;needed-=amount;allocations.push({rollId:r.id,mm:amount});}
  }
  ledger.events[e.key]=next;
  if(allocations.length||usedCredits.length)changes.push({...e,rawMm:next.rawMm-old.rawMm,coveredMm:next.coveredMm-old.coveredMm,allocations,usedCredits});
  if(needed)pending.push({key:e.key,warehouseId:e.warehouseId,material:e.material,color:e.color,meters:needed/1000,requestId:e.requestId});
 }
 state.shipmentPending=pending;
 return {state,changes,pending};
}
async function syncFabricShipments(tx,clientId,userId=null){
 if(!AUTO_CLIENTS.has(clientId))return {changes:[],pending:[]};
 const enabled=await tx.systemSetting.findUnique({where:{key:'fabric.rolls.enabled.v1:'+clientId}});
 if(enabled?.value?.enabled!==true)return {changes:[],pending:[]};
 const key='fabric.rolls.v1:'+clientId;
 await takeLock(tx,key);
 const stored=await tx.systemSetting.findUnique({where:{key}}),before=stored?.value;
 if(!before?.rolls?.length)return {changes:[],pending:[]};
 const first=new Date(Math.min(...before.rolls.map(r=>new Date(r.createdAt).getTime())));
 const rows=await tx.sku.findMany({where:{clientId},select:{id:true,name:true,internalSku:true}});
 const skus=new Map(rows.map(s=>[s.id,identify(s)]).filter(([,s])=>s));const ids=[...skus.keys()];
 if(!ids.length)return {changes:[],pending:[]};
 const facts=await tx.wbOrderShipment.findMany({where:{clientId,skuId:{in:ids},shippedAt:{gte:first}},select:{id:true,requestId:true,skuId:true,warehouseId:true,quantity:true,shippedAt:true,connectionId:true,orderId:true,assemblyId:true}});
 const events=facts.map(f=>{const s=skus.get(f.skuId);return {key:'wb:'+f.id,requestId:f.requestId,marketplace:'WILDBERRIES',connectionId:f.connectionId,orderId:f.orderId,taskId:f.assemblyId,skuId:f.skuId,warehouseId:f.warehouseId,at:f.shippedAt,material:s.material,color:s.color,mm:f.quantity*s.mm};});
 const requests=await tx.clientRequest.findMany({where:{clientId,status:'DONE',fboAssembly:{isNot:null},items:{some:{skuId:{in:ids}}}},select:{id:true,warehouseId:true,updatedAt:true,fboAssembly:{select:{pickClosure:true}},items:{select:{id:true,skuId:true,quantity:true}},events:{where:{statusTo:'DONE'},orderBy:{createdAt:'asc'},take:1,select:{createdAt:true}}}});
 for(const r of requests){const at=r.events[0]?.createdAt||r.updatedAt;if(at<first)continue;const items=r.fboAssembly?.pickClosure?require('../tsd/fbo-two-stage-policy').closedFboItems(r.items,r.fboAssembly.pickClosure):r.items;for(const i of items){const s=skus.get(i.skuId);if(s&&i.quantity>0)events.push({key:'fbo:'+r.id+':'+i.id,requestId:r.id,skuId:i.skuId,warehouseId:r.warehouseId,at,material:s.material,color:s.color,mm:i.quantity*s.mm});}}
 // Only CUT receipt movements mint credits. Unrelated ready-stock receipts never do.
 const cuts=await tx.auditLog.findMany({where:{entity:'FabricRolls',entityId:clientId,action:'FABRIC_ROLL_CUT'},select:{id:true,createdAt:true,payload:true},orderBy:{createdAt:'asc'}});
 const receipts=cuts.length?await tx.stockMovement.findMany({where:{clientId,skuId:{in:ids},quantity:{gt:0},sourceDocument:{in:cuts.map(c=>c.id)}},select:{id:true,sourceDocument:true,skuId:true,warehouseId:true,quantity:true,createdAt:true},orderBy:[{createdAt:'asc'},{id:'asc'}]}):[];
 const byCut=new Map(cuts.map(c=>[c.id,c]));
 const credits=receipts.filter(r=>byCut.has(r.sourceDocument)).map(r=>({key:r.id,skuId:r.skuId,warehouseId:r.warehouseId,at:r.createdAt,mm:r.quantity*skus.get(r.skuId).mm}));
 // FIX: only audited PACKING production is a bound credit.
 const produced=before.fbsOrders?await tx.auditLog.findMany({where:{entity:'FabricRolls',entityId:clientId,action:'FABRIC_FBS_CUT'},select:{payload:true}}):[];
 for(const row of produced){const c=row.payload;if(!c||c.clientId!==clientId||!fabricCreditMatches(c,c)||!Number.isFinite(Date.parse(c.at)))throw new ConflictException('Некорректная история нарезки ФБС.');credits.push({...c,at:c.at});}
 const result=planShipments(before,events,credits);
 if(require('node:util').isDeepStrictEqual(before,result.state))return result;
 for(const e of result.changes){
  const id='fabric-ship-'+createHash('sha256').update(e.key+':'+JSON.stringify(result.state.shipmentAccounting.events[e.key])).digest('hex').slice(0,48);
  await tx.auditLog.create({data:{id,userId,action:'FABRIC_ROLL_SHIP',entity:'FabricRolls',entityId:clientId,payload:{shipmentKey:e.key,requestId:e.requestId,skuId:e.skuId,warehouseId:e.warehouseId,material:e.material,color:e.color,shippedAt:new Date(e.at).toISOString(),cutMeters:e.rawMm/1000,coveredMeters:e.coveredMm/1000,allocations:e.allocations,usedCredits:e.usedCredits,storageRollEquivalentDelta:-e.rawMm/100000,volumeLiters:VOLUME,lengthCm:140,diameterCm:15}}});
 }
 await tx.systemSetting.update({where:{key},data:{value:result.state,...(userId?{updatedByUserId:userId}:{})}});
 return result;
}
module.exports={identify,planShipments,syncFabricShipments,lockFabricClient};
