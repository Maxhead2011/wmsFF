"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rememberRibbon = rememberRibbon;
exports.readRibbon = readRibbon;
exports.confirmRibbon = confirmRibbon;
const node_crypto_1 = require("node:crypto");
const fbs_request_auto_status_1 = require("./fbs-request-auto-status");
const key = (clientId, userId, bytes) => `fbs.ribbon.v1:${clientId}:${userId}:${(0, node_crypto_1.createHash)('sha256').update(bytes).digest('hex')}`;
// FIX: the server binds exact PDF bytes to the order selection; a caller cannot nominate arbitrary requests.
async function rememberRibbon(db, clientId, userId, orders, bytes) {
    if (!(0, fbs_request_auto_status_1.fbsActionStatusEnabled)() || !orders.length || orders.some(o => !['WILDBERRIES', 'OZON'].includes(o.marketplace)))
        return;
    const setting = await db.systemSetting.findUnique({ where: { key: `fbs.action-status.v1:${clientId}` } });
    if (setting?.value?.startOnRibbon !== true)
        return;
    const value = { clientId, userId, orders: orders.map(o => ({ id: o.id, connectionId: o.connectionId, marketplace: o.marketplace })), generatedAt: Date.now() };
    await db.systemSetting.upsert({ where: { key: key(clientId, userId, bytes) }, create: { key: key(clientId, userId, bytes), value }, update: { value } });
}
async function readRibbon(db, clientId, userId, bytes, warehouseId) {
    if (!(0, fbs_request_auto_status_1.fbsActionStatusEnabled)())
        return [];
    const value = (await db.systemSetting.findUnique({ where: { key: key(clientId, userId, bytes) } }))?.value;
    if (!value || value.clientId !== clientId || value.userId !== userId || !Array.isArray(value.orders) || Date.now() - value.generatedAt > 86400000)
        return [];
    const links = await db.fbsOrderRequestLink.findMany({ where: { clientId, syncStatus: 'ACTIVE', OR: value.orders.map((o) => ({ connectionId: o.connectionId, orderId: o.id, marketplace: o.marketplace })), request: { warehouseId, type: 'OUTBOUND', status: { notIn: ['DONE', 'CANCELLED', 'REJECTED'] } } }, select: { requestId: true, connectionId: true, orderId: true, marketplace: true } });
    return links.map((l) => ({ requestId: l.requestId, connectionId: l.connectionId, orderId: l.orderId, marketplace: l.marketplace }));
}
async function confirmRibbon(tx, payload, jobId, at) {
    if (!(0, fbs_request_auto_status_1.fbsActionStatusEnabled)() || !Array.isArray(payload.fbsRibbon) || !payload.fbsRibbon.length)
        return;
    for (const requestId of [...new Set(payload.fbsRibbon.map((l) => l.requestId))].sort()) {
        await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${requestId} FOR UPDATE`;
        const r = await tx.clientRequest.findUnique({ where: { id: requestId }, select: { clientId: true, warehouseId: true } });
        if (r?.clientId !== payload.clientId || r.warehouseId !== payload.warehouseId)
            continue;
        const selection = payload.fbsRibbon.filter((l) => l.requestId === requestId);
        const links = await tx.fbsOrderRequestLink.findMany({ where: { requestId, clientId: payload.clientId, syncStatus: 'ACTIVE', OR: selection.map((l) => ({ connectionId: l.connectionId, orderId: l.orderId, marketplace: l.marketplace })) }, select: { orderId: true } });
        if (!links.length)
            continue;
        await (0, fbs_request_auto_status_1.reconcileFbsRequestStatus)(tx, requestId, { stage: 'RIBBON', occurredAt: at, actorId: payload.requestedById });
        await tx.auditLog.create({ data: { userId: payload.requestedById, entity: 'ClientRequest', entityId: requestId, action: 'FBS_RIBBON_PRINTED', payload: { jobId, at: at.toISOString(), orderIds: links.map((l) => l.orderId) } } });
    }
}
