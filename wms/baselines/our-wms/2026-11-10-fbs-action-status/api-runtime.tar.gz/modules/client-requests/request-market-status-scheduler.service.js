"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RequestMarketStatusScheduler_1;
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestMarketStatusScheduler = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const request_market_status_service_1 = require("./request-market-status.service");
const market_status_schedule_1 = require("./market-status-schedule");
// FIX: bounded server job with durable per-request slots; no browser/desktop automation dependency.
let RequestMarketStatusScheduler = RequestMarketStatusScheduler_1 = class RequestMarketStatusScheduler {
    db;
    statuses;
    timer;
    running = false;
    stopped = false;
    cursor = '';
    log = new common_1.Logger(RequestMarketStatusScheduler_1.name);
    constructor(db, statuses) {
        this.db = db;
        this.statuses = statuses;
    }
    onModuleInit() { if ((0, market_status_schedule_1.marketStatusScheduleEnabled)())
        this.schedule(); }
    onModuleDestroy() { this.stopped = true; if (this.timer)
        clearTimeout(this.timer); }
    schedule() { if (!this.stopped) {
        this.timer = setTimeout(() => void this.tick(), 30000);
        this.timer.unref?.();
    } }
    async tick() {
        if (this.running || this.stopped || !(0, market_status_schedule_1.marketStatusScheduleEnabled)())
            return;
        this.running = true;
        try {
            const slot = (0, market_status_schedule_1.marketStatusSlot)();
            if (!slot)
                return;
            const rows = await this.db.clientRequest.findMany({ where: { type: 'OUTBOUND', status: 'PACKED', client: { isDemo: false }, warehouseId: { not: null },
                    ...(this.cursor ? { id: { gt: this.cursor } } : {}), yandexFbyShipment: null, lamodaAssembly: null,
                    OR: [{ fbsOrderLinks: { some: { marketplace: { in: ['WILDBERRIES', 'OZON'] } } } }, { ozonShipment: { isNot: null } }, { fboAssembly: { isNot: null } }] }, select: { id: true, clientId: true, warehouseId: true }, orderBy: { id: 'asc' }, take: 100 });
            if (!rows.length)
                this.cursor = '';
            let checked = 0;
            for (const r of rows) {
                if (this.stopped || !(0, market_status_schedule_1.marketStatusScheduleEnabled)() || (0, market_status_schedule_1.marketStatusSlot)() !== slot)
                    break;
                this.cursor = r.id;
                const claim = await (0, market_status_schedule_1.claimMarketSlot)(this.db, r.id, slot);
                if (!claim)
                    continue;
                let success = false, code = 'ERROR';
                try {
                    const user = { id: undefined, email: '', name: 'Автоматическая сверка статусов', roleCodes: [], permissionCodes: ['client-requests:write', 'client-requests:status'], clientScopeMode: 'LIMITED', clientIds: [r.clientId], writableClientIds: [r.clientId], activeWarehouseId: r.warehouseId, warehouseIds: [r.warehouseId], writableWarehouseIds: [r.warehouseId] };
                    const result = await this.statuses.check(r.id, user);
                    success = true;
                    code = result.status;
                }
                catch (e) {
                    code = String(e?.getStatus?.() ?? 'INTERNAL');
                }
                await (0, market_status_schedule_1.finishMarketSlot)(this.db, r.id, claim, success, code);
                this.log.log(JSON.stringify({ event: 'request_market_schedule', requestId: r.id, slot, result: code, success }));
                if (++checked >= 10)
                    break;
            }
        }
        catch {
            this.log.warn('Marketplace schedule failed; durable leases retained.');
        }
        finally {
            this.running = false;
            if ((0, market_status_schedule_1.marketStatusScheduleEnabled)())
                this.schedule();
        }
    }
};
exports.RequestMarketStatusScheduler = RequestMarketStatusScheduler;
exports.RequestMarketStatusScheduler = RequestMarketStatusScheduler = RequestMarketStatusScheduler_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof request_market_status_service_1.RequestMarketStatusService !== "undefined" && request_market_status_service_1.RequestMarketStatusService) === "function" ? _b : Object])
], RequestMarketStatusScheduler);
