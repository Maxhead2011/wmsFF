"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b, _c, _d, _e, _f;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestMarketStatusController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const require_permissions_decorator_1 = require("../auth/decorators/require-permissions.decorator");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const
client_scope_service_1 = require("../auth/client-scope.service");
const  marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const ozon_assembly_supply_service_1 = require("./ozon-assembly-supply.service");
const wb_fbo_supply_service_1 = require("./wb-fbo-supply.service");
const  fbo_delivery_sync_service_1 = require("./fbo-delivery-sync.service");
const request_market_status_service_1 = require("./request-market-status.service");
// FIX: endpoint contract retained; scheduled checks reuse the service, never bypass controllers via HTTP.
let RequestMarketStatusController = class RequestMarketStatusController extends request_market_status_service_1.RequestMarketStatusService {
    constructor(db, scopes, connections, ozon, wb, delivery) { super(db, scopes, connections, ozon, wb, delivery); }
    targets(user) { return super.targets(user); }
    check(id, user) { return super.check(id, user); }
};
exports.RequestMarketStatusController = RequestMarketStatusController;
__decorate([(0, common_1.Get)('market-status/targets'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], RequestMarketStatusController.prototype, "targets", null);
__decorate([
    (0, common_1.Post)(':id/market-status'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], RequestMarketStatusController.prototype, "check", null);
exports.RequestMarketStatusController = RequestMarketStatusController = __decorate([
    (0, common_1.Controller)('client-requests'),
    (0, require_permissions_decorator_1.RequirePermissions)('client-requests:write', 'client-requests:status'),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof marketplace_connections_service_1.MarketplaceConnectionsService !== "undefined" && marketplace_connections_service_1.MarketplaceConnectionsService) === "function" ? _c : Object, typeof (_d = typeof ozon_assembly_supply_service_1.OzonAssemblySupplyService !== "undefined" && ozon_assembly_supply_service_1.OzonAssemblySupplyService) === "function" ? _d : Object, typeof (_e = typeof wb_fbo_supply_service_1.WbFboSupplyService !== "undefined" && wb_fbo_supply_service_1.WbFboSupplyService) === "function" ? _e : Object, typeof (_f = typeof fbo_delivery_sync_service_1.FboDeliverySyncService !== "undefined" && fbo_delivery_sync_service_1.FboDeliverySyncService) === "function" ? _f : Object])
], RequestMarketStatusController);
