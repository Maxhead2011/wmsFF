"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c, _d, _e, _f;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestMarketStatusService = void 0;
const common_1 = require("@nestjs/common");
const client_scope_service_1 = require("../auth/client-scope.service");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const request_removal_policy_1 = require("./request-removal-policy");
const marketplace_connections_service_1 = require("../marketplace-connections/marketplace-connections.service");
const wb_packed_auto_done_1 = require("../marketplace-connections/wb-packed-auto-done");
const ozon_packed_auto_done_1 = require("../marketplace-connections/ozon-packed-auto-done");
const wb_fbo_supply_service_1 = require("./wb-fbo-supply.service");
const ozon_assembly_supply_service_1 = require("./ozon-assembly-supply.service");
const fbo_delivery_sync_service_1 = require("./fbo-delivery-sync.service");
const ozon_supply_policy_1 = require("./ozon-supply-policy");
const lamoda_client_1 = require("../lamoda/lamoda-client");
const lamoda_submission_1 = require("../lamoda/lamoda-submission");
const linkIdentity = (links) => JSON.stringify(links.map(l => JSON.stringify([l.marketplace, l.connectionId, l.orderId, l.syncStatus])).sort());
// FIX: manual and scheduled checks share the same authorization and marketplace evidence rules.
let RequestMarketStatusService = class RequestMarketStatusService {
    db;
    scopes;
    connections;
    ozon;
    wb;
    delivery;
    constructor(db, scopes, connections, ozon, wb, delivery) {
        this.db = db;
        this.scopes = scopes;
        this.connections = connections;
        this.ozon = ozon;
        this.wb = wb;
        this.delivery = delivery;
    }
    // FIX: force a scoped read from the marketplace, then apply the ordinary completion policy.
    async targets(user) {
        // FIX: manual capability is independent of the background worker switch.
        if (process.env.WMS_FBO_DELIVERY_SYNC_ENABLED !== 'true' && process.env.WMS_REQUEST_MARKET_STATUS_MANUAL_ENABLED !== 'true')
            throw new common_1.NotFoundException();
        if (user.isDemo)
            throw new common_1.ForbiddenException();
        const rows = await this.db.clientRequest.findMany({ where: {
                type: 'OUTBOUND', status: { notIn: ['DONE', 'CANCELLED', 'REJECTED'] }, client: { isDemo: false },
                clientId: this.scopes.resolveClientFilter(user), ...(0, client_request_warehouse_scope_1.warehouseScopeWhere)(user, 'write'),
                ...(user.activeWarehouseId ? { warehouseId: user.activeWarehouseId } : {}), yandexFbyShipment: null,
                OR: [{ fbsOrderLinks: { some: { marketplace: { in: ['OZON', 'WILDBERRIES'] } } } },
                    { ozonShipment: { isNot: null } }, { lamodaAssembly: { isNot: null } }, { fboAssembly: { isNot: null } }]
            }, select: { id: true, number: true, clientId: true }, orderBy: { number: 'asc' } });
        const all = user.permissionCodes.includes('system:admin') || user.clientScopeMode === 'ALL';
        return rows.filter(r => all || user.writableClientIds.includes(r.clientId)).map(({ id, number }) => ({ id, number }));
    }
    async check(id, user) {
        // FIX: manual capability is independent of the background worker switch.
        if (process.env.WMS_FBO_DELIVERY_SYNC_ENABLED !== 'true' && process.env.WMS_REQUEST_MARKET_STATUS_MANUAL_ENABLED !== 'true')
            throw new common_1.NotFoundException();
        if (user.isDemo)
            throw new common_1.ForbiddenException();
        const r = await this.db.clientRequest.findUnique({ where: { id }, include: {
                client: { select: { isDemo: true } }, fbsOrderLinks: true, ozonShipment: { select: { requestId: true } },
                lamodaAssembly: { include: { plan: true } }, fboAssembly: { select: { phase: true } }, yandexFbyShipment: { select: { id: true } }
            } });
        if (!r || r.client.isDemo)
            throw new common_1.NotFoundException();
        this.scopes.requireClientAccess(user, r.clientId, 'write');
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, r, 'write');
        await (0, request_removal_policy_1.assertRequestNotRemoved)(this.db, id);
        if (r.type !== 'OUTBOUND' || ['DONE', 'CANCELLED', 'REJECTED'].includes(r.status))
            throw new common_1.ConflictException('Проверка доступна для открытой заявки на отгрузку.');
        let message;
        if (r.fbsOrderLinks.length) {
            message = await this.checkFbs(id, r.clientId, r.fbsOrderLinks, user);
        }
        else if (r.lamodaAssembly) {
            const { plan } = r.lamodaAssembly;
            const account = await this.db.lamodaAccount.findFirst({ where: { id: plan.accountId, clientId: r.clientId, isActive: true } });
            if (!account)
                throw new common_1.ConflictException('Кабинет Lamoda недоступен.');
            const credentials = { sellerId: account.sellerId, oauthClientId: account.oauthClientId,
                secret: (0, lamoda_client_1.openSecret)(account.encryptedSecret, JSON.stringify([r.clientId, account.sellerId, account.oauthClientId])) };
            const remote = new lamoda_client_1.LamodaClient();
            const submission = new lamoda_submission_1.LamodaSubmission(this.db, remote);
            if ((await submission.view(account.id, id, user)).receipt) {
                const receipt = await submission.refresh(account.id, id, user, credentials);
                message = 'Lamoda · ' + receipt.remoteStatus;
            }
            else {
                const remoteId = plan.remoteShipmentId;
                if (!remoteId)
                    throw new common_1.ConflictException('Привяжите поставку Lamoda.');
                const { shipment: snapshot } = await remote.fboShipment(credentials, remoteId);
                if (snapshot.id !== remoteId || String(snapshot.sellerId) !== account.sellerId || typeof snapshot.status !== 'string')
                    throw new common_1.BadGatewayException('Lamoda не подтвердила статус привязанной поставки.');
                const status = snapshot.status;
                await this.db.$transaction(async (tx) => {
                    const current = await tx.lamodaPlan.findUnique({ where: { id: plan.id } });
                    if (current?.accountId !== account.id || current.remoteShipmentId !== remoteId)
                        throw new common_1.ConflictException('Привязка Lamoda изменилась.');
                    await tx.lamodaDocument.upsert({ where: { accountId_kind_remoteId: { accountId: account.id, kind: 'FBO_SHIPMENTS', remoteId } },
                        update: { status, syncedAt: new Date() }, create: { accountId: account.id, kind: 'FBO_SHIPMENTS', remoteId, number: String(snapshot.number ?? remoteId), status, payload: { id: remoteId, status } } });
                }, { isolationLevel: 'Serializable' });
                message = 'Lamoda · ' + status;
            }
        }
        else if (r.ozonShipment) {
            const view = await this.ozon.refresh(id, user);
            message = 'Ozon · ' + (view.link ? (0, ozon_supply_policy_1.supplyOrders)(view.link).map(o => o.orderNumber + ' ' + o.state).join(', ') : 'поставка не привязана');
            await this.delivery.reconcile(id, undefined, r, true);
        }
        else if (r.fboAssembly && !r.yandexFbyShipment) {
            const view = await this.wb.refresh(id, user, true);
            if (view.binding?.lastError)
                throw new common_1.BadGatewayException(view.binding.lastError);
            message = 'WB · ' + (view.binding?.status ?? 'поставка не привязана');
            await this.delivery.reconcile(id, undefined, r, true);
            if (view.binding && [4, 5, 6].includes(view.binding.statusId) && !view.dispatch)
                message += ' · В WMS требуется отметка загрузки в автомобиль';
        }
        else
            throw new common_1.ConflictException('У заявки нет поддерживаемой привязки к маркетплейсу.');
        const current = await this.db.clientRequest.findUniqueOrThrow({ where: { id }, select: { status: true } });
        return { status: current.status, message, checkedAt: new Date().toISOString() };
    }
    async checkFbs(id, clientId, links, user) {
        const active = links.filter(l => !['ADMIN_REMOVED', 'REMOVED'].includes(l.syncStatus));
        const market = active[0]?.marketplace;
        if (!market || !['WILDBERRIES', 'OZON'].includes(market) || active.some(l => l.marketplace !== market || l.syncStatus === 'MOVING'))
            throw new common_1.ConflictException('Проверьте привязку и перенос отправлений ФБС.');
        const observations = [];
        const started = Date.now();
        for (const connectionId of new Set(active.map(l => l.connectionId))) {
            const account = await this.db.clientMarketplaceConnection.findFirst({ where: {
                    id: connectionId, clientId, isActive: true, marketplace: market === 'OZON' ? 'OZON' : 'WILDBERRIES'
                } });
            if (!account)
                throw new common_1.ConflictException('Кабинет маркетплейса недоступен.');
            const ids = active.filter(l => l.connectionId === connectionId).map(l => l.orderId);
            if (market === 'WILDBERRIES') {
                const statuses = await this.connections.readWbStatusesForConnection(account.apiKey, ids);
                for (const orderId of ids) {
                    const status = statuses.get(orderId);
                    if (!status?.supplierStatus || !status.wbStatus)
                        throw new common_1.BadGatewayException('WB вернул неполный ответ.');
                    observations.push({ id: orderId, connectionId, marketplace: market, ...status });
                }
            }
            else
                for (const orderId of ids) {
                    const response = await this.ozon.call(account, '/v3/posting/fbs/get', { posting_number: orderId });
                    const posting = response.result ?? response;
                    if (posting.posting_number !== orderId || typeof posting.status !== 'string' || !posting.status)
                        throw new common_1.BadGatewayException('Ozon вернул неполный ответ.');
                    observations.push({ id: orderId, connectionId, marketplace: market, supplierStatus: posting.status, wbStatus: posting.status });
                }
        }
        await this.db.$transaction(async (tx) => {
            await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${id} FOR UPDATE`;
            const fresh = await tx.clientRequest.findUniqueOrThrow({ where: { id }, include: { fbsOrderLinks: true } });
            (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, fresh, 'write');
            await (0, request_removal_policy_1.assertRequestNotRemoved)(tx, id);
            if (fresh.clientId !== clientId || linkIdentity(fresh.fbsOrderLinks) !== linkIdentity(links) || Date.now() - started > 240000)
                throw new common_1.ConflictException('Данные заявки изменились. Повторите проверку.');
            const special = !!(await tx.fbsRepeatAssemblyRun.findUnique({ where: { requestId: id } }) ??
                await tx.fbsReshipmentRun.findUnique({ where: { requestId: id } }));
            const close = market === 'OZON' ? ozon_packed_auto_done_1.closeOzonPackedRequest : wb_packed_auto_done_1.closeWbPackedRequest;
            await close(tx, fresh, observations, special);
        });
        const counts = new Map();
        for (const o of observations) {
            const status = market === 'OZON' ? o.supplierStatus : o.supplierStatus + '/' + o.wbStatus;
            counts.set(status, (counts.get(status) ?? 0) + 1);
        }
        return (market === 'OZON' ? 'Ozon' : 'WB') + ' · ' + [...counts].map(([status, n]) => status + ' (' + n + ')').join(', ');
    }
};
exports.RequestMarketStatusService = RequestMarketStatusService;
exports.RequestMarketStatusService = RequestMarketStatusService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof marketplace_connections_service_1.MarketplaceConnectionsService !== "undefined" && marketplace_connections_service_1.MarketplaceConnectionsService) === "function" ? _c : Object, typeof (_d = typeof ozon_assembly_supply_service_1.OzonAssemblySupplyService !== "undefined" && ozon_assembly_supply_service_1.OzonAssemblySupplyService) === "function" ? _d : Object, typeof (_e = typeof wb_fbo_supply_service_1.WbFboSupplyService !== "undefined" && wb_fbo_supply_service_1.WbFboSupplyService) === "function" ? _e : Object, typeof (_f = typeof fbo_delivery_sync_service_1.FboDeliverySyncService !== "undefined" && fbo_delivery_sync_service_1.FboDeliverySyncService) === "function" ? _f : Object])
], RequestMarketStatusService);
