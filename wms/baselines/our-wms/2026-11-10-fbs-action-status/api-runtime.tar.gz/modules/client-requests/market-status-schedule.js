"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.marketStatusScheduleEnabled = void 0;
exports.marketStatusSlot = marketStatusSlot;
exports.claimMarketSlot = claimMarketSlot;
exports.finishMarketSlot = finishMarketSlot;
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
const marketStatusScheduleEnabled = () => process.env.WMS_MARKET_STATUS_SCHEDULE_ENABLED === 'true';
exports.marketStatusScheduleEnabled = marketStatusScheduleEnabled;
// FIX: timezone is explicit, independent of container/host timezone. No catch-up burst of old slots.
function marketStatusSlot(now = new Date()) {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Moscow', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hourCycle: 'h23' }).formatToParts(now);
    const get = (type) => parts.find(p => p.type === type).value;
    const hour = [8, 12, 15, 18, 21].filter(h => h <= Number(get('hour'))).at(-1);
    return hour === undefined ? null : `${get('year')}-${get('month')}-${get('day')}T${String(hour).padStart(2, '0')}:00+03:00`;
}
const settingKey = (id) => `request.market-schedule.v1:${id}`;
async function claimMarketSlot(db, id, slot, now = Date.now()) {
    return db.$transaction(async (tx) => {
        const key = settingKey(id);
        await tx.$queryRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(${key},0))::text`);
        const old = (await tx.systemSetting.findUnique({ where: { key } }))?.value ?? {};
        if (old.leaseUntil > now || old.slot === slot && (old.done || old.nextAt > now))
            return null;
        const value = { slot, token: (0, node_crypto_1.randomUUID)(), leaseUntil: now + 10 * 60000, attempts: old.slot === slot ? (old.attempts ?? 0) + 1 : 1 };
        await tx.systemSetting.upsert({ where: { key }, create: { key, value }, update: { value } });
        return value;
    });
}
async function finishMarketSlot(db, id, claim, success, code, now = Date.now()) {
    return db.$transaction(async (tx) => {
        const key = settingKey(id);
        await tx.$queryRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(${key},0))::text`);
        const old = (await tx.systemSetting.findUnique({ where: { key } }))?.value;
        if (old?.token !== claim.token)
            return;
        await tx.systemSetting.update({ where: { key }, data: { value: { ...old, token: null, leaseUntil: 0, done: success, nextAt: now + Math.min(60, 5 * 2 ** Math.min(old.attempts - 1, 4)) * 60000, checkedAt: new Date(now).toISOString(), result: code } } });
    });
}
