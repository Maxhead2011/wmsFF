"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pvzOrderKey = exports.pvzLossEnabled = exports.pvzLossKey = void 0;
exports.assertPvzLossMode = assertPvzLossMode;
exports.assertPvzShipment = assertPvzShipment;
exports.pvzLossOrderKeys = pvzLossOrderKeys;
exports.isPvzLossTask = isPvzLossTask;
exports.isPvzLossRequest = isPvzLossRequest;
exports.syncPvzLossBatch = syncPvzLossBatch;
const common_1 = require("@nestjs/common");
const prefix = 'fbs.pvzLossSettlement.';
const pvzLossKey = (requestId) => prefix + requestId;
exports.pvzLossKey = pvzLossKey;
const pvzLossEnabled = () => process.env.WMS_FBS_PVZ_LOSS_SETTLEMENT_ENABLED === 'true';
exports.pvzLossEnabled = pvzLossEnabled;
const pvzOrderKey = (row) => JSON.stringify([row.requestId, row.connectionId, row.orderId]);
exports.pvzOrderKey = pvzOrderKey;
// FIX: separate purpose, enabled only on our installation and always with the old label.
function assertPvzLossMode(dto) {
    if (!dto.pvzLossSettlement)
        return;
    if (!(0, exports.pvzLossEnabled)())
        throw new common_1.ForbiddenException('Режим довоза ПВЗ не включён для этой WMS.');
    if (!dto.preserveOriginalSticker || !dto.settlementReason?.trim() || dto.settlementReason.trim().length > 1000) {
        throw new common_1.BadRequestException('Для довоза ПВЗ нужны прежний стикер и основание.');
    }
}
// FIX: legacy RELEASED/null-KIZ attempts require immutable, exact shipment evidence.
function assertPvzShipment(task, shipment, warehouseId, wb) {
    if (!shipment || !['COMPLETED', 'RELEASED'].includes(task.status) || !task.completedAt ||
        task.itemCount !== 1 || task.cargoPackingId || shipment.quantity !== 1 ||
        shipment.clientId !== task.clientId || shipment.connectionId !== task.connectionId ||
        shipment.orderId !== task.orderId || shipment.assemblyId !== task.id ||
        shipment.requestId !== task.requestId || shipment.warehouseId !== warehouseId || shipment.skuId !== task.skuId ||
        !shipment.shippedAt || !shipment.assemblySnapshot?.barcode ||
        (task.requiresKiz && (!shipment.kiz || shipment.assemblySnapshot.kiz !== shipment.kiz)) ||
        !wb || !['complete', 'cancel', 'canceled', 'cancelled'].includes(wb.supplierStatus) ||
        !['waiting', 'sorted', 'canceled', 'cancelled', 'canceled_by_client', 'declined_by_client', 'canceled_by_carrier'].includes(wb.wbStatus)) {
        throw new common_1.BadRequestException('Для довоза ПВЗ не подтверждена точная прежняя отгрузка или статус WB.');
    }
}
// FIX: a trusted server record binds the exception to one request/order. Never infer it from titles/comments.
async function pvzLossOrderKeys(db, rows) {
    const result = new Set();
    if (!(0, exports.pvzLossEnabled)() || !rows.length || !db.systemSetting?.findMany)
        return result;
    const ids = [...new Set(rows.map(row => row.requestId).filter(Boolean))];
    if (!ids.length)
        return result;
    const records = await db.systemSetting.findMany({ where: { key: { in: ids.map(exports.pvzLossKey) } } });
    for (const record of records) {
        const value = record.value;
        if (value?.version !== 1 || value.purpose !== 'PVZ_LOSS_SETTLEMENT' || record.key !== (0, exports.pvzLossKey)(value.requestId) ||
            !value.clientId || !value.warehouseId || !value.shipmentId || !value.taskId || !value.originalAttemptId)
            continue;
        for (const row of rows) {
            if (row.requestId !== value.requestId || row.connectionId !== value.connectionId || row.orderId !== value.orderId ||
                (row.marketplace && row.marketplace !== 'WILDBERRIES') ||
                (row.clientId && row.clientId !== value.clientId) ||
                (row.request?.client?.id && row.request.client.id !== value.clientId) ||
                (row.stockWarehouseId && row.stockWarehouseId !== value.warehouseId) ||
                (row.skuId && row.skuId !== value.skuId) ||
                (row.requestItemId && row.id !== value.taskId))
                continue;
            result.add((0, exports.pvzOrderKey)(row));
        }
    }
    return result;
}
async function isPvzLossTask(db, task) {
    return (await pvzLossOrderKeys(db, [task])).has((0, exports.pvzOrderKey)(task));
}
// FIX: a worker can open a proven urgent delivery outside the ordinary fixed window.
async function isPvzLossRequest(db, requestId, clientId) {
    if (!(0, exports.pvzLossEnabled)() || !db.systemSetting?.findMany)
        return false;
    const records = await db.systemSetting.findMany({ where: { key: { in: [(0, exports.pvzLossKey)(requestId)] } } });
    const value = records[0]?.value;
    if (!value?.taskId)
        return false;
    const task = await db.fbsTsdAssembly.findUnique({ where: { id: value.taskId } });
    return Boolean(task && task.requestId === requestId && task.clientId === clientId && await isPvzLossTask(db, task));
}
// FIX: marketplace refresh may update its actual snapshot, never cancel/auto-finish a local settlement.
async function syncPvzLossBatch(db, requestId, orders) {
    if (!(0, exports.pvzLossEnabled)() || !db.systemSetting?.findMany)
        return false;
    const records = await db.systemSetting.findMany({ where: { key: { in: [(0, exports.pvzLossKey)(requestId)] } } });
    const value = records[0]?.value;
    if (!value?.taskId)
        return false;
    const task = await db.fbsTsdAssembly.findUnique({ where: { id: value.taskId } });
    if (!task || !await isPvzLossTask(db, task))
        throw new common_1.BadRequestException('Повреждена привязка довоза ПВЗ; требуется проверка администратора.');
    const link = await db.fbsOrderRequestLink.findUnique({ where: { marketplace_connectionId_orderId: { marketplace: 'WILDBERRIES', connectionId: task.connectionId, orderId: task.orderId } } });
    if (!link || link.requestId !== requestId || link.clientId !== value.clientId || link.syncStatus !== 'ACTIVE') {
        throw new common_1.BadRequestException('Привязка довоза ПВЗ изменилась; автоматическое восстановление запрещено.');
    }
    const remote = orders.find(order => order.connectionId === task.connectionId && order.id === task.orderId);
    if (remote)
        await db.fbsOrderRequestLink.update({ where: { id: link.id }, data: { lastCategory: remote.category, lastSupplierStatus: remote.supplierStatus, lastWbStatus: remote.wbStatus, lastSeenAt: new Date() } });
    return true;
}
