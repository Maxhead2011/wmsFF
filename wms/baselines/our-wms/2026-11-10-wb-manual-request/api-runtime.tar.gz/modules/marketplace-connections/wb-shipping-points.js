"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wbShippingEnabled = void 0;
exports.shippingDate = shippingDate;
exports.shippingPoints = shippingPoints;
exports.availableShippingPoint = availableShippingPoint;
exports.saveShippingMethod = saveShippingMethod;
const common_1 = require("@nestjs/common");
// FIX: shippingPointId is independent of destinationOfficeId. Russian WB API,
// official 03-orders-fbs.yaml, retrieved 2026-11-09. Sold installation stays off.
const wbShippingEnabled = () => process.env.WMS_WB_SHIPPING_POINTS_ENABLED === 'true';
exports.wbShippingEnabled = wbShippingEnabled;
function shippingDate(value) {
    const date = String(value ?? '');
    const parsed = new Date(`${date}T00:00:00Z`);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== date) {
        throw new common_1.BadRequestException('Укажите корректную дату отгрузки.');
    }
    return date;
}
async function shippingPoints(request, supplyId, city, date) {
    if (!city?.trim() || city.length > 120)
        throw new common_1.BadRequestException('Укажите населённый пункт сдачи.');
    const query = new URLSearchParams({ city: city.trim(), officeType: 'sc,sw,pp,pfc,gpp', shippingDt: shippingDate(date) });
    const result = await request(`/api/marketplace/v3/fbs/supplies/${encodeURIComponent(supplyId)}/shipping-points?${query}`);
    if (!Array.isArray(result.shippingPoints))
        throw new common_1.BadRequestException('WB не вернул список пунктов сдачи. Повторите проверку.');
    return result.shippingPoints.filter((point) => Number.isSafeInteger(Number(point.id)) && Number(point.id) > 0).map((point) => ({
        id: String(point.id), name: String(point.name ?? ''), address: String(point.address ?? ''),
        city: String(point.city ?? ''), officeType: String(point.officeType ?? ''), available: point.available === true,
    }));
}
function availableShippingPoint(points, id) {
    const point = points.find((item) => item.id === id && item.available);
    if (!point)
        throw new common_1.BadRequestException('Выбранный пункт сдачи недоступен для этой поставки и даты. Обновите список пунктов.');
    return point;
}
async function saveShippingMethod(request, supplyId, pointId, date) {
    const id = Number(pointId);
    if (!Number.isSafeInteger(id) || id <= 0)
        throw new common_1.BadRequestException('Некорректный пункт сдачи.');
    const result = await request('/api/marketplace/v3/fbs/supplies/shipping-method', {
        method: 'PATCH', body: JSON.stringify({ data: [{ supplyId, shippingPointId: id, shippingDt: shippingDate(date), shippingType: 'selfShipping' }] }),
    });
    const row = Array.isArray(result.results) ? result.results.find((item) => item.supplyId === supplyId) : null;
    if (!row || row.success !== true || row.error)
        throw new common_1.BadRequestException(`WB не сохранил пункт сдачи: ${row?.error?.detail || 'нет подтверждения для поставки'}`);
    const fresh = await request(`/api/v3/supplies/${encodeURIComponent(supplyId)}`);
    if (String(fresh.shippingPointId) !== pointId || fresh.shippingDt !== date || fresh.shippingType !== 'selfShipping') {
        throw new common_1.BadRequestException('WB не подтвердил сохранённые параметры. Обновите поставку перед передачей.');
    }
    return fresh;
}
