"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fabricPairedLabels = fabricPairedLabels;
exports.buildFbsProductLabel = buildFbsProductLabel;
const common_1 = require("@nestjs/common");
const bwipjs = require("bwip-js");
const pdfMake = require("pdfmake");
const pdf_lib_1 = require("pdf-lib");
const pdfmake_1 = require("../../common/pdf/pdfmake");
const marketplace_product_links_1 = require("./marketplace-product-links");
const ozon_fbs_pick_lines_1 = require("./ozon-fbs-pick-lines");
const fbs_stickers_pdf_1 = require("./fbs-stickers-pdf");
const fbs_sorting_label_1 = require("./fbs-sorting-label");
const MM = 72 / 25.4;
const key = (s) => JSON.stringify([s.connectionId, s.id]);
const clean = (v) => String(v ?? '').replace(/[\x00-\x1f]/g, ' ').trim();
// FIX: general unmarked printing is independent of fabric accounting.
// The legacy fabric gate remains only for deployments without the new opt-in.
// Never ship/assemble an order or manufacture/debit stock in a print request.
async function fabricPairedLabels(db, clientId, selections, resolve, json, binary) {
    if (!selections.length)
        return null;
    const unmarkedPrinting = process.env.WMS_FBS_UNMARKED_PAIRED_LABELS_ENABLED === 'true';
    if (!unmarkedPrinting) {
        if (process.env.WMS_FBS_FABRIC_CUT_ENABLED !== 'true')
            return null;
        const enabled = await db.systemSetting.findUnique({ where: { key: `fabric.fbs.enabled.v1:${clientId}` } });
        if (enabled?.value?.enabled !== true)
            return null;
    }
    const selected = [...new Map(selections.map(s => [key(s), s])).values()];
    const connectionIds = [...new Set(selected.map(s => s.connectionId))];
    const connections = await db.clientMarketplaceConnection.findMany({
        where: { id: { in: connectionIds }, clientId, isActive: true },
        select: { id: true, marketplace: true, sellerId: true, apiKey: true },
    });
    if (connections.length !== connectionIds.length)
        throw new common_1.BadRequestException('Подключение выбранного кабинета не найдено или отключено.');
    if (connections.some((c) => !['WILDBERRIES', 'OZON'].includes(c.marketplace)))
        return null;
    const catalog = await db.sku.findMany({ where: { clientId }, include: { barcodes: true } });
    const wbSelected = selected.filter(s => connections.find((c) => c.id === s.connectionId)?.marketplace === 'WILDBERRIES');
    const wbOrders = wbSelected.length ? (await resolve(wbSelected)).orders : [];
    const plans = [];
    // Resolve every product before requesting any printable file. No partial download.
    for (const selection of selected) {
        const connection = connections.find((c) => c.id === selection.connectionId);
        let products = [], crossBorder = false;
        if (connection.marketplace === 'WILDBERRIES') {
            const matches = wbOrders.filter(o => key(o) === key(selection));
            if (matches.length !== 1)
                throw new common_1.BadRequestException(`Не найден выбранный заказ WB ${selection.id}.`);
            const order = matches[0];
            if (!['confirm', 'complete'].includes(order.supplierStatus) || order.category === 'cancelled')
                throw new common_1.BadRequestException(`Стикер WB ${selection.id} недоступен в текущем статусе.`);
            crossBorder = Number(order.crossBorderType ?? 0) !== 0;
            const sku = catalog.find((s) => s.id === order.product?.id);
            if (!sku)
                throw new common_1.BadRequestException(`Не найден товар заказа ${selection.id}. Обновите карточки товаров.`);
            // Printing does not depend on the raw-roll parser's supported colours.
            const marketplaceMarking = unmarkedPrinting && [...(order.requiredMeta ?? []), ...(order.optionalMeta ?? [])]
                .some(value => String(value).toLowerCase() === 'sgtin');
            if (!marketplaceMarking && (!sku.needsChestnyZnak || sku.isUnmarked))
                products = [labelProduct(sku, order.barcodes, order.itemCount, selection.id)];
        }
        else {
            if (!connection.sellerId)
                throw new common_1.BadRequestException('В подключении Ozon не заполнен Client-Id.');
            const response = await json('https://api-seller.ozon.ru/v3/posting/fbs/get', {
                method: 'POST', headers: ozonHeaders(connection), body: JSON.stringify({ posting_number: selection.id }), signal: AbortSignal.timeout(20000),
            });
            const posting = response.result ?? response;
            if (posting.posting_number !== selection.id)
                throw new common_1.BadRequestException('Ozon вернул другой номер заказа.');
            if (!['awaiting_deliver', 'arbitration', 'delivering', 'delivered'].includes(posting.status))
                throw new common_1.BadRequestException(`Ozon ещё не разрешил официальный стикер ${selection.id}. Сначала передайте сборку Ozon; скачивание не меняет статус заказа.`);
            const skus = await (0, marketplace_product_links_1.ozonLinkedSkus)(db, clientId, connection.id, catalog);
            const lines = (0, ozon_fbs_pick_lines_1.ozonPostingProducts)(posting);
            if (unmarkedPrinting) {
                // Existing warehouse cards may originate in WB. Obtain the exact Ozon
                // SKU/offer barcode rather than choosing a card by its name or old order.
                const missing = lines.filter(line => !line.barcodes.length && printingOzonCandidates(line, skus).length !== 1);
                for (let i = 0; i < missing.length; i += 100) {
                    const batch = missing.slice(i, i + 100);
                    const response = await json('https://api-seller.ozon.ru/v3/product/info/list', {
                        method: 'POST', headers: ozonHeaders(connection), body: JSON.stringify({ sku: batch.map(line => String(line.productId)) }), signal: AbortSignal.timeout(20000),
                    });
                    const cards = response.items ?? response.result?.items ?? response.result ?? [];
                    if (!Array.isArray(cards))
                        throw new common_1.BadRequestException('Ozon не вернул карточки выбранных товаров.');
                    for (const line of batch)
                        line.barcodes = [...new Set(cards.filter((card) => card.offer_id === line.offerId &&
                                Array.isArray(card.sources) && card.sources.some((source) => String(source.sku) === String(line.productId)))
                                .flatMap((card) => Array.isArray(card.barcodes) ? card.barcodes.map(String) : []))];
                }
            }
            // The picking resolver rejects marked goods; printing must preserve their official
            // sticker and simply omit the extra product label, including mixed postings.
            const marks = new Set((posting.requirements?.products_requiring_mandatory_mark ?? []).map(String));
            const resolved = lines.map(line => ({ line, sku: unmarkedPrinting ? printingOzonSku(line, skus) : (0, ozon_fbs_pick_lines_1.resolveOzonLineSku)(line, skus) }))
                .filter(({ line, sku }) => !unmarkedPrinting || (!marks.has(String(line.productId)) && (!sku.needsChestnyZnak || sku.isUnmarked)));
            products = resolved.map(({ line, sku }) => labelProduct(sku, line.barcodes.length ? line.barcodes : sku.barcodes.map((b) => b.value), line.quantity, selection.id));
        }
        plans.push({ ...selection, connection, products, crossBorder });
    }
    if (!plans.some(p => p.products.length))
        return null;
    const wbFiles = new Map();
    for (const connection of connections.filter((c) => c.marketplace === 'WILDBERRIES')) {
        for (const crossBorder of [false, true]) {
            const group = plans.filter(p => p.connectionId === connection.id && p.crossBorder === crossBorder);
            for (let i = 0; i < group.length; i += 100) {
                const chunk = group.slice(i, i + 100);
                if (chunk.some(p => !/^\d+$/.test(p.id) || !Number.isSafeInteger(Number(p.id))))
                    throw new common_1.BadRequestException('Некорректный номер заказа WB.');
                const response = await json('https://marketplace-api.wildberries.ru/api/v3/orders/stickers' +
                    (crossBorder ? '/cross-border' : '?type=png&width=58&height=40'), {
                    method: 'POST', headers: { Authorization: connection.apiKey, 'Content-Type': 'application/json' },
                    body: JSON.stringify({ orders: chunk.map(p => Number(p.id)) }), signal: AbortSignal.timeout(30000),
                });
                for (const plan of chunk) {
                    const stickers = (response.stickers ?? []).filter((s) => String(s.orderId) === plan.id && s.file);
                    if (stickers.length !== 1 || (crossBorder && stickers[0].status !== 'ready'))
                        throw new common_1.BadRequestException(`WB не вернул официальный стикер заказа ${plan.id}. Повторите скачивание позже.`);
                    const sticker = stickers[0];
                    wbFiles.set(key(plan), crossBorder ? Buffer.from(sticker.file, 'base64') :
                        await (0, fbs_stickers_pdf_1.buildFbsStickersPdf)([{ orderId: plan.id, barcode: String(sticker.barcode ?? ''), file: sticker.file }]));
                }
            }
        }
    }
    const parts = [];
    let numberedSet = 0;
    for (const plan of plans) {
        let official = wbFiles.get(key(plan));
        if (plan.connection.marketplace === 'OZON') {
            // One posting per response: batch PDF page order is not an order identity.
            official = (await binary('https://api-seller.ozon.ru/v2/posting/fbs/package-label', {
                method: 'POST', headers: { ...ozonHeaders(plan.connection), Accept: 'application/pdf' },
                body: JSON.stringify({ posting_number: [plan.id] }), signal: AbortSignal.timeout(30000),
            })).buffer;
        }
        if (!official?.length || (await pdf_lib_1.PDFDocument.load(official)).getPageCount() === 0)
            throw new common_1.BadRequestException(`Нет официальной этикетки заказа ${plan.id}.`);
        // FIX: one numbered set per posting, products first; never number unrelated WB pages.
        if (unmarkedPrinting && plan.connection.marketplace === 'OZON' && plan.products.length) {
            const source = await pdf_lib_1.PDFDocument.load(official);
            const position = { set: ++numberedSet, page: 0, total: plan.products.length + source.getPageCount() };
            for (const product of plan.products)
                parts.push(await buildFbsProductLabel(plan.id, product, { ...position, page: ++position.page }));
            parts.push(await numberedOzonLabels(source, position));
        }
        else {
            for (const product of plan.products)
                parts.push(await buildFbsProductLabel(plan.id, product));
            parts.push(official);
        }
    }
    return { buffer: await (0, fbs_stickers_pdf_1.mergeFbsStickerPdfs)(parts), count: plans.length };
}
function ozonHeaders(c) { return { 'Client-Id': c.sellerId, 'Api-Key': c.apiKey, 'Content-Type': 'application/json' }; }
function printingOzonCandidates(line, skus) {
    return skus.filter(sku => {
        const ids = String(sku.marketplaceProductId ?? '').split(':');
        return ids.includes(line.offerId) || ids.includes(String(line.productId)) || sku.marketplaceOfferId === line.offerId ||
            (sku.barcodes ?? []).some((b) => line.barcodes.includes(b.value));
    });
}
function printingOzonSku(line, skus) {
    const candidates = printingOzonCandidates(line, skus);
    if (candidates.length !== 1)
        throw new common_1.BadRequestException(`Не найдено однозначное соответствие артикула Ozon ${line.offerId}. Проверьте карточку в WMS.`);
    return candidates[0];
}
function labelProduct(sku, orderBarcodes, quantity, orderId) {
    const codes = [...new Set((orderBarcodes ?? []).map(clean).filter((b) => sku.barcodes.some((s) => s.value === b)))];
    if (codes.length !== 1 || !/^[\x21-\x7e]{4,48}$/.test(codes[0]))
        throw new common_1.BadRequestException(`Не найден однозначный ШК товара заказа ${orderId}. Проверьте карточку товара.`);
    if (!Number.isSafeInteger(quantity) || quantity <= 0)
        throw new common_1.BadRequestException(`Некорректное количество заказа ${orderId}.`);
    if (sku.needsChestnyZnak && !sku.isUnmarked)
        throw new common_1.BadRequestException(`Товар ${orderId} требует КИЗ; парная печать не заменяет проверку маркировки.`);
    return { barcode: codes[0], name: clean(sku.name), article: clean(sku.internalSku || sku.article), quantity };
}
const positionText = (p) => `Комплект ${String(p.set).padStart(3, '0')} · ${p.page}/${p.total}`;
// FIX: the official artwork is embedded as vector content, proportionally fitted
// above a separate footer. Never draw numbering over the marketplace barcode.
async function numberedOzonLabels(source, position) {
    (0, pdfmake_1.configurePdfMake)();
    const width = 58 * MM, height = 40 * MM;
    const templates = await pdfMake.createPdf({ pageSize: { width, height }, pageMargins: 0,
        defaultStyle: { font: 'DejaVuSans' },
        content: source.getPages().map((_, index) => ({ text: positionText({ ...position, page: position.page + index + 1 }),
            fontSize: 6.5, bold: true, alignment: 'center', absolutePosition: { x: 0, y: 37 * MM },
            ...(index ? { pageBreak: 'before' } : {}) })),
    }).getBuffer();
    const result = await pdf_lib_1.PDFDocument.load(templates);
    for (const [index, page] of source.getPages().entries()) {
        const crop = page.getCropBox();
        if (!(crop.width > 0 && crop.height > 0))
            throw new common_1.BadRequestException('Некорректный размер этикетки Ozon.');
        page.pushOperators(); // Retain even an empty source page without an embedding error.
        const artwork = await result.embedPage(page, { left: crop.x, bottom: crop.y, right: crop.x + crop.width, top: crop.y + crop.height });
        // Respect the PDF's rotation, then use landscape orientation on 58x40 stock.
        let angle = ((page.getRotation().angle % 360) + 360) % 360;
        if (![0, 90, 180, 270].includes(angle))
            throw new common_1.BadRequestException('Неподдерживаемый поворот этикетки Ozon.');
        let w = angle % 180 ? crop.height : crop.width, h = angle % 180 ? crop.width : crop.height;
        if (h > w) {
            angle = (angle + 90) % 360;
            [w, h] = [h, w];
        }
        const scale = Math.min(56 * MM / w, 35 * MM / h);
        const left = (width - w * scale) / 2, bottom = 4 * MM + (35 * MM - h * scale) / 2;
        // PDF /Rotate is clockwise; pdf-lib drawPage's rotate is counterclockwise.
        const offsets = { 0: [0, 0], 90: [0, crop.width], 180: [crop.width, crop.height], 270: [crop.height, 0] }[angle];
        result.getPage(index).drawPage(artwork, { x: left + offsets[0] * scale, y: bottom + offsets[1] * scale,
            width: crop.width * scale, height: crop.height * scale, rotate: (0, pdf_lib_1.degrees)(-angle) });
    }
    return Buffer.from(await result.save());
}
async function buildFbsProductLabel(orderId, product, position) {
    (0, pdfmake_1.configurePdfMake)();
    const fit = (text, count) => text.length > count ? text.slice(0, count - 1) + '…' : text;
    const line = (text, y, fontSize, bold = false) => ({
        absolutePosition: { x: 2 * MM, y: y * MM }, columns: [{ width: 54 * MM, text, fontSize, bold, noWrap: true }],
    });
    const svg = bwipjs.toSVG({ bcid: 'code128', text: product.barcode, scale: 2, height: 10, includetext: false });
    const name = (0, fbs_sorting_label_1.fitSortingWarehouse)(product.name, 54 * MM, 9 * MM);
    return Buffer.from(await pdfMake.createPdf({
        pageSize: { width: 58 * MM, height: 40 * MM }, pageMargins: 0,
        defaultStyle: { font: 'DejaVuSans' },
        content: [line(`Заказ ${clean(orderId)}`, 1.5, 7, true),
            { svg, width: 50 * MM, height: 10 * MM, absolutePosition: { x: 4 * MM, y: 6 * MM } },
            line(product.barcode, 16.5, Math.min(7, 54 * MM / product.barcode.length)),
            ...name.text.split('\n').map((text, index) => line(text, 20 + index * name.fontSize * 1.3 / MM, name.fontSize, true)),
            line(`Артикул: ${fit(product.article, 30)}`, 30, 6),
            line(`Количество: ${product.quantity} шт.`, position ? 33 : 34, position ? 8 : 9, true),
            ...(position ? [line(positionText(position), 37, 6.5, true)] : [])],
    }).getBuffer());
}
