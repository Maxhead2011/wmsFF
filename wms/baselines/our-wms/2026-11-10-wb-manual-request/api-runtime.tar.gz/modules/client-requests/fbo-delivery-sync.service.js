"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var FboDeliverySyncService_1;
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FboDeliverySyncService = void 0;
exports.claimDelivery = claimDelivery;
exports.finishDelivery = finishDelivery;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const stock_operations_service_1 = require("../stock/stock-operations.service");
const ozon_assembly_supply_service_1 = require("./ozon-assembly-supply.service");
const wb_fbo_supply_service_1 = require("./wb-fbo-supply.service");
const ozon_supply_policy_1 = require("./ozon-supply-policy");
const fbo_delivery_policy_1 = require("./fbo-delivery-policy");
const request_removal_policy_1 = require("./request-removal-policy");
const fbs_attempt_history_1 = require("../../common/shipment-history/fbs-attempt-history");
// FIX: durable per-request cooldown/lease; no transaction remains open during marketplace HTTP calls.
async function claimDelivery(db, id, now = Date.now()) {
    return db.$transaction(async (tx) => {
        const key = (0, fbo_delivery_policy_1.deliveryKey)(id);
        await tx.$queryRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(${key},0))::text`);
        const old = (await tx.systemSetting.findUnique({ where: { key } }))?.value ?? {};
        if (Number(old.leaseUntil) > now || Number(old.nextAt) > now)
            return null;
        const state = { ...old, token: (0, node_crypto_1.randomUUID)(), leaseUntil: now + 10 * 60_000, attempts: (Number(old.attempts) || 0) + 1, lastAttemptAt: new Date(now).toISOString() };
        await tx.systemSetting.upsert({ where: { key }, create: { key, value: state }, update: { value: state } });
        return state;
    });
}
async function finishDelivery(db, id, claim, outcome, now = Date.now()) {
    return db.$transaction(async (tx) => {
        const key = (0, fbo_delivery_policy_1.deliveryKey)(id);
        await tx.$queryRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(${key},0))::text`);
        const old = (await tx.systemSetting.findUnique({ where: { key } }))?.value;
        if (old?.token !== claim.token)
            return;
        const failed = outcome === 'RETRY';
        await tx.systemSetting.update({ where: { key }, data: { value: { ...old, token: null, leaseUntil: 0, outcome,
                    attempts: failed ? old.attempts : 0, nextAt: now + (failed ? (0, fbo_delivery_policy_1.deliveryRetryMs)(old.attempts) : 5 * 60_000), finishedAt: new Date(now).toISOString() } } });
    });
}
let FboDeliverySyncService = FboDeliverySyncService_1 = class FboDeliverySyncService {
    db;
    ozon;
    wb;
    stock;
    timer;
    running = false;
    stopped = false;
    cursor = '';
    log = new common_1.Logger(FboDeliverySyncService_1.name);
    constructor(db, ozon, wb, stock) {
        this.db = db;
        this.ozon = ozon;
        this.wb = wb;
        this.stock = stock;
    }
    onModuleInit() { if ((0, fbo_delivery_policy_1.fboDeliveryEnabled)())
        this.schedule(30_000); }
    onModuleDestroy() { this.stopped = true; if (this.timer)
        clearTimeout(this.timer); }
    schedule(ms) { if (this.stopped)
        return; this.timer = setTimeout(() => void this.tick(), ms); this.timer.unref?.(); }
    async tick() {
        if (this.running || this.stopped || !(0, fbo_delivery_policy_1.fboDeliveryEnabled)())
            return;
        this.running = true;
        try {
            const rows = await this.db.clientRequest.findMany({ where: { type: 'OUTBOUND', status: 'PACKED', warehouseId: { not: null }, client: { isDemo: false }, fboAssembly: { phase: 'COMPLETED' }, fbsOrderLinks: { none: {} }, ...(this.cursor ? { id: { gt: this.cursor } } : {}) }, orderBy: { id: 'asc' }, take: 100, select: { id: true } });
            if (!rows.length)
                this.cursor = '';
            let count = 0;
            for (const row of rows) {
                if (this.stopped || !(0, fbo_delivery_policy_1.fboDeliveryEnabled)())
                    break;
                this.cursor = row.id;
                let context;
                try {
                    context = await this.context(row.id);
                }
                catch {
                    this.log.warn(JSON.stringify({ event: 'fbo_delivery_sync', requestId: row.id, outcome: 'INVALID_CONTEXT' }));
                    continue;
                }
                if (!context)
                    continue;
                const claim = await claimDelivery(this.db, row.id);
                if (!claim)
                    continue;
                let outcome = 'RETRY';
                try {
                    outcome = await this.reconcile(row.id, context);
                }
                catch (error) {
                    this.log.warn(JSON.stringify({ event: 'fbo_delivery_sync', requestId: row.id, outcome: 'RETRY', code: error?.getStatus?.() ?? 'INTERNAL' }));
                }
                await finishDelivery(this.db, row.id, claim, outcome);
                if (++count >= 10)
                    break;
            }
        }
        catch {
            this.log.warn('FBO delivery cycle failed; persisted leases and cooldowns retained.');
        }
        finally {
            this.running = false;
            if ((0, fbo_delivery_policy_1.fboDeliveryEnabled)())
                this.schedule(60_000);
        }
    }
    async context(id, db = this.db) {
        const r = await db.clientRequest.findUnique({ where: { id }, include: { client: { select: { isDemo: true } }, fboAssembly: { select: { phase: true } }, ozonShipment: { select: { integration: true } }, lamodaAssembly: { select: { requestId: true } }, yandexFbyShipment: { select: { id: true } }, items: { select: { id: true, skuId: true, quantity: true } }, _count: { select: { fbsOrderLinks: true } } } });
        if (!r || r.client.isDemo || r.type !== 'OUTBOUND' || !['PACKED', 'DONE'].includes(r.status) || r.fboAssembly?.phase !== 'COMPLETED' || !r.warehouseId || r._count.fbsOrderLinks || r.lamodaAssembly || r.yandexFbyShipment)
            return null;
        if (/^(FBS|DBS)/i.test((r.title ?? '').trim()) || r.comment?.toLocaleLowerCase('ru-RU').includes('создано из fbs-заказов:') || (await (0, fbs_attempt_history_1.readFbsAttemptHistory)(db, { requestId: id })).length)
            return null;
        await (0, request_removal_policy_1.assertRequestNotRemoved)(db, id);
        const link = r.ozonShipment?.integration ?? (await db.systemSetting.findUnique({ where: { key: 'wb-fbo-tracking:v1:' + id } }))?.value;
        if (!link?.connectionId)
            return null;
        const market = r.ozonShipment ? 'OZON' : 'WILDBERRIES';
        if (market === 'OZON')
            (0, ozon_supply_policy_1.assertNoOzonAdjustment)(link);
        const connection = await db.clientMarketplaceConnection.findFirst({ where: { id: link.connectionId, clientId: r.clientId, marketplace: market, isActive: true } });
        if (!connection)
            return null;
        const dispatch = (await db.systemSetting.findUnique({ where: { key: 'wb-fbo-dispatch:v1:' + id } }))?.value;
        if (market === 'WILDBERRIES' && !dispatch?.at)
            return null;
        const version = (0, fbo_delivery_policy_1.deliveryVersion)([r.clientId, r.warehouseId, r.items.sort((a, b) => a.id.localeCompare(b.id)), market,
            market === 'OZON' ? link : [link.connectionId, link.supplyId], dispatch]);
        return { r, link, market, connection, dispatch, version };
    }
    async reconcile(id, initial, scope, manual = false) {
        const enabled = () => (0, fbo_delivery_policy_1.fboDeliveryEnabled)() || (manual && process.env.WMS_REQUEST_MARKET_STATUS_MANUAL_ENABLED === 'true');
        if (!enabled())
            return 'DISABLED';
        const c = initial ?? await this.context(id);
        if (!c || c.r.status === 'DONE')
            return 'SKIPPED';
        if(scope && (c.r.clientId!==scope.clientId || c.r.warehouseId!==scope.warehouseId)) throw new common_1.ConflictException('Заявка сменила клиента или филиал. Обновите список.');
        let evidence, accepted = false;
        if (c.market === 'OZON') {
            const ids = (0, ozon_supply_policy_1.supplyOrders)(c.link).map(o => Number(o.orderId));
            if (!ids.length || ids.length > 100 || ids.some(n => !Number.isSafeInteger(n) || n <= 0))
                throw new common_1.ConflictException('Некорректная привязка Ozon.');
            const response = await this.ozon.call(c.connection, '/v3/supply-order/get', { order_ids: ids });
            evidence = (0, fbo_delivery_policy_1.ozonDeliveryProof)(c.link, response);
            accepted = Boolean(evidence);
        }
        else {
            if (!/^[1-9]\d*$/.test(c.link.supplyId) || !Number.isSafeInteger(Number(c.link.supplyId)))
                throw new common_1.ConflictException('Некорректная привязка WB.');
            evidence = await this.wb.remote(c.connection, c.link.supplyId);
            accepted = (0, fbo_delivery_policy_1.wbDeliveryAccepted)(evidence, c.r.items.reduce((n, i) => n + i.quantity, 0), c.dispatch);
        }
        if (!accepted)
            return 'WAITING_MARKETPLACE';
        const checkedAt = Date.now();
        // System operation has no human actor; undefined leaves the assignee unchanged and writes nullable audit actors.
        const user = { id: undefined, email: '', name: 'Автоматическая сверка сдачи ФБО', roleCodes: [], permissionCodes: ['client-requests:write'], clientScopeMode: 'LIMITED', clientIds: [c.r.clientId], writableClientIds: [c.r.clientId], activeWarehouseId: c.r.warehouseId, warehouseIds: [c.r.warehouseId], writableWarehouseIds: [c.r.warehouseId] };
        await this.stock.shipClientRequest({ requestId: id, idempotencyKey: `ship-request:${id}`, comment: `Автоматически подтверждена сдача ФБО ${c.market === 'OZON' ? 'Ozon' : 'WB'}.` }, user, async (tx) => {
            if (!enabled() || Date.now() - checkedAt > 4 * 60_000)
                throw new common_1.ConflictException('Проверка сдачи устарела.');
            const fresh = await this.context(id, tx);
            if (!fresh || fresh.version !== c.version)
                throw new common_1.ConflictException('Привязка или состав поставки изменились.');
            if (fresh.r.status === 'DONE')
                return;
            // Evidence and status/stock changes commit or roll back together.
            await tx.auditLog.create({ data: { entity: 'ClientRequest', entityId: id, action: 'FBO_DELIVERY_CONFIRMED', payload: { marketplace: c.market, connectionId: c.connection.id, checkedAt: new Date(checkedAt).toISOString(), evidence } } });
        });
        this.log.log(JSON.stringify({ event: 'fbo_delivery_sync', requestId: id, outcome: 'DONE', marketplace: c.market }));
        return 'DONE';
    }
};
exports.FboDeliverySyncService = FboDeliverySyncService;
exports.FboDeliverySyncService = FboDeliverySyncService = FboDeliverySyncService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof ozon_assembly_supply_service_1.OzonAssemblySupplyService !== "undefined" && ozon_assembly_supply_service_1.OzonAssemblySupplyService) === "function" ? _b : Object, typeof (_c = typeof wb_fbo_supply_service_1.WbFboSupplyService !== "undefined" && wb_fbo_supply_service_1.WbFboSupplyService) === "function" ? _c : Object, typeof (_d = typeof stock_operations_service_1.StockOperationsService !== "undefined" && stock_operations_service_1.StockOperationsService) === "function" ? _d : Object])
], FboDeliverySyncService);
