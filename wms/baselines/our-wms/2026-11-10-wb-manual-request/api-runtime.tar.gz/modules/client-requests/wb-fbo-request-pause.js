"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wbPauseDeadline = wbPauseDeadline;
exports.wbFboPausedFetch = wbFboPausedFetch;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const node_crypto_1 = require("node:crypto");
const positive = (n) => Number.isFinite(n) && n > 0 ? n : 0;
// FIX: honor the longest server deadline; Retry-After can be seconds or an HTTP date.
function wbPauseDeadline(response, now) {
    const seconds = (name) => positive(Number(response.headers.get(name))) * 1000;
    const raw = response.headers.get('retry-after');
    const retry = raw ? (/^\d+(?:\.\d+)?$/.test(raw.trim()) ? positive(Number(raw)) * 1000 : positive(Date.parse(raw) - now)) : 0;
    const delay = Math.max(retry, seconds('x-ratelimit-retry'), seconds('x-ratelimit-reset'));
    return now + Math.max(response.status === 429 ? 60000 : 2000, delay);
}
function message(until, busy = false) {
    const time = new Date(until).toLocaleTimeString('ru-RU', { timeZone: 'Europe/Moscow', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    return new common_1.BadGatewayException(busy
        ? 'Проверка поставки WB этого клиента уже выполняется. Повторите позже.'
        : 'WB ограничил частоту проверки поставок. Следующая проверка доступна после ' + time + ' МСК (через ' + Math.max(1, Math.ceil((until - Date.now()) / 1000)) + ' сек.).');
}
// FIX: one durable gate per WMS client, shared by cabinet connections and manual/background calls.
// No DB transaction stays open while HTTP is in flight.
async function wbFboPausedFetch(db, clientId, send) {
    if (!clientId)
        throw new common_1.BadGatewayException('Не определён клиент для проверки поставки WB.');
    const key = 'wb-fbo-http-pause:v1:' + clientId;
    const locked = (fn) => db.$transaction(async (tx) => {
        await tx.$queryRaw(client_1.Prisma.sql `SELECT pg_advisory_xact_lock(hashtextextended(${key},0))::text`);
        return fn(tx, (await tx.systemSetting.findUnique({ where: { key } }))?.value ?? {});
    });
    const save = (tx, value) => tx.systemSetting.upsert({ where: { key }, create: { key, value }, update: { value } });
    const token = (0, node_crypto_1.randomUUID)();
    await locked(async (tx, s) => {
        const now = Date.now();
        if ((s.until ?? 0) > now)
            throw message(s.until);
        if ((s.leaseUntil ?? 0) > now)
            throw message(s.leaseUntil, true);
        await save(tx, { ...s, token, leaseUntil: now + 60000 });
    });
    let response;
    try {
        response = await send();
    }
    finally {
        await locked(async (tx, s) => {
            const now = Date.now();
            const limited = response?.status === 429 || response?.headers.get('x-ratelimit-remaining') === '0';
            const until = Math.max(s.until ?? 0, response ? (limited ? wbPauseDeadline(response, now) : now + 2000) : now + 10000);
            await save(tx, { ...s, until, ...(s.token === token ? { token: null, leaseUntil: 0 } : {}) });
        });
    }
    if (response.status === 429)
        throw message(wbPauseDeadline(response, Date.now()));
    return response;
}
