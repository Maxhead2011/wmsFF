"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var _a, _b, _c;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WbFboSupplyService = exports.wbFboStatuses = void 0;
exports.wbFboSupplyId = wbFboSupplyId;
const wb_fbo_dispatch_1 = require("./wb-fbo-dispatch");
const stock_operations_service_1 = require("../stock/stock-operations.service");
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../common/prisma/prisma.service");
const client_scope_service_1 = require("../auth/client-scope.service");
const client_request_warehouse_scope_1 = require("./client-request-warehouse-scope");
const request_removal_policy_1 = require("./request-removal-policy");
const fbs_attempt_history_1 = require("../../common/shipment-history/fbs-attempt-history");
// FIX: extract an ID, never fetch an arbitrary pasted URL.
function wbFboSupplyId(input) {
    let value = input?.trim();
    if (!value)
        throw new common_1.BadRequestException('Укажите номер или ссылку на поставку WB.');
    if (!/^\d+$/.test(value)) {
        let u;
        try {
            u = new URL(value);
        }
        catch {
            throw new common_1.BadRequestException('Некорректная ссылка WB.');
        }
        if (u.protocol !== 'https:' || u.hostname !== 'seller.wildberries.ru' || u.username || u.password || u.port || u.searchParams.getAll('supplyId').length !== 1)
            throw new common_1.BadRequestException('Нужна ссылка кабинета WB с supplyId.');
        value = u.searchParams.get('supplyId') || '';
    }
    if (!/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value)))
        throw new common_1.BadRequestException('Некорректный номер поставки WB.');
    return value;
}
exports.wbFboStatuses = { 1: 'Не запланировано', 2: 'Запланировано', 3: 'Отгрузка разрешена', 4: 'Идёт приёмка', 5: 'Принято', 6: 'Отгружено на воротах WB' };
const key = (id) => 'wb-fbo-tracking:v1:' + id;
let WbFboSupplyService = class WbFboSupplyService {
    db;
    scopes;
    stock;
    constructor(db, scopes, stock) {
        this.db = db;
        this.scopes = scopes;
        this.stock = stock;
    }
    async load(id, user, mode, db = this.db, allowOther = false) {
        if (process.env.WMS_MARKETPLACE_WORKSPACES_ENABLED !== 'true')
            throw new common_1.NotFoundException();
        if (mode === 'write' && (user.isDemo || !user.permissionCodes.some(p => p === 'system:admin' || p === 'client-requests:write')))
            throw new common_1.ForbiddenException();
        const r = await db.clientRequest.findUnique({ where: { id }, include: { ozonShipment: { select: { requestId: true } }, lamodaAssembly: { select: { requestId: true } }, yandexFbyShipment: { select: { id: true } }, fboAssembly: { select: { phase: true } }, items: { select: { quantity: true } }, _count: { select: { fbsOrderLinks: true } } } });
        if (!r)
            throw new common_1.NotFoundException('Заявка не найдена.');
        this.scopes.requireClientAccess(user, r.clientId, mode);
        (0, client_request_warehouse_scope_1.assertWarehouseAccess)(user, r, mode);
        if (r.type !== 'OUTBOUND' || (!allowOther && (r.ozonShipment || r.lamodaAssembly || r.yandexFbyShipment)) || r._count.fbsOrderLinks || /^(FBS|DBS)/i.test(r.title.trim()) || r.comment?.toLocaleLowerCase('ru-RU').includes('создано из fbs-заказов:') || (await (0, fbs_attempt_history_1.readFbsAttemptHistory)(db, { requestId: id })).length)
            throw new common_1.BadRequestException('Привязка доступна только для ФБО WB.');
        if (mode === 'write') {
            await (0, request_removal_policy_1.assertRequestNotRemoved)(db, id);
            if (['CANCELLED', 'REJECTED'].includes(r.status))
                throw new common_1.ConflictException('Заявка отменена.');
        }
        return r;
    }
    async stored(db, id) { return (await db.systemSetting.findUnique({ where: { key: key(id) } }))?.value ?? null; }
    async connection(id, clientId) { const c = await this.db.clientMarketplaceConnection.findFirst({ where: { id, clientId, marketplace: 'WILDBERRIES', isActive: true } }); if (!c)
        throw new common_1.BadRequestException('Действующее подключение WB этого клиента не найдено.'); return c; }
    // FIX: fixed read endpoint, bounded timeout, no marketplace writes or raw response logging.
    async remote(c, id) {
        let response;
        try {
            response = await (process.env.WMS_WB_FBO_REQUEST_PAUSE === 'true' ? (url,init)=>require('./wb-fbo-request-pause').wbFboPausedFetch(this.db,c.clientId,()=>fetch(url,init)) : fetch)('https://supplies-api.wildberries.ru/api/v1/supplies/' + id + '?isPreorderID=false', { headers: { Authorization: c.apiKey }, signal: AbortSignal.timeout(20000), redirect: 'error' });
        }
        catch (e) {
            if(e instanceof common_1.BadGatewayException) throw e;
            throw new common_1.BadGatewayException('Нет ответа WB. Повторите проверку.');
        }
        if (response.status === 429)
            throw new common_1.BadGatewayException('WB временно ограничил запросы (HTTP 429). Повторите проверку поставки позже.');
        if (!response.ok)
            throw new common_1.BadGatewayException(response.status === 403 ? 'Нет доступа к поставкам WB у этого API-ключа.' : `WB: HTTP ${response.status}.`);
        let data;
        try {
            data = await response.json();
        }
        catch {
            throw new common_1.BadGatewayException('Некорректный ответ WB.');
        }
        if (!Number.isInteger(data.statusID) || !exports.wbFboStatuses[data.statusID] || !Number.isSafeInteger(data.quantity) || data.quantity < 0 || !Number.isSafeInteger(data.acceptedQuantity) || data.acceptedQuantity < 0)
            throw new common_1.BadGatewayException('WB не подтвердил статус и количество поставки.');
        return { statusId: data.statusID, status: exports.wbFboStatuses[data.statusID], warehouse: String(data.warehouseName ?? ''), date: typeof data.supplyDate === 'string' ? data.supplyDate : null, quantity: data.quantity, acceptedQuantity: data.acceptedQuantity, checkedAt: new Date().toISOString() };
    }
    // FIX: after picking closes, use one physical unit per record, excluding returns.
    async bindingQuantity(db, r) {
        const plannedQuantity = r.items.reduce((sum, line) => sum + line.quantity, 0);
        if (process.env.WMS_WB_FBO_ACTUAL_BINDING_ENABLED !== 'true' || !r.fboAssembly ||
            !['PACKING', 'CONTROL', 'COMPLETED'].includes(r.fboAssembly.phase)) {
            return { plannedQuantity, bindingQuantity: plannedQuantity, quantityBasis: 'plan' };
        }
        const groups = await db.fboAssemblyUnit.groupBy({ by: ['state'], where: { requestId: r.id, state: { not: 'RETURNED' } }, _count: true });
        const picked = groups.reduce((sum, group) => sum + group._count, 0);
        const packed = groups.find(group => group.state === 'PACKED')?._count ?? 0;
        return { plannedQuantity, bindingQuantity: picked > 0 && picked === packed ? packed : null, quantityBasis: 'actual' };
    }
    async view(id, user) { const r = await this.load(id, user, 'read', this.db, true); return { dispatch: (await this.db.systemSetting.findUnique({ where: { key: (0, wb_fbo_dispatch_1.dispatchKey)(id) } }))?.value ?? null, binding: await this.stored(this.db, id), ...await this.bindingQuantity(this.db, r), canWrite: !user.isDemo && user.permissionCodes.some(p => p === 'system:admin' || p === 'client-requests:write'), canGate: ['PACKED', 'DONE'].includes(r.status) && r.fboAssembly?.phase === 'COMPLETED', connections: await this.db.clientMarketplaceConnection.findMany({ where: { clientId: r.clientId, marketplace: 'WILDBERRIES', isActive: true }, select: { id: true, accountName: true, sellerId: true } }) }; }
    async event(tx, r, user, title, body) { await tx.clientRequestEvent.create({ data: { requestId: r.id, clientId: r.clientId, eventType: 'COMMENT', title, body, createdByUserId: user.id } }); await tx.auditLog.create({ data: { userId: user.id, action: 'WB_FBO_TRACKING', entity: 'ClientRequest', entityId: r.id, payload: { title, body } } }); }
    async bind(id, connectionId, input, user) {
        const r = await this.load(id, user, 'write'), supplyId = wbFboSupplyId(input), c = await this.connection(connectionId, r.clientId), snapshot = await this.remote(c, supplyId);
        await this.db.$transaction(async (tx) => {
            await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${id} FOR UPDATE`;
            const fresh = await this.load(id, user, 'write', tx);
            const { bindingQuantity, quantityBasis } = await this.bindingQuantity(tx, fresh);
            if (bindingQuantity === null)
                throw new common_1.ConflictException('Для привязки по факту завершите упаковку всех отобранных единиц.');
            if (snapshot.quantity !== bindingQuantity)
                throw new common_1.ConflictException(`В WB ${snapshot.quantity} шт., ${quantityBasis === 'actual' ? 'отобрано и упаковано' : 'в заявке'} ${bindingQuantity} шт. Проверьте поставку.`);
            const claim = 'wb-fbo-supply-owner:v1:' + connectionId + ':' + supplyId;
            await tx.$executeRaw `SELECT pg_advisory_xact_lock(hashtext(${claim}))`;
            const old = await this.stored(tx, id), owner = await tx.systemSetting.findUnique({ where: { key: claim } });
            if (owner && owner.value.requestId !== id)
                throw new common_1.ConflictException('Поставка WB уже привязана к другой заявке.');
            if (old) {
                if (old.connectionId === connectionId && old.supplyId === supplyId)
                    return;
                throw new common_1.ConflictException('Заявка уже привязана. Изменение привязки требует разбора.');
            }
            await tx.systemSetting.create({ data: { key: claim, value: { requestId: id }, updatedByUserId: user.id } });
            await tx.systemSetting.create({ data: { key: key(id), value: { connectionId, supplyId, linkedAt: new Date().toISOString(), linkedBy: user.id, ...snapshot }, updatedByUserId: user.id } });
            await this.event(tx, fresh, user, 'Привязана поставка ФБО WB', `WB №${supplyId} · ${snapshot.quantity} шт. · ${snapshot.warehouse}`);
        });
        return this.view(id, user);
    }
    async refresh(id, user) {
        const r = await this.load(id, user, 'read');
        if (user.isDemo)
            throw new common_1.ForbiddenException();
        const before = await this.stored(this.db, id);
        if (!before)
            throw new common_1.ConflictException('Сначала привяжите поставку WB.');
        // FIX: shared fresh read avoids polling the same supply repeatedly across viewers.
        if (Date.now() - Date.parse(before.attemptedAt ?? before.checkedAt) < 30000) {
            await this.completeConfirmed(id, r, user);
            return this.view(id, user);
        }
        let snapshot, error;
        try {
            snapshot = await this.remote(await this.connection(before.connectionId, r.clientId), before.supplyId);
        }
        catch (e) {
            error = e instanceof Error ? e.message : 'Ошибка проверки WB';
        }
        await this.db.$transaction(async (tx) => {
            await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${id} FOR UPDATE`;
            const fresh = await this.load(id, user, 'read', tx), current = await this.stored(tx, id);
            if (!current || current.checkedAt !== before.checkedAt || current.attemptedAt !== before.attemptedAt)
                return;
            const next = { ...current, ...snapshot, attemptedAt: new Date().toISOString(), lastError: error ?? '' };
            await tx.systemSetting.update({ where: { key: key(id) }, data: { value: next, updatedByUserId: user.id } });
            if (snapshot && current.statusId !== snapshot.statusId)
                await this.event(tx, fresh, user, 'Обновлён статус поставки WB', `WB №${current.supplyId}: ${snapshot.status}. Принято ${snapshot.acceptedQuantity} из ${snapshot.quantity} шт.`);
        });
        await this.completeConfirmed(id, r, user, !!snapshot);
        return this.view(id, user);
    }
    async gate(id, user) {
        await this.db.$transaction(async (tx) => {
            await tx.$queryRaw `SELECT id FROM "ClientRequest" WHERE id=${id} FOR UPDATE`;
            const r = await this.load(id, user, 'write', tx, true);
            if (await tx.systemSetting.findUnique({ where: { key: (0, wb_fbo_dispatch_1.dispatchKey)(id) } }))
                return;
            if (r.status !== 'PACKED' || r.fboAssembly?.phase !== 'COMPLETED')
                throw new common_1.ConflictException('Сначала завершите упаковку и проверку коробов.');
            await tx.systemSetting.create({ data: { key: (0, wb_fbo_dispatch_1.dispatchKey)(id), value: { at: new Date().toISOString(), userId: user.id }, updatedByUserId: user.id } });
            await this.event(tx, r, user, 'Отгружено — загружено в автомобиль', 'Ручное подтверждение загрузки. Сдача маркетплейсу подтверждается отдельно.');
        });
        return this.view(id, user);
    }

async completeConfirmed(id, r, user, freshSnapshot = false) {
        const latest = await this.stored(this.db, id), dispatch = await this.db.systemSetting.findUnique({ where: { key: (0, wb_fbo_dispatch_1.dispatchKey)(id) } });
        const actual = process.env.WMS_WB_FBO_ACTUAL_BINDING_ENABLED === 'true';
        if (r.status !== 'PACKED' || r.fboAssembly?.phase !== 'COMPLETED' || !latest || !dispatch || !this.stock ||
            user.isDemo || !user.permissionCodes.some(p => p === 'system:admin' || p === 'client-requests:write'))
            return;
        if (![4, 5, 6].includes(latest.statusId) || (!freshSnapshot && !(actual && latest.statusId === 6)))
            return;
        const { bindingQuantity } = await this.bindingQuantity(this.db, r);
        if (bindingQuantity === null || latest.quantity !== bindingQuantity)
            return;
        await this.load(id, user, 'write');
        await this.stock.shipClientRequest({ requestId: id, idempotencyKey: `ship-request:${id}`,
            comment: `Сдано: WB №${latest.supplyId}, ${latest.status}.` }, user);
    }
};
exports.WbFboSupplyService = WbFboSupplyService;
exports.WbFboSupplyService = WbFboSupplyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [typeof (_a = typeof prisma_service_1.PrismaService !== "undefined" && prisma_service_1.PrismaService) === "function" ? _a : Object, typeof (_b = typeof client_scope_service_1.ClientScopeService !== "undefined" && client_scope_service_1.ClientScopeService) === "function" ? _b : Object, typeof (_c = typeof stock_operations_service_1.StockOperationsService !== "undefined" && stock_operations_service_1.StockOperationsService) === "function" ? _c : Object])
], WbFboSupplyService);
