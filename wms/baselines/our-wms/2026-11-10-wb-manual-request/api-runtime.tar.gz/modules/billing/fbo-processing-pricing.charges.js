"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFboCompositionCharges = createFboCompositionCharges;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const fbo_processing_pricing_policy_1 = require("./fbo-processing-pricing.policy");
// FIX: opt-in compositions replace only processing lines; packaging and relabeling remain separate.
async function createFboCompositionCharges(tx, input) {
    if (!(0, fbo_processing_pricing_policy_1.fboProcessingPricingEnabled)())
        return false;
    const rows = await tx.$queryRaw `SELECT * FROM "ClientFboProcessingTariff" WHERE "clientId"=${input.request.clientId}`;
    const revision = (await tx.$queryRaw `SELECT * FROM "ClientFboProductRuleRevision" WHERE "clientId"=${input.request.clientId} AND "createdAt"<=${input.serviceDate} ORDER BY "revision" DESC LIMIT 1`)[0];
    const tariff = require('./product-rules').combinedTariff(rows[0],revision);
    if (!rows[0] && !(revision?.rules.length)) return false;
    if (!tariff || input.serviceDate < new Date(tariff.createdAt))
        return false;
    // Request-local lock prevents two independent closing/packing retries creating duplicate snapshots.
    await tx.$queryRaw `SELECT 1 FROM pg_advisory_xact_lock(1179209295, hashtext(${input.request.id}))`;
    const prefix = `fulfillment-fbo-composition:${input.request.id}:`;
    const existing = await tx.billingCharge.findFirst({ where: { requestId: input.request.id, OR: [{ sourceKey: { startsWith: prefix } }, { sourceKey: { startsWith: `fulfillment-processing:${input.request.id}:` } }, { sourceKey: { startsWith: `fulfillment-clothing-processing:${input.request.id}:` } }] }, select: { sourceKey: true } });
    if (existing)
        return Boolean(existing.sourceKey?.startsWith(prefix));
    if (!input.processedUnits)
        return true;
    const catalog = await tx.billingService.findMany({ where: { id: { in: [...tariff.definition.common, ...tariff.definition.variants.flatMap(v => v.services), ...(tariff.definition.rules || []).flatMap(rule => rule.services)].map(part => part.serviceId) } } });
    const definition = (0, fbo_processing_pricing_policy_1.normalizeFboTariff)(tariff.definition, catalog);
    if (definition.rulesEffectiveFrom && input.serviceDate < new Date(definition.rulesEffectiveFrom)) definition.rules = [];
    let units = input.packages.flatMap(pack => pack.items ?? []).map(item => ({ skuId: item.skuId ?? item.requestItem?.sku?.id ?? '', quantity: item.quantity }));
    if (!units.length && !definition.variants.length && !(definition.rules || []).length)
        units = [{ skuId: '__default__', quantity: input.processedUnits }];
    if (units.some(item => !item.skuId) || units.reduce((sum, item) => sum + item.quantity, 0) !== input.processedUnits)
        throw new common_1.BadRequestException('Для расчёта первоначальной обработки не хватает фактического состава упаковок.');
    const ruleSkuIds = [...new Set([...units, ...(input.receiptUnits || [])].map(unit => unit.skuId))];
    const ruleProducts = (definition.rules || []).length ? await tx.sku.findMany({
        where: { clientId: input.request.clientId, id: { in: ruleSkuIds } },
        select: { id: true, name: true, category: true },
    }) : [];
    const productById = new Map(ruleProducts.map(product => [product.id,product]));
    if ((definition.rules || []).length && ruleSkuIds.some(id => !productById.has(id)))
        throw new common_1.BadRequestException('Для автоматической обработки не найдены карточки всех товаров клиента.');
    units = units.map(unit => ({ ...unit, ...productById.get(unit.skuId) }));
    const lines = input.receiptUnits ? input.receiptUnits.flatMap(unit => (0, fbo_processing_pricing_policy_1.priceFboUnits)(definition, [{ ...productById.get(unit.skuId), skuId: unit.skuId, quantity: 1 }]).filter(line => !unit.selection || (!unit.selection.profile.includedServiceIds.includes(line.serviceId) && !['ITEM_PROCESSING', 'NOM_ОБРАБОТКА_ОДЕЖДЫ'].includes(catalog.find(s => s.id === line.serviceId)?.code ?? '')))) : (0, fbo_processing_pricing_policy_1.priceFboUnits)(definition, units);
    // FIX: retain one immutable row per service/variant when receipt profiles split the same SKU.
    if (input.receiptUnits) {
        const grouped = new Map();
        for (const line of lines) {
            const key = line.variantKey + ':' + line.serviceId;
            const previous = grouped.get(key);
            if (previous) {
                previous.quantity = String(Number(previous.quantity) + Number(line.quantity));
                previous.totalRub = String(Number(previous.totalRub) + Number(line.totalRub));
            }
            else
                grouped.set(key, { ...line });
        }
        for (const line of grouped.values())
            line.totalRub = new client_1.Prisma.Decimal(line.priceBeforeTaxRub).mul(line.quantity).div(line.taxMode === 'ADD_6_PERCENT' ? '0.94' : '1').toFixed(2);
        lines.splice(0, lines.length, ...grouped.values());
    }
    for (const line of lines) {
        const service = catalog.find(s => s.id === line.serviceId);
        await tx.billingCharge.create({ data: { clientId: input.request.clientId, requestId: input.request.id, serviceId: service.id, description: `${service.name}${line.variantName ? ' · ' + line.variantName : ''} по заявке ${input.request.title ?? input.request.id}`, unit: 'PIECE', quantity: line.quantity, unitPriceRub: line.unitPriceRub, totalRub: line.totalRub, status: 'APPROVED', source: 'MANUAL', serviceDate: input.serviceDate, sourceKey: prefix + tariff.id + ':' + line.variantKey + ':' + service.id, metadata: { packageBilling: true, fboProcessingComposition: true, tariffId: tariff.id, definitionHash: tariff.definitionHash, rulesRevisionId: tariff.rulesRevisionId || null, variantName: line.variantName, multiplier: line.multiplier, taxMode: line.taxMode, priceBeforeTaxRub: line.priceBeforeTaxRub, processedUnits: input.processedUnits }, comment: 'Первоначальная обработка FBO: сохранённый состав услуг', createdByUserId: input.user.id, approvedByUserId: input.user.id, approvedAt: new Date() } });
    }
    return true;
}
