"use strict";
const { BadRequestException, ConflictException, NotFoundException } = require('@nestjs/common');
const { randomUUID, createHash } = require('node:crypto');
const { runBillingMutation } = require('./billing-mutation');
const { normalizeFboTariff } = require('./fbo-processing-pricing.policy');
const { combinedTariff, previewRules } = require('./product-rules');

async function prepare(service, db, clientId, dto, user) {
    service.requireEnabled();
    service.requirePermission(user, 'billing:write');
    service.scopes.requireClientAccess(user, clientId, 'write');
    if (!Array.isArray(dto?.rules)) throw new BadRequestException('Передайте список правил.');
    const client = await db.client.findFirst({ where: { id: clientId, isDemo: Boolean(user.isDemo) }, select: { id: true } });
    if (!client) throw new NotFoundException('Клиент не найден.');
    const base = (await db.$queryRaw`SELECT * FROM "ClientFboProcessingTariff" WHERE "clientId"=${clientId}`)[0];
    const revision = (await db.$queryRaw`SELECT * FROM "ClientFboProductRuleRevision" WHERE "clientId"=${clientId} ORDER BY "revision" DESC LIMIT 1`)[0];
    const saved = combinedTariff(base, revision);
    const catalog = await db.billingService.findMany({ where: { isActive: true, unit: { in: ['PIECE', 'SERVICE'] } } });
    const definition = !base && dto.rules.length === 0 ? { common: [], variants: [], rules: [] }
        : normalizeFboTariff({ ...(base?.definition || { common: [], variants: [] }), rules: dto.rules }, catalog);
    const products = await db.sku.findMany({ where: { clientId }, select: { id: true, name: true, category: true, article: true, size: true } });
    return { saved, base, revision, definition, preview: previewRules(definition, products) };
}

async function preview(service, clientId, dto, user) {
    const prepared = await prepare(service, service.prisma, clientId, dto, user);
    return { ...prepared.preview, definitionHash: prepared.saved?.definitionHash || null };
}

async function save(service, clientId, dto, user) {
    if (!(dto?.expectedDefinitionHash === null || typeof dto?.expectedDefinitionHash === 'string'))
        throw new BadRequestException('Проверьте версию тарифа.');
    return runBillingMutation(service.prisma, async db => {
        const { saved, base, revision, definition, preview } = await prepare(service, db, clientId, dto, user);
        if (preview.conflictCount) throw new ConflictException(`Несколько правил совпали для ${preview.conflictCount} товаров. Уточните слова в правилах.`);
        if (definition.rules.length && preview.unmatchedCount && !definition.common.some(part => Number(part.priceRub) > 0) && dto.allowUnmatched !== true)
            throw new BadRequestException('Для товаров без совпадения потребуется тариф. Подтвердите это после проверки товаров.');
        const hash = createHash('sha256').update(JSON.stringify(definition.rules)).digest('hex');
        if (revision?.rulesHash === hash) return saved;
        if ((saved?.definitionHash || null) !== dto.expectedDefinitionHash)
            throw new ConflictException('Тариф изменён другим сотрудником. Обновите страницу и проверьте правила.');
        const id = randomUUID();
        const inserted = (await db.$queryRaw`INSERT INTO "ClientFboProductRuleRevision" ("id","clientId","rules","rulesHash","createdByUserId")
            VALUES (${id},${clientId},${JSON.stringify(definition.rules)}::jsonb,${hash},${user.id}) RETURNING *`)[0];
        await db.auditLog.create({ data: { userId: user.id, action: 'FBO_PRODUCT_RULES_SAVED', entity: 'ClientFboProductRuleRevision', entityId: id,
            payload: { clientId, previousRevisionId: revision?.id || null, baseTariffHash: base?.definitionHash || null,
                rules: definition.rules, rulesHash: hash,
                matchedProducts: preview.rules.map(rule => ({ name: rule.name, count: rule.count })) } } });
        return combinedTariff(base, inserted);
    });
}

module.exports = { preview, save };
