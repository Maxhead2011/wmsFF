"use strict";

function correctionRows(corrections) {
    return corrections.filter(correction => Number(correction.amountRub) !== 0).map(correction => {
        const reason = String(correction.reason || '').replace(/\s*По поручению пользователя через Codex.*$/u, '').trim();
        const amount = Number(correction.amountRub);
        return {
            id: `correction:${correction.id}`,
            invoiceId: correction.invoiceId,
            chargeId: null,
            charge: null,
            description: `Корректировка счёта${reason ? ': ' + reason : ''}`,
            unit: 'SERVICE',
            quantity: 1,
            unitPriceRub: amount,
            totalRub: amount,
            serviceDate: correction.createdAt,
            isCorrection: true,
            correctionId: correction.id,
        };
    });
}

function presentInvoice(invoice, corrections, balance) {
    const base = { ...invoice, ...balance };
    if (!corrections.length) return base;
    return { ...base, totalRub: balance.effectiveTotalRub,
        items: [...invoice.items, ...correctionRows(corrections)],
        corrections: corrections.map(correction => ({ id: correction.id, amountRub: Number(correction.amountRub), reason: correction.reason, createdAt: correction.createdAt })),
    };
}

module.exports = { correctionRows, presentInvoice };
