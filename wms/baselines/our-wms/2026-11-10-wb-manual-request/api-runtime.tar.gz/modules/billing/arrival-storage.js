"use strict";

const DEFAULT_BAG_LITERS = 480;
const DEFAULT_BOX_LITERS = 96;
const round = value => Math.round((value + Number.EPSILON) * 1000) / 1000;

function dateKey(value) {
    return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) &&
        !Number.isNaN(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
}

function arrivalVolume(payload) {
    const bags = Number(payload.bagCount || 0);
    const boxes = Number(payload.boxCount || 0);
    if (!Number.isInteger(bags) || bags < 0 || !Number.isInteger(boxes) || boxes < 0) {
        throw new Error('Некорректное количество мест в приходе.');
    }
    const liters = payload.storageVolumeLiters == null
        ? bags * DEFAULT_BAG_LITERS + boxes * DEFAULT_BOX_LITERS
        : Number(payload.storageVolumeLiters);
    if (!Number.isFinite(liters) || liters < 0) throw new Error('Объём хранения должен быть неотрицательным числом.');
    return round(liters);
}

function eligibleArrivals(rows, periodTo) {
    return rows.filter(row => row.payload && row.payload.status !== 'CANCELLED')
        .map(row => {
            const payload = row.payload;
            if (!dateKey(payload.arrivalDate)) throw new Error('В приходе не определена дата хранения.');
            if (payload.storageReconciledAt != null &&
                (!dateKey(payload.storageReconciledAt) || payload.storageReconciledAt < payload.arrivalDate)) {
                throw new Error('Некорректная дата фактической приёмки.');
            }
            return { id: row.id, warehouseId: payload.warehouseId, arrivalDate: payload.arrivalDate,
                reconciledAt: payload.storageReconciledAt || null, liters: arrivalVolume(payload),
                bagCount: Number(payload.bagCount || 0), boxCount: Number(payload.boxCount || 0),
                corrected: payload.storageVolumeLiters != null };
        }).filter(row => row.arrivalDate <= periodTo.toISOString().slice(0, 10));
}

function addArrivalStorage(details, arrivals, periodFrom, periodTo) {
    if (!arrivals.length) return details;
    const ledgerByDay = new Map(details.daily.map(row => [row.date, row]));
    const daily = [];
    const contributions = new Map();
    const end = periodTo.toISOString().slice(0, 10);
    for (let day = new Date(periodFrom.toISOString().slice(0, 10)); day.toISOString().slice(0, 10) <= end; day.setUTCDate(day.getUTCDate() + 1)) {
        const date = day.toISOString().slice(0, 10);
        const ledger = ledgerByDay.get(date) || { date, totalLiters: details.totalLiters || 0,
            literDays: details.totalLiters || 0, positions: details.balancesCount || 0 };
        const active = arrivals.filter(row => row.arrivalDate <= date && (!row.reconciledAt || date < row.reconciledAt) && row.liters > 0);
        const arrivalLiters = round(active.reduce((sum, row) => sum + row.liters, 0));
        for (const row of active) contributions.set(row.id, round((contributions.get(row.id) || 0) + row.liters));
        daily.push({ ...ledger, ledgerLiters: ledger.totalLiters, arrivalLiters,
            totalLiters: round(ledger.totalLiters + arrivalLiters),
            literDays: round(ledger.literDays + arrivalLiters), positions: ledger.positions + active.length });
    }
    const literDays = round(daily.reduce((sum, row) => sum + row.literDays, 0));
    const arrivalLiterDays = round([...contributions.values()].reduce((sum, value) => sum + value, 0));
    return { ...details, calculationMode: `${details.calculationMode}+ARRIVALS`, daily,
        days: daily.length, literDays, totalLiters: round(literDays / daily.length),
        balancesCount: details.balancesCount + contributions.size,
        arrivalStorage: { bagLiters: DEFAULT_BAG_LITERS, boxLiters: DEFAULT_BOX_LITERS,
            arrivalLiterDays, arrivals: arrivals.map(row => ({ ...row, literDays: contributions.get(row.id) || 0 })) } };
}

function correctionInput(dto, payload) {
    const liters = dto.storageVolumeLiters;
    if (liters !== null && (typeof liters !== 'number' || !Number.isFinite(liters) || liters < 0)) {
        throw new Error('Укажите фактический объём в литрах или null для стандартного объёма.');
    }
    const date = dto.storageReconciledAt;
    if (date !== null && (!dateKey(date) || date < payload.arrivalDate)) {
        throw new Error('Укажите дату завершения приёмки не ранее даты прихода или null.');
    }
    return { storageVolumeLiters: liters === null ? null : round(liters), storageReconciledAt: date,
        storageCorrectionComment: typeof dto.comment === 'string' ? dto.comment.trim() : null };
}

module.exports = { DEFAULT_BAG_LITERS, DEFAULT_BOX_LITERS, arrivalVolume, eligibleArrivals, addArrivalStorage, correctionInput };
