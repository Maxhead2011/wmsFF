"use strict";

function normalizedText(value) {
    return String(value || '').normalize('NFKC').toLocaleLowerCase('ru-RU').replace(/ё/g, 'е').replace(/\s+/g, ' ').trim();
}

function normalizeRuleMatchers(value) {
    if (value === undefined) return [];
    if (!Array.isArray(value) || value.length > 50) throw new Error('Разрешено до 50 правил обработки на клиента.');
    const names = new Set();
    return value.map(rule => {
        const name = typeof rule?.name === 'string' ? rule.name.trim() : '';
        if (!name || name.length > 120 || names.has(normalizedText(name))) throw new Error('Укажите разные названия правил длиной до 120 символов.');
        names.add(normalizedText(name));
        if (!['NAME', 'CATEGORY'].includes(rule.field)) throw new Error('Выберите поиск по названию или категории товара.');
        if (!Array.isArray(rule.keywords) || !rule.keywords.length || rule.keywords.length > 20) throw new Error('Укажите от 1 до 20 слов или фраз для правила.');
        const keywords = [...new Set(rule.keywords.map(word => {
            if (typeof word !== 'string' || !normalizedText(word) || word.trim().length > 120) throw new Error('Проверьте слова для поиска.');
            return normalizedText(word);
        }))];
        return { name, field: rule.field, keywords };
    });
}

function matchingRules(rules, product) {
    return rules.map((rule, index) => ({ rule, index })).filter(({ rule }) => {
        const text = normalizedText(rule.field === 'CATEGORY' ? product.category : product.name);
        return Boolean(text) && rule.keywords.some(keyword => text.includes(normalizedText(keyword)));
    });
}

function previewRules(definition, products) {
    const manual = new Set(definition.variants.flatMap(variant => variant.skuIds));
    const rows = (definition.rules || []).map(rule => ({ name: rule.name, count: 0, examples: [] }));
    let conflictCount = 0;
    let unmatchedCount = 0;
    let manualCount = 0;
    const conflicts = [];
    for (const product of products) {
        if (manual.has(product.id)) { manualCount++; continue; }
        const matches = matchingRules(definition.rules || [], product);
        if (!matches.length) unmatchedCount++;
        if (matches.length > 1) {
            conflictCount++;
            if (conflicts.length < 10) conflicts.push({ id: product.id, name: product.name, article: product.article,
                rules: matches.map(match => match.rule.name) });
        }
        for (const match of matches) {
            const row = rows[match.index];
            row.count++;
            if (row.examples.length < 5) row.examples.push({ id: product.id, name: product.name, article: product.article, size: product.size, category: product.category });
        }
    }
    return { total: products.length, manualCount, unmatchedCount, conflictCount, conflicts, rules: rows };
}

function combinedTariff(base, revision) {
    if (!revision) return base || null;
    return { ...(base || { id: revision.id, clientId: revision.clientId, createdAt: revision.createdAt }),
        definition: { ...(base?.definition || { common: [], variants: [] }), rules: revision.rules },
        definitionHash: `${base?.definitionHash || 'legacy'}:${revision.id}`,
        rulesRevisionId: revision.id,
    };
}

module.exports = { normalizedText, normalizeRuleMatchers, matchingRules, previewRules, combinedTariff };
