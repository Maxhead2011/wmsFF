"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BillingMergePeriodDto = void 0;
exports.billingMergePeriodWhere = billingMergePeriodWhere;
exports.invoiceWithinMergePeriod = invoiceWithinMergePeriod;
const class_validator_1 = require("class-validator");
const common_1 = require("@nestjs/common");
// FIX: optional dates preserve existing API callers. A supplied range needs both ends.
class BillingMergePeriodDto {
    periodFrom;
    periodTo;
}
exports.BillingMergePeriodDto = BillingMergePeriodDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], BillingMergePeriodDto.prototype, "periodFrom", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.Matches)(/^\d{4}-\d{2}-\d{2}$/),
    __metadata("design:type", String)
], BillingMergePeriodDto.prototype, "periodTo", void 0);
function billingMergePeriodWhere(period) {
    if (period.periodFrom === undefined && period.periodTo === undefined)
        return {};
    const { periodFrom, periodTo } = period;
    if (!periodFrom || !periodTo || !isDateKey(periodFrom) || !isDateKey(periodTo) || periodFrom > periodTo) {
        throw new common_1.BadRequestException('Укажите корректный период объединения — дату начала и окончания.');
    }
    // Invoice periods use UTC calendar dates, including a 23:59:59.999 end of day.
    return {
        periodFrom: { gte: new Date(`${periodFrom}T00:00:00.000Z`) },
        periodTo: { lte: new Date(`${periodTo}T23:59:59.999Z`) },
    };
}
function isDateKey(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value))
        return false;
    const date = new Date(`${value}T00:00:00.000Z`);
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function invoiceWithinMergePeriod(invoice, range) {
    return (!range.periodFrom || invoice.periodFrom >= range.periodFrom.gte) &&
        (!range.periodTo || invoice.periodTo <= range.periodTo.lte);
}
