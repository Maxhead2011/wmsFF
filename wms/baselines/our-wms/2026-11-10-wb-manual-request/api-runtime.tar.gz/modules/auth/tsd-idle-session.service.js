"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsdIdleSessionService = void 0;
const common_1 = require("@nestjs/common");
const crypto_1 = require("crypto");
const IDLE_MS = 15 * 60_000;
const denied = () => new common_1.UnauthorizedException({ code: 'TSD_SESSION_EXPIRED', message: 'Вход ТСД завершён. Войдите тем же сотрудником: неподтверждённые сканы сохранены.' });
// FIX: stable device tokens use a durable sliding deadline; background requests cannot extend it.
class TsdIdleSessionService {
    db;
    tokens;
    constructor(db, tokens) {
        this.db = db;
        this.tokens = tokens;
    }
    async start(login) {
        if (process.env.WMS_TSD_IDLE_SESSION_ENABLED !== 'true')
            return login;
        const accessToken = this.tokens.sign(login.user.id, { deviceId: login.device.id, deviceCode: login.device.code, tsdIdleSessionId: (0, crypto_1.randomUUID)() });
        await this.db.userSession.create({ data: { userId: login.user.id, accessTokenId: this.tokens.fingerprint(accessToken),
                appName: 'LOGOFF ТСД · 15 минут бездействия', lastSeenAt: new Date(), expiresAt: new Date(Date.now() + IDLE_MS) } });
        return { ...login, accessToken, idleTimeoutSeconds: 900 };
    }
    async assertActive(token, payload) {
        if (process.env.WMS_TSD_IDLE_SESSION_ENABLED !== 'true' || !payload.tsdIdleSessionId || !payload.deviceId || !payload.deviceCode)
            throw denied();
        const [session, device] = await Promise.all([
            this.db.userSession.findUnique({ where: { accessTokenId: this.tokens.fingerprint(token) } }),
            this.db.tsdDevice.findUnique({ where: { id: payload.deviceId }, select: { userId: true, status: true, code: true } }),
        ]);
        if (!session || session.userId !== payload.sub || !session.expiresAt || session.expiresAt.getTime() <= Date.now()
            || device?.status !== 'ACTIVE' || device.userId !== payload.sub || device.code !== payload.deviceCode)
            throw denied();
        return session;
    }
    async activity(token, body) {
        const age = body?.activityAgeMs;
        if (typeof age !== 'number' || !Number.isInteger(age) || age < 0 || age >= IDLE_MS)
            throw new common_1.BadRequestException('Некорректное время действия ТСД.');
        const payload = this.tokens.verify(token, true);
        await this.assertActive(token, payload);
        const now = new Date(), expiresAt = new Date(now.getTime() + IDLE_MS - age);
        // FIX: CAS cannot revive a concurrently expired/revoked session; late inputs cannot shorten it.
        const result = await this.db.userSession.updateMany({ where: { accessTokenId: this.tokens.fingerprint(token), userId: payload.sub,
                expiresAt: { gt: now, lt: expiresAt } }, data: { expiresAt, lastSeenAt: new Date(now.getTime() - age) } });
        if (!result.count) {
            const current = await this.assertActive(token, payload);
            if (current.expiresAt.getTime() < expiresAt.getTime())
                throw denied();
        }
        return { accepted: true, idleTimeoutSeconds: 900 };
    }
}
exports.TsdIdleSessionService = TsdIdleSessionService;
