export function createPhysicalPanel(React){const {useState,useEffect,useRef}=React;
 async function ozonAdjustment(token,id,action,body={}){const response=await fetch('/api/v1/tsd/requests/'+encodeURIComponent(id)+'/fbo/ozon-adjustment'+(action?'/'+action:''),{method:action?'POST':'GET',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},...(action?{body:JSON.stringify(body)}:{})});const data=await response.json();if(!response.ok)throw Error(Array.isArray(data.message)?data.message.join('; '):data.message??'HTTP '+response.status);return data;}
 const ozonSync=ozonAdjustment;
 const names = { NEEDS_ATTENTION: 'Корректировка требует внимания — есть отказ или неподтверждённый ответ Ozon', PENDING: 'Ожидает отправки', SENDING: 'Отправляется', ACCEPTED: 'Обрабатывается Ozon', SUCCESS: 'Подтверждено Ozon', FAILED: 'Отклонено Ozon', UNKNOWN: 'Ответ не подтверждён', RUNNING: 'Выполняется корректировка', APPLIED: 'План WMS и Ozon скорректирован', CANCELLED: 'Корректировка отменена' };
// FIX: show the exact per-destination reductions before the explicit external-write action.
function OzonStockAdjustment({ requestId, accessToken, disabled, onLockChange, onChanged, autoPreview = false }) {
    const [preview, setPreview] = useState(null), [quantities, setQuantities] = useState([]), [state, setState] = useState({ operation: null }), [busy, setBusy] = useState(false), [error, setError] = useState(''), [confirm, setConfirm] = useState(false);
    const running = !!state.operation && !['APPLIED', 'CANCELLED'].includes(state.operation.state);
    const [mode, setMode] = useState('AVAILABLE');
    const generation = useRef(0), inFlight = useRef(false);
    const [sync, setSync] = useState(null), [syncConfirmed, setSyncConfirmed] = useState(false), [notice, setNotice] = useState('');
    async function synchronize(apply = false) { if (inFlight.current || disabled || apply && (!sync || !syncConfirmed))
        return; inFlight.current = true; const gen = generation.current; setBusy(true); setError(''); setNotice(''); setPreview(null); try {
        const result = await ozonSync(accessToken, requestId, apply ? 'sync-apply' : 'sync-preview', apply ? { token: sync?.token, confirm: true } : {});
        if (gen !== generation.current)
            return;
        setSyncConfirmed(false);
        if (apply) {
            setSync(null);
            setNotice('Состав ВМС обновлён из Ozon.');
            onChanged();
        }
        else
            setSync(result);
    }
    catch (e) {
        if (gen === generation.current) {
            setError(e instanceof Error ? e.message : String(e));
            setSync(null);
            setSyncConfirmed(false);
        }
    }
    finally {
        if (gen === generation.current) {
            setBusy(false);
            inFlight.current = false;
        }
    } }
    useEffect(() => { onLockChange(running); }, [running, onLockChange]);
    // FIX: import correction opens a fresh read-only assessment; it never auto-submits to Ozon.
    useEffect(() => { const gen = ++generation.current; setPreview(null); setSync(null); setConfirm(false); setSyncConfirmed(false); setError(''); setMode('AVAILABLE'); setState({ operation: null }); setBusy(true); inFlight.current = true; void (async () => { try {
        const s = await ozonAdjustment(accessToken, requestId, '');
        if (gen !== generation.current)
            return;
        setState(s);
        if (autoPreview && (!s.operation || ['APPLIED', 'CANCELLED'].includes(s.operation.state))) {
            const p = await ozonAdjustment(accessToken, requestId, 'preview', { mode: 'AVAILABLE' });
            if (gen === generation.current) {
                setPreview(p);
                setQuantities(p.rows.map(r => r.after));
            }
        }
    }
    catch (e) {
        if (gen === generation.current)
            setError(e instanceof Error ? e.message : String(e));
    }
    finally {
        if (gen === generation.current) {
            setBusy(false);
            inFlight.current = false;
        }
    } })(); return () => { generation.current++; }; }, [requestId, accessToken, autoPreview]);
    async function run(action, nextMode = mode) { if (inFlight.current || disabled || action === 'start' && (!preview || !confirm))
        return; inFlight.current = true; const gen = generation.current; setBusy(true); setError(''); setSync(null); setNotice(''); if (action === 'preview') {
        setPreview(null);
        setConfirm(false);
        setMode(nextMode);
    } try {
        const result = await ozonAdjustment(accessToken, requestId, action, action === 'start' ? { token: preview?.token, quantities, confirm: true, mode } : action === 'preview' ? { mode: nextMode } : {});
        if (gen !== generation.current)
            return;
        if (action === 'preview') {
            setPreview(result);
            setQuantities(result.rows.map(r => r.after));
            setConfirm(false);
        }
        else {
            setState(result);
            setPreview(null);
            if (result.operation?.state === 'APPLIED')
                onChanged();
        }
    }
    catch (e) {
        if (gen !== generation.current)
            return;
        setError(e instanceof Error ? e.message : String(e));
        setPreview(null);
        setConfirm(false);
        try {
            const s = await ozonAdjustment(accessToken, requestId, '');
            if (gen === generation.current)
                setState(s);
        }
        catch { }
    }
    finally {
        if (gen === generation.current) {
            setBusy(false);
            inFlight.current = false;
        }
    } }
    return React.createElement("section", { className: "ozon-adjustment", "aria-label": "\u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u043E\u0441\u0442\u0430\u0442\u043A\u043E\u0432 Ozon", "aria-busy": busy },
        !running && React.createElement("div", { className: "ozon-adjustment__toolbar" },
            React.createElement("button", { className: "ozon-adjustment__primary", type: "button", disabled: busy || disabled, onClick: () => void run('preview', 'AVAILABLE') }, "\u0421\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C Ozon \u043F\u043E \u0444\u0430\u043A\u0442\u0443"),
            React.createElement("button", { type: "button", disabled: busy || disabled, onClick: () => void synchronize() }, "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u043E\u0441\u0442\u0430\u0432 \u0438\u0437 Ozon")),
        busy && React.createElement("p", { role: "status" }, "\u0421\u0432\u0435\u0440\u044F\u044E \u0441\u043E\u0441\u0442\u0430\u0432 \u0438 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\u2026"),
        notice && React.createElement("p", { role: "status" }, notice),
        sync && !running && React.createElement("div", { className: "ozon-adjustment__preview" },
            React.createElement("h3", null, "Ozon \u2192 \u0412\u041C\u0421"),
            React.createElement("p", null,
                "\u0421\u043E\u0441\u0442\u0430\u0432 \u0438\u0437 Ozon: \u0431\u044B\u043B\u043E ",
                sync.needed,
                " \u0448\u0442. \u2192 \u0431\u0443\u0434\u0435\u0442 ",
                sync.after,
                " \u0448\u0442. \u041E\u0442\u0431\u043E\u0440 \u0438 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F."),
            React.createElement("div", { className: "ozon-adjustment__table" },
                React.createElement("table", null,
                    React.createElement("thead", null,
                        React.createElement("tr", null,
                            React.createElement("th", null, "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 / \u0442\u043E\u0432\u0430\u0440 / \u0428\u041A"),
                            React.createElement("th", null, "\u0412 \u0437\u0430\u044F\u0432\u043A\u0435"),
                            React.createElement("th", null, "\u0412 Ozon"),
                            React.createElement("th", null, "\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E"))),
                    React.createElement("tbody", null, sync.rows.map(r => React.createElement("tr", { key: `${r.direction}:${r.skuId}` },
                        React.createElement("td", null,
                            r.direction,
                            React.createElement("br", null),
                            r.name,
                            React.createElement("br", null),
                            r.barcode),
                        React.createElement("td", null, r.before),
                        React.createElement("td", null, r.after),
                        React.createElement("td", null, r.packed)))))),
            React.createElement("label", { className: "ozon-adjustment__confirm" },
                React.createElement("input", { type: "checkbox", checked: syncConfirmed, disabled: busy || disabled, onChange: e => setSyncConfirmed(e.target.checked) }),
                "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u0437\u0430\u044F\u0432\u043A\u0438 \u043F\u043E \u0441\u043E\u0441\u0442\u0430\u0432\u0443 Ozon"),
            React.createElement("button", { type: "button", disabled: busy || disabled || !syncConfirmed, onClick: () => void synchronize(true) }, "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443 \u0438\u0437 Ozon"),
            React.createElement("button", { type: "button", disabled: busy, onClick: () => setSync(null) }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440")),
        error && React.createElement("p", { role: "alert", className: "ozon-adjustment__error" }, error),
        state.operation && React.createElement("div", { role: "status", className: "ozon-adjustment__preview" },
            React.createElement("strong", null, names[state.operation.state] ?? state.operation.state),
            state.operation.operations.map(o => React.createElement("p", { key: o.supplyId },
                o.direction ? `${o.direction} · ` : "",
                "\u041F\u043E\u0441\u0442\u0430\u0432\u043A\u0430 ",
                o.supplyId,
                ": ",
                names[o.state] ?? o.state,
                o.error ? ` · ${o.error}` : '')),
            running && React.createElement(React.Fragment, null,
                React.createElement("p", null, "\u0421\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0430 \u0433\u0440\u0443\u0437\u043E\u043C\u0435\u0441\u0442 \u043F\u0440\u0438\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u044B \u0434\u043E \u0441\u0432\u0435\u0440\u043A\u0438. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0435 \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F."),
                React.createElement("button", { type: "button", disabled: busy || disabled, onClick: () => void run('resume') }, "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 / \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C"),
                state.operation.operations.every(o => ['FAILED', 'PENDING'].includes(o.state)) && React.createElement("button", { type: "button", disabled: busy || disabled, onClick: () => void run('cancel') }, "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0442\u043A\u043B\u043E\u043D\u0451\u043D\u043D\u0443\u044E \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0443"))),
        preview && !running && React.createElement("div", { className: "ozon-adjustment__preview" },
            React.createElement("h3", null, "\u0412\u041C\u0421 \u2192 Ozon"),
            React.createElement("div", { className: "ozon-adjustment__toolbar", "aria-label": "\u041E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0438" }, preview.physicalBasis === 'PACKED' ? React.createElement("strong", null, "\u041F\u043E \u0443\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u043C\u0443 \u0441\u043E\u0441\u0442\u0430\u0432\u0443 \u043A\u043E\u0440\u043E\u0431\u043E\u0432") : React.createElement(React.Fragment, null,
                React.createElement("button", { type: "button", "aria-pressed": mode === 'AVAILABLE', disabled: busy || disabled, onClick: () => void run('preview', 'AVAILABLE') }, "\u041F\u043E \u043D\u0430\u043B\u0438\u0447\u0438\u044E"),
                React.createElement("button", { type: "button", "aria-pressed": mode === 'PICKED', disabled: busy || disabled, onClick: () => void run('preview', 'PICKED') }, "\u041F\u043E \u043E\u0442\u043E\u0431\u0440\u0430\u043D\u043D\u043E\u043C\u0443"))),
            React.createElement("p", null,
                "\u0412 \u0437\u0430\u044F\u0432\u043A\u0435 ",
                preview.needed,
                " \u0448\u0442. \u2192 \u0431\u0443\u0434\u0435\u0442 ",
                preview.after,
                " \u0448\u0442. ",
                preview.physicalBasis === 'AVAILABLE' ? 'Учтены отобранные товары и свободный остаток за вычетом чужих резервов.' : preview.physicalBasis === 'PACKED' ? 'Учтён подтверждённый в ВМС состав упаковки.' : 'Учтены только фактически отобранные единицы.',
                " \u041A\u043E\u0440\u043E\u0431\u0430, \u0441\u043A\u0430\u043D\u044B \u0438 \u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u044E\u0442\u0441\u044F."),
            React.createElement("div", { className: "ozon-adjustment__table" },
                React.createElement("table", null,
                    React.createElement("thead", null,
                        React.createElement("tr", null,
                            React.createElement("th", null, "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435 / \u0442\u043E\u0432\u0430\u0440 / \u0428\u041A"),
                            React.createElement("th", null, "\u0412 \u0412\u041C\u0421"),
                            React.createElement("th", null, "\u0412 Ozon"),
                            React.createElement("th", null, "\u0423\u043F\u0430\u043A\u043E\u0432\u0430\u043D\u043E"),
                            React.createElement("th", null, "\u0411\u0443\u0434\u0435\u0442"))),
                    React.createElement("tbody", null, (preview.comparison ?? preview.rows.map(r => ({ ...r, remote: r.before }))).map(r => { const i = preview.rows.findIndex(v => v.direction === r.direction && v.barcode === r.barcode), row = preview.rows[i]; return React.createElement("tr", { key: `${r.direction}:${r.barcode}` },
                        React.createElement("td", null,
                            r.direction,
                            React.createElement("br", null),
                            preview.lines.find(l => l.skuId === row?.skuId)?.name,
                            React.createElement("br", null),
                            r.barcode),
                        React.createElement("td", null, r.before),
                        React.createElement("td", null, r.remote),
                        React.createElement("td", null, row?.packed ?? 0),
                        React.createElement("td", null, row ? React.createElement("input", { "aria-label": `Количество ${r.direction} ${r.barcode}`, type: "number", min: row.packed, max: row.before, step: 1, value: quantities[i], disabled: busy || disabled || preview.physicalBasis === 'PACKED', onChange: e => { const next = [...quantities]; next[i] = Number(e.target.value); setQuantities(next); setConfirm(false); } }) : 0)); })))),
            (preview.changes ?? preview.after < preview.needed) ? React.createElement(React.Fragment, null,
                React.createElement("p", null, preview.physicalBasis === 'PACKED' ? 'Состав будет передан точно по упакованным единицам каждого направления.' : 'Распределение между направлениями можно изменить, сохранив итог каждого товара. Уже упакованное количество не уменьшается.'),
                React.createElement("label", { className: "ozon-adjustment__confirm" },
                    React.createElement("input", { type: "checkbox", checked: confirm, disabled: busy || disabled, onChange: e => setConfirm(e.target.checked) }),
                    "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0430\u044E \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u044B\u0439 \u0441\u043E\u0441\u0442\u0430\u0432 \u0432 \u0412\u041C\u0421 \u0438 Ozon"),
                React.createElement("button", { className: "ozon-adjustment__primary", type: "button", disabled: busy || disabled || !confirm, onClick: () => void run('start') }, "\u041F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u044C \u0432 \u0412\u041C\u0421 \u0438 Ozon")) : React.createElement("p", null, "\u0421\u043E\u0441\u0442\u0430\u0432 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442. \u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u043D\u0435 \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044F."),
            React.createElement("button", { type: "button", disabled: busy, onClick: () => setPreview(null) }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440")));
}

 return OzonStockAdjustment;}