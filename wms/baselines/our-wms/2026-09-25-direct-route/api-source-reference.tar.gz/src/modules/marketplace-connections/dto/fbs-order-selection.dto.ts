import { Type } from 'class-transformer';
import { FbsDeliveryDestination } from '@prisma/client';
import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsEnum,
  IsISO8601,
  Matches,
  IsOptional,
  IsString,
  Length,
  ValidateNested,
} from 'class-validator';

export class FbsOrderSelectionItemDto {
  @IsString()
  @Length(1, 100)
  connectionId!: string;

  @IsString()
  @Length(1, 100)
  id!: string;

  // Older/open browser sessions can submit the richer order preview object.
  // These display-only properties are deliberately ignored by the service,
  // but accepting their validated shape keeps actions compatible during rollout.
  @IsOptional()
  @IsString()
  @Length(1, 100)
  assemblyId?: string | null;

  @IsOptional()
  @IsBoolean()
  requiresKiz?: boolean;

  @IsOptional()
  @IsBoolean()
  kizAccepted?: boolean;
}

export class FbsOrderSelectionDto {
  @IsString()
  @Length(1, 100)
  clientId!: string;

  @IsArray()
  @ArrayMinSize(1)
  // A manager may select several large WMS requests at once. Marketplace
  // operations split the selection into WB-safe chunks inside the service,
  // so the transport DTO must not reject the combined selection at 1,000.
  @ArrayMaxSize(5000)
  @ValidateNested({ each: true })
  @Type(() => FbsOrderSelectionItemDto)
  orders!: FbsOrderSelectionItemDto[];

  @IsOptional()
  @IsEnum(FbsDeliveryDestination)
  deliveryDestination?: FbsDeliveryDestination;

  // ADDED: WB derives the destination from the orders, but WMS requires the
  // operator to confirm it explicitly before the irreversible delivery call.
  @IsOptional()
  @IsString()
  @Matches(/^\d+$/)
  @Length(1, 20)
  destinationOfficeId?: string;

  // ADDED: the public WB FBS API does not accept a delivery date; WMS stores
  // the operator's logistics plan and includes it in the delivery audit.
  @IsOptional()
  @IsISO8601({ strict: true })
  plannedDeliveryDate?: string;

  @IsOptional()
  @IsString()
  @Length(1, 260)
  marketplaceWarehouseKey?: string;

  @IsOptional()
  @IsString()
  @Length(1, 100)
  targetSupplyId?: string;

  // ADDED: protects online-request recovery from replaying a completed move.
  @IsOptional()
  @IsString()
  @Length(1, 100)
  sourceRequestId?: string;
}
