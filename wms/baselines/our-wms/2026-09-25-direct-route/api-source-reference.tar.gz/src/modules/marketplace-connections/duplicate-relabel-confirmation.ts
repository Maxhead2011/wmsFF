import { createHash } from 'node:crypto';
import type { DuplicateGroup } from './duplicate-stock-groups';
type Pair = { sourceArticle: string; targetArticle: string };
const norm = (value: string) => value.trim().toLowerCase();
export function relabelConfirmation(clientId: string, group: DuplicateGroup, pairs: Pair[], mappings: Pair[]) {
  const unique = [...new Map(pairs.map(p => [norm(p.sourceArticle) + ':' + norm(p.targetArticle), p])).values()];
  const conflicts = unique.flatMap(pair => {
    const existing = mappings.filter(m =>
      (norm(m.targetArticle) === norm(pair.targetArticle) && norm(m.sourceArticle) !== norm(pair.sourceArticle))
      || norm(m.targetArticle) === norm(pair.sourceArticle) || norm(m.sourceArticle) === norm(pair.targetArticle));
    return existing.length ? [{ ...pair, existing }] : [];
  });
  const snapshot = mappings.map(m => [norm(m.sourceArticle), norm(m.targetArticle)]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
  const confirmationKey = conflicts.length ? createHash('sha256').update(JSON.stringify({ clientId, group, snapshot })).digest('hex') : null;
  return { confirmationKey, conflicts };
}
