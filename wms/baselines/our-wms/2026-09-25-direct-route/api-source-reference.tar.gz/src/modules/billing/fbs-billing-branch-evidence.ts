import { createHash } from 'node:crypto';

type Source = { clientId: string; sourceKey?: string | null; serviceDate: Date; metadata?: unknown };
type Evidence = { version: 1; source: 'WB_ORDER_WAREHOUSE_ROUTING'; fingerprint: string;
  warehouseIds: string[]; excludedOrders: number; totalOrders: number; auditId: string };
const obj = (v: unknown): Record<string, unknown> => v && typeof v === 'object' && !Array.isArray(v) ? v as Record<string, unknown> : {};

// Bound to the actual order set, client, connection, shipment and service date.
// Prices deliberately do not establish a warehouse and are never changed here.
export function fbsBranchSourceFingerprint(source: Source): string | null {
  const meta = obj(source.metadata);
  if (meta.kind !== 'FBS' || meta.marketplace !== 'WILDBERRIES' ||
      typeof meta.connectionId !== 'string' || !meta.connectionId ||
      !Array.isArray(meta.orderIds) || !meta.orderIds.length ||
      meta.orderIds.some(id => typeof id !== 'string' || !id)) return null;
  const orderIds = [...meta.orderIds].sort();
  if (new Set(orderIds).size !== orderIds.length) return null;
  return createHash('sha256').update(JSON.stringify({ clientId: source.clientId,
    sourceKey: source.sourceKey ?? null, serviceDate: source.serviceDate.toISOString(),
    marketplace: meta.marketplace, connectionId: meta.connectionId,
    supplyId: meta.supplyId ?? null, orderIds })).digest('hex');
}

export function readFbsBranchEvidence(source: Source): Evidence | null {
  const evidence = obj(obj(source.metadata).billingBranchEvidence);
  const fingerprint = fbsBranchSourceFingerprint(source);
  if (!fingerprint || evidence.version !== 1 || evidence.source !== 'WB_ORDER_WAREHOUSE_ROUTING' ||
      evidence.fingerprint !== fingerprint || typeof evidence.auditId !== 'string' || !evidence.auditId ||
      !Array.isArray(evidence.warehouseIds) || evidence.warehouseIds.some(id => typeof id !== 'string' || !id) ||
      new Set(evidence.warehouseIds).size !== evidence.warehouseIds.length ||
      !Number.isInteger(evidence.totalOrders) || evidence.totalOrders !== (obj(source.metadata).orderIds as string[]).length ||
      !Number.isInteger(evidence.excludedOrders) || Number(evidence.excludedOrders) < 0 ||
      Number(evidence.excludedOrders) > Number(evidence.totalOrders) ||
      (evidence.warehouseIds.length === 0) !== (evidence.excludedOrders === evidence.totalOrders)) return null;
  return evidence as Evidence;
}

// The ordinary FBS refresh replaces metadata. Retain only a still-matching,
// audited source classification; new/moved orders must be verified again.
export function retainFbsBranchEvidence<T>(source: Source & { metadata: T }, previous?: Source | null): T {
  if (!previous) return source.metadata;
  const evidence = readFbsBranchEvidence(previous);
  if (!evidence || evidence.fingerprint !== fbsBranchSourceFingerprint(source)) return source.metadata;
  return { ...obj(source.metadata), billingBranchEvidence: evidence } as T;
}
