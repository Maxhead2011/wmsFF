import { IsOptional, IsUUID } from 'class-validator';
import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import type { AuthUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import {
  CompleteInventoryDto,
  CountInventoryItemDto,
  InventoryDecisionDto,
  OpenInventoryBoxDto,
  ResolveInventoryBoxDto,
  SetInventoryCountDto,
  StartInventoryDto,
} from './dto/inventory.dto';
import { InventoryService } from './inventory.service';
import { CreateSkuCollectionDto, SearchSkuCollectionDto } from './dto/sku-collection.dto';
import { SkuCollectionService } from './sku-collection.service';
import { SkuSortingService } from './sku-sorting.service';

class OpenedCheckDto {
  @IsOptional() @IsUUID() auditBoxId?: string;
  @IsUUID() openingId!: string;
}

@ApiTags('inventory')
@RequirePermissions('stock:read')
@Controller('inventory')
export class InventoryController {
  constructor(
    private readonly inventory: InventoryService,
    private readonly skuCollections: SkuCollectionService,
    private readonly skuSorting: SkuSortingService,
  ) {}

  @Get('sku-collections/capabilities')
  @RequirePermissions('stock:write')
  skuCollectionCapabilities(@CurrentUser() user: AuthUser) {
    return this.skuSorting.cancelCapabilities(user);
  }

  // FIX: dedicated cancellation preserves collection evidence and releases only its own reserves.
  @Post('sku-collections/:id/cancel')
  @RequirePermissions('stock:write')
  cancelSkuCollection(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.skuSorting.cancel(id, user);
  }

  @Get('sku-collections/search')
  searchSkuCollection(@Query() dto: SearchSkuCollectionDto, @CurrentUser() user: AuthUser) {
    return this.skuCollections.search(dto.clientId, dto.search, user);
  }

  @Post('sku-collections')
  @RequirePermissions('stock:write')
  createSkuCollection(@Body() dto: CreateSkuCollectionDto, @CurrentUser() user: AuthUser) {
    return this.skuCollections.create(dto, user);
  }

  @Get('dashboard')
  dashboard(@Query('workOnly') workOnly: string | undefined, @CurrentUser() user: AuthUser) {
    return this.inventory.dashboard(user, workOnly === 'true');
  }

  @Get('sessions')
  list(@Query('type') type: string | undefined, @CurrentUser() user: AuthUser) {
    return this.inventory.listSessions(type, user);
  }

  @Get('sessions/:id')
  get(
    @Param('id') id: string,
    @Query('workOnly') workOnly: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.inventory.getSession(id, user, workOnly === 'true');
  }

  @Post('sessions')
  @RequirePermissions('stock:write')
  start(@Body() dto: StartInventoryDto, @CurrentUser() user: AuthUser) {
    return this.inventory.startSession(dto, user);
  }

  // FIX: deliberate opening is distinct from background inventory GET requests.
  @Post('sessions/:id/opened')
  opened(@Param('id') id: string, @Body() dto: OpenedCheckDto, @CurrentUser() user: AuthUser) {
    return this.inventory.recordViewed(id, dto.auditBoxId, dto.openingId, user);
  }

  @Post('sessions/:id/boxes/open')
  @RequirePermissions('stock:write')
  openBox(@Param('id') id: string, @Body() dto: OpenInventoryBoxDto, @CurrentUser() user: AuthUser) {
    return this.inventory.openBox(id, dto.boxCode, user);
  }

  @Post('boxes/:id/scan')
  @RequirePermissions('stock:write')
  scan(@Param('id') id: string, @Body() dto: CountInventoryItemDto, @CurrentUser() user: AuthUser) {
    return this.inventory.scanItem(id, dto, user);
  }

  @Patch('boxes/:id/count')
  @RequirePermissions('stock:write')
  setCount(@Param('id') id: string, @Body() dto: SetInventoryCountDto, @CurrentUser() user: AuthUser) {
    return this.inventory.setCount(id, dto, user);
  }

  @Post('boxes/:id/finish')
  @RequirePermissions('stock:write')
  finishBox(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.inventory.finishBox(id, user);
  }

  @Post('rescan-requests/:id/approve')
  @RequirePermissions('stock:write')
  approveRescan(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.inventory.approveRescanRequest(id, user);
  }

  @Post('sessions/:id/review')
  @RequirePermissions('stock:write')
  review(@Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.inventory.sendToReview(id, user);
  }

  @Patch('lines/:id/decision')
  @RequirePermissions('stock:write')
  decide(@Param('id') id: string, @Body() dto: InventoryDecisionDto, @CurrentUser() user: AuthUser) {
    return this.inventory.decideLine(id, dto, user);
  }

  @Post('boxes/:id/resolve')
  @RequirePermissions('stock:write')
  resolveBox(@Param('id') id: string, @Body() dto: ResolveInventoryBoxDto, @CurrentUser() user: AuthUser) {
    return this.inventory.resolveBox(id, dto, user);
  }

  @Post('sessions/:id/complete')
  @RequirePermissions('stock:write')
  complete(@Param('id') id: string, @Body() dto: CompleteInventoryDto, @CurrentUser() user: AuthUser) {
    return this.inventory.completeSession(id, dto.comment, user);
  }

  @Post('sessions/:id/cancel')
  @RequirePermissions('stock:write')
  cancel(@Param('id') id: string, @Body() dto: CompleteInventoryDto, @CurrentUser() user: AuthUser) {
    return this.inventory.cancelSession(id, dto.comment, user);
  }
}
