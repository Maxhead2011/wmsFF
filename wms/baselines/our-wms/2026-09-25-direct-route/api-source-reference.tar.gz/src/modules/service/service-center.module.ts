import { Module } from '@nestjs/common';
import { ClientNotificationsModule } from '../client-notifications/client-notifications.module';
import { ServiceCenterController } from './service-center.controller';
import { ServiceCenterService } from './service-center.service';
import { StorageOptimizationService } from './storage-optimization.service';
import { UnprintedKizController } from './unprinted-kiz.controller';
import { UnprintedKizService } from './unprinted-kiz.service';
import { AuthModule } from '../auth/auth.module';
import { WbPrintCheckService } from './wb-print-check.service';

@Module({
  imports: [ClientNotificationsModule, AuthModule],
  controllers: [ServiceCenterController, UnprintedKizController],
  providers: [ServiceCenterService, StorageOptimizationService, WbPrintCheckService, UnprintedKizService],
})
export class ServiceCenterModule {}
