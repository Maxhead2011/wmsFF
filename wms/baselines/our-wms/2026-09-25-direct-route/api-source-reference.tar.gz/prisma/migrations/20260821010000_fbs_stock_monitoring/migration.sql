-- ADDED: audit-safe WB/WMS stock monitoring. These tables observe existing
-- order and balance flows and do not mutate StockBalance or WB publications.
CREATE TABLE "FbsStockMonitorConfig" (
    "id" TEXT NOT NULL,
    "clientId" TEXT NOT NULL,
    "connectionId" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "allowedDelaySeconds" INTEGER NOT NULL DEFAULT 300,
    "retryIntervalSeconds" INTEGER NOT NULL DEFAULT 30,
    "maxAttempts" INTEGER NOT NULL DEFAULT 10,
    "wbRule" TEXT NOT NULL DEFAULT 'ORDER_AND_STOCK_DELTA',
    "wmsRule" TEXT NOT NULL DEFAULT 'ORDER_RESERVATION_OR_SELLABLE_DELTA',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "FbsStockMonitorConfig_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "FbsStockMonitorEvent" (
    "id" TEXT NOT NULL,
    "eventKey" TEXT NOT NULL,
    "clientId" TEXT NOT NULL,
    "connectionId" TEXT NOT NULL,
    "marketplace" "MarketplaceType" NOT NULL DEFAULT 'WILDBERRIES',
    "marketplaceWarehouseId" TEXT,
    "marketplaceWarehouseName" TEXT,
    "executionWarehouseId" TEXT,
    "orderId" TEXT NOT NULL,
    "orderUid" TEXT,
    "eventType" TEXT NOT NULL DEFAULT 'SALE',
    "sourceFingerprint" TEXT,
    "sourceIds" JSONB,
    "skuId" TEXT NOT NULL,
    "productName" TEXT NOT NULL,
    "article" TEXT,
    "nmId" TEXT,
    "chrtId" INTEGER,
    "barcode" TEXT,
    "size" TEXT,
    "color" TEXT,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "saleAt" TIMESTAMP(3) NOT NULL,
    "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deadlineAt" TIMESTAMP(3) NOT NULL,
    "wbBeforeAmount" INTEGER,
    "wbExpectedAfterAmount" INTEGER,
    "wbAfterAmount" INTEGER,
    "wbCurrentAmount" INTEGER,
    "wbStatus" TEXT NOT NULL DEFAULT 'PENDING',
    "wbAttempts" INTEGER NOT NULL DEFAULT 0,
    "wbMessage" TEXT,
    "wmsBeforeAmount" INTEGER,
    "wmsExpectedAfterAmount" INTEGER,
    "wmsAfterAmount" INTEGER,
    "wmsCurrentAmount" INTEGER,
    "wmsReservedAmount" INTEGER,
    "wmsStatus" TEXT NOT NULL DEFAULT 'PENDING',
    "wmsAttempts" INTEGER NOT NULL DEFAULT 0,
    "wmsMessage" TEXT,
    "overallStatus" TEXT NOT NULL DEFAULT 'PENDING',
    "statusRank" INTEGER NOT NULL DEFAULT 1,
    "nextCheckAt" TIMESTAMP(3),
    "lastCheckedAt" TIMESTAMP(3),
    "processingAt" TIMESTAMP(3),
    "processingBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "FbsStockMonitorEvent_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "FbsStockMonitorHistory" (
    "id" TEXT NOT NULL,
    "eventId" TEXT NOT NULL,
    "system" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "attempt" INTEGER NOT NULL DEFAULT 0,
    "beforeAmount" INTEGER,
    "expectedAmount" INTEGER,
    "currentAmount" INTEGER,
    "reservedAmount" INTEGER,
    "message" TEXT,
    "sourceIds" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "FbsStockMonitorHistory_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "FbsStockMonitorRun" (
    "id" TEXT NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),
    "durationMs" INTEGER,
    "ingested" INTEGER NOT NULL DEFAULT 0,
    "checked" INTEGER NOT NULL DEFAULT 0,
    "succeeded" INTEGER NOT NULL DEFAULT 0,
    "pending" INTEGER NOT NULL DEFAULT 0,
    "failed" INTEGER NOT NULL DEFAULT 0,
    "unavailable" INTEGER NOT NULL DEFAULT 0,
    "wbErrors" INTEGER NOT NULL DEFAULT 0,
    "wmsErrors" INTEGER NOT NULL DEFAULT 0,
    "errorMessage" TEXT,
    CONSTRAINT "FbsStockMonitorRun_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "FbsStockMonitorConfig_connectionId_key" ON "FbsStockMonitorConfig"("connectionId");
CREATE INDEX "FbsStockMonitorConfig_clientId_enabled_idx" ON "FbsStockMonitorConfig"("clientId", "enabled");
CREATE UNIQUE INDEX "FbsStockMonitorEvent_eventKey_key" ON "FbsStockMonitorEvent"("eventKey");
CREATE INDEX "FbsStockMonitorEvent_clientId_saleAt_idx" ON "FbsStockMonitorEvent"("clientId", "saleAt");
CREATE INDEX "FbsStockMonitorEvent_connectionId_marketplaceWarehouseId_skuId_saleAt_idx" ON "FbsStockMonitorEvent"("connectionId", "marketplaceWarehouseId", "skuId", "saleAt");
CREATE INDEX "FbsStockMonitorEvent_overallStatus_nextCheckAt_idx" ON "FbsStockMonitorEvent"("overallStatus", "nextCheckAt");
CREATE INDEX "FbsStockMonitorEvent_statusRank_saleAt_idx" ON "FbsStockMonitorEvent"("statusRank", "saleAt");
CREATE INDEX "FbsStockMonitorEvent_wbStatus_nextCheckAt_idx" ON "FbsStockMonitorEvent"("wbStatus", "nextCheckAt");
CREATE INDEX "FbsStockMonitorEvent_wmsStatus_nextCheckAt_idx" ON "FbsStockMonitorEvent"("wmsStatus", "nextCheckAt");
CREATE INDEX "FbsStockMonitorEvent_orderId_idx" ON "FbsStockMonitorEvent"("orderId");
CREATE INDEX "FbsStockMonitorHistory_eventId_createdAt_idx" ON "FbsStockMonitorHistory"("eventId", "createdAt");
CREATE INDEX "FbsStockMonitorHistory_system_status_createdAt_idx" ON "FbsStockMonitorHistory"("system", "status", "createdAt");
CREATE INDEX "FbsStockMonitorRun_startedAt_idx" ON "FbsStockMonitorRun"("startedAt");
CREATE INDEX "FbsStockMonitorRun_completedAt_idx" ON "FbsStockMonitorRun"("completedAt");

ALTER TABLE "FbsStockMonitorHistory" ADD CONSTRAINT "FbsStockMonitorHistory_eventId_fkey"
  FOREIGN KEY ("eventId") REFERENCES "FbsStockMonitorEvent"("id") ON DELETE CASCADE ON UPDATE CASCADE;
