-- ADDED: make every manual WB stock repair durable and idempotent without
-- changing existing monitoring history rows.
ALTER TABLE "FbsStockMonitorHistory"
ADD COLUMN "idempotencyKey" TEXT;

CREATE UNIQUE INDEX "FbsStockMonitorHistory_idempotencyKey_key"
ON "FbsStockMonitorHistory"("idempotencyKey");
