import {r as React} from "./admin-tiles-20261019-0.js";
const { useEffect, useRef, useState } = React;
// FIX: downloading the actual composition is read-only and isolated from assembly/status mutations.
export function FbyActualExportButton({ token, accountId, requestId, number, status }) {
    const [busy, setBusy] = useState(false), [error, setError] = useState('');
    const controller = useRef(null);
    useEffect(() => { controller.current = null; setBusy(false); setError(''); return () => { controller.current?.abort(); }; }, [token, accountId, requestId]);
    async function download() {
        if (controller.current)
            return;
        const current = new AbortController();
        controller.current = current;
        setBusy(true);
        setError('');
        try {
            const response = await fetch(`${import.meta.env?.VITE_API_URL ?? '/api/v1'}/yandex-fby/accounts/${encodeURIComponent(accountId)}/requests/${encodeURIComponent(requestId)}/export`, { headers: { Authorization: `Bearer ${token}` }, signal: current.signal });
            if (!response.ok) {
                let message = 'Не удалось скачать файл для Яндекса.';
                try {
                    const data = await response.json();
                    if (typeof data.message === 'string')
                        message = data.message;
                }
                catch { }
                throw new Error(message);
            }
            const blob = await response.blob();
            if (current.signal.aborted)
                return;
            const url = URL.createObjectURL(blob), a = document.createElement('a');
            a.href = url;
            a.download = `Yandex-FBY-${String(number).replace(/[^0-9]/g, '')}.xlsx`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        }
        catch (e) {
            if (!current.signal.aborted)
                setError(e instanceof Error ? e.message : 'Не удалось скачать файл.');
        }
        finally {
            if (controller.current === current) {
                controller.current = null;
                if (!current.signal.aborted)
                    setBusy(false);
            }
        }
    }
    return React.createElement("span", null,
        React.createElement("button", { type: "button", className: "icon-text-button", disabled: busy || !['PACKED', 'DONE'].includes(status), onClick: () => void download(), title: "\u041F\u043E\u0441\u043B\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0438 \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043A\u043E\u0440\u043E\u0431\u043E\u0432" }, busy ? 'Готовлю файл…' : 'Скачать для Яндекса'),
        error && React.createElement("span", { role: "alert", className: "error-message" }, error));
}
