import { r as t } from "/assets/storage-volume-root-20261109.js";
const i = (...n) => t.useState(...n), M = (...n) => t.useEffect(...n), te = (...n) => t.useRef(...n), ge = (...n) => t.useMemo(...n), ve = (...n) => t.useCallback(...n), he = "/api/v1";
async function Ce(n, l = {}) {
  return S(
    ye("/clients", {
      includeArchived: l.includeArchived ? "true" : void 0,
      marketplaceDirectory: l.marketplaceDirectory ? "true" : void 0,
      allBranches: l.allBranches ? "1" : void 0,
      displayWarehouseId: l.displayWarehouseId || void 0
    }),
    {
      accessToken: n
    }
  );
}
async function S(n, l = {}) {
  const c = await fetch(`${he}${n}`, {
    method: l.method ?? "GET",
    headers: {
      "Content-Type": "application/json",
      ...l.accessToken ? { Authorization: `Bearer ${l.accessToken}` } : {}
    },
    body: l.body ? JSON.stringify(l.body) : void 0
  });
  if (!c.ok) {
    const a = await c.json().catch(() => null), d = new Error(await we(c, a));
    throw (a == null ? void 0 : a.code) === "KIZ_DUPLICATE" && a.duplicateInfo && typeof a.duplicateInfo == "object" && Object.assign(d, { code: a.code, duplicate: !0, duplicateInfo: a.duplicateInfo }), d;
  }
  return await c.json();
}
function ye(n, l) {
  const c = new URLSearchParams();
  Object.entries(l).forEach(([d, u]) => {
    u !== void 0 && u !== "" && u !== !1 && c.set(d, String(u));
  });
  const a = c.toString();
  return a ? `${n}?${a}` : n;
}
async function we(n, l) {
  try {
    const c = l === void 0 ? await n.json() : l;
    return Array.isArray(c == null ? void 0 : c.message) ? c.message.join(`
`) : (c == null ? void 0 : c.message) || `HTTP ${n.status}`;
  } catch {
    return `HTTP ${n.status}`;
  }
}
const Ie = "logoff-wms:last-client", L = "logoff-wms:last-client-change";
function Se(n, l = {}) {
  var w, y;
  const c = ge(() => `${Ie}:${n}`, [n]), a = ((w = l.fixedClientId) == null ? void 0 : w.trim()) ?? "", d = ((y = l.initialClientId) == null ? void 0 : y.trim()) ?? "", [u, v] = i(
    () => a || (l.preferInitialClientId ? d : "") || Ne(c) || d
  );
  M(() => {
    a && v(a);
  }, [a]), M(() => {
    if (a || typeof window > "u") return;
    const h = (b) => {
      const f = Te(b, c);
      f && v(f);
    };
    return window.addEventListener(L, h), () => {
      window.removeEventListener(L, h);
    };
  }, [a, c]);
  const E = ve((h) => {
    v((b) => {
      const f = typeof h == "function" ? h(b) : h;
      return !a && f && typeof window < "u" && (window.localStorage.setItem(c, f), window.dispatchEvent(new CustomEvent(L, {
        detail: { storageKey: c, clientId: f }
      }))), f;
    });
  }, [a, c]);
  return [u, E];
}
function ke(n, l, c = "") {
  var a;
  return l.some((d) => d.id === n) ? n : c || ((a = l[0]) == null ? void 0 : a.id) || "";
}
function Te(n, l) {
  var a;
  const c = n.detail;
  return n.type !== L || (c == null ? void 0 : c.storageKey) !== l ? "" : ((a = c.clientId) == null ? void 0 : a.trim()) ?? "";
}
function Ne(n) {
  var l;
  return typeof window > "u" ? "" : ((l = window.localStorage.getItem(n)) == null ? void 0 : l.trim()) ?? "";
}
const Re = { синий: "#2563eb", красный: "#dc3545", черный: "#202733", белый: "#ffffff", "айвори / шампань": "#eee0bc", зеленый: "#27845b", айвори: "#eee0bc", шампань: "#eee0bc", пудровый: "#e7bdc6", розовый: "#e7a9bd", серый: "#929aa6", бежевый: "#d5bea0", желтый: "#edc64a", голубой: "#83bce4", коричневый: "#80563e", фиолетовый: "#8757aa" };
function Ae(n) {
  return Re[n.trim().toLocaleLowerCase("ru-RU").replace(/ё/g, "е")] ?? null;
}
function ne({ name: n }) {
  const l = Ae(n);
  return /* @__PURE__ */ t.createElement("span", { className: "fabric-color-label" }, /* @__PURE__ */ t.createElement("span", { "aria-hidden": "true", title: l ? `Условный образец: ${n}` : "Оттенок не задан", className: `fabric-color-swatch${l ? "" : " fabric-color-swatch--unknown"}`, style: l ? { backgroundColor: l } : void 0 }), n);
}
const ae = { SATIN: "Атлас", GABARDINE: "Габардин" };
function Le({ session: n }) {
  var Q, X, Z, Y;
  const [l, c] = i([]), [a, d] = Se(n.user.id), [u, v] = i(null), [E, w] = i(null), [y, h] = i("SATIN"), [b, f] = i("black"), [D, B] = i(""), [k, le] = i(1), [O, j] = i(""), [T, re] = i(5), [o, I] = i(!1), [_, p] = i(""), [W, F] = i(""), [N, ce] = i(""), [g, oe] = i("ADJUST"), [J, ie] = i(0), [U, se] = i(""), [K, ue] = i(""), [$, me] = i(""), [G, de] = i(""), [H, Ee] = i(1), m = te(0), R = te(null), C = n.accessToken, P = "/warehouse/fabric-rolls/" + encodeURIComponent(a), fe = !n.user.roleCodes.includes("CLIENT") && n.user.permissionCodes.some((e) => ["stock:write", "system:admin"].includes(e)), be = !n.user.roleCodes.includes("CLIENT") && n.user.permissionCodes.some((e) => ["clients:write", "system:admin"].includes(e));
  M(() => {
    let e = !0;
    return Ce(C).then((r) => {
      e && (c(r), d((s) => ke(s, r)));
    }).catch((r) => {
      e && p(String(r.message));
    }), () => {
      e = !1;
    };
  }, [C]);
  async function x() {
    const e = ++m.current;
    p("");
    try {
      const [r, s] = await Promise.all([S(P, { accessToken: C }), S("/warehouse/fabric-catalog/" + encodeURIComponent(a), { accessToken: C })]);
      e === m.current && (v(r), w(s));
    } catch (r) {
      e === m.current && p(r instanceof Error ? r.message : String(r));
    }
  }
  M(() => (v(null), w(null), j(""), f("black"), F(""), R.current = null, a && x(), () => {
    m.current++;
  }), [a, C, n.user.activeWarehouseId]);
  async function z(e) {
    if (!E || o) return;
    I(!0), p("");
    const r = m.current;
    try {
      const s = await S("/warehouse/fabric-catalog/" + encodeURIComponent(a), { accessToken: C, method: "POST", body: { action: e, material: y, name: D, skuId: O, colorId: b, lengthMm: Math.round(T * 1e3), version: E.version } });
      if (r !== m.current) return;
      w(s.catalog), s.result.color && (f(s.result.color.id), B("")), F(s.result.reused ? "Такой цвет уже есть — он выбран." : e === "CREATE_COLOR" ? "Цвет добавлен и выбран для приёмки." : "Привязка товара сохранена."), await x();
    } catch (s) {
      r === m.current && p(s instanceof Error ? s.message : String(s));
    } finally {
      I(!1);
    }
  }
  async function q(e) {
    var ee;
    if (o || !u) return;
    I(!0), p("");
    const r = m.current, s = JSON.stringify({ clientId: a, body: e });
    ((ee = R.current) == null ? void 0 : ee.fingerprint) !== s && (R.current = { fingerprint: s, key: crypto.randomUUID() });
    try {
      const A = await S(P, { method: "POST", accessToken: C, body: { ...e, version: u.version, operationKey: R.current.key } });
      r === m.current && (v(A), R.current = null, F(e.action === "RECEIVE" ? "Рулоны приняты." : "Операция с рулоном сохранена."));
    } catch (A) {
      r === m.current && p(A instanceof Error ? A.message : String(A));
    } finally {
      I(!1);
    }
  }
  async function pe() {
    if (o) return;
    I(!0), p("");
    const e = m.current;
    try {
      const r = await S(P, { method: "PUT", accessToken: C, body: { enabled: !0 } });
      e === m.current && v(r);
    } catch (r) {
      e === m.current && p(r instanceof Error ? r.message : String(r));
    } finally {
      I(!1);
    }
  }
  const V = [...Object.entries((E == null ? void 0 : E.baseColors) ?? {}).map(([e, r]) => ({ id: e, name: r })), ...(E == null ? void 0 : E.colors.filter((e) => e.material === y)) ?? []];
  return /* @__PURE__ */ t.createElement("section", { className: "warehouse-panel fabric-warehouse", "aria-label": "Ткани: хранение и учёт" }, /* @__PURE__ */ t.createElement("header", { className: "fabric-heading" }, /* @__PURE__ */ t.createElement("div", null, /* @__PURE__ */ t.createElement("span", { className: "fabric-eyebrow" }, "Склад · ткани"), /* @__PURE__ */ t.createElement("h2", null, "Ткани: хранение и учёт"), /* @__PURE__ */ t.createElement("p", null, "Рулоны, готовые отрезы и движение ткани"))), /* @__PURE__ */ t.createElement("div", { className: "fabric-toolbar" }, /* @__PURE__ */ t.createElement("label", null, "Клиент", /* @__PURE__ */ t.createElement("select", { value: a, disabled: o, onChange: (e) => d(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "" }, "Выберите клиента"), l.map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.name)))), a ? /* @__PURE__ */ t.createElement("button", { type: "button", disabled: o, onClick: () => void x() }, "Обновить") : null), _ ? /* @__PURE__ */ t.createElement("p", { role: "alert" }, _) : null, W ? /* @__PURE__ */ t.createElement("p", { role: "status" }, W) : null, u && !u.enabled ? /* @__PURE__ */ t.createElement("div", null, /* @__PURE__ */ t.createElement("p", null, "Рулонный учёт у клиента выключен."), be ? /* @__PURE__ */ t.createElement("button", { disabled: o, onClick: () => void pe() }, "Включить «Товар в рулонах»") : /* @__PURE__ */ t.createElement("p", null, "Для включения обратитесь к администратору.")) : null, u != null && u.enabled && E ? /* @__PURE__ */ t.createElement(t.Fragment, null, /* @__PURE__ */ t.createElement("p", null, "Рулон — 100 м. Остатки рулонов и готовые отрезы учитываются отдельно."), /* @__PURE__ */ t.createElement("div", { className: "warehouse-topic-grid" }, (Q = u.groups) == null ? void 0 : Q.map((e) => /* @__PURE__ */ t.createElement("article", { className: "warehouse-panel", key: e.key }, /* @__PURE__ */ t.createElement("h3", { className: "fabric-card-title" }, /* @__PURE__ */ t.createElement("span", { className: "fabric-material" }, ae[e.material]), /* @__PURE__ */ t.createElement(ne, { name: e.colorName })), /* @__PURE__ */ t.createElement("p", null, "Целых: ", e.whole, " · открытых: ", e.open, " · в рулонах: ", e.rawMeters.toLocaleString("ru-RU"), " м"), /* @__PURE__ */ t.createElement("p", null, "Объём хранения: ", e.rawLiters.toLocaleString("ru-RU"), " л"), /* @__PURE__ */ t.createElement("p", null, "Готовые отрезы: ", e.ready.reduce((r, s) => r + s.pieces, 0), " шт."), /* @__PURE__ */ t.createElement("p", null, "FBS: ", e.fbs.pieces, " отрезов / ", e.fbs.meters, " м · FBO: ", e.fbo.pieces, " отрезов / ", e.fbo.meters, " м"), /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "Остаток каждого рулона"), e.rolls.map((r) => /* @__PURE__ */ t.createElement("p", { key: r.id }, r.code, ": ", (r.remainingMm / 1e3).toLocaleString("ru-RU"), " м")))))), fe ? /* @__PURE__ */ t.createElement(t.Fragment, null, /* @__PURE__ */ t.createElement("section", { className: "fabric-intake" }, /* @__PURE__ */ t.createElement("div", { className: "fabric-section-heading" }, /* @__PURE__ */ t.createElement("h3", null, "Приёмка новых рулонов"), /* @__PURE__ */ t.createElement("span", null, "1 рулон = 100 м")), /* @__PURE__ */ t.createElement("div", { className: "fabric-intake-selects" }, /* @__PURE__ */ t.createElement("label", null, "Ткань", /* @__PURE__ */ t.createElement("select", { disabled: o, value: y, onChange: (e) => {
    h(e.target.value), f("black");
  } }, Object.entries(ae).map(([e, r]) => /* @__PURE__ */ t.createElement("option", { key: e, value: e }, r)))), /* @__PURE__ */ t.createElement("label", null, "Цвет", /* @__PURE__ */ t.createElement("select", { disabled: o, value: b, onChange: (e) => f(e.target.value) }, V.map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.name)))), /* @__PURE__ */ t.createElement("span", { className: "fabric-selected-color" }, /* @__PURE__ */ t.createElement(ne, { name: ((X = V.find((e) => e.id === b)) == null ? void 0 : X.name) ?? b }))), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), z("CREATE_COLOR");
  } }, /* @__PURE__ */ t.createElement("label", null, "Новый цвет", /* @__PURE__ */ t.createElement("input", { value: D, maxLength: 80, disabled: o, onChange: (e) => B(e.target.value), placeholder: "Например, Пудровый" })), /* @__PURE__ */ t.createElement("button", { disabled: o || !D.trim() }, "Добавить цвет")), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), q({ action: "RECEIVE", material: y, color: b, count: k });
  } }, /* @__PURE__ */ t.createElement("label", null, "Количество рулонов", /* @__PURE__ */ t.createElement("input", { type: "number", min: 1, max: 500, step: 1, value: k, disabled: o, onChange: (e) => le(Number(e.target.value)) })), /* @__PURE__ */ t.createElement("button", { disabled: o || !Number.isInteger(k) || k < 1 || k > 500 }, "Принять рулоны"))), /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "Операции с рулоном"), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), q(g === "CUT" ? { action: g, rollId: N, barcode: K, boxCode: $, kiz: G, count: H } : g === "ADJUST" ? { action: g, rollId: N, deltaMm: Math.round(J * 1e3), reason: U } : { action: g, rollId: N, reason: U });
  } }, /* @__PURE__ */ t.createElement("label", null, "Рулон", /* @__PURE__ */ t.createElement("select", { value: N, disabled: o, onChange: (e) => ce(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "" }, "Выберите рулон"), (Z = u.groups) == null ? void 0 : Z.flatMap((e) => e.rolls).filter((e) => e.warehouseId === n.user.activeWarehouseId && e.remainingMm > 0).map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.code, " · ", e.remainingMm / 1e3, " м")))), /* @__PURE__ */ t.createElement("label", null, "Действие", /* @__PURE__ */ t.createElement("select", { value: g, disabled: o, onChange: (e) => oe(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "ADJUST" }, "Фактическая корректировка ±2 м"), /* @__PURE__ */ t.createElement("option", { value: "CUT" }, "Нарезать готовые отрезы"), /* @__PURE__ */ t.createElement("option", { value: "WRITE_OFF" }, "Списать остаток рулона"))), g === "CUT" ? /* @__PURE__ */ t.createElement(t.Fragment, null, /* @__PURE__ */ t.createElement("label", null, "Штрихкод отреза", /* @__PURE__ */ t.createElement("input", { value: K, disabled: o, onChange: (e) => ue(e.target.value) })), /* @__PURE__ */ t.createElement("label", null, "Короб готовых отрезов", /* @__PURE__ */ t.createElement("input", { value: $, disabled: o, onChange: (e) => me(e.target.value) })), /* @__PURE__ */ t.createElement("label", null, "Количество отрезов", /* @__PURE__ */ t.createElement("input", { type: "number", min: 1, max: 500, step: 1, value: H, disabled: o, onChange: (e) => Ee(Number(e.target.value)) })), /* @__PURE__ */ t.createElement("label", null, "КИЗ, по одному на строку", /* @__PURE__ */ t.createElement("textarea", { value: G, disabled: o, onChange: (e) => de(e.target.value) }))) : /* @__PURE__ */ t.createElement(t.Fragment, null, g === "ADJUST" ? /* @__PURE__ */ t.createElement("label", null, "Изменение, м", /* @__PURE__ */ t.createElement("input", { type: "number", min: -2, max: 2, step: 1e-3, value: J, disabled: o, onChange: (e) => ie(Number(e.target.value)) })) : /* @__PURE__ */ t.createElement("p", null, "Будет списан весь остаток выбранного рулона."), /* @__PURE__ */ t.createElement("label", null, "Причина", /* @__PURE__ */ t.createElement("input", { value: U, disabled: o, onChange: (e) => se(e.target.value) }))), /* @__PURE__ */ t.createElement("button", { disabled: o || !N || g !== "CUT" && U.trim().length < 5 }, "Сохранить операцию с рулоном"))), /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "Привязка к товару маркетплейса"), /* @__PURE__ */ t.createElement("p", null, "Выберите ткань и цвет выше. Для каждой длины отреза привяжите соответствующую карточку товара WMS."), /* @__PURE__ */ t.createElement("form", { onSubmit: (e) => {
    e.preventDefault(), z("BIND_SKU");
  } }, /* @__PURE__ */ t.createElement("label", null, "Товар", /* @__PURE__ */ t.createElement("select", { value: O, disabled: o, onChange: (e) => j(e.target.value) }, /* @__PURE__ */ t.createElement("option", { value: "" }, "Выберите товар клиента"), E.skus.map((e) => /* @__PURE__ */ t.createElement("option", { key: e.id, value: e.id }, e.marketplace ?? "WMS", " · ", e.name, " · ", e.offerId ?? e.internalSku, e.binding ? " · привязан" : "")))), /* @__PURE__ */ t.createElement("label", null, "Длина отреза, м", /* @__PURE__ */ t.createElement("input", { type: "number", min: 1e-3, max: 100, step: 1e-3, value: T, disabled: o, onChange: (e) => re(Number(e.target.value)) })), /* @__PURE__ */ t.createElement("button", { disabled: o || !O || !Number.isFinite(T) || T <= 0 || T > 100 }, "Сохранить привязку")))) : null, /* @__PURE__ */ t.createElement("details", null, /* @__PURE__ */ t.createElement("summary", null, "История рулонного учёта"), (Y = u.history) == null ? void 0 : Y.map((e, r) => {
    var s;
    return /* @__PURE__ */ t.createElement("p", { key: r }, new Date(e.createdAt).toLocaleString("ru-RU"), " · ", e.action, " ", ((s = e.payload) == null ? void 0 : s.reason) ?? "");
  }))) : null);
}
export {
  Le as FabricWarehousePanel
};
