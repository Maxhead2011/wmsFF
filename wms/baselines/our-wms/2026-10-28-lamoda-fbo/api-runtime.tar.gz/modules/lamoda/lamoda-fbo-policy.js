"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lamodaAssemblyEnabled = void 0;
exports.lamodaShipmentId = lamodaShipmentId;
exports.lamodaShipmentLines = lamodaShipmentLines;
exports.resolveLamodaLines = resolveLamodaLines;
const common_1 = require("@nestjs/common");
const lamoda_policy_1 = require("./lamoda-policy");
const lamodaAssemblyEnabled = () => process.env.WMS_LAMODA_ENABLED === 'true' && process.env.WMS_LAMODA_FBO_ASSEMBLY_ENABLED === 'true';
exports.lamodaAssemblyEnabled = lamodaAssemblyEnabled;
// FIX: URL parsing never fetches arbitrary user-supplied hosts. Live cabinet URL shape remains to be verified.
function lamodaShipmentId(input) {
    let id = (0, lamoda_policy_1.text)(input, 'ID или ссылка поставки', 2000);
    if (/^https?:/i.test(id)) {
        let u;
        try {
            u = new URL(id);
        }
        catch {
            throw new common_1.BadRequestException('Некорректная ссылка.');
        }
        if (u.protocol !== 'https:' || u.hostname !== 'seller.lamoda.tech' || u.port || u.username || u.password || u.search || u.hash)
            throw new common_1.BadRequestException('Введите ID поставки либо прямую ссылку из кабинета Lamoda без дополнительных параметров.');
        id = u.pathname.split('/').filter(Boolean).pop() ?? '';
    }
    if (!/^(?:MPG\d+|\d+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(id))
        throw new common_1.BadRequestException('Не удалось определить ID. Скопируйте идентификатор поставки Lamoda.');
    return id;
}
function lamodaShipmentLines(items, destination) {
    if (!items.length || items.length > 1000)
        throw new common_1.BadRequestException('В поставке должно быть от 1 до 1000 строк.');
    const lines = items.map(item => {
        if (typeof item.sku !== 'string' || !item.sku.trim() || typeof item.ean !== 'string' || !/^\d{8,14}$/.test(item.ean) || !Number.isSafeInteger(item.quantityPlanned) || Number(item.quantityPlanned) < 0 || Number(item.quantityPlanned) > 100000)
            throw new common_1.BadRequestException('В составе Lamoda отсутствуют корректные SKU, ШК или плановое количество.');
        return { remoteSku: item.sku, barcode: item.ean, quantity: Number(item.quantityPlanned), article: '', destination };
    }).filter(l => l.quantity > 0);
    if (!lines.length)
        throw new common_1.BadRequestException('В поставке нет товара к отбору.');
    return lines;
}
function resolveLamodaLines(lines, products) {
    const grouped = new Map();
    const byDirection = new Map();
    for (const [index, line] of lines.entries()) {
        const matches = products.filter(p => p.isPresent && p.linkState === 'CONFIRMED' && p.skuId && p.barcode === line.barcode && (!line.remoteSku || p.remoteSku === line.remoteSku) && (!line.article || p.externalSku === line.article));
        if (matches.length !== 1)
            throw new common_1.BadRequestException(`Строка ${index + 2}: подтвердите однозначное соответствие товара Lamoda и WMS.`);
        const skuId = matches[0].skuId, name = line.destination || 'Основная поставка';
        const row = grouped.get(skuId) ?? { skuId, barcode: line.barcode, quantity: 0 };
        row.quantity += line.quantity;
        grouped.set(skuId, row);
        const dir = byDirection.get(name) ?? new Map(), item = dir.get(skuId) ?? { skuId, barcode: line.barcode, quantity: 0 };
        item.quantity += line.quantity;
        dir.set(skuId, item);
        byDirection.set(name, dir);
    }
    return { items: [...grouped.values()], directions: [...byDirection].map(([name, items]) => ({ name, items: [...items.values()] })) };
}
