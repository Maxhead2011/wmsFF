"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LamodaImportShipmentDto = exports.LamodaImportDto = exports.LamodaLinkDto = exports.LamodaSyncDto = exports.LamodaUpdateAccountDto = exports.LamodaCreateAccountDto = void 0;
const class_validator_1 = require("class-validator");
const lamoda_client_1 = require("./lamoda-client");
// FIX: DTO classes preserve ValidationPipe checks at runtime (interfaces do not).
class LamodaCreateAccountDto {
    clientId;
    name;
    sellerId;
    oauthClientId;
    secret;
    fboEnabled;
    fbsEnabled;
}
exports.LamodaCreateAccountDto = LamodaCreateAccountDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaCreateAccountDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaCreateAccountDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaCreateAccountDto.prototype, "sellerId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaCreateAccountDto.prototype, "oauthClientId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(2000),
    __metadata("design:type", String)
], LamodaCreateAccountDto.prototype, "secret", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], LamodaCreateAccountDto.prototype, "fboEnabled", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], LamodaCreateAccountDto.prototype, "fbsEnabled", void 0);
class LamodaUpdateAccountDto {
    secret;
    isActive;
}
exports.LamodaUpdateAccountDto = LamodaUpdateAccountDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(2000),
    __metadata("design:type", String)
], LamodaUpdateAccountDto.prototype, "secret", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], LamodaUpdateAccountDto.prototype, "isActive", void 0);
class LamodaSyncDto {
    kind;
}
exports.LamodaSyncDto = LamodaSyncDto;
__decorate([
    (0, class_validator_1.IsIn)(lamoda_client_1.lamodaResources),
    __metadata("design:type", Object)
], LamodaSyncDto.prototype, "kind", void 0);
class LamodaLinkDto {
    skuId;
}
exports.LamodaLinkDto = LamodaLinkDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaLinkDto.prototype, "skuId", void 0);
class LamodaImportDto {
    title;
    warehouseId;
    remoteShipmentId;
}
exports.LamodaImportDto = LamodaImportDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaImportDto.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaImportDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaImportDto.prototype, "remoteShipmentId", void 0);
class LamodaImportShipmentDto {
    reference;
    warehouseId;
    title;
}
exports.LamodaImportShipmentDto = LamodaImportShipmentDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(2000),
    __metadata("design:type", String)
], LamodaImportShipmentDto.prototype, "reference", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaImportShipmentDto.prototype, "warehouseId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], LamodaImportShipmentDto.prototype, "title", void 0);
