"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unboxedFboEnabled = void 0;
exports.unboxedFree = unboxedFree;
exports.pickUnboxed = pickUnboxed;
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const wb_order_stock_lifecycle_1 = require("../../common/stock/wb-order-stock-lifecycle");
// FIX: storage mode changes only the source of picking, never outbound packing.
const unboxedFboEnabled = () => process.env.WMS_FBO_UNBOXED_PICK_ENABLED === 'true';
exports.unboxedFboEnabled = unboxedFboEnabled;
async function unboxedFree(tx, r, skuIds) {
    if (!r.warehouseId)
        throw new common_1.BadRequestException('Укажите филиал заявки.');
    const rows = await tx.stockBalance.findMany({ where: { clientId: r.clientId, warehouseId: r.warehouseId, skuId: { in: skuIds }, boxId: null, palletId: null, status: 'AVAILABLE' } });
    const reserved = await (0, wb_order_stock_lifecycle_1.wbReservationQuantities)(tx, r.clientId, skuIds, r.warehouseId, r.id);
    return new Map(skuIds.map(id => [id, Math.max(0, rows.filter(b => b.skuId === id).reduce((n, b) => n + b.quantity, 0) - (reserved.get(id) ?? 0))]));
}
// Runs within the normal serializable request/action transaction and shares its replay guard.
async function pickUnboxed(tx, r, lines, dto, key, user, move, exactMark) {
    if (!(0, exports.unboxedFboEnabled)() || !r.client.storesWithoutBoxes || dto.action !== 'PICK_UNIT' || dto.sourceBoxCode || dto.palletCode)
        throw new common_1.BadRequestException('Для хранения без коробов сканируйте только ШК товара.');
    const line = lines.find(l => l.remaining > 0 && (l.barcode === dto.barcode || l.sku.barcodes.some((b) => b.value === dto.barcode)));
    if (!line)
        throw new common_1.BadRequestException('Этот товар не требуется или уже полностью отобран.');
    const free = await unboxedFree(tx, r, [line.skuId]);
    if ((free.get(line.skuId) ?? 0) < 1)
        throw new common_1.ConflictException('Нет свободного остатка: товар отсутствует или зарезервирован другой заявкой.');
    const marked = (line.sku.needsChestnyZnak && !line.sku.isUnmarked) || !!await tx.productMark.findFirst({ where: { clientId: r.clientId, skuId: line.skuId, boxId: null, status: 'AVAILABLE', stockMovement: { warehouseId: r.warehouseId } } });
    if (marked && !dto.kiz)
        throw new common_1.BadRequestException('После ШК отсканируйте КИЗ.');
    const mark = dto.kiz ? await exactMark(tx, dto.kiz) : null;
    if (mark) {
        const evidence = mark.stockMovementId ? await tx.stockMovement.findUnique({ where: { id: mark.stockMovementId } }) : null;
        if (mark.clientId !== r.clientId || mark.skuId !== line.skuId || mark.boxId !== null || mark.status !== 'AVAILABLE' || evidence?.warehouseId !== r.warehouseId)
            throw new common_1.ConflictException('КИЗ не доступен в общем остатке выбранного филиала.');
    }
    const holding = await tx.box.upsert({ where: { code: `FBO-PICK-${r.id}` }, create: { code: `FBO-PICK-${r.id}`, clientId: r.clientId, warehouseId: r.warehouseId, status: 'fbo-picking' }, update: {} });
    const unitId = (0, node_crypto_1.randomUUID)(), movement = await move(tx, r, line.skuId, null, holding.id, 'AVAILABLE', 'PACKING', 1, `${key}:${unitId}`, user);
    if (mark) {
        const changed = await tx.productMark.updateMany({ where: { id: mark.id, boxId: null, status: 'AVAILABLE' }, data: { boxId: holding.id, status: 'PACKING', stockMovementId: movement.id } });
        if (changed.count !== 1)
            throw new common_1.ConflictException('КИЗ уже отобран.');
    }
    // Empty source fields explicitly mean no physical source box; neither is a Box foreign key.
    await tx.fboAssemblyUnit.create({ data: { id: unitId, requestId: r.id, requestItemId: line.id, skuId: line.skuId, barcode: line.barcode, sourceBoxId: '', sourceBoxCode: '', wholeBox: false, markId: mark?.id, activeMarkId: mark?.id, kiz: mark?.value, pickedByUserId: user.id } });
}
